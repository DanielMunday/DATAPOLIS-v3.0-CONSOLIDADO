# DATAPOLIS v4.0 - PARTE 5: COMPLIANCE SUITE

## Arquitectura Empresarial Exhaustiva - Vertical de Cumplimiento Normativo

**Versión**: 4.0.0  
**Fecha**: Febrero 2026  
**Clasificación**: Documentación Técnica Empresarial  
**Autor**: DATAPOLIS SpA - Arquitectura de Soluciones

---

# ÍNDICE PARTE 5

1. [Visión General del Compliance Suite](#1-visión-general)
2. [Módulo C01-GRC: Governance, Risk & Compliance](#2-módulo-c01-grc)
3. [Módulo C02-AML: Anti-Money Laundering](#3-módulo-c02-aml)
4. [Módulo C03-KYC: Know Your Customer](#4-módulo-c03-kyc)
5. [Módulo C04-PEP: Politically Exposed Persons](#5-módulo-c04-pep)
6. [Módulo C05-SAR: Suspicious Activity Reporting](#6-módulo-c05-sar)
7. [Módulo C06-CTR: Currency Transaction Reporting](#7-módulo-c06-ctr)
8. [Módulo C07-FATCA: Foreign Account Tax Compliance](#8-módulo-c07-fatca)
9. [Módulo C08-CRS: Common Reporting Standard](#9-módulo-c08-crs)
10. [Módulo C09-GDPR: Data Protection & Privacy](#10-módulo-c09-gdpr)
11. [Arquitectura Técnica Integrada](#11-arquitectura-técnica)
12. [Implementación de Código Completa](#12-implementación-código)

---

# 1. VISIÓN GENERAL

## 1.1 Propósito del Compliance Suite

El Compliance Suite de DATAPOLIS integra **9 módulos especializados** para gestión integral del cumplimiento normativo en instituciones financieras, inmobiliarias y corporativas en Chile y Latinoamérica.

### 1.1.1 Regulaciones Cubiertas

| Jurisdicción | Regulación | Módulo(s) |
|--------------|------------|-----------|
| Chile | Ley 19.913 (UAF) | C02-AML, C05-SAR |
| Chile | Ley 20.393 (Resp. Penal PJ) | C01-GRC |
| Chile | Circular UAF N°57 | C03-KYC, C04-PEP |
| Chile | NCG 380 CMF | C01-GRC |
| Internacional | FATF 40 Recommendations | C02-AML |
| USA | FATCA | C07-FATCA |
| OCDE | CRS | C08-CRS |
| UE | GDPR | C09-GDPR |
| Chile | Ley 19.628 (Datos) | C09-GDPR |

### 1.1.2 Arquitectura del Suite

```
┌─────────────────────────────────────────────────────────────────────┐
│                     COMPLIANCE SUITE v4.0                            │
├─────────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                  │
│  │  C01-GRC    │  │  C02-AML    │  │  C03-KYC    │                  │
│  │ Governance  │  │Anti-Lavado  │  │   Clientes  │                  │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘                  │
│         │                │                │                          │
│  ┌──────┴────────────────┴────────────────┴──────┐                  │
│  │           MOTOR DE REGLAS COMPLIANCE           │                  │
│  │      (Drools + Python Rules Engine)            │                  │
│  └──────┬────────────────┬────────────────┬──────┘                  │
│         │                │                │                          │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐                  │
│  │  C04-PEP    │  │  C05-SAR    │  │  C06-CTR    │                  │
│  │  Personas   │  │  Reportes   │  │Transacciones│                  │
│  │  Expuestas  │  │ Sospechosos │  │  Efectivo   │                  │
│  └─────────────┘  └─────────────┘  └─────────────┘                  │
│                                                                      │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                  │
│  │  C07-FATCA  │  │  C08-CRS    │  │  C09-GDPR   │                  │
│  │  US Fiscal  │  │ Intercambio │  │  Privacidad │                  │
│  │  Compliance │  │ Automático  │  │    Datos    │                  │
│  └─────────────┘  └─────────────┘  └─────────────┘                  │
└─────────────────────────────────────────────────────────────────────┘
```

---

# 2. MÓDULO C01-GRC: GOVERNANCE, RISK & COMPLIANCE

## 2.1 Descripción Funcional

### 2.1.1 Propósito
Sistema integrado de gestión de gobierno corporativo, riesgos y cumplimiento basado en el marco COSO ERM 2017 y ISO 31000:2018.

### 2.1.2 Funcionalidades Principales

| ID | Funcionalidad | Descripción |
|----|---------------|-------------|
| GRC-01 | Gestión de Políticas | Repositorio versionado de políticas con workflow de aprobación |
| GRC-02 | Matriz de Riesgos | Identificación, evaluación y tratamiento de riesgos |
| GRC-03 | Controles Internos | Mapeo de controles a riesgos con testing periódico |
| GRC-04 | Incidentes | Registro, investigación y remediación de incidentes |
| GRC-05 | Auditorías | Planificación y ejecución de auditorías internas |
| GRC-06 | Obligaciones | Calendario de obligaciones regulatorias |
| GRC-07 | KRIs/KPIs | Dashboard de indicadores de riesgo y desempeño |
| GRC-08 | Reportería | Generación automática de informes al directorio |

### 2.1.3 Metodología de Evaluación de Riesgos

```
Riesgo Inherente = Probabilidad × Impacto

Probabilidad (P):
├── 5: Casi Cierto (>90%)
├── 4: Probable (70-90%)
├── 3: Posible (30-70%)
├── 2: Improbable (10-30%)
└── 1: Raro (<10%)

Impacto (I):
├── 5: Catastrófico (>$10M, pérdida licencia)
├── 4: Mayor ($1M-$10M, sanción CMF)
├── 3: Moderado ($100K-$1M, multa)
├── 2: Menor ($10K-$100K, observación)
└── 1: Insignificante (<$10K, hallazgo)

Riesgo Residual = Riesgo Inherente × (1 - Efectividad Control)

Efectividad Control:
├── 95%: Excelente (automatizado, probado)
├── 80%: Bueno (documentado, consistente)
├── 60%: Adecuado (existe, variable)
├── 40%: Débil (informal, inconsistente)
└── 20%: Inexistente (sin control)
```

## 2.2 Arquitectura Técnica C01-GRC

### 2.2.1 Modelo de Datos

```sql
-- =============================================================================
-- COMPLIANCE SUITE: C01-GRC - GOVERNANCE, RISK & COMPLIANCE
-- PostgreSQL 16 Schema
-- =============================================================================

-- Schema dedicado
CREATE SCHEMA IF NOT EXISTS compliance_grc;
SET search_path TO compliance_grc, public;

-- -----------------------------------------------------------------------------
-- CATÁLOGOS BASE
-- -----------------------------------------------------------------------------

CREATE TABLE risk_categories (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    parent_id INTEGER REFERENCES risk_categories(id),
    description TEXT,
    coso_component VARCHAR(50), -- Ambiente Control, Evaluación Riesgos, etc.
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Categorías COSO ERM
INSERT INTO risk_categories (code, name, coso_component) VALUES
('STR', 'Estratégico', 'Strategy & Objective-Setting'),
('OPR', 'Operacional', 'Performance'),
('FIN', 'Financiero', 'Performance'),
('CMP', 'Cumplimiento', 'Review & Revision'),
('REP', 'Reputacional', 'Information, Communication & Reporting'),
('TEC', 'Tecnológico', 'Performance'),
('CYB', 'Ciberseguridad', 'Performance'),
('LEG', 'Legal', 'Review & Revision');

CREATE TABLE control_types (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    nature VARCHAR(20) CHECK (nature IN ('Preventivo', 'Detectivo', 'Correctivo')),
    automation VARCHAR(20) CHECK (automation IN ('Manual', 'Semi-automatico', 'Automatico')),
    frequency VARCHAR(20)
);

INSERT INTO control_types (code, name, nature, automation) VALUES
('SEG', 'Segregación de Funciones', 'Preventivo', 'Manual'),
('APR', 'Aprobación Multinivel', 'Preventivo', 'Semi-automatico'),
('REC', 'Reconciliación', 'Detectivo', 'Automatico'),
('MON', 'Monitoreo Continuo', 'Detectivo', 'Automatico'),
('AUD', 'Auditoría Interna', 'Detectivo', 'Manual'),
('INC', 'Gestión Incidentes', 'Correctivo', 'Semi-automatico');

-- -----------------------------------------------------------------------------
-- POLÍTICAS Y PROCEDIMIENTOS
-- -----------------------------------------------------------------------------

CREATE TABLE policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(30) UNIQUE NOT NULL,
    title VARCHAR(200) NOT NULL,
    version VARCHAR(10) NOT NULL,
    status VARCHAR(20) DEFAULT 'Borrador' 
        CHECK (status IN ('Borrador', 'En_Revision', 'Aprobada', 'Vigente', 'Obsoleta')),
    category VARCHAR(50),
    owner_id UUID NOT NULL, -- Referencia a usuarios
    approver_id UUID,
    effective_date DATE,
    review_date DATE,
    document_url TEXT,
    summary TEXT,
    regulatory_references JSONB DEFAULT '[]',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    approved_at TIMESTAMPTZ
);

CREATE TABLE policy_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id UUID REFERENCES policies(id) ON DELETE CASCADE,
    version VARCHAR(10) NOT NULL,
    changes_summary TEXT,
    document_content TEXT,
    created_by UUID NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE policy_acknowledgments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id UUID REFERENCES policies(id),
    user_id UUID NOT NULL,
    acknowledged_at TIMESTAMPTZ DEFAULT NOW(),
    ip_address INET,
    user_agent TEXT
);

-- -----------------------------------------------------------------------------
-- REGISTRO DE RIESGOS
-- -----------------------------------------------------------------------------

CREATE TABLE risks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(30) UNIQUE NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    category_id INTEGER REFERENCES risk_categories(id),
    
    -- Evaluación Inherente
    inherent_probability INTEGER CHECK (inherent_probability BETWEEN 1 AND 5),
    inherent_impact INTEGER CHECK (inherent_impact BETWEEN 1 AND 5),
    inherent_score INTEGER GENERATED ALWAYS AS (inherent_probability * inherent_impact) STORED,
    
    -- Evaluación Residual (post-controles)
    residual_probability INTEGER CHECK (residual_probability BETWEEN 1 AND 5),
    residual_impact INTEGER CHECK (residual_impact BETWEEN 1 AND 5),
    residual_score INTEGER GENERATED ALWAYS AS (residual_probability * residual_impact) STORED,
    
    -- Clasificación
    risk_level VARCHAR(20) GENERATED ALWAYS AS (
        CASE 
            WHEN residual_probability * residual_impact >= 20 THEN 'Crítico'
            WHEN residual_probability * residual_impact >= 12 THEN 'Alto'
            WHEN residual_probability * residual_impact >= 6 THEN 'Medio'
            ELSE 'Bajo'
        END
    ) STORED,
    
    -- Tratamiento
    treatment_strategy VARCHAR(20) CHECK (treatment_strategy IN ('Mitigar', 'Transferir', 'Aceptar', 'Evitar')),
    treatment_plan TEXT,
    target_residual_score INTEGER,
    
    -- Responsables
    risk_owner_id UUID NOT NULL,
    business_unit VARCHAR(100),
    
    -- Estado
    status VARCHAR(20) DEFAULT 'Identificado'
        CHECK (status IN ('Identificado', 'Evaluado', 'En_Tratamiento', 'Monitoreado', 'Cerrado')),
    
    -- Auditoría
    last_review_date DATE,
    next_review_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para consultas frecuentes
CREATE INDEX idx_risks_category ON risks(category_id);
CREATE INDEX idx_risks_level ON risks(risk_level);
CREATE INDEX idx_risks_owner ON risks(risk_owner_id);
CREATE INDEX idx_risks_residual ON risks(residual_score DESC);

-- -----------------------------------------------------------------------------
-- CONTROLES INTERNOS
-- -----------------------------------------------------------------------------

CREATE TABLE controls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(30) UNIQUE NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    control_type_id INTEGER REFERENCES control_types(id),
    
    -- Características
    nature VARCHAR(20) CHECK (nature IN ('Preventivo', 'Detectivo', 'Correctivo')),
    automation_level VARCHAR(20) CHECK (automation_level IN ('Manual', 'Semi-automatico', 'Automatico')),
    frequency VARCHAR(30), -- Continuo, Diario, Semanal, Mensual, etc.
    
    -- Efectividad
    design_effectiveness INTEGER CHECK (design_effectiveness BETWEEN 0 AND 100),
    operating_effectiveness INTEGER CHECK (operating_effectiveness BETWEEN 0 AND 100),
    overall_effectiveness INTEGER GENERATED ALWAYS AS (
        (design_effectiveness + operating_effectiveness) / 2
    ) STORED,
    
    -- Responsables
    control_owner_id UUID NOT NULL,
    executor_id UUID,
    
    -- Evidencia
    evidence_requirements TEXT,
    evidence_location TEXT,
    
    -- Estado
    status VARCHAR(20) DEFAULT 'Diseñado'
        CHECK (status IN ('Diseñado', 'Implementado', 'Operativo', 'Inefectivo', 'Suspendido')),
    
    last_test_date DATE,
    next_test_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Relación Riesgos-Controles (N:M)
CREATE TABLE risk_control_mappings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    risk_id UUID REFERENCES risks(id) ON DELETE CASCADE,
    control_id UUID REFERENCES controls(id) ON DELETE CASCADE,
    coverage_percentage INTEGER CHECK (coverage_percentage BETWEEN 0 AND 100),
    is_key_control BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(risk_id, control_id)
);

-- -----------------------------------------------------------------------------
-- TESTING DE CONTROLES
-- -----------------------------------------------------------------------------

CREATE TABLE control_tests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    control_id UUID REFERENCES controls(id) ON DELETE CASCADE,
    test_date DATE NOT NULL,
    tester_id UUID NOT NULL,
    
    -- Metodología
    test_type VARCHAR(30) CHECK (test_type IN ('Walkthrough', 'Muestreo', 'Reperformance', 'Observacion')),
    sample_size INTEGER,
    population_size INTEGER,
    
    -- Resultados
    design_conclusion VARCHAR(20) CHECK (design_conclusion IN ('Efectivo', 'Parcial', 'Inefectivo')),
    operating_conclusion VARCHAR(20) CHECK (operating_conclusion IN ('Efectivo', 'Parcial', 'Inefectivo')),
    exceptions_found INTEGER DEFAULT 0,
    
    -- Documentación
    test_procedures TEXT,
    findings TEXT,
    recommendations TEXT,
    evidence_references JSONB DEFAULT '[]',
    
    -- Seguimiento
    remediation_required BOOLEAN DEFAULT FALSE,
    remediation_due_date DATE,
    remediation_completed_date DATE,
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------------------------------
-- INCIDENTES Y EVENTOS DE RIESGO
-- -----------------------------------------------------------------------------

CREATE TABLE incidents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_number VARCHAR(20) UNIQUE NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    
    -- Clasificación
    incident_type VARCHAR(30) CHECK (incident_type IN 
        ('Operacional', 'Fraude', 'Ciberataque', 'Cumplimiento', 'Legal', 'Reputacional', 'Otro')),
    severity VARCHAR(20) CHECK (severity IN ('Crítico', 'Alto', 'Medio', 'Bajo')),
    related_risk_id UUID REFERENCES risks(id),
    
    -- Cronología
    detected_date TIMESTAMPTZ NOT NULL,
    occurred_date TIMESTAMPTZ,
    reported_date TIMESTAMPTZ DEFAULT NOW(),
    resolved_date TIMESTAMPTZ,
    
    -- Impacto
    financial_impact DECIMAL(15,2),
    affected_customers INTEGER,
    regulatory_notification_required BOOLEAN DEFAULT FALSE,
    regulatory_notification_date DATE,
    
    -- Responsables
    reported_by_id UUID NOT NULL,
    assigned_to_id UUID,
    
    -- Estado
    status VARCHAR(20) DEFAULT 'Reportado'
        CHECK (status IN ('Reportado', 'En_Investigacion', 'Contenido', 'Resuelto', 'Cerrado')),
    
    -- Root Cause Analysis
    root_cause TEXT,
    corrective_actions TEXT,
    preventive_actions TEXT,
    
    -- Lecciones Aprendidas
    lessons_learned TEXT,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Secuencia para números de incidente
CREATE SEQUENCE incident_number_seq START 1;

CREATE OR REPLACE FUNCTION generate_incident_number()
RETURNS TRIGGER AS $$
BEGIN
    NEW.incident_number := 'INC-' || TO_CHAR(NOW(), 'YYYY') || '-' || 
                          LPAD(NEXTVAL('incident_number_seq')::TEXT, 5, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_incident_number
    BEFORE INSERT ON incidents
    FOR EACH ROW
    WHEN (NEW.incident_number IS NULL)
    EXECUTE FUNCTION generate_incident_number();

-- -----------------------------------------------------------------------------
-- OBLIGACIONES REGULATORIAS
-- -----------------------------------------------------------------------------

CREATE TABLE regulatory_obligations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(30) UNIQUE NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    
    -- Regulación
    regulator VARCHAR(50), -- CMF, UAF, SII, etc.
    regulation_reference VARCHAR(100), -- NCG 380, Ley 19.913, etc.
    
    -- Recurrencia
    frequency VARCHAR(30) CHECK (frequency IN 
        ('Unica', 'Diaria', 'Semanal', 'Quincenal', 'Mensual', 'Trimestral', 'Semestral', 'Anual')),
    due_day INTEGER, -- Día del mes/período
    
    -- Próximo vencimiento
    next_due_date DATE,
    reminder_days INTEGER[] DEFAULT ARRAY[30, 7, 1],
    
    -- Responsable
    owner_id UUID NOT NULL,
    backup_owner_id UUID,
    
    -- Estado
    status VARCHAR(20) DEFAULT 'Activa'
        CHECK (status IN ('Activa', 'Suspendida', 'Obsoleta')),
    
    -- Histórico de cumplimiento
    last_compliance_date DATE,
    compliance_rate DECIMAL(5,2), -- Porcentaje últimos 12 meses
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE obligation_submissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    obligation_id UUID REFERENCES regulatory_obligations(id),
    period_start DATE,
    period_end DATE,
    due_date DATE NOT NULL,
    
    -- Cumplimiento
    submitted_date TIMESTAMPTZ,
    submitted_by_id UUID,
    is_on_time BOOLEAN GENERATED ALWAYS AS (submitted_date::DATE <= due_date) STORED,
    
    -- Detalles
    submission_reference VARCHAR(100), -- Número de envío/folio
    evidence_url TEXT,
    notes TEXT,
    
    -- Estado
    status VARCHAR(20) DEFAULT 'Pendiente'
        CHECK (status IN ('Pendiente', 'En_Preparacion', 'Enviado', 'Aceptado', 'Rechazado', 'Vencido')),
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------------------------------
-- KRIs (Key Risk Indicators)
-- -----------------------------------------------------------------------------

CREATE TABLE key_risk_indicators (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(30) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    
    -- Vinculación
    related_risk_id UUID REFERENCES risks(id),
    category VARCHAR(50),
    
    -- Métrica
    metric_formula TEXT,
    unit VARCHAR(30),
    direction VARCHAR(10) CHECK (direction IN ('Higher', 'Lower', 'Target')),
    
    -- Umbrales (semáforo)
    threshold_green DECIMAL(15,4), -- Normal
    threshold_yellow DECIMAL(15,4), -- Alerta
    threshold_red DECIMAL(15,4), -- Crítico
    
    -- Valores actuales
    current_value DECIMAL(15,4),
    previous_value DECIMAL(15,4),
    trend VARCHAR(10) CHECK (trend IN ('Up', 'Down', 'Stable')),
    current_status VARCHAR(10) CHECK (current_status IN ('Green', 'Yellow', 'Red')),
    
    -- Frecuencia
    measurement_frequency VARCHAR(20),
    last_measured_at TIMESTAMPTZ,
    
    -- Responsable
    owner_id UUID NOT NULL,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE kri_measurements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kri_id UUID REFERENCES key_risk_indicators(id) ON DELETE CASCADE,
    measurement_date DATE NOT NULL,
    value DECIMAL(15,4) NOT NULL,
    status VARCHAR(10) CHECK (status IN ('Green', 'Yellow', 'Red')),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Particionamiento por fecha para histórico
-- (En producción, usar particiones mensuales)

-- -----------------------------------------------------------------------------
-- VISTAS ANALÍTICAS
-- -----------------------------------------------------------------------------

-- Vista de Matriz de Riesgos
CREATE VIEW v_risk_matrix AS
SELECT 
    r.id,
    r.code,
    r.title,
    rc.name as category,
    r.inherent_probability,
    r.inherent_impact,
    r.inherent_score,
    r.residual_probability,
    r.residual_impact,
    r.residual_score,
    r.risk_level,
    r.treatment_strategy,
    COUNT(DISTINCT rcm.control_id) as control_count,
    AVG(c.overall_effectiveness) as avg_control_effectiveness
FROM risks r
LEFT JOIN risk_categories rc ON r.category_id = rc.id
LEFT JOIN risk_control_mappings rcm ON r.id = rcm.risk_id
LEFT JOIN controls c ON rcm.control_id = c.id
WHERE r.status != 'Cerrado'
GROUP BY r.id, r.code, r.title, rc.name, 
         r.inherent_probability, r.inherent_impact, r.inherent_score,
         r.residual_probability, r.residual_impact, r.residual_score,
         r.risk_level, r.treatment_strategy;

-- Vista de Compliance Dashboard
CREATE VIEW v_compliance_dashboard AS
SELECT 
    ro.regulator,
    COUNT(*) as total_obligations,
    COUNT(*) FILTER (WHERE os.status = 'Enviado' AND os.is_on_time) as on_time,
    COUNT(*) FILTER (WHERE os.status = 'Vencido') as overdue,
    COUNT(*) FILTER (WHERE os.status = 'Pendiente') as pending,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE os.is_on_time) / NULLIF(COUNT(*), 0), 2
    ) as compliance_rate
FROM regulatory_obligations ro
LEFT JOIN obligation_submissions os ON ro.id = os.obligation_id
    AND os.period_end >= CURRENT_DATE - INTERVAL '12 months'
GROUP BY ro.regulator;

-- Vista de Incidentes por Categoría
CREATE VIEW v_incident_summary AS
SELECT 
    incident_type,
    severity,
    DATE_TRUNC('month', detected_date) as month,
    COUNT(*) as incident_count,
    SUM(financial_impact) as total_impact,
    AVG(EXTRACT(EPOCH FROM (resolved_date - detected_date))/3600)::INTEGER as avg_resolution_hours
FROM incidents
WHERE detected_date >= CURRENT_DATE - INTERVAL '12 months'
GROUP BY incident_type, severity, DATE_TRUNC('month', detected_date)
ORDER BY month DESC, incident_count DESC;

-- -----------------------------------------------------------------------------
-- FUNCIONES Y PROCEDIMIENTOS
-- -----------------------------------------------------------------------------

-- Función para calcular score de riesgo ajustado
CREATE OR REPLACE FUNCTION calculate_adjusted_risk_score(
    p_risk_id UUID
) RETURNS DECIMAL AS $$
DECLARE
    v_inherent_score INTEGER;
    v_control_effectiveness DECIMAL;
    v_adjusted_score DECIMAL;
BEGIN
    -- Obtener score inherente
    SELECT inherent_score INTO v_inherent_score
    FROM risks WHERE id = p_risk_id;
    
    -- Calcular efectividad promedio ponderada de controles
    SELECT COALESCE(
        SUM(c.overall_effectiveness * rcm.coverage_percentage) / 
        NULLIF(SUM(rcm.coverage_percentage), 0),
        0
    ) / 100.0
    INTO v_control_effectiveness
    FROM risk_control_mappings rcm
    JOIN controls c ON rcm.control_id = c.id
    WHERE rcm.risk_id = p_risk_id
    AND c.status = 'Operativo';
    
    -- Calcular score ajustado
    v_adjusted_score := v_inherent_score * (1 - v_control_effectiveness);
    
    RETURN ROUND(v_adjusted_score, 2);
END;
$$ LANGUAGE plpgsql;

-- Función para actualizar KRI y detectar alertas
CREATE OR REPLACE FUNCTION update_kri_value(
    p_kri_id UUID,
    p_value DECIMAL
) RETURNS TABLE(
    status VARCHAR,
    trend VARCHAR,
    alert_triggered BOOLEAN
) AS $$
DECLARE
    v_kri RECORD;
    v_new_status VARCHAR;
    v_new_trend VARCHAR;
    v_alert BOOLEAN := FALSE;
BEGIN
    -- Obtener configuración del KRI
    SELECT * INTO v_kri FROM key_risk_indicators WHERE id = p_kri_id;
    
    -- Determinar status según umbrales
    IF v_kri.direction = 'Lower' THEN
        IF p_value <= v_kri.threshold_green THEN v_new_status := 'Green';
        ELSIF p_value <= v_kri.threshold_yellow THEN v_new_status := 'Yellow';
        ELSE v_new_status := 'Red';
        END IF;
    ELSE -- Higher o Target
        IF p_value >= v_kri.threshold_green THEN v_new_status := 'Green';
        ELSIF p_value >= v_kri.threshold_yellow THEN v_new_status := 'Yellow';
        ELSE v_new_status := 'Red';
        END IF;
    END IF;
    
    -- Determinar tendencia
    IF v_kri.current_value IS NULL THEN
        v_new_trend := 'Stable';
    ELSIF p_value > v_kri.current_value THEN
        v_new_trend := 'Up';
    ELSIF p_value < v_kri.current_value THEN
        v_new_trend := 'Down';
    ELSE
        v_new_trend := 'Stable';
    END IF;
    
    -- Detectar si se genera alerta (cambio a Red o empeoramiento)
    IF v_new_status = 'Red' AND v_kri.current_status != 'Red' THEN
        v_alert := TRUE;
    END IF;
    
    -- Actualizar KRI
    UPDATE key_risk_indicators SET
        previous_value = current_value,
        current_value = p_value,
        trend = v_new_trend,
        current_status = v_new_status,
        last_measured_at = NOW(),
        updated_at = NOW()
    WHERE id = p_kri_id;
    
    -- Registrar medición histórica
    INSERT INTO kri_measurements (kri_id, measurement_date, value, status)
    VALUES (p_kri_id, CURRENT_DATE, p_value, v_new_status);
    
    RETURN QUERY SELECT v_new_status, v_new_trend, v_alert;
END;
$$ LANGUAGE plpgsql;

-- Procedimiento para generar reporte de compliance mensual
CREATE OR REPLACE PROCEDURE generate_monthly_compliance_report(
    p_year INTEGER,
    p_month INTEGER
) LANGUAGE plpgsql AS $$
DECLARE
    v_period_start DATE;
    v_period_end DATE;
BEGIN
    v_period_start := MAKE_DATE(p_year, p_month, 1);
    v_period_end := (v_period_start + INTERVAL '1 month - 1 day')::DATE;
    
    -- Crear tabla temporal con reporte
    CREATE TEMP TABLE IF NOT EXISTS monthly_compliance_report AS
    SELECT 
        ro.regulator,
        ro.code,
        ro.title,
        os.due_date,
        os.submitted_date,
        os.is_on_time,
        os.status,
        CASE 
            WHEN os.is_on_time THEN 'Cumplido a tiempo'
            WHEN os.status = 'Enviado' THEN 'Cumplido con retraso'
            WHEN os.status = 'Vencido' THEN 'Incumplido'
            ELSE 'Pendiente'
        END as compliance_status
    FROM regulatory_obligations ro
    JOIN obligation_submissions os ON ro.id = os.obligation_id
    WHERE os.due_date BETWEEN v_period_start AND v_period_end
    ORDER BY os.due_date;
    
    -- En producción, enviar por email o guardar en storage
    RAISE NOTICE 'Reporte generado para período % - %', v_period_start, v_period_end;
END;
$$;
```

## 2.3 API REST C01-GRC

### 2.3.1 Endpoints FastAPI

```python
# =============================================================================
# COMPLIANCE SUITE: C01-GRC API
# FastAPI Implementation
# =============================================================================

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_
from typing import List, Optional
from datetime import date, datetime
from pydantic import BaseModel, Field
from enum import Enum
import uuid

router = APIRouter(prefix="/api/v1/grc", tags=["GRC - Governance, Risk & Compliance"])

# =============================================================================
# SCHEMAS
# =============================================================================

class RiskLevel(str, Enum):
    CRITICO = "Crítico"
    ALTO = "Alto"
    MEDIO = "Medio"
    BAJO = "Bajo"

class TreatmentStrategy(str, Enum):
    MITIGAR = "Mitigar"
    TRANSFERIR = "Transferir"
    ACEPTAR = "Aceptar"
    EVITAR = "Evitar"

class RiskCreateSchema(BaseModel):
    code: str = Field(..., max_length=30)
    title: str = Field(..., max_length=200)
    description: Optional[str] = None
    category_id: int
    inherent_probability: int = Field(..., ge=1, le=5)
    inherent_impact: int = Field(..., ge=1, le=5)
    treatment_strategy: TreatmentStrategy
    treatment_plan: Optional[str] = None
    risk_owner_id: uuid.UUID
    business_unit: Optional[str] = None

class RiskResponseSchema(BaseModel):
    id: uuid.UUID
    code: str
    title: str
    description: Optional[str]
    category_name: str
    inherent_probability: int
    inherent_impact: int
    inherent_score: int
    residual_probability: Optional[int]
    residual_impact: Optional[int]
    residual_score: Optional[int]
    risk_level: RiskLevel
    treatment_strategy: TreatmentStrategy
    control_count: int
    avg_control_effectiveness: Optional[float]
    status: str
    created_at: datetime

    class Config:
        from_attributes = True

class RiskMatrixSchema(BaseModel):
    probability: int
    impact: int
    risk_count: int
    risk_ids: List[uuid.UUID]
    avg_score: float

class ControlCreateSchema(BaseModel):
    code: str = Field(..., max_length=30)
    title: str = Field(..., max_length=200)
    description: Optional[str] = None
    control_type_id: int
    nature: str = Field(..., pattern="^(Preventivo|Detectivo|Correctivo)$")
    automation_level: str = Field(..., pattern="^(Manual|Semi-automatico|Automatico)$")
    frequency: str
    design_effectiveness: int = Field(..., ge=0, le=100)
    operating_effectiveness: int = Field(..., ge=0, le=100)
    control_owner_id: uuid.UUID
    evidence_requirements: Optional[str] = None

class ControlResponseSchema(BaseModel):
    id: uuid.UUID
    code: str
    title: str
    nature: str
    automation_level: str
    frequency: str
    overall_effectiveness: int
    status: str
    related_risks_count: int
    last_test_date: Optional[date]
    next_test_date: Optional[date]

    class Config:
        from_attributes = True

class IncidentCreateSchema(BaseModel):
    title: str = Field(..., max_length=200)
    description: str
    incident_type: str
    severity: str = Field(..., pattern="^(Crítico|Alto|Medio|Bajo)$")
    detected_date: datetime
    occurred_date: Optional[datetime] = None
    financial_impact: Optional[float] = None
    affected_customers: Optional[int] = None
    related_risk_id: Optional[uuid.UUID] = None

class KRIValueSchema(BaseModel):
    kri_id: uuid.UUID
    value: float
    notes: Optional[str] = None

class KRIAlertSchema(BaseModel):
    kri_id: uuid.UUID
    kri_name: str
    previous_value: float
    current_value: float
    previous_status: str
    current_status: str
    trend: str
    alert_message: str

class ComplianceDashboardSchema(BaseModel):
    total_risks: int
    critical_risks: int
    high_risks: int
    controls_effective: int
    controls_total: int
    compliance_rate: float
    open_incidents: int
    pending_obligations: int
    kris_in_red: int
    risk_trend: str  # "Improving", "Stable", "Deteriorating"

# =============================================================================
# DEPENDENCIES
# =============================================================================

async def get_db() -> AsyncSession:
    async with AsyncSessionLocal() as session:
        yield session

# =============================================================================
# RISK ENDPOINTS
# =============================================================================

@router.get("/risks", response_model=List[RiskResponseSchema])
async def list_risks(
    category_id: Optional[int] = None,
    risk_level: Optional[RiskLevel] = None,
    status: Optional[str] = None,
    business_unit: Optional[str] = None,
    limit: int = Query(50, le=200),
    offset: int = 0,
    db: AsyncSession = Depends(get_db)
):
    """
    Listar riesgos con filtros opcionales.
    
    Soporta filtrado por:
    - category_id: ID de categoría de riesgo
    - risk_level: Nivel de riesgo (Crítico, Alto, Medio, Bajo)
    - status: Estado del riesgo
    - business_unit: Unidad de negocio
    """
    query = select(Risk).join(RiskCategory)
    
    if category_id:
        query = query.where(Risk.category_id == category_id)
    if risk_level:
        query = query.where(Risk.risk_level == risk_level.value)
    if status:
        query = query.where(Risk.status == status)
    if business_unit:
        query = query.where(Risk.business_unit.ilike(f"%{business_unit}%"))
    
    query = query.order_by(Risk.residual_score.desc()).limit(limit).offset(offset)
    
    result = await db.execute(query)
    risks = result.scalars().all()
    
    # Enriquecer con conteo de controles
    enriched = []
    for risk in risks:
        control_count = await db.scalar(
            select(func.count(RiskControlMapping.id))
            .where(RiskControlMapping.risk_id == risk.id)
        )
        avg_effectiveness = await db.scalar(
            select(func.avg(Control.overall_effectiveness))
            .join(RiskControlMapping, Control.id == RiskControlMapping.control_id)
            .where(RiskControlMapping.risk_id == risk.id)
        )
        
        enriched.append(RiskResponseSchema(
            **risk.__dict__,
            category_name=risk.category.name,
            control_count=control_count or 0,
            avg_control_effectiveness=avg_effectiveness
        ))
    
    return enriched

@router.post("/risks", response_model=RiskResponseSchema, status_code=201)
async def create_risk(
    risk_data: RiskCreateSchema,
    db: AsyncSession = Depends(get_db)
):
    """Crear nuevo riesgo en el registro."""
    # Verificar código único
    existing = await db.scalar(
        select(Risk).where(Risk.code == risk_data.code)
    )
    if existing:
        raise HTTPException(400, f"Código de riesgo '{risk_data.code}' ya existe")
    
    risk = Risk(
        **risk_data.dict(),
        status="Identificado",
        residual_probability=risk_data.inherent_probability,
        residual_impact=risk_data.inherent_impact,
        next_review_date=date.today() + timedelta(days=90)
    )
    
    db.add(risk)
    await db.commit()
    await db.refresh(risk)
    
    return RiskResponseSchema(
        **risk.__dict__,
        category_name=(await db.get(RiskCategory, risk.category_id)).name,
        control_count=0,
        avg_control_effectiveness=None
    )

@router.get("/risks/{risk_id}", response_model=RiskResponseSchema)
async def get_risk(risk_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    """Obtener detalle de un riesgo específico."""
    risk = await db.get(Risk, risk_id)
    if not risk:
        raise HTTPException(404, "Riesgo no encontrado")
    
    # Obtener controles asociados
    controls = await db.execute(
        select(Control)
        .join(RiskControlMapping, Control.id == RiskControlMapping.control_id)
        .where(RiskControlMapping.risk_id == risk_id)
    )
    
    return risk

@router.get("/risks/matrix", response_model=List[RiskMatrixSchema])
async def get_risk_matrix(
    use_residual: bool = True,
    db: AsyncSession = Depends(get_db)
):
    """
    Obtener datos para matriz de riesgos 5x5.
    
    Retorna conteo de riesgos por celda de la matriz.
    """
    prob_col = Risk.residual_probability if use_residual else Risk.inherent_probability
    impact_col = Risk.residual_impact if use_residual else Risk.inherent_impact
    
    query = select(
        prob_col.label('probability'),
        impact_col.label('impact'),
        func.count(Risk.id).label('risk_count'),
        func.array_agg(Risk.id).label('risk_ids'),
        func.avg(Risk.residual_score).label('avg_score')
    ).where(
        Risk.status != 'Cerrado'
    ).group_by(
        prob_col, impact_col
    )
    
    result = await db.execute(query)
    
    return [
        RiskMatrixSchema(
            probability=row.probability,
            impact=row.impact,
            risk_count=row.risk_count,
            risk_ids=row.risk_ids,
            avg_score=float(row.avg_score or 0)
        )
        for row in result.all()
    ]

@router.post("/risks/{risk_id}/evaluate")
async def evaluate_risk(
    risk_id: uuid.UUID,
    residual_probability: int = Query(..., ge=1, le=5),
    residual_impact: int = Query(..., ge=1, le=5),
    db: AsyncSession = Depends(get_db)
):
    """
    Evaluar/reevaluar riesgo residual.
    
    Actualiza probabilidad e impacto residual basado en efectividad de controles.
    """
    risk = await db.get(Risk, risk_id)
    if not risk:
        raise HTTPException(404, "Riesgo no encontrado")
    
    risk.residual_probability = residual_probability
    risk.residual_impact = residual_impact
    risk.status = "Evaluado"
    risk.last_review_date = date.today()
    risk.next_review_date = date.today() + timedelta(days=90)
    risk.updated_at = datetime.utcnow()
    
    await db.commit()
    
    return {
        "message": "Riesgo evaluado exitosamente",
        "residual_score": residual_probability * residual_impact,
        "risk_level": risk.risk_level
    }

# =============================================================================
# CONTROL ENDPOINTS
# =============================================================================

@router.get("/controls", response_model=List[ControlResponseSchema])
async def list_controls(
    nature: Optional[str] = None,
    automation_level: Optional[str] = None,
    effectiveness_min: Optional[int] = None,
    db: AsyncSession = Depends(get_db)
):
    """Listar controles con filtros opcionales."""
    query = select(Control)
    
    if nature:
        query = query.where(Control.nature == nature)
    if automation_level:
        query = query.where(Control.automation_level == automation_level)
    if effectiveness_min:
        query = query.where(Control.overall_effectiveness >= effectiveness_min)
    
    query = query.order_by(Control.overall_effectiveness.desc())
    
    result = await db.execute(query)
    return result.scalars().all()

@router.post("/controls", response_model=ControlResponseSchema, status_code=201)
async def create_control(
    control_data: ControlCreateSchema,
    db: AsyncSession = Depends(get_db)
):
    """Crear nuevo control interno."""
    control = Control(**control_data.dict(), status="Diseñado")
    db.add(control)
    await db.commit()
    await db.refresh(control)
    return control

@router.post("/controls/{control_id}/link-risk/{risk_id}")
async def link_control_to_risk(
    control_id: uuid.UUID,
    risk_id: uuid.UUID,
    coverage_percentage: int = Query(..., ge=0, le=100),
    is_key_control: bool = False,
    db: AsyncSession = Depends(get_db)
):
    """Vincular control a un riesgo con porcentaje de cobertura."""
    # Verificar existencia
    control = await db.get(Control, control_id)
    risk = await db.get(Risk, risk_id)
    
    if not control or not risk:
        raise HTTPException(404, "Control o riesgo no encontrado")
    
    mapping = RiskControlMapping(
        risk_id=risk_id,
        control_id=control_id,
        coverage_percentage=coverage_percentage,
        is_key_control=is_key_control
    )
    
    db.add(mapping)
    await db.commit()
    
    return {"message": "Control vinculado exitosamente al riesgo"}

@router.post("/controls/{control_id}/test")
async def record_control_test(
    control_id: uuid.UUID,
    test_type: str,
    design_conclusion: str,
    operating_conclusion: str,
    sample_size: Optional[int] = None,
    population_size: Optional[int] = None,
    exceptions_found: int = 0,
    findings: Optional[str] = None,
    recommendations: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Registrar resultado de testing de control."""
    control = await db.get(Control, control_id)
    if not control:
        raise HTTPException(404, "Control no encontrado")
    
    test = ControlTest(
        control_id=control_id,
        test_date=date.today(),
        tester_id=uuid.uuid4(),  # En producción: obtener del contexto de auth
        test_type=test_type,
        sample_size=sample_size,
        population_size=population_size,
        design_conclusion=design_conclusion,
        operating_conclusion=operating_conclusion,
        exceptions_found=exceptions_found,
        findings=findings,
        recommendations=recommendations,
        remediation_required=exceptions_found > 0
    )
    
    db.add(test)
    
    # Actualizar fecha de último test en control
    control.last_test_date = date.today()
    control.next_test_date = date.today() + timedelta(days=90)
    
    # Actualizar efectividad si hay excepciones
    if exceptions_found > 0 and sample_size:
        error_rate = exceptions_found / sample_size
        control.operating_effectiveness = int(
            control.operating_effectiveness * (1 - error_rate)
        )
    
    await db.commit()
    
    return {
        "message": "Test registrado exitosamente",
        "test_id": test.id,
        "remediation_required": test.remediation_required
    }

# =============================================================================
# INCIDENT ENDPOINTS
# =============================================================================

@router.get("/incidents")
async def list_incidents(
    incident_type: Optional[str] = None,
    severity: Optional[str] = None,
    status: Optional[str] = None,
    from_date: Optional[date] = None,
    to_date: Optional[date] = None,
    db: AsyncSession = Depends(get_db)
):
    """Listar incidentes con filtros."""
    query = select(Incident)
    
    if incident_type:
        query = query.where(Incident.incident_type == incident_type)
    if severity:
        query = query.where(Incident.severity == severity)
    if status:
        query = query.where(Incident.status == status)
    if from_date:
        query = query.where(Incident.detected_date >= from_date)
    if to_date:
        query = query.where(Incident.detected_date <= to_date)
    
    query = query.order_by(Incident.detected_date.desc())
    
    result = await db.execute(query)
    return result.scalars().all()

@router.post("/incidents", status_code=201)
async def create_incident(
    incident_data: IncidentCreateSchema,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Registrar nuevo incidente.
    
    Dispara notificaciones automáticas según severidad.
    """
    incident = Incident(
        **incident_data.dict(),
        reported_by_id=uuid.uuid4(),  # En producción: del contexto auth
        status="Reportado"
    )
    
    db.add(incident)
    await db.commit()
    await db.refresh(incident)
    
    # Notificaciones en background según severidad
    if incident_data.severity in ["Crítico", "Alto"]:
        background_tasks.add_task(
            send_incident_alert,
            incident_id=incident.id,
            severity=incident_data.severity
        )
    
    return {
        "message": "Incidente registrado",
        "incident_number": incident.incident_number,
        "id": incident.id
    }

@router.patch("/incidents/{incident_id}/investigate")
async def start_investigation(
    incident_id: uuid.UUID,
    assigned_to_id: uuid.UUID,
    db: AsyncSession = Depends(get_db)
):
    """Iniciar investigación de incidente."""
    incident = await db.get(Incident, incident_id)
    if not incident:
        raise HTTPException(404, "Incidente no encontrado")
    
    incident.status = "En_Investigacion"
    incident.assigned_to_id = assigned_to_id
    incident.updated_at = datetime.utcnow()
    
    await db.commit()
    
    return {"message": "Investigación iniciada", "assigned_to": assigned_to_id}

@router.patch("/incidents/{incident_id}/resolve")
async def resolve_incident(
    incident_id: uuid.UUID,
    root_cause: str,
    corrective_actions: str,
    preventive_actions: Optional[str] = None,
    lessons_learned: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Resolver incidente con análisis de causa raíz."""
    incident = await db.get(Incident, incident_id)
    if not incident:
        raise HTTPException(404, "Incidente no encontrado")
    
    incident.status = "Resuelto"
    incident.resolved_date = datetime.utcnow()
    incident.root_cause = root_cause
    incident.corrective_actions = corrective_actions
    incident.preventive_actions = preventive_actions
    incident.lessons_learned = lessons_learned
    incident.updated_at = datetime.utcnow()
    
    await db.commit()
    
    return {
        "message": "Incidente resuelto",
        "resolution_time_hours": (
            incident.resolved_date - incident.detected_date
        ).total_seconds() / 3600
    }

# =============================================================================
# KRI ENDPOINTS
# =============================================================================

@router.get("/kris")
async def list_kris(
    category: Optional[str] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Listar KRIs con estado actual."""
    query = select(KeyRiskIndicator)
    
    if category:
        query = query.where(KeyRiskIndicator.category == category)
    if status:
        query = query.where(KeyRiskIndicator.current_status == status)
    
    result = await db.execute(query)
    return result.scalars().all()

@router.post("/kris/measure", response_model=KRIAlertSchema)
async def record_kri_measurement(
    measurement: KRIValueSchema,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Registrar medición de KRI.
    
    Actualiza valor, calcula tendencia y dispara alertas si corresponde.
    """
    kri = await db.get(KeyRiskIndicator, measurement.kri_id)
    if not kri:
        raise HTTPException(404, "KRI no encontrado")
    
    # Guardar valores previos
    previous_value = kri.current_value
    previous_status = kri.current_status
    
    # Calcular nuevo status
    if kri.direction == 'Lower':
        if measurement.value <= kri.threshold_green:
            new_status = 'Green'
        elif measurement.value <= kri.threshold_yellow:
            new_status = 'Yellow'
        else:
            new_status = 'Red'
    else:  # Higher or Target
        if measurement.value >= kri.threshold_green:
            new_status = 'Green'
        elif measurement.value >= kri.threshold_yellow:
            new_status = 'Yellow'
        else:
            new_status = 'Red'
    
    # Calcular tendencia
    if previous_value is None:
        trend = 'Stable'
    elif measurement.value > previous_value:
        trend = 'Up'
    elif measurement.value < previous_value:
        trend = 'Down'
    else:
        trend = 'Stable'
    
    # Actualizar KRI
    kri.previous_value = previous_value
    kri.current_value = measurement.value
    kri.current_status = new_status
    kri.trend = trend
    kri.last_measured_at = datetime.utcnow()
    kri.updated_at = datetime.utcnow()
    
    # Registrar medición histórica
    kri_measurement = KRIMeasurement(
        kri_id=measurement.kri_id,
        measurement_date=date.today(),
        value=measurement.value,
        status=new_status,
        notes=measurement.notes
    )
    db.add(kri_measurement)
    
    await db.commit()
    
    # Generar alerta si cambió a Red
    alert_triggered = new_status == 'Red' and previous_status != 'Red'
    
    if alert_triggered:
        background_tasks.add_task(
            send_kri_alert,
            kri_id=kri.id,
            kri_name=kri.name,
            value=measurement.value,
            status=new_status
        )
    
    return KRIAlertSchema(
        kri_id=kri.id,
        kri_name=kri.name,
        previous_value=previous_value or 0,
        current_value=measurement.value,
        previous_status=previous_status or 'N/A',
        current_status=new_status,
        trend=trend,
        alert_message=f"KRI '{kri.name}' cambió a estado {new_status}" if alert_triggered else ""
    )

@router.get("/kris/{kri_id}/history")
async def get_kri_history(
    kri_id: uuid.UUID,
    months: int = Query(12, ge=1, le=36),
    db: AsyncSession = Depends(get_db)
):
    """Obtener histórico de mediciones de un KRI."""
    cutoff_date = date.today() - timedelta(days=months * 30)
    
    query = select(KRIMeasurement).where(
        and_(
            KRIMeasurement.kri_id == kri_id,
            KRIMeasurement.measurement_date >= cutoff_date
        )
    ).order_by(KRIMeasurement.measurement_date)
    
    result = await db.execute(query)
    measurements = result.scalars().all()
    
    kri = await db.get(KeyRiskIndicator, kri_id)
    
    return {
        "kri_id": kri_id,
        "kri_name": kri.name if kri else None,
        "thresholds": {
            "green": kri.threshold_green if kri else None,
            "yellow": kri.threshold_yellow if kri else None,
            "red": kri.threshold_red if kri else None
        },
        "measurements": [
            {
                "date": m.measurement_date.isoformat(),
                "value": float(m.value),
                "status": m.status
            }
            for m in measurements
        ]
    }

# =============================================================================
# OBLIGATIONS ENDPOINTS
# =============================================================================

@router.get("/obligations")
async def list_obligations(
    regulator: Optional[str] = None,
    status: Optional[str] = None,
    overdue_only: bool = False,
    db: AsyncSession = Depends(get_db)
):
    """Listar obligaciones regulatorias."""
    query = select(RegulatoryObligation)
    
    if regulator:
        query = query.where(RegulatoryObligation.regulator == regulator)
    if status:
        query = query.where(RegulatoryObligation.status == status)
    if overdue_only:
        query = query.where(RegulatoryObligation.next_due_date < date.today())
    
    query = query.order_by(RegulatoryObligation.next_due_date)
    
    result = await db.execute(query)
    return result.scalars().all()

@router.get("/obligations/upcoming")
async def get_upcoming_obligations(
    days: int = Query(30, ge=1, le=90),
    db: AsyncSession = Depends(get_db)
):
    """Obtener obligaciones próximas a vencer."""
    cutoff = date.today() + timedelta(days=days)
    
    query = select(RegulatoryObligation).where(
        and_(
            RegulatoryObligation.status == 'Activa',
            RegulatoryObligation.next_due_date <= cutoff,
            RegulatoryObligation.next_due_date >= date.today()
        )
    ).order_by(RegulatoryObligation.next_due_date)
    
    result = await db.execute(query)
    obligations = result.scalars().all()
    
    return [
        {
            "id": o.id,
            "code": o.code,
            "title": o.title,
            "regulator": o.regulator,
            "due_date": o.next_due_date.isoformat(),
            "days_remaining": (o.next_due_date - date.today()).days,
            "owner_id": o.owner_id
        }
        for o in obligations
    ]

@router.post("/obligations/{obligation_id}/submit")
async def submit_obligation(
    obligation_id: uuid.UUID,
    submission_reference: str,
    evidence_url: Optional[str] = None,
    notes: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Registrar cumplimiento de obligación."""
    obligation = await db.get(RegulatoryObligation, obligation_id)
    if not obligation:
        raise HTTPException(404, "Obligación no encontrada")
    
    submission = ObligationSubmission(
        obligation_id=obligation_id,
        period_start=date.today().replace(day=1),
        period_end=date.today(),
        due_date=obligation.next_due_date,
        submitted_date=datetime.utcnow(),
        submitted_by_id=uuid.uuid4(),  # En producción: del contexto auth
        submission_reference=submission_reference,
        evidence_url=evidence_url,
        notes=notes,
        status="Enviado"
    )
    
    db.add(submission)
    
    # Calcular próximo vencimiento
    if obligation.frequency == 'Mensual':
        next_month = obligation.next_due_date.replace(day=1) + timedelta(days=32)
        obligation.next_due_date = next_month.replace(day=obligation.due_day or 1)
    elif obligation.frequency == 'Trimestral':
        obligation.next_due_date += timedelta(days=90)
    elif obligation.frequency == 'Anual':
        obligation.next_due_date = obligation.next_due_date.replace(
            year=obligation.next_due_date.year + 1
        )
    
    obligation.last_compliance_date = date.today()
    
    await db.commit()
    
    return {
        "message": "Obligación cumplida",
        "submission_id": submission.id,
        "is_on_time": submission.is_on_time,
        "next_due_date": obligation.next_due_date.isoformat()
    }

# =============================================================================
# DASHBOARD ENDPOINT
# =============================================================================

@router.get("/dashboard", response_model=ComplianceDashboardSchema)
async def get_compliance_dashboard(db: AsyncSession = Depends(get_db)):
    """
    Dashboard consolidado de compliance.
    
    Incluye métricas de riesgos, controles, incidentes, obligaciones y KRIs.
    """
    # Total riesgos por nivel
    risk_counts = await db.execute(
        select(
            Risk.risk_level,
            func.count(Risk.id)
        ).where(Risk.status != 'Cerrado')
        .group_by(Risk.risk_level)
    )
    risk_dict = {row[0]: row[1] for row in risk_counts.all()}
    
    # Controles efectivos (>=70%)
    controls_effective = await db.scalar(
        select(func.count(Control.id))
        .where(Control.overall_effectiveness >= 70)
    )
    controls_total = await db.scalar(select(func.count(Control.id)))
    
    # Compliance rate (obligaciones a tiempo últimos 12 meses)
    submissions = await db.execute(
        select(ObligationSubmission.is_on_time)
        .where(ObligationSubmission.submitted_date >= datetime.utcnow() - timedelta(days=365))
    )
    sub_list = submissions.scalars().all()
    compliance_rate = (sum(1 for s in sub_list if s) / len(sub_list) * 100) if sub_list else 100.0
    
    # Incidentes abiertos
    open_incidents = await db.scalar(
        select(func.count(Incident.id))
        .where(Incident.status.in_(['Reportado', 'En_Investigacion', 'Contenido']))
    )
    
    # Obligaciones pendientes
    pending_obligations = await db.scalar(
        select(func.count(RegulatoryObligation.id))
        .where(
            and_(
                RegulatoryObligation.status == 'Activa',
                RegulatoryObligation.next_due_date <= date.today() + timedelta(days=7)
            )
        )
    )
    
    # KRIs en rojo
    kris_red = await db.scalar(
        select(func.count(KeyRiskIndicator.id))
        .where(KeyRiskIndicator.current_status == 'Red')
    )
    
    # Determinar tendencia (comparar riesgos críticos vs mes anterior)
    # Simplificado: basado en cambio en riesgos críticos
    risk_trend = "Stable"  # En producción: calcular vs histórico
    
    return ComplianceDashboardSchema(
        total_risks=sum(risk_dict.values()),
        critical_risks=risk_dict.get('Crítico', 0),
        high_risks=risk_dict.get('Alto', 0),
        controls_effective=controls_effective or 0,
        controls_total=controls_total or 0,
        compliance_rate=round(compliance_rate, 2),
        open_incidents=open_incidents or 0,
        pending_obligations=pending_obligations or 0,
        kris_in_red=kris_red or 0,
        risk_trend=risk_trend
    )

# =============================================================================
# REPORTS
# =============================================================================

@router.get("/reports/risk-register")
async def export_risk_register(
    format: str = Query("xlsx", pattern="^(xlsx|csv|pdf)$"),
    db: AsyncSession = Depends(get_db)
):
    """Exportar registro de riesgos completo."""
    risks = await db.execute(
        select(Risk)
        .join(RiskCategory)
        .order_by(Risk.residual_score.desc())
    )
    
    # Generar archivo según formato
    if format == "xlsx":
        # Usar openpyxl para generar Excel
        from io import BytesIO
        import openpyxl
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Registro de Riesgos"
        
        # Headers
        headers = [
            "Código", "Título", "Categoría", "Prob. Inherente", "Impacto Inherente",
            "Score Inherente", "Prob. Residual", "Impacto Residual", "Score Residual",
            "Nivel", "Estrategia", "Estado"
        ]
        ws.append(headers)
        
        for risk in risks.scalars():
            ws.append([
                risk.code, risk.title, risk.category.name,
                risk.inherent_probability, risk.inherent_impact, risk.inherent_score,
                risk.residual_probability, risk.residual_impact, risk.residual_score,
                risk.risk_level, risk.treatment_strategy, risk.status
            ])
        
        output = BytesIO()
        wb.save(output)
        output.seek(0)
        
        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=risk_register.xlsx"}
        )
    
    # Implementar CSV y PDF similarmente

@router.get("/reports/compliance-summary")
async def get_compliance_summary_report(
    year: int = Query(default=None),
    month: int = Query(default=None, ge=1, le=12),
    db: AsyncSession = Depends(get_db)
):
    """Generar reporte resumen de compliance para período."""
    if year is None:
        year = date.today().year
    if month is None:
        month = date.today().month
    
    period_start = date(year, month, 1)
    period_end = (period_start + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    
    # Obligaciones del período
    obligations = await db.execute(
        select(
            RegulatoryObligation.regulator,
            func.count(ObligationSubmission.id).label('total'),
            func.count(ObligationSubmission.id).filter(
                ObligationSubmission.is_on_time == True
            ).label('on_time')
        )
        .join(ObligationSubmission)
        .where(
            and_(
                ObligationSubmission.due_date >= period_start,
                ObligationSubmission.due_date <= period_end
            )
        )
        .group_by(RegulatoryObligation.regulator)
    )
    
    return {
        "period": f"{year}-{month:02d}",
        "by_regulator": [
            {
                "regulator": row.regulator,
                "total": row.total,
                "on_time": row.on_time,
                "compliance_rate": round(row.on_time / row.total * 100, 2) if row.total > 0 else 100
            }
            for row in obligations.all()
        ]
    }

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

async def send_incident_alert(incident_id: uuid.UUID, severity: str):
    """Enviar alerta de incidente (background task)."""
    # Implementar integración con email/Slack/Teams
    print(f"ALERT: Incident {incident_id} with severity {severity}")

async def send_kri_alert(kri_id: uuid.UUID, kri_name: str, value: float, status: str):
    """Enviar alerta de KRI (background task)."""
    # Implementar integración con email/Slack/Teams
    print(f"ALERT: KRI '{kri_name}' is now {status} with value {value}")
```

---

# 3. MÓDULO C02-AML: ANTI-MONEY LAUNDERING

## 3.1 Descripción Funcional

### 3.1.1 Propósito
Sistema de prevención de lavado de activos y financiamiento del terrorismo (LA/FT) conforme a Ley 19.913 (Chile) y estándares GAFI/FATF.

### 3.1.2 Funcionalidades

| ID | Funcionalidad | Descripción |
|----|---------------|-------------|
| AML-01 | Transaction Monitoring | Monitoreo en tiempo real de transacciones |
| AML-02 | Alert Management | Gestión de alertas con workflow de investigación |
| AML-03 | Case Management | Gestión de casos sospechosos |
| AML-04 | Scenario Builder | Constructor de escenarios de detección |
| AML-05 | Risk Scoring | Scoring de riesgo de clientes |
| AML-06 | Watchlist Screening | Filtrado contra listas restrictivas |
| AML-07 | SAR Generation | Generación automática de ROS |
| AML-08 | Audit Trail | Trazabilidad completa |

### 3.1.3 Escenarios de Detección

```python
# =============================================================================
# AML DETECTION SCENARIOS
# =============================================================================

from dataclasses import dataclass
from typing import List, Dict, Any, Optional
from decimal import Decimal
from datetime import datetime, timedelta
import numpy as np

@dataclass
class DetectionScenario:
    """Escenario de detección AML."""
    code: str
    name: str
    description: str
    risk_category: str  # LA, FT, Fraude, Corrupción
    parameters: Dict[str, Any]
    severity: str  # High, Medium, Low
    enabled: bool = True

# Escenarios configurados según tipologías GAFI/UAF Chile
DETECTION_SCENARIOS = [
    # ==========================================================================
    # LAVADO DE ACTIVOS (LA)
    # ==========================================================================
    DetectionScenario(
        code="LA-001",
        name="Structuring (Pitufeo)",
        description="Múltiples transacciones bajo umbral de reporte para evadir detección",
        risk_category="LA",
        parameters={
            "time_window_hours": 24,
            "threshold_amount": 450_000,  # Bajo USD 10K
            "min_transactions": 3,
            "max_single_amount": 400_000,
            "aggregate_threshold": 1_000_000
        },
        severity="High"
    ),
    DetectionScenario(
        code="LA-002",
        name="Rapid Movement of Funds",
        description="Fondos entran y salen rápidamente sin justificación económica",
        risk_category="LA",
        parameters={
            "deposit_to_withdrawal_hours": 48,
            "min_amount": 5_000_000,
            "withdrawal_percentage": 0.80,  # 80% o más
            "exclude_known_patterns": ["payroll", "supplier_payment"]
        },
        severity="High"
    ),
    DetectionScenario(
        code="LA-003",
        name="Round Amount Transactions",
        description="Transacciones en montos redondos inusuales",
        risk_category="LA",
        parameters={
            "round_threshold": 1_000_000,  # Múltiplos de 1M
            "time_window_days": 30,
            "min_occurrences": 5,
            "round_tolerance": 0.01  # 1% tolerance
        },
        severity="Medium"
    ),
    DetectionScenario(
        code="LA-004",
        name="Geographic Risk",
        description="Transacciones con jurisdicciones de alto riesgo GAFI",
        risk_category="LA",
        parameters={
            "high_risk_countries": ["AF", "KP", "IR", "MM", "SY", "YE"],
            "min_amount": 1_000_000,
            "exclude_documented_trade": True
        },
        severity="High"
    ),
    DetectionScenario(
        code="LA-005",
        name="Shell Company Indicators",
        description="Patrones asociados a empresas de fachada",
        risk_category="LA",
        parameters={
            "no_physical_presence": True,
            "recently_incorporated_months": 6,
            "complex_ownership_layers": 3,
            "nominee_directors": True,
            "high_value_transactions_without_employees": 10_000_000
        },
        severity="High"
    ),
    
    # ==========================================================================
    # FINANCIAMIENTO DEL TERRORISMO (FT)
    # ==========================================================================
    DetectionScenario(
        code="FT-001",
        name="Watchlist Match",
        description="Match contra listas OFAC, UN, EU, Chile",
        risk_category="FT",
        parameters={
            "watchlists": ["OFAC_SDN", "UN_CONSOLIDATED", "EU_SANCTIONS", "CHILE_UAF"],
            "match_threshold": 0.85,  # Fuzzy match
            "include_aliases": True,
            "check_beneficial_owners": True
        },
        severity="Critical"
    ),
    DetectionScenario(
        code="FT-002",
        name="NPO Suspicious Activity",
        description="Actividad sospechosa en organizaciones sin fines de lucro",
        risk_category="FT",
        parameters={
            "entity_types": ["fundacion", "corporacion", "ong"],
            "cash_percentage_threshold": 0.30,
            "high_risk_beneficiary_countries": True,
            "lack_of_transparency": True
        },
        severity="High"
    ),
    DetectionScenario(
        code="FT-003",
        name="Correspondent Banking Risk",
        description="Riesgo en banca corresponsal",
        risk_category="FT",
        parameters={
            "nested_correspondent": True,
            "payable_through_accounts": True,
            "high_risk_corridors": [("US", "LB"), ("EU", "PK")]
        },
        severity="High"
    ),
    
    # ==========================================================================
    # FRAUDE
    # ==========================================================================
    DetectionScenario(
        code="FR-001",
        name="Account Takeover",
        description="Indicadores de toma de control de cuenta",
        risk_category="Fraude",
        parameters={
            "new_device": True,
            "new_ip_location": True,
            "credential_change_within_hours": 24,
            "large_transfer_after_change": 5_000_000
        },
        severity="High"
    ),
    DetectionScenario(
        code="FR-002",
        name="First Party Fraud",
        description="Fraude de primera parte (cliente)",
        risk_category="Fraude",
        parameters={
            "new_account_days": 30,
            "rapid_credit_utilization": 0.90,
            "multiple_applications": 3,
            "inconsistent_information": True
        },
        severity="Medium"
    ),
    
    # ==========================================================================
    # CORRUPCIÓN (PEP)
    # ==========================================================================
    DetectionScenario(
        code="COR-001",
        name="PEP Unusual Wealth",
        description="PEP con patrimonio inconsistente con ingresos declarados",
        risk_category="Corrupcion",
        parameters={
            "wealth_to_income_ratio": 5.0,
            "unexplained_wealth_threshold": 50_000_000,
            "sudden_wealth_increase_percentage": 200
        },
        severity="High"
    ),
    DetectionScenario(
        code="COR-002",
        name="PEP Third Party Transactions",
        description="Transacciones de PEP a través de terceros relacionados",
        risk_category="Corrupcion",
        parameters={
            "related_party_types": ["familiar", "socio", "empleado_domestico"],
            "transaction_just_below_threshold": True,
            "pattern_correlation": 0.70
        },
        severity="High"
    )
]

class AMLDetectionEngine:
    """Motor de detección AML."""
    
    def __init__(self, scenarios: List[DetectionScenario] = DETECTION_SCENARIOS):
        self.scenarios = {s.code: s for s in scenarios if s.enabled}
        self.alert_buffer = []
    
    def evaluate_transaction(
        self,
        transaction: Dict[str, Any],
        customer: Dict[str, Any],
        history: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Evaluar transacción contra todos los escenarios.
        
        Args:
            transaction: Transacción actual
            customer: Datos del cliente
            history: Historial de transacciones del cliente
        
        Returns:
            Lista de alertas generadas
        """
        alerts = []
        
        for code, scenario in self.scenarios.items():
            result = self._evaluate_scenario(scenario, transaction, customer, history)
            if result['triggered']:
                alerts.append({
                    'scenario_code': code,
                    'scenario_name': scenario.name,
                    'severity': scenario.severity,
                    'risk_category': scenario.risk_category,
                    'score': result['score'],
                    'details': result['details'],
                    'transaction_id': transaction.get('id'),
                    'customer_id': customer.get('id'),
                    'timestamp': datetime.utcnow().isoformat()
                })
        
        return alerts
    
    def _evaluate_scenario(
        self,
        scenario: DetectionScenario,
        transaction: Dict[str, Any],
        customer: Dict[str, Any],
        history: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Evaluar un escenario específico."""
        
        evaluators = {
            'LA-001': self._check_structuring,
            'LA-002': self._check_rapid_movement,
            'LA-003': self._check_round_amounts,
            'LA-004': self._check_geographic_risk,
            'LA-005': self._check_shell_company,
            'FT-001': self._check_watchlist,
            'FT-002': self._check_npo_activity,
            'FR-001': self._check_account_takeover,
            'COR-001': self._check_pep_wealth,
            'COR-002': self._check_pep_third_party,
        }
        
        evaluator = evaluators.get(scenario.code)
        if evaluator:
            return evaluator(scenario.parameters, transaction, customer, history)
        
        return {'triggered': False, 'score': 0, 'details': {}}
    
    def _check_structuring(
        self,
        params: Dict,
        txn: Dict,
        customer: Dict,
        history: List[Dict]
    ) -> Dict:
        """Detectar estructuración (pitufeo)."""
        time_window = timedelta(hours=params['time_window_hours'])
        cutoff = datetime.utcnow() - time_window
        
        # Filtrar transacciones en ventana
        recent = [
            t for t in history
            if datetime.fromisoformat(t['timestamp']) >= cutoff
            and t['type'] in ['deposit', 'cash_in']
            and t['amount'] < params['max_single_amount']
        ]
        
        if len(recent) < params['min_transactions']:
            return {'triggered': False, 'score': 0, 'details': {}}
        
        total = sum(t['amount'] for t in recent)
        
        if total >= params['aggregate_threshold']:
            score = min(100, int((total / params['aggregate_threshold']) * 80))
            return {
                'triggered': True,
                'score': score,
                'details': {
                    'transaction_count': len(recent),
                    'aggregate_amount': total,
                    'time_window_hours': params['time_window_hours'],
                    'individual_amounts': [t['amount'] for t in recent]
                }
            }
        
        return {'triggered': False, 'score': 0, 'details': {}}
    
    def _check_rapid_movement(
        self,
        params: Dict,
        txn: Dict,
        customer: Dict,
        history: List[Dict]
    ) -> Dict:
        """Detectar movimiento rápido de fondos."""
        if txn['type'] not in ['withdrawal', 'transfer_out']:
            return {'triggered': False, 'score': 0, 'details': {}}
        
        window = timedelta(hours=params['deposit_to_withdrawal_hours'])
        recent_deposits = [
            t for t in history
            if t['type'] in ['deposit', 'transfer_in']
            and datetime.fromisoformat(txn['timestamp']) - datetime.fromisoformat(t['timestamp']) <= window
        ]
        
        if not recent_deposits:
            return {'triggered': False, 'score': 0, 'details': {}}
        
        total_in = sum(t['amount'] for t in recent_deposits)
        
        if total_in >= params['min_amount']:
            withdrawal_ratio = txn['amount'] / total_in
            if withdrawal_ratio >= params['withdrawal_percentage']:
                return {
                    'triggered': True,
                    'score': int(withdrawal_ratio * 100),
                    'details': {
                        'deposit_amount': total_in,
                        'withdrawal_amount': txn['amount'],
                        'ratio': round(withdrawal_ratio, 2),
                        'hours_between': params['deposit_to_withdrawal_hours']
                    }
                }
        
        return {'triggered': False, 'score': 0, 'details': {}}
    
    def _check_watchlist(
        self,
        params: Dict,
        txn: Dict,
        customer: Dict,
        history: List[Dict]
    ) -> Dict:
        """Verificar contra listas de sanciones."""
        # Simular verificación contra watchlists
        # En producción: llamar a servicio de screening (WorldCheck, etc.)
        
        name = customer.get('name', '')
        aliases = customer.get('aliases', [])
        
        # Fuzzy matching simulado
        watchlist_matches = self._fuzzy_watchlist_check(
            name,
            aliases,
            params['watchlists'],
            params['match_threshold']
        )
        
        if watchlist_matches:
            return {
                'triggered': True,
                'score': 100,  # Siempre crítico
                'details': {
                    'matches': watchlist_matches,
                    'lists_checked': params['watchlists']
                }
            }
        
        return {'triggered': False, 'score': 0, 'details': {}}
    
    def _fuzzy_watchlist_check(
        self,
        name: str,
        aliases: List[str],
        watchlists: List[str],
        threshold: float
    ) -> List[Dict]:
        """
        Verificación fuzzy contra watchlists.
        
        En producción, usar servicio especializado como:
        - Refinitiv World-Check
        - Dow Jones Risk & Compliance
        - ComplyAdvantage
        """
        # Placeholder - simular algunos matches para testing
        return []
    
    def _check_geographic_risk(
        self,
        params: Dict,
        txn: Dict,
        customer: Dict,
        history: List[Dict]
    ) -> Dict:
        """Verificar riesgo geográfico."""
        high_risk = params['high_risk_countries']
        
        # Verificar país de contraparte
        counterparty_country = txn.get('counterparty_country')
        
        if counterparty_country in high_risk and txn['amount'] >= params['min_amount']:
            return {
                'triggered': True,
                'score': 85,
                'details': {
                    'country': counterparty_country,
                    'amount': txn['amount'],
                    'gafi_status': 'high_risk'
                }
            }
        
        return {'triggered': False, 'score': 0, 'details': {}}
    
    def _check_pep_wealth(
        self,
        params: Dict,
        txn: Dict,
        customer: Dict,
        history: List[Dict]
    ) -> Dict:
        """Verificar riqueza inusual de PEP."""
        if not customer.get('is_pep'):
            return {'triggered': False, 'score': 0, 'details': {}}
        
        declared_income = customer.get('declared_annual_income', 0)
        estimated_wealth = customer.get('estimated_wealth', 0)
        
        if declared_income > 0:
            ratio = estimated_wealth / declared_income
            if ratio > params['wealth_to_income_ratio']:
                return {
                    'triggered': True,
                    'score': min(100, int(ratio * 15)),
                    'details': {
                        'wealth_to_income_ratio': round(ratio, 2),
                        'declared_income': declared_income,
                        'estimated_wealth': estimated_wealth,
                        'pep_position': customer.get('pep_position')
                    }
                }
        
        return {'triggered': False, 'score': 0, 'details': {}}
    
    # Implementar resto de evaluadores...
    def _check_round_amounts(self, params, txn, customer, history):
        return {'triggered': False, 'score': 0, 'details': {}}
    
    def _check_shell_company(self, params, txn, customer, history):
        return {'triggered': False, 'score': 0, 'details': {}}
    
    def _check_npo_activity(self, params, txn, customer, history):
        return {'triggered': False, 'score': 0, 'details': {}}
    
    def _check_account_takeover(self, params, txn, customer, history):
        return {'triggered': False, 'score': 0, 'details': {}}
    
    def _check_pep_third_party(self, params, txn, customer, history):
        return {'triggered': False, 'score': 0, 'details': {}}


# =============================================================================
# CUSTOMER RISK SCORING
# =============================================================================

class CustomerRiskScorer:
    """Calcula score de riesgo AML de clientes."""
    
    # Pesos por factor
    FACTOR_WEIGHTS = {
        'customer_type': 0.15,
        'geographic': 0.20,
        'product': 0.15,
        'channel': 0.10,
        'behavior': 0.25,
        'pep_status': 0.15
    }
    
    # Scores por tipo de cliente
    CUSTOMER_TYPE_SCORES = {
        'individual': 20,
        'sole_proprietor': 40,
        'small_business': 35,
        'corporation': 50,
        'trust': 70,
        'foundation': 60,
        'offshore': 90,
        'shell_company': 100
    }
    
    # Scores geográficos (ISO country codes)
    GEOGRAPHIC_SCORES = {
        'CL': 10,  # Chile - bajo riesgo local
        'US': 20, 'CA': 15, 'GB': 15, 'DE': 15,  # Bajo riesgo
        'MX': 50, 'CO': 55, 'BR': 45, 'AR': 40,  # Medio riesgo LatAm
        'PA': 75, 'BZ': 80, 'VG': 85,  # Jurisdicciones offshore
        'AF': 100, 'KP': 100, 'IR': 100, 'SY': 100,  # GAFI lista negra
    }
    
    # Scores por producto
    PRODUCT_SCORES = {
        'savings_account': 10,
        'checking_account': 15,
        'credit_card': 20,
        'personal_loan': 25,
        'mortgage': 15,
        'investment_account': 40,
        'private_banking': 60,
        'correspondent_banking': 80,
        'trade_finance': 70,
        'wire_transfer': 50,
        'prepaid_card': 65,
        'crypto': 85
    }
    
    def calculate_risk_score(self, customer: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calcular score de riesgo integral del cliente.
        
        Returns:
            Dict con score total, scores parciales y nivel de riesgo
        """
        scores = {}
        
        # Factor 1: Tipo de cliente
        customer_type = customer.get('type', 'individual')
        scores['customer_type'] = self.CUSTOMER_TYPE_SCORES.get(customer_type, 50)
        
        # Factor 2: Riesgo geográfico (máximo entre país residencia y nacionalidad)
        residence = customer.get('country_residence', 'CL')
        nationality = customer.get('nationality', 'CL')
        scores['geographic'] = max(
            self.GEOGRAPHIC_SCORES.get(residence, 50),
            self.GEOGRAPHIC_SCORES.get(nationality, 50)
        )
        
        # Factor 3: Productos
        products = customer.get('products', ['savings_account'])
        product_scores = [self.PRODUCT_SCORES.get(p, 30) for p in products]
        scores['product'] = max(product_scores) if product_scores else 30
        
        # Factor 4: Canal de onboarding
        channel_scores = {
            'branch': 10, 'digital_verified': 25, 
            'digital_basic': 45, 'third_party': 60
        }
        scores['channel'] = channel_scores.get(customer.get('onboarding_channel', 'branch'), 30)
        
        # Factor 5: Comportamiento (basado en alertas históricas)
        alert_count = customer.get('alert_count_12m', 0)
        sar_count = customer.get('sar_count', 0)
        
        behavior_score = min(100, alert_count * 10 + sar_count * 40)
        scores['behavior'] = behavior_score
        
        # Factor 6: Status PEP
        if customer.get('is_pep'):
            pep_level = customer.get('pep_level', 1)  # 1=nacional, 2=regional, 3=local
            scores['pep_status'] = 100 - (pep_level - 1) * 15
        elif customer.get('is_pep_related'):
            scores['pep_status'] = 60
        else:
            scores['pep_status'] = 0
        
        # Calcular score ponderado
        total_score = sum(
            scores[factor] * weight 
            for factor, weight in self.FACTOR_WEIGHTS.items()
        )
        
        # Determinar nivel de riesgo
        if total_score >= 70:
            risk_level = 'High'
            edd_required = True
            review_frequency_months = 6
        elif total_score >= 40:
            risk_level = 'Medium'
            edd_required = False
            review_frequency_months = 12
        else:
            risk_level = 'Low'
            edd_required = False
            review_frequency_months = 24
        
        return {
            'total_score': round(total_score, 1),
            'risk_level': risk_level,
            'factor_scores': scores,
            'edd_required': edd_required,
            'review_frequency_months': review_frequency_months,
            'calculated_at': datetime.utcnow().isoformat()
        }


# =============================================================================
# ALERT MANAGEMENT
# =============================================================================

from enum import Enum

class AlertStatus(str, Enum):
    NEW = "New"
    UNDER_REVIEW = "Under Review"
    ESCALATED = "Escalated"
    CLOSED_FALSE_POSITIVE = "Closed - False Positive"
    CLOSED_SAR_FILED = "Closed - SAR Filed"
    CLOSED_NO_ACTION = "Closed - No Action Required"

class AlertPriority(str, Enum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

@dataclass
class AMLAlert:
    """Alerta AML."""
    id: str
    scenario_code: str
    scenario_name: str
    customer_id: str
    customer_name: str
    transaction_ids: List[str]
    total_amount: Decimal
    risk_score: int
    priority: AlertPriority
    status: AlertStatus
    assigned_to: Optional[str]
    created_at: datetime
    due_date: datetime
    details: Dict[str, Any]
    investigation_notes: List[Dict[str, Any]] = None
    documents: List[str] = None

class AlertManager:
    """Gestión de alertas AML."""
    
    # SLA por prioridad (horas)
    SLA_HOURS = {
        AlertPriority.CRITICAL: 4,
        AlertPriority.HIGH: 24,
        AlertPriority.MEDIUM: 72,
        AlertPriority.LOW: 168  # 7 días
    }
    
    def create_alert(
        self,
        detection_result: Dict[str, Any],
        customer: Dict[str, Any]
    ) -> AMLAlert:
        """Crear nueva alerta desde resultado de detección."""
        
        # Determinar prioridad basada en severidad y score
        severity = detection_result.get('severity', 'Medium')
        score = detection_result.get('score', 50)
        
        if severity == 'Critical' or score >= 90:
            priority = AlertPriority.CRITICAL
        elif severity == 'High' or score >= 70:
            priority = AlertPriority.HIGH
        elif score >= 40:
            priority = AlertPriority.MEDIUM
        else:
            priority = AlertPriority.LOW
        
        due_date = datetime.utcnow() + timedelta(hours=self.SLA_HOURS[priority])
        
        alert = AMLAlert(
            id=f"ALT-{datetime.utcnow().strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}",
            scenario_code=detection_result['scenario_code'],
            scenario_name=detection_result['scenario_name'],
            customer_id=customer['id'],
            customer_name=customer['name'],
            transaction_ids=[detection_result.get('transaction_id')],
            total_amount=Decimal(str(detection_result['details'].get('aggregate_amount', 0))),
            risk_score=score,
            priority=priority,
            status=AlertStatus.NEW,
            assigned_to=None,
            created_at=datetime.utcnow(),
            due_date=due_date,
            details=detection_result['details'],
            investigation_notes=[],
            documents=[]
        )
        
        return alert
    
    def assign_alert(self, alert: AMLAlert, analyst_id: str) -> AMLAlert:
        """Asignar alerta a analista."""
        alert.assigned_to = analyst_id
        alert.status = AlertStatus.UNDER_REVIEW
        alert.investigation_notes.append({
            'timestamp': datetime.utcnow().isoformat(),
            'analyst': analyst_id,
            'action': 'assigned',
            'note': f'Alert assigned to analyst {analyst_id}'
        })
        return alert
    
    def add_investigation_note(
        self,
        alert: AMLAlert,
        analyst_id: str,
        note: str,
        documents: List[str] = None
    ) -> AMLAlert:
        """Agregar nota de investigación."""
        alert.investigation_notes.append({
            'timestamp': datetime.utcnow().isoformat(),
            'analyst': analyst_id,
            'action': 'note_added',
            'note': note
        })
        
        if documents:
            alert.documents.extend(documents)
        
        return alert
    
    def escalate_alert(
        self,
        alert: AMLAlert,
        analyst_id: str,
        reason: str,
        escalate_to: str
    ) -> AMLAlert:
        """Escalar alerta a supervisor/comité."""
        alert.status = AlertStatus.ESCALATED
        alert.assigned_to = escalate_to
        alert.investigation_notes.append({
            'timestamp': datetime.utcnow().isoformat(),
            'analyst': analyst_id,
            'action': 'escalated',
            'note': f'Escalated to {escalate_to}. Reason: {reason}'
        })
        return alert
    
    def close_alert(
        self,
        alert: AMLAlert,
        analyst_id: str,
        disposition: str,
        rationale: str,
        sar_reference: str = None
    ) -> AMLAlert:
        """Cerrar alerta con disposición."""
        
        status_map = {
            'false_positive': AlertStatus.CLOSED_FALSE_POSITIVE,
            'sar_filed': AlertStatus.CLOSED_SAR_FILED,
            'no_action': AlertStatus.CLOSED_NO_ACTION
        }
        
        alert.status = status_map.get(disposition, AlertStatus.CLOSED_NO_ACTION)
        alert.investigation_notes.append({
            'timestamp': datetime.utcnow().isoformat(),
            'analyst': analyst_id,
            'action': 'closed',
            'disposition': disposition,
            'rationale': rationale,
            'sar_reference': sar_reference
        })
        
        return alert
```

## 3.2 Base de Datos C02-AML

```sql
-- =============================================================================
-- COMPLIANCE SUITE: C02-AML - ANTI-MONEY LAUNDERING
-- PostgreSQL 16 Schema
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS compliance_aml;
SET search_path TO compliance_aml, public;

-- -----------------------------------------------------------------------------
-- TRANSACCIONES PARA MONITOREO
-- -----------------------------------------------------------------------------

CREATE TABLE monitored_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_id VARCHAR(50) NOT NULL,
    customer_id UUID NOT NULL,
    account_id UUID NOT NULL,
    
    -- Tipo y dirección
    transaction_type VARCHAR(30) NOT NULL,
    direction VARCHAR(10) CHECK (direction IN ('INBOUND', 'OUTBOUND', 'INTERNAL')),
    
    -- Montos
    amount DECIMAL(18,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'CLP',
    amount_usd DECIMAL(18,2), -- Equivalente USD para umbrales
    
    -- Contraparte
    counterparty_name VARCHAR(200),
    counterparty_account VARCHAR(50),
    counterparty_bank VARCHAR(100),
    counterparty_country VARCHAR(2),
    
    -- Metadata
    channel VARCHAR(30), -- BRANCH, ATM, ONLINE, MOBILE, WIRE
    purpose VARCHAR(200),
    reference VARCHAR(100),
    
    -- Timestamps
    transaction_date TIMESTAMPTZ NOT NULL,
    value_date DATE,
    processed_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- Flags de detección
    is_cash BOOLEAN DEFAULT FALSE,
    is_international BOOLEAN DEFAULT FALSE,
    is_high_risk_country BOOLEAN DEFAULT FALSE,
    is_pep_related BOOLEAN DEFAULT FALSE,
    
    -- Scoring
    risk_score INTEGER DEFAULT 0,
    scenarios_triggered VARCHAR[] DEFAULT '{}',
    
    created_at TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (transaction_date);

-- Particiones mensuales
CREATE TABLE monitored_transactions_2026_01 PARTITION OF monitored_transactions
    FOR VALUES FROM ('2026-01-01') TO ('2026-02-01');
CREATE TABLE monitored_transactions_2026_02 PARTITION OF monitored_transactions
    FOR VALUES FROM ('2026-02-01') TO ('2026-03-01');
-- ... crear particiones adicionales

-- Índices
CREATE INDEX idx_txn_customer ON monitored_transactions(customer_id, transaction_date DESC);
CREATE INDEX idx_txn_amount ON monitored_transactions(amount DESC) WHERE amount >= 1000000;
CREATE INDEX idx_txn_scenarios ON monitored_transactions USING GIN(scenarios_triggered);
CREATE INDEX idx_txn_risk ON monitored_transactions(risk_score DESC) WHERE risk_score >= 50;

-- -----------------------------------------------------------------------------
-- ALERTAS AML
-- -----------------------------------------------------------------------------

CREATE TABLE aml_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    alert_number VARCHAR(30) UNIQUE NOT NULL,
    
    -- Escenario
    scenario_code VARCHAR(20) NOT NULL,
    scenario_name VARCHAR(100) NOT NULL,
    risk_category VARCHAR(30), -- LA, FT, Fraude, Corrupcion
    
    -- Cliente/Transacciones
    customer_id UUID NOT NULL,
    customer_name VARCHAR(200),
    transaction_ids UUID[] DEFAULT '{}',
    total_amount DECIMAL(18,2),
    
    -- Scoring y prioridad
    risk_score INTEGER NOT NULL,
    priority VARCHAR(20) CHECK (priority IN ('Critical', 'High', 'Medium', 'Low')),
    
    -- Estado
    status VARCHAR(30) DEFAULT 'New' CHECK (status IN (
        'New', 'Under Review', 'Escalated', 
        'Closed - False Positive', 'Closed - SAR Filed', 'Closed - No Action Required'
    )),
    
    -- Asignación
    assigned_to UUID,
    assigned_at TIMESTAMPTZ,
    
    -- SLA
    due_date TIMESTAMPTZ NOT NULL,
    is_overdue BOOLEAN GENERATED ALWAYS AS (
        status NOT LIKE 'Closed%' AND NOW() > due_date
    ) STORED,
    
    -- Detalles
    detection_details JSONB NOT NULL DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    closed_at TIMESTAMPTZ
);

-- Secuencia para números de alerta
CREATE SEQUENCE alert_number_seq;

CREATE OR REPLACE FUNCTION generate_alert_number()
RETURNS TRIGGER AS $$
BEGIN
    NEW.alert_number := 'ALT-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || 
                       LPAD(NEXTVAL('alert_number_seq')::TEXT, 6, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_alert_number
    BEFORE INSERT ON aml_alerts
    FOR EACH ROW
    WHEN (NEW.alert_number IS NULL)
    EXECUTE FUNCTION generate_alert_number();

-- Índices
CREATE INDEX idx_alerts_status ON aml_alerts(status) WHERE status NOT LIKE 'Closed%';
CREATE INDEX idx_alerts_priority ON aml_alerts(priority, created_at DESC);
CREATE INDEX idx_alerts_assigned ON aml_alerts(assigned_to) WHERE assigned_to IS NOT NULL;
CREATE INDEX idx_alerts_overdue ON aml_alerts(due_date) WHERE is_overdue = TRUE;

-- -----------------------------------------------------------------------------
-- NOTAS DE INVESTIGACIÓN
-- -----------------------------------------------------------------------------

CREATE TABLE alert_investigation_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    alert_id UUID REFERENCES aml_alerts(id) ON DELETE CASCADE,
    analyst_id UUID NOT NULL,
    action VARCHAR(30) NOT NULL, -- assigned, note_added, escalated, closed
    note TEXT,
    disposition VARCHAR(30), -- Solo para cierre
    rationale TEXT,
    sar_reference VARCHAR(50),
    documents JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_notes_alert ON alert_investigation_notes(alert_id, created_at);

-- -----------------------------------------------------------------------------
-- REPORTES DE OPERACIONES SOSPECHOSAS (ROS/SAR)
-- -----------------------------------------------------------------------------

CREATE TABLE suspicious_activity_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sar_number VARCHAR(30) UNIQUE NOT NULL,
    
    -- Origen
    alert_ids UUID[] NOT NULL,
    case_id UUID,
    
    -- Sujeto
    subject_type VARCHAR(20) CHECK (subject_type IN ('Individual', 'Entity')),
    subject_id UUID NOT NULL,
    subject_name VARCHAR(200) NOT NULL,
    subject_rut VARCHAR(12),
    
    -- Actividad
    activity_type VARCHAR(50), -- Tipología LA/FT
    activity_start_date DATE,
    activity_end_date DATE,
    total_amount DECIMAL(18,2),
    currency VARCHAR(3) DEFAULT 'CLP',
    
    -- Descripción
    narrative TEXT NOT NULL,
    suspicious_indicators TEXT[],
    supporting_documents JSONB DEFAULT '[]',
    
    -- Estado
    status VARCHAR(30) DEFAULT 'Draft' CHECK (status IN (
        'Draft', 'Under Review', 'Approved', 'Submitted', 'Acknowledged'
    )),
    
    -- Aprobación
    prepared_by UUID NOT NULL,
    prepared_at TIMESTAMPTZ DEFAULT NOW(),
    reviewed_by UUID,
    reviewed_at TIMESTAMPTZ,
    approved_by UUID,
    approved_at TIMESTAMPTZ,
    
    -- Envío a UAF
    submitted_at TIMESTAMPTZ,
    uaf_reference VARCHAR(50),
    uaf_acknowledgment_date DATE,
    
    -- Metadata
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Secuencia para ROS
CREATE SEQUENCE sar_number_seq;

CREATE OR REPLACE FUNCTION generate_sar_number()
RETURNS TRIGGER AS $$
BEGIN
    NEW.sar_number := 'ROS-' || TO_CHAR(NOW(), 'YYYY') || '-' || 
                     LPAD(NEXTVAL('sar_number_seq')::TEXT, 6, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_sar_number
    BEFORE INSERT ON suspicious_activity_reports
    FOR EACH ROW
    WHEN (NEW.sar_number IS NULL)
    EXECUTE FUNCTION generate_sar_number();

-- -----------------------------------------------------------------------------
-- WATCHLIST SCREENING
-- -----------------------------------------------------------------------------

CREATE TABLE watchlist_sources (
    id SERIAL PRIMARY KEY,
    code VARCHAR(30) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    provider VARCHAR(50),
    last_updated TIMESTAMPTZ,
    record_count INTEGER,
    is_active BOOLEAN DEFAULT TRUE
);

INSERT INTO watchlist_sources (code, name, provider) VALUES
('OFAC_SDN', 'OFAC Specially Designated Nationals', 'US Treasury'),
('UN_CONSOLIDATED', 'UN Security Council Consolidated List', 'United Nations'),
('EU_SANCTIONS', 'EU Consolidated Financial Sanctions', 'European Union'),
('CHILE_UAF', 'Lista UAF Chile', 'UAF Chile'),
('INTERPOL_RED', 'INTERPOL Red Notices', 'INTERPOL'),
('PEP_GLOBAL', 'Politically Exposed Persons', 'Multi-source');

CREATE TABLE watchlist_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id INTEGER REFERENCES watchlist_sources(id),
    
    -- Identificación
    entity_type VARCHAR(20) CHECK (entity_type IN ('Individual', 'Entity', 'Vessel', 'Aircraft')),
    primary_name VARCHAR(300) NOT NULL,
    aliases JSONB DEFAULT '[]',
    
    -- Identificadores
    identifiers JSONB DEFAULT '{}', -- passport, national_id, etc.
    
    -- Características (para individuos)
    date_of_birth DATE,
    place_of_birth VARCHAR(100),
    nationality VARCHAR(2)[],
    
    -- Características (para entidades)
    country_registration VARCHAR(2),
    
    -- Programa/Razón
    program VARCHAR(100),
    designation_date DATE,
    reasons TEXT[],
    
    -- Metadata
    source_reference VARCHAR(100),
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_watchlist_name ON watchlist_entries USING GIN(to_tsvector('spanish', primary_name));
CREATE INDEX idx_watchlist_source ON watchlist_entries(source_id, is_active);

CREATE TABLE watchlist_screening_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Qué se screenó
    screening_type VARCHAR(30), -- customer, transaction, counterparty
    screened_entity_id UUID,
    screened_name VARCHAR(300),
    
    -- Resultado
    match_found BOOLEAN DEFAULT FALSE,
    match_count INTEGER DEFAULT 0,
    highest_score DECIMAL(5,2),
    
    -- Matches detallados
    matches JSONB DEFAULT '[]', -- [{watchlist_entry_id, score, matched_on}]
    
    -- Disposición
    disposition VARCHAR(30), -- true_match, false_positive, pending_review
    disposition_by UUID,
    disposition_at TIMESTAMPTZ,
    disposition_notes TEXT,
    
    -- Timestamps
    screened_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------------------------------
-- CUSTOMER RISK SCORING
-- -----------------------------------------------------------------------------

CREATE TABLE customer_risk_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID UNIQUE NOT NULL,
    
    -- Score total y nivel
    total_score DECIMAL(5,1) NOT NULL,
    risk_level VARCHAR(20) CHECK (risk_level IN ('Low', 'Medium', 'High', 'Prohibited')),
    
    -- Scores por factor
    factor_scores JSONB NOT NULL DEFAULT '{}',
    
    -- Requerimientos
    edd_required BOOLEAN DEFAULT FALSE,
    edd_completed BOOLEAN DEFAULT FALSE,
    edd_completion_date DATE,
    
    -- Revisión
    review_frequency_months INTEGER DEFAULT 12,
    last_review_date DATE,
    next_review_date DATE,
    reviewed_by UUID,
    
    -- Override manual
    is_manually_overridden BOOLEAN DEFAULT FALSE,
    override_level VARCHAR(20),
    override_reason TEXT,
    override_by UUID,
    override_at TIMESTAMPTZ,
    
    -- Timestamps
    calculated_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_risk_level ON customer_risk_profiles(risk_level);
CREATE INDEX idx_risk_review ON customer_risk_profiles(next_review_date) 
    WHERE next_review_date <= CURRENT_DATE + INTERVAL '30 days';

-- -----------------------------------------------------------------------------
-- VISTAS ANALÍTICAS
-- -----------------------------------------------------------------------------

-- Vista de alertas pendientes con SLA
CREATE VIEW v_pending_alerts AS
SELECT 
    a.id,
    a.alert_number,
    a.scenario_code,
    a.scenario_name,
    a.customer_name,
    a.total_amount,
    a.risk_score,
    a.priority,
    a.status,
    a.assigned_to,
    a.due_date,
    a.is_overdue,
    EXTRACT(EPOCH FROM (a.due_date - NOW()))/3600 as hours_remaining,
    crp.risk_level as customer_risk_level
FROM aml_alerts a
LEFT JOIN customer_risk_profiles crp ON a.customer_id = crp.customer_id
WHERE a.status NOT LIKE 'Closed%'
ORDER BY 
    CASE a.priority 
        WHEN 'Critical' THEN 1 
        WHEN 'High' THEN 2 
        WHEN 'Medium' THEN 3 
        ELSE 4 
    END,
    a.due_date;

-- Vista de métricas de eficiencia
CREATE VIEW v_alert_metrics AS
SELECT 
    DATE_TRUNC('month', created_at) as month,
    scenario_code,
    COUNT(*) as total_alerts,
    COUNT(*) FILTER (WHERE status = 'Closed - False Positive') as false_positives,
    COUNT(*) FILTER (WHERE status = 'Closed - SAR Filed') as sar_filed,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE status = 'Closed - False Positive') / COUNT(*), 2
    ) as false_positive_rate,
    AVG(EXTRACT(EPOCH FROM (closed_at - created_at))/3600)::INTEGER as avg_resolution_hours
FROM aml_alerts
WHERE created_at >= CURRENT_DATE - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', created_at), scenario_code
ORDER BY month DESC, total_alerts DESC;

-- Vista de ROS por estado
CREATE VIEW v_sar_summary AS
SELECT 
    status,
    COUNT(*) as count,
    SUM(total_amount) as total_amount,
    AVG(EXTRACT(EPOCH FROM (submitted_at - prepared_at))/86400)::INTEGER as avg_days_to_submit
FROM suspicious_activity_reports
WHERE prepared_at >= CURRENT_DATE - INTERVAL '12 months'
GROUP BY status;
```

---

# 4. MÓDULO C03-KYC: KNOW YOUR CUSTOMER

## 4.1 Descripción Funcional

### 4.1.1 Propósito
Sistema integral de conocimiento del cliente conforme a Circular UAF N°57 y mejores prácticas GAFI para identificación, verificación y debida diligencia.

### 4.1.2 Niveles de Due Diligence

| Nivel | Aplicación | Requisitos |
|-------|------------|------------|
| **SDD** (Simplificada) | Bajo riesgo, montos menores | Identificación básica, verificación documental |
| **CDD** (Estándar) | Riesgo medio, clientes regulares | ID + verificación + propósito + origen fondos |
| **EDD** (Reforzada) | Alto riesgo, PEPs, jurisdicciones riesgo | CDD + fuente riqueza + visitas + aprobación senior |

## 4.2 Implementación KYC

```python
# =============================================================================
# COMPLIANCE SUITE: C03-KYC - KNOW YOUR CUSTOMER
# =============================================================================

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import date, datetime
from enum import Enum
import re

class CustomerType(str, Enum):
    INDIVIDUAL = "individual"
    SOLE_PROPRIETOR = "sole_proprietor"
    COMPANY = "company"
    TRUST = "trust"
    FOUNDATION = "foundation"
    GOVERNMENT = "government"

class DocumentType(str, Enum):
    # Chile
    CEDULA_IDENTIDAD = "cedula_identidad"
    PASAPORTE = "pasaporte"
    RUT = "rut"
    # Empresas
    ESCRITURA_CONSTITUCION = "escritura_constitucion"
    ESTATUTOS = "estatutos"
    VIGENCIA = "vigencia"
    PODER = "poder"
    # Financieros
    DECLARACION_RENTA = "declaracion_renta"
    BALANCE = "balance"
    ESTADOS_FINANCIEROS = "estados_financieros"
    # Otros
    PROOF_ADDRESS = "proof_address"
    UBO_DECLARATION = "ubo_declaration"

class VerificationStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    VERIFIED = "verified"
    REJECTED = "rejected"
    EXPIRED = "expired"

class DueDiligenceLevel(str, Enum):
    SDD = "Simplified Due Diligence"
    CDD = "Customer Due Diligence"
    EDD = "Enhanced Due Diligence"

@dataclass
class IdentityDocument:
    """Documento de identidad."""
    document_type: DocumentType
    document_number: str
    issuing_country: str
    issue_date: Optional[date] = None
    expiry_date: Optional[date] = None
    verification_status: VerificationStatus = VerificationStatus.PENDING
    verification_method: Optional[str] = None  # manual, ocr, biometric, third_party
    verification_date: Optional[datetime] = None
    verification_notes: Optional[str] = None
    document_url: Optional[str] = None

@dataclass
class Address:
    """Dirección del cliente."""
    address_type: str  # residential, business, mailing
    street: str
    number: str
    unit: Optional[str] = None
    city: str = ""
    region: str = ""
    postal_code: str = ""
    country: str = "CL"
    is_verified: bool = False
    verification_document: Optional[str] = None

@dataclass
class BeneficialOwner:
    """Beneficiario final (UBO)."""
    name: str
    nationality: str
    document_type: DocumentType
    document_number: str
    ownership_percentage: float
    is_pep: bool = False
    pep_details: Optional[Dict] = None
    verification_status: VerificationStatus = VerificationStatus.PENDING

@dataclass
class IndividualKYC:
    """KYC para persona natural."""
    # Identificación básica
    first_name: str
    last_name: str
    date_of_birth: date
    nationality: str
    country_residence: str
    
    # Documentos
    documents: List[IdentityDocument] = field(default_factory=list)
    
    # Direcciones
    addresses: List[Address] = field(default_factory=list)
    
    # Contacto
    email: Optional[str] = None
    phone: Optional[str] = None
    
    # Ocupación/Ingresos
    occupation: Optional[str] = None
    employer: Optional[str] = None
    annual_income_range: Optional[str] = None  # "<10M", "10M-50M", "50M-100M", ">100M"
    source_of_funds: Optional[str] = None
    source_of_wealth: Optional[str] = None
    
    # PEP
    is_pep: bool = False
    pep_position: Optional[str] = None
    pep_relationship: Optional[str] = None  # self, family, close_associate
    
    # Propósito
    account_purpose: Optional[str] = None
    expected_transaction_types: List[str] = field(default_factory=list)
    expected_monthly_volume: Optional[str] = None
    
    # Estado KYC
    kyc_status: VerificationStatus = VerificationStatus.PENDING
    due_diligence_level: DueDiligenceLevel = DueDiligenceLevel.CDD
    kyc_completion_date: Optional[datetime] = None
    next_review_date: Optional[date] = None

@dataclass
class EntityKYC:
    """KYC para persona jurídica."""
    # Identificación
    legal_name: str
    trade_name: Optional[str] = None
    rut: str = ""
    entity_type: CustomerType = CustomerType.COMPANY
    country_incorporation: str = "CL"
    date_incorporation: Optional[date] = None
    
    # Documentos corporativos
    documents: List[IdentityDocument] = field(default_factory=list)
    
    # Direcciones
    registered_address: Optional[Address] = None
    business_address: Optional[Address] = None
    
    # Contacto
    contact_name: Optional[str] = None
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None
    
    # Estructura
    beneficial_owners: List[BeneficialOwner] = field(default_factory=list)
    authorized_signatories: List[Dict] = field(default_factory=list)
    parent_company: Optional[str] = None
    subsidiaries: List[str] = field(default_factory=list)
    
    # Actividad económica
    industry_code: Optional[str] = None  # CIIU
    business_description: Optional[str] = None
    website: Optional[str] = None
    employee_count: Optional[int] = None
    annual_revenue: Optional[str] = None
    
    # Financiero
    source_of_funds: Optional[str] = None
    banking_relationships: List[Dict] = field(default_factory=list)
    
    # Estado KYC
    kyc_status: VerificationStatus = VerificationStatus.PENDING
    due_diligence_level: DueDiligenceLevel = DueDiligenceLevel.CDD
    kyc_completion_date: Optional[datetime] = None
    next_review_date: Optional[date] = None


class KYCProcessor:
    """Procesador de KYC."""
    
    # Requisitos por nivel de due diligence
    REQUIREMENTS = {
        DueDiligenceLevel.SDD: {
            'individual': ['cedula_identidad', 'proof_address'],
            'entity': ['rut', 'escritura_constitucion']
        },
        DueDiligenceLevel.CDD: {
            'individual': [
                'cedula_identidad', 'proof_address', 'declaracion_renta',
                'source_of_funds', 'account_purpose'
            ],
            'entity': [
                'rut', 'escritura_constitucion', 'vigencia', 'poder',
                'ubo_declaration', 'estados_financieros'
            ]
        },
        DueDiligenceLevel.EDD: {
            'individual': [
                'cedula_identidad', 'pasaporte', 'proof_address', 
                'declaracion_renta', 'source_of_funds', 'source_of_wealth',
                'account_purpose', 'site_visit', 'senior_approval'
            ],
            'entity': [
                'rut', 'escritura_constitucion', 'estatutos', 'vigencia', 
                'poder', 'ubo_declaration', 'estados_financieros', 'balance',
                'site_visit', 'senior_approval', 'third_party_verification'
            ]
        }
    }
    
    def determine_dd_level(
        self,
        customer_type: str,
        risk_score: float,
        is_pep: bool,
        country_risk: str,
        product_risk: str
    ) -> DueDiligenceLevel:
        """
        Determinar nivel de due diligence requerido.
        
        Args:
            customer_type: Tipo de cliente
            risk_score: Score de riesgo calculado
            is_pep: Si es PEP o relacionado
            country_risk: Nivel de riesgo del país
            product_risk: Nivel de riesgo del producto
        
        Returns:
            Nivel de due diligence requerido
        """
        # EDD obligatorio para PEPs
        if is_pep:
            return DueDiligenceLevel.EDD
        
        # EDD para países de alto riesgo
        if country_risk == 'high':
            return DueDiligenceLevel.EDD
        
        # EDD para score alto
        if risk_score >= 70:
            return DueDiligenceLevel.EDD
        
        # SDD solo para bajo riesgo
        if risk_score < 25 and country_risk == 'low' and product_risk == 'low':
            return DueDiligenceLevel.SDD
        
        return DueDiligenceLevel.CDD
    
    def validate_rut(self, rut: str) -> bool:
        """Validar RUT chileno."""
        rut = rut.upper().replace(".", "").replace("-", "")
        
        if not re.match(r'^\d{7,8}[0-9K]$', rut):
            return False
        
        body = rut[:-1]
        dv = rut[-1]
        
        # Algoritmo módulo 11
        total = 0
        factor = 2
        
        for digit in reversed(body):
            total += int(digit) * factor
            factor = factor + 1 if factor < 7 else 2
        
        remainder = total % 11
        calculated_dv = 11 - remainder
        
        if calculated_dv == 11:
            calculated_dv = '0'
        elif calculated_dv == 10:
            calculated_dv = 'K'
        else:
            calculated_dv = str(calculated_dv)
        
        return dv == calculated_dv
    
    def check_document_requirements(
        self,
        kyc_data: IndividualKYC | EntityKYC,
        dd_level: DueDiligenceLevel
    ) -> Dict[str, Any]:
        """
        Verificar cumplimiento de requisitos documentales.
        
        Returns:
            Dict con estado de cada requisito y completitud general
        """
        is_entity = isinstance(kyc_data, EntityKYC)
        customer_type = 'entity' if is_entity else 'individual'
        
        requirements = self.REQUIREMENTS[dd_level][customer_type]
        
        # Documentos presentados
        presented_docs = {
            doc.document_type.value: doc 
            for doc in kyc_data.documents
        }
        
        results = {}
        missing = []
        pending = []
        verified = []
        
        for req in requirements:
            if req in ['source_of_funds', 'source_of_wealth', 'account_purpose']:
                # Campos no documentales
                value = getattr(kyc_data, req, None)
                if value:
                    results[req] = {'status': 'provided', 'value': value}
                    verified.append(req)
                else:
                    results[req] = {'status': 'missing'}
                    missing.append(req)
            elif req in ['site_visit', 'senior_approval', 'third_party_verification']:
                # Requisitos especiales EDD
                results[req] = {'status': 'required', 'completed': False}
                pending.append(req)
            elif req in presented_docs:
                doc = presented_docs[req]
                results[req] = {
                    'status': doc.verification_status.value,
                    'document_number': doc.document_number,
                    'expiry_date': doc.expiry_date.isoformat() if doc.expiry_date else None
                }
                if doc.verification_status == VerificationStatus.VERIFIED:
                    verified.append(req)
                elif doc.verification_status == VerificationStatus.PENDING:
                    pending.append(req)
            else:
                results[req] = {'status': 'missing'}
                missing.append(req)
        
        total = len(requirements)
        completion = len(verified) / total * 100 if total > 0 else 0
        
        return {
            'requirements': results,
            'summary': {
                'total_requirements': total,
                'verified': len(verified),
                'pending': len(pending),
                'missing': len(missing),
                'completion_percentage': round(completion, 1)
            },
            'is_complete': len(missing) == 0 and len(pending) == 0,
            'missing_items': missing,
            'pending_items': pending
        }
    
    def verify_ubo_threshold(
        self,
        beneficial_owners: List[BeneficialOwner],
        threshold: float = 10.0
    ) -> Dict[str, Any]:
        """
        Verificar identificación de UBOs sobre umbral.
        
        En Chile, umbral UAF es 10% de propiedad.
        """
        significant_ubos = [
            ubo for ubo in beneficial_owners 
            if ubo.ownership_percentage >= threshold
        ]
        
        total_ownership = sum(ubo.ownership_percentage for ubo in beneficial_owners)
        
        unidentified = 100 - total_ownership if total_ownership < 100 else 0
        
        all_verified = all(
            ubo.verification_status == VerificationStatus.VERIFIED 
            for ubo in significant_ubos
        )
        
        pep_ubos = [ubo for ubo in significant_ubos if ubo.is_pep]
        
        return {
            'threshold': threshold,
            'significant_ubos': len(significant_ubos),
            'total_identified_ownership': total_ownership,
            'unidentified_ownership': unidentified,
            'all_verified': all_verified,
            'pep_ubos': len(pep_ubos),
            'requires_edd': len(pep_ubos) > 0,
            'ubos': [
                {
                    'name': ubo.name,
                    'ownership': ubo.ownership_percentage,
                    'verified': ubo.verification_status == VerificationStatus.VERIFIED,
                    'is_pep': ubo.is_pep
                }
                for ubo in significant_ubos
            ]
        }
    
    def calculate_kyc_expiry(
        self,
        dd_level: DueDiligenceLevel,
        risk_score: float
    ) -> date:
        """Calcular fecha de próxima revisión KYC."""
        from datetime import timedelta
        
        # Frecuencia base por nivel DD
        base_months = {
            DueDiligenceLevel.SDD: 36,  # 3 años
            DueDiligenceLevel.CDD: 24,  # 2 años
            DueDiligenceLevel.EDD: 12   # 1 año
        }
        
        months = base_months[dd_level]
        
        # Ajustar por score de riesgo
        if risk_score >= 70:
            months = min(months, 6)
        elif risk_score >= 50:
            months = min(months, 12)
        
        return date.today() + timedelta(days=months * 30)
    
    async def perform_kyc_verification(
        self,
        kyc_data: IndividualKYC | EntityKYC
    ) -> Dict[str, Any]:
        """
        Realizar proceso de verificación KYC completo.
        
        Incluye:
        1. Validación de documentos
        2. Verificación contra listas
        3. Verificación biométrica (si aplica)
        4. Scoring de riesgo
        5. Determinación de nivel DD
        """
        results = {
            'kyc_id': str(uuid.uuid4()),
            'timestamp': datetime.utcnow().isoformat(),
            'customer_type': 'entity' if isinstance(kyc_data, EntityKYC) else 'individual',
            'verifications': []
        }
        
        # 1. Validar documentos
        if isinstance(kyc_data, IndividualKYC):
            # Validar cédula/RUT
            for doc in kyc_data.documents:
                if doc.document_type in [DocumentType.CEDULA_IDENTIDAD, DocumentType.RUT]:
                    is_valid = self.validate_rut(doc.document_number)
                    results['verifications'].append({
                        'type': 'document_validation',
                        'document': doc.document_type.value,
                        'valid': is_valid
                    })
        else:
            # Validar RUT empresa
            is_valid = self.validate_rut(kyc_data.rut)
            results['verifications'].append({
                'type': 'rut_validation',
                'rut': kyc_data.rut,
                'valid': is_valid
            })
        
        # 2. Screening contra listas
        screening_result = await self._perform_watchlist_screening(kyc_data)
        results['verifications'].append({
            'type': 'watchlist_screening',
            'result': screening_result
        })
        
        # 3. Verificación de UBOs (para entidades)
        if isinstance(kyc_data, EntityKYC):
            ubo_result = self.verify_ubo_threshold(kyc_data.beneficial_owners)
            results['verifications'].append({
                'type': 'ubo_verification',
                'result': ubo_result
            })
        
        # 4. Calcular score de riesgo
        risk_scorer = CustomerRiskScorer()
        risk_result = risk_scorer.calculate_risk_score(
            self._kyc_to_customer_dict(kyc_data)
        )
        results['risk_assessment'] = risk_result
        
        # 5. Determinar nivel DD
        dd_level = self.determine_dd_level(
            customer_type=results['customer_type'],
            risk_score=risk_result['total_score'],
            is_pep=kyc_data.is_pep if hasattr(kyc_data, 'is_pep') else False,
            country_risk='low',  # Simplificado
            product_risk='low'
        )
        results['due_diligence_level'] = dd_level.value
        
        # 6. Verificar requisitos documentales
        doc_check = self.check_document_requirements(kyc_data, dd_level)
        results['document_requirements'] = doc_check
        
        # 7. Determinar estado final
        if doc_check['is_complete'] and not screening_result.get('matches'):
            results['kyc_status'] = 'approved'
            results['next_review_date'] = self.calculate_kyc_expiry(
                dd_level, risk_result['total_score']
            ).isoformat()
        elif screening_result.get('matches'):
            results['kyc_status'] = 'escalated'
            results['escalation_reason'] = 'watchlist_match'
        else:
            results['kyc_status'] = 'pending'
            results['pending_items'] = doc_check['missing_items'] + doc_check['pending_items']
        
        return results
    
    async def _perform_watchlist_screening(
        self,
        kyc_data: IndividualKYC | EntityKYC
    ) -> Dict[str, Any]:
        """Realizar screening contra listas."""
        # Placeholder - en producción usar servicio real
        return {
            'screened': True,
            'matches': [],
            'lists_checked': ['OFAC_SDN', 'UN_CONSOLIDATED', 'EU_SANCTIONS', 'CHILE_UAF']
        }
    
    def _kyc_to_customer_dict(self, kyc_data) -> Dict[str, Any]:
        """Convertir KYC a dict para scoring."""
        if isinstance(kyc_data, IndividualKYC):
            return {
                'type': 'individual',
                'country_residence': kyc_data.country_residence,
                'nationality': kyc_data.nationality,
                'is_pep': kyc_data.is_pep,
                'products': [],
                'onboarding_channel': 'digital_verified'
            }
        else:
            return {
                'type': kyc_data.entity_type.value,
                'country_residence': kyc_data.country_incorporation,
                'nationality': kyc_data.country_incorporation,
                'is_pep': any(ubo.is_pep for ubo in kyc_data.beneficial_owners),
                'products': [],
                'onboarding_channel': 'digital_verified'
            }
```

---

# 5-10. MÓDULOS C04-C09

*[Por brevedad, se resumen los módulos restantes. La implementación completa seguiría el mismo patrón detallado.]*

## 5. C04-PEP: Politically Exposed Persons

- **Funcionalidades**: Identificación PEP, categorización por nivel, monitoreo relaciones
- **Fuentes**: Diario Oficial, SII (contribuyentes especiales), SERVEL, Poder Judicial
- **Categorías**: PEP Nacional (ministros, parlamentarios, jueces), PEP Regional, PEP Internacional

## 6. C05-SAR: Suspicious Activity Reporting

- **Funcionalidades**: Generación ROS automática, workflow aprobación, envío UAF
- **Formato**: XML según especificación UAF Chile
- **SLA**: 24 horas para críticos, 5 días para alto riesgo

## 7. C06-CTR: Currency Transaction Reporting

- **Umbral**: USD 10,000 (equivalente CLP)
- **Reporte**: Automático a UAF para transacciones en efectivo
- **Agregación**: Múltiples transacciones del mismo cliente en 24h

## 8. C07-FATCA: Foreign Account Tax Compliance

- **Aplicación**: Cuentas de US persons
- **Reportes**: Form 8966 anual
- **Clasificación**: FFI Participating, NFFE

## 9. C08-CRS: Common Reporting Standard

- **Intercambio**: Automático con 100+ jurisdicciones
- **Due Diligence**: Self-certification, verificación documental
- **Reportes**: XML formato OCDE

## 10. C09-GDPR: Data Protection

- **Derechos**: Acceso, rectificación, portabilidad, olvido
- **Consentimientos**: Gestión granular
- **Brechas**: Notificación 72 horas

---

# 11. ARQUITECTURA TÉCNICA INTEGRADA

## 11.1 Diagrama de Arquitectura

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        COMPLIANCE SUITE v4.0                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                         API GATEWAY (Kong)                              │ │
│  │  Rate Limiting │ Auth (JWT/OAuth2) │ Audit Logging │ API Versioning    │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                    │                                         │
│  ┌─────────────┬──────────────┬────┴────────┬──────────────┬─────────────┐ │
│  │             │              │             │              │             │ │
│  │  GRC API    │  AML API     │  KYC API    │  SAR API     │  Report API │ │
│  │  (FastAPI)  │  (FastAPI)   │  (FastAPI)  │  (FastAPI)   │  (FastAPI)  │ │
│  │             │              │             │              │             │ │
│  └──────┬──────┴───────┬──────┴──────┬──────┴───────┬──────┴──────┬──────┘ │
│         │              │             │              │             │         │
│  ┌──────┴──────────────┴─────────────┴──────────────┴─────────────┴──────┐ │
│  │                     BUSINESS LOGIC LAYER                               │ │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐      │ │
│  │  │ Rule Engine │ │ Detection   │ │ Scoring     │ │ Workflow    │      │ │
│  │  │ (Drools)    │ │ Engine      │ │ Engine      │ │ Engine      │      │ │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘      │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                    │                                         │
│  ┌─────────────┬──────────────┬────┴────────┬──────────────┬─────────────┐ │
│  │             │              │             │              │             │ │
│  │ PostgreSQL  │  MongoDB     │  Redis      │ Elasticsearch│ TimescaleDB │ │
│  │ (Transac.)  │  (Documents) │  (Cache)    │ (Search)     │ (Series)    │ │
│  │             │              │             │              │             │ │
│  └─────────────┴──────────────┴─────────────┴──────────────┴─────────────┘ │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                      EXTERNAL INTEGRATIONS                              │ │
│  │  UAF │ CMF │ SII │ WorldCheck │ Dow Jones │ ComplyAdvantage │ e-Sign   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 11.2 Stack Tecnológico

| Capa | Tecnología | Versión | Propósito |
|------|------------|---------|-----------|
| Frontend | Next.js | 14.x | UI Compliance Dashboard |
| API | FastAPI | 0.109+ | REST APIs |
| Business Logic | Python | 3.11+ | Core processing |
| Rules Engine | Drools | 8.x | Reglas de negocio complejas |
| Cache | Redis | 7.x | Sesiones, rate limiting |
| Primary DB | PostgreSQL | 16 | Datos transaccionales |
| Document Store | MongoDB | 7.x | KYC documents, audit logs |
| Time Series | TimescaleDB | 2.x | Métricas, KRIs |
| Search | Elasticsearch | 8.x | Full-text search, alertas |
| Message Queue | RabbitMQ | 3.x | Event-driven processing |
| Orchestration | Kubernetes | 1.29+ | Container management |

---

# 12. IMPLEMENTACIÓN DE CÓDIGO COMPLETA

*[El código completo de implementación se encuentra en los archivos de código separados en el repositorio, incluyendo:]*

- `compliance_grc_api.py` - API completa GRC
- `compliance_aml_api.py` - API completa AML
- `compliance_kyc_api.py` - API completa KYC
- `compliance_models.py` - Modelos SQLAlchemy
- `compliance_schemas.py` - Schemas Pydantic
- `compliance_services.py` - Servicios de negocio
- `compliance_rules.py` - Motor de reglas
- `compliance_integrations.py` - Integraciones externas

---

**FIN PARTE 5: COMPLIANCE SUITE**

*Continúa en Parte 6: Due Diligence Corporativa*
