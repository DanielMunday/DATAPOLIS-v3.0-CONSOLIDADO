# DATAPOLIS PRO v3.1

## Sistema Integral de Gestión de Copropiedades

### Descripción
DATAPOLIS PRO es una plataforma PropTech/FinTech especializada en la administración de condominios chilenos, con enfoque en:
- Cumplimiento tributario (Ley 21.713)
- Gestión de copropiedad (Ley 21.442)
- Protección de datos (Ley 21.719)
- Normativa reglamentaria (DS 7-2025)

### Características Principales

#### 🏢 Gestión de Comunidades
- Administración de edificios y unidades
- Control de propietarios y arrendatarios
- Porcentajes de dominio y prorrateo

#### 💰 Gastos Comunes
- Emisión de boletas mensuales
- Control de morosidad (límite 3% Ley 21.442)
- Fondo de reserva obligatorio
- Cobranza automatizada

#### 📡 Arriendos de Bienes Comunes
- Contratos de arriendo (antenas, publicidad, estacionamientos, etc.)
- Facturación mensual
- Distribución a copropietarios
- **Cumplimiento Art. 17 N°3 LIR (Ley 21.713)**

#### 🏦 Sistema Bancario (NUEVO v3.1)
- Gestión de cuentas bancarias según ley
- Cuenta exclusiva GC (Art. 40 Ley 21.442)
- Cuenta separada arriendos (Art. 23 DS 7-2025)
- Traspasos con asientos automáticos
- Conciliación bancaria

#### 📊 Contabilidad
- Plan de cuentas chileno
- Asientos contables
- Libro Mayor y Diario
- Balance General
- Estado de Resultados
- Cierres mensuales/anuales

#### 📋 Reportes Tributarios
- Balance formato SII
- Declaraciones Juradas
- **Planilla de distribución formato SII**
- **Certificados por copropietario (Art. 17 N°3)**
- PPM y retenciones

#### 👥 RRHH
- Contratos de trabajo
- Liquidaciones de sueldo
- Cálculos previsionales
- Previred
- Vacaciones y finiquitos

#### 📱 Portal Copropietarios
- Dashboard personal
- Estado de cuenta
- Pagos online (WebPay, Khipu)
- Documentos
- Votaciones online
- Reservas de espacios

#### ✅ Compliance
- Análisis de reglamentos (DS 7-2025)
- Simulador de sanciones
- Certificación de cumplimiento
- Protección de datos (ARCO)

### Stack Tecnológico

**Backend:**
- PHP 8.2+
- Laravel 11
- MySQL 8.0 / PostgreSQL 15
- Redis (colas y caché)

**Frontend:**
- React 18
- TypeScript
- Tailwind CSS
- Vite

### Instalación

```bash
# Clonar repositorio
git clone https://github.com/datapolis/datapolis-pro.git
cd datapolis-pro

# Backend
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed

# Frontend
cd frontend
npm install
npm run dev
```

### Configuración de Cuentas Bancarias

Para cumplir con la ley, debe crear al menos estas cuentas:

```php
// Cuenta Gastos Comunes (obligatoria Art. 40 Ley 21.442)
POST /api/bancos/cuentas
{
    "edificio_id": 1,
    "banco_codigo": "BCI",
    "banco_nombre": "Banco de Crédito e Inversiones",
    "tipo_cuenta": "corriente",
    "numero_cuenta": "12345678",
    "proposito": "gastos_comunes"
}

// Cuenta Arriendos (obligatoria si hay arriendos - Art. 23 DS 7-2025)
POST /api/bancos/cuentas
{
    "edificio_id": 1,
    "banco_codigo": "BCI",
    "banco_nombre": "Banco de Crédito e Inversiones",
    "tipo_cuenta": "corriente",
    "numero_cuenta": "12345679",
    "proposito": "arriendos"
}
```

### Flujo Art. 17 N°3 (Ley 21.713)

```php
// 1. Procesar distribución mensual
POST /api/tributario/distribucion-mensual
{
    "edificio_id": 1,
    "mes": 1,
    "anio": 2025
}

// 2. Crear traspasos de arriendos a GC (NO constituye renta)
POST /api/bancos/traspasos/arriendos-gc
{
    "edificio_id": 1,
    "monto": 500000,
    "periodo": "2025-01"
}

// 3. Generar resumen anual
POST /api/tributario/resumen-anual
{
    "edificio_id": 1,
    "anio": 2025
}

// 4. Descargar certificados
GET /api/tributario/certificado/{unidadId}/pdf?anio=2025
```

### Estructura del Proyecto

```
datapolis-pro/
├── app/
│   ├── Http/Controllers/Api/
│   │   ├── AuthController.php
│   │   ├── EdificiosController.php
│   │   ├── UnidadesController.php
│   │   ├── GastosComunesController.php
│   │   ├── ArriendosController.php
│   │   ├── DistribucionController.php
│   │   ├── ContabilidadController.php
│   │   ├── RRHHController.php
│   │   ├── ReportesTributariosController.php
│   │   ├── SistemaBancarioTributarioController.php  # NUEVO
│   │   └── ...
│   ├── Services/
│   │   ├── GastosComunesService.php
│   │   ├── TributarioService.php
│   │   ├── GestionBancariaTributariaService.php  # NUEVO
│   │   └── ...
│   └── Models/
├── database/migrations/
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   ├── components/
│   │   └── services/
│   └── package.json
├── resources/views/pdf/
└── routes/
```

### Documentación

- [Manual de Usuario](docs/MANUAL_USUARIO.md)
- [API Reference](docs/API_REFERENCE.yaml)
- [Guía de Desarrollo](docs/GUIA_DESARROLLO.md)
- [Cumplimiento Legal](docs/MANUAL_CUMPLIMIENTO_LEGAL.md)

### Licencia

Propietario - DATAPOLIS SpA © 2024-2025

### Contacto

- Web: https://datapolis.cl
- Email: soporte@datapolis.cl
