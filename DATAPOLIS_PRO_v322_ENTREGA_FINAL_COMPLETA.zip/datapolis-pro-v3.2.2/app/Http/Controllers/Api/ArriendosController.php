<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - Arriendos Controller
 * Contratos de arriendo y tributación Ley 21.713
 */
class ArriendosController extends Controller
{
    /**
     * Listar contratos
     */
    public function contratos(Request $request): JsonResponse
    {
        $contratos = DB::table('contratos_arriendo')
            ->join('edificios', 'contratos_arriendo.edificio_id', '=', 'edificios.id')
            ->leftJoin('arrendatarios', 'contratos_arriendo.arrendatario_id', '=', 'arrendatarios.id')
            ->where('contratos_arriendo.tenant_id', Auth::user()->tenant_id)
            ->whereNull('contratos_arriendo.deleted_at')
            ->when($request->edificio_id, fn($q) => $q->where('contratos_arriendo.edificio_id', $request->edificio_id))
            ->when($request->estado, fn($q) => $q->where('contratos_arriendo.estado', $request->estado))
            ->select(
                'contratos_arriendo.*',
                'edificios.nombre as edificio',
                'arrendatarios.razon_social as arrendatario',
                'arrendatarios.rut as arrendatario_rut'
            )
            ->orderByDesc('contratos_arriendo.fecha_inicio')
            ->get();

        return response()->json(['success' => true, 'data' => $contratos]);
    }

    /**
     * Crear contrato
     */
    public function crearContrato(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'arrendatario_id' => 'required|exists:arrendatarios,id',
            'tipo_espacio' => 'required|in:azotea,fachada,subterraneo,terreno,sala_tecnica,otro',
            'ubicacion_espacio' => 'required|string|max:200',
            'fecha_inicio' => 'required|date',
            'fecha_termino' => 'required|date|after:fecha_inicio',
            'monto_mensual' => 'required|numeric|min:0',
            'moneda' => 'required|in:CLP,UF,USD',
        ]);

        $id = DB::table('contratos_arriendo')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'arrendatario_id' => $request->arrendatario_id,
            'tipo_espacio' => $request->tipo_espacio,
            'ubicacion_espacio' => $request->ubicacion_espacio,
            'superficie_m2' => $request->superficie_m2,
            'descripcion_espacio' => $request->descripcion_espacio,
            'fecha_inicio' => $request->fecha_inicio,
            'fecha_termino' => $request->fecha_termino,
            'monto_mensual' => $request->monto_mensual,
            'moneda' => $request->moneda,
            'dia_facturacion' => $request->dia_facturacion ?? 1,
            'dias_pago' => $request->dias_pago ?? 30,
            'reajuste_tipo' => $request->reajuste_tipo ?? 'uf',
            'reajuste_periodo' => $request->reajuste_periodo ?? 'anual',
            'garantia_meses' => $request->garantia_meses ?? 1,
            'garantia_monto' => $request->garantia_monto,
            'estado' => 'activo',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Contrato creado exitosamente',
            'id' => $id,
        ], 201);
    }

    /**
     * Mostrar contrato
     */
    public function showContrato(int $id): JsonResponse
    {
        $contrato = DB::table('contratos_arriendo')
            ->join('edificios', 'contratos_arriendo.edificio_id', '=', 'edificios.id')
            ->leftJoin('arrendatarios', 'contratos_arriendo.arrendatario_id', '=', 'arrendatarios.id')
            ->where('contratos_arriendo.id', $id)
            ->where('contratos_arriendo.tenant_id', Auth::user()->tenant_id)
            ->select(
                'contratos_arriendo.*',
                'edificios.nombre as edificio',
                'edificios.direccion as edificio_direccion',
                'arrendatarios.razon_social as arrendatario',
                'arrendatarios.rut as arrendatario_rut',
                'arrendatarios.email as arrendatario_email'
            )
            ->first();

        if (!$contrato) {
            return response()->json(['success' => false, 'message' => 'Contrato no encontrado'], 404);
        }

        // Facturas del contrato
        $contrato->facturas = DB::table('facturas_arriendo')
            ->where('contrato_id', $id)
            ->orderByDesc('periodo_anio')
            ->orderByDesc('periodo_mes')
            ->limit(24)
            ->get();

        // Estadísticas
        $contrato->stats = [
            'total_facturado' => DB::table('facturas_arriendo')
                ->where('contrato_id', $id)
                ->sum('monto_total'),
            'total_pagado' => DB::table('facturas_arriendo')
                ->where('contrato_id', $id)
                ->where('estado', 'pagada')
                ->sum('monto_total'),
            'facturas_pendientes' => DB::table('facturas_arriendo')
                ->where('contrato_id', $id)
                ->whereIn('estado', ['pendiente', 'vencida'])
                ->count(),
        ];

        return response()->json(['success' => true, 'data' => $contrato]);
    }

    /**
     * Actualizar contrato
     */
    public function updateContrato(Request $request, int $id): JsonResponse
    {
        $contrato = DB::table('contratos_arriendo')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$contrato) {
            return response()->json(['success' => false, 'message' => 'Contrato no encontrado'], 404);
        }

        DB::table('contratos_arriendo')->where('id', $id)->update(array_merge(
            array_filter($request->only([
                'ubicacion_espacio', 'superficie_m2', 'descripcion_espacio',
                'monto_mensual', 'moneda', 'dia_facturacion', 'dias_pago',
                'reajuste_tipo', 'reajuste_periodo',
            ]), fn($v) => $v !== null),
            ['updated_at' => now()]
        ));

        return response()->json(['success' => true, 'message' => 'Contrato actualizado']);
    }

    /**
     * Renovar contrato
     */
    public function renovarContrato(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'nueva_fecha_termino' => 'required|date|after:today',
            'nuevo_monto' => 'nullable|numeric|min:0',
        ]);

        $contrato = DB::table('contratos_arriendo')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$contrato) {
            return response()->json(['success' => false, 'message' => 'Contrato no encontrado'], 404);
        }

        DB::table('contratos_arriendo')->where('id', $id)->update([
            'fecha_termino' => $request->nueva_fecha_termino,
            'monto_mensual' => $request->nuevo_monto ?? $contrato->monto_mensual,
            'renovaciones' => ($contrato->renovaciones ?? 0) + 1,
            'ultima_renovacion' => now(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Contrato renovado']);
    }

    /**
     * Terminar contrato
     */
    public function terminarContrato(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'fecha_termino_real' => 'required|date',
            'motivo' => 'required|string|max:500',
        ]);

        $contrato = DB::table('contratos_arriendo')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$contrato) {
            return response()->json(['success' => false, 'message' => 'Contrato no encontrado'], 404);
        }

        DB::table('contratos_arriendo')->where('id', $id)->update([
            'estado' => 'terminado',
            'fecha_termino_real' => $request->fecha_termino_real,
            'motivo_termino' => $request->motivo,
            'terminado_por' => Auth::id(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Contrato terminado']);
    }

    /**
     * Listar facturación
     */
    public function facturacion(Request $request): JsonResponse
    {
        $facturas = DB::table('facturas_arriendo')
            ->join('contratos_arriendo', 'facturas_arriendo.contrato_id', '=', 'contratos_arriendo.id')
            ->join('edificios', 'contratos_arriendo.edificio_id', '=', 'edificios.id')
            ->leftJoin('arrendatarios', 'contratos_arriendo.arrendatario_id', '=', 'arrendatarios.id')
            ->where('facturas_arriendo.tenant_id', Auth::user()->tenant_id)
            ->when($request->edificio_id, fn($q) => $q->where('contratos_arriendo.edificio_id', $request->edificio_id))
            ->when($request->estado, fn($q) => $q->where('facturas_arriendo.estado', $request->estado))
            ->when($request->anio, fn($q) => $q->where('facturas_arriendo.periodo_anio', $request->anio))
            ->select(
                'facturas_arriendo.*',
                'edificios.nombre as edificio',
                'arrendatarios.razon_social as arrendatario'
            )
            ->orderByDesc('facturas_arriendo.periodo_anio')
            ->orderByDesc('facturas_arriendo.periodo_mes')
            ->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $facturas]);
    }

    /**
     * Generar facturación mensual
     */
    public function generarFacturacion(Request $request): JsonResponse
    {
        $request->validate([
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
            'edificio_id' => 'nullable|exists:edificios,id',
        ]);

        $tenantId = Auth::user()->tenant_id;
        $mes = $request->mes;
        $anio = $request->anio;

        $contratos = DB::table('contratos_arriendo')
            ->where('tenant_id', $tenantId)
            ->where('estado', 'activo')
            ->where('fecha_inicio', '<=', Carbon::create($anio, $mes)->endOfMonth())
            ->where('fecha_termino', '>=', Carbon::create($anio, $mes)->startOfMonth())
            ->when($request->edificio_id, fn($q) => $q->where('edificio_id', $request->edificio_id))
            ->get();

        $generadas = 0;
        $ufValor = config('datapolis.tributario.uf', 37000);

        foreach ($contratos as $contrato) {
            // Verificar si ya existe factura
            $existe = DB::table('facturas_arriendo')
                ->where('contrato_id', $contrato->id)
                ->where('periodo_mes', $mes)
                ->where('periodo_anio', $anio)
                ->exists();

            if ($existe) continue;

            // Calcular monto según moneda
            $montoClp = $contrato->monto_mensual;
            if ($contrato->moneda === 'UF') {
                $montoClp = round($contrato->monto_mensual * $ufValor, 0);
            }

            $numeroFactura = sprintf('FA-%04d%02d-%04d', $anio, $mes, $contrato->id);

            DB::table('facturas_arriendo')->insert([
                'tenant_id' => $tenantId,
                'contrato_id' => $contrato->id,
                'edificio_id' => $contrato->edificio_id,
                'numero_factura' => $numeroFactura,
                'periodo_mes' => $mes,
                'periodo_anio' => $anio,
                'fecha_emision' => now(),
                'fecha_vencimiento' => Carbon::create($anio, $mes, $contrato->dia_facturacion ?? 1)
                    ->addDays($contrato->dias_pago ?? 30),
                'monto_neto' => $montoClp,
                'iva' => 0, // Arriendos exentos de IVA en condominios
                'monto_total' => $montoClp,
                'moneda_original' => $contrato->moneda,
                'monto_original' => $contrato->monto_mensual,
                'valor_uf_aplicado' => $ufValor,
                'estado' => 'pendiente',
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $generadas++;
        }

        return response()->json([
            'success' => true,
            'message' => "Se generaron {$generadas} facturas para {$mes}/{$anio}",
            'generadas' => $generadas,
        ]);
    }

    /**
     * Generar PDF de factura
     */
    public function facturaPdf(int $id)
    {
        $factura = DB::table('facturas_arriendo')
            ->join('contratos_arriendo', 'facturas_arriendo.contrato_id', '=', 'contratos_arriendo.id')
            ->join('edificios', 'contratos_arriendo.edificio_id', '=', 'edificios.id')
            ->leftJoin('arrendatarios', 'contratos_arriendo.arrendatario_id', '=', 'arrendatarios.id')
            ->where('facturas_arriendo.id', $id)
            ->select(
                'facturas_arriendo.*',
                'contratos_arriendo.tipo_espacio',
                'contratos_arriendo.ubicacion_espacio',
                'edificios.nombre as edificio',
                'edificios.direccion as edificio_direccion',
                'edificios.rut as edificio_rut',
                'arrendatarios.razon_social as arrendatario',
                'arrendatarios.rut as arrendatario_rut',
                'arrendatarios.direccion as arrendatario_direccion'
            )
            ->first();

        if (!$factura) {
            return response()->json(['success' => false, 'message' => 'Factura no encontrada'], 404);
        }

        $pdf = Pdf::loadView('pdf.factura-arriendo', compact('factura'));
        return $pdf->download("factura-{$factura->numero_factura}.pdf");
    }

    /**
     * Listar arrendatarios
     */
    public function arrendatarios(Request $request): JsonResponse
    {
        $arrendatarios = DB::table('arrendatarios')
            ->where('tenant_id', Auth::user()->tenant_id)
            ->whereNull('deleted_at')
            ->when($request->search, fn($q, $s) => $q->where('razon_social', 'like', "%{$s}%")
                ->orWhere('rut', 'like', "%{$s}%"))
            ->orderBy('razon_social')
            ->get();

        return response()->json(['success' => true, 'data' => $arrendatarios]);
    }

    /**
     * Crear arrendatario
     */
    public function crearArrendatario(Request $request): JsonResponse
    {
        $request->validate([
            'rut' => 'required|string|max:12',
            'razon_social' => 'required|string|max:200',
            'giro' => 'nullable|string|max:200',
            'email' => 'required|email',
        ]);

        $id = DB::table('arrendatarios')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'rut' => $request->rut,
            'razon_social' => $request->razon_social,
            'giro' => $request->giro,
            'direccion' => $request->direccion,
            'comuna' => $request->comuna,
            'telefono' => $request->telefono,
            'email' => $request->email,
            'contacto_nombre' => $request->contacto_nombre,
            'contacto_telefono' => $request->contacto_telefono,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Arrendatario creado',
            'id' => $id,
        ], 201);
    }
}
