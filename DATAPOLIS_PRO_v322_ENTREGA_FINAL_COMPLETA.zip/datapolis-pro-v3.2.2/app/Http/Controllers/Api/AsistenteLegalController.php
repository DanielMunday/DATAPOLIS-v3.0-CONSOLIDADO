<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

/**
 * DATAPOLIS PRO v3.0 - Asistente Legal Controller
 * Consultas sobre Ley 21.442, Ley 21.713, Ley 21.719
 */
class AsistenteLegalController extends Controller
{
    /**
     * Base de conocimiento legal
     */
    private array $leyes = [
        'ley_21442' => [
            'nombre' => 'Ley 21.442 de Copropiedad Inmobiliaria',
            'vigencia' => '2022-04-01',
            'descripcion' => 'Regula el régimen de copropiedad inmobiliaria en Chile',
            'articulos_clave' => [
                2 => 'Definiciones: Unidad, bienes comunes, prorrateo',
                5 => 'Gastos comunes: obligación de pago, interés máximo 3%',
                17 => 'Asambleas: convocatoria, quórum, votaciones',
                23 => 'Administrador: funciones y responsabilidades',
                32 => 'Fondo de reserva: mínimo 5% del presupuesto',
                '97_n2' => 'Sanciones por incumplimiento tributario',
            ],
        ],
        'ley_21713' => [
            'nombre' => 'Ley 21.713 de Cumplimiento Tributario',
            'vigencia' => '2024-01-01',
            'descripcion' => 'Establece nuevas obligaciones tributarias para condominios',
            'articulos_clave' => [
                '17_n3' => 'Tributación de arriendos de espacios comunes',
                'dj_1887' => 'Declaración jurada de distribución de ingresos',
                'distribucion' => 'Distribución proporcional a copropietarios',
            ],
        ],
        'ley_21719' => [
            'nombre' => 'Ley 21.719 de Protección de Datos Personales',
            'vigencia' => '2024-12-01',
            'descripcion' => 'Regula el tratamiento de datos personales',
            'articulos_clave' => [
                'arco' => 'Derechos ARCO: Acceso, Rectificación, Cancelación, Oposición',
                'consentimiento' => 'Requisitos para el tratamiento de datos',
                'brechas' => 'Notificación de brechas de seguridad',
                'sanciones' => 'Multas por incumplimiento',
            ],
        ],
    ];

    /**
     * Consulta al asistente legal
     */
    public function consulta(Request $request): JsonResponse
    {
        $request->validate([
            'pregunta' => 'required|string|max:1000',
            'contexto' => 'nullable|string',
        ]);

        $pregunta = strtolower($request->pregunta);
        $respuestas = [];

        // Detectar temas en la consulta
        if (str_contains($pregunta, 'mora') || str_contains($pregunta, 'interés') || str_contains($pregunta, 'interes')) {
            $respuestas[] = $this->respuestaMora();
        }

        if (str_contains($pregunta, 'asamblea') || str_contains($pregunta, 'quórum') || str_contains($pregunta, 'quorum') || str_contains($pregunta, 'votación')) {
            $respuestas[] = $this->respuestaAsambleas();
        }

        if (str_contains($pregunta, 'arriendo') || str_contains($pregunta, 'antena') || str_contains($pregunta, 'distribución') || str_contains($pregunta, '21.713') || str_contains($pregunta, '21713')) {
            $respuestas[] = $this->respuestaArriendos();
        }

        if (str_contains($pregunta, 'dato') || str_contains($pregunta, 'privacidad') || str_contains($pregunta, 'arco') || str_contains($pregunta, '21.719') || str_contains($pregunta, '21719')) {
            $respuestas[] = $this->respuestaProteccionDatos();
        }

        if (str_contains($pregunta, 'administrador') || str_contains($pregunta, 'funciones')) {
            $respuestas[] = $this->respuestaAdministrador();
        }

        if (str_contains($pregunta, 'fondo') || str_contains($pregunta, 'reserva')) {
            $respuestas[] = $this->respuestaFondoReserva();
        }

        if (empty($respuestas)) {
            $respuestas[] = [
                'tema' => 'Consulta general',
                'respuesta' => 'Su consulta ha sido registrada. Para temas específicos, puede preguntar sobre: gastos comunes y morosidad, asambleas y votaciones, arriendos y tributación (Ley 21.713), protección de datos (Ley 21.719), funciones del administrador, o fondo de reserva.',
                'referencias' => array_keys($this->leyes),
            ];
        }

        return response()->json([
            'success' => true,
            'data' => [
                'pregunta' => $request->pregunta,
                'respuestas' => $respuestas,
                'disclaimer' => 'Esta información es orientativa. Para casos específicos, consulte con un abogado especializado.',
            ],
        ]);
    }

    /**
     * Listar leyes disponibles
     */
    public function leyes(): JsonResponse
    {
        $resumen = collect($this->leyes)->map(fn($ley) => [
            'nombre' => $ley['nombre'],
            'vigencia' => $ley['vigencia'],
            'descripcion' => $ley['descripcion'],
        ]);

        return response()->json(['success' => true, 'data' => $resumen]);
    }

    /**
     * Artículos de una ley
     */
    public function articulos(string $ley): JsonResponse
    {
        $key = str_replace('.', '', $ley);
        $key = "ley_{$key}";

        if (!isset($this->leyes[$key])) {
            return response()->json(['success' => false, 'message' => 'Ley no encontrada'], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $this->leyes[$key],
        ]);
    }

    private function respuestaMora(): array
    {
        return [
            'tema' => 'Morosidad e Intereses',
            'respuesta' => 'Según el Art. 5 de la Ley 21.442, el interés máximo por mora en gastos comunes es del 3% mensual. El cobro debe realizarse desde el día siguiente al vencimiento. Los intereses se calculan sobre el saldo insoluto y no pueden exceder el tope legal.',
            'normativa' => 'Ley 21.442, Artículo 5',
            'recomendaciones' => [
                'Establecer fecha de vencimiento clara en el reglamento',
                'Notificar al copropietario antes de aplicar intereses',
                'Mantener registro detallado de la morosidad',
                'Considerar convenios de pago para deudores',
            ],
        ];
    }

    private function respuestaAsambleas(): array
    {
        return [
            'tema' => 'Asambleas y Votaciones',
            'respuesta' => 'La Ley 21.442 establece los siguientes quórums: Asamblea ordinaria (primera citación): 60% de derechos. Segunda citación: 33.33%. Asamblea extraordinaria: 66.67%. Materias especiales (modificación reglamento, obras mayores): pueden requerir mayorías calificadas o unanimidad.',
            'normativa' => 'Ley 21.442, Artículos 17-20',
            'recomendaciones' => [
                'Convocar con al menos 5 días de anticipación',
                'Incluir tabla de materias en la convocatoria',
                'Permitir asambleas telemáticas según reglamento',
                'Levantar acta con firma de asistentes',
            ],
        ];
    }

    private function respuestaArriendos(): array
    {
        return [
            'tema' => 'Arriendos y Tributación (Ley 21.713)',
            'respuesta' => 'Desde 2024, los ingresos por arriendo de espacios comunes (antenas, publicidad, etc.) deben: 1) Tributar según Art. 17 N°3 de la LIR. 2) Distribuirse proporcionalmente a los copropietarios según prorrateo. 3) Informarse al SII mediante DJ 1887. Los copropietarios deben declarar su parte proporcional en sus declaraciones de renta.',
            'normativa' => 'Ley 21.713, Ley de Impuesto a la Renta Art. 17 N°3',
            'recomendaciones' => [
                'Mantener contabilidad separada de arriendos',
                'Calcular distribución mensual por prorrateo',
                'Emitir certificados de renta a copropietarios',
                'Presentar DJ 1887 antes del 31 de marzo',
            ],
        ];
    }

    private function respuestaProteccionDatos(): array
    {
        return [
            'tema' => 'Protección de Datos Personales (Ley 21.719)',
            'respuesta' => 'La administración del condominio debe cumplir con: Derechos ARCO+ (Acceso, Rectificación, Cancelación, Oposición, Portabilidad). Obtener consentimiento para tratamiento de datos. Implementar medidas de seguridad. Notificar brechas en 72 horas. Plazo para responder solicitudes: 10 días hábiles.',
            'normativa' => 'Ley 21.719 de Protección de Datos Personales',
            'recomendaciones' => [
                'Crear registro de tratamiento de datos',
                'Implementar política de privacidad',
                'Capacitar al personal sobre protección de datos',
                'Establecer procedimiento para solicitudes ARCO',
            ],
        ];
    }

    private function respuestaAdministrador(): array
    {
        return [
            'tema' => 'Funciones del Administrador',
            'respuesta' => 'Según el Art. 23 de la Ley 21.442, el administrador debe: Representar a la comunidad judicialmente y extrajudicialmente. Velar por el cumplimiento del reglamento. Cobrar gastos comunes. Mantener la contabilidad al día. Convocar asambleas. Cuidar los bienes comunes. Contratar seguros obligatorios.',
            'normativa' => 'Ley 21.442, Artículos 23-25',
            'recomendaciones' => [
                'Rendir cuenta documentada mensualmente',
                'Mantener pólizas de seguro vigentes',
                'Informar novedades a los copropietarios',
                'Conservar documentación por 5 años',
            ],
        ];
    }

    private function respuestaFondoReserva(): array
    {
        return [
            'tema' => 'Fondo de Reserva',
            'respuesta' => 'El Art. 32 de la Ley 21.442 establece un fondo de reserva mínimo del 5% del presupuesto anual. Este fondo está destinado a: Reparaciones mayores no previstas. Mantención extraordinaria de bienes comunes. Contingencias. No puede usarse para gastos corrientes sin autorización de asamblea.',
            'normativa' => 'Ley 21.442, Artículo 32',
            'recomendaciones' => [
                'Mantener el fondo en cuenta separada',
                'Invertir en instrumentos de bajo riesgo',
                'Presentar informe del fondo en asamblea anual',
                'Documentar todo uso del fondo',
            ],
        ];
    }
}
