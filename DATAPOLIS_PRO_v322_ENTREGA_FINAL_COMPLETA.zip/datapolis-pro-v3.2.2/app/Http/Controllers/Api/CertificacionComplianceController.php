<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\CertificacionComplianceService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use App\Models\Edificio;
use App\Models\CertificadoCompliance;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

/**
 * CertificacionComplianceController
 * 
 * API REST para certificación de compliance integral
 * Leyes 21.442, 21.713, 21.719 y Protección de Datos
 * 
 * @package DATAPOLIS PRO v3.0
 * @author Daniel - DATAPOLIS
 * @version 1.0.0
 */
class CertificacionComplianceController extends Controller
{
    protected CertificacionComplianceService $certificacionService;

    public function __construct(CertificacionComplianceService $certificacionService)
    {
        $this->certificacionService = $certificacionService;
    }

    /**
     * Evaluar compliance sin emitir certificado
     * 
     * POST /api/v1/compliance/evaluar
     */
    public function evaluar(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'edificio_id' => 'required|integer|exists:edificios,id',
            'modulos' => 'nullable|array',
            'modulos.*' => 'string|in:gobernanza,financiero,tributario,proteccion_datos,operacional',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $edificio = Edificio::findOrFail($request->edificio_id);
            $this->authorize('evaluar-compliance', $edificio);

            $resultado = $this->certificacionService->evaluarCompliance(
                $request->edificio_id,
                $request->modulos
            );

            Log::info('Evaluación compliance completada', [
                'edificio_id' => $request->edificio_id,
                'score' => $resultado['score_global'],
            ]);

            return response()->json([
                'success' => true,
                'data' => $resultado,
            ]);

        } catch (\Exception $e) {
            Log::error('Error en evaluación compliance', [
                'edificio_id' => $request->edificio_id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Error al evaluar compliance',
            ], 500);
        }
    }

    /**
     * Emitir certificado de compliance
     * 
     * POST /api/v1/compliance/certificar
     */
    public function certificar(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'edificio_id' => 'required|integer|exists:edificios,id',
            'tipo_certificado' => 'required|string|in:COMPLIANCE_INTEGRAL,LEY_21442,TRIBUTARIO,PROTECCION_DATOS,DISTRIBUCION_RENTAS,NO_DEUDA,RENTA_DISTRIBUIDA',
            'periodo' => 'nullable|string|regex:/^\d{4}(-\d{2})?$/',
            'observaciones' => 'nullable|string|max:500',
        ], [
            'tipo_certificado.in' => 'Tipo de certificado no válido',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $edificio = Edificio::findOrFail($request->edificio_id);
            $this->authorize('emitir-certificado', $edificio);

            $resultado = $this->certificacionService->emitirCertificado(
                $request->edificio_id,
                $request->tipo_certificado,
                $request->periodo,
                $request->observaciones
            );

            if ($resultado['estado'] === 'RECHAZADO') {
                return response()->json([
                    'success' => false,
                    'error' => 'No se puede emitir el certificado',
                    'data' => [
                        'motivo' => 'No cumple requisitos mínimos',
                        'score' => $resultado['score_global'],
                        'items_criticos_fallidos' => $resultado['items_criticos_fallidos'] ?? [],
                        'recomendaciones' => $resultado['recomendaciones'] ?? [],
                    ],
                ], 422);
            }

            Log::info('Certificado compliance emitido', [
                'edificio_id' => $request->edificio_id,
                'tipo' => $request->tipo_certificado,
                'codigo' => $resultado['codigo_certificado'],
                'estado' => $resultado['estado'],
            ]);

            return response()->json([
                'success' => true,
                'data' => [
                    'certificado' => [
                        'codigo' => $resultado['codigo_certificado'],
                        'tipo' => $request->tipo_certificado,
                        'estado' => $resultado['estado'],
                        'score' => $resultado['score_global'],
                        'nivel' => $resultado['nivel_cumplimiento'],
                        'fecha_emision' => $resultado['fecha_emision'],
                        'fecha_vencimiento' => $resultado['fecha_vencimiento'],
                        'url_verificacion' => $resultado['url_verificacion'],
                        'hash_verificacion' => $resultado['hash_verificacion'],
                    ],
                    'evaluacion' => $resultado['evaluacion_detallada'] ?? null,
                ],
                'mensaje' => 'Certificado emitido exitosamente',
            ], 201);

        } catch (\Exception $e) {
            Log::error('Error emitiendo certificado', [
                'edificio_id' => $request->edificio_id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Error al emitir certificado',
            ], 500);
        }
    }

    /**
     * Verificar certificado (público)
     * 
     * GET /api/v1/compliance/verificar/{codigo}
     */
    public function verificar(string $codigo): JsonResponse
    {
        try {
            $resultado = $this->certificacionService->verificarCertificado($codigo);

            if (!$resultado['valido']) {
                return response()->json([
                    'success' => false,
                    'data' => [
                        'valido' => false,
                        'motivo' => $resultado['motivo'],
                    ],
                ], 404);
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'valido' => true,
                    'certificado' => [
                        'codigo' => $resultado['certificado']['codigo'],
                        'tipo' => $resultado['certificado']['tipo'],
                        'edificio' => $resultado['certificado']['edificio_nombre'],
                        'direccion' => $resultado['certificado']['edificio_direccion'],
                        'estado' => $resultado['certificado']['estado'],
                        'nivel_cumplimiento' => $resultado['certificado']['nivel_cumplimiento'],
                        'score' => $resultado['certificado']['score'],
                        'fecha_emision' => $resultado['certificado']['fecha_emision'],
                        'fecha_vencimiento' => $resultado['certificado']['fecha_vencimiento'],
                        'vigente' => $resultado['certificado']['vigente'],
                    ],
                    'verificacion' => [
                        'fecha_consulta' => now()->format('Y-m-d H:i:s'),
                        'hash_valido' => true,
                    ],
                ],
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al verificar certificado',
            ], 500);
        }
    }

    /**
     * Descargar certificado en PDF
     * 
     * GET /api/v1/compliance/certificado/{id}/pdf
     */
    public function descargarPdf(int $id): JsonResponse
    {
        try {
            $certificado = CertificadoCompliance::with('edificio')->findOrFail($id);
            $this->authorize('descargar-certificado', $certificado->edificio);

            // Generar QR
            $qrCode = QrCode::format('png')
                ->size(150)
                ->generate($certificado->url_verificacion);

            $qrBase64 = base64_encode($qrCode);

            // Generar PDF
            $pdf = \PDF::loadView('certificados.compliance', [
                'certificado' => $certificado,
                'edificio' => $certificado->edificio,
                'evaluacion' => json_decode($certificado->evaluacion_json, true),
                'qr_base64' => $qrBase64,
            ]);

            $filename = "certificado_{$certificado->tipo}_{$certificado->codigo}.pdf";
            $path = "certificados/{$certificado->edificio_id}/{$filename}";
            
            Storage::disk('public')->put($path, $pdf->output());

            return response()->json([
                'success' => true,
                'data' => [
                    'url' => Storage::disk('public')->url($path),
                    'filename' => $filename,
                ],
            ]);

        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'error' => 'Certificado no encontrado',
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al generar PDF',
            ], 500);
        }
    }

    /**
     * Listar certificados de un edificio
     * 
     * GET /api/v1/compliance/certificados/{edificioId}
     */
    public function listar(int $edificioId, Request $request): JsonResponse
    {
        try {
            $edificio = Edificio::findOrFail($edificioId);
            $this->authorize('ver-certificados', $edificio);

            $query = CertificadoCompliance::where('edificio_id', $edificioId);

            // Filtros opcionales
            if ($request->tipo) {
                $query->where('tipo', $request->tipo);
            }
            if ($request->estado) {
                $query->where('estado', $request->estado);
            }
            if ($request->vigentes_solo) {
                $query->where('fecha_vencimiento', '>=', now());
            }

            $certificados = $query->orderBy('created_at', 'desc')
                ->paginate($request->per_page ?? 20);

            return response()->json([
                'success' => true,
                'data' => $certificados->map(function ($cert) {
                    return [
                        'id' => $cert->id,
                        'codigo' => $cert->codigo,
                        'tipo' => $cert->tipo,
                        'estado' => $cert->estado,
                        'nivel' => $cert->nivel_cumplimiento,
                        'score' => $cert->score_global,
                        'fecha_emision' => $cert->created_at->format('Y-m-d'),
                        'fecha_vencimiento' => $cert->fecha_vencimiento,
                        'vigente' => $cert->fecha_vencimiento >= now()->format('Y-m-d'),
                        'url_verificacion' => $cert->url_verificacion,
                    ];
                }),
                'meta' => [
                    'total' => $certificados->total(),
                    'pagina_actual' => $certificados->currentPage(),
                    'ultima_pagina' => $certificados->lastPage(),
                ],
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al listar certificados',
            ], 500);
        }
    }

    /**
     * Obtener resumen de compliance del edificio
     * 
     * GET /api/v1/compliance/resumen/{edificioId}
     */
    public function resumen(int $edificioId): JsonResponse
    {
        try {
            $edificio = Edificio::findOrFail($edificioId);
            $this->authorize('ver-compliance', $edificio);

            // Último certificado integral
            $ultimoCertificado = CertificadoCompliance::where('edificio_id', $edificioId)
                ->where('tipo', 'COMPLIANCE_INTEGRAL')
                ->orderBy('created_at', 'desc')
                ->first();

            // Estadísticas de certificados
            $stats = CertificadoCompliance::where('edificio_id', $edificioId)
                ->selectRaw("
                    COUNT(*) as total,
                    SUM(CASE WHEN fecha_vencimiento >= CURDATE() THEN 1 ELSE 0 END) as vigentes,
                    SUM(CASE WHEN estado = 'APROBADO' THEN 1 ELSE 0 END) as aprobados,
                    SUM(CASE WHEN estado = 'CONDICIONAL' THEN 1 ELSE 0 END) as condicionales,
                    AVG(score_global) as score_promedio
                ")
                ->first();

            // Alertas de vencimiento próximo (30 días)
            $porVencer = CertificadoCompliance::where('edificio_id', $edificioId)
                ->whereBetween('fecha_vencimiento', [now(), now()->addDays(30)])
                ->get(['id', 'codigo', 'tipo', 'fecha_vencimiento']);

            // Evaluación rápida actual
            $evaluacionActual = $this->certificacionService->evaluarCompliance($edificioId);

            return response()->json([
                'success' => true,
                'data' => [
                    'edificio' => [
                        'id' => $edificio->id,
                        'nombre' => $edificio->nombre,
                    ],
                    'estado_actual' => [
                        'score_global' => $evaluacionActual['score_global'],
                        'nivel' => $evaluacionActual['nivel_cumplimiento'],
                        'puede_certificar' => $evaluacionActual['score_global'] >= 70,
                    ],
                    'ultimo_certificado_integral' => $ultimoCertificado ? [
                        'codigo' => $ultimoCertificado->codigo,
                        'score' => $ultimoCertificado->score_global,
                        'fecha' => $ultimoCertificado->created_at->format('Y-m-d'),
                        'vigente' => $ultimoCertificado->fecha_vencimiento >= now()->format('Y-m-d'),
                    ] : null,
                    'estadisticas' => [
                        'total_certificados' => $stats->total ?? 0,
                        'vigentes' => $stats->vigentes ?? 0,
                        'aprobados' => $stats->aprobados ?? 0,
                        'condicionales' => $stats->condicionales ?? 0,
                        'score_promedio' => round($stats->score_promedio ?? 0, 1),
                    ],
                    'alertas_vencimiento' => $porVencer->map(function ($cert) {
                        return [
                            'id' => $cert->id,
                            'codigo' => $cert->codigo,
                            'tipo' => $cert->tipo,
                            'vence_en_dias' => now()->diffInDays($cert->fecha_vencimiento),
                            'fecha_vencimiento' => $cert->fecha_vencimiento,
                        ];
                    }),
                    'modulos_evaluacion' => $evaluacionActual['modulos'] ?? [],
                ],
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al obtener resumen',
            ], 500);
        }
    }

    /**
     * Obtener tipos de certificado disponibles
     * 
     * GET /api/v1/compliance/tipos-certificado
     */
    public function tiposCertificado(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data' => [
                [
                    'codigo' => 'COMPLIANCE_INTEGRAL',
                    'nombre' => 'Certificado de Compliance Integral',
                    'descripcion' => 'Evaluación completa de todos los módulos de cumplimiento',
                    'validez_meses' => 12,
                    'modulos_evaluados' => ['gobernanza', 'financiero', 'tributario', 'proteccion_datos', 'operacional'],
                ],
                [
                    'codigo' => 'LEY_21442',
                    'nombre' => 'Certificado Ley 21.442',
                    'descripcion' => 'Cumplimiento de Ley de Copropiedad Inmobiliaria',
                    'validez_meses' => 12,
                    'modulos_evaluados' => ['gobernanza', 'operacional'],
                ],
                [
                    'codigo' => 'TRIBUTARIO',
                    'nombre' => 'Certificado Tributario',
                    'descripcion' => 'Cumplimiento de obligaciones tributarias F29, DJ 1887, distribuciones',
                    'validez_meses' => 6,
                    'modulos_evaluados' => ['tributario'],
                ],
                [
                    'codigo' => 'PROTECCION_DATOS',
                    'nombre' => 'Certificado Protección de Datos',
                    'descripcion' => 'Cumplimiento Ley 19.628 y preparación para nueva ley',
                    'validez_meses' => 12,
                    'modulos_evaluados' => ['proteccion_datos'],
                ],
                [
                    'codigo' => 'DISTRIBUCION_RENTAS',
                    'nombre' => 'Certificado Distribución de Rentas',
                    'descripcion' => 'Cumplimiento Art. 17 N°3 Ley Renta (arriendos antenas)',
                    'validez_meses' => 12,
                    'modulos_evaluados' => ['tributario'],
                ],
                [
                    'codigo' => 'NO_DEUDA',
                    'nombre' => 'Certificado de No Deuda',
                    'descripcion' => 'Certifica que copropietario está al día en gastos comunes',
                    'validez_meses' => 1,
                    'modulos_evaluados' => ['financiero'],
                ],
                [
                    'codigo' => 'RENTA_DISTRIBUIDA',
                    'nombre' => 'Certificado de Renta Distribuida',
                    'descripcion' => 'Certifica montos distribuidos a copropietario para declaración renta',
                    'validez_meses' => 12,
                    'modulos_evaluados' => ['tributario'],
                ],
            ],
        ]);
    }

    /**
     * Renovar certificado próximo a vencer
     * 
     * POST /api/v1/compliance/renovar/{id}
     */
    public function renovar(int $id): JsonResponse
    {
        try {
            $certificadoAnterior = CertificadoCompliance::findOrFail($id);
            $this->authorize('emitir-certificado', $certificadoAnterior->edificio);

            // Verificar que el certificado está por vencer o vencido
            $diasParaVencer = now()->diffInDays($certificadoAnterior->fecha_vencimiento, false);
            
            if ($diasParaVencer > 30) {
                return response()->json([
                    'success' => false,
                    'error' => 'El certificado aún tiene más de 30 días de vigencia',
                    'dias_restantes' => $diasParaVencer,
                ], 422);
            }

            // Emitir nuevo certificado del mismo tipo
            $resultado = $this->certificacionService->emitirCertificado(
                $certificadoAnterior->edificio_id,
                $certificadoAnterior->tipo
            );

            if ($resultado['estado'] === 'RECHAZADO') {
                return response()->json([
                    'success' => false,
                    'error' => 'No se puede renovar: no cumple requisitos actuales',
                    'data' => $resultado,
                ], 422);
            }

            Log::info('Certificado renovado', [
                'certificado_anterior' => $id,
                'certificado_nuevo' => $resultado['codigo_certificado'],
            ]);

            return response()->json([
                'success' => true,
                'data' => [
                    'certificado_anterior' => $certificadoAnterior->codigo,
                    'certificado_nuevo' => $resultado['codigo_certificado'],
                    'estado' => $resultado['estado'],
                    'fecha_vencimiento' => $resultado['fecha_vencimiento'],
                ],
                'mensaje' => 'Certificado renovado exitosamente',
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al renovar certificado',
            ], 500);
        }
    }
}
