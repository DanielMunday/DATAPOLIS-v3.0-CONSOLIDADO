<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - Contabilidad Controller
 */
class ContabilidadController extends Controller
{
    /**
     * Plan de cuentas
     */
    public function cuentas(Request $request): JsonResponse
    {
        $query = DB::table('cuentas_contables')
            ->where('tenant_id', Auth::user()->tenant_id)
            ->when($request->edificio_id, fn($q) => $q->where('edificio_id', $request->edificio_id))
            ->when($request->tipo, fn($q) => $q->where('tipo', $request->tipo))
            ->when($request->activa !== null, fn($q) => $q->where('activa', $request->boolean('activa')));

        $cuentas = $query->orderBy('codigo')->get();

        // Estructurar jerárquicamente
        $estructura = $this->estructurarCuentas($cuentas);

        return response()->json(['success' => true, 'data' => $estructura]);
    }

    /**
     * Crear cuenta contable
     */
    public function crearCuenta(Request $request): JsonResponse
    {
        $request->validate([
            'codigo' => 'required|string|max:20',
            'nombre' => 'required|string|max:200',
            'tipo' => 'required|in:activo,pasivo,patrimonio,ingreso,gasto',
            'edificio_id' => 'required|exists:edificios,id',
        ]);

        // Verificar código único
        $existe = DB::table('cuentas_contables')
            ->where('tenant_id', Auth::user()->tenant_id)
            ->where('edificio_id', $request->edificio_id)
            ->where('codigo', $request->codigo)
            ->exists();

        if ($existe) {
            return response()->json(['success' => false, 'message' => 'El código ya existe'], 422);
        }

        $nivel = substr_count($request->codigo, '.') + 1;

        $id = DB::table('cuentas_contables')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'codigo' => $request->codigo,
            'nombre' => $request->nombre,
            'tipo' => $request->tipo,
            'nivel' => $nivel,
            'cuenta_padre' => $request->cuenta_padre,
            'acepta_movimientos' => $request->acepta_movimientos ?? true,
            'activa' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Cuenta creada', 'id' => $id], 201);
    }

    /**
     * Actualizar cuenta
     */
    public function updateCuenta(int $id, Request $request): JsonResponse
    {
        $cuenta = DB::table('cuentas_contables')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$cuenta) {
            return response()->json(['success' => false, 'message' => 'Cuenta no encontrada'], 404);
        }

        DB::table('cuentas_contables')->where('id', $id)->update(array_merge(
            array_filter($request->only(['nombre', 'acepta_movimientos', 'activa']), fn($v) => $v !== null),
            ['updated_at' => now()]
        ));

        return response()->json(['success' => true, 'message' => 'Cuenta actualizada']);
    }

    /**
     * Listar asientos
     */
    public function asientos(Request $request): JsonResponse
    {
        $query = DB::table('asientos_contables')
            ->where('tenant_id', Auth::user()->tenant_id)
            ->when($request->edificio_id, fn($q) => $q->where('edificio_id', $request->edificio_id))
            ->when($request->fecha_desde, fn($q) => $q->where('fecha', '>=', $request->fecha_desde))
            ->when($request->fecha_hasta, fn($q) => $q->where('fecha', '<=', $request->fecha_hasta))
            ->when($request->estado, fn($q) => $q->where('estado', $request->estado));

        $asientos = $query->orderByDesc('fecha')->orderByDesc('numero')->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $asientos]);
    }

    /**
     * Crear asiento
     */
    public function crearAsiento(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'fecha' => 'required|date',
            'glosa' => 'required|string|max:500',
            'movimientos' => 'required|array|min:2',
            'movimientos.*.cuenta_id' => 'required|exists:cuentas_contables,id',
            'movimientos.*.debe' => 'required|numeric|min:0',
            'movimientos.*.haber' => 'required|numeric|min:0',
        ]);

        // Validar cuadratura
        $totalDebe = collect($request->movimientos)->sum('debe');
        $totalHaber = collect($request->movimientos)->sum('haber');

        if (abs($totalDebe - $totalHaber) > 0.01) {
            return response()->json([
                'success' => false,
                'message' => 'El asiento no cuadra. Debe: ' . number_format($totalDebe) . ', Haber: ' . number_format($totalHaber),
            ], 422);
        }

        // Generar número de asiento
        $ultimoNumero = DB::table('asientos_contables')
            ->where('edificio_id', $request->edificio_id)
            ->whereYear('fecha', Carbon::parse($request->fecha)->year)
            ->max('numero');

        $numero = ($ultimoNumero ?? 0) + 1;

        $asientoId = DB::table('asientos_contables')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'numero' => $numero,
            'fecha' => $request->fecha,
            'glosa' => $request->glosa,
            'tipo' => $request->tipo ?? 'manual',
            'total_debe' => $totalDebe,
            'total_haber' => $totalHaber,
            'estado' => 'borrador',
            'created_by' => Auth::id(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Insertar movimientos
        foreach ($request->movimientos as $mov) {
            DB::table('movimientos_contables')->insert([
                'asiento_id' => $asientoId,
                'cuenta_id' => $mov['cuenta_id'],
                'debe' => $mov['debe'],
                'haber' => $mov['haber'],
                'glosa' => $mov['glosa'] ?? null,
                'created_at' => now(),
            ]);
        }

        return response()->json(['success' => true, 'message' => 'Asiento creado', 'id' => $asientoId, 'numero' => $numero], 201);
    }

    /**
     * Mostrar asiento
     */
    public function showAsiento(int $id): JsonResponse
    {
        $asiento = DB::table('asientos_contables')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$asiento) {
            return response()->json(['success' => false, 'message' => 'Asiento no encontrado'], 404);
        }

        $asiento->movimientos = DB::table('movimientos_contables')
            ->join('cuentas_contables', 'movimientos_contables.cuenta_id', '=', 'cuentas_contables.id')
            ->where('movimientos_contables.asiento_id', $id)
            ->select('movimientos_contables.*', 'cuentas_contables.codigo', 'cuentas_contables.nombre as cuenta')
            ->get();

        return response()->json(['success' => true, 'data' => $asiento]);
    }

    /**
     * Anular asiento
     */
    public function anularAsiento(int $id): JsonResponse
    {
        $asiento = DB::table('asientos_contables')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$asiento) {
            return response()->json(['success' => false, 'message' => 'Asiento no encontrado'], 404);
        }

        if ($asiento->estado === 'anulado') {
            return response()->json(['success' => false, 'message' => 'El asiento ya está anulado'], 422);
        }

        DB::table('asientos_contables')->where('id', $id)->update([
            'estado' => 'anulado',
            'anulado_por' => Auth::id(),
            'anulado_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Asiento anulado']);
    }

    /**
     * Libro Mayor
     */
    public function libroMayor(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'cuenta_id' => 'required|exists:cuentas_contables,id',
            'fecha_desde' => 'required|date',
            'fecha_hasta' => 'required|date',
        ]);

        $cuenta = DB::table('cuentas_contables')->where('id', $request->cuenta_id)->first();

        // Saldo inicial
        $saldoInicial = DB::table('movimientos_contables')
            ->join('asientos_contables', 'movimientos_contables.asiento_id', '=', 'asientos_contables.id')
            ->where('asientos_contables.edificio_id', $request->edificio_id)
            ->where('asientos_contables.estado', '!=', 'anulado')
            ->where('movimientos_contables.cuenta_id', $request->cuenta_id)
            ->where('asientos_contables.fecha', '<', $request->fecha_desde)
            ->selectRaw('COALESCE(SUM(debe), 0) - COALESCE(SUM(haber), 0) as saldo')
            ->value('saldo') ?? 0;

        // Movimientos del período
        $movimientos = DB::table('movimientos_contables')
            ->join('asientos_contables', 'movimientos_contables.asiento_id', '=', 'asientos_contables.id')
            ->where('asientos_contables.edificio_id', $request->edificio_id)
            ->where('asientos_contables.estado', '!=', 'anulado')
            ->where('movimientos_contables.cuenta_id', $request->cuenta_id)
            ->whereBetween('asientos_contables.fecha', [$request->fecha_desde, $request->fecha_hasta])
            ->select(
                'asientos_contables.fecha',
                'asientos_contables.numero',
                'asientos_contables.glosa',
                'movimientos_contables.debe',
                'movimientos_contables.haber'
            )
            ->orderBy('asientos_contables.fecha')
            ->orderBy('asientos_contables.numero')
            ->get();

        // Calcular saldos acumulados
        $saldo = $saldoInicial;
        $movimientosConSaldo = $movimientos->map(function ($mov) use (&$saldo) {
            $saldo += $mov->debe - $mov->haber;
            $mov->saldo = $saldo;
            return $mov;
        });

        return response()->json([
            'success' => true,
            'data' => [
                'cuenta' => $cuenta,
                'saldo_inicial' => $saldoInicial,
                'movimientos' => $movimientosConSaldo,
                'saldo_final' => $saldo,
                'total_debe' => $movimientos->sum('debe'),
                'total_haber' => $movimientos->sum('haber'),
            ],
        ]);
    }

    /**
     * Libro Diario
     */
    public function libroDiario(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'fecha_desde' => 'required|date',
            'fecha_hasta' => 'required|date',
        ]);

        $asientos = DB::table('asientos_contables')
            ->where('edificio_id', $request->edificio_id)
            ->where('estado', '!=', 'anulado')
            ->whereBetween('fecha', [$request->fecha_desde, $request->fecha_hasta])
            ->orderBy('fecha')
            ->orderBy('numero')
            ->get();

        foreach ($asientos as $asiento) {
            $asiento->movimientos = DB::table('movimientos_contables')
                ->join('cuentas_contables', 'movimientos_contables.cuenta_id', '=', 'cuentas_contables.id')
                ->where('movimientos_contables.asiento_id', $asiento->id)
                ->select('cuentas_contables.codigo', 'cuentas_contables.nombre', 
                         'movimientos_contables.debe', 'movimientos_contables.haber')
                ->get();
        }

        return response()->json(['success' => true, 'data' => $asientos]);
    }

    /**
     * Balance General
     */
    public function balance(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'fecha' => 'required|date',
        ]);

        $tipos = ['activo', 'pasivo', 'patrimonio'];
        $balance = [];

        foreach ($tipos as $tipo) {
            $cuentas = DB::table('cuentas_contables')
                ->where('edificio_id', $request->edificio_id)
                ->where('tipo', $tipo)
                ->where('activa', true)
                ->orderBy('codigo')
                ->get();

            $cuentasConSaldo = $cuentas->map(function ($cuenta) use ($request) {
                $saldo = DB::table('movimientos_contables')
                    ->join('asientos_contables', 'movimientos_contables.asiento_id', '=', 'asientos_contables.id')
                    ->where('asientos_contables.edificio_id', $request->edificio_id)
                    ->where('asientos_contables.estado', '!=', 'anulado')
                    ->where('movimientos_contables.cuenta_id', $cuenta->id)
                    ->where('asientos_contables.fecha', '<=', $request->fecha)
                    ->selectRaw('COALESCE(SUM(debe), 0) - COALESCE(SUM(haber), 0) as saldo')
                    ->value('saldo') ?? 0;

                $cuenta->saldo = $tipo === 'activo' ? $saldo : -$saldo;
                return $cuenta;
            })->filter(fn($c) => abs($c->saldo) > 0);

            $balance[$tipo] = [
                'cuentas' => $cuentasConSaldo->values(),
                'total' => $cuentasConSaldo->sum('saldo'),
            ];
        }

        return response()->json([
            'success' => true,
            'data' => [
                'fecha' => $request->fecha,
                'balance' => $balance,
                'cuadra' => abs($balance['activo']['total'] - $balance['pasivo']['total'] - $balance['patrimonio']['total']) < 1,
            ],
        ]);
    }

    /**
     * Estado de Resultados
     */
    public function estadoResultados(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'fecha_desde' => 'required|date',
            'fecha_hasta' => 'required|date',
        ]);

        $ingresos = $this->obtenerCuentasConSaldo($request->edificio_id, 'ingreso', $request->fecha_desde, $request->fecha_hasta);
        $gastos = $this->obtenerCuentasConSaldo($request->edificio_id, 'gasto', $request->fecha_desde, $request->fecha_hasta);

        $totalIngresos = collect($ingresos)->sum('saldo');
        $totalGastos = collect($gastos)->sum('saldo');
        $resultado = $totalIngresos - $totalGastos;

        return response()->json([
            'success' => true,
            'data' => [
                'periodo' => ['desde' => $request->fecha_desde, 'hasta' => $request->fecha_hasta],
                'ingresos' => ['cuentas' => $ingresos, 'total' => $totalIngresos],
                'gastos' => ['cuentas' => $gastos, 'total' => $totalGastos],
                'resultado' => $resultado,
                'tipo_resultado' => $resultado >= 0 ? 'utilidad' : 'perdida',
            ],
        ]);
    }

    /**
     * Cierre mensual
     */
    public function cierreMensual(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
        ]);

        // Verificar que no exista cierre
        $existe = DB::table('cierres_contables')
            ->where('edificio_id', $request->edificio_id)
            ->where('mes', $request->mes)
            ->where('anio', $request->anio)
            ->exists();

        if ($existe) {
            return response()->json(['success' => false, 'message' => 'Ya existe un cierre para este período'], 422);
        }

        $fechaDesde = Carbon::create($request->anio, $request->mes, 1);
        $fechaHasta = $fechaDesde->copy()->endOfMonth();

        // Obtener totales
        $totales = DB::table('movimientos_contables')
            ->join('asientos_contables', 'movimientos_contables.asiento_id', '=', 'asientos_contables.id')
            ->where('asientos_contables.edificio_id', $request->edificio_id)
            ->where('asientos_contables.estado', '!=', 'anulado')
            ->whereBetween('asientos_contables.fecha', [$fechaDesde, $fechaHasta])
            ->selectRaw('SUM(debe) as total_debe, SUM(haber) as total_haber, COUNT(DISTINCT asiento_id) as asientos')
            ->first();

        $cierreId = DB::table('cierres_contables')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'mes' => $request->mes,
            'anio' => $request->anio,
            'fecha_cierre' => now(),
            'total_asientos' => $totales->asientos ?? 0,
            'total_debe' => $totales->total_debe ?? 0,
            'total_haber' => $totales->total_haber ?? 0,
            'cerrado_por' => Auth::id(),
            'created_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Cierre mensual realizado', 'id' => $cierreId]);
    }

    /**
     * Cierre anual
     */
    public function cierreAnual(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'anio' => 'required|integer|min:2020',
        ]);

        // Crear asiento de cierre de resultados
        $fechaDesde = Carbon::create($request->anio, 1, 1);
        $fechaHasta = Carbon::create($request->anio, 12, 31);

        $ingresos = $this->obtenerCuentasConSaldo($request->edificio_id, 'ingreso', $fechaDesde, $fechaHasta);
        $gastos = $this->obtenerCuentasConSaldo($request->edificio_id, 'gasto', $fechaDesde, $fechaHasta);

        $totalIngresos = collect($ingresos)->sum('saldo');
        $totalGastos = collect($gastos)->sum('saldo');
        $resultado = $totalIngresos - $totalGastos;

        return response()->json([
            'success' => true,
            'data' => [
                'anio' => $request->anio,
                'resultado' => $resultado,
                'mensaje' => 'Cierre anual preparado. Revise el resultado antes de confirmar.',
            ],
        ]);
    }

    /**
     * Estructurar cuentas jerárquicamente
     */
    private function estructurarCuentas($cuentas): array
    {
        return $cuentas->groupBy('tipo')->map(fn($grupo) => $grupo->values())->toArray();
    }

    /**
     * Obtener cuentas con saldo para un período
     */
    private function obtenerCuentasConSaldo(int $edificioId, string $tipo, $fechaDesde, $fechaHasta): array
    {
        $cuentas = DB::table('cuentas_contables')
            ->where('edificio_id', $edificioId)
            ->where('tipo', $tipo)
            ->where('activa', true)
            ->orderBy('codigo')
            ->get();

        return $cuentas->map(function ($cuenta) use ($edificioId, $fechaDesde, $fechaHasta, $tipo) {
            $saldo = DB::table('movimientos_contables')
                ->join('asientos_contables', 'movimientos_contables.asiento_id', '=', 'asientos_contables.id')
                ->where('asientos_contables.edificio_id', $edificioId)
                ->where('asientos_contables.estado', '!=', 'anulado')
                ->where('movimientos_contables.cuenta_id', $cuenta->id)
                ->whereBetween('asientos_contables.fecha', [$fechaDesde, $fechaHasta])
                ->selectRaw('COALESCE(SUM(haber), 0) - COALESCE(SUM(debe), 0) as saldo')
                ->value('saldo') ?? 0;

            $cuenta->saldo = $tipo === 'ingreso' ? $saldo : -$saldo;
            return $cuenta;
        })->filter(fn($c) => abs($c->saldo) > 0)->values()->toArray();
    }
}
