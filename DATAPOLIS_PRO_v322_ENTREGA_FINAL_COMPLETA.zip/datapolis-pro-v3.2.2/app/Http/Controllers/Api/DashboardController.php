<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

/**
 * DATAPOLIS PRO v3.0 - Dashboard Controller
 */
class DashboardController extends Controller
{
    /**
     * Estadísticas generales
     */
    public function stats(Request $request): JsonResponse
    {
        $tenantId = Auth::user()->tenant_id;
        $edificioId = $request->get('edificio_id');

        $stats = [
            'total_unidades' => DB::table('unidades')
                ->where('tenant_id', $tenantId)
                ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
                ->count(),

            'recaudacion_mes' => DB::table('pagos_gc')
                ->join('boletas_gc', 'pagos_gc.boleta_id', '=', 'boletas_gc.id')
                ->where('boletas_gc.tenant_id', $tenantId)
                ->when($edificioId, fn($q) => $q->where('boletas_gc.edificio_id', $edificioId))
                ->whereMonth('pagos_gc.fecha_pago', now()->month)
                ->whereYear('pagos_gc.fecha_pago', now()->year)
                ->sum('pagos_gc.monto'),

            'morosidad_total' => DB::table('boletas_gc')
                ->where('tenant_id', $tenantId)
                ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
                ->whereIn('estado', ['pendiente', 'vencida'])
                ->sum(DB::raw('total_a_pagar - COALESCE(total_abonos, 0)')),

            'contratos_activos' => DB::table('contratos_arriendo')
                ->where('tenant_id', $tenantId)
                ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
                ->where('estado', 'activo')
                ->count(),

            'empleados_activos' => DB::table('empleados')
                ->where('tenant_id', $tenantId)
                ->where('estado', 'activo')
                ->count(),

            'reuniones_programadas' => DB::table('reuniones')
                ->where('tenant_id', $tenantId)
                ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
                ->where('fecha_inicio', '>', now())
                ->whereIn('estado', ['programada', 'convocada'])
                ->count(),
        ];

        return response()->json(['success' => true, 'data' => $stats]);
    }

    /**
     * Reporte de morosidad
     */
    public function morosidad(Request $request): JsonResponse
    {
        $tenantId = Auth::user()->tenant_id;
        $edificioId = $request->get('edificio_id');

        $morosos = DB::table('boletas_gc')
            ->join('unidades', 'boletas_gc.unidad_id', '=', 'unidades.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->leftJoin('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->where('boletas_gc.tenant_id', $tenantId)
            ->when($edificioId, fn($q) => $q->where('boletas_gc.edificio_id', $edificioId))
            ->whereIn('boletas_gc.estado', ['pendiente', 'vencida'])
            ->select(
                'unidades.id',
                'unidades.numero',
                'personas.nombre_completo as propietario',
                'edificios.nombre as edificio',
                DB::raw('SUM(boletas_gc.total_a_pagar - COALESCE(boletas_gc.total_abonos, 0)) as deuda'),
                DB::raw('MAX(boletas_gc.dias_mora) as dias_mora'),
                DB::raw('COUNT(boletas_gc.id) as boletas_pendientes')
            )
            ->groupBy('unidades.id', 'unidades.numero', 'personas.nombre_completo', 'edificios.nombre')
            ->havingRaw('SUM(boletas_gc.total_a_pagar - COALESCE(boletas_gc.total_abonos, 0)) > 0')
            ->orderByDesc('deuda')
            ->limit(50)
            ->get();

        return response()->json(['success' => true, 'data' => $morosos]);
    }

    /**
     * Ingresos por período
     */
    public function ingresos(Request $request): JsonResponse
    {
        $tenantId = Auth::user()->tenant_id;
        $meses = min($request->get('meses', 12), 24);
        $edificioId = $request->get('edificio_id');

        $ingresos = collect();
        for ($i = $meses - 1; $i >= 0; $i--) {
            $fecha = now()->subMonths($i);

            $gc = DB::table('pagos_gc')
                ->join('boletas_gc', 'pagos_gc.boleta_id', '=', 'boletas_gc.id')
                ->where('boletas_gc.tenant_id', $tenantId)
                ->when($edificioId, fn($q) => $q->where('boletas_gc.edificio_id', $edificioId))
                ->whereMonth('pagos_gc.fecha_pago', $fecha->month)
                ->whereYear('pagos_gc.fecha_pago', $fecha->year)
                ->sum('pagos_gc.monto');

            $arriendos = DB::table('facturas_arriendo')
                ->where('tenant_id', $tenantId)
                ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
                ->whereMonth('fecha_pago', $fecha->month)
                ->whereYear('fecha_pago', $fecha->year)
                ->where('estado', 'pagada')
                ->sum('monto_total');

            $ingresos->push([
                'mes' => $fecha->format('Y-m'),
                'nombre' => $fecha->locale('es')->monthName,
                'gastos_comunes' => (float) $gc,
                'arriendos' => (float) $arriendos,
                'total' => (float) ($gc + $arriendos),
            ]);
        }

        return response()->json(['success' => true, 'data' => $ingresos]);
    }

    /**
     * Alertas del sistema
     */
    public function alertas(Request $request): JsonResponse
    {
        $tenantId = Auth::user()->tenant_id;
        $edificioId = $request->get('edificio_id');
        $alertas = [];

        // Boletas vencidas con más de 30 días
        $vencidas = DB::table('boletas_gc')
            ->where('tenant_id', $tenantId)
            ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
            ->where('estado', 'vencida')
            ->where('dias_mora', '>', 30)
            ->count();

        if ($vencidas > 0) {
            $alertas[] = [
                'tipo' => 'error',
                'icono' => 'alert-circle',
                'titulo' => 'Morosidad crítica',
                'mensaje' => "{$vencidas} boletas con más de 30 días de mora",
                'accion' => '/gastos-comunes/morosidad',
            ];
        }

        // Contratos por vencer en 60 días
        $contratosPorVencer = DB::table('contratos_arriendo')
            ->where('tenant_id', $tenantId)
            ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
            ->where('estado', 'activo')
            ->whereBetween('fecha_termino', [now(), now()->addDays(60)])
            ->count();

        if ($contratosPorVencer > 0) {
            $alertas[] = [
                'tipo' => 'warning',
                'icono' => 'calendar',
                'titulo' => 'Contratos por vencer',
                'mensaje' => "{$contratosPorVencer} contratos vencen en los próximos 60 días",
                'accion' => '/arriendos/contratos',
            ];
        }

        // Reuniones programadas
        $reunionesProximas = DB::table('reuniones')
            ->where('tenant_id', $tenantId)
            ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
            ->whereBetween('fecha_inicio', [now(), now()->addDays(7)])
            ->whereIn('estado', ['convocada', 'programada'])
            ->count();

        if ($reunionesProximas > 0) {
            $alertas[] = [
                'tipo' => 'info',
                'icono' => 'users',
                'titulo' => 'Reuniones próximas',
                'mensaje' => "{$reunionesProximas} reuniones programadas esta semana",
                'accion' => '/reuniones',
            ];
        }

        // Documentos por vencer
        $documentosPorVencer = DB::table('documentos_legales')
            ->where('tenant_id', $tenantId)
            ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
            ->whereBetween('fecha_vencimiento', [now(), now()->addDays(30)])
            ->count();

        if ($documentosPorVencer > 0) {
            $alertas[] = [
                'tipo' => 'warning',
                'icono' => 'file-text',
                'titulo' => 'Documentos por vencer',
                'mensaje' => "{$documentosPorVencer} documentos vencen en 30 días",
                'accion' => '/documentos',
            ];
        }

        return response()->json(['success' => true, 'data' => $alertas]);
    }
}
