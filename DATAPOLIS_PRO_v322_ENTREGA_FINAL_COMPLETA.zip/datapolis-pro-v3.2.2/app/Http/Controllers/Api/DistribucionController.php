<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - Distribución Controller
 * Distribución de ingresos según Ley 21.713 (Art. 17 N°3)
 */
class DistribucionController extends Controller
{
    /**
     * Dashboard de distribución
     */
    public function index(Request $request): JsonResponse
    {
        $tenantId = Auth::user()->tenant_id;
        $anio = $request->get('anio', now()->year);

        $resumen = [
            'ingresos_totales' => DB::table('facturas_arriendo')
                ->where('tenant_id', $tenantId)
                ->where('periodo_anio', $anio)
                ->where('estado', 'pagada')
                ->sum('monto_total'),

            'distribuido' => DB::table('distribucion_ingresos')
                ->where('tenant_id', $tenantId)
                ->where('anio', $anio)
                ->where('estado', 'aprobado')
                ->sum('monto_total_distribuido'),

            'contratos_activos' => DB::table('contratos_arriendo')
                ->where('tenant_id', $tenantId)
                ->where('estado', 'activo')
                ->count(),

            'unidades_beneficiarias' => DB::table('unidades')
                ->where('tenant_id', $tenantId)
                ->where('activa', true)
                ->count(),
        ];

        $distribucionesPendientes = DB::table('distribucion_ingresos')
            ->where('tenant_id', $tenantId)
            ->where('estado', 'borrador')
            ->orderByDesc('anio')
            ->orderByDesc('mes')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'resumen' => $resumen,
                'pendientes' => $distribucionesPendientes,
                'anio' => $anio,
            ],
        ]);
    }

    /**
     * Calcular distribución para un período
     */
    public function calcular(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
        ]);

        $tenantId = Auth::user()->tenant_id;
        $edificioId = $request->edificio_id;
        $mes = $request->mes;
        $anio = $request->anio;

        // Verificar que no exista distribución
        $existe = DB::table('distribucion_ingresos')
            ->where('edificio_id', $edificioId)
            ->where('mes', $mes)
            ->where('anio', $anio)
            ->exists();

        if ($existe) {
            return response()->json([
                'success' => false,
                'message' => 'Ya existe una distribución para este período',
            ], 422);
        }

        // Obtener ingresos del período
        $ingresos = DB::table('facturas_arriendo')
            ->join('contratos_arriendo', 'facturas_arriendo.contrato_id', '=', 'contratos_arriendo.id')
            ->where('contratos_arriendo.edificio_id', $edificioId)
            ->where('facturas_arriendo.periodo_mes', $mes)
            ->where('facturas_arriendo.periodo_anio', $anio)
            ->where('facturas_arriendo.estado', 'pagada')
            ->sum('facturas_arriendo.monto_total');

        if ($ingresos <= 0) {
            return response()->json([
                'success' => false,
                'message' => 'No hay ingresos pagados para distribuir en este período',
            ], 422);
        }

        // Obtener unidades activas con sus prorrateos
        $unidades = DB::table('unidades')
            ->where('edificio_id', $edificioId)
            ->where('activa', true)
            ->whereNull('deleted_at')
            ->get();

        $totalProrrateo = $unidades->sum('prorrateo');

        if ($totalProrrateo <= 0) {
            return response()->json([
                'success' => false,
                'message' => 'Las unidades no tienen prorrateo configurado',
            ], 422);
        }

        // Crear distribución
        $distribucionId = DB::table('distribucion_ingresos')->insertGetId([
            'tenant_id' => $tenantId,
            'edificio_id' => $edificioId,
            'mes' => $mes,
            'anio' => $anio,
            'monto_total_ingresos' => $ingresos,
            'monto_total_distribuido' => $ingresos,
            'total_unidades' => $unidades->count(),
            'estado' => 'borrador',
            'created_by' => Auth::id(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Crear detalle por unidad
        foreach ($unidades as $unidad) {
            $porcentaje = $unidad->prorrateo / $totalProrrateo * 100;
            $monto = round($ingresos * ($porcentaje / 100), 0);

            DB::table('distribucion_detalle')->insert([
                'distribucion_id' => $distribucionId,
                'unidad_id' => $unidad->id,
                'prorrateo_aplicado' => $unidad->prorrateo,
                'porcentaje_distribucion' => round($porcentaje, 4),
                'monto_distribuido' => $monto,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Distribución calculada exitosamente',
            'data' => [
                'id' => $distribucionId,
                'monto_total' => $ingresos,
                'unidades' => $unidades->count(),
            ],
        ], 201);
    }

    /**
     * Listar períodos de distribución
     */
    public function periodos(Request $request): JsonResponse
    {
        $periodos = DB::table('distribucion_ingresos')
            ->join('edificios', 'distribucion_ingresos.edificio_id', '=', 'edificios.id')
            ->where('distribucion_ingresos.tenant_id', Auth::user()->tenant_id)
            ->when($request->edificio_id, fn($q) => $q->where('distribucion_ingresos.edificio_id', $request->edificio_id))
            ->when($request->anio, fn($q) => $q->where('distribucion_ingresos.anio', $request->anio))
            ->select('distribucion_ingresos.*', 'edificios.nombre as edificio')
            ->orderByDesc('anio')
            ->orderByDesc('mes')
            ->paginate(24);

        return response()->json(['success' => true, 'data' => $periodos]);
    }

    /**
     * Mostrar distribución con detalle
     */
    public function showPeriodo(int $id): JsonResponse
    {
        $distribucion = DB::table('distribucion_ingresos')
            ->join('edificios', 'distribucion_ingresos.edificio_id', '=', 'edificios.id')
            ->where('distribucion_ingresos.id', $id)
            ->where('distribucion_ingresos.tenant_id', Auth::user()->tenant_id)
            ->select('distribucion_ingresos.*', 'edificios.nombre as edificio')
            ->first();

        if (!$distribucion) {
            return response()->json(['success' => false, 'message' => 'Distribución no encontrada'], 404);
        }

        $detalle = DB::table('distribucion_detalle')
            ->join('unidades', 'distribucion_detalle.unidad_id', '=', 'unidades.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('distribucion_detalle.distribucion_id', $id)
            ->select(
                'distribucion_detalle.*',
                'unidades.numero',
                'unidades.tipo',
                'personas.nombre_completo as propietario',
                'personas.rut as propietario_rut'
            )
            ->orderByRaw("CAST(REGEXP_REPLACE(unidades.numero, '[^0-9]', '') AS UNSIGNED)")
            ->get();

        $distribucion->detalle = $detalle;

        return response()->json(['success' => true, 'data' => $distribucion]);
    }

    /**
     * Aprobar distribución
     */
    public function aprobarPeriodo(int $id): JsonResponse
    {
        $distribucion = DB::table('distribucion_ingresos')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$distribucion) {
            return response()->json(['success' => false, 'message' => 'Distribución no encontrada'], 404);
        }

        if ($distribucion->estado !== 'borrador') {
            return response()->json(['success' => false, 'message' => 'La distribución ya fue procesada'], 422);
        }

        DB::table('distribucion_ingresos')->where('id', $id)->update([
            'estado' => 'aprobado',
            'aprobado_por' => Auth::id(),
            'aprobado_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Distribución aprobada']);
    }

    /**
     * Certificado de distribución por unidad
     */
    public function certificadoUnidad(int $unidadId, Request $request): JsonResponse
    {
        $anio = $request->get('anio', now()->year);

        $unidad = DB::table('unidades')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('unidades.id', $unidadId)
            ->where('unidades.tenant_id', Auth::user()->tenant_id)
            ->select(
                'unidades.*',
                'edificios.nombre as edificio',
                'edificios.rut as edificio_rut',
                'edificios.direccion as edificio_direccion',
                'personas.nombre_completo as propietario',
                'personas.rut as propietario_rut'
            )
            ->first();

        if (!$unidad) {
            return response()->json(['success' => false, 'message' => 'Unidad no encontrada'], 404);
        }

        // Obtener distribuciones del año
        $distribuciones = DB::table('distribucion_detalle')
            ->join('distribucion_ingresos', 'distribucion_detalle.distribucion_id', '=', 'distribucion_ingresos.id')
            ->where('distribucion_detalle.unidad_id', $unidadId)
            ->where('distribucion_ingresos.anio', $anio)
            ->where('distribucion_ingresos.estado', 'aprobado')
            ->select(
                'distribucion_detalle.*',
                'distribucion_ingresos.mes',
                'distribucion_ingresos.anio'
            )
            ->orderBy('distribucion_ingresos.mes')
            ->get();

        $certificado = [
            'unidad' => $unidad,
            'anio' => $anio,
            'distribuciones' => $distribuciones,
            'total_anual' => $distribuciones->sum('monto_distribuido'),
            'fecha_emision' => now()->format('Y-m-d'),
        ];

        return response()->json(['success' => true, 'data' => $certificado]);
    }

    /**
     * Generar PDF de certificado
     */
    public function certificadoPdf(int $unidadId, Request $request)
    {
        $anio = $request->get('anio', now()->year);

        $unidad = DB::table('unidades')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('unidades.id', $unidadId)
            ->select(
                'unidades.*',
                'edificios.nombre as edificio',
                'edificios.rut as edificio_rut',
                'edificios.direccion as edificio_direccion',
                'personas.nombre_completo as propietario',
                'personas.rut as propietario_rut'
            )
            ->first();

        if (!$unidad) {
            return response()->json(['success' => false, 'message' => 'Unidad no encontrada'], 404);
        }

        $distribuciones = DB::table('distribucion_detalle')
            ->join('distribucion_ingresos', 'distribucion_detalle.distribucion_id', '=', 'distribucion_ingresos.id')
            ->where('distribucion_detalle.unidad_id', $unidadId)
            ->where('distribucion_ingresos.anio', $anio)
            ->where('distribucion_ingresos.estado', 'aprobado')
            ->select('distribucion_detalle.*', 'distribucion_ingresos.mes')
            ->orderBy('distribucion_ingresos.mes')
            ->get();

        $totalAnual = $distribuciones->sum('monto_distribuido');

        $pdf = Pdf::loadView('pdf.certificado-distribucion', compact('unidad', 'distribuciones', 'anio', 'totalAnual'));
        return $pdf->download("certificado-distribucion-{$unidad->numero}-{$anio}.pdf");
    }
}
