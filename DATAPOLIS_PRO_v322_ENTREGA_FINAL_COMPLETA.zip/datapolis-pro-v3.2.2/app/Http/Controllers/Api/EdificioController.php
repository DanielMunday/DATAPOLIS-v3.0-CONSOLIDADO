<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

/**
 * DATAPOLIS PRO v3.0 - Edificio Controller
 */
class EdificioController extends Controller
{
    /**
     * Listar edificios
     */
    public function index(Request $request): JsonResponse
    {
        $query = DB::table('edificios')
            ->where('tenant_id', Auth::user()->tenant_id)
            ->whereNull('deleted_at');

        if ($request->has('activo')) {
            $query->where('activo', $request->boolean('activo'));
        }

        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('nombre', 'like', "%{$request->search}%")
                  ->orWhere('direccion', 'like', "%{$request->search}%")
                  ->orWhere('rut', 'like', "%{$request->search}%");
            });
        }

        $edificios = $query->orderBy('nombre')->get();

        return response()->json(['success' => true, 'data' => $edificios]);
    }

    /**
     * Crear edificio
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'nombre' => 'required|string|max:200',
            'direccion' => 'required|string|max:300',
            'comuna' => 'required|string|max:100',
            'rut' => 'required|string|max:12|unique:edificios,rut',
            'tipo' => 'required|in:condominio,comunidad,edificio,conjunto',
            'total_unidades' => 'required|integer|min:1',
        ]);

        $id = DB::table('edificios')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'nombre' => $request->nombre,
            'direccion' => $request->direccion,
            'comuna' => $request->comuna,
            'region' => $request->region ?? 'Metropolitana',
            'rut' => $request->rut,
            'rol_avaluo' => $request->rol_avaluo,
            'tipo' => $request->tipo,
            'total_unidades' => $request->total_unidades,
            'activo' => true,
            'administrador_nombre' => $request->administrador_nombre,
            'administrador_rut' => $request->administrador_rut,
            'administrador_email' => $request->administrador_email,
            'administrador_telefono' => $request->administrador_telefono,
            'dia_vencimiento_gc' => $request->dia_vencimiento_gc ?? 10,
            'interes_mora' => $request->interes_mora ?? 3.0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Edificio creado exitosamente',
            'id' => $id,
        ], 201);
    }

    /**
     * Mostrar edificio
     */
    public function show(int $id): JsonResponse
    {
        $edificio = DB::table('edificios')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->whereNull('deleted_at')
            ->first();

        if (!$edificio) {
            return response()->json(['success' => false, 'message' => 'Edificio no encontrado'], 404);
        }

        // Agregar estadísticas
        $edificio->stats = [
            'total_unidades' => DB::table('unidades')->where('edificio_id', $id)->whereNull('deleted_at')->count(),
            'unidades_ocupadas' => DB::table('unidades')->where('edificio_id', $id)->whereNotNull('propietario_id')->count(),
            'morosidad_total' => DB::table('boletas_gc')
                ->where('edificio_id', $id)
                ->whereIn('estado', ['pendiente', 'vencida'])
                ->sum(DB::raw('total_a_pagar - COALESCE(total_abonos, 0)')),
            'contratos_activos' => DB::table('contratos_arriendo')
                ->where('edificio_id', $id)
                ->where('estado', 'activo')
                ->count(),
        ];

        return response()->json(['success' => true, 'data' => $edificio]);
    }

    /**
     * Actualizar edificio
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $edificio = DB::table('edificios')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$edificio) {
            return response()->json(['success' => false, 'message' => 'Edificio no encontrado'], 404);
        }

        $request->validate([
            'nombre' => 'sometimes|string|max:200',
            'direccion' => 'sometimes|string|max:300',
            'comuna' => 'sometimes|string|max:100',
            'interes_mora' => 'sometimes|numeric|min:0|max:3',
        ]);

        DB::table('edificios')->where('id', $id)->update(array_merge(
            $request->only([
                'nombre', 'direccion', 'comuna', 'region', 'rol_avaluo',
                'administrador_nombre', 'administrador_rut', 'administrador_email',
                'administrador_telefono', 'dia_vencimiento_gc', 'interes_mora', 'activo',
            ]),
            ['updated_at' => now()]
        ));

        return response()->json(['success' => true, 'message' => 'Edificio actualizado']);
    }

    /**
     * Eliminar edificio (soft delete)
     */
    public function destroy(int $id): JsonResponse
    {
        $edificio = DB::table('edificios')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$edificio) {
            return response()->json(['success' => false, 'message' => 'Edificio no encontrado'], 404);
        }

        // Verificar que no tenga unidades activas
        $unidadesActivas = DB::table('unidades')
            ->where('edificio_id', $id)
            ->whereNull('deleted_at')
            ->count();

        if ($unidadesActivas > 0) {
            return response()->json([
                'success' => false,
                'message' => "No se puede eliminar: tiene {$unidadesActivas} unidades asociadas",
            ], 422);
        }

        DB::table('edificios')->where('id', $id)->update([
            'deleted_at' => now(),
            'activo' => false,
        ]);

        return response()->json(['success' => true, 'message' => 'Edificio eliminado']);
    }

    /**
     * Listar unidades del edificio
     */
    public function unidades(int $edificioId): JsonResponse
    {
        $unidades = DB::table('unidades')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('unidades.edificio_id', $edificioId)
            ->whereNull('unidades.deleted_at')
            ->select(
                'unidades.*',
                'personas.nombre_completo as propietario_nombre',
                'personas.rut as propietario_rut',
                'personas.email as propietario_email'
            )
            ->orderByRaw("CAST(REGEXP_REPLACE(unidades.numero, '[^0-9]', '') AS UNSIGNED)")
            ->orderBy('unidades.numero')
            ->get();

        return response()->json(['success' => true, 'data' => $unidades]);
    }

    /**
     * Estadísticas del edificio
     */
    public function estadisticas(int $edificioId): JsonResponse
    {
        $edificio = DB::table('edificios')
            ->where('id', $edificioId)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$edificio) {
            return response()->json(['success' => false, 'message' => 'Edificio no encontrado'], 404);
        }

        $stats = [
            'general' => [
                'total_unidades' => DB::table('unidades')->where('edificio_id', $edificioId)->count(),
                'total_propietarios' => DB::table('unidades')
                    ->where('edificio_id', $edificioId)
                    ->whereNotNull('propietario_id')
                    ->distinct('propietario_id')
                    ->count('propietario_id'),
            ],
            'financiero' => [
                'morosidad_total' => DB::table('boletas_gc')
                    ->where('edificio_id', $edificioId)
                    ->whereIn('estado', ['pendiente', 'vencida'])
                    ->sum(DB::raw('total_a_pagar - COALESCE(total_abonos, 0)')),
                'recaudacion_mes' => DB::table('pagos_gc')
                    ->join('boletas_gc', 'pagos_gc.boleta_id', '=', 'boletas_gc.id')
                    ->where('boletas_gc.edificio_id', $edificioId)
                    ->whereMonth('pagos_gc.fecha_pago', now()->month)
                    ->whereYear('pagos_gc.fecha_pago', now()->year)
                    ->sum('pagos_gc.monto'),
                'boletas_pendientes' => DB::table('boletas_gc')
                    ->where('edificio_id', $edificioId)
                    ->whereIn('estado', ['pendiente', 'vencida'])
                    ->count(),
            ],
            'contratos' => [
                'activos' => DB::table('contratos_arriendo')
                    ->where('edificio_id', $edificioId)
                    ->where('estado', 'activo')
                    ->count(),
                'por_vencer' => DB::table('contratos_arriendo')
                    ->where('edificio_id', $edificioId)
                    ->where('estado', 'activo')
                    ->whereBetween('fecha_termino', [now(), now()->addDays(90)])
                    ->count(),
            ],
        ];

        return response()->json(['success' => true, 'data' => $stats]);
    }
}
