<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.1 - Controlador de Espacios Arrendables
 * 
 * Gestiona:
 * - Categorías y tipos de espacios
 * - Espacios arrendables (estacionamientos, publicidad, locales, etc.)
 * - Reservas de espacios
 * - Contratos de concesión
 */
class EspaciosArrendablesController extends Controller
{
    // =========================================================================
    // CATEGORÍAS Y TIPOS
    // =========================================================================

    /**
     * Listar categorías de arriendo
     */
    public function listarCategorias(): JsonResponse
    {
        $categorias = DB::table('categorias_arriendo')
            ->where('activa', true)
            ->orderBy('orden')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $categorias
        ]);
    }

    /**
     * Listar tipos de espacio por categoría
     */
    public function listarTiposEspacio(Request $request): JsonResponse
    {
        $query = DB::table('tipos_espacio_arriendo')
            ->join('categorias_arriendo', 'tipos_espacio_arriendo.categoria_id', '=', 'categorias_arriendo.id')
            ->where('tipos_espacio_arriendo.activo', true);

        if ($request->categoria_id) {
            $query->where('tipos_espacio_arriendo.categoria_id', $request->categoria_id);
        }

        if ($request->categoria_codigo) {
            $query->where('categorias_arriendo.codigo', $request->categoria_codigo);
        }

        $tipos = $query->select(
            'tipos_espacio_arriendo.*',
            'categorias_arriendo.nombre as categoria_nombre',
            'categorias_arriendo.codigo as categoria_codigo'
        )->orderBy('categorias_arriendo.orden')
         ->orderBy('tipos_espacio_arriendo.nombre')
         ->get();

        return response()->json([
            'success' => true,
            'data' => $tipos
        ]);
    }

    // =========================================================================
    // ESPACIOS ARRENDABLES
    // =========================================================================

    /**
     * Listar espacios de un edificio
     */
    public function listarEspacios(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id'
        ]);

        $query = DB::table('espacios_arrendables')
            ->join('tipos_espacio_arriendo', 'espacios_arrendables.tipo_espacio_id', '=', 'tipos_espacio_arriendo.id')
            ->join('categorias_arriendo', 'tipos_espacio_arriendo.categoria_id', '=', 'categorias_arriendo.id')
            ->where('espacios_arrendables.edificio_id', $request->edificio_id)
            ->where('espacios_arrendables.activo', true)
            ->whereNull('espacios_arrendables.deleted_at');

        if ($request->categoria_id) {
            $query->where('categorias_arriendo.id', $request->categoria_id);
        }

        if ($request->estado) {
            $query->where('espacios_arrendables.estado', $request->estado);
        }

        if ($request->tipo_espacio_id) {
            $query->where('espacios_arrendables.tipo_espacio_id', $request->tipo_espacio_id);
        }

        $espacios = $query->select(
            'espacios_arrendables.*',
            'tipos_espacio_arriendo.nombre as tipo_nombre',
            'tipos_espacio_arriendo.codigo as tipo_codigo',
            'tipos_espacio_arriendo.unidad_medida',
            'tipos_espacio_arriendo.permite_reserva',
            'categorias_arriendo.nombre as categoria_nombre',
            'categorias_arriendo.codigo as categoria_codigo',
            'categorias_arriendo.color as categoria_color',
            'categorias_arriendo.icono as categoria_icono'
        )
        ->orderBy('categorias_arriendo.orden')
        ->orderBy('espacios_arrendables.codigo')
        ->get();

        // Agregar información de contrato activo si existe
        foreach ($espacios as $espacio) {
            $contratoActivo = DB::table('contratos_arriendo')
                ->where('espacio_id', $espacio->id)
                ->where('estado', 'vigente')
                ->where('fecha_inicio', '<=', now())
                ->where('fecha_termino', '>=', now())
                ->first();

            $espacio->contrato_activo = $contratoActivo ? [
                'id' => $contratoActivo->id,
                'arrendatario' => DB::table('arrendatarios')->find($contratoActivo->arrendatario_id)?->nombre ?? 'N/A',
                'fecha_termino' => $contratoActivo->fecha_termino,
                'monto_mensual' => $contratoActivo->monto_mensual,
            ] : null;
        }

        // Estadísticas
        $stats = [
            'total' => $espacios->count(),
            'disponibles' => $espacios->where('estado', 'disponible')->count(),
            'arrendados' => $espacios->where('estado', 'arrendado')->count(),
            'mantencion' => $espacios->where('estado', 'mantencion')->count(),
        ];

        return response()->json([
            'success' => true,
            'data' => $espacios,
            'stats' => $stats
        ]);
    }

    /**
     * Crear espacio arrendable
     */
    public function crearEspacio(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'tipo_espacio_id' => 'required|exists:tipos_espacio_arriendo,id',
            'codigo' => 'required|string|max:50',
            'nombre' => 'required|string|max:100',
        ]);

        // Verificar código único en el edificio
        $existe = DB::table('espacios_arrendables')
            ->where('edificio_id', $request->edificio_id)
            ->where('codigo', $request->codigo)
            ->whereNull('deleted_at')
            ->exists();

        if ($existe) {
            return response()->json([
                'success' => false,
                'message' => 'Ya existe un espacio con ese código en este edificio'
            ], 422);
        }

        $id = DB::table('espacios_arrendables')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'tipo_espacio_id' => $request->tipo_espacio_id,
            'codigo' => $request->codigo,
            'nombre' => $request->nombre,
            'descripcion' => $request->descripcion,
            'ubicacion' => $request->ubicacion,
            'superficie_m2' => $request->superficie_m2,
            'altura_m' => $request->altura_m,
            'capacidad_personas' => $request->capacidad_personas,
            'numero_estacionamiento' => $request->numero_estacionamiento,
            'tipo_vehiculo' => $request->tipo_vehiculo,
            'tiene_techo' => $request->tiene_techo,
            'dimension_ancho_m' => $request->dimension_ancho_m,
            'dimension_alto_m' => $request->dimension_alto_m,
            'orientacion' => $request->orientacion,
            'iluminado' => $request->iluminado,
            'amenidades' => $request->amenidades ? json_encode($request->amenidades) : null,
            'equipamiento' => $request->equipamiento ? json_encode($request->equipamiento) : null,
            'estado' => 'disponible',
            'precio_base' => $request->precio_base,
            'periodo_precio' => $request->periodo_precio ?? 'mes',
            'precio_copropietario' => $request->precio_copropietario,
            'garantia_requerida' => $request->garantia_requerida,
            'activo' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Espacio creado exitosamente',
            'id' => $id
        ], 201);
    }

    /**
     * Actualizar espacio
     */
    public function actualizarEspacio(Request $request, int $id): JsonResponse
    {
        $espacio = DB::table('espacios_arrendables')->find($id);

        if (!$espacio) {
            return response()->json(['success' => false, 'message' => 'Espacio no encontrado'], 404);
        }

        $datos = array_filter([
            'nombre' => $request->nombre,
            'descripcion' => $request->descripcion,
            'ubicacion' => $request->ubicacion,
            'superficie_m2' => $request->superficie_m2,
            'capacidad_personas' => $request->capacidad_personas,
            'precio_base' => $request->precio_base,
            'precio_copropietario' => $request->precio_copropietario,
            'garantia_requerida' => $request->garantia_requerida,
            'estado' => $request->estado,
            'amenidades' => $request->amenidades ? json_encode($request->amenidades) : null,
            'updated_at' => now(),
        ], fn($v) => $v !== null);

        DB::table('espacios_arrendables')
            ->where('id', $id)
            ->update($datos);

        return response()->json(['success' => true, 'message' => 'Espacio actualizado']);
    }

    /**
     * Obtener detalle de espacio
     */
    public function mostrarEspacio(int $id): JsonResponse
    {
        $espacio = DB::table('espacios_arrendables')
            ->join('tipos_espacio_arriendo', 'espacios_arrendables.tipo_espacio_id', '=', 'tipos_espacio_arriendo.id')
            ->join('categorias_arriendo', 'tipos_espacio_arriendo.categoria_id', '=', 'categorias_arriendo.id')
            ->where('espacios_arrendables.id', $id)
            ->select(
                'espacios_arrendables.*',
                'tipos_espacio_arriendo.nombre as tipo_nombre',
                'tipos_espacio_arriendo.permite_reserva',
                'tipos_espacio_arriendo.requiere_garantia',
                'categorias_arriendo.nombre as categoria_nombre',
                'categorias_arriendo.genera_iva',
                'categorias_arriendo.tasa_retencion'
            )
            ->first();

        if (!$espacio) {
            return response()->json(['success' => false, 'message' => 'Espacio no encontrado'], 404);
        }

        // Contratos históricos
        $espacio->contratos = DB::table('contratos_arriendo')
            ->join('arrendatarios', 'contratos_arriendo.arrendatario_id', '=', 'arrendatarios.id')
            ->where('contratos_arriendo.espacio_id', $id)
            ->select(
                'contratos_arriendo.*',
                'arrendatarios.nombre as arrendatario_nombre'
            )
            ->orderByDesc('contratos_arriendo.fecha_inicio')
            ->limit(10)
            ->get();

        // Reservas recientes
        if ($espacio->permite_reserva) {
            $espacio->reservas = DB::table('reservas_espacios')
                ->where('espacio_id', $id)
                ->where('fecha_reserva', '>=', now()->subDays(30))
                ->orderByDesc('fecha_reserva')
                ->limit(20)
                ->get();
        }

        return response()->json(['success' => true, 'data' => $espacio]);
    }

    // =========================================================================
    // RESERVAS
    // =========================================================================

    /**
     * Listar reservas
     */
    public function listarReservas(Request $request): JsonResponse
    {
        $query = DB::table('reservas_espacios')
            ->join('espacios_arrendables', 'reservas_espacios.espacio_id', '=', 'espacios_arrendables.id')
            ->join('personas', 'reservas_espacios.solicitante_id', '=', 'personas.id')
            ->whereNull('reservas_espacios.deleted_at');

        if ($request->edificio_id) {
            $query->where('espacios_arrendables.edificio_id', $request->edificio_id);
        }

        if ($request->espacio_id) {
            $query->where('reservas_espacios.espacio_id', $request->espacio_id);
        }

        if ($request->fecha_desde) {
            $query->where('reservas_espacios.fecha_reserva', '>=', $request->fecha_desde);
        }

        if ($request->fecha_hasta) {
            $query->where('reservas_espacios.fecha_reserva', '<=', $request->fecha_hasta);
        }

        if ($request->estado) {
            $query->where('reservas_espacios.estado', $request->estado);
        }

        $reservas = $query->select(
            'reservas_espacios.*',
            'espacios_arrendables.nombre as espacio_nombre',
            'espacios_arrendables.codigo as espacio_codigo',
            'personas.nombre_completo as solicitante_nombre',
            'personas.telefono as solicitante_telefono'
        )
        ->orderByDesc('reservas_espacios.fecha_reserva')
        ->orderBy('reservas_espacios.hora_inicio')
        ->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $reservas]);
    }

    /**
     * Crear reserva
     */
    public function crearReserva(Request $request): JsonResponse
    {
        $request->validate([
            'espacio_id' => 'required|exists:espacios_arrendables,id',
            'solicitante_id' => 'required|exists:personas,id',
            'fecha_reserva' => 'required|date|after_or_equal:today',
            'hora_inicio' => 'nullable|date_format:H:i',
            'hora_fin' => 'nullable|date_format:H:i|after:hora_inicio',
        ]);

        $espacio = DB::table('espacios_arrendables')
            ->join('tipos_espacio_arriendo', 'espacios_arrendables.tipo_espacio_id', '=', 'tipos_espacio_arriendo.id')
            ->where('espacios_arrendables.id', $request->espacio_id)
            ->select('espacios_arrendables.*', 'tipos_espacio_arriendo.permite_reserva', 'tipos_espacio_arriendo.requiere_garantia')
            ->first();

        if (!$espacio) {
            return response()->json(['success' => false, 'message' => 'Espacio no encontrado'], 404);
        }

        if (!$espacio->permite_reserva) {
            return response()->json(['success' => false, 'message' => 'Este espacio no permite reservas'], 422);
        }

        if ($espacio->estado !== 'disponible') {
            return response()->json(['success' => false, 'message' => 'El espacio no está disponible'], 422);
        }

        // Verificar disponibilidad en la fecha/hora
        $conflicto = DB::table('reservas_espacios')
            ->where('espacio_id', $request->espacio_id)
            ->where('fecha_reserva', $request->fecha_reserva)
            ->whereIn('estado', ['pendiente', 'confirmada', 'pagada', 'en_uso'])
            ->where(function($q) use ($request) {
                if ($request->hora_inicio && $request->hora_fin) {
                    $q->where(function($q2) use ($request) {
                        $q2->where('hora_inicio', '<', $request->hora_fin)
                           ->where('hora_fin', '>', $request->hora_inicio);
                    });
                }
            })
            ->exists();

        if ($conflicto) {
            return response()->json([
                'success' => false,
                'message' => 'Ya existe una reserva en ese horario'
            ], 422);
        }

        // Calcular monto
        $montoArriendo = $espacio->precio_base ?? 0;
        
        // Verificar si es copropietario para precio especial
        $esCopropietario = DB::table('unidades')
            ->where('propietario_id', $request->solicitante_id)
            ->where('edificio_id', $espacio->edificio_id)
            ->exists();

        if ($esCopropietario && $espacio->precio_copropietario) {
            $montoArriendo = $espacio->precio_copropietario;
        }

        $montoGarantia = $espacio->requiere_garantia ? ($espacio->garantia_requerida ?? 0) : 0;
        $montoTotal = $montoArriendo + $montoGarantia;

        // Generar número de reserva
        $numero = 'RES-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

        $id = DB::table('reservas_espacios')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'espacio_id' => $request->espacio_id,
            'solicitante_id' => $request->solicitante_id,
            'unidad_id' => $request->unidad_id,
            'numero_reserva' => $numero,
            'fecha_reserva' => $request->fecha_reserva,
            'hora_inicio' => $request->hora_inicio,
            'hora_fin' => $request->hora_fin,
            'fecha_fin' => $request->fecha_fin,
            'motivo' => $request->motivo,
            'cantidad_personas' => $request->cantidad_personas,
            'monto_arriendo' => $montoArriendo,
            'monto_garantia' => $montoGarantia,
            'monto_total' => $montoTotal,
            'estado' => 'pendiente',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Reserva creada exitosamente',
            'id' => $id,
            'numero_reserva' => $numero,
            'monto_total' => $montoTotal,
        ], 201);
    }

    /**
     * Confirmar reserva
     */
    public function confirmarReserva(int $id): JsonResponse
    {
        $reserva = DB::table('reservas_espacios')->find($id);

        if (!$reserva) {
            return response()->json(['success' => false, 'message' => 'Reserva no encontrada'], 404);
        }

        if ($reserva->estado !== 'pendiente') {
            return response()->json(['success' => false, 'message' => 'Solo se pueden confirmar reservas pendientes'], 422);
        }

        DB::table('reservas_espacios')
            ->where('id', $id)
            ->update([
                'estado' => 'confirmada',
                'confirmada_at' => now(),
                'updated_at' => now(),
            ]);

        return response()->json(['success' => true, 'message' => 'Reserva confirmada']);
    }

    /**
     * Cancelar reserva
     */
    public function cancelarReserva(Request $request, int $id): JsonResponse
    {
        $reserva = DB::table('reservas_espacios')->find($id);

        if (!$reserva) {
            return response()->json(['success' => false, 'message' => 'Reserva no encontrada'], 404);
        }

        if (in_array($reserva->estado, ['finalizada', 'cancelada'])) {
            return response()->json(['success' => false, 'message' => 'No se puede cancelar esta reserva'], 422);
        }

        DB::table('reservas_espacios')
            ->where('id', $id)
            ->update([
                'estado' => 'cancelada',
                'cancelada_at' => now(),
                'motivo_cancelacion' => $request->motivo,
                'updated_at' => now(),
            ]);

        return response()->json(['success' => true, 'message' => 'Reserva cancelada']);
    }

    /**
     * Obtener disponibilidad de espacio
     */
    public function disponibilidadEspacio(Request $request): JsonResponse
    {
        $request->validate([
            'espacio_id' => 'required|exists:espacios_arrendables,id',
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2024',
        ]);

        $fechaInicio = Carbon::create($request->anio, $request->mes, 1)->startOfMonth();
        $fechaFin = $fechaInicio->copy()->endOfMonth();

        $reservas = DB::table('reservas_espacios')
            ->where('espacio_id', $request->espacio_id)
            ->whereBetween('fecha_reserva', [$fechaInicio, $fechaFin])
            ->whereIn('estado', ['confirmada', 'pagada', 'en_uso'])
            ->select('fecha_reserva', 'hora_inicio', 'hora_fin', 'estado')
            ->get()
            ->groupBy('fecha_reserva');

        // Generar calendario del mes
        $calendario = [];
        $fecha = $fechaInicio->copy();

        while ($fecha <= $fechaFin) {
            $fechaStr = $fecha->format('Y-m-d');
            $reservasDia = $reservas->get($fechaStr, collect([]));

            $calendario[] = [
                'fecha' => $fechaStr,
                'dia_semana' => $fecha->dayOfWeek,
                'disponible' => $reservasDia->isEmpty(),
                'reservas' => $reservasDia->count(),
                'horarios_ocupados' => $reservasDia->map(fn($r) => [
                    'inicio' => $r->hora_inicio,
                    'fin' => $r->hora_fin,
                ])->values(),
            ];

            $fecha->addDay();
        }

        return response()->json([
            'success' => true,
            'data' => [
                'mes' => $request->mes,
                'anio' => $request->anio,
                'calendario' => $calendario,
            ]
        ]);
    }

    // =========================================================================
    // CONCESIONES
    // =========================================================================

    /**
     * Listar contratos de concesión
     */
    public function listarConcesiones(Request $request): JsonResponse
    {
        $query = DB::table('contratos_concesion')
            ->join('espacios_arrendables', 'contratos_concesion.espacio_id', '=', 'espacios_arrendables.id')
            ->join('personas', 'contratos_concesion.concesionario_id', '=', 'personas.id')
            ->whereNull('contratos_concesion.deleted_at');

        if ($request->edificio_id) {
            $query->where('contratos_concesion.edificio_id', $request->edificio_id);
        }

        if ($request->estado) {
            $query->where('contratos_concesion.estado', $request->estado);
        }

        $concesiones = $query->select(
            'contratos_concesion.*',
            'espacios_arrendables.nombre as espacio_nombre',
            'personas.nombre_completo as concesionario_nombre',
            'personas.rut as concesionario_rut'
        )
        ->orderByDesc('contratos_concesion.fecha_inicio')
        ->paginate($request->get('per_page', 20));

        return response()->json(['success' => true, 'data' => $concesiones]);
    }

    /**
     * Crear contrato de concesión
     */
    public function crearConcesion(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'espacio_id' => 'required|exists:espacios_arrendables,id',
            'concesionario_id' => 'required|exists:personas,id',
            'tipo_concesion' => 'required|string|max:50',
            'fecha_inicio' => 'required|date',
            'fecha_termino' => 'required|date|after:fecha_inicio',
            'tipo_pago' => 'required|in:fijo,porcentaje_ventas,mixto',
        ]);

        // Verificar que el espacio no tenga concesión vigente
        $concesionVigente = DB::table('contratos_concesion')
            ->where('espacio_id', $request->espacio_id)
            ->where('estado', 'vigente')
            ->exists();

        if ($concesionVigente) {
            return response()->json([
                'success' => false,
                'message' => 'El espacio ya tiene una concesión vigente'
            ], 422);
        }

        $numero = 'CON-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

        $id = DB::table('contratos_concesion')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'espacio_id' => $request->espacio_id,
            'concesionario_id' => $request->concesionario_id,
            'numero_contrato' => $numero,
            'tipo_concesion' => $request->tipo_concesion,
            'nombre_comercial' => $request->nombre_comercial,
            'giro' => $request->giro,
            'patente_municipal' => $request->patente_municipal,
            'fecha_inicio' => $request->fecha_inicio,
            'fecha_termino' => $request->fecha_termino,
            'renovacion_automatica' => $request->renovacion_automatica ?? false,
            'meses_aviso_no_renovacion' => $request->meses_aviso_no_renovacion ?? 3,
            'tipo_pago' => $request->tipo_pago,
            'monto_fijo_mensual' => $request->monto_fijo_mensual,
            'porcentaje_ventas' => $request->porcentaje_ventas,
            'minimo_garantizado' => $request->minimo_garantizado,
            'dia_pago' => $request->dia_pago ?? 5,
            'monto_garantia' => $request->monto_garantia,
            'tipo_garantia' => $request->tipo_garantia,
            'servicios_incluidos' => $request->servicios_incluidos ? json_encode($request->servicios_incluidos) : null,
            'gastos_comunes_fijos' => $request->gastos_comunes_fijos,
            'estado' => 'borrador',
            'clausulas_especiales' => $request->clausulas_especiales,
            'observaciones' => $request->observaciones,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Contrato de concesión creado',
            'id' => $id,
            'numero_contrato' => $numero,
        ], 201);
    }

    /**
     * Activar concesión
     */
    public function activarConcesion(int $id): JsonResponse
    {
        $concesion = DB::table('contratos_concesion')->find($id);

        if (!$concesion) {
            return response()->json(['success' => false, 'message' => 'Concesión no encontrada'], 404);
        }

        DB::beginTransaction();

        try {
            // Actualizar estado
            DB::table('contratos_concesion')
                ->where('id', $id)
                ->update([
                    'estado' => 'vigente',
                    'updated_at' => now(),
                ]);

            // Actualizar espacio
            DB::table('espacios_arrendables')
                ->where('id', $concesion->espacio_id)
                ->update([
                    'estado' => 'arrendado',
                    'updated_at' => now(),
                ]);

            DB::commit();

            return response()->json(['success' => true, 'message' => 'Concesión activada']);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Registrar pago de concesión
     */
    public function registrarPagoConcesion(Request $request): JsonResponse
    {
        $request->validate([
            'contrato_id' => 'required|exists:contratos_concesion,id',
            'periodo' => 'required|string|max:7',
            'ventas_declaradas' => 'nullable|numeric|min:0',
        ]);

        $contrato = DB::table('contratos_concesion')->find($request->contrato_id);

        if (!$contrato) {
            return response()->json(['success' => false, 'message' => 'Contrato no encontrado'], 404);
        }

        // Calcular montos
        $montoFijo = $contrato->monto_fijo_mensual ?? 0;
        $ventasDeclaradas = $request->ventas_declaradas ?? 0;
        $porcentaje = $contrato->porcentaje_ventas ?? 0;
        $montoVariable = round($ventasDeclaradas * ($porcentaje / 100), 0);
        $gastosComunes = $contrato->gastos_comunes_fijos ?? 0;
        $otrosCargos = $request->otros_cargos ?? 0;
        $montoTotal = $montoFijo + $montoVariable + $gastosComunes + $otrosCargos;

        // Aplicar mínimo garantizado si aplica
        if ($contrato->minimo_garantizado && $montoTotal < $contrato->minimo_garantizado) {
            $montoTotal = $contrato->minimo_garantizado;
        }

        $id = DB::table('pagos_concesion')->insertGetId([
            'contrato_id' => $request->contrato_id,
            'periodo' => $request->periodo,
            'fecha_vencimiento' => Carbon::parse($request->periodo . '-01')->day($contrato->dia_pago),
            'monto_fijo' => $montoFijo,
            'ventas_declaradas' => $ventasDeclaradas,
            'porcentaje_aplicado' => $porcentaje,
            'monto_variable' => $montoVariable,
            'gastos_comunes' => $gastosComunes,
            'otros_cargos' => $otrosCargos,
            'monto_total' => $montoTotal,
            'estado' => 'pendiente',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Pago registrado',
            'id' => $id,
            'monto_total' => $montoTotal,
        ], 201);
    }
}
