<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - Gastos Comunes Controller
 * Cumplimiento Ley 21.442 de Copropiedad Inmobiliaria
 */
class GastosComunesController extends Controller
{
    /**
     * Listar períodos
     */
    public function periodos(Request $request): JsonResponse
    {
        $periodos = DB::table('periodos_gc')
            ->join('edificios', 'periodos_gc.edificio_id', '=', 'edificios.id')
            ->where('periodos_gc.tenant_id', Auth::user()->tenant_id)
            ->when($request->edificio_id, fn($q) => $q->where('periodos_gc.edificio_id', $request->edificio_id))
            ->select('periodos_gc.*', 'edificios.nombre as edificio')
            ->orderByDesc('anio')
            ->orderByDesc('mes')
            ->paginate(24);

        return response()->json(['success' => true, 'data' => $periodos]);
    }

    /**
     * Crear período
     */
    public function crearPeriodo(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
            'fecha_vencimiento' => 'required|date',
        ]);

        $existe = DB::table('periodos_gc')
            ->where('edificio_id', $request->edificio_id)
            ->where('mes', $request->mes)
            ->where('anio', $request->anio)
            ->exists();

        if ($existe) {
            return response()->json(['success' => false, 'message' => 'El período ya existe'], 422);
        }

        $id = DB::table('periodos_gc')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'mes' => $request->mes,
            'anio' => $request->anio,
            'fecha_emision' => now(),
            'fecha_vencimiento' => $request->fecha_vencimiento,
            'estado' => 'abierto',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Período creado', 'id' => $id], 201);
    }

    /**
     * Mostrar período con boletas
     */
    public function showPeriodo(int $id): JsonResponse
    {
        $periodo = DB::table('periodos_gc')
            ->join('edificios', 'periodos_gc.edificio_id', '=', 'edificios.id')
            ->where('periodos_gc.id', $id)
            ->where('periodos_gc.tenant_id', Auth::user()->tenant_id)
            ->select('periodos_gc.*', 'edificios.nombre as edificio')
            ->first();

        if (!$periodo) {
            return response()->json(['success' => false, 'message' => 'No encontrado'], 404);
        }

        $boletas = DB::table('boletas_gc')
            ->join('unidades', 'boletas_gc.unidad_id', '=', 'unidades.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('boletas_gc.periodo_id', $id)
            ->select(
                'boletas_gc.*',
                'unidades.numero',
                'personas.nombre_completo as propietario'
            )
            ->orderByRaw("CAST(REGEXP_REPLACE(unidades.numero, '[^0-9]', '') AS UNSIGNED)")
            ->get();

        $periodo->boletas = $boletas;
        $periodo->resumen = [
            'total_boletas' => $boletas->count(),
            'total_emitido' => $boletas->sum('total_a_pagar'),
            'total_pagado' => $boletas->sum('total_abonos'),
            'total_pendiente' => $boletas->sum(fn($b) => $b->total_a_pagar - $b->total_abonos),
            'boletas_pagadas' => $boletas->where('estado', 'pagada')->count(),
            'boletas_pendientes' => $boletas->whereIn('estado', ['pendiente', 'vencida'])->count(),
        ];

        return response()->json(['success' => true, 'data' => $periodo]);
    }

    /**
     * Generar boletas del período
     */
    public function generarBoletas(int $periodoId): JsonResponse
    {
        $periodo = DB::table('periodos_gc')
            ->where('id', $periodoId)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$periodo || $periodo->estado !== 'abierto') {
            return response()->json(['success' => false, 'message' => 'Período no válido o ya cerrado'], 422);
        }

        $unidades = DB::table('unidades')
            ->where('edificio_id', $periodo->edificio_id)
            ->where('activa', true)
            ->whereNull('deleted_at')
            ->get();

        $edificio = DB::table('edificios')->where('id', $periodo->edificio_id)->first();

        $conceptos = DB::table('conceptos_gc')
            ->where('tenant_id', $periodo->tenant_id)
            ->where('activo', true)
            ->orderBy('orden')
            ->get();

        $presupuesto = DB::table('presupuestos_gc')
            ->where('edificio_id', $periodo->edificio_id)
            ->where('anio', $periodo->anio)
            ->get()
            ->keyBy('concepto_id');

        $generadas = 0;
        $errores = [];

        foreach ($unidades as $unidad) {
            // Verificar si ya existe boleta
            $existe = DB::table('boletas_gc')
                ->where('periodo_id', $periodoId)
                ->where('unidad_id', $unidad->id)
                ->exists();

            if ($existe) continue;

            try {
                // Calcular saldo anterior
                $saldoAnterior = DB::table('boletas_gc')
                    ->where('unidad_id', $unidad->id)
                    ->where('id', '<', $periodoId)
                    ->whereIn('estado', ['pendiente', 'vencida'])
                    ->sum(DB::raw('total_a_pagar - COALESCE(total_abonos, 0)'));

                // Calcular cargos según prorrateo
                $totalCargos = 0;
                $cargosData = [];

                foreach ($conceptos as $concepto) {
                    $montoBase = isset($presupuesto[$concepto->id]) 
                        ? $presupuesto[$concepto->id]->monto_mensual 
                        : 0;

                    $monto = $concepto->metodo_calculo === 'prorrateo'
                        ? round($montoBase * ($unidad->prorrateo / 100), 0)
                        : $montoBase;

                    if ($monto > 0) {
                        $cargosData[] = [
                            'concepto_id' => $concepto->id,
                            'descripcion' => $concepto->nombre,
                            'monto' => $monto,
                            'tipo' => $concepto->tipo,
                        ];
                        $totalCargos += $monto;
                    }
                }

                $numeroBoleta = sprintf('%s-%04d-%02d-%04d',
                    str_replace(['.', '-'], '', $edificio->rut ?? ''),
                    $periodo->anio,
                    $periodo->mes,
                    $unidad->id
                );

                $boletaId = DB::table('boletas_gc')->insertGetId([
                    'tenant_id' => $periodo->tenant_id,
                    'edificio_id' => $periodo->edificio_id,
                    'periodo_id' => $periodoId,
                    'unidad_id' => $unidad->id,
                    'numero_boleta' => $numeroBoleta,
                    'fecha_emision' => $periodo->fecha_emision ?? now(),
                    'fecha_vencimiento' => $periodo->fecha_vencimiento,
                    'saldo_anterior' => $saldoAnterior,
                    'total_cargos' => $totalCargos,
                    'total_abonos' => 0,
                    'total_intereses' => 0,
                    'total_a_pagar' => $saldoAnterior + $totalCargos,
                    'estado' => 'pendiente',
                    'dias_mora' => 0,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                // Insertar cargos
                foreach ($cargosData as $cargo) {
                    DB::table('cargos_gc')->insert([
                        'boleta_id' => $boletaId,
                        'concepto_id' => $cargo['concepto_id'],
                        'descripcion' => $cargo['descripcion'],
                        'monto' => $cargo['monto'],
                        'tipo' => $cargo['tipo'],
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }

                $generadas++;
            } catch (\Exception $e) {
                $errores[] = "Unidad {$unidad->numero}: {$e->getMessage()}";
            }
        }

        // Actualizar totales del período
        $totales = DB::table('boletas_gc')
            ->where('periodo_id', $periodoId)
            ->selectRaw('SUM(total_a_pagar) as emitido, SUM(total_abonos) as recaudado')
            ->first();

        DB::table('periodos_gc')->where('id', $periodoId)->update([
            'total_emitido' => $totales->emitido ?? 0,
            'total_recaudado' => $totales->recaudado ?? 0,
            'total_pendiente' => ($totales->emitido ?? 0) - ($totales->recaudado ?? 0),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => "Se generaron {$generadas} boletas",
            'generadas' => $generadas,
            'errores' => $errores,
        ]);
    }

    /**
     * Cerrar período
     */
    public function cerrarPeriodo(int $periodoId): JsonResponse
    {
        $periodo = DB::table('periodos_gc')
            ->where('id', $periodoId)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$periodo) {
            return response()->json(['success' => false, 'message' => 'Período no encontrado'], 404);
        }

        DB::table('periodos_gc')->where('id', $periodoId)->update([
            'estado' => 'cerrado',
            'cerrado_at' => now(),
            'cerrado_por' => Auth::id(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Período cerrado']);
    }

    /**
     * Listar boletas
     */
    public function boletas(Request $request): JsonResponse
    {
        $query = DB::table('boletas_gc')
            ->join('unidades', 'boletas_gc.unidad_id', '=', 'unidades.id')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->join('edificios', 'boletas_gc.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('boletas_gc.tenant_id', Auth::user()->tenant_id)
            ->select(
                'boletas_gc.*',
                'unidades.numero as unidad',
                'periodos_gc.mes',
                'periodos_gc.anio',
                'edificios.nombre as edificio',
                'personas.nombre_completo as propietario'
            );

        if ($request->edificio_id) {
            $query->where('boletas_gc.edificio_id', $request->edificio_id);
        }

        if ($request->estado) {
            $query->where('boletas_gc.estado', $request->estado);
        }

        if ($request->periodo_id) {
            $query->where('boletas_gc.periodo_id', $request->periodo_id);
        }

        $boletas = $query
            ->orderByDesc('periodos_gc.anio')
            ->orderByDesc('periodos_gc.mes')
            ->orderBy('unidades.numero')
            ->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $boletas]);
    }

    /**
     * Mostrar boleta con detalles
     */
    public function showBoleta(int $id): JsonResponse
    {
        $boleta = DB::table('boletas_gc')
            ->join('unidades', 'boletas_gc.unidad_id', '=', 'unidades.id')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->join('edificios', 'boletas_gc.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('boletas_gc.id', $id)
            ->where('boletas_gc.tenant_id', Auth::user()->tenant_id)
            ->select(
                'boletas_gc.*',
                'unidades.numero as unidad',
                'unidades.tipo as tipo_unidad',
                'unidades.prorrateo',
                'periodos_gc.mes',
                'periodos_gc.anio',
                'edificios.nombre as edificio',
                'edificios.direccion as edificio_direccion',
                'edificios.rut as edificio_rut',
                'personas.nombre_completo as propietario',
                'personas.rut as propietario_rut',
                'personas.email as propietario_email'
            )
            ->first();

        if (!$boleta) {
            return response()->json(['success' => false, 'message' => 'Boleta no encontrada'], 404);
        }

        $boleta->cargos = DB::table('cargos_gc')->where('boleta_id', $id)->get();
        $boleta->pagos = DB::table('pagos_gc')
            ->where('boleta_id', $id)
            ->whereNull('deleted_at')
            ->orderByDesc('fecha_pago')
            ->get();

        $boleta->saldo_pendiente = $boleta->total_a_pagar - $boleta->total_abonos;

        return response()->json(['success' => true, 'data' => $boleta]);
    }

    /**
     * Generar PDF de boleta
     */
    public function boletaPdf(int $id)
    {
        $boleta = DB::table('boletas_gc')
            ->join('unidades', 'boletas_gc.unidad_id', '=', 'unidades.id')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->join('edificios', 'boletas_gc.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('boletas_gc.id', $id)
            ->select(
                'boletas_gc.*',
                'unidades.numero as unidad',
                'periodos_gc.mes',
                'periodos_gc.anio',
                'edificios.nombre as edificio',
                'edificios.direccion',
                'edificios.rut as edificio_rut',
                'personas.nombre_completo as propietario',
                'personas.rut as propietario_rut'
            )
            ->first();

        if (!$boleta) {
            return response()->json(['success' => false, 'message' => 'Boleta no encontrada'], 404);
        }

        $cargos = DB::table('cargos_gc')->where('boleta_id', $id)->get();

        $pdf = Pdf::loadView('pdf.boleta-gc', compact('boleta', 'cargos'));
        return $pdf->download("boleta-{$boleta->numero_boleta}.pdf");
    }

    /**
     * Registrar pago
     */
    public function registrarPago(Request $request): JsonResponse
    {
        $request->validate([
            'boleta_id' => 'required|exists:boletas_gc,id',
            'monto' => 'required|numeric|min:1',
            'fecha_pago' => 'required|date',
            'medio_pago' => 'required|in:efectivo,transferencia,cheque,tarjeta,pac,webpay,khipu,otro',
        ]);

        $boleta = DB::table('boletas_gc')
            ->where('id', $request->boleta_id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$boleta) {
            return response()->json(['success' => false, 'message' => 'Boleta no encontrada'], 404);
        }

        $saldoPendiente = $boleta->total_a_pagar - $boleta->total_abonos;

        if ($request->monto > $saldoPendiente) {
            return response()->json([
                'success' => false,
                'message' => "El monto excede el saldo pendiente de $" . number_format($saldoPendiente, 0, ',', '.'),
            ], 422);
        }

        $pagoId = DB::table('pagos_gc')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'boleta_id' => $request->boleta_id,
            'monto' => $request->monto,
            'fecha_pago' => $request->fecha_pago,
            'medio_pago' => $request->medio_pago,
            'referencia' => $request->referencia,
            'banco' => $request->banco,
            'numero_operacion' => $request->numero_operacion,
            'observaciones' => $request->observaciones,
            'estado' => 'confirmado',
            'registrado_por' => Auth::id(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Actualizar boleta
        $nuevoAbono = $boleta->total_abonos + $request->monto;
        $nuevoEstado = $nuevoAbono >= $boleta->total_a_pagar ? 'pagada' : 'parcial';

        DB::table('boletas_gc')->where('id', $request->boleta_id)->update([
            'total_abonos' => $nuevoAbono,
            'estado' => $nuevoEstado,
            'fecha_pago' => $nuevoEstado === 'pagada' ? now() : null,
            'updated_at' => now(),
        ]);

        // Actualizar totales del período
        $this->actualizarTotalesPeriodo($boleta->periodo_id);

        return response()->json([
            'success' => true,
            'message' => 'Pago registrado exitosamente',
            'id' => $pagoId,
        ], 201);
    }

    /**
     * Anular pago
     */
    public function anularPago(int $id): JsonResponse
    {
        $pago = DB::table('pagos_gc')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->whereNull('deleted_at')
            ->first();

        if (!$pago) {
            return response()->json(['success' => false, 'message' => 'Pago no encontrado'], 404);
        }

        // Soft delete del pago
        DB::table('pagos_gc')->where('id', $id)->update([
            'deleted_at' => now(),
            'anulado_por' => Auth::id(),
        ]);

        // Actualizar boleta
        $boleta = DB::table('boletas_gc')->where('id', $pago->boleta_id)->first();
        $nuevoAbono = $boleta->total_abonos - $pago->monto;
        $nuevoEstado = $nuevoAbono <= 0 ? 'pendiente' : ($nuevoAbono >= $boleta->total_a_pagar ? 'pagada' : 'parcial');

        DB::table('boletas_gc')->where('id', $pago->boleta_id)->update([
            'total_abonos' => max(0, $nuevoAbono),
            'estado' => $nuevoEstado,
            'fecha_pago' => null,
            'updated_at' => now(),
        ]);

        $this->actualizarTotalesPeriodo($boleta->periodo_id);

        return response()->json(['success' => true, 'message' => 'Pago anulado']);
    }

    /**
     * Reporte de morosidad
     */
    public function morosidad(Request $request): JsonResponse
    {
        $morosos = DB::table('boletas_gc')
            ->join('unidades', 'boletas_gc.unidad_id', '=', 'unidades.id')
            ->join('edificios', 'boletas_gc.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('boletas_gc.tenant_id', Auth::user()->tenant_id)
            ->whereIn('boletas_gc.estado', ['pendiente', 'vencida'])
            ->when($request->edificio_id, fn($q) => $q->where('boletas_gc.edificio_id', $request->edificio_id))
            ->select(
                'unidades.id as unidad_id',
                'unidades.numero',
                'edificios.id as edificio_id',
                'edificios.nombre as edificio',
                'personas.nombre_completo as propietario',
                'personas.email',
                'personas.telefono',
                DB::raw('SUM(boletas_gc.total_a_pagar - COALESCE(boletas_gc.total_abonos, 0)) as deuda'),
                DB::raw('SUM(boletas_gc.total_intereses) as intereses'),
                DB::raw('COUNT(boletas_gc.id) as boletas_pendientes'),
                DB::raw('MAX(boletas_gc.dias_mora) as dias_mora')
            )
            ->groupBy('unidades.id', 'unidades.numero', 'edificios.id', 'edificios.nombre', 
                      'personas.nombre_completo', 'personas.email', 'personas.telefono')
            ->havingRaw('SUM(boletas_gc.total_a_pagar - COALESCE(boletas_gc.total_abonos, 0)) > 0')
            ->orderByDesc('deuda')
            ->get();

        $totales = [
            'total_morosos' => $morosos->count(),
            'deuda_total' => $morosos->sum('deuda'),
            'intereses_total' => $morosos->sum('intereses'),
        ];

        return response()->json([
            'success' => true,
            'data' => [
                'totales' => $totales,
                'morosos' => $morosos,
            ],
        ]);
    }

    /**
     * Calcular intereses de mora (Ley 21.442 Art. 5)
     */
    public function calcularIntereses(Request $request): JsonResponse
    {
        $tenantId = Auth::user()->tenant_id;
        $edificioId = $request->edificio_id;

        $boletas = DB::table('boletas_gc')
            ->join('edificios', 'boletas_gc.edificio_id', '=', 'edificios.id')
            ->where('boletas_gc.tenant_id', $tenantId)
            ->when($edificioId, fn($q) => $q->where('boletas_gc.edificio_id', $edificioId))
            ->whereIn('boletas_gc.estado', ['pendiente', 'vencida'])
            ->where('boletas_gc.fecha_vencimiento', '<', now())
            ->select('boletas_gc.*', 'edificios.interes_mora')
            ->get();

        $actualizadas = 0;
        foreach ($boletas as $boleta) {
            $diasMora = now()->diffInDays(Carbon::parse($boleta->fecha_vencimiento));
            $tasaMensual = min($boleta->interes_mora ?? 3, 3); // Máximo 3% según Ley 21.442
            $saldoBase = $boleta->total_cargos + $boleta->saldo_anterior - $boleta->total_abonos;
            
            // Interés simple mensual
            $mesesMora = ceil($diasMora / 30);
            $intereses = round($saldoBase * ($tasaMensual / 100) * $mesesMora, 0);

            DB::table('boletas_gc')->where('id', $boleta->id)->update([
                'dias_mora' => $diasMora,
                'total_intereses' => $intereses,
                'total_a_pagar' => $boleta->saldo_anterior + $boleta->total_cargos + $intereses,
                'estado' => 'vencida',
                'updated_at' => now(),
            ]);

            $actualizadas++;
        }

        return response()->json([
            'success' => true,
            'message' => "Se actualizaron {$actualizadas} boletas con intereses de mora",
        ]);
    }

    /**
     * Listar conceptos de gastos comunes
     */
    public function conceptos(): JsonResponse
    {
        $conceptos = DB::table('conceptos_gc')
            ->where('tenant_id', Auth::user()->tenant_id)
            ->where('activo', true)
            ->orderBy('orden')
            ->get();

        return response()->json(['success' => true, 'data' => $conceptos]);
    }

    /**
     * Actualizar totales del período
     */
    private function actualizarTotalesPeriodo(int $periodoId): void
    {
        $totales = DB::table('boletas_gc')
            ->where('periodo_id', $periodoId)
            ->selectRaw('SUM(total_a_pagar) as emitido, SUM(total_abonos) as recaudado')
            ->first();

        DB::table('periodos_gc')->where('id', $periodoId)->update([
            'total_recaudado' => $totales->recaudado ?? 0,
            'total_pendiente' => ($totales->emitido ?? 0) - ($totales->recaudado ?? 0),
            'updated_at' => now(),
        ]);
    }
}
