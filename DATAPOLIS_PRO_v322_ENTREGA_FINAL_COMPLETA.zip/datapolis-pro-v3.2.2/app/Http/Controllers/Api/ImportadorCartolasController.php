<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\ImportadorCartolasService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Storage;

/**
 * DATAPOLIS PRO v3.1 - Controlador de Importación de Cartolas
 */
class ImportadorCartolasController extends Controller
{
    protected ImportadorCartolasService $service;

    public function __construct(ImportadorCartolasService $service)
    {
        $this->service = $service;
    }

    /**
     * Obtener bancos soportados
     * GET /api/bancos/importador/bancos
     */
    public function bancosSoportados(): JsonResponse
    {
        $bancos = $this->service->getBancosSoportados();

        return response()->json([
            'success' => true,
            'data' => $bancos,
        ]);
    }

    /**
     * Previsualizar archivo de cartola
     * POST /api/bancos/importador/preview
     */
    public function preview(Request $request): JsonResponse
    {
        $request->validate([
            'archivo' => 'required|file|mimes:csv,xls,xlsx,txt|max:10240',
            'banco' => 'required|string',
            'lineas' => 'nullable|integer|min:5|max:50',
        ]);

        // Guardar archivo temporal
        $archivo = $request->file('archivo');
        $ruta = $archivo->store('temp/cartolas');
        $rutaCompleta = Storage::path($ruta);

        try {
            $resultado = $this->service->previsualizarCartola(
                $rutaCompleta,
                $request->banco,
                $request->get('lineas', 10)
            );

            // Limpiar archivo temporal
            Storage::delete($ruta);

            return response()->json($resultado);

        } catch (\Exception $e) {
            Storage::delete($ruta);
            return response()->json([
                'success' => false,
                'message' => 'Error al procesar archivo: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Importar cartola
     * POST /api/bancos/importador/importar
     */
    public function importar(Request $request): JsonResponse
    {
        $request->validate([
            'archivo' => 'required|file|mimes:csv,xls,xlsx,txt|max:10240',
            'cuenta_id' => 'required|exists:cuentas_bancarias_comunidad,id',
            'banco' => 'required|string',
        ]);

        // Guardar archivo
        $archivo = $request->file('archivo');
        $nombreOriginal = $archivo->getClientOriginalName();
        $ruta = $archivo->store('cartolas/' . date('Y/m'));
        $rutaCompleta = Storage::path($ruta);

        try {
            $resultado = $this->service->importarCartola(
                $request->cuenta_id,
                $rutaCompleta,
                $request->banco,
                [
                    'nombre_archivo' => $nombreOriginal,
                    'ruta_archivo' => $ruta,
                ]
            );

            if (!$resultado['success']) {
                Storage::delete($ruta);
            }

            return response()->json($resultado, $resultado['success'] ? 200 : 422);

        } catch (\Exception $e) {
            Storage::delete($ruta);
            return response()->json([
                'success' => false,
                'message' => 'Error al importar: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Ejecutar match automático
     * POST /api/bancos/importador/match
     */
    public function matchAutomatico(Request $request): JsonResponse
    {
        $request->validate([
            'cuenta_id' => 'required|exists:cuentas_bancarias_comunidad,id',
        ]);

        $resultado = $this->service->matchAutomatico($request->cuenta_id);

        return response()->json($resultado);
    }

    /**
     * Obtener plantilla de importación
     * GET /api/bancos/importador/plantilla/{banco}
     */
    public function plantilla(string $banco): JsonResponse
    {
        $resultado = $this->service->generarPlantilla($banco);

        return response()->json($resultado);
    }

    /**
     * Descargar plantilla CSV
     * GET /api/bancos/importador/plantilla/{banco}/csv
     */
    public function descargarPlantilla(string $banco)
    {
        $resultado = $this->service->generarPlantilla($banco);

        if (!$resultado['success']) {
            return response()->json($resultado, 404);
        }

        $separador = $resultado['separador'];
        $contenido = implode($separador, $resultado['encabezados']) . "\n";

        foreach ($resultado['ejemplos'] as $ejemplo) {
            $contenido .= implode($separador, $ejemplo) . "\n";
        }

        $nombre = "plantilla_cartola_{$banco}.csv";

        return response($contenido, 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"{$nombre}\"",
        ]);
    }
}
