<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\NotificacionesService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use App\Models\Edificio;
use App\Models\Copropietario;
use App\Models\PreferenciasNotificacion;

/**
 * NotificacionesController
 * 
 * API REST para sistema de notificaciones multicanal
 * Email, Push, WhatsApp (futuro)
 * 
 * @package DATAPOLIS PRO v3.0
 * @author Daniel - DATAPOLIS
 * @version 1.0.0
 */
class NotificacionesController extends Controller
{
    protected NotificacionesService $notificacionesService;

    public function __construct(NotificacionesService $notificacionesService)
    {
        $this->notificacionesService = $notificacionesService;
    }

    /**
     * Enviar notificación individual
     * 
     * POST /api/v1/notificaciones/enviar
     */
    public function enviar(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'edificio_id' => 'required|integer|exists:edificios,id',
            'copropietario_id' => 'required|integer|exists:copropietarios,id',
            'tipo' => 'required|string',
            'datos' => 'required|array',
            'canales' => 'nullable|array',
            'canales.*' => 'string|in:email,push,whatsapp',
            'prioridad' => 'nullable|string|in:critica,alta,media,baja',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $edificio = Edificio::findOrFail($request->edificio_id);
            $this->authorize('enviar-notificaciones', $edificio);

            $copropietario = Copropietario::findOrFail($request->copropietario_id);

            // Verificar que el copropietario pertenece al edificio
            if ($copropietario->edificio_id !== $request->edificio_id) {
                return response()->json([
                    'success' => false,
                    'error' => 'El copropietario no pertenece a este edificio',
                ], 422);
            }

            $resultado = $this->notificacionesService->enviar(
                $copropietario,
                $request->tipo,
                $request->datos,
                $request->canales ?? ['email'],
                $request->prioridad ?? 'media'
            );

            Log::info('Notificación enviada', [
                'edificio_id' => $request->edificio_id,
                'copropietario_id' => $request->copropietario_id,
                'tipo' => $request->tipo,
                'resultado' => $resultado,
            ]);

            return response()->json([
                'success' => true,
                'data' => $resultado,
                'mensaje' => 'Notificación enviada',
            ]);

        } catch (\Exception $e) {
            Log::error('Error enviando notificación', [
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Error al enviar notificación',
            ], 500);
        }
    }

    /**
     * Enviar notificación masiva a todo el edificio
     * 
     * POST /api/v1/notificaciones/enviar-masivo
     */
    public function enviarMasivo(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'edificio_id' => 'required|integer|exists:edificios,id',
            'tipo' => 'required|string',
            'datos' => 'required|array',
            'canales' => 'nullable|array',
            'canales.*' => 'string|in:email,push,whatsapp',
            'filtros' => 'nullable|array',
            'filtros.tipo_persona' => 'nullable|string|in:propietario,arrendatario,residente',
            'filtros.unidades' => 'nullable|array',
            'filtros.unidades.*' => 'integer',
            'filtros.morosos_excluir' => 'nullable|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $edificio = Edificio::findOrFail($request->edificio_id);
            $this->authorize('enviar-notificaciones-masivas', $edificio);

            $resultado = $this->notificacionesService->enviarMasivo(
                $request->edificio_id,
                $request->tipo,
                $request->datos,
                $request->canales ?? ['email'],
                $request->filtros ?? []
            );

            Log::info('Notificación masiva enviada', [
                'edificio_id' => $request->edificio_id,
                'tipo' => $request->tipo,
                'destinatarios' => $resultado['total_destinatarios'] ?? 0,
            ]);

            return response()->json([
                'success' => true,
                'data' => $resultado,
                'mensaje' => "Notificación enviada a {$resultado['total_destinatarios']} destinatarios",
            ]);

        } catch (\Exception $e) {
            Log::error('Error en envío masivo', [
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Error al enviar notificación masiva',
            ], 500);
        }
    }

    /**
     * Programar notificación para envío futuro
     * 
     * POST /api/v1/notificaciones/programar
     */
    public function programar(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'edificio_id' => 'required|integer|exists:edificios,id',
            'copropietario_id' => 'nullable|integer|exists:copropietarios,id',
            'tipo' => 'required|string',
            'datos' => 'required|array',
            'fecha_envio' => 'required|date|after:now',
            'canales' => 'nullable|array',
            'es_masivo' => 'nullable|boolean',
            'filtros' => 'nullable|array',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $edificio = Edificio::findOrFail($request->edificio_id);
            $this->authorize('programar-notificaciones', $edificio);

            $resultado = $this->notificacionesService->programar(
                $request->edificio_id,
                $request->copropietario_id,
                $request->tipo,
                $request->datos,
                $request->fecha_envio,
                $request->canales ?? ['email'],
                $request->es_masivo ?? false,
                $request->filtros ?? []
            );

            return response()->json([
                'success' => true,
                'data' => [
                    'notificacion_id' => $resultado['id'],
                    'fecha_programada' => $resultado['fecha_envio'],
                    'estado' => 'programada',
                ],
                'mensaje' => 'Notificación programada exitosamente',
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al programar notificación',
            ], 500);
        }
    }

    /**
     * Cancelar notificación programada
     * 
     * DELETE /api/v1/notificaciones/programadas/{id}
     */
    public function cancelarProgramada(int $id): JsonResponse
    {
        try {
            $notificacion = \App\Models\NotificacionProgramada::findOrFail($id);
            $this->authorize('cancelar-notificacion', $notificacion->edificio);

            if ($notificacion->estado !== 'pendiente') {
                return response()->json([
                    'success' => false,
                    'error' => 'Solo se pueden cancelar notificaciones pendientes',
                ], 422);
            }

            $notificacion->update([
                'estado' => 'cancelada',
                'cancelada_por' => Auth::id(),
                'cancelada_at' => now(),
            ]);

            return response()->json([
                'success' => true,
                'mensaje' => 'Notificación cancelada',
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al cancelar notificación',
            ], 500);
        }
    }

    /**
     * Obtener historial de notificaciones
     * 
     * GET /api/v1/notificaciones/historial
     */
    public function historial(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'edificio_id' => 'required|integer|exists:edificios,id',
            'copropietario_id' => 'nullable|integer',
            'tipo' => 'nullable|string',
            'canal' => 'nullable|string|in:email,push,whatsapp',
            'estado' => 'nullable|string|in:enviado,fallido,pendiente',
            'desde' => 'nullable|date',
            'hasta' => 'nullable|date|after_or_equal:desde',
            'per_page' => 'nullable|integer|min:10|max:100',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $edificio = Edificio::findOrFail($request->edificio_id);
            $this->authorize('ver-notificaciones', $edificio);

            $historial = $this->notificacionesService->obtenerHistorial(
                $request->edificio_id,
                $request->copropietario_id,
                $request->tipo,
                $request->canal,
                $request->estado,
                $request->desde,
                $request->hasta,
                $request->per_page ?? 20
            );

            return response()->json([
                'success' => true,
                'data' => $historial['items'],
                'meta' => [
                    'total' => $historial['total'],
                    'pagina_actual' => $historial['pagina_actual'],
                    'ultima_pagina' => $historial['ultima_pagina'],
                ],
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al obtener historial',
            ], 500);
        }
    }

    /**
     * Obtener estadísticas de notificaciones
     * 
     * GET /api/v1/notificaciones/estadisticas/{edificioId}
     */
    public function estadisticas(int $edificioId, Request $request): JsonResponse
    {
        try {
            $edificio = Edificio::findOrFail($edificioId);
            $this->authorize('ver-notificaciones', $edificio);

            $desde = $request->desde ?? now()->subMonth()->format('Y-m-d');
            $hasta = $request->hasta ?? now()->format('Y-m-d');

            $estadisticas = $this->notificacionesService->obtenerEstadisticas(
                $edificioId,
                $desde,
                $hasta
            );

            return response()->json([
                'success' => true,
                'data' => [
                    'periodo' => [
                        'desde' => $desde,
                        'hasta' => $hasta,
                    ],
                    'resumen' => [
                        'total_enviadas' => $estadisticas['total_enviadas'],
                        'total_fallidas' => $estadisticas['total_fallidas'],
                        'tasa_exito' => $estadisticas['tasa_exito'],
                    ],
                    'por_tipo' => $estadisticas['por_tipo'],
                    'por_canal' => $estadisticas['por_canal'],
                    'tendencia_diaria' => $estadisticas['tendencia_diaria'] ?? [],
                ],
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al obtener estadísticas',
            ], 500);
        }
    }

    /**
     * Obtener preferencias de notificación del copropietario
     * 
     * GET /api/v1/notificaciones/preferencias/{copropietarioId}
     */
    public function obtenerPreferencias(int $copropietarioId): JsonResponse
    {
        try {
            $copropietario = Copropietario::findOrFail($copropietarioId);
            
            // Solo el propio copropietario o admin del edificio
            if (Auth::id() !== $copropietario->user_id) {
                $this->authorize('ver-preferencias-notificaciones', $copropietario->edificio);
            }

            $preferencias = PreferenciasNotificacion::where('copropietario_id', $copropietarioId)
                ->first();

            if (!$preferencias) {
                // Retornar preferencias por defecto
                $preferencias = $this->getPreferenciasDefecto();
            } else {
                $preferencias = json_decode($preferencias->configuracion, true);
            }

            return response()->json([
                'success' => true,
                'data' => $preferencias,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al obtener preferencias',
            ], 500);
        }
    }

    /**
     * Guardar preferencias de notificación
     * 
     * PUT /api/v1/notificaciones/preferencias/{copropietarioId}
     */
    public function guardarPreferencias(int $copropietarioId, Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'categorias' => 'required|array',
            'categorias.*.activo' => 'required|boolean',
            'categorias.*.canales' => 'required|array',
            'categorias.*.canales.*' => 'boolean',
            'horario_silencio' => 'nullable|array',
            'horario_silencio.activo' => 'boolean',
            'horario_silencio.desde' => 'required_if:horario_silencio.activo,true|date_format:H:i',
            'horario_silencio.hasta' => 'required_if:horario_silencio.activo,true|date_format:H:i',
            'idioma' => 'nullable|string|in:es,en',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $copropietario = Copropietario::findOrFail($copropietarioId);
            
            // Solo el propio copropietario puede modificar sus preferencias
            if (Auth::id() !== $copropietario->user_id) {
                return response()->json([
                    'success' => false,
                    'error' => 'No puede modificar preferencias de otro usuario',
                ], 403);
            }

            $this->notificacionesService->guardarPreferencias(
                $copropietarioId,
                $request->all()
            );

            return response()->json([
                'success' => true,
                'mensaje' => 'Preferencias guardadas',
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al guardar preferencias',
            ], 500);
        }
    }

    /**
     * Registrar suscripción push
     * 
     * POST /api/v1/notificaciones/push/suscribir
     */
    public function suscribirPush(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'copropietario_id' => 'required|integer|exists:copropietarios,id',
            'endpoint' => 'required|url',
            'keys' => 'required|array',
            'keys.p256dh' => 'required|string',
            'keys.auth' => 'required|string',
            'dispositivo' => 'nullable|string|max:100',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $copropietario = Copropietario::findOrFail($request->copropietario_id);
            
            // Verificar que es el propio usuario
            if (Auth::id() !== $copropietario->user_id) {
                return response()->json([
                    'success' => false,
                    'error' => 'No autorizado',
                ], 403);
            }

            $resultado = $this->notificacionesService->registrarSuscripcionPush(
                $request->copropietario_id,
                $request->endpoint,
                $request->keys['p256dh'],
                $request->keys['auth'],
                $request->dispositivo
            );

            return response()->json([
                'success' => true,
                'data' => [
                    'suscripcion_id' => $resultado['id'],
                ],
                'mensaje' => 'Suscripción push registrada',
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al registrar suscripción',
            ], 500);
        }
    }

    /**
     * Eliminar suscripción push
     * 
     * DELETE /api/v1/notificaciones/push/desuscribir
     */
    public function desuscribirPush(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'endpoint' => 'required|url',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            \App\Models\PushSubscription::where('endpoint', $request->endpoint)
                ->where('copropietario_id', function ($query) {
                    $query->select('id')
                        ->from('copropietarios')
                        ->where('user_id', Auth::id());
                })
                ->delete();

            return response()->json([
                'success' => true,
                'mensaje' => 'Suscripción eliminada',
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al eliminar suscripción',
            ], 500);
        }
    }

    /**
     * Obtener tipos de notificación disponibles
     * 
     * GET /api/v1/notificaciones/tipos
     */
    public function tipos(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data' => [
                'gastos_comunes' => [
                    ['codigo' => 'BOLETA_EMITIDA', 'nombre' => 'Boleta Emitida', 'descripcion' => 'Nueva boleta de gastos comunes'],
                    ['codigo' => 'PAGO_RECIBIDO', 'nombre' => 'Pago Recibido', 'descripcion' => 'Confirmación de pago'],
                    ['codigo' => 'MOROSIDAD_ALERTA', 'nombre' => 'Alerta Morosidad', 'descripcion' => 'Aviso de deuda pendiente'],
                ],
                'asambleas' => [
                    ['codigo' => 'CONVOCATORIA', 'nombre' => 'Convocatoria Asamblea', 'descripcion' => 'Citación a asamblea ordinaria/extraordinaria'],
                    ['codigo' => 'RECORDATORIO', 'nombre' => 'Recordatorio', 'descripcion' => 'Recordatorio previo a asamblea'],
                    ['codigo' => 'ACTA', 'nombre' => 'Acta Disponible', 'descripcion' => 'Acta de asamblea publicada'],
                ],
                'tributario' => [
                    ['codigo' => 'CERTIFICADO_RENTA', 'nombre' => 'Certificado de Renta', 'descripcion' => 'Certificado anual disponible'],
                    ['codigo' => 'DISTRIBUCION_APROBADA', 'nombre' => 'Distribución Aprobada', 'descripcion' => 'Nueva distribución de rentas'],
                ],
                'compliance' => [
                    ['codigo' => 'CERTIFICADO_COMPLIANCE', 'nombre' => 'Certificado Compliance', 'descripcion' => 'Nuevo certificado emitido'],
                    ['codigo' => 'ALERTA_CUMPLIMIENTO', 'nombre' => 'Alerta Cumplimiento', 'descripcion' => 'Vencimiento próximo de obligación'],
                ],
                'administracion' => [
                    ['codigo' => 'COMUNICADO_GENERAL', 'nombre' => 'Comunicado', 'descripcion' => 'Comunicación general de administración'],
                    ['codigo' => 'MANTENCION_PROGRAMADA', 'nombre' => 'Mantención', 'descripcion' => 'Aviso de mantención programada'],
                ],
                'proteccion_datos' => [
                    ['codigo' => 'ARCO_SOLICITUD_RECIBIDA', 'nombre' => 'Solicitud ARCO+ Recibida', 'descripcion' => 'Confirmación de recepción'],
                    ['codigo' => 'ARCO_SOLICITUD_RESUELTA', 'nombre' => 'Solicitud ARCO+ Resuelta', 'descripcion' => 'Resolución de solicitud'],
                    ['codigo' => 'BRECHA_SEGURIDAD', 'nombre' => 'Brecha de Seguridad', 'descripcion' => 'Notificación de incidente'],
                ],
            ],
        ]);
    }

    /**
     * Enviar notificación de prueba
     * 
     * POST /api/v1/notificaciones/test
     */
    public function test(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'canal' => 'required|string|in:email,push',
            'email' => 'required_if:canal,email|email',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            // Solo admins pueden enviar tests
            if (!Auth::user()->hasRole('admin')) {
                return response()->json([
                    'success' => false,
                    'error' => 'No autorizado',
                ], 403);
            }

            $resultado = [
                'canal' => $request->canal,
                'enviado' => true,
                'timestamp' => now()->format('Y-m-d H:i:s'),
            ];

            if ($request->canal === 'email') {
                \Mail::raw('Esto es una notificación de prueba de DATAPOLIS PRO', function ($message) use ($request) {
                    $message->to($request->email)
                        ->subject('🧪 Test DATAPOLIS - Notificación de Prueba');
                });
                $resultado['destinatario'] = $request->email;
            }

            return response()->json([
                'success' => true,
                'data' => $resultado,
                'mensaje' => 'Notificación de prueba enviada',
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al enviar test: ' . $e->getMessage(),
            ], 500);
        }
    }

    // === Métodos auxiliares ===

    private function getPreferenciasDefecto(): array
    {
        return [
            'categorias' => [
                'gastos_comunes' => [
                    'activo' => true,
                    'canales' => ['email' => true, 'push' => true],
                ],
                'asambleas' => [
                    'activo' => true,
                    'canales' => ['email' => true, 'push' => true],
                ],
                'tributario' => [
                    'activo' => true,
                    'canales' => ['email' => true, 'push' => false],
                ],
                'compliance' => [
                    'activo' => true,
                    'canales' => ['email' => true, 'push' => false],
                ],
                'administracion' => [
                    'activo' => true,
                    'canales' => ['email' => true, 'push' => true],
                ],
                'proteccion_datos' => [
                    'activo' => true,
                    'canales' => ['email' => true, 'push' => true],
                ],
            ],
            'horario_silencio' => [
                'activo' => true,
                'desde' => '22:00',
                'hasta' => '08:00',
            ],
            'idioma' => 'es',
        ];
    }
}
