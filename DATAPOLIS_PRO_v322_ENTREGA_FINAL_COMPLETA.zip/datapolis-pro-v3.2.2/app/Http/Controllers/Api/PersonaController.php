<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

/**
 * DATAPOLIS PRO v3.0 - Persona Controller
 */
class PersonaController extends Controller
{
    /**
     * Listar personas
     */
    public function index(Request $request): JsonResponse
    {
        $query = DB::table('personas')
            ->where('tenant_id', Auth::user()->tenant_id)
            ->whereNull('deleted_at');

        if ($request->tipo) {
            $query->where('tipo', $request->tipo);
        }

        if ($request->search) {
            $query->where(function ($q) use ($request) {
                $q->where('nombre_completo', 'like', "%{$request->search}%")
                  ->orWhere('rut', 'like', "%{$request->search}%")
                  ->orWhere('email', 'like', "%{$request->search}%");
            });
        }

        $personas = $query->orderBy('nombre_completo')->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $personas]);
    }

    /**
     * Crear persona
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'rut' => 'required|string|max:12',
            'nombre' => 'required|string|max:100',
            'apellido_paterno' => 'required|string|max:100',
            'email' => 'nullable|email|max:200',
            'telefono' => 'nullable|string|max:20',
            'tipo' => 'required|in:propietario,arrendatario,residente,proveedor,otro',
        ]);

        // Verificar RUT único en el tenant
        $existe = DB::table('personas')
            ->where('tenant_id', Auth::user()->tenant_id)
            ->where('rut', $request->rut)
            ->whereNull('deleted_at')
            ->exists();

        if ($existe) {
            return response()->json([
                'success' => false,
                'message' => 'Ya existe una persona con ese RUT',
            ], 422);
        }

        $nombreCompleto = trim("{$request->nombre} {$request->apellido_paterno} {$request->apellido_materno}");

        $id = DB::table('personas')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'rut' => $this->formatearRut($request->rut),
            'nombre' => $request->nombre,
            'apellido_paterno' => $request->apellido_paterno,
            'apellido_materno' => $request->apellido_materno,
            'nombre_completo' => $nombreCompleto,
            'email' => $request->email,
            'telefono' => $request->telefono,
            'direccion' => $request->direccion,
            'comuna' => $request->comuna,
            'tipo' => $request->tipo,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Persona creada exitosamente',
            'id' => $id,
        ], 201);
    }

    /**
     * Mostrar persona
     */
    public function show(int $id): JsonResponse
    {
        $persona = DB::table('personas')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->whereNull('deleted_at')
            ->first();

        if (!$persona) {
            return response()->json(['success' => false, 'message' => 'Persona no encontrada'], 404);
        }

        // Obtener unidades asociadas
        $unidades = DB::table('unidades')
            ->leftJoin('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->where('unidades.propietario_id', $id)
            ->whereNull('unidades.deleted_at')
            ->select('unidades.*', 'edificios.nombre as edificio_nombre')
            ->get();

        $persona->unidades = $unidades;

        return response()->json(['success' => true, 'data' => $persona]);
    }

    /**
     * Actualizar persona
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $persona = DB::table('personas')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$persona) {
            return response()->json(['success' => false, 'message' => 'Persona no encontrada'], 404);
        }

        $request->validate([
            'nombre' => 'sometimes|string|max:100',
            'apellido_paterno' => 'sometimes|string|max:100',
            'email' => 'nullable|email|max:200',
        ]);

        $data = array_filter($request->only([
            'nombre', 'apellido_paterno', 'apellido_materno',
            'email', 'telefono', 'direccion', 'comuna', 'tipo',
        ]), fn($v) => $v !== null);

        // Recalcular nombre completo si se actualizan nombres
        if (isset($data['nombre']) || isset($data['apellido_paterno']) || isset($data['apellido_materno'])) {
            $nombre = $data['nombre'] ?? $persona->nombre;
            $apellidoP = $data['apellido_paterno'] ?? $persona->apellido_paterno;
            $apellidoM = $data['apellido_materno'] ?? $persona->apellido_materno;
            $data['nombre_completo'] = trim("{$nombre} {$apellidoP} {$apellidoM}");
        }

        $data['updated_at'] = now();

        DB::table('personas')->where('id', $id)->update($data);

        return response()->json(['success' => true, 'message' => 'Persona actualizada']);
    }

    /**
     * Eliminar persona
     */
    public function destroy(int $id): JsonResponse
    {
        $persona = DB::table('personas')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$persona) {
            return response()->json(['success' => false, 'message' => 'Persona no encontrada'], 404);
        }

        // Verificar que no sea propietario de unidades
        $unidades = DB::table('unidades')
            ->where('propietario_id', $id)
            ->whereNull('deleted_at')
            ->count();

        if ($unidades > 0) {
            return response()->json([
                'success' => false,
                'message' => "No se puede eliminar: es propietario de {$unidades} unidades",
            ], 422);
        }

        DB::table('personas')->where('id', $id)->update([
            'deleted_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Persona eliminada']);
    }

    /**
     * Buscar personas por RUT o nombre
     */
    public function buscar(Request $request): JsonResponse
    {
        $request->validate([
            'q' => 'required|string|min:2',
        ]);

        $personas = DB::table('personas')
            ->where('tenant_id', Auth::user()->tenant_id)
            ->whereNull('deleted_at')
            ->where(function ($query) use ($request) {
                $query->where('nombre_completo', 'like', "%{$request->q}%")
                      ->orWhere('rut', 'like', "%{$request->q}%");
            })
            ->select('id', 'rut', 'nombre_completo', 'email', 'tipo')
            ->limit(20)
            ->get();

        return response()->json(['success' => true, 'data' => $personas]);
    }

    /**
     * Formatear RUT chileno
     */
    private function formatearRut(string $rut): string
    {
        $rut = preg_replace('/[^0-9kK]/', '', $rut);
        
        if (strlen($rut) < 2) {
            return $rut;
        }

        $dv = strtoupper(substr($rut, -1));
        $numero = substr($rut, 0, -1);
        $numeroFormateado = number_format((int) $numero, 0, '', '.');

        return "{$numeroFormateado}-{$dv}";
    }
}
