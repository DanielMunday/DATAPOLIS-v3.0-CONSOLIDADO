<?php

namespace App\Http\Controllers\Api\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - Documentos, Comunicados, Reservas y Votaciones
 * Portal Copropietarios
 */
class DocumentosComunicadosController extends Controller
{
    // =========================================================
    // DOCUMENTOS COMPARTIDOS
    // =========================================================

    /**
     * Listar documentos disponibles
     */
    public function documentos(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        $categoria = $request->get('categoria');

        $query = DB::table('documentos_compartidos')
            ->where('edificio_id', $edificioId)
            ->where('visible_portal', true)
            ->whereNull('deleted_at');

        if ($categoria) {
            $query->where('categoria', $categoria);
        }

        $documentos = $query
            ->orderByDesc('destacado')
            ->orderByDesc('created_at')
            ->get();

        // Categorías disponibles
        $categorias = DB::table('documentos_compartidos')
            ->where('edificio_id', $edificioId)
            ->where('visible_portal', true)
            ->whereNull('deleted_at')
            ->distinct()
            ->pluck('categoria');

        return response()->json([
            'success' => true,
            'data' => [
                'documentos' => $documentos->map(function ($d) {
                    return [
                        'id' => $d->id,
                        'nombre' => $d->nombre,
                        'descripcion' => $d->descripcion,
                        'categoria' => $d->categoria,
                        'fecha_documento' => $d->fecha_documento,
                        'destacado' => $d->destacado,
                        'archivo_size' => $this->formatearBytes($d->archivo_size),
                        'descargas' => $d->descargas_count,
                        'created_at' => $d->created_at,
                    ];
                }),
                'categorias' => $categorias,
            ],
        ]);
    }

    /**
     * Descargar documento
     */
    public function descargarDocumento(Request $request, int $id)
    {
        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        $documento = DB::table('documentos_compartidos')
            ->where('id', $id)
            ->where('edificio_id', $edificioId)
            ->where('visible_portal', true)
            ->first();

        if (!$documento) {
            return response()->json([
                'success' => false,
                'message' => 'Documento no encontrado.'
            ], 404);
        }

        // Registrar descarga
        DB::table('log_descargas_documentos')->insert([
            'documento_id' => $id,
            'acceso_id' => $acceso->id,
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'created_at' => now(),
        ]);

        // Incrementar contador
        DB::table('documentos_compartidos')
            ->where('id', $id)
            ->increment('descargas_count');

        // Retornar archivo
        $path = Storage::disk('public')->path($documento->archivo_path);
        
        return response()->download($path, $documento->archivo_nombre, [
            'Content-Type' => $documento->archivo_mime,
        ]);
    }

    // =========================================================
    // COMUNICADOS
    // =========================================================

    /**
     * Listar comunicados
     */
    public function comunicados(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        $comunicados = DB::table('comunicados')
            ->leftJoin('lecturas_comunicados', function ($join) use ($acceso) {
                $join->on('comunicados.id', '=', 'lecturas_comunicados.comunicado_id')
                    ->where('lecturas_comunicados.acceso_id', '=', $acceso->id);
            })
            ->where('comunicados.edificio_id', $edificioId)
            ->where('comunicados.publicado', true)
            ->where(function ($q) {
                $q->whereNull('comunicados.vigente_hasta')
                  ->orWhere('comunicados.vigente_hasta', '>=', now());
            })
            ->select(
                'comunicados.*',
                'lecturas_comunicados.leido_at'
            )
            ->orderByDesc('comunicados.fijado')
            ->orderByDesc('comunicados.publicado_at')
            ->paginate(20);

        // Contar no leídos
        $noLeidos = DB::table('comunicados')
            ->leftJoin('lecturas_comunicados', function ($join) use ($acceso) {
                $join->on('comunicados.id', '=', 'lecturas_comunicados.comunicado_id')
                    ->where('lecturas_comunicados.acceso_id', '=', $acceso->id);
            })
            ->where('comunicados.edificio_id', $edificioId)
            ->where('comunicados.publicado', true)
            ->whereNull('lecturas_comunicados.id')
            ->count();

        return response()->json([
            'success' => true,
            'data' => [
                'comunicados' => $comunicados,
                'no_leidos' => $noLeidos,
            ],
        ]);
    }

    /**
     * Ver comunicado
     */
    public function verComunicado(Request $request, int $id): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        $comunicado = DB::table('comunicados')
            ->where('id', $id)
            ->where('edificio_id', $edificioId)
            ->where('publicado', true)
            ->first();

        if (!$comunicado) {
            return response()->json([
                'success' => false,
                'message' => 'Comunicado no encontrado.'
            ], 404);
        }

        // Marcar como leído
        DB::table('lecturas_comunicados')->updateOrInsert(
            ['comunicado_id' => $id, 'acceso_id' => $acceso->id],
            ['leido_at' => now()]
        );

        // Incrementar lecturas
        DB::table('comunicados')->where('id', $id)->increment('lecturas_count');

        return response()->json([
            'success' => true,
            'data' => [
                'comunicado' => [
                    'id' => $comunicado->id,
                    'titulo' => $comunicado->titulo,
                    'contenido' => $comunicado->contenido,
                    'tipo' => $comunicado->tipo,
                    'prioridad' => $comunicado->prioridad,
                    'archivos_adjuntos' => json_decode($comunicado->archivos_adjuntos ?? '[]'),
                    'publicado_at' => $comunicado->publicado_at,
                ],
            ],
        ]);
    }

    // =========================================================
    // RESERVAS DE ESPACIOS COMUNES
    // =========================================================

    /**
     * Listar espacios comunes disponibles
     */
    public function espaciosComunes(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        $espacios = DB::table('espacios_comunes')
            ->where('edificio_id', $edificioId)
            ->where('activo', true)
            ->whereNull('deleted_at')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'espacios' => $espacios->map(function ($e) {
                    return [
                        'id' => $e->id,
                        'nombre' => $e->nombre,
                        'descripcion' => $e->descripcion,
                        'tipo' => $e->tipo,
                        'capacidad_maxima' => $e->capacidad_maxima,
                        'requiere_reserva' => $e->requiere_reserva,
                        'tiene_costo' => $e->tiene_costo,
                        'costo_hora' => $e->costo_hora,
                        'garantia' => $e->garantia,
                        'duracion_minima' => $e->duracion_minima_minutos,
                        'duracion_maxima' => $e->duracion_maxima_minutos,
                        'anticipacion_minima' => $e->anticipacion_minima_horas,
                        'anticipacion_maxima' => $e->anticipacion_maxima_dias,
                        'reservas_maximas_mes' => $e->reservas_maximas_mes,
                        'reglas_uso' => $e->reglas_uso,
                        'imagenes' => json_decode($e->imagenes ?? '[]'),
                        'horarios' => json_decode($e->horarios_disponibles ?? '{}'),
                    ];
                }),
            ],
        ]);
    }

    /**
     * Ver disponibilidad de un espacio
     */
    public function disponibilidadEspacio(Request $request, int $espacioId): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        $espacio = DB::table('espacios_comunes')
            ->where('id', $espacioId)
            ->where('edificio_id', $edificioId)
            ->where('activo', true)
            ->first();

        if (!$espacio) {
            return response()->json([
                'success' => false,
                'message' => 'Espacio no encontrado.'
            ], 404);
        }

        $fecha = $request->get('fecha', now()->toDateString());

        // Reservas del día
        $reservasDelDia = DB::table('reservas_espacios')
            ->where('espacio_id', $espacioId)
            ->where('fecha', $fecha)
            ->whereIn('estado', ['pendiente', 'confirmada'])
            ->select('hora_inicio', 'hora_fin')
            ->get();

        // Mis reservas del mes
        $mesActual = Carbon::parse($fecha);
        $misReservasMes = DB::table('reservas_espacios')
            ->where('espacio_id', $espacioId)
            ->where('acceso_id', $acceso->id)
            ->whereYear('fecha', $mesActual->year)
            ->whereMonth('fecha', $mesActual->month)
            ->whereIn('estado', ['pendiente', 'confirmada', 'completada'])
            ->count();

        return response()->json([
            'success' => true,
            'data' => [
                'espacio' => $espacio->nombre,
                'fecha' => $fecha,
                'reservas_ocupadas' => $reservasDelDia,
                'mis_reservas_mes' => $misReservasMes,
                'limite_reservas_mes' => $espacio->reservas_maximas_mes,
                'puede_reservar' => $misReservasMes < $espacio->reservas_maximas_mes,
            ],
        ]);
    }

    /**
     * Crear reserva
     */
    public function crearReserva(Request $request): JsonResponse
    {
        $request->validate([
            'espacio_id' => 'required|integer',
            'fecha' => 'required|date|after_or_equal:today',
            'hora_inicio' => 'required|date_format:H:i',
            'hora_fin' => 'required|date_format:H:i|after:hora_inicio',
            'cantidad_personas' => 'nullable|integer|min:1',
            'motivo' => 'nullable|string|max:500',
        ]);

        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        // Verificar espacio
        $espacio = DB::table('espacios_comunes')
            ->where('id', $request->espacio_id)
            ->where('edificio_id', $edificioId)
            ->where('activo', true)
            ->first();

        if (!$espacio) {
            return response()->json([
                'success' => false,
                'message' => 'Espacio no disponible.'
            ], 400);
        }

        // Verificar límite mensual
        $mesReserva = Carbon::parse($request->fecha);
        $reservasMes = DB::table('reservas_espacios')
            ->where('espacio_id', $request->espacio_id)
            ->where('acceso_id', $acceso->id)
            ->whereYear('fecha', $mesReserva->year)
            ->whereMonth('fecha', $mesReserva->month)
            ->whereIn('estado', ['pendiente', 'confirmada', 'completada'])
            ->count();

        if ($reservasMes >= $espacio->reservas_maximas_mes) {
            return response()->json([
                'success' => false,
                'message' => "Límite de reservas mensuales alcanzado ({$espacio->reservas_maximas_mes})."
            ], 400);
        }

        // Verificar conflictos
        $conflicto = DB::table('reservas_espacios')
            ->where('espacio_id', $request->espacio_id)
            ->where('fecha', $request->fecha)
            ->whereIn('estado', ['pendiente', 'confirmada'])
            ->where(function ($q) use ($request) {
                $q->whereBetween('hora_inicio', [$request->hora_inicio, $request->hora_fin])
                  ->orWhereBetween('hora_fin', [$request->hora_inicio, $request->hora_fin])
                  ->orWhere(function ($q2) use ($request) {
                      $q2->where('hora_inicio', '<=', $request->hora_inicio)
                         ->where('hora_fin', '>=', $request->hora_fin);
                  });
            })
            ->exists();

        if ($conflicto) {
            return response()->json([
                'success' => false,
                'message' => 'El horario seleccionado no está disponible.'
            ], 400);
        }

        // Calcular costo
        $horaInicio = Carbon::parse($request->hora_inicio);
        $horaFin = Carbon::parse($request->hora_fin);
        $horas = $horaFin->diffInMinutes($horaInicio) / 60;
        $costoTotal = $espacio->tiene_costo ? ($espacio->costo_hora * $horas) : 0;

        // Crear reserva
        $codigoReserva = strtoupper(Str::random(6));

        $reservaId = DB::table('reservas_espacios')->insertGetId([
            'tenant_id' => $acceso->tenant_id,
            'espacio_id' => $request->espacio_id,
            'unidad_id' => $acceso->unidad_id,
            'acceso_id' => $acceso->id,
            'codigo_reserva' => $codigoReserva,
            'fecha' => $request->fecha,
            'hora_inicio' => $request->hora_inicio,
            'hora_fin' => $request->hora_fin,
            'cantidad_personas' => $request->cantidad_personas,
            'motivo' => $request->motivo,
            'estado' => 'pendiente',
            'costo_total' => $costoTotal,
            'garantia' => $espacio->garantia,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Reserva creada exitosamente.',
            'data' => [
                'id' => $reservaId,
                'codigo' => $codigoReserva,
                'costo_total' => $costoTotal,
                'requiere_pago' => $costoTotal > 0,
            ],
        ], 201);
    }

    /**
     * Mis reservas
     */
    public function misReservas(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $reservas = DB::table('reservas_espacios')
            ->join('espacios_comunes', 'reservas_espacios.espacio_id', '=', 'espacios_comunes.id')
            ->where('reservas_espacios.acceso_id', $acceso->id)
            ->whereNull('reservas_espacios.deleted_at')
            ->select(
                'reservas_espacios.*',
                'espacios_comunes.nombre as espacio_nombre'
            )
            ->orderByDesc('reservas_espacios.fecha')
            ->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $reservas,
        ]);
    }

    /**
     * Cancelar reserva
     */
    public function cancelarReserva(Request $request, int $id): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $reserva = DB::table('reservas_espacios')
            ->where('id', $id)
            ->where('acceso_id', $acceso->id)
            ->whereIn('estado', ['pendiente', 'confirmada'])
            ->where('fecha', '>', now()->toDateString())
            ->first();

        if (!$reserva) {
            return response()->json([
                'success' => false,
                'message' => 'Reserva no puede ser cancelada.'
            ], 400);
        }

        DB::table('reservas_espacios')
            ->where('id', $id)
            ->update([
                'estado' => 'cancelada',
                'cancelada_at' => now(),
                'motivo_cancelacion' => 'Cancelada por el usuario',
                'cancelada_por' => $acceso->id,
                'updated_at' => now(),
            ]);

        return response()->json([
            'success' => true,
            'message' => 'Reserva cancelada.'
        ]);
    }

    // =========================================================
    // VOTACIONES
    // =========================================================

    /**
     * Listar votaciones disponibles
     */
    public function votaciones(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        $votaciones = DB::table('votaciones_online')
            ->leftJoin('votos', function ($join) use ($acceso) {
                $join->on('votaciones_online.id', '=', 'votos.votacion_id')
                    ->where('votos.unidad_id', '=', $acceso->unidad_id);
            })
            ->where('votaciones_online.edificio_id', $edificioId)
            ->whereIn('votaciones_online.estado', ['activa', 'cerrada'])
            ->select(
                'votaciones_online.*',
                'votos.id as mi_voto_id',
                'votos.opcion_seleccionada'
            )
            ->orderByDesc('votaciones_online.fin_votacion')
            ->paginate(15);

        return response()->json([
            'success' => true,
            'data' => $votaciones,
        ]);
    }

    /**
     * Ver detalle de votación
     */
    public function verVotacion(Request $request, int $id): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        $votacion = DB::table('votaciones_online')
            ->where('id', $id)
            ->where('edificio_id', $edificioId)
            ->first();

        if (!$votacion) {
            return response()->json([
                'success' => false,
                'message' => 'Votación no encontrada.'
            ], 404);
        }

        // Mi voto
        $miVoto = DB::table('votos')
            ->where('votacion_id', $id)
            ->where('unidad_id', $acceso->unidad_id)
            ->first();

        // Resultados (si votación cerrada o ya voté)
        $resultados = null;
        if ($votacion->estado === 'cerrada' || $miVoto) {
            $resultados = json_decode($votacion->resultados ?? '{}');
        }

        return response()->json([
            'success' => true,
            'data' => [
                'votacion' => [
                    'id' => $votacion->id,
                    'titulo' => $votacion->titulo,
                    'descripcion' => $votacion->descripcion,
                    'tipo' => $votacion->tipo,
                    'opciones' => json_decode($votacion->opciones),
                    'permite_abstencion' => $votacion->permite_abstencion,
                    'estado' => $votacion->estado,
                    'inicio' => $votacion->inicio_votacion,
                    'fin' => $votacion->fin_votacion,
                    'quorum_requerido' => $votacion->quorum_requerido,
                    'quorum_alcanzado' => $votacion->quorum_alcanzado,
                    'documentos' => json_decode($votacion->documentos_adjuntos ?? '[]'),
                ],
                'mi_voto' => $miVoto ? [
                    'opcion' => $miVoto->opcion_seleccionada,
                    'fecha' => $miVoto->created_at,
                ] : null,
                'puede_votar' => $votacion->estado === 'activa' && !$miVoto,
                'resultados' => $resultados,
            ],
        ]);
    }

    /**
     * Emitir voto
     */
    public function votar(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'opcion' => 'required|string|max:50',
        ]);

        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        $votacion = DB::table('votaciones_online')
            ->where('id', $id)
            ->where('edificio_id', $edificioId)
            ->where('estado', 'activa')
            ->where('fin_votacion', '>=', now())
            ->first();

        if (!$votacion) {
            return response()->json([
                'success' => false,
                'message' => 'Votación no disponible.'
            ], 400);
        }

        // Verificar si ya votó
        $yaVoto = DB::table('votos')
            ->where('votacion_id', $id)
            ->where('unidad_id', $acceso->unidad_id)
            ->exists();

        if ($yaVoto) {
            return response()->json([
                'success' => false,
                'message' => 'Ya has emitido tu voto.'
            ], 400);
        }

        // Validar opción
        $opciones = json_decode($votacion->opciones, true);
        if (!in_array($request->opcion, $opciones) && $request->opcion !== 'abstencion') {
            return response()->json([
                'success' => false,
                'message' => 'Opción de voto inválida.'
            ], 400);
        }

        // Obtener prorrateo de la unidad
        $unidad = DB::table('unidades')->where('id', $acceso->unidad_id)->first();

        // Generar hash del voto
        $hashVoto = hash('sha256', $id . $acceso->unidad_id . $request->opcion . now()->timestamp);

        // Registrar voto
        DB::table('votos')->insert([
            'votacion_id' => $id,
            'unidad_id' => $acceso->unidad_id,
            'acceso_id' => $acceso->id,
            'opcion_seleccionada' => $request->opcion,
            'prorrateo_unidad' => $unidad->prorrateo,
            'hash_voto' => $hashVoto,
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Actualizar quórum
        $this->actualizarQuorum($id);

        return response()->json([
            'success' => true,
            'message' => 'Voto registrado exitosamente.',
            'data' => [
                'hash_verificacion' => $hashVoto,
            ],
        ]);
    }

    /**
     * Actualizar quórum de votación
     */
    private function actualizarQuorum(int $votacionId): void
    {
        $totalProrrateo = DB::table('votos')
            ->where('votacion_id', $votacionId)
            ->sum('prorrateo_unidad');

        DB::table('votaciones_online')
            ->where('id', $votacionId)
            ->update([
                'quorum_alcanzado' => $totalProrrateo,
                'updated_at' => now(),
            ]);
    }

    // =========================================================
    // NOTIFICACIONES
    // =========================================================

    /**
     * Listar notificaciones
     */
    public function notificaciones(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $notificaciones = DB::table('notificaciones_portal')
            ->where('acceso_id', $acceso->id)
            ->orderByDesc('created_at')
            ->paginate(30);

        $noLeidas = DB::table('notificaciones_portal')
            ->where('acceso_id', $acceso->id)
            ->where('leida', false)
            ->count();

        return response()->json([
            'success' => true,
            'data' => [
                'notificaciones' => $notificaciones,
                'no_leidas' => $noLeidas,
            ],
        ]);
    }

    /**
     * Marcar notificación como leída
     */
    public function marcarLeida(Request $request, int $id): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        DB::table('notificaciones_portal')
            ->where('id', $id)
            ->where('acceso_id', $acceso->id)
            ->update([
                'leida' => true,
                'leida_at' => now(),
            ]);

        return response()->json(['success' => true]);
    }

    /**
     * Marcar todas como leídas
     */
    public function marcarTodasLeidas(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        DB::table('notificaciones_portal')
            ->where('acceso_id', $acceso->id)
            ->where('leida', false)
            ->update([
                'leida' => true,
                'leida_at' => now(),
            ]);

        return response()->json(['success' => true]);
    }

    // =========================================================
    // HELPERS
    // =========================================================

    private function formatearBytes(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 2) . ' ' . $units[$i];
    }
}
