<?php

namespace App\Http\Controllers\Api\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Barryvdh\DomPDF\Facade\Pdf;

/**
 * DATAPOLIS PRO v3.0 - Estado de Cuenta y Boletas
 * Portal Copropietarios
 */
class EstadoCuentaController extends Controller
{
    /**
     * Obtener estado de cuenta completo
     */
    public function index(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $unidadId = $acceso->unidad_id;

        // Boletas pendientes
        $boletasPendientes = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $unidadId)
            ->whereIn('boletas_gc.estado', ['pendiente', 'vencida'])
            ->select(
                'boletas_gc.*',
                'periodos_gc.mes',
                'periodos_gc.anio',
                DB::raw('boletas_gc.total_a_pagar - COALESCE(boletas_gc.total_abonos, 0) as saldo_pendiente')
            )
            ->orderBy('periodos_gc.anio')
            ->orderBy('periodos_gc.mes')
            ->get();

        // Calcular totales
        $totalPendiente = $boletasPendientes->sum('saldo_pendiente');
        $totalVencido = $boletasPendientes->where('estado', 'vencida')->sum('saldo_pendiente');
        $totalIntereses = $boletasPendientes->sum('interes_mora');

        // Resumen por año
        $resumenAnual = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $unidadId)
            ->groupBy('periodos_gc.anio')
            ->select(
                'periodos_gc.anio',
                DB::raw('SUM(boletas_gc.total_a_pagar) as total_emitido'),
                DB::raw('SUM(COALESCE(boletas_gc.total_abonos, 0)) as total_pagado'),
                DB::raw('SUM(boletas_gc.total_a_pagar - COALESCE(boletas_gc.total_abonos, 0)) as saldo')
            )
            ->orderByDesc('periodos_gc.anio')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'resumen' => [
                    'total_pendiente' => $totalPendiente,
                    'total_vencido' => $totalVencido,
                    'total_intereses' => $totalIntereses,
                    'boletas_pendientes' => $boletasPendientes->count(),
                    'boletas_vencidas' => $boletasPendientes->where('estado', 'vencida')->count(),
                ],
                'boletas_pendientes' => $boletasPendientes->map(function ($b) {
                    return [
                        'id' => $b->id,
                        'periodo' => sprintf('%02d/%d', $b->mes, $b->anio),
                        'mes' => $b->mes,
                        'anio' => $b->anio,
                        'total_a_pagar' => $b->total_a_pagar,
                        'total_abonos' => $b->total_abonos ?? 0,
                        'saldo_pendiente' => $b->saldo_pendiente,
                        'interes_mora' => $b->interes_mora ?? 0,
                        'estado' => $b->estado,
                        'fecha_vencimiento' => $b->fecha_vencimiento,
                        'dias_mora' => $b->dias_mora ?? 0,
                    ];
                }),
                'resumen_anual' => $resumenAnual,
            ],
        ]);
    }

    /**
     * Historial de boletas
     */
    public function historial(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $unidadId = $acceso->unidad_id;

        $anio = $request->get('anio', now()->year);
        $estado = $request->get('estado');

        $query = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $unidadId)
            ->where('periodos_gc.anio', $anio);

        if ($estado) {
            $query->where('boletas_gc.estado', $estado);
        }

        $boletas = $query
            ->select(
                'boletas_gc.*',
                'periodos_gc.mes',
                'periodos_gc.anio'
            )
            ->orderByDesc('periodos_gc.mes')
            ->get();

        // Años disponibles
        $aniosDisponibles = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $unidadId)
            ->distinct()
            ->pluck('periodos_gc.anio')
            ->sort()
            ->values();

        return response()->json([
            'success' => true,
            'data' => [
                'anio_actual' => $anio,
                'anios_disponibles' => $aniosDisponibles,
                'boletas' => $boletas->map(function ($b) {
                    return [
                        'id' => $b->id,
                        'periodo' => sprintf('%02d/%d', $b->mes, $b->anio),
                        'gasto_comun' => $b->gasto_comun,
                        'fondo_reserva' => $b->fondo_reserva,
                        'otros_cargos' => $b->otros_cargos ?? 0,
                        'total_a_pagar' => $b->total_a_pagar,
                        'total_abonos' => $b->total_abonos ?? 0,
                        'saldo' => $b->total_a_pagar - ($b->total_abonos ?? 0),
                        'estado' => $b->estado,
                        'fecha_emision' => $b->fecha_emision,
                        'fecha_vencimiento' => $b->fecha_vencimiento,
                        'fecha_pago' => $b->fecha_pago,
                    ];
                }),
            ],
        ]);
    }

    /**
     * Detalle de una boleta específica
     */
    public function detalleBoleta(Request $request, int $boletaId): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $boleta = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.id', $boletaId)
            ->where('boletas_gc.unidad_id', $acceso->unidad_id)
            ->select('boletas_gc.*', 'periodos_gc.mes', 'periodos_gc.anio')
            ->first();

        if (!$boleta) {
            return response()->json([
                'success' => false,
                'message' => 'Boleta no encontrada.'
            ], 404);
        }

        // Detalle de cargos
        $detalleCargos = DB::table('detalle_boletas_gc')
            ->where('boleta_id', $boletaId)
            ->get();

        // Pagos asociados
        $pagos = DB::table('pagos_gc')
            ->where('boleta_id', $boletaId)
            ->orderBy('fecha_pago')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'boleta' => [
                    'id' => $boleta->id,
                    'periodo' => sprintf('%02d/%d', $boleta->mes, $boleta->anio),
                    'gasto_comun' => $boleta->gasto_comun,
                    'fondo_reserva' => $boleta->fondo_reserva,
                    'otros_cargos' => $boleta->otros_cargos ?? 0,
                    'descuentos' => $boleta->descuentos ?? 0,
                    'interes_mora' => $boleta->interes_mora ?? 0,
                    'total_a_pagar' => $boleta->total_a_pagar,
                    'total_abonos' => $boleta->total_abonos ?? 0,
                    'saldo_pendiente' => $boleta->total_a_pagar - ($boleta->total_abonos ?? 0),
                    'estado' => $boleta->estado,
                    'fecha_emision' => $boleta->fecha_emision,
                    'fecha_vencimiento' => $boleta->fecha_vencimiento,
                    'dias_mora' => $boleta->dias_mora ?? 0,
                ],
                'detalle_cargos' => $detalleCargos->map(function ($d) {
                    return [
                        'concepto' => $d->concepto,
                        'descripcion' => $d->descripcion,
                        'monto' => $d->monto,
                    ];
                }),
                'pagos' => $pagos->map(function ($p) {
                    return [
                        'id' => $p->id,
                        'fecha' => $p->fecha_pago,
                        'monto' => $p->monto,
                        'medio_pago' => $p->medio_pago,
                        'comprobante' => $p->numero_comprobante,
                    ];
                }),
            ],
        ]);
    }

    /**
     * Descargar boleta en PDF
     */
    public function descargarBoletaPdf(Request $request, int $boletaId)
    {
        $acceso = $request->attributes->get('acceso_portal');

        $boleta = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->join('unidades', 'boletas_gc.unidad_id', '=', 'unidades.id')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('boletas_gc.id', $boletaId)
            ->where('boletas_gc.unidad_id', $acceso->unidad_id)
            ->select(
                'boletas_gc.*',
                'periodos_gc.mes',
                'periodos_gc.anio',
                'unidades.numero as unidad_numero',
                'unidades.tipo as unidad_tipo',
                'edificios.nombre as edificio_nombre',
                'edificios.direccion as edificio_direccion',
                'edificios.rut as edificio_rut',
                'personas.nombre_completo as propietario_nombre',
                'personas.rut as propietario_rut'
            )
            ->first();

        if (!$boleta) {
            return response()->json([
                'success' => false,
                'message' => 'Boleta no encontrada.'
            ], 404);
        }

        // Detalle de cargos
        $detalleCargos = DB::table('detalle_boletas_gc')
            ->where('boleta_id', $boletaId)
            ->get();

        $pdf = Pdf::loadView('pdf.boleta-gasto-comun', [
            'boleta' => $boleta,
            'detalle' => $detalleCargos,
        ]);

        $nombreArchivo = "boleta-gc-{$boleta->mes}-{$boleta->anio}-unidad-{$boleta->unidad_numero}.pdf";

        // Registrar descarga
        DB::table('log_actividad_portal')->insert([
            'acceso_id' => $acceso->id,
            'accion' => 'descargar_boleta',
            'modulo' => 'estado_cuenta',
            'descripcion' => "Descarga boleta {$boleta->mes}/{$boleta->anio}",
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'created_at' => now(),
        ]);

        return $pdf->download($nombreArchivo);
    }

    /**
     * Descargar estado de cuenta completo en PDF
     */
    public function descargarEstadoCuentaPdf(Request $request)
    {
        $acceso = $request->attributes->get('acceso_portal');
        $unidadId = $acceso->unidad_id;

        // Obtener datos de la unidad
        $unidad = DB::table('unidades')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('unidades.id', $unidadId)
            ->select(
                'unidades.*',
                'edificios.nombre as edificio_nombre',
                'edificios.direccion as edificio_direccion',
                'edificios.rut as edificio_rut',
                'personas.nombre_completo as propietario_nombre',
                'personas.rut as propietario_rut'
            )
            ->first();

        // Boletas pendientes
        $boletasPendientes = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $unidadId)
            ->whereIn('boletas_gc.estado', ['pendiente', 'vencida'])
            ->select('boletas_gc.*', 'periodos_gc.mes', 'periodos_gc.anio')
            ->orderBy('periodos_gc.anio')
            ->orderBy('periodos_gc.mes')
            ->get();

        // Últimos pagos
        $ultimosPagos = DB::table('pagos_gc')
            ->join('boletas_gc', 'pagos_gc.boleta_id', '=', 'boletas_gc.id')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $unidadId)
            ->orderByDesc('pagos_gc.fecha_pago')
            ->limit(12)
            ->select('pagos_gc.*', 'periodos_gc.mes', 'periodos_gc.anio')
            ->get();

        $totalPendiente = $boletasPendientes->sum(fn($b) => $b->total_a_pagar - ($b->total_abonos ?? 0));

        $pdf = Pdf::loadView('pdf.estado-cuenta', [
            'unidad' => $unidad,
            'boletas_pendientes' => $boletasPendientes,
            'ultimos_pagos' => $ultimosPagos,
            'total_pendiente' => $totalPendiente,
            'fecha_emision' => now()->format('d/m/Y H:i'),
        ]);

        $nombreArchivo = "estado-cuenta-unidad-{$unidad->numero}-" . now()->format('Ymd') . ".pdf";

        return $pdf->download($nombreArchivo);
    }

    /**
     * Historial de pagos
     */
    public function historialPagos(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $unidadId = $acceso->unidad_id;

        $anio = $request->get('anio', now()->year);

        $pagos = DB::table('pagos_gc')
            ->join('boletas_gc', 'pagos_gc.boleta_id', '=', 'boletas_gc.id')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $unidadId)
            ->whereYear('pagos_gc.fecha_pago', $anio)
            ->select(
                'pagos_gc.*',
                'periodos_gc.mes',
                'periodos_gc.anio'
            )
            ->orderByDesc('pagos_gc.fecha_pago')
            ->get();

        // Transacciones online
        $transaccionesOnline = DB::table('transacciones_pago')
            ->where('unidad_id', $unidadId)
            ->whereYear('created_at', $anio)
            ->orderByDesc('created_at')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'anio' => $anio,
                'pagos' => $pagos->map(function ($p) {
                    return [
                        'id' => $p->id,
                        'fecha' => $p->fecha_pago,
                        'monto' => $p->monto,
                        'periodo' => sprintf('%02d/%d', $p->mes, $p->anio),
                        'medio_pago' => $p->medio_pago,
                        'comprobante' => $p->numero_comprobante,
                    ];
                }),
                'transacciones_online' => $transaccionesOnline->map(function ($t) {
                    return [
                        'id' => $t->id,
                        'codigo' => $t->codigo_transaccion,
                        'fecha' => $t->completada_at ?? $t->created_at,
                        'monto' => $t->monto_total,
                        'pasarela' => $t->pasarela,
                        'estado' => $t->estado,
                    ];
                }),
                'total_pagado' => $pagos->sum('monto'),
            ],
        ]);
    }

    /**
     * Certificado de no deuda
     */
    public function certificadoNoDeuda(Request $request)
    {
        $acceso = $request->attributes->get('acceso_portal');
        $unidadId = $acceso->unidad_id;

        // Verificar si tiene deuda
        $saldoPendiente = DB::table('boletas_gc')
            ->where('unidad_id', $unidadId)
            ->whereIn('estado', ['pendiente', 'vencida'])
            ->sum(DB::raw('total_a_pagar - COALESCE(total_abonos, 0)'));

        if ($saldoPendiente > 0) {
            return response()->json([
                'success' => false,
                'message' => 'No es posible emitir certificado de no deuda. Existe saldo pendiente.',
                'saldo_pendiente' => $saldoPendiente,
            ], 400);
        }

        // Obtener datos
        $unidad = DB::table('unidades')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('unidades.id', $unidadId)
            ->select(
                'unidades.*',
                'edificios.nombre as edificio_nombre',
                'edificios.direccion as edificio_direccion',
                'edificios.rut as edificio_rut',
                'edificios.administrador_nombre',
                'personas.nombre_completo as propietario_nombre',
                'personas.rut as propietario_rut'
            )
            ->first();

        // Generar código verificación
        $codigoVerificacion = strtoupper(substr(md5($unidadId . now()->timestamp), 0, 8));

        $pdf = Pdf::loadView('pdf.certificado-no-deuda', [
            'unidad' => $unidad,
            'fecha_emision' => now(),
            'codigo_verificacion' => $codigoVerificacion,
            'vigencia' => now()->addDays(30),
        ]);

        $nombreArchivo = "certificado-no-deuda-{$unidad->numero}-" . now()->format('Ymd') . ".pdf";

        // Registrar emisión
        DB::table('log_actividad_portal')->insert([
            'acceso_id' => $acceso->id,
            'accion' => 'emitir_certificado',
            'modulo' => 'estado_cuenta',
            'descripcion' => "Certificado de no deuda emitido - Código: {$codigoVerificacion}",
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'created_at' => now(),
        ]);

        return $pdf->download($nombreArchivo);
    }
}
