<?php

namespace App\Http\Controllers\Api\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - Sistema de Pagos Online
 * Integración WebPay Plus y Khipu
 */
class PagosOnlineController extends Controller
{
    // =========================================================
    // CONFIGURACIÓN
    // =========================================================
    
    private const WEBPAY_INTEGRATION_URL = 'https://webpay3gint.transbank.cl';
    private const WEBPAY_PRODUCTION_URL = 'https://webpay3g.transbank.cl';
    private const KHIPU_API_URL = 'https://khipu.com/api/2.0';

    // =========================================================
    // INICIAR PAGO
    // =========================================================

    /**
     * Obtener opciones de pago disponibles
     */
    public function opcionesPago(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $unidadId = $acceso->unidad_id;

        $edificioId = DB::table('unidades')->where('id', $unidadId)->value('edificio_id');
        $tenantId = $acceso->tenant_id;

        // Obtener pasarelas activas
        $pasarelasActivas = DB::table('configuracion_pasarelas')
            ->where('tenant_id', $tenantId)
            ->where(function ($q) use ($edificioId) {
                $q->whereNull('edificio_id')
                  ->orWhere('edificio_id', $edificioId);
            })
            ->where('activa', true)
            ->get();

        // Boletas pendientes
        $boletasPendientes = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $unidadId)
            ->whereIn('boletas_gc.estado', ['pendiente', 'vencida'])
            ->select(
                'boletas_gc.id',
                'periodos_gc.mes',
                'periodos_gc.anio',
                'boletas_gc.total_a_pagar',
                'boletas_gc.total_abonos',
                'boletas_gc.estado',
                'boletas_gc.fecha_vencimiento',
                DB::raw('boletas_gc.total_a_pagar - COALESCE(boletas_gc.total_abonos, 0) as saldo')
            )
            ->orderBy('periodos_gc.anio')
            ->orderBy('periodos_gc.mes')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'pasarelas' => $pasarelasActivas->map(function ($p) {
                    return [
                        'id' => $p->pasarela,
                        'nombre' => $p->pasarela === 'webpay' ? 'WebPay Plus' : 'Khipu',
                        'descripcion' => $p->pasarela === 'webpay' 
                            ? 'Paga con tarjeta de crédito o débito'
                            : 'Paga con transferencia bancaria simplificada',
                        'monto_minimo' => $p->monto_minimo,
                        'monto_maximo' => $p->monto_maximo,
                        'comision' => $p->comision_porcentaje > 0 
                            ? "Comisión: {$p->comision_porcentaje}%"
                            : null,
                    ];
                }),
                'boletas_pendientes' => $boletasPendientes->map(function ($b) {
                    return [
                        'id' => $b->id,
                        'periodo' => sprintf('%02d/%d', $b->mes, $b->anio),
                        'saldo' => $b->saldo,
                        'estado' => $b->estado,
                        'vencimiento' => $b->fecha_vencimiento,
                    ];
                }),
                'total_pendiente' => $boletasPendientes->sum('saldo'),
            ],
        ]);
    }

    /**
     * Iniciar transacción de pago
     */
    public function iniciarPago(Request $request): JsonResponse
    {
        $request->validate([
            'pasarela' => 'required|in:webpay,khipu',
            'boletas_ids' => 'required|array|min:1',
            'boletas_ids.*' => 'integer|exists:boletas_gc,id',
        ]);

        $acceso = $request->attributes->get('acceso_portal');
        $unidadId = $acceso->unidad_id;

        // Verificar que las boletas pertenecen a la unidad
        $boletas = DB::table('boletas_gc')
            ->whereIn('id', $request->boletas_ids)
            ->where('unidad_id', $unidadId)
            ->whereIn('estado', ['pendiente', 'vencida'])
            ->get();

        if ($boletas->count() !== count($request->boletas_ids)) {
            return response()->json([
                'success' => false,
                'message' => 'Una o más boletas no son válidas para pago.'
            ], 400);
        }

        // Calcular monto total
        $montoTotal = $boletas->sum(fn($b) => $b->total_a_pagar - ($b->total_abonos ?? 0));

        if ($montoTotal <= 0) {
            return response()->json([
                'success' => false,
                'message' => 'El monto a pagar debe ser mayor a 0.'
            ], 400);
        }

        // Verificar configuración de pasarela
        $configPasarela = DB::table('configuracion_pasarelas')
            ->where('tenant_id', $acceso->tenant_id)
            ->where('pasarela', $request->pasarela)
            ->where('activa', true)
            ->first();

        if (!$configPasarela) {
            return response()->json([
                'success' => false,
                'message' => 'Pasarela de pago no disponible.'
            ], 400);
        }

        // Validar montos
        if ($montoTotal < $configPasarela->monto_minimo) {
            return response()->json([
                'success' => false,
                'message' => "Monto mínimo de pago: $" . number_format($configPasarela->monto_minimo, 0, ',', '.')
            ], 400);
        }

        if ($montoTotal > $configPasarela->monto_maximo) {
            return response()->json([
                'success' => false,
                'message' => "Monto máximo de pago: $" . number_format($configPasarela->monto_maximo, 0, ',', '.')
            ], 400);
        }

        // Crear transacción
        $codigoTransaccion = strtoupper(Str::random(8)) . now()->format('ymdHis');
        $ordenCompra = 'DP' . $acceso->tenant_id . '-' . now()->format('YmdHis') . rand(100, 999);

        $transaccionId = DB::table('transacciones_pago')->insertGetId([
            'tenant_id' => $acceso->tenant_id,
            'unidad_id' => $unidadId,
            'acceso_id' => $acceso->id,
            'codigo_transaccion' => $codigoTransaccion,
            'orden_compra' => $ordenCompra,
            'tipo' => 'gasto_comun',
            'estado' => 'pendiente',
            'monto_original' => $montoTotal,
            'monto_interes' => $boletas->sum('interes_mora'),
            'monto_descuento' => 0,
            'monto_total' => $montoTotal,
            'pasarela' => $request->pasarela,
            'boletas_ids' => json_encode($request->boletas_ids),
            'ip_origen' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'expira_at' => now()->addHours(2),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Iniciar pago según pasarela
        if ($request->pasarela === 'webpay') {
            return $this->iniciarWebPay($transaccionId, $ordenCompra, $montoTotal, $configPasarela);
        } else {
            return $this->iniciarKhipu($transaccionId, $ordenCompra, $montoTotal, $configPasarela, $acceso);
        }
    }

    // =========================================================
    // WEBPAY PLUS
    // =========================================================

    /**
     * Iniciar transacción WebPay Plus
     */
    private function iniciarWebPay(int $transaccionId, string $ordenCompra, float $monto, object $config): JsonResponse
    {
        try {
            $baseUrl = $config->modo_produccion ? self::WEBPAY_PRODUCTION_URL : self::WEBPAY_INTEGRATION_URL;
            $apiKey = $config->modo_produccion ? Crypt::decryptString($config->api_key) : '579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C';
            $commerceCode = $config->modo_produccion ? $config->commerce_code : '597055555532';

            $returnUrl = config('app.url') . '/api/portal/pagos/webpay/retorno';
            
            $response = $this->webpayRequest('POST', "{$baseUrl}/rswebpaytransaction/api/webpay/v1.2/transactions", [
                'buy_order' => $ordenCompra,
                'session_id' => "session-{$transaccionId}",
                'amount' => (int) $monto,
                'return_url' => $returnUrl,
            ], $commerceCode, $apiKey);

            if (!isset($response['token'])) {
                throw new \Exception('No se recibió token de WebPay');
            }

            // Guardar token
            DB::table('transacciones_pago')->where('id', $transaccionId)->update([
                'webpay_token' => $response['token'],
                'estado' => 'procesando',
                'iniciada_at' => now(),
                'updated_at' => now(),
            ]);

            return response()->json([
                'success' => true,
                'data' => [
                    'pasarela' => 'webpay',
                    'url_pago' => $response['url'],
                    'token' => $response['token'],
                    'metodo' => 'redirect', // El usuario debe ser redirigido
                ],
            ]);

        } catch (\Exception $e) {
            Log::error('WebPay Init Error', [
                'transaccion_id' => $transaccionId,
                'error' => $e->getMessage(),
            ]);

            DB::table('transacciones_pago')->where('id', $transaccionId)->update([
                'estado' => 'rechazada',
                'notas' => 'Error al iniciar: ' . $e->getMessage(),
                'updated_at' => now(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Error al conectar con WebPay. Intente nuevamente.',
            ], 500);
        }
    }

    /**
     * Callback de retorno WebPay
     */
    public function webpayRetorno(Request $request)
    {
        $tokenWs = $request->input('token_ws');
        $tbkToken = $request->input('TBK_TOKEN');
        
        // Si viene TBK_TOKEN significa que fue anulado
        if ($tbkToken) {
            $transaccion = DB::table('transacciones_pago')
                ->where('webpay_token', $tbkToken)
                ->first();

            if ($transaccion) {
                DB::table('transacciones_pago')->where('id', $transaccion->id)->update([
                    'estado' => 'anulada',
                    'notas' => 'Pago anulado por el usuario',
                    'updated_at' => now(),
                ]);
            }

            return redirect(config('app.frontend_url') . '/portal/pagos/resultado?status=anulado');
        }

        if (!$tokenWs) {
            return redirect(config('app.frontend_url') . '/portal/pagos/resultado?status=error');
        }

        $transaccion = DB::table('transacciones_pago')
            ->where('webpay_token', $tokenWs)
            ->first();

        if (!$transaccion) {
            return redirect(config('app.frontend_url') . '/portal/pagos/resultado?status=error');
        }

        // Confirmar transacción con WebPay
        $config = DB::table('configuracion_pasarelas')
            ->where('tenant_id', $transaccion->tenant_id)
            ->where('pasarela', 'webpay')
            ->first();

        try {
            $baseUrl = $config->modo_produccion ? self::WEBPAY_PRODUCTION_URL : self::WEBPAY_INTEGRATION_URL;
            $apiKey = $config->modo_produccion ? Crypt::decryptString($config->api_key) : '579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C';
            $commerceCode = $config->modo_produccion ? $config->commerce_code : '597055555532';

            $response = $this->webpayRequest(
                'PUT',
                "{$baseUrl}/rswebpaytransaction/api/webpay/v1.2/transactions/{$tokenWs}",
                [],
                $commerceCode,
                $apiKey
            );

            if ($response['response_code'] === 0) {
                // Pago exitoso
                DB::table('transacciones_pago')->where('id', $transaccion->id)->update([
                    'estado' => 'aprobada',
                    'webpay_authorization_code' => $response['authorization_code'] ?? null,
                    'webpay_card_number' => $response['card_detail']['card_number'] ?? null,
                    'webpay_payment_type' => $response['payment_type_code'] ?? null,
                    'webpay_installments' => $response['installments_number'] ?? null,
                    'pasarela_respuesta' => json_encode($response),
                    'completada_at' => now(),
                    'updated_at' => now(),
                ]);

                // Aplicar pagos a boletas
                $this->aplicarPagoBoletas($transaccion);

                return redirect(config('app.frontend_url') . '/portal/pagos/resultado?status=aprobado&codigo=' . $transaccion->codigo_transaccion);
            } else {
                DB::table('transacciones_pago')->where('id', $transaccion->id)->update([
                    'estado' => 'rechazada',
                    'pasarela_respuesta' => json_encode($response),
                    'notas' => 'Pago rechazado: código ' . ($response['response_code'] ?? 'desconocido'),
                    'updated_at' => now(),
                ]);

                return redirect(config('app.frontend_url') . '/portal/pagos/resultado?status=rechazado');
            }
        } catch (\Exception $e) {
            Log::error('WebPay Confirm Error', [
                'transaccion_id' => $transaccion->id,
                'error' => $e->getMessage(),
            ]);

            return redirect(config('app.frontend_url') . '/portal/pagos/resultado?status=error');
        }
    }

    /**
     * Helper para requests a WebPay
     */
    private function webpayRequest(string $method, string $url, array $data, string $commerceCode, string $apiKey): array
    {
        $ch = curl_init();
        
        $headers = [
            'Content-Type: application/json',
            "Tbk-Api-Key-Id: {$commerceCode}",
            "Tbk-Api-Key-Secret: {$apiKey}",
        ];

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 30,
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode >= 400) {
            throw new \Exception("WebPay HTTP Error: {$httpCode}");
        }

        return json_decode($response, true) ?? [];
    }

    // =========================================================
    // KHIPU
    // =========================================================

    /**
     * Iniciar pago con Khipu
     */
    private function iniciarKhipu(int $transaccionId, string $ordenCompra, float $monto, object $config, object $acceso): JsonResponse
    {
        try {
            $receiverId = $config->modo_produccion ? $config->receiver_id : 'TEST_RECEIVER';
            $apiKey = $config->modo_produccion ? Crypt::decryptString($config->api_key) : 'TEST_API_KEY';

            // Obtener datos para descripción
            $unidad = DB::table('unidades')
                ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
                ->where('unidades.id', $acceso->unidad_id)
                ->select('unidades.numero', 'edificios.nombre as edificio')
                ->first();

            $notifyUrl = config('app.url') . '/api/portal/pagos/khipu/notificacion';
            $returnUrl = config('app.frontend_url') . '/portal/pagos/resultado';

            $response = $this->khipuRequest('POST', '/payments', [
                'subject' => "Pago GGCC - {$unidad->edificio} - Unidad {$unidad->numero}",
                'currency' => 'CLP',
                'amount' => (int) $monto,
                'transaction_id' => $ordenCompra,
                'notify_url' => $notifyUrl,
                'return_url' => $returnUrl,
                'cancel_url' => $returnUrl . '?status=cancelado',
                'payer_email' => $acceso->email,
            ], $receiverId, $apiKey);

            if (!isset($response['payment_id'])) {
                throw new \Exception('No se recibió payment_id de Khipu');
            }

            // Guardar datos de Khipu
            DB::table('transacciones_pago')->where('id', $transaccionId)->update([
                'khipu_payment_id' => $response['payment_id'],
                'khipu_payment_url' => $response['payment_url'],
                'khipu_simplified_url' => $response['simplified_transfer_url'] ?? null,
                'khipu_app_url' => $response['app_url'] ?? null,
                'estado' => 'procesando',
                'iniciada_at' => now(),
                'updated_at' => now(),
            ]);

            return response()->json([
                'success' => true,
                'data' => [
                    'pasarela' => 'khipu',
                    'payment_id' => $response['payment_id'],
                    'url_pago' => $response['payment_url'],
                    'url_simplificada' => $response['simplified_transfer_url'] ?? null,
                    'url_app' => $response['app_url'] ?? null,
                    'metodo' => 'redirect',
                ],
            ]);

        } catch (\Exception $e) {
            Log::error('Khipu Init Error', [
                'transaccion_id' => $transaccionId,
                'error' => $e->getMessage(),
            ]);

            DB::table('transacciones_pago')->where('id', $transaccionId)->update([
                'estado' => 'rechazada',
                'notas' => 'Error al iniciar: ' . $e->getMessage(),
                'updated_at' => now(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Error al conectar con Khipu. Intente nuevamente.',
            ], 500);
        }
    }

    /**
     * Notificación de Khipu (webhook)
     */
    public function khipuNotificacion(Request $request): JsonResponse
    {
        $notificationToken = $request->input('notification_token');
        
        if (!$notificationToken) {
            return response()->json(['error' => 'Token no proporcionado'], 400);
        }

        // Buscar transacción
        $transaccion = DB::table('transacciones_pago')
            ->where('khipu_notification_token', $notificationToken)
            ->orWhere('khipu_payment_id', $request->input('payment_id'))
            ->first();

        if (!$transaccion) {
            Log::warning('Khipu Notification: Transacción no encontrada', ['token' => $notificationToken]);
            return response()->json(['error' => 'Transacción no encontrada'], 404);
        }

        // Verificar estado con Khipu
        $config = DB::table('configuracion_pasarelas')
            ->where('tenant_id', $transaccion->tenant_id)
            ->where('pasarela', 'khipu')
            ->first();

        try {
            $receiverId = $config->modo_produccion ? $config->receiver_id : 'TEST_RECEIVER';
            $apiKey = $config->modo_produccion ? Crypt::decryptString($config->api_key) : 'TEST_API_KEY';

            $response = $this->khipuRequest(
                'GET',
                '/payments/' . $transaccion->khipu_payment_id,
                [],
                $receiverId,
                $apiKey
            );

            if ($response['status'] === 'done') {
                DB::table('transacciones_pago')->where('id', $transaccion->id)->update([
                    'estado' => 'aprobada',
                    'pasarela_respuesta' => json_encode($response),
                    'completada_at' => now(),
                    'updated_at' => now(),
                ]);

                $this->aplicarPagoBoletas($transaccion);
            } elseif ($response['status'] === 'pending') {
                // Sigue pendiente
            } else {
                DB::table('transacciones_pago')->where('id', $transaccion->id)->update([
                    'estado' => 'rechazada',
                    'pasarela_respuesta' => json_encode($response),
                    'notas' => 'Estado Khipu: ' . $response['status'],
                    'updated_at' => now(),
                ]);
            }

            return response()->json(['success' => true]);

        } catch (\Exception $e) {
            Log::error('Khipu Notification Error', [
                'transaccion_id' => $transaccion->id,
                'error' => $e->getMessage(),
            ]);

            return response()->json(['error' => 'Error al verificar pago'], 500);
        }
    }

    /**
     * Helper para requests a Khipu
     */
    private function khipuRequest(string $method, string $endpoint, array $data, string $receiverId, string $apiKey): array
    {
        $ch = curl_init();
        
        $url = self::KHIPU_API_URL . $endpoint;
        
        if ($method === 'GET' && !empty($data)) {
            $url .= '?' . http_build_query($data);
        }

        $headers = [
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: ' . $receiverId . ':' . $apiKey,
        ];

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 30,
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode >= 400) {
            throw new \Exception("Khipu HTTP Error: {$httpCode}");
        }

        return json_decode($response, true) ?? [];
    }

    // =========================================================
    // FUNCIONES COMUNES
    // =========================================================

    /**
     * Aplicar pago a boletas
     */
    private function aplicarPagoBoletas(object $transaccion): void
    {
        $boletasIds = json_decode($transaccion->boletas_ids, true);
        
        if (empty($boletasIds)) {
            return;
        }

        $boletas = DB::table('boletas_gc')
            ->whereIn('id', $boletasIds)
            ->orderBy('id')
            ->get();

        $montoDisponible = $transaccion->monto_total;
        $ahora = now();

        foreach ($boletas as $boleta) {
            if ($montoDisponible <= 0) break;

            $saldoBoleta = $boleta->total_a_pagar - ($boleta->total_abonos ?? 0);
            $montoAplicar = min($montoDisponible, $saldoBoleta);

            // Registrar pago
            DB::table('pagos_gc')->insert([
                'boleta_id' => $boleta->id,
                'fecha_pago' => $ahora,
                'monto' => $montoAplicar,
                'medio_pago' => $transaccion->pasarela,
                'numero_comprobante' => $transaccion->codigo_transaccion,
                'referencia_externa' => $transaccion->pasarela === 'webpay' 
                    ? $transaccion->webpay_authorization_code 
                    : $transaccion->khipu_payment_id,
                'created_at' => $ahora,
                'updated_at' => $ahora,
            ]);

            // Actualizar boleta
            $nuevoTotalAbonos = ($boleta->total_abonos ?? 0) + $montoAplicar;
            $nuevoEstado = $nuevoTotalAbonos >= $boleta->total_a_pagar ? 'pagada' : $boleta->estado;

            DB::table('boletas_gc')->where('id', $boleta->id)->update([
                'total_abonos' => $nuevoTotalAbonos,
                'estado' => $nuevoEstado,
                'fecha_pago' => $nuevoEstado === 'pagada' ? $ahora : null,
                'updated_at' => $ahora,
            ]);

            $montoDisponible -= $montoAplicar;
        }

        // Generar comprobante
        $this->generarComprobante($transaccion);
    }

    /**
     * Generar comprobante de pago
     */
    private function generarComprobante(object $transaccion): void
    {
        $numeroComprobante = 'COMP-' . date('Y') . '-' . str_pad($transaccion->id, 8, '0', STR_PAD_LEFT);
        
        DB::table('transacciones_pago')->where('id', $transaccion->id)->update([
            'comprobante_numero' => $numeroComprobante,
            'updated_at' => now(),
        ]);

        // TODO: Enviar comprobante por email
    }

    /**
     * Consultar estado de transacción
     */
    public function estadoTransaccion(Request $request, string $codigo): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $transaccion = DB::table('transacciones_pago')
            ->where('codigo_transaccion', $codigo)
            ->where('acceso_id', $acceso->id)
            ->first();

        if (!$transaccion) {
            return response()->json([
                'success' => false,
                'message' => 'Transacción no encontrada.'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => [
                'codigo' => $transaccion->codigo_transaccion,
                'estado' => $transaccion->estado,
                'monto' => $transaccion->monto_total,
                'pasarela' => $transaccion->pasarela,
                'fecha_creacion' => $transaccion->created_at,
                'fecha_completada' => $transaccion->completada_at,
                'comprobante' => $transaccion->comprobante_numero,
            ],
        ]);
    }

    /**
     * Historial de transacciones del usuario
     */
    public function historialTransacciones(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $transacciones = DB::table('transacciones_pago')
            ->where('acceso_id', $acceso->id)
            ->orderByDesc('created_at')
            ->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $transacciones,
        ]);
    }

    /**
     * Descargar comprobante de pago
     */
    public function descargarComprobante(Request $request, string $codigo)
    {
        $acceso = $request->attributes->get('acceso_portal');

        $transaccion = DB::table('transacciones_pago')
            ->where('codigo_transaccion', $codigo)
            ->where('acceso_id', $acceso->id)
            ->where('estado', 'aprobada')
            ->first();

        if (!$transaccion) {
            return response()->json([
                'success' => false,
                'message' => 'Comprobante no disponible.'
            ], 404);
        }

        // Obtener datos adicionales
        $unidad = DB::table('unidades')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('unidades.id', $transaccion->unidad_id)
            ->select(
                'unidades.numero',
                'edificios.nombre as edificio',
                'edificios.rut as edificio_rut',
                'personas.nombre_completo',
                'personas.rut'
            )
            ->first();

        $boletas = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->whereIn('boletas_gc.id', json_decode($transaccion->boletas_ids, true))
            ->select('periodos_gc.mes', 'periodos_gc.anio', 'boletas_gc.total_a_pagar')
            ->get();

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.comprobante-pago', [
            'transaccion' => $transaccion,
            'unidad' => $unidad,
            'boletas' => $boletas,
        ]);

        return $pdf->download("comprobante-{$transaccion->comprobante_numero}.pdf");
    }
}
