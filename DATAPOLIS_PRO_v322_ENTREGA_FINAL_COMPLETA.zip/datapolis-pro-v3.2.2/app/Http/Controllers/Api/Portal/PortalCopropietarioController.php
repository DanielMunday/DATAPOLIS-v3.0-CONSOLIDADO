<?php

namespace App\Http\Controllers\Api\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - Portal Copropietarios Controller
 * Autenticación, Dashboard y funcionalidades principales
 */
class PortalCopropietarioController extends Controller
{
    // =========================================================
    // AUTENTICACIÓN PORTAL
    // =========================================================

    /**
     * Login de copropietario al portal
     */
    public function login(Request $request): JsonResponse
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
            'dispositivo' => 'nullable|string',
        ]);

        $acceso = DB::table('accesos_portal')
            ->where('email', $request->email)
            ->whereNull('deleted_at')
            ->first();

        if (!$acceso) {
            return response()->json([
                'success' => false,
                'message' => 'Credenciales inválidas'
            ], 401);
        }

        // Verificar si está bloqueado
        if ($acceso->bloqueado_hasta && Carbon::parse($acceso->bloqueado_hasta)->isFuture()) {
            $minutos = Carbon::now()->diffInMinutes(Carbon::parse($acceso->bloqueado_hasta));
            return response()->json([
                'success' => false,
                'message' => "Cuenta bloqueada. Intente en {$minutos} minutos."
            ], 423);
        }

        // Verificar contraseña
        if (!Hash::check($request->password, $acceso->password)) {
            $intentos = $acceso->intentos_fallidos + 1;
            $updates = ['intentos_fallidos' => $intentos];
            
            if ($intentos >= 5) {
                $updates['bloqueado_hasta'] = Carbon::now()->addMinutes(30);
            }
            
            DB::table('accesos_portal')->where('id', $acceso->id)->update($updates);
            
            return response()->json([
                'success' => false,
                'message' => 'Credenciales inválidas',
                'intentos_restantes' => max(0, 5 - $intentos)
            ], 401);
        }

        // Verificar si está activo
        if (!$acceso->activo) {
            return response()->json([
                'success' => false,
                'message' => 'Cuenta desactivada. Contacte al administrador.'
            ], 403);
        }

        // Crear sesión
        $token = Str::random(64);
        $ahora = Carbon::now();
        
        DB::table('sesiones_portal')->insert([
            'acceso_id' => $acceso->id,
            'token' => hash('sha256', $token),
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'dispositivo' => $this->detectarDispositivo($request->userAgent()),
            'navegador' => $this->detectarNavegador($request->userAgent()),
            'sistema_operativo' => $this->detectarSO($request->userAgent()),
            'expira_at' => $ahora->copy()->addDays(7),
            'ultima_actividad' => $ahora,
            'activa' => true,
            'created_at' => $ahora,
            'updated_at' => $ahora,
        ]);

        // Actualizar acceso
        DB::table('accesos_portal')->where('id', $acceso->id)->update([
            'ultimo_acceso' => $ahora,
            'ultimo_ip' => $request->ip(),
            'ultimo_dispositivo' => $request->dispositivo ?? $this->detectarDispositivo($request->userAgent()),
            'intentos_fallidos' => 0,
            'bloqueado_hasta' => null,
        ]);

        // Obtener datos del copropietario
        $copropietario = DB::table('personas')
            ->where('id', $acceso->copropietario_id)
            ->first();

        $unidad = DB::table('unidades')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->where('unidades.id', $acceso->unidad_id)
            ->select('unidades.*', 'edificios.nombre as edificio_nombre', 'edificios.direccion as edificio_direccion')
            ->first();

        // Registrar actividad
        $this->registrarActividad($acceso->id, 'login', 'auth', 'Inicio de sesión exitoso', $request);

        return response()->json([
            'success' => true,
            'token' => $token,
            'acceso' => [
                'id' => $acceso->id,
                'email' => $acceso->email,
                'email_verificado' => $acceso->email_verificado,
            ],
            'copropietario' => [
                'id' => $copropietario->id,
                'nombre' => $copropietario->nombre_completo ?? "{$copropietario->nombre} {$copropietario->apellido_paterno}",
                'rut' => $copropietario->rut,
                'email' => $copropietario->email,
                'telefono' => $copropietario->telefono,
            ],
            'unidad' => [
                'id' => $unidad->id,
                'numero' => $unidad->numero,
                'tipo' => $unidad->tipo,
                'piso' => $unidad->piso,
                'edificio' => $unidad->edificio_nombre,
                'direccion' => $unidad->edificio_direccion,
            ],
            'preferencias' => json_decode($acceso->preferencias ?? '{}'),
        ]);
    }

    /**
     * Logout del portal
     */
    public function logout(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $sesion = $request->attributes->get('sesion_portal');

        if ($sesion) {
            DB::table('sesiones_portal')
                ->where('id', $sesion->id)
                ->update(['activa' => false, 'updated_at' => now()]);
        }

        $this->registrarActividad($acceso->id, 'logout', 'auth', 'Cierre de sesión', $request);

        return response()->json([
            'success' => true,
            'message' => 'Sesión cerrada correctamente'
        ]);
    }

    /**
     * Registrar nuevo copropietario en el portal
     */
    public function registrar(Request $request): JsonResponse
    {
        $request->validate([
            'rut' => 'required|string|max:12',
            'email' => 'required|email|unique:accesos_portal,email',
            'password' => 'required|min:8|confirmed',
            'numero_unidad' => 'required|string',
            'codigo_edificio' => 'required|string',
        ]);

        // Buscar persona por RUT
        $persona = DB::table('personas')
            ->where('rut', $this->formatearRut($request->rut))
            ->first();

        if (!$persona) {
            return response()->json([
                'success' => false,
                'message' => 'RUT no encontrado en el sistema. Contacte al administrador.'
            ], 404);
        }

        // Buscar unidad
        $unidad = DB::table('unidades')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->where('unidades.numero', $request->numero_unidad)
            ->where('edificios.rut', $request->codigo_edificio)
            ->where('unidades.propietario_id', $persona->id)
            ->select('unidades.*', 'edificios.tenant_id')
            ->first();

        if (!$unidad) {
            return response()->json([
                'success' => false,
                'message' => 'No se encontró una unidad asociada a su RUT con esos datos.'
            ], 404);
        }

        // Verificar si ya tiene acceso
        $existente = DB::table('accesos_portal')
            ->where('copropietario_id', $persona->id)
            ->where('unidad_id', $unidad->id)
            ->whereNull('deleted_at')
            ->first();

        if ($existente) {
            return response()->json([
                'success' => false,
                'message' => 'Ya existe un acceso registrado para esta unidad.'
            ], 409);
        }

        // Crear acceso
        $tokenVerificacion = Str::random(64);
        
        $accesoId = DB::table('accesos_portal')->insertGetId([
            'tenant_id' => $unidad->tenant_id,
            'copropietario_id' => $persona->id,
            'unidad_id' => $unidad->id,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'activo' => true,
            'email_verificado' => false,
            'token_verificacion' => $tokenVerificacion,
            'es_principal' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // TODO: Enviar email de verificación

        return response()->json([
            'success' => true,
            'message' => 'Registro exitoso. Se ha enviado un correo de verificación.',
            'acceso_id' => $accesoId,
        ], 201);
    }

    /**
     * Verificar email
     */
    public function verificarEmail(Request $request): JsonResponse
    {
        $request->validate([
            'token' => 'required|string|size:64',
        ]);

        $acceso = DB::table('accesos_portal')
            ->where('token_verificacion', $request->token)
            ->whereNull('deleted_at')
            ->first();

        if (!$acceso) {
            return response()->json([
                'success' => false,
                'message' => 'Token de verificación inválido o expirado.'
            ], 400);
        }

        DB::table('accesos_portal')->where('id', $acceso->id)->update([
            'email_verificado' => true,
            'email_verificado_at' => now(),
            'token_verificacion' => null,
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Email verificado correctamente.'
        ]);
    }

    /**
     * Recuperar contraseña - Solicitar
     */
    public function solicitarRecuperacion(Request $request): JsonResponse
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $acceso = DB::table('accesos_portal')
            ->where('email', $request->email)
            ->whereNull('deleted_at')
            ->first();

        if (!$acceso) {
            // Por seguridad, no revelamos si el email existe
            return response()->json([
                'success' => true,
                'message' => 'Si el email existe, recibirás instrucciones para recuperar tu contraseña.'
            ]);
        }

        $token = Str::random(64);
        
        DB::table('password_reset_tokens')->updateOrInsert(
            ['email' => $request->email],
            [
                'token' => hash('sha256', $token),
                'created_at' => now(),
            ]
        );

        // TODO: Enviar email de recuperación

        return response()->json([
            'success' => true,
            'message' => 'Si el email existe, recibirás instrucciones para recuperar tu contraseña.'
        ]);
    }

    /**
     * Recuperar contraseña - Resetear
     */
    public function resetearPassword(Request $request): JsonResponse
    {
        $request->validate([
            'token' => 'required|string',
            'email' => 'required|email',
            'password' => 'required|min:8|confirmed',
        ]);

        $reset = DB::table('password_reset_tokens')
            ->where('email', $request->email)
            ->where('token', hash('sha256', $request->token))
            ->first();

        if (!$reset || Carbon::parse($reset->created_at)->addHours(24)->isPast()) {
            return response()->json([
                'success' => false,
                'message' => 'Token inválido o expirado.'
            ], 400);
        }

        DB::table('accesos_portal')
            ->where('email', $request->email)
            ->update([
                'password' => Hash::make($request->password),
                'updated_at' => now(),
            ]);

        DB::table('password_reset_tokens')->where('email', $request->email)->delete();

        return response()->json([
            'success' => true,
            'message' => 'Contraseña actualizada correctamente.'
        ]);
    }

    // =========================================================
    // DASHBOARD
    // =========================================================

    /**
     * Dashboard principal del copropietario
     */
    public function dashboard(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');
        $unidadId = $acceso->unidad_id;

        // Saldo pendiente
        $saldoPendiente = DB::table('boletas_gc')
            ->where('unidad_id', $unidadId)
            ->whereIn('estado', ['pendiente', 'vencida'])
            ->sum(DB::raw('total_a_pagar - COALESCE(total_abonos, 0)'));

        // Última boleta
        $ultimaBoleta = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $unidadId)
            ->orderByDesc('periodos_gc.anio')
            ->orderByDesc('periodos_gc.mes')
            ->select('boletas_gc.*', 'periodos_gc.mes', 'periodos_gc.anio')
            ->first();

        // Próximo vencimiento
        $proximoVencimiento = DB::table('boletas_gc')
            ->where('unidad_id', $unidadId)
            ->where('estado', 'pendiente')
            ->where('fecha_vencimiento', '>=', now())
            ->orderBy('fecha_vencimiento')
            ->first();

        // Solicitudes activas
        $solicitudesActivas = DB::table('solicitudes_copropietarios')
            ->where('acceso_id', $acceso->id)
            ->whereNotIn('estado', ['cerrada', 'resuelta', 'rechazada'])
            ->count();

        // Reservas próximas
        $reservasProximas = DB::table('reservas_espacios')
            ->join('espacios_comunes', 'reservas_espacios.espacio_id', '=', 'espacios_comunes.id')
            ->where('reservas_espacios.acceso_id', $acceso->id)
            ->where('reservas_espacios.fecha', '>=', now()->toDateString())
            ->where('reservas_espacios.estado', 'confirmada')
            ->orderBy('reservas_espacios.fecha')
            ->select('reservas_espacios.*', 'espacios_comunes.nombre as espacio_nombre')
            ->limit(3)
            ->get();

        // Comunicados recientes no leídos
        $edificioId = DB::table('unidades')->where('id', $unidadId)->value('edificio_id');
        
        $comunicadosNoLeidos = DB::table('comunicados')
            ->leftJoin('lecturas_comunicados', function ($join) use ($acceso) {
                $join->on('comunicados.id', '=', 'lecturas_comunicados.comunicado_id')
                    ->where('lecturas_comunicados.acceso_id', '=', $acceso->id);
            })
            ->where('comunicados.edificio_id', $edificioId)
            ->where('comunicados.publicado', true)
            ->whereNull('lecturas_comunicados.id')
            ->count();

        // Votaciones activas
        $votacionesActivas = DB::table('votaciones_online')
            ->where('edificio_id', $edificioId)
            ->where('estado', 'activa')
            ->where('fin_votacion', '>=', now())
            ->count();

        // Últimos pagos
        $ultimosPagos = DB::table('transacciones_pago')
            ->where('unidad_id', $unidadId)
            ->where('estado', 'aprobada')
            ->orderByDesc('completada_at')
            ->limit(5)
            ->get(['id', 'codigo_transaccion', 'monto_total', 'completada_at', 'tipo']);

        // Notificaciones no leídas
        $notificacionesNoLeidas = DB::table('notificaciones_portal')
            ->where('acceso_id', $acceso->id)
            ->where('leida', false)
            ->count();

        return response()->json([
            'success' => true,
            'data' => [
                'resumen_financiero' => [
                    'saldo_pendiente' => $saldoPendiente,
                    'ultima_boleta' => $ultimaBoleta ? [
                        'periodo' => "{$ultimaBoleta->mes}/{$ultimaBoleta->anio}",
                        'monto' => $ultimaBoleta->total_a_pagar,
                        'estado' => $ultimaBoleta->estado,
                    ] : null,
                    'proximo_vencimiento' => $proximoVencimiento ? [
                        'fecha' => $proximoVencimiento->fecha_vencimiento,
                        'monto' => $proximoVencimiento->total_a_pagar - ($proximoVencimiento->total_abonos ?? 0),
                    ] : null,
                ],
                'actividad' => [
                    'solicitudes_activas' => $solicitudesActivas,
                    'comunicados_no_leidos' => $comunicadosNoLeidos,
                    'votaciones_activas' => $votacionesActivas,
                    'notificaciones_no_leidas' => $notificacionesNoLeidas,
                ],
                'reservas_proximas' => $reservasProximas,
                'ultimos_pagos' => $ultimosPagos,
            ],
        ]);
    }

    /**
     * Obtener perfil del copropietario
     */
    public function perfil(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $copropietario = DB::table('personas')
            ->where('id', $acceso->copropietario_id)
            ->first();

        $unidad = DB::table('unidades')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->where('unidades.id', $acceso->unidad_id)
            ->select(
                'unidades.*',
                'edificios.nombre as edificio_nombre',
                'edificios.direccion as edificio_direccion',
                'edificios.comuna as edificio_comuna'
            )
            ->first();

        // Otras unidades del mismo copropietario
        $otrasUnidades = DB::table('accesos_portal')
            ->join('unidades', 'accesos_portal.unidad_id', '=', 'unidades.id')
            ->join('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->where('accesos_portal.copropietario_id', $acceso->copropietario_id)
            ->where('accesos_portal.id', '!=', $acceso->id)
            ->whereNull('accesos_portal.deleted_at')
            ->select('unidades.numero', 'edificios.nombre as edificio')
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'acceso' => [
                    'email' => $acceso->email,
                    'email_verificado' => $acceso->email_verificado,
                    'ultimo_acceso' => $acceso->ultimo_acceso,
                ],
                'copropietario' => [
                    'rut' => $copropietario->rut,
                    'nombre' => $copropietario->nombre,
                    'apellido_paterno' => $copropietario->apellido_paterno,
                    'apellido_materno' => $copropietario->apellido_materno,
                    'nombre_completo' => $copropietario->nombre_completo,
                    'email' => $copropietario->email,
                    'telefono' => $copropietario->telefono,
                    'direccion' => $copropietario->direccion,
                ],
                'unidad' => [
                    'numero' => $unidad->numero,
                    'tipo' => $unidad->tipo,
                    'piso' => $unidad->piso,
                    'superficie_util' => $unidad->superficie_util,
                    'prorrateo' => $unidad->prorrateo,
                    'edificio' => $unidad->edificio_nombre,
                    'direccion' => $unidad->edificio_direccion,
                    'comuna' => $unidad->edificio_comuna,
                ],
                'otras_unidades' => $otrasUnidades,
                'preferencias' => json_decode($acceso->preferencias ?? '{}'),
            ],
        ]);
    }

    /**
     * Actualizar perfil
     */
    public function actualizarPerfil(Request $request): JsonResponse
    {
        $request->validate([
            'telefono' => 'nullable|string|max:20',
            'email_notificaciones' => 'nullable|email',
            'acepta_notificaciones_email' => 'nullable|boolean',
            'acepta_notificaciones_push' => 'nullable|boolean',
            'acepta_notificaciones_sms' => 'nullable|boolean',
        ]);

        $acceso = $request->attributes->get('acceso_portal');

        // Actualizar persona si hay teléfono
        if ($request->has('telefono')) {
            DB::table('personas')
                ->where('id', $acceso->copropietario_id)
                ->update(['telefono' => $request->telefono, 'updated_at' => now()]);
        }

        // Actualizar preferencias de acceso
        $updates = ['updated_at' => now()];
        
        if ($request->has('acepta_notificaciones_email')) {
            $updates['acepta_notificaciones_email'] = $request->acepta_notificaciones_email;
        }
        if ($request->has('acepta_notificaciones_push')) {
            $updates['acepta_notificaciones_push'] = $request->acepta_notificaciones_push;
        }
        if ($request->has('acepta_notificaciones_sms')) {
            $updates['acepta_notificaciones_sms'] = $request->acepta_notificaciones_sms;
        }

        DB::table('accesos_portal')->where('id', $acceso->id)->update($updates);

        $this->registrarActividad($acceso->id, 'actualizar_perfil', 'perfil', 'Perfil actualizado', $request);

        return response()->json([
            'success' => true,
            'message' => 'Perfil actualizado correctamente.'
        ]);
    }

    /**
     * Cambiar contraseña
     */
    public function cambiarPassword(Request $request): JsonResponse
    {
        $request->validate([
            'password_actual' => 'required|string',
            'password_nuevo' => 'required|min:8|confirmed',
        ]);

        $acceso = $request->attributes->get('acceso_portal');

        if (!Hash::check($request->password_actual, $acceso->password)) {
            return response()->json([
                'success' => false,
                'message' => 'La contraseña actual es incorrecta.'
            ], 400);
        }

        DB::table('accesos_portal')->where('id', $acceso->id)->update([
            'password' => Hash::make($request->password_nuevo),
            'updated_at' => now(),
        ]);

        // Cerrar otras sesiones
        DB::table('sesiones_portal')
            ->where('acceso_id', $acceso->id)
            ->where('id', '!=', $request->attributes->get('sesion_portal')->id)
            ->update(['activa' => false]);

        $this->registrarActividad($acceso->id, 'cambiar_password', 'auth', 'Contraseña cambiada', $request);

        return response()->json([
            'success' => true,
            'message' => 'Contraseña actualizada correctamente.'
        ]);
    }

    // =========================================================
    // HELPERS
    // =========================================================

    private function detectarDispositivo(string $userAgent): string
    {
        if (preg_match('/mobile|android|iphone|ipad/i', $userAgent)) {
            if (preg_match('/ipad|tablet/i', $userAgent)) {
                return 'tablet';
            }
            return 'mobile';
        }
        return 'desktop';
    }

    private function detectarNavegador(string $userAgent): string
    {
        if (preg_match('/Chrome/i', $userAgent)) return 'Chrome';
        if (preg_match('/Firefox/i', $userAgent)) return 'Firefox';
        if (preg_match('/Safari/i', $userAgent)) return 'Safari';
        if (preg_match('/Edge/i', $userAgent)) return 'Edge';
        if (preg_match('/Opera|OPR/i', $userAgent)) return 'Opera';
        return 'Otro';
    }

    private function detectarSO(string $userAgent): string
    {
        if (preg_match('/Windows/i', $userAgent)) return 'Windows';
        if (preg_match('/Mac/i', $userAgent)) return 'macOS';
        if (preg_match('/Linux/i', $userAgent)) return 'Linux';
        if (preg_match('/Android/i', $userAgent)) return 'Android';
        if (preg_match('/iOS|iPhone|iPad/i', $userAgent)) return 'iOS';
        return 'Otro';
    }

    private function formatearRut(string $rut): string
    {
        return strtoupper(preg_replace('/[^0-9kK]/', '', $rut));
    }

    private function registrarActividad(int $accesoId, string $accion, string $modulo, ?string $descripcion, Request $request): void
    {
        DB::table('log_actividad_portal')->insert([
            'acceso_id' => $accesoId,
            'accion' => $accion,
            'modulo' => $modulo,
            'descripcion' => $descripcion,
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'created_at' => now(),
        ]);
    }
}
