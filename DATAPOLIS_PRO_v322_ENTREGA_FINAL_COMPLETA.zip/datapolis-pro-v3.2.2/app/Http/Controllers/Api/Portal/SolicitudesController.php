<?php

namespace App\Http\Controllers\Api\Portal;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - Solicitudes y Reclamos
 * Portal Copropietarios
 */
class SolicitudesController extends Controller
{
    /**
     * Listar solicitudes del copropietario
     */
    public function index(Request $request): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $estado = $request->get('estado');
        $tipo = $request->get('tipo');

        $query = DB::table('solicitudes_copropietarios')
            ->where('acceso_id', $acceso->id)
            ->whereNull('deleted_at');

        if ($estado) {
            $query->where('estado', $estado);
        }
        if ($tipo) {
            $query->where('tipo', $tipo);
        }

        $solicitudes = $query
            ->orderByDesc('created_at')
            ->paginate(15);

        // Estadísticas
        $estadisticas = DB::table('solicitudes_copropietarios')
            ->where('acceso_id', $acceso->id)
            ->whereNull('deleted_at')
            ->selectRaw("
                COUNT(*) as total,
                SUM(CASE WHEN estado IN ('abierta', 'en_revision', 'en_proceso', 'pendiente_respuesta') THEN 1 ELSE 0 END) as activas,
                SUM(CASE WHEN estado = 'resuelta' THEN 1 ELSE 0 END) as resueltas,
                SUM(CASE WHEN estado = 'cerrada' THEN 1 ELSE 0 END) as cerradas
            ")
            ->first();

        return response()->json([
            'success' => true,
            'data' => [
                'solicitudes' => $solicitudes,
                'estadisticas' => $estadisticas,
            ],
        ]);
    }

    /**
     * Crear nueva solicitud
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'tipo' => 'required|in:reclamo,sugerencia,consulta,solicitud_reparacion,solicitud_certificado,solicitud_documentos,denuncia,felicitacion,otro',
            'categoria' => 'required|in:administracion,mantencion,seguridad,areas_comunes,ruidos_molestias,estacionamientos,mascotas,gastos_comunes,otro',
            'asunto' => 'required|string|max:200',
            'descripcion' => 'required|string|max:5000',
            'prioridad' => 'nullable|in:baja,media,alta,urgente',
            'es_anonima' => 'nullable|boolean',
            'archivos' => 'nullable|array|max:5',
            'archivos.*' => 'file|max:5120|mimes:jpg,jpeg,png,pdf,doc,docx',
        ]);

        $acceso = $request->attributes->get('acceso_portal');
        $edificioId = DB::table('unidades')->where('id', $acceso->unidad_id)->value('edificio_id');

        // Generar número de ticket
        $ultimoTicket = DB::table('solicitudes_copropietarios')
            ->where('tenant_id', $acceso->tenant_id)
            ->whereYear('created_at', now()->year)
            ->max('numero_ticket');

        $numero = $ultimoTicket 
            ? intval(substr($ultimoTicket, -5)) + 1 
            : 1;
        
        $numeroTicket = 'TK' . now()->format('Y') . str_pad($numero, 5, '0', STR_PAD_LEFT);

        // Procesar archivos adjuntos
        $archivosAdjuntos = [];
        if ($request->hasFile('archivos')) {
            foreach ($request->file('archivos') as $archivo) {
                $path = $archivo->store("solicitudes/{$edificioId}", 'public');
                $archivosAdjuntos[] = [
                    'nombre' => $archivo->getClientOriginalName(),
                    'path' => $path,
                    'mime' => $archivo->getMimeType(),
                    'size' => $archivo->getSize(),
                ];
            }
        }

        $solicitudId = DB::table('solicitudes_copropietarios')->insertGetId([
            'tenant_id' => $acceso->tenant_id,
            'unidad_id' => $acceso->unidad_id,
            'acceso_id' => $acceso->id,
            'edificio_id' => $edificioId,
            'numero_ticket' => $numeroTicket,
            'tipo' => $request->tipo,
            'categoria' => $request->categoria,
            'prioridad' => $request->prioridad ?? 'media',
            'asunto' => $request->asunto,
            'descripcion' => $request->descripcion,
            'archivos_adjuntos' => !empty($archivosAdjuntos) ? json_encode($archivosAdjuntos) : null,
            'estado' => 'abierta',
            'es_anonima' => $request->es_anonima ?? false,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Registrar en seguimiento
        DB::table('seguimiento_solicitudes')->insert([
            'solicitud_id' => $solicitudId,
            'acceso_id' => $acceso->id,
            'tipo' => 'cambio_estado',
            'estado_nuevo' => 'abierta',
            'contenido' => 'Solicitud creada',
            'visible_copropietario' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Notificar a administración (TODO: implementar notificación)

        return response()->json([
            'success' => true,
            'message' => 'Solicitud creada exitosamente.',
            'data' => [
                'id' => $solicitudId,
                'numero_ticket' => $numeroTicket,
            ],
        ], 201);
    }

    /**
     * Ver detalle de solicitud
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $solicitud = DB::table('solicitudes_copropietarios')
            ->leftJoin('users as asignado', 'solicitudes_copropietarios.asignado_a', '=', 'asignado.id')
            ->leftJoin('users as respondido', 'solicitudes_copropietarios.respondida_por', '=', 'respondido.id')
            ->where('solicitudes_copropietarios.id', $id)
            ->where('solicitudes_copropietarios.acceso_id', $acceso->id)
            ->select(
                'solicitudes_copropietarios.*',
                'asignado.name as asignado_nombre',
                'respondido.name as respondido_nombre'
            )
            ->first();

        if (!$solicitud) {
            return response()->json([
                'success' => false,
                'message' => 'Solicitud no encontrada.'
            ], 404);
        }

        // Obtener seguimiento
        $seguimiento = DB::table('seguimiento_solicitudes')
            ->leftJoin('users', 'seguimiento_solicitudes.usuario_id', '=', 'users.id')
            ->where('seguimiento_solicitudes.solicitud_id', $id)
            ->where('seguimiento_solicitudes.visible_copropietario', true)
            ->orderBy('seguimiento_solicitudes.created_at')
            ->select(
                'seguimiento_solicitudes.*',
                'users.name as usuario_nombre'
            )
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'solicitud' => [
                    'id' => $solicitud->id,
                    'numero_ticket' => $solicitud->numero_ticket,
                    'tipo' => $solicitud->tipo,
                    'categoria' => $solicitud->categoria,
                    'prioridad' => $solicitud->prioridad,
                    'asunto' => $solicitud->asunto,
                    'descripcion' => $solicitud->descripcion,
                    'estado' => $solicitud->estado,
                    'archivos_adjuntos' => json_decode($solicitud->archivos_adjuntos ?? '[]'),
                    'asignado_a' => $solicitud->asignado_nombre,
                    'respuesta' => $solicitud->respuesta,
                    'respondida_at' => $solicitud->respondida_at,
                    'respondida_por' => $solicitud->respondido_nombre,
                    'calificacion' => $solicitud->calificacion,
                    'fecha_limite' => $solicitud->fecha_limite,
                    'created_at' => $solicitud->created_at,
                ],
                'seguimiento' => $seguimiento->map(function ($s) {
                    return [
                        'tipo' => $s->tipo,
                        'contenido' => $s->contenido,
                        'estado_anterior' => $s->estado_anterior,
                        'estado_nuevo' => $s->estado_nuevo,
                        'usuario' => $s->usuario_nombre ?? 'Sistema',
                        'fecha' => $s->created_at,
                        'archivos' => json_decode($s->archivos ?? '[]'),
                    ];
                }),
            ],
        ]);
    }

    /**
     * Agregar comentario a solicitud
     */
    public function agregarComentario(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'comentario' => 'required|string|max:2000',
            'archivos' => 'nullable|array|max:3',
            'archivos.*' => 'file|max:5120|mimes:jpg,jpeg,png,pdf',
        ]);

        $acceso = $request->attributes->get('acceso_portal');

        $solicitud = DB::table('solicitudes_copropietarios')
            ->where('id', $id)
            ->where('acceso_id', $acceso->id)
            ->whereNotIn('estado', ['cerrada', 'rechazada'])
            ->first();

        if (!$solicitud) {
            return response()->json([
                'success' => false,
                'message' => 'Solicitud no encontrada o no permite comentarios.'
            ], 404);
        }

        // Procesar archivos
        $archivos = [];
        if ($request->hasFile('archivos')) {
            foreach ($request->file('archivos') as $archivo) {
                $path = $archivo->store("solicitudes/{$solicitud->edificio_id}", 'public');
                $archivos[] = [
                    'nombre' => $archivo->getClientOriginalName(),
                    'path' => $path,
                ];
            }
        }

        DB::table('seguimiento_solicitudes')->insert([
            'solicitud_id' => $id,
            'acceso_id' => $acceso->id,
            'tipo' => 'comentario',
            'contenido' => $request->comentario,
            'archivos' => !empty($archivos) ? json_encode($archivos) : null,
            'visible_copropietario' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Cambiar estado si estaba pendiente de respuesta
        if ($solicitud->estado === 'pendiente_respuesta') {
            DB::table('solicitudes_copropietarios')
                ->where('id', $id)
                ->update([
                    'estado' => 'en_proceso',
                    'updated_at' => now(),
                ]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Comentario agregado.'
        ]);
    }

    /**
     * Calificar solicitud resuelta
     */
    public function calificar(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'calificacion' => 'required|integer|min:1|max:5',
            'comentario' => 'nullable|string|max:500',
        ]);

        $acceso = $request->attributes->get('acceso_portal');

        $solicitud = DB::table('solicitudes_copropietarios')
            ->where('id', $id)
            ->where('acceso_id', $acceso->id)
            ->whereIn('estado', ['resuelta', 'cerrada'])
            ->whereNull('calificacion')
            ->first();

        if (!$solicitud) {
            return response()->json([
                'success' => false,
                'message' => 'Solicitud no encontrada o ya calificada.'
            ], 404);
        }

        DB::table('solicitudes_copropietarios')
            ->where('id', $id)
            ->update([
                'calificacion' => $request->calificacion,
                'comentario_calificacion' => $request->comentario,
                'updated_at' => now(),
            ]);

        return response()->json([
            'success' => true,
            'message' => 'Gracias por tu calificación.'
        ]);
    }

    /**
     * Cerrar solicitud (por el copropietario)
     */
    public function cerrar(Request $request, int $id): JsonResponse
    {
        $acceso = $request->attributes->get('acceso_portal');

        $solicitud = DB::table('solicitudes_copropietarios')
            ->where('id', $id)
            ->where('acceso_id', $acceso->id)
            ->whereNotIn('estado', ['cerrada', 'rechazada'])
            ->first();

        if (!$solicitud) {
            return response()->json([
                'success' => false,
                'message' => 'Solicitud no encontrada.'
            ], 404);
        }

        DB::table('solicitudes_copropietarios')
            ->where('id', $id)
            ->update([
                'estado' => 'cerrada',
                'cerrada_at' => now(),
                'updated_at' => now(),
            ]);

        DB::table('seguimiento_solicitudes')->insert([
            'solicitud_id' => $id,
            'acceso_id' => $acceso->id,
            'tipo' => 'cambio_estado',
            'estado_anterior' => $solicitud->estado,
            'estado_nuevo' => 'cerrada',
            'contenido' => 'Solicitud cerrada por el copropietario',
            'visible_copropietario' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Solicitud cerrada.'
        ]);
    }

    /**
     * Obtener tipos y categorías disponibles
     */
    public function catalogos(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data' => [
                'tipos' => [
                    ['id' => 'reclamo', 'nombre' => 'Reclamo'],
                    ['id' => 'sugerencia', 'nombre' => 'Sugerencia'],
                    ['id' => 'consulta', 'nombre' => 'Consulta'],
                    ['id' => 'solicitud_reparacion', 'nombre' => 'Solicitud de Reparación'],
                    ['id' => 'solicitud_certificado', 'nombre' => 'Solicitud de Certificado'],
                    ['id' => 'solicitud_documentos', 'nombre' => 'Solicitud de Documentos'],
                    ['id' => 'denuncia', 'nombre' => 'Denuncia'],
                    ['id' => 'felicitacion', 'nombre' => 'Felicitación'],
                    ['id' => 'otro', 'nombre' => 'Otro'],
                ],
                'categorias' => [
                    ['id' => 'administracion', 'nombre' => 'Administración'],
                    ['id' => 'mantencion', 'nombre' => 'Mantención'],
                    ['id' => 'seguridad', 'nombre' => 'Seguridad'],
                    ['id' => 'areas_comunes', 'nombre' => 'Áreas Comunes'],
                    ['id' => 'ruidos_molestias', 'nombre' => 'Ruidos y Molestias'],
                    ['id' => 'estacionamientos', 'nombre' => 'Estacionamientos'],
                    ['id' => 'mascotas', 'nombre' => 'Mascotas'],
                    ['id' => 'gastos_comunes', 'nombre' => 'Gastos Comunes'],
                    ['id' => 'otro', 'nombre' => 'Otro'],
                ],
                'prioridades' => [
                    ['id' => 'baja', 'nombre' => 'Baja'],
                    ['id' => 'media', 'nombre' => 'Media'],
                    ['id' => 'alta', 'nombre' => 'Alta'],
                    ['id' => 'urgente', 'nombre' => 'Urgente'],
                ],
            ],
        ]);
    }
}
