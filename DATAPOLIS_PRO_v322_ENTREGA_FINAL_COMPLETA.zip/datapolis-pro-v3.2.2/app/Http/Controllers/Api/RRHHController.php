<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - RRHH Controller
 * Cumplimiento Código del Trabajo Chile
 */
class RRHHController extends Controller
{
    /**
     * Listar empleados
     */
    public function empleados(Request $request): JsonResponse
    {
        $query = DB::table('empleados')
            ->leftJoin('edificios', 'empleados.edificio_id', '=', 'edificios.id')
            ->where('empleados.tenant_id', Auth::user()->tenant_id)
            ->whereNull('empleados.deleted_at');

        if ($request->estado) {
            $query->where('empleados.estado', $request->estado);
        }

        if ($request->edificio_id) {
            $query->where('empleados.edificio_id', $request->edificio_id);
        }

        if ($request->search) {
            $query->where(function ($q) use ($request) {
                $q->where('empleados.nombre_completo', 'like', "%{$request->search}%")
                  ->orWhere('empleados.rut', 'like', "%{$request->search}%");
            });
        }

        $empleados = $query->select('empleados.*', 'edificios.nombre as edificio')
            ->orderBy('empleados.nombre_completo')
            ->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $empleados]);
    }

    /**
     * Crear empleado
     */
    public function crearEmpleado(Request $request): JsonResponse
    {
        $request->validate([
            'rut' => 'required|string|max:12',
            'nombre' => 'required|string|max:100',
            'apellido_paterno' => 'required|string|max:100',
            'cargo' => 'required|string|max:100',
            'tipo_contrato' => 'required|in:indefinido,plazo_fijo,por_obra,honorarios',
            'fecha_ingreso' => 'required|date',
            'sueldo_base' => 'required|numeric|min:0',
            'afp' => 'required|string',
        ]);

        $nombreCompleto = trim("{$request->nombre} {$request->apellido_paterno} {$request->apellido_materno}");

        $id = DB::table('empleados')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'rut' => $request->rut,
            'nombre' => $request->nombre,
            'apellido_paterno' => $request->apellido_paterno,
            'apellido_materno' => $request->apellido_materno,
            'nombre_completo' => $nombreCompleto,
            'fecha_nacimiento' => $request->fecha_nacimiento,
            'direccion' => $request->direccion,
            'telefono' => $request->telefono,
            'email' => $request->email,
            'cargo' => $request->cargo,
            'tipo_contrato' => $request->tipo_contrato,
            'fecha_ingreso' => $request->fecha_ingreso,
            'fecha_termino' => $request->fecha_termino,
            'sueldo_base' => $request->sueldo_base,
            'afp' => $request->afp,
            'isapre' => $request->isapre ?? 'fonasa',
            'plan_isapre' => $request->plan_isapre,
            'cuenta_banco' => $request->cuenta_banco,
            'tipo_cuenta' => $request->tipo_cuenta,
            'banco' => $request->banco,
            'estado' => 'activo',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Empleado creado exitosamente',
            'id' => $id,
        ], 201);
    }

    /**
     * Mostrar empleado
     */
    public function showEmpleado(int $id): JsonResponse
    {
        $empleado = DB::table('empleados')
            ->leftJoin('edificios', 'empleados.edificio_id', '=', 'edificios.id')
            ->where('empleados.id', $id)
            ->where('empleados.tenant_id', Auth::user()->tenant_id)
            ->select('empleados.*', 'edificios.nombre as edificio')
            ->first();

        if (!$empleado) {
            return response()->json(['success' => false, 'message' => 'Empleado no encontrado'], 404);
        }

        // Últimas liquidaciones
        $empleado->liquidaciones = DB::table('liquidaciones')
            ->where('empleado_id', $id)
            ->orderByDesc('anio')
            ->orderByDesc('mes')
            ->limit(12)
            ->get();

        return response()->json(['success' => true, 'data' => $empleado]);
    }

    /**
     * Actualizar empleado
     */
    public function updateEmpleado(Request $request, int $id): JsonResponse
    {
        $empleado = DB::table('empleados')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$empleado) {
            return response()->json(['success' => false, 'message' => 'Empleado no encontrado'], 404);
        }

        $data = array_filter($request->only([
            'cargo', 'sueldo_base', 'afp', 'isapre', 'plan_isapre',
            'direccion', 'telefono', 'email', 'cuenta_banco', 'tipo_cuenta', 'banco',
            'edificio_id', 'estado',
        ]), fn($v) => $v !== null);

        $data['updated_at'] = now();

        DB::table('empleados')->where('id', $id)->update($data);

        return response()->json(['success' => true, 'message' => 'Empleado actualizado']);
    }

    /**
     * Listar liquidaciones
     */
    public function liquidaciones(Request $request): JsonResponse
    {
        $query = DB::table('liquidaciones')
            ->join('empleados', 'liquidaciones.empleado_id', '=', 'empleados.id')
            ->where('liquidaciones.tenant_id', Auth::user()->tenant_id);

        if ($request->empleado_id) {
            $query->where('liquidaciones.empleado_id', $request->empleado_id);
        }

        if ($request->mes && $request->anio) {
            $query->where('liquidaciones.mes', $request->mes)
                  ->where('liquidaciones.anio', $request->anio);
        }

        if ($request->estado) {
            $query->where('liquidaciones.estado', $request->estado);
        }

        $liquidaciones = $query->select('liquidaciones.*', 'empleados.nombre_completo', 'empleados.rut')
            ->orderByDesc('liquidaciones.anio')
            ->orderByDesc('liquidaciones.mes')
            ->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $liquidaciones]);
    }

    /**
     * Calcular liquidación
     */
    public function calcularLiquidacion(Request $request): JsonResponse
    {
        $request->validate([
            'empleado_id' => 'required|exists:empleados,id',
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
        ]);

        $empleado = DB::table('empleados')->where('id', $request->empleado_id)->first();
        
        if (!$empleado || $empleado->estado !== 'activo') {
            return response()->json(['success' => false, 'message' => 'Empleado no válido'], 422);
        }

        // Verificar si ya existe
        $existe = DB::table('liquidaciones')
            ->where('empleado_id', $request->empleado_id)
            ->where('mes', $request->mes)
            ->where('anio', $request->anio)
            ->first();

        if ($existe) {
            return response()->json([
                'success' => false,
                'message' => 'Ya existe liquidación para este período',
                'liquidacion_id' => $existe->id,
            ], 422);
        }

        // Valores tributarios
        $config = config('datapolis.tributario');
        $uf = $config['uf'];
        $utm = $config['utm'];
        $tasaAfp = $config['tasas_afp'][strtolower($empleado->afp)] ?? 11.44;
        $topeImponible = $config['tope_imponible_afp'] * $uf;

        // Haberes
        $sueldoBase = $empleado->sueldo_base;
        $gratificacion = min($sueldoBase * 0.25, 4.75 * $utm / 12);
        $colacion = $request->colacion ?? 0;
        $movilizacion = $request->movilizacion ?? 0;
        $bonoAsistencia = $request->bono_asistencia ?? 0;
        $horasExtras = $request->horas_extras ?? 0;
        $otrosHaberes = $request->otros_haberes ?? 0;

        $totalHaberes = $sueldoBase + $gratificacion + $colacion + $movilizacion + 
                       $bonoAsistencia + $horasExtras + $otrosHaberes;

        // Base imponible (excluye colación y movilización)
        $baseImponible = min($sueldoBase + $gratificacion + $bonoAsistencia + $horasExtras, $topeImponible);

        // Descuentos legales
        $afpMonto = round($baseImponible * ($tasaAfp / 100), 0);
        
        $saludMonto = 0;
        if ($empleado->isapre === 'fonasa') {
            $saludMonto = round($baseImponible * 0.07, 0);
        } else {
            $saludMonto = round(($empleado->plan_isapre ?? 7) * $uf / 100 * $baseImponible, 0);
        }

        // Seguro de cesantía
        $tasaCesantia = $empleado->tipo_contrato === 'indefinido' ? 0.6 : 0;
        $cesantiaMonto = round($baseImponible * ($tasaCesantia / 100), 0);

        // Impuesto único
        $baseImpuesto = $baseImponible - $afpMonto - $saludMonto;
        $impuesto = $this->calcularImpuestoUnico($baseImpuesto, $utm);

        $totalDescuentos = $afpMonto + $saludMonto + $cesantiaMonto + $impuesto + ($request->otros_descuentos ?? 0);
        $liquido = $totalHaberes - $totalDescuentos;

        // Crear liquidación
        $liquidacionId = DB::table('liquidaciones')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'empleado_id' => $request->empleado_id,
            'mes' => $request->mes,
            'anio' => $request->anio,
            'dias_trabajados' => $request->dias_trabajados ?? 30,
            'sueldo_base' => $sueldoBase,
            'gratificacion' => $gratificacion,
            'colacion' => $colacion,
            'movilizacion' => $movilizacion,
            'bono_asistencia' => $bonoAsistencia,
            'horas_extras' => $horasExtras,
            'otros_haberes' => $otrosHaberes,
            'total_haberes' => $totalHaberes,
            'base_imponible' => $baseImponible,
            'afp' => $empleado->afp,
            'afp_monto' => $afpMonto,
            'salud' => $empleado->isapre,
            'salud_monto' => $saludMonto,
            'cesantia_monto' => $cesantiaMonto,
            'impuesto_unico' => $impuesto,
            'otros_descuentos' => $request->otros_descuentos ?? 0,
            'total_descuentos' => $totalDescuentos,
            'liquido' => $liquido,
            'estado' => 'borrador',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Liquidación calculada',
            'id' => $liquidacionId,
            'resumen' => [
                'total_haberes' => $totalHaberes,
                'total_descuentos' => $totalDescuentos,
                'liquido' => $liquido,
            ],
        ], 201);
    }

    /**
     * Mostrar liquidación
     */
    public function showLiquidacion(int $id): JsonResponse
    {
        $liquidacion = DB::table('liquidaciones')
            ->join('empleados', 'liquidaciones.empleado_id', '=', 'empleados.id')
            ->where('liquidaciones.id', $id)
            ->where('liquidaciones.tenant_id', Auth::user()->tenant_id)
            ->select('liquidaciones.*', 'empleados.nombre_completo', 'empleados.rut', 
                     'empleados.cargo', 'empleados.fecha_ingreso')
            ->first();

        if (!$liquidacion) {
            return response()->json(['success' => false, 'message' => 'Liquidación no encontrada'], 404);
        }

        return response()->json(['success' => true, 'data' => $liquidacion]);
    }

    /**
     * Aprobar liquidación
     */
    public function aprobarLiquidacion(int $id): JsonResponse
    {
        $liquidacion = DB::table('liquidaciones')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$liquidacion) {
            return response()->json(['success' => false, 'message' => 'Liquidación no encontrada'], 404);
        }

        if ($liquidacion->estado !== 'borrador') {
            return response()->json(['success' => false, 'message' => 'Solo se pueden aprobar liquidaciones en borrador'], 422);
        }

        DB::table('liquidaciones')->where('id', $id)->update([
            'estado' => 'aprobada',
            'aprobado_por' => Auth::id(),
            'aprobado_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Liquidación aprobada']);
    }

    /**
     * Generar PDF de liquidación
     */
    public function liquidacionPdf(int $id)
    {
        $liquidacion = DB::table('liquidaciones')
            ->join('empleados', 'liquidaciones.empleado_id', '=', 'empleados.id')
            ->leftJoin('edificios', 'empleados.edificio_id', '=', 'edificios.id')
            ->where('liquidaciones.id', $id)
            ->select('liquidaciones.*', 'empleados.*', 'edificios.nombre as edificio', 
                     'edificios.rut as edificio_rut')
            ->first();

        if (!$liquidacion) {
            return response()->json(['success' => false, 'message' => 'Liquidación no encontrada'], 404);
        }

        $pdf = Pdf::loadView('pdf.liquidacion', compact('liquidacion'));
        
        $nombreArchivo = sprintf('liquidacion-%s-%04d-%02d.pdf', 
            str_replace(['.', '-'], '', $liquidacion->rut),
            $liquidacion->anio,
            $liquidacion->mes
        );

        return $pdf->download($nombreArchivo);
    }

    /**
     * Libro de remuneraciones
     */
    public function libroRemuneraciones(Request $request): JsonResponse
    {
        $request->validate([
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
        ]);

        $liquidaciones = DB::table('liquidaciones')
            ->join('empleados', 'liquidaciones.empleado_id', '=', 'empleados.id')
            ->where('liquidaciones.tenant_id', Auth::user()->tenant_id)
            ->where('liquidaciones.mes', $request->mes)
            ->where('liquidaciones.anio', $request->anio)
            ->where('liquidaciones.estado', 'aprobada')
            ->select('liquidaciones.*', 'empleados.nombre_completo', 'empleados.rut')
            ->orderBy('empleados.nombre_completo')
            ->get();

        $totales = [
            'total_haberes' => $liquidaciones->sum('total_haberes'),
            'total_descuentos' => $liquidaciones->sum('total_descuentos'),
            'total_liquido' => $liquidaciones->sum('liquido'),
            'total_afp' => $liquidaciones->sum('afp_monto'),
            'total_salud' => $liquidaciones->sum('salud_monto'),
            'total_cesantia' => $liquidaciones->sum('cesantia_monto'),
            'total_impuesto' => $liquidaciones->sum('impuesto_unico'),
        ];

        return response()->json([
            'success' => true,
            'data' => [
                'periodo' => ['mes' => $request->mes, 'anio' => $request->anio],
                'liquidaciones' => $liquidaciones,
                'totales' => $totales,
            ],
        ]);
    }

    /**
     * Generar finiquito
     */
    public function generarFiniquito(int $id, Request $request): JsonResponse
    {
        $request->validate([
            'fecha_termino' => 'required|date',
            'causal' => 'required|string',
        ]);

        $empleado = DB::table('empleados')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$empleado) {
            return response()->json(['success' => false, 'message' => 'Empleado no encontrado'], 404);
        }

        $fechaIngreso = Carbon::parse($empleado->fecha_ingreso);
        $fechaTermino = Carbon::parse($request->fecha_termino);
        $aniosServicio = $fechaIngreso->diffInYears($fechaTermino);
        $mesesServicio = $fechaIngreso->diffInMonths($fechaTermino);

        // Cálculo de indemnización (si aplica)
        $indemnizacion = 0;
        if (in_array($request->causal, ['necesidades_empresa', 'desahucio'])) {
            $indemnizacion = min($aniosServicio, 11) * $empleado->sueldo_base;
        }

        // Vacaciones proporcionales
        $vacacionesPendientes = $request->dias_vacaciones_pendientes ?? 0;
        $valorDiaVacacion = $empleado->sueldo_base / 30;
        $pagoVacaciones = $vacacionesPendientes * $valorDiaVacacion;

        // Mes de aviso (si aplica)
        $mesAviso = in_array($request->causal, ['necesidades_empresa']) ? $empleado->sueldo_base : 0;

        $totalFiniquito = $indemnizacion + $pagoVacaciones + $mesAviso;

        // Actualizar empleado
        DB::table('empleados')->where('id', $id)->update([
            'estado' => 'finiquitado',
            'fecha_termino' => $request->fecha_termino,
            'updated_at' => now(),
        ]);

        // Crear registro de finiquito
        $finiquitoId = DB::table('finiquitos')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'empleado_id' => $id,
            'fecha_termino' => $request->fecha_termino,
            'causal' => $request->causal,
            'anios_servicio' => $aniosServicio,
            'meses_servicio' => $mesesServicio,
            'indemnizacion' => $indemnizacion,
            'vacaciones_pendientes' => $vacacionesPendientes,
            'pago_vacaciones' => $pagoVacaciones,
            'mes_aviso' => $mesAviso,
            'total' => $totalFiniquito,
            'estado' => 'pendiente',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Finiquito generado',
            'id' => $finiquitoId,
            'resumen' => [
                'indemnizacion' => $indemnizacion,
                'vacaciones' => $pagoVacaciones,
                'mes_aviso' => $mesAviso,
                'total' => $totalFiniquito,
            ],
        ]);
    }

    /**
     * Calcular impuesto único segunda categoría
     */
    private function calcularImpuestoUnico(float $baseImponible, float $utm): float
    {
        $tramos = config('datapolis.tributario.impuesto_unico');
        $baseEnUtm = $baseImponible / $utm;

        foreach ($tramos as $tramo) {
            if ($baseEnUtm >= $tramo['desde'] && $baseEnUtm < $tramo['hasta']) {
                $impuesto = ($baseImponible * ($tramo['tasa'] / 100)) - ($tramo['rebaja'] * $utm);
                return max(0, round($impuesto, 0));
            }
        }

        return 0;
    }
}
