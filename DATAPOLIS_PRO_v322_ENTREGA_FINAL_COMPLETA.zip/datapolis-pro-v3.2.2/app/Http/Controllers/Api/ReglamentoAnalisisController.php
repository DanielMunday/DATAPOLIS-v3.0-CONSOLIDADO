<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\ReglamentoCopropiedadAnalyzerService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use App\Models\Edificio;
use App\Models\Reglamento;
use App\Models\AnalisisReglamento;

/**
 * ReglamentoAnalisisController
 * 
 * API REST para análisis de reglamentos de copropiedad
 * según Ley 21.442 y DS 7-2025
 * 
 * @package DATAPOLIS PRO v3.0
 * @author Daniel - DATAPOLIS
 * @version 1.0.0
 */
class ReglamentoAnalisisController extends Controller
{
    protected ReglamentoCopropiedadAnalyzerService $analyzerService;

    public function __construct(ReglamentoCopropiedadAnalyzerService $analyzerService)
    {
        $this->analyzerService = $analyzerService;
    }

    /**
     * Analizar reglamento de copropiedad
     * 
     * POST /api/v1/reglamentos/analizar
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function analizar(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'edificio_id' => 'required|integer|exists:edificios,id',
            'texto_reglamento' => 'required_without:archivo|string|min:100',
            'archivo' => 'required_without:texto_reglamento|file|mimes:pdf,doc,docx,txt|max:10240',
            'fecha_inscripcion_cbr' => 'nullable|date|before_or_equal:today',
            'notaria' => 'nullable|string|max:255',
            'numero_inscripcion' => 'nullable|string|max:100',
        ], [
            'edificio_id.required' => 'Debe especificar el edificio',
            'edificio_id.exists' => 'El edificio no existe en el sistema',
            'texto_reglamento.required_without' => 'Debe proporcionar el texto del reglamento o subir un archivo',
            'texto_reglamento.min' => 'El texto del reglamento es demasiado corto para analizar',
            'archivo.mimes' => 'El archivo debe ser PDF, DOC, DOCX o TXT',
            'archivo.max' => 'El archivo no puede superar 10MB',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Validación fallida',
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            // Verificar permisos sobre el edificio
            $edificio = Edificio::findOrFail($request->edificio_id);
            $this->authorize('analizar-reglamento', $edificio);

            // Obtener texto del reglamento
            $textoReglamento = $request->texto_reglamento;
            
            if ($request->hasFile('archivo')) {
                $textoReglamento = $this->extraerTextoArchivo($request->file('archivo'));
            }

            // Ejecutar análisis
            $resultado = $this->analyzerService->analizarReglamento(
                $textoReglamento,
                $request->edificio_id,
                $request->fecha_inscripcion_cbr
            );

            // Guardar análisis en BD
            $analisis = AnalisisReglamento::create([
                'edificio_id' => $request->edificio_id,
                'usuario_id' => Auth::id(),
                'score_global' => $resultado['resumen_ejecutivo']['score_global'],
                'nivel_cumplimiento' => $resultado['resumen_ejecutivo']['nivel_cumplimiento'],
                'elementos_ok' => $resultado['resumen_ejecutivo']['elementos_ok'],
                'elementos_faltantes' => $resultado['resumen_ejecutivo']['elementos_faltantes'],
                'resultado_completo' => json_encode($resultado),
                'fecha_inscripcion_cbr' => $request->fecha_inscripcion_cbr,
                'notaria' => $request->notaria,
                'numero_inscripcion' => $request->numero_inscripcion,
                'created_at' => now(),
            ]);

            Log::info('Análisis de reglamento completado', [
                'edificio_id' => $request->edificio_id,
                'analisis_id' => $analisis->id,
                'score' => $resultado['resumen_ejecutivo']['score_global'],
            ]);

            return response()->json([
                'success' => true,
                'data' => [
                    'analisis_id' => $analisis->id,
                    'resultado' => $resultado,
                ],
                'mensaje' => 'Análisis completado exitosamente',
            ], 200);

        } catch (\Illuminate\Auth\Access\AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'error' => 'No tiene permisos para analizar reglamentos de este edificio',
            ], 403);
        } catch (\Exception $e) {
            Log::error('Error en análisis de reglamento', [
                'edificio_id' => $request->edificio_id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Error al procesar el análisis',
                'detalle' => config('app.debug') ? $e->getMessage() : null,
            ], 500);
        }
    }

    /**
     * Obtener historial de análisis de un edificio
     * 
     * GET /api/v1/reglamentos/historial/{edificioId}
     */
    public function historial(int $edificioId): JsonResponse
    {
        try {
            $edificio = Edificio::findOrFail($edificioId);
            $this->authorize('ver-reglamento', $edificio);

            $analisis = AnalisisReglamento::where('edificio_id', $edificioId)
                ->orderBy('created_at', 'desc')
                ->limit(20)
                ->get()
                ->map(function ($item) {
                    return [
                        'id' => $item->id,
                        'fecha' => $item->created_at->format('Y-m-d H:i'),
                        'score_global' => $item->score_global,
                        'nivel_cumplimiento' => $item->nivel_cumplimiento,
                        'elementos_ok' => $item->elementos_ok,
                        'elementos_faltantes' => $item->elementos_faltantes,
                        'usuario' => $item->usuario->nombre ?? 'Sistema',
                    ];
                });

            return response()->json([
                'success' => true,
                'data' => $analisis,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al obtener historial',
            ], 500);
        }
    }

    /**
     * Obtener detalle de un análisis específico
     * 
     * GET /api/v1/reglamentos/analisis/{id}
     */
    public function detalle(int $id): JsonResponse
    {
        try {
            $analisis = AnalisisReglamento::with('edificio')->findOrFail($id);
            $this->authorize('ver-reglamento', $analisis->edificio);

            return response()->json([
                'success' => true,
                'data' => [
                    'id' => $analisis->id,
                    'edificio' => [
                        'id' => $analisis->edificio->id,
                        'nombre' => $analisis->edificio->nombre,
                    ],
                    'fecha_analisis' => $analisis->created_at->format('Y-m-d H:i'),
                    'resultado' => json_decode($analisis->resultado_completo, true),
                ],
            ]);

        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'error' => 'Análisis no encontrado',
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al obtener detalle',
            ], 500);
        }
    }

    /**
     * Generar informe PDF del análisis
     * 
     * GET /api/v1/reglamentos/analisis/{id}/pdf
     */
    public function generarPdf(int $id): JsonResponse
    {
        try {
            $analisis = AnalisisReglamento::with('edificio')->findOrFail($id);
            $this->authorize('ver-reglamento', $analisis->edificio);

            $resultado = json_decode($analisis->resultado_completo, true);
            
            // Generar PDF usando DomPDF o similar
            $pdf = \PDF::loadView('reportes.analisis-reglamento', [
                'analisis' => $analisis,
                'resultado' => $resultado,
                'edificio' => $analisis->edificio,
            ]);

            $filename = "analisis_reglamento_{$analisis->edificio->id}_{$analisis->id}.pdf";
            $path = "reportes/reglamentos/{$filename}";
            
            Storage::disk('public')->put($path, $pdf->output());

            return response()->json([
                'success' => true,
                'data' => [
                    'url' => Storage::disk('public')->url($path),
                    'filename' => $filename,
                    'expira' => now()->addDays(7)->format('Y-m-d'),
                ],
            ]);

        } catch (\Exception $e) {
            Log::error('Error generando PDF de análisis', [
                'analisis_id' => $id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Error al generar PDF',
            ], 500);
        }
    }

    /**
     * Comparar dos análisis (evolución)
     * 
     * POST /api/v1/reglamentos/comparar
     */
    public function comparar(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'analisis_anterior_id' => 'required|integer|exists:analisis_reglamentos,id',
            'analisis_actual_id' => 'required|integer|exists:analisis_reglamentos,id|different:analisis_anterior_id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $anterior = AnalisisReglamento::findOrFail($request->analisis_anterior_id);
            $actual = AnalisisReglamento::findOrFail($request->analisis_actual_id);

            // Verificar que son del mismo edificio
            if ($anterior->edificio_id !== $actual->edificio_id) {
                return response()->json([
                    'success' => false,
                    'error' => 'Los análisis deben ser del mismo edificio',
                ], 422);
            }

            $this->authorize('ver-reglamento', $anterior->edificio);

            $resultadoAnterior = json_decode($anterior->resultado_completo, true);
            $resultadoActual = json_decode($actual->resultado_completo, true);

            $comparacion = [
                'edificio_id' => $anterior->edificio_id,
                'periodo' => [
                    'desde' => $anterior->created_at->format('Y-m-d'),
                    'hasta' => $actual->created_at->format('Y-m-d'),
                    'dias_transcurridos' => $anterior->created_at->diffInDays($actual->created_at),
                ],
                'evolucion_score' => [
                    'anterior' => $anterior->score_global,
                    'actual' => $actual->score_global,
                    'diferencia' => $actual->score_global - $anterior->score_global,
                    'porcentaje_mejora' => $anterior->score_global > 0 
                        ? round((($actual->score_global - $anterior->score_global) / $anterior->score_global) * 100, 1)
                        : 0,
                ],
                'elementos_mejorados' => $this->calcularElementosMejorados(
                    $resultadoAnterior['analisis_detallado'] ?? [],
                    $resultadoActual['analisis_detallado'] ?? []
                ),
                'elementos_pendientes' => $this->calcularElementosPendientes(
                    $resultadoActual['analisis_detallado'] ?? []
                ),
                'recomendacion' => $this->generarRecomendacionEvolucion(
                    $anterior->score_global,
                    $actual->score_global
                ),
            ];

            return response()->json([
                'success' => true,
                'data' => $comparacion,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al comparar análisis',
            ], 500);
        }
    }

    /**
     * Extraer texto de archivo subido
     */
    private function extraerTextoArchivo($archivo): string
    {
        $extension = $archivo->getClientOriginalExtension();
        $path = $archivo->store('temp/reglamentos');
        $fullPath = Storage::path($path);

        $texto = '';

        switch (strtolower($extension)) {
            case 'txt':
                $texto = file_get_contents($fullPath);
                break;
            
            case 'pdf':
                // Usar pdftotext o Smalot\PdfParser
                $parser = new \Smalot\PdfParser\Parser();
                $pdf = $parser->parseFile($fullPath);
                $texto = $pdf->getText();
                break;
            
            case 'doc':
            case 'docx':
                // Usar PhpWord
                $phpWord = \PhpOffice\PhpWord\IOFactory::load($fullPath);
                foreach ($phpWord->getSections() as $section) {
                    foreach ($section->getElements() as $element) {
                        if (method_exists($element, 'getText')) {
                            $texto .= $element->getText() . "\n";
                        }
                    }
                }
                break;
        }

        // Limpiar archivo temporal
        Storage::delete($path);

        return $texto;
    }

    private function calcularElementosMejorados(array $anterior, array $actual): array
    {
        $mejorados = [];
        
        foreach ($actual as $elemento => $datos) {
            $cumpliaAntes = $anterior[$elemento]['cumple'] ?? false;
            $cumpleAhora = $datos['cumple'] ?? false;
            
            if (!$cumpliaAntes && $cumpleAhora) {
                $mejorados[] = [
                    'elemento' => $elemento,
                    'descripcion' => $datos['descripcion'] ?? '',
                ];
            }
        }
        
        return $mejorados;
    }

    private function calcularElementosPendientes(array $actual): array
    {
        $pendientes = [];
        
        foreach ($actual as $elemento => $datos) {
            if (!($datos['cumple'] ?? false)) {
                $pendientes[] = [
                    'elemento' => $elemento,
                    'descripcion' => $datos['descripcion'] ?? '',
                    'criticidad' => $datos['criticidad'] ?? 'media',
                ];
            }
        }
        
        return $pendientes;
    }

    private function generarRecomendacionEvolucion(float $anterior, float $actual): array
    {
        $diferencia = $actual - $anterior;
        
        if ($diferencia > 20) {
            return [
                'tipo' => 'excelente',
                'mensaje' => 'Excelente progreso. El reglamento ha mejorado significativamente.',
                'icono' => '🎉',
            ];
        } elseif ($diferencia > 10) {
            return [
                'tipo' => 'bueno',
                'mensaje' => 'Buen avance. Continúe con las mejoras pendientes.',
                'icono' => '👍',
            ];
        } elseif ($diferencia > 0) {
            return [
                'tipo' => 'moderado',
                'mensaje' => 'Avance moderado. Se recomienda acelerar la actualización.',
                'icono' => '📈',
            ];
        } elseif ($diferencia === 0) {
            return [
                'tipo' => 'sin_cambio',
                'mensaje' => 'Sin cambios detectados. Revise los elementos pendientes.',
                'icono' => '➡️',
            ];
        } else {
            return [
                'tipo' => 'retroceso',
                'mensaje' => 'Se detectó retroceso. Verifique cambios recientes al reglamento.',
                'icono' => '⚠️',
            ];
        }
    }
}
