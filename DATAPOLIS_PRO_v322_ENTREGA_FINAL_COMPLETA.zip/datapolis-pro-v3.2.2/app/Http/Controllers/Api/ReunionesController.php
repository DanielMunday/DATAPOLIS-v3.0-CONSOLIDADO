<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.0 - Reuniones y Asambleas Controller
 * Cumplimiento Ley 21.442 de Copropiedad Inmobiliaria
 */
class ReunionesController extends Controller
{
    /**
     * Listar reuniones
     */
    public function index(Request $request): JsonResponse
    {
        $query = DB::table('reuniones')
            ->join('edificios', 'reuniones.edificio_id', '=', 'edificios.id')
            ->where('reuniones.tenant_id', Auth::user()->tenant_id)
            ->when($request->edificio_id, fn($q) => $q->where('reuniones.edificio_id', $request->edificio_id))
            ->when($request->tipo, fn($q) => $q->where('reuniones.tipo', $request->tipo))
            ->when($request->estado, fn($q) => $q->where('reuniones.estado', $request->estado));

        $reuniones = $query->select('reuniones.*', 'edificios.nombre as edificio')
            ->orderByDesc('reuniones.fecha_inicio')
            ->paginate($request->get('per_page', 20));

        return response()->json(['success' => true, 'data' => $reuniones]);
    }

    /**
     * Crear reunión
     */
    public function crear(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'tipo' => 'required|in:ordinaria,extraordinaria,comite,directorio',
            'titulo' => 'required|string|max:300',
            'fecha_inicio' => 'required|date|after:now',
            'lugar' => 'required|string|max:300',
        ]);

        // Validar quórum según tipo (Ley 21.442)
        $quorum = match($request->tipo) {
            'ordinaria' => config('datapolis.asambleas.quorum.primera_citacion', 60),
            'extraordinaria' => config('datapolis.asambleas.quorum.extraordinaria', 66.67),
            default => 50,
        };

        $id = DB::table('reuniones')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'tipo' => $request->tipo,
            'titulo' => $request->titulo,
            'descripcion' => $request->descripcion,
            'fecha_inicio' => $request->fecha_inicio,
            'fecha_fin' => $request->fecha_fin,
            'lugar' => $request->lugar,
            'modalidad' => $request->modalidad ?? 'presencial',
            'enlace_virtual' => $request->enlace_virtual,
            'quorum_requerido' => $quorum,
            'estado' => 'programada',
            'citacion' => $request->citacion,
            'created_by' => Auth::id(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Crear tabla de materias si se proporcionan
        if ($request->has('materias')) {
            foreach ($request->materias as $orden => $materia) {
                DB::table('materias_reunion')->insert([
                    'reunion_id' => $id,
                    'orden' => $orden + 1,
                    'titulo' => $materia['titulo'],
                    'descripcion' => $materia['descripcion'] ?? null,
                    'requiere_votacion' => $materia['requiere_votacion'] ?? false,
                    'created_at' => now(),
                ]);
            }
        }

        return response()->json(['success' => true, 'message' => 'Reunión creada', 'id' => $id], 201);
    }

    /**
     * Mostrar reunión
     */
    public function show(int $id): JsonResponse
    {
        $reunion = DB::table('reuniones')
            ->join('edificios', 'reuniones.edificio_id', '=', 'edificios.id')
            ->where('reuniones.id', $id)
            ->where('reuniones.tenant_id', Auth::user()->tenant_id)
            ->select('reuniones.*', 'edificios.nombre as edificio', 'edificios.direccion as edificio_direccion')
            ->first();

        if (!$reunion) {
            return response()->json(['success' => false, 'message' => 'Reunión no encontrada'], 404);
        }

        $reunion->materias = DB::table('materias_reunion')
            ->where('reunion_id', $id)
            ->orderBy('orden')
            ->get();

        $reunion->asistencia = DB::table('asistencia_reunion')
            ->join('unidades', 'asistencia_reunion.unidad_id', '=', 'unidades.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('asistencia_reunion.reunion_id', $id)
            ->select(
                'asistencia_reunion.*',
                'unidades.numero',
                'unidades.prorrateo',
                'personas.nombre_completo as propietario'
            )
            ->get();

        $reunion->votaciones = DB::table('votaciones')
            ->where('reunion_id', $id)
            ->get();

        // Calcular quórum actual
        $totalProrrateo = DB::table('unidades')
            ->where('edificio_id', $reunion->edificio_id)
            ->where('activa', true)
            ->sum('prorrateo');

        $prorrateoPresente = $reunion->asistencia->where('presente', true)->sum('prorrateo');
        $reunion->quorum_actual = $totalProrrateo > 0 ? round(($prorrateoPresente / $totalProrrateo) * 100, 2) : 0;
        $reunion->hay_quorum = $reunion->quorum_actual >= $reunion->quorum_requerido;

        return response()->json(['success' => true, 'data' => $reunion]);
    }

    /**
     * Actualizar reunión
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $reunion = DB::table('reuniones')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$reunion) {
            return response()->json(['success' => false, 'message' => 'Reunión no encontrada'], 404);
        }

        if (!in_array($reunion->estado, ['programada', 'convocada'])) {
            return response()->json(['success' => false, 'message' => 'Solo se pueden editar reuniones programadas o convocadas'], 422);
        }

        DB::table('reuniones')->where('id', $id)->update(array_merge(
            array_filter($request->only([
                'titulo', 'descripcion', 'fecha_inicio', 'fecha_fin',
                'lugar', 'modalidad', 'enlace_virtual', 'citacion',
            ]), fn($v) => $v !== null),
            ['updated_at' => now()]
        ));

        return response()->json(['success' => true, 'message' => 'Reunión actualizada']);
    }

    /**
     * Convocar reunión
     */
    public function convocar(int $id): JsonResponse
    {
        $reunion = DB::table('reuniones')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$reunion) {
            return response()->json(['success' => false, 'message' => 'Reunión no encontrada'], 404);
        }

        if ($reunion->estado !== 'programada') {
            return response()->json(['success' => false, 'message' => 'Solo se pueden convocar reuniones programadas'], 422);
        }

        // Verificar anticipación mínima (Art. 17 Ley 21.442)
        $diasAnticipacion = Carbon::parse($reunion->fecha_inicio)->diffInDays(now());
        $minimoRequerido = config('datapolis.asambleas.anticipacion_citacion', 5);

        if ($diasAnticipacion < $minimoRequerido) {
            return response()->json([
                'success' => false,
                'message' => "La convocatoria debe realizarse con al menos {$minimoRequerido} días de anticipación",
            ], 422);
        }

        DB::table('reuniones')->where('id', $id)->update([
            'estado' => 'convocada',
            'fecha_convocatoria' => now(),
            'updated_at' => now(),
        ]);

        // TODO: Enviar notificaciones a copropietarios

        return response()->json(['success' => true, 'message' => 'Reunión convocada']);
    }

    /**
     * Iniciar reunión
     */
    public function iniciar(int $id): JsonResponse
    {
        $reunion = DB::table('reuniones')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$reunion) {
            return response()->json(['success' => false, 'message' => 'Reunión no encontrada'], 404);
        }

        if ($reunion->estado !== 'convocada') {
            return response()->json(['success' => false, 'message' => 'Solo se pueden iniciar reuniones convocadas'], 422);
        }

        // Verificar quórum
        $totalProrrateo = DB::table('unidades')
            ->where('edificio_id', $reunion->edificio_id)
            ->where('activa', true)
            ->sum('prorrateo');

        $prorrateoPresente = DB::table('asistencia_reunion')
            ->join('unidades', 'asistencia_reunion.unidad_id', '=', 'unidades.id')
            ->where('asistencia_reunion.reunion_id', $id)
            ->where('asistencia_reunion.presente', true)
            ->sum('unidades.prorrateo');

        $quorumActual = $totalProrrateo > 0 ? ($prorrateoPresente / $totalProrrateo) * 100 : 0;

        if ($quorumActual < $reunion->quorum_requerido) {
            return response()->json([
                'success' => false,
                'message' => "No hay quórum suficiente. Actual: " . number_format($quorumActual, 2) . "%, Requerido: {$reunion->quorum_requerido}%",
                'quorum_actual' => $quorumActual,
                'quorum_requerido' => $reunion->quorum_requerido,
            ], 422);
        }

        DB::table('reuniones')->where('id', $id)->update([
            'estado' => 'en_curso',
            'hora_inicio_real' => now(),
            'quorum_obtenido' => $quorumActual,
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Reunión iniciada',
            'quorum' => $quorumActual,
        ]);
    }

    /**
     * Finalizar reunión
     */
    public function finalizar(int $id, Request $request): JsonResponse
    {
        $reunion = DB::table('reuniones')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$reunion) {
            return response()->json(['success' => false, 'message' => 'Reunión no encontrada'], 404);
        }

        if ($reunion->estado !== 'en_curso') {
            return response()->json(['success' => false, 'message' => 'Solo se pueden finalizar reuniones en curso'], 422);
        }

        DB::table('reuniones')->where('id', $id)->update([
            'estado' => 'finalizada',
            'hora_fin_real' => now(),
            'observaciones' => $request->observaciones,
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Reunión finalizada']);
    }

    /**
     * Registrar asistencia
     */
    public function registrarAsistencia(int $id, Request $request): JsonResponse
    {
        $request->validate([
            'unidad_id' => 'required|exists:unidades,id',
            'presente' => 'required|boolean',
        ]);

        $reunion = DB::table('reuniones')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$reunion) {
            return response()->json(['success' => false, 'message' => 'Reunión no encontrada'], 404);
        }

        $unidad = DB::table('unidades')->where('id', $request->unidad_id)->first();

        DB::table('asistencia_reunion')->updateOrInsert(
            ['reunion_id' => $id, 'unidad_id' => $request->unidad_id],
            [
                'presente' => $request->presente,
                'representante' => $request->representante,
                'tipo_representacion' => $request->tipo_representacion ?? 'propietario',
                'prorrateo' => $unidad->prorrateo,
                'hora_registro' => now(),
                'updated_at' => now(),
            ]
        );

        return response()->json(['success' => true, 'message' => 'Asistencia registrada']);
    }

    /**
     * Crear votación
     */
    public function crearVotacion(int $id, Request $request): JsonResponse
    {
        $request->validate([
            'materia_id' => 'nullable|exists:materias_reunion,id',
            'titulo' => 'required|string|max:300',
            'tipo_quorum' => 'required|in:simple,absoluta,calificada,unanimidad',
        ]);

        $reunion = DB::table('reuniones')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$reunion || $reunion->estado !== 'en_curso') {
            return response()->json(['success' => false, 'message' => 'La reunión debe estar en curso'], 422);
        }

        $quorumRequerido = match($request->tipo_quorum) {
            'simple' => 50.01,
            'absoluta' => 50.01,
            'calificada' => 66.67,
            'unanimidad' => 100,
        };

        $votacionId = DB::table('votaciones')->insertGetId([
            'reunion_id' => $id,
            'materia_id' => $request->materia_id,
            'titulo' => $request->titulo,
            'descripcion' => $request->descripcion,
            'tipo_quorum' => $request->tipo_quorum,
            'quorum_requerido' => $quorumRequerido,
            'estado' => 'abierta',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Votación creada', 'id' => $votacionId], 201);
    }

    /**
     * Registrar voto
     */
    public function votar(int $votacionId, Request $request): JsonResponse
    {
        $request->validate([
            'unidad_id' => 'required|exists:unidades,id',
            'voto' => 'required|in:favor,contra,abstencion',
        ]);

        $votacion = DB::table('votaciones')
            ->join('reuniones', 'votaciones.reunion_id', '=', 'reuniones.id')
            ->where('votaciones.id', $votacionId)
            ->where('reuniones.tenant_id', Auth::user()->tenant_id)
            ->select('votaciones.*')
            ->first();

        if (!$votacion || $votacion->estado !== 'abierta') {
            return response()->json(['success' => false, 'message' => 'La votación no está abierta'], 422);
        }

        // Verificar que la unidad esté presente
        $asistencia = DB::table('asistencia_reunion')
            ->where('reunion_id', $votacion->reunion_id)
            ->where('unidad_id', $request->unidad_id)
            ->where('presente', true)
            ->first();

        if (!$asistencia) {
            return response()->json(['success' => false, 'message' => 'La unidad no está registrada como presente'], 422);
        }

        // Verificar que no haya votado
        $yaVoto = DB::table('votos')
            ->where('votacion_id', $votacionId)
            ->where('unidad_id', $request->unidad_id)
            ->exists();

        if ($yaVoto) {
            return response()->json(['success' => false, 'message' => 'La unidad ya emitió su voto'], 422);
        }

        $unidad = DB::table('unidades')->where('id', $request->unidad_id)->first();

        DB::table('votos')->insert([
            'votacion_id' => $votacionId,
            'unidad_id' => $request->unidad_id,
            'voto' => $request->voto,
            'prorrateo' => $unidad->prorrateo,
            'created_at' => now(),
        ]);

        // Actualizar totales de votación
        $this->actualizarResultadosVotacion($votacionId);

        return response()->json(['success' => true, 'message' => 'Voto registrado']);
    }

    /**
     * Generar acta
     */
    public function acta(int $id): JsonResponse
    {
        $reunion = DB::table('reuniones')
            ->join('edificios', 'reuniones.edificio_id', '=', 'edificios.id')
            ->where('reuniones.id', $id)
            ->where('reuniones.tenant_id', Auth::user()->tenant_id)
            ->select('reuniones.*', 'edificios.nombre as edificio', 'edificios.direccion', 'edificios.rut as edificio_rut')
            ->first();

        if (!$reunion) {
            return response()->json(['success' => false, 'message' => 'Reunión no encontrada'], 404);
        }

        $reunion->asistencia = DB::table('asistencia_reunion')
            ->join('unidades', 'asistencia_reunion.unidad_id', '=', 'unidades.id')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('asistencia_reunion.reunion_id', $id)
            ->where('asistencia_reunion.presente', true)
            ->select('unidades.numero', 'unidades.prorrateo', 'personas.nombre_completo', 'asistencia_reunion.representante')
            ->get();

        $reunion->materias = DB::table('materias_reunion')
            ->where('reunion_id', $id)
            ->orderBy('orden')
            ->get();

        $reunion->votaciones = DB::table('votaciones')
            ->where('reunion_id', $id)
            ->get();

        foreach ($reunion->votaciones as $votacion) {
            $votacion->votos = DB::table('votos')
                ->join('unidades', 'votos.unidad_id', '=', 'unidades.id')
                ->where('votos.votacion_id', $votacion->id)
                ->select('unidades.numero', 'votos.voto', 'votos.prorrateo')
                ->get();
        }

        return response()->json(['success' => true, 'data' => $reunion]);
    }

    /**
     * Generar PDF del acta
     */
    public function actaPdf(int $id)
    {
        $acta = $this->acta($id)->getData();

        if (!$acta->success) {
            return response()->json(['success' => false, 'message' => 'Reunión no encontrada'], 404);
        }

        $reunion = $acta->data;
        $pdf = Pdf::loadView('pdf.acta-reunion', compact('reunion'));
        
        return $pdf->download("acta-reunion-{$id}.pdf");
    }

    /**
     * Actualizar resultados de votación
     */
    private function actualizarResultadosVotacion(int $votacionId): void
    {
        $votos = DB::table('votos')
            ->where('votacion_id', $votacionId)
            ->get();

        $favor = $votos->where('voto', 'favor')->sum('prorrateo');
        $contra = $votos->where('voto', 'contra')->sum('prorrateo');
        $abstencion = $votos->where('voto', 'abstencion')->sum('prorrateo');
        $total = $favor + $contra + $abstencion;

        $porcentajeFavor = $total > 0 ? ($favor / $total) * 100 : 0;

        $votacion = DB::table('votaciones')->where('id', $votacionId)->first();
        $aprobada = $porcentajeFavor >= $votacion->quorum_requerido;

        DB::table('votaciones')->where('id', $votacionId)->update([
            'votos_favor' => $favor,
            'votos_contra' => $contra,
            'votos_abstencion' => $abstencion,
            'porcentaje_favor' => $porcentajeFavor,
            'resultado' => $aprobada ? 'aprobada' : 'rechazada',
            'updated_at' => now(),
        ]);
    }
}
