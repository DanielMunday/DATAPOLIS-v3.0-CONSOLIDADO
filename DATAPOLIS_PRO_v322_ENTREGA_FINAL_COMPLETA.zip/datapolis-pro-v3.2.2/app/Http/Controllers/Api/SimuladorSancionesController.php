<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\SimuladorSancionesService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use App\Models\Edificio;
use App\Models\SimulacionSancion;
use App\Models\ObligacionTributaria;

/**
 * SimuladorSancionesController
 * 
 * API REST para simulación de sanciones tributarias
 * Art. 97 N°2 Código Tributario chileno
 * 
 * @package DATAPOLIS PRO v3.0
 * @author Daniel - DATAPOLIS
 * @version 1.0.0
 */
class SimuladorSancionesController extends Controller
{
    protected SimuladorSancionesService $simuladorService;

    public function __construct(SimuladorSancionesService $simuladorService)
    {
        $this->simuladorService = $simuladorService;
    }

    /**
     * Simular sanción tributaria
     * 
     * POST /api/v1/sanciones/simular
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function simular(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'edificio_id' => 'required|integer|exists:edificios,id',
            'monto_impuesto' => 'required|numeric|min:1',
            'tipo_infraccion' => 'required|string|in:retardo,omision,incompleta,maliciosa',
            'fecha_vencimiento' => 'required|date|before:today',
            'meses_atraso' => 'nullable|integer|min:1|max:120',
            'escenario' => 'nullable|string|in:regularizacion_voluntaria,fiscalizacion,denuncia_terceros,omision_historica,primera_infraccion',
            'guardar_simulacion' => 'nullable|boolean',
        ], [
            'monto_impuesto.required' => 'Debe especificar el monto del impuesto adeudado',
            'monto_impuesto.min' => 'El monto debe ser mayor a 0',
            'tipo_infraccion.required' => 'Debe especificar el tipo de infracción',
            'tipo_infraccion.in' => 'Tipo de infracción no válido',
            'fecha_vencimiento.required' => 'Debe especificar la fecha de vencimiento original',
            'fecha_vencimiento.before' => 'La fecha de vencimiento debe ser anterior a hoy',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Validación fallida',
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            // Verificar permisos
            $edificio = Edificio::findOrFail($request->edificio_id);
            $this->authorize('simular-sanciones', $edificio);

            // Calcular meses de atraso si no se especifica
            $mesesAtraso = $request->meses_atraso;
            if (!$mesesAtraso) {
                $fechaVencimiento = \Carbon\Carbon::parse($request->fecha_vencimiento);
                $mesesAtraso = $fechaVencimiento->diffInMonths(now());
            }

            // Ejecutar simulación
            $resultado = $this->simuladorService->simularSancion(
                $request->monto_impuesto,
                $request->tipo_infraccion,
                $mesesAtraso,
                $request->escenario
            );

            // Guardar simulación si se solicita
            $simulacionId = null;
            if ($request->guardar_simulacion) {
                $simulacion = SimulacionSancion::create([
                    'edificio_id' => $request->edificio_id,
                    'usuario_id' => Auth::id(),
                    'monto_impuesto_original' => $request->monto_impuesto,
                    'tipo_infraccion' => $request->tipo_infraccion,
                    'fecha_vencimiento' => $request->fecha_vencimiento,
                    'meses_atraso' => $mesesAtraso,
                    'escenario' => $request->escenario,
                    'total_deuda_clp' => $resultado['total']['clp'],
                    'total_deuda_utm' => $resultado['total']['utm'],
                    'resultado_completo' => json_encode($resultado),
                    'created_at' => now(),
                ]);
                $simulacionId = $simulacion->id;
            }

            Log::info('Simulación de sanción completada', [
                'edificio_id' => $request->edificio_id,
                'tipo' => $request->tipo_infraccion,
                'monto' => $request->monto_impuesto,
                'total_deuda' => $resultado['total']['clp'],
            ]);

            return response()->json([
                'success' => true,
                'data' => [
                    'simulacion_id' => $simulacionId,
                    'resultado' => $resultado,
                ],
                'mensaje' => 'Simulación completada',
            ], 200);

        } catch (\Illuminate\Auth\Access\AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'error' => 'No tiene permisos para simular sanciones en este edificio',
            ], 403);
        } catch (\Exception $e) {
            Log::error('Error en simulación de sanción', [
                'edificio_id' => $request->edificio_id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Error al procesar la simulación',
                'detalle' => config('app.debug') ? $e->getMessage() : null,
            ], 500);
        }
    }

    /**
     * Simular sanción rápida (sin guardar)
     * 
     * GET /api/v1/sanciones/simular-rapido
     */
    public function simularRapido(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'monto' => 'required|numeric|min:1',
            'tipo' => 'required|string|in:retardo,omision,incompleta,maliciosa',
            'meses' => 'required|integer|min:1|max:120',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        // Cache por 5 minutos para mismos parámetros
        $cacheKey = "sancion_rapida_{$request->monto}_{$request->tipo}_{$request->meses}";
        
        $resultado = Cache::remember($cacheKey, 300, function () use ($request) {
            return $this->simuladorService->simularSancion(
                $request->monto,
                $request->tipo,
                $request->meses
            );
        });

        return response()->json([
            'success' => true,
            'data' => [
                'resumen' => [
                    'impuesto_original' => $resultado['desglose']['impuesto_original'],
                    'multa' => $resultado['desglose']['multa'],
                    'intereses' => $resultado['desglose']['intereses'],
                    'reajuste' => $resultado['desglose']['reajuste'],
                    'total_clp' => $resultado['total']['clp'],
                    'total_utm' => $resultado['total']['utm'],
                ],
            ],
        ]);
    }

    /**
     * Comparar escenarios de sanción
     * 
     * POST /api/v1/sanciones/comparar-escenarios
     */
    public function compararEscenarios(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'monto_impuesto' => 'required|numeric|min:1',
            'tipo_infraccion' => 'required|string|in:retardo,omision,incompleta,maliciosa',
            'meses_atraso' => 'required|integer|min:1|max:120',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $escenarios = [
                'regularizacion_voluntaria',
                'fiscalizacion',
                'denuncia_terceros',
                'primera_infraccion',
            ];

            $comparacion = [];
            $mejorEscenario = null;
            $menorDeuda = PHP_INT_MAX;

            foreach ($escenarios as $escenario) {
                $resultado = $this->simuladorService->simularSancion(
                    $request->monto_impuesto,
                    $request->tipo_infraccion,
                    $request->meses_atraso,
                    $escenario
                );

                $totalClp = $resultado['total']['clp'];
                
                $comparacion[$escenario] = [
                    'nombre' => $this->getNombreEscenario($escenario),
                    'descripcion' => $this->getDescripcionEscenario($escenario),
                    'total_clp' => $totalClp,
                    'total_utm' => $resultado['total']['utm'],
                    'multa' => $resultado['desglose']['multa'],
                    'porcentaje_multa' => $resultado['analisis_multa']['porcentaje_aplicado'] ?? 0,
                    'reduccion_aplicada' => $resultado['analisis_multa']['reduccion_aplicada'] ?? 0,
                ];

                if ($totalClp < $menorDeuda) {
                    $menorDeuda = $totalClp;
                    $mejorEscenario = $escenario;
                }
            }

            // Calcular ahorro vs peor escenario
            $peorDeuda = max(array_column($comparacion, 'total_clp'));
            
            foreach ($comparacion as $escenario => &$datos) {
                $datos['ahorro_vs_peor'] = $peorDeuda - $datos['total_clp'];
                $datos['porcentaje_ahorro'] = $peorDeuda > 0 
                    ? round((($peorDeuda - $datos['total_clp']) / $peorDeuda) * 100, 1)
                    : 0;
                $datos['es_mejor_opcion'] = ($escenario === $mejorEscenario);
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'parametros' => [
                        'monto_impuesto' => $request->monto_impuesto,
                        'tipo_infraccion' => $request->tipo_infraccion,
                        'meses_atraso' => $request->meses_atraso,
                    ],
                    'comparacion' => $comparacion,
                    'mejor_escenario' => [
                        'codigo' => $mejorEscenario,
                        'nombre' => $this->getNombreEscenario($mejorEscenario),
                        'total_clp' => $menorDeuda,
                        'ahorro_total' => $peorDeuda - $menorDeuda,
                    ],
                    'recomendacion' => $this->generarRecomendacion($mejorEscenario, $menorDeuda, $peorDeuda),
                ],
            ]);

        } catch (\Exception $e) {
            Log::error('Error comparando escenarios', ['error' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'error' => 'Error al comparar escenarios',
            ], 500);
        }
    }

    /**
     * Proyectar deuda futura
     * 
     * POST /api/v1/sanciones/proyectar
     */
    public function proyectar(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'monto_impuesto' => 'required|numeric|min:1',
            'tipo_infraccion' => 'required|string|in:retardo,omision,incompleta,maliciosa',
            'meses_actuales' => 'required|integer|min:0|max:120',
            'meses_proyeccion' => 'nullable|array',
            'meses_proyeccion.*' => 'integer|min:1|max:60',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $mesesProyeccion = $request->meses_proyeccion ?? [3, 6, 12, 24, 36];
            
            // Calcular deuda actual
            $deudaActual = $this->simuladorService->simularSancion(
                $request->monto_impuesto,
                $request->tipo_infraccion,
                $request->meses_actuales
            );

            $proyecciones = [];
            $totalActual = $deudaActual['total']['clp'];

            foreach ($mesesProyeccion as $mesesAdicionales) {
                $mesesTotal = $request->meses_actuales + $mesesAdicionales;
                
                $deudaFutura = $this->simuladorService->simularSancion(
                    $request->monto_impuesto,
                    $request->tipo_infraccion,
                    $mesesTotal
                );

                $totalFuturo = $deudaFutura['total']['clp'];
                
                $proyecciones[] = [
                    'meses_adicionales' => $mesesAdicionales,
                    'meses_totales' => $mesesTotal,
                    'fecha_proyectada' => now()->addMonths($mesesAdicionales)->format('Y-m-d'),
                    'total_clp' => $totalFuturo,
                    'total_utm' => $deudaFutura['total']['utm'],
                    'incremento_clp' => $totalFuturo - $totalActual,
                    'incremento_porcentaje' => $totalActual > 0 
                        ? round((($totalFuturo - $totalActual) / $totalActual) * 100, 1)
                        : 0,
                    'incremento_mensual_promedio' => $mesesAdicionales > 0 
                        ? round(($totalFuturo - $totalActual) / $mesesAdicionales)
                        : 0,
                ];
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'situacion_actual' => [
                        'monto_impuesto' => $request->monto_impuesto,
                        'meses_atraso' => $request->meses_actuales,
                        'total_clp' => $totalActual,
                        'total_utm' => $deudaActual['total']['utm'],
                    ],
                    'proyecciones' => $proyecciones,
                    'alerta' => $this->generarAlertaProyeccion($proyecciones),
                    'grafico_data' => $this->prepararDatosGrafico($totalActual, $proyecciones),
                ],
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al proyectar deuda',
            ], 500);
        }
    }

    /**
     * Simular convenio de pago
     * 
     * POST /api/v1/sanciones/convenio
     */
    public function simularConvenio(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'deuda_total' => 'required|numeric|min:1',
            'cuotas' => 'nullable|array',
            'cuotas.*' => 'integer|in:3,6,12,18,24',
            'capacidad_pago_mensual' => 'nullable|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errores' => $validator->errors(),
            ], 422);
        }

        try {
            $opcionesCuotas = $request->cuotas ?? [3, 6, 12, 18, 24];
            $convenios = [];

            foreach ($opcionesCuotas as $numCuotas) {
                $cuotaMensual = ceil($request->deuda_total / $numCuotas);
                
                $convenios[] = [
                    'cuotas' => $numCuotas,
                    'monto_cuota' => $cuotaMensual,
                    'total_a_pagar' => $cuotaMensual * $numCuotas,
                    'fecha_termino' => now()->addMonths($numCuotas)->format('Y-m-d'),
                    'viable' => $request->capacidad_pago_mensual 
                        ? ($cuotaMensual <= $request->capacidad_pago_mensual)
                        : null,
                ];
            }

            // Determinar mejor opción según capacidad de pago
            $mejorOpcion = null;
            if ($request->capacidad_pago_mensual) {
                foreach ($convenios as $convenio) {
                    if ($convenio['viable'] && 
                        (!$mejorOpcion || $convenio['cuotas'] < $mejorOpcion['cuotas'])) {
                        $mejorOpcion = $convenio;
                    }
                }
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'deuda_total' => $request->deuda_total,
                    'capacidad_pago' => $request->capacidad_pago_mensual,
                    'opciones_convenio' => $convenios,
                    'mejor_opcion' => $mejorOpcion,
                    'requisitos_sii' => [
                        'Solicitud formal en oficina SII o portal web',
                        'RUT y clave tributaria vigente',
                        'No tener convenios anteriores incumplidos',
                        'Pie mínimo del 5% de la deuda',
                        'Cuotas se indexan a UTM mensual',
                    ],
                ],
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al simular convenio',
            ], 500);
        }
    }

    /**
     * Obtener historial de simulaciones
     * 
     * GET /api/v1/sanciones/historial/{edificioId}
     */
    public function historial(int $edificioId): JsonResponse
    {
        try {
            $edificio = Edificio::findOrFail($edificioId);
            $this->authorize('ver-sanciones', $edificio);

            $simulaciones = SimulacionSancion::where('edificio_id', $edificioId)
                ->orderBy('created_at', 'desc')
                ->limit(50)
                ->get()
                ->map(function ($item) {
                    return [
                        'id' => $item->id,
                        'fecha' => $item->created_at->format('Y-m-d H:i'),
                        'tipo_infraccion' => $item->tipo_infraccion,
                        'monto_original' => $item->monto_impuesto_original,
                        'meses_atraso' => $item->meses_atraso,
                        'total_deuda_clp' => $item->total_deuda_clp,
                        'total_deuda_utm' => $item->total_deuda_utm,
                        'escenario' => $item->escenario,
                        'usuario' => $item->usuario->nombre ?? 'Sistema',
                    ];
                });

            return response()->json([
                'success' => true,
                'data' => $simulaciones,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error al obtener historial',
            ], 500);
        }
    }

    /**
     * Obtener valores UTM y UF actuales
     * 
     * GET /api/v1/sanciones/valores-tributarios
     */
    public function valoresTributarios(): JsonResponse
    {
        // Idealmente esto vendría de una API del SII o BC
        $valores = Cache::remember('valores_tributarios', 3600, function () {
            return [
                'utm' => [
                    'valor' => 67000,
                    'fecha' => now()->format('Y-m'),
                    'fuente' => 'SII',
                ],
                'uf' => [
                    'valor' => 38500,
                    'fecha' => now()->format('Y-m-d'),
                    'fuente' => 'Banco Central',
                ],
                'ipc_anual' => [
                    'valor' => 4.0,
                    'periodo' => 'últimos 12 meses',
                ],
                'interes_moratorio' => [
                    'valor' => 1.5,
                    'tipo' => 'mensual',
                    'base_legal' => 'Art. 53 Código Tributario',
                ],
            ];
        });

        return response()->json([
            'success' => true,
            'data' => $valores,
        ]);
    }

    // === Métodos auxiliares ===

    private function getNombreEscenario(string $escenario): string
    {
        return match ($escenario) {
            'regularizacion_voluntaria' => 'Regularización Voluntaria',
            'fiscalizacion' => 'Fiscalización SII',
            'denuncia_terceros' => 'Denuncia de Terceros',
            'omision_historica' => 'Omisión Histórica (+3 años)',
            'primera_infraccion' => 'Primera Infracción',
            default => ucfirst(str_replace('_', ' ', $escenario)),
        };
    }

    private function getDescripcionEscenario(string $escenario): string
    {
        return match ($escenario) {
            'regularizacion_voluntaria' => 'El contribuyente se regulariza antes de cualquier acción del SII',
            'fiscalizacion' => 'La infracción es detectada durante una fiscalización del SII',
            'denuncia_terceros' => 'La infracción es denunciada por un tercero ante el SII',
            'primera_infraccion' => 'Es la primera vez que el contribuyente comete esta infracción',
            default => '',
        };
    }

    private function generarRecomendacion(string $mejorEscenario, int $menorDeuda, int $peorDeuda): array
    {
        $ahorro = $peorDeuda - $menorDeuda;
        
        return [
            'accion' => 'REGULARIZACIÓN INMEDIATA',
            'motivo' => "Puede ahorrar hasta $" . number_format($ahorro, 0, ',', '.') . " CLP",
            'pasos' => [
                'Recopilar documentación de respaldo',
                'Preparar declaraciones rectificatorias',
                'Presentar ante SII como regularización voluntaria',
                'Solicitar condonación parcial si aplica',
            ],
            'urgencia' => $ahorro > 1000000 ? 'ALTA' : ($ahorro > 500000 ? 'MEDIA' : 'NORMAL'),
        ];
    }

    private function generarAlertaProyeccion(array $proyecciones): array
    {
        $ultimaProyeccion = end($proyecciones);
        $incrementoTotal = $ultimaProyeccion['incremento_porcentaje'] ?? 0;

        if ($incrementoTotal > 100) {
            return [
                'nivel' => 'CRÍTICO',
                'mensaje' => 'La deuda se duplicará. Regularice urgentemente.',
                'color' => 'red',
            ];
        } elseif ($incrementoTotal > 50) {
            return [
                'nivel' => 'ALTO',
                'mensaje' => 'Incremento significativo proyectado. Actúe pronto.',
                'color' => 'orange',
            ];
        } else {
            return [
                'nivel' => 'MODERADO',
                'mensaje' => 'Crecimiento controlado pero evitable.',
                'color' => 'yellow',
            ];
        }
    }

    private function prepararDatosGrafico(int $deudaActual, array $proyecciones): array
    {
        $data = [
            [
                'mes' => 0,
                'label' => 'Hoy',
                'valor' => $deudaActual,
            ],
        ];

        foreach ($proyecciones as $p) {
            $data[] = [
                'mes' => $p['meses_adicionales'],
                'label' => "+{$p['meses_adicionales']} meses",
                'valor' => $p['total_clp'],
            ];
        }

        return $data;
    }
}
