<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\GestionBancariaTributariaService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;

/**
 * DATAPOLIS PRO v3.1 - Controlador Sistema Bancario y Tributario
 * 
 * Gestiona:
 * - Cuentas Bancarias de la Comunidad (Art. 40 Ley 21.442, Art. 23 DS 7-2025)
 * - Traspasos entre Cuentas (Art. 17 N°3 LIR - Ley 21.713)
 * - Conciliación Bancaria
 * - Planillas de Distribución para SII
 * - Certificados Tributarios por Copropietario
 */
class SistemaBancarioTributarioController extends Controller
{
    protected GestionBancariaTributariaService $service;

    public function __construct(GestionBancariaTributariaService $service)
    {
        $this->service = $service;
    }

    // =========================================================================
    // CUENTAS BANCARIAS
    // =========================================================================

    /**
     * Listar cuentas bancarias de un edificio
     * 
     * GET /api/bancos/cuentas
     */
    public function listarCuentas(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id'
        ]);

        $cuentas = $this->service->obtenerCuentasBancarias($request->edificio_id);

        return response()->json([
            'success' => true,
            'data' => $cuentas,
            'nota_legal' => 'Según Art. 40 Ley 21.442, la comunidad debe tener cuenta corriente exclusiva para gastos comunes. Según Art. 23 DS 7-2025, debe tener cuenta separada para arriendos.'
        ]);
    }

    /**
     * Crear cuenta bancaria
     * 
     * POST /api/bancos/cuentas
     */
    public function crearCuenta(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'banco_codigo' => 'required|string|max:10',
            'banco_nombre' => 'required|string|max:100',
            'tipo_cuenta' => 'required|in:corriente,vista,ahorro,rut',
            'numero_cuenta' => 'required|string|max:30',
            'rut_titular' => 'required|string|max:12',
            'nombre_titular' => 'required|string|max:200',
            'proposito' => 'required|in:gastos_comunes,arriendos,fondo_reserva,operacional,inversiones,remuneraciones',
            'saldo_inicial' => 'nullable|numeric|min:0',
            'firmantes' => 'nullable|array',
        ]);

        $resultado = $this->service->crearCuentaBancaria($request->all());

        return response()->json($resultado, $resultado['success'] ? 201 : 422);
    }

    /**
     * Obtener detalle de cuenta bancaria
     * 
     * GET /api/bancos/cuentas/{id}
     */
    public function mostrarCuenta(int $id): JsonResponse
    {
        $cuenta = DB::table('cuentas_bancarias_comunidad')
            ->where('id', $id)
            ->whereNull('deleted_at')
            ->first();

        if (!$cuenta) {
            return response()->json(['success' => false, 'message' => 'Cuenta no encontrada'], 404);
        }

        // Obtener últimos movimientos
        $cuenta->ultimos_movimientos = DB::table('movimientos_bancarios')
            ->where('cuenta_bancaria_id', $id)
            ->orderByDesc('fecha')
            ->orderByDesc('id')
            ->limit(20)
            ->get();

        // Obtener estadísticas
        $cuenta->estadisticas = [
            'movimientos_mes' => DB::table('movimientos_bancarios')
                ->where('cuenta_bancaria_id', $id)
                ->whereMonth('fecha', now()->month)
                ->whereYear('fecha', now()->year)
                ->count(),
            'total_cargos_mes' => DB::table('movimientos_bancarios')
                ->where('cuenta_bancaria_id', $id)
                ->whereMonth('fecha', now()->month)
                ->whereYear('fecha', now()->year)
                ->sum('cargo'),
            'total_abonos_mes' => DB::table('movimientos_bancarios')
                ->where('cuenta_bancaria_id', $id)
                ->whereMonth('fecha', now()->month)
                ->whereYear('fecha', now()->year)
                ->sum('abono'),
        ];

        return response()->json(['success' => true, 'data' => $cuenta]);
    }

    /**
     * Actualizar cuenta bancaria
     * 
     * PUT /api/bancos/cuentas/{id}
     */
    public function actualizarCuenta(Request $request, int $id): JsonResponse
    {
        $cuenta = DB::table('cuentas_bancarias_comunidad')
            ->where('id', $id)
            ->first();

        if (!$cuenta) {
            return response()->json(['success' => false, 'message' => 'Cuenta no encontrada'], 404);
        }

        DB::table('cuentas_bancarias_comunidad')
            ->where('id', $id)
            ->update(array_merge(
                array_filter($request->only([
                    'banco_codigo', 'banco_nombre', 'numero_cuenta',
                    'firmantes', 'saldo_minimo_alerta', 'enviar_alertas', 'activa'
                ]), fn($v) => $v !== null),
                ['updated_at' => now()]
            ));

        return response()->json(['success' => true, 'message' => 'Cuenta actualizada']);
    }

    // =========================================================================
    // MOVIMIENTOS BANCARIOS
    // =========================================================================

    /**
     * Listar movimientos de una cuenta
     * 
     * GET /api/bancos/movimientos
     */
    public function listarMovimientos(Request $request): JsonResponse
    {
        $request->validate([
            'cuenta_id' => 'required|exists:cuentas_bancarias_comunidad,id',
            'fecha_desde' => 'nullable|date',
            'fecha_hasta' => 'nullable|date',
        ]);

        $movimientos = DB::table('movimientos_bancarios')
            ->where('cuenta_bancaria_id', $request->cuenta_id)
            ->when($request->fecha_desde, fn($q) => $q->where('fecha', '>=', $request->fecha_desde))
            ->when($request->fecha_hasta, fn($q) => $q->where('fecha', '<=', $request->fecha_hasta))
            ->when($request->tipo, fn($q) => $q->where('tipo', $request->tipo))
            ->when($request->conciliado !== null, fn($q) => $q->where('conciliado', $request->boolean('conciliado')))
            ->orderByDesc('fecha')
            ->orderByDesc('id')
            ->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $movimientos]);
    }

    /**
     * Registrar movimiento bancario manual
     * 
     * POST /api/bancos/movimientos
     */
    public function registrarMovimiento(Request $request): JsonResponse
    {
        $request->validate([
            'cuenta_bancaria_id' => 'required|exists:cuentas_bancarias_comunidad,id',
            'fecha' => 'required|date',
            'tipo' => 'required|string',
            'descripcion' => 'required|string|max:500',
            'cargo' => 'nullable|numeric|min:0',
            'abono' => 'nullable|numeric|min:0',
        ]);

        // Validar que tenga cargo o abono
        if (empty($request->cargo) && empty($request->abono)) {
            return response()->json([
                'success' => false,
                'message' => 'Debe especificar cargo o abono'
            ], 422);
        }

        $id = DB::table('movimientos_bancarios')->insertGetId([
            'cuenta_bancaria_id' => $request->cuenta_bancaria_id,
            'fecha' => $request->fecha,
            'tipo' => $request->tipo,
            'numero_documento' => $request->numero_documento,
            'descripcion' => $request->descripcion,
            'cargo' => $request->cargo ?? 0,
            'abono' => $request->abono ?? 0,
            'rut_tercero' => $request->rut_tercero,
            'nombre_tercero' => $request->nombre_tercero,
            'estado' => 'procesado',
            'created_at' => now(),
        ]);

        // Actualizar saldo de la cuenta
        $movimiento = $request->cargo > 0 ? -$request->cargo : $request->abono;
        DB::table('cuentas_bancarias_comunidad')
            ->where('id', $request->cuenta_bancaria_id)
            ->increment('saldo_contable', $movimiento);

        return response()->json([
            'success' => true,
            'message' => 'Movimiento registrado',
            'id' => $id
        ], 201);
    }

    // =========================================================================
    // TRASPASOS ENTRE CUENTAS (Art. 17 N°3 LIR)
    // =========================================================================

    /**
     * Listar traspasos
     * 
     * GET /api/bancos/traspasos
     */
    public function listarTraspasos(Request $request): JsonResponse
    {
        $traspasos = DB::table('traspasos_cuentas')
            ->join('cuentas_bancarias_comunidad as origen', 'traspasos_cuentas.cuenta_origen_id', '=', 'origen.id')
            ->leftJoin('cuentas_bancarias_comunidad as destino', 'traspasos_cuentas.cuenta_destino_id', '=', 'destino.id')
            ->where('traspasos_cuentas.tenant_id', Auth::user()->tenant_id)
            ->when($request->edificio_id, fn($q) => $q->where('traspasos_cuentas.edificio_id', $request->edificio_id))
            ->when($request->tipo, fn($q) => $q->where('traspasos_cuentas.tipo', $request->tipo))
            ->when($request->estado, fn($q) => $q->where('traspasos_cuentas.estado', $request->estado))
            ->when($request->periodo, fn($q) => $q->where('traspasos_cuentas.periodo', $request->periodo))
            ->select(
                'traspasos_cuentas.*',
                'origen.banco_nombre as banco_origen',
                'origen.numero_cuenta as cuenta_origen',
                'origen.proposito as proposito_origen',
                'destino.banco_nombre as banco_destino',
                'destino.numero_cuenta as cuenta_destino',
                'destino.proposito as proposito_destino'
            )
            ->orderByDesc('traspasos_cuentas.fecha')
            ->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $traspasos]);
    }

    /**
     * Crear traspaso de arriendos a GC (Art. 17 N°3 - NO constituye renta)
     * 
     * POST /api/bancos/traspasos/arriendos-gc
     */
    public function crearTraspasoArriendosGC(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'monto' => 'required|numeric|min:1',
            'fecha' => 'nullable|date',
            'concepto' => 'nullable|string|max:500',
            'periodo' => 'nullable|string|max:7',
            'unidad_id' => 'nullable|exists:unidades,id',
            'persona_id' => 'nullable|exists:personas,id',
        ]);

        $resultado = $this->service->crearTraspasoArriendosAGC($request->all());

        return response()->json($resultado, $resultado['success'] ? 201 : 422);
    }

    /**
     * Crear traspaso de remanente a copropietario (SÍ constituye renta)
     * 
     * POST /api/bancos/traspasos/remanente-copropietario
     */
    public function crearTraspasoRemanente(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'monto' => 'required|numeric|min:1',
            'periodo' => 'required|string|max:7',
            'unidad_id' => 'required|exists:unidades,id',
            'persona_id' => 'required|exists:personas,id',
            'rut_beneficiario' => 'required|string|max:12',
            'nombre_beneficiario' => 'required|string|max:200',
            'banco_beneficiario' => 'nullable|string|max:100',
            'cuenta_beneficiario' => 'nullable|string|max:30',
        ]);

        $resultado = $this->service->crearTraspasoRemanenteCopropietario($request->all());

        return response()->json($resultado, $resultado['success'] ? 201 : 422);
    }

    /**
     * Aprobar traspaso
     * 
     * POST /api/bancos/traspasos/{id}/aprobar
     */
    public function aprobarTraspaso(int $id): JsonResponse
    {
        $traspaso = DB::table('traspasos_cuentas')
            ->where('id', $id)
            ->first();

        if (!$traspaso) {
            return response()->json(['success' => false, 'message' => 'Traspaso no encontrado'], 404);
        }

        if ($traspaso->estado !== 'pendiente') {
            return response()->json(['success' => false, 'message' => 'Solo se pueden aprobar traspasos pendientes'], 422);
        }

        DB::table('traspasos_cuentas')
            ->where('id', $id)
            ->update([
                'estado' => 'aprobado',
                'aprobado_por' => Auth::id(),
                'aprobado_at' => now(),
                'updated_at' => now(),
            ]);

        return response()->json(['success' => true, 'message' => 'Traspaso aprobado']);
    }

    /**
     * Ejecutar traspaso aprobado
     * 
     * POST /api/bancos/traspasos/{id}/ejecutar
     */
    public function ejecutarTraspaso(int $id): JsonResponse
    {
        $resultado = $this->service->ejecutarTraspaso($id);

        return response()->json($resultado, $resultado['success'] ? 200 : 422);
    }

    /**
     * Rechazar traspaso
     * 
     * POST /api/bancos/traspasos/{id}/rechazar
     */
    public function rechazarTraspaso(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'motivo' => 'required|string|max:500'
        ]);

        DB::table('traspasos_cuentas')
            ->where('id', $id)
            ->update([
                'estado' => 'rechazado',
                'motivo_rechazo' => $request->motivo,
                'updated_at' => now(),
            ]);

        return response()->json(['success' => true, 'message' => 'Traspaso rechazado']);
    }

    // =========================================================================
    // DISTRIBUCIÓN MENSUAL (Art. 17 N°3)
    // =========================================================================

    /**
     * Procesar distribución mensual aplicando Art. 17 N°3
     * 
     * POST /api/tributario/distribucion-mensual
     */
    public function procesarDistribucionMensual(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
        ]);

        $resultado = $this->service->procesarDistribucionMensual(
            $request->edificio_id,
            $request->mes,
            $request->anio
        );

        return response()->json($resultado, $resultado['success'] ? 200 : 422);
    }

    /**
     * Obtener planilla de distribución del período
     * 
     * GET /api/tributario/planilla-distribucion
     */
    public function obtenerPlanillaDistribucion(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
        ]);

        $planilla = DB::table('planilla_distribucion_arriendos')
            ->where('edificio_id', $request->edificio_id)
            ->where('mes', $request->mes)
            ->where('anio', $request->anio)
            ->orderBy('numero_unidad')
            ->get();

        $totales = [
            'total_ingreso_bruto' => $planilla->sum('ingreso_bruto_arriendos'),
            'total_traspaso_gc' => $planilla->sum('traspaso_a_gc'),
            'total_art_17_n3' => $planilla->sum('monto_art_17_n3'),
            'total_remanente' => $planilla->sum('remanente_gravable'),
            'total_ppm' => $planilla->sum('ppm_retenido'),
            'total_neto' => $planilla->sum('neto_a_pagar'),
        ];

        return response()->json([
            'success' => true,
            'data' => [
                'periodo' => sprintf('%04d-%02d', $request->anio, $request->mes),
                'detalle' => $planilla,
                'totales' => $totales,
                'nota_legal' => 'Según Art. 17 N°3 LIR (Ley 21.713): Los montos traspasados a GC NO constituyen renta. Los remanentes SÍ constituyen renta.'
            ]
        ]);
    }

    // =========================================================================
    // RESUMEN ANUAL Y CERTIFICADOS
    // =========================================================================

    /**
     * Generar resumen anual por copropietario
     * 
     * POST /api/tributario/resumen-anual
     */
    public function generarResumenAnual(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'anio' => 'required|integer|min:2020',
        ]);

        $resultado = $this->service->generarResumenAnualCopropietario(
            $request->edificio_id,
            $request->anio
        );

        return response()->json($resultado, $resultado['success'] ? 200 : 422);
    }

    /**
     * Obtener planilla completa formato SII
     * 
     * GET /api/tributario/planilla-sii
     */
    public function obtenerPlanillaSII(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'anio' => 'required|integer|min:2020',
        ]);

        $planilla = $this->service->obtenerPlanillaCompletaSII(
            $request->edificio_id,
            $request->anio
        );

        return response()->json(['success' => true, 'data' => $planilla]);
    }

    /**
     * Descargar planilla SII en PDF
     * 
     * GET /api/tributario/planilla-sii/pdf
     */
    public function descargarPlanillaSIIPdf(Request $request)
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'anio' => 'required|integer|min:2020',
        ]);

        $planilla = $this->service->obtenerPlanillaCompletaSII(
            $request->edificio_id,
            $request->anio
        );

        $pdf = Pdf::loadView('pdf.planilla-distribucion-sii', ['planilla' => $planilla]);
        
        $filename = "planilla-distribucion-{$planilla['edificio']['rut']}-{$request->anio}.pdf";
        
        return $pdf->download($filename);
    }

    /**
     * Obtener certificado de un copropietario
     * 
     * GET /api/tributario/certificado/{unidadId}
     */
    public function obtenerCertificadoCopropietario(int $unidadId, Request $request): JsonResponse
    {
        $request->validate([
            'anio' => 'required|integer|min:2020',
        ]);

        $certificado = DB::table('resumen_anual_copropietario')
            ->join('edificios', 'resumen_anual_copropietario.edificio_id', '=', 'edificios.id')
            ->where('resumen_anual_copropietario.unidad_id', $unidadId)
            ->where('resumen_anual_copropietario.anio', $request->anio)
            ->select(
                'resumen_anual_copropietario.*',
                'edificios.nombre as edificio_nombre',
                'edificios.rut as edificio_rut',
                'edificios.direccion as edificio_direccion'
            )
            ->first();

        if (!$certificado) {
            return response()->json([
                'success' => false,
                'message' => 'Certificado no encontrado. Debe generarse primero el resumen anual.'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $certificado,
            'nota_legal' => [
                'base_legal' => 'Art. 17 N°3 LIR modificado por Ley 21.713',
                'no_renta' => 'El monto indicado como Art. 17 N°3 NO constituye renta y no debe declararse.',
                'renta' => 'El remanente gravable SÍ constituye renta y debe declararse en F22.',
            ]
        ]);
    }

    /**
     * Descargar certificado en PDF
     * 
     * GET /api/tributario/certificado/{unidadId}/pdf
     */
    public function descargarCertificadoPdf(int $unidadId, Request $request)
    {
        $request->validate([
            'anio' => 'required|integer|min:2020',
        ]);

        $certificado = DB::table('resumen_anual_copropietario')
            ->join('edificios', 'resumen_anual_copropietario.edificio_id', '=', 'edificios.id')
            ->where('resumen_anual_copropietario.unidad_id', $unidadId)
            ->where('resumen_anual_copropietario.anio', $request->anio)
            ->select(
                'resumen_anual_copropietario.*',
                'edificios.nombre as edificio_nombre',
                'edificios.rut as edificio_rut',
                'edificios.direccion as edificio_direccion'
            )
            ->first();

        if (!$certificado) {
            return response()->json(['success' => false, 'message' => 'Certificado no encontrado'], 404);
        }

        $pdf = Pdf::loadView('pdf.certificado-arriendos-copropietario', [
            'certificado' => $certificado,
            'detalle_mensual' => json_decode($certificado->detalle_mensual, true),
        ]);

        $filename = "certificado-arriendos-{$certificado->rut_copropietario}-{$request->anio}.pdf";

        return $pdf->download($filename);
    }

    // =========================================================================
    // CONCILIACIÓN BANCARIA
    // =========================================================================

    /**
     * Iniciar conciliación bancaria
     * 
     * POST /api/bancos/conciliacion/iniciar
     */
    public function iniciarConciliacion(Request $request): JsonResponse
    {
        $request->validate([
            'cuenta_id' => 'required|exists:cuentas_bancarias_comunidad,id',
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
        ]);

        $resultado = $this->service->iniciarConciliacion(
            $request->cuenta_id,
            $request->mes,
            $request->anio
        );

        return response()->json($resultado, $resultado['success'] ? 200 : 422);
    }

    /**
     * Obtener estado de conciliación
     * 
     * GET /api/bancos/conciliacion
     */
    public function obtenerConciliacion(Request $request): JsonResponse
    {
        $request->validate([
            'cuenta_id' => 'required|exists:cuentas_bancarias_comunidad,id',
            'mes' => 'required|integer|between:1,12',
            'anio' => 'required|integer|min:2020',
        ]);

        $conciliacion = DB::table('conciliaciones_bancarias')
            ->where('cuenta_bancaria_id', $request->cuenta_id)
            ->where('mes', $request->mes)
            ->where('anio', $request->anio)
            ->first();

        if (!$conciliacion) {
            return response()->json([
                'success' => false,
                'message' => 'No existe conciliación para este período'
            ], 404);
        }

        // Obtener movimientos pendientes de conciliar
        $movimientosPendientes = DB::table('movimientos_bancarios')
            ->where('cuenta_bancaria_id', $request->cuenta_id)
            ->where('conciliado', false)
            ->whereBetween('fecha', [$conciliacion->fecha_inicio, $conciliacion->fecha_cierre])
            ->get();

        $conciliacion->movimientos_pendientes = $movimientosPendientes;

        return response()->json(['success' => true, 'data' => $conciliacion]);
    }

    /**
     * Conciliar movimiento
     * 
     * POST /api/bancos/conciliacion/conciliar-movimiento
     */
    public function conciliarMovimiento(Request $request): JsonResponse
    {
        $request->validate([
            'movimiento_id' => 'required|exists:movimientos_bancarios,id',
        ]);

        DB::table('movimientos_bancarios')
            ->where('id', $request->movimiento_id)
            ->update([
                'conciliado' => true,
                'fecha_conciliacion' => now()->toDateString(),
                'conciliado_por' => Auth::id(),
            ]);

        return response()->json(['success' => true, 'message' => 'Movimiento conciliado']);
    }

    /**
     * Actualizar saldo banco en conciliación
     * 
     * PUT /api/bancos/conciliacion/saldo-banco
     */
    public function actualizarSaldoBanco(Request $request): JsonResponse
    {
        $request->validate([
            'conciliacion_id' => 'required|exists:conciliaciones_bancarias,id',
            'saldo_final_banco' => 'required|numeric',
        ]);

        $conciliacion = DB::table('conciliaciones_bancarias')
            ->where('id', $request->conciliacion_id)
            ->first();

        $diferencia = $conciliacion->saldo_final_libro - $request->saldo_final_banco;

        DB::table('conciliaciones_bancarias')
            ->where('id', $request->conciliacion_id)
            ->update([
                'saldo_final_banco' => $request->saldo_final_banco,
                'diferencia' => $diferencia,
                'conciliada' => abs($diferencia) < 0.01,
                'estado' => abs($diferencia) < 0.01 ? 'conciliada' : 'con_diferencia',
                'updated_at' => now(),
            ]);

        return response()->json([
            'success' => true,
            'message' => abs($diferencia) < 0.01 ? 'Conciliación cuadra' : 'Hay diferencia',
            'diferencia' => $diferencia,
            'conciliada' => abs($diferencia) < 0.01,
        ]);
    }

    // =========================================================================
    // PPM Y RETENCIONES
    // =========================================================================

    /**
     * Listar PPM y retenciones del período
     * 
     * GET /api/tributario/ppm
     */
    public function listarPPM(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'anio' => 'required|integer|min:2020',
        ]);

        $ppm = DB::table('ppm_retenciones')
            ->where('edificio_id', $request->edificio_id)
            ->where('anio', $request->anio)
            ->when($request->mes, fn($q) => $q->where('mes', $request->mes))
            ->when($request->tipo, fn($q) => $q->where('tipo', $request->tipo))
            ->orderBy('mes')
            ->get();

        $totales = [
            'total_base_imponible' => $ppm->sum('base_imponible'),
            'total_retencion' => $ppm->sum('monto_retencion'),
        ];

        return response()->json([
            'success' => true,
            'data' => [
                'detalle' => $ppm,
                'totales' => $totales,
            ]
        ]);
    }

    /**
     * Resumen tributario del edificio
     * 
     * GET /api/tributario/resumen
     */
    public function resumenTributario(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'anio' => 'required|integer|min:2020',
        ]);

        $edificioId = $request->edificio_id;
        $anio = $request->anio;

        // Ingresos por arriendos
        $ingresosArriendos = DB::table('facturas_arriendo')
            ->join('contratos_arriendo', 'facturas_arriendo.contrato_id', '=', 'contratos_arriendo.id')
            ->where('contratos_arriendo.edificio_id', $edificioId)
            ->where('facturas_arriendo.periodo_anio', $anio)
            ->where('facturas_arriendo.estado', 'pagada')
            ->sum('facturas_arriendo.monto_total');

        // Distribución Art. 17 N°3
        $distribucion = DB::table('resumen_anual_copropietario')
            ->where('edificio_id', $edificioId)
            ->where('anio', $anio)
            ->selectRaw('
                SUM(total_ingreso_bruto_arriendos) as total_ingreso_bruto,
                SUM(total_monto_art_17_n3) as total_no_renta,
                SUM(total_remanente_gravable) as total_renta,
                SUM(total_ppm_retenido) as total_ppm
            ')
            ->first();

        // PPM total
        $ppmTotal = DB::table('ppm_retenciones')
            ->where('edificio_id', $edificioId)
            ->where('anio', $anio)
            ->sum('monto_retencion');

        return response()->json([
            'success' => true,
            'data' => [
                'anio' => $anio,
                'ingresos' => [
                    'arriendos' => $ingresosArriendos,
                ],
                'distribucion_art_17_n3' => [
                    'total_distribuido' => $distribucion->total_ingreso_bruto ?? 0,
                    'monto_no_renta' => $distribucion->total_no_renta ?? 0,
                    'monto_renta' => $distribucion->total_renta ?? 0,
                    'base_legal' => 'Art. 17 N°3 LIR - Ley 21.713',
                ],
                'retenciones' => [
                    'ppm' => $ppmTotal,
                ],
            ]
        ]);
    }
}
