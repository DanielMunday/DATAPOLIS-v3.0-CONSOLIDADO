<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

/**
 * DATAPOLIS PRO v3.0 - Unidad Controller
 */
class UnidadController extends Controller
{
    /**
     * Listar unidades
     */
    public function index(Request $request): JsonResponse
    {
        $query = DB::table('unidades')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->leftJoin('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->where('unidades.tenant_id', Auth::user()->tenant_id)
            ->whereNull('unidades.deleted_at')
            ->select(
                'unidades.*',
                'personas.nombre_completo as propietario_nombre',
                'personas.rut as propietario_rut',
                'personas.email as propietario_email',
                'edificios.nombre as edificio_nombre'
            );

        if ($request->edificio_id) {
            $query->where('unidades.edificio_id', $request->edificio_id);
        }

        if ($request->tipo) {
            $query->where('unidades.tipo', $request->tipo);
        }

        if ($request->search) {
            $query->where(function ($q) use ($request) {
                $q->where('unidades.numero', 'like', "%{$request->search}%")
                  ->orWhere('personas.nombre_completo', 'like', "%{$request->search}%")
                  ->orWhere('personas.rut', 'like', "%{$request->search}%");
            });
        }

        $unidades = $query
            ->orderBy('edificios.nombre')
            ->orderByRaw("CAST(REGEXP_REPLACE(unidades.numero, '[^0-9]', '') AS UNSIGNED)")
            ->paginate($request->get('per_page', 50));

        return response()->json(['success' => true, 'data' => $unidades]);
    }

    /**
     * Crear unidad
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'edificio_id' => 'required|exists:edificios,id',
            'numero' => 'required|string|max:20',
            'tipo' => 'required|in:departamento,casa,local,oficina,bodega,estacionamiento',
            'prorrateo' => 'required|numeric|min:0|max:100',
            'superficie_util' => 'nullable|numeric|min:0',
        ]);

        // Verificar que no exista unidad con mismo número en el edificio
        $existe = DB::table('unidades')
            ->where('edificio_id', $request->edificio_id)
            ->where('numero', $request->numero)
            ->whereNull('deleted_at')
            ->exists();

        if ($existe) {
            return response()->json([
                'success' => false,
                'message' => 'Ya existe una unidad con ese número en el edificio',
            ], 422);
        }

        $id = DB::table('unidades')->insertGetId([
            'tenant_id' => Auth::user()->tenant_id,
            'edificio_id' => $request->edificio_id,
            'numero' => $request->numero,
            'tipo' => $request->tipo,
            'piso' => $request->piso,
            'superficie_util' => $request->superficie_util,
            'superficie_terraza' => $request->superficie_terraza,
            'prorrateo' => $request->prorrateo,
            'rol_avaluo' => $request->rol_avaluo,
            'propietario_id' => $request->propietario_id,
            'activa' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Unidad creada exitosamente',
            'id' => $id,
        ], 201);
    }

    /**
     * Mostrar unidad
     */
    public function show(int $id): JsonResponse
    {
        $unidad = DB::table('unidades')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->leftJoin('edificios', 'unidades.edificio_id', '=', 'edificios.id')
            ->where('unidades.id', $id)
            ->where('unidades.tenant_id', Auth::user()->tenant_id)
            ->select(
                'unidades.*',
                'personas.nombre_completo as propietario_nombre',
                'personas.rut as propietario_rut',
                'personas.email as propietario_email',
                'personas.telefono as propietario_telefono',
                'edificios.nombre as edificio_nombre',
                'edificios.direccion as edificio_direccion'
            )
            ->first();

        if (!$unidad) {
            return response()->json(['success' => false, 'message' => 'Unidad no encontrada'], 404);
        }

        return response()->json(['success' => true, 'data' => $unidad]);
    }

    /**
     * Actualizar unidad
     */
    public function update(Request $request, int $id): JsonResponse
    {
        $unidad = DB::table('unidades')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$unidad) {
            return response()->json(['success' => false, 'message' => 'Unidad no encontrada'], 404);
        }

        $request->validate([
            'numero' => 'sometimes|string|max:20',
            'tipo' => 'sometimes|in:departamento,casa,local,oficina,bodega,estacionamiento',
            'prorrateo' => 'sometimes|numeric|min:0|max:100',
        ]);

        DB::table('unidades')->where('id', $id)->update(array_merge(
            array_filter($request->only([
                'numero', 'tipo', 'piso', 'superficie_util', 'superficie_terraza',
                'prorrateo', 'rol_avaluo', 'propietario_id', 'activa',
            ]), fn($v) => $v !== null),
            ['updated_at' => now()]
        ));

        return response()->json(['success' => true, 'message' => 'Unidad actualizada']);
    }

    /**
     * Eliminar unidad
     */
    public function destroy(int $id): JsonResponse
    {
        $unidad = DB::table('unidades')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$unidad) {
            return response()->json(['success' => false, 'message' => 'Unidad no encontrada'], 404);
        }

        // Verificar que no tenga boletas pendientes
        $boletasPendientes = DB::table('boletas_gc')
            ->where('unidad_id', $id)
            ->whereIn('estado', ['pendiente', 'vencida'])
            ->count();

        if ($boletasPendientes > 0) {
            return response()->json([
                'success' => false,
                'message' => "No se puede eliminar: tiene {$boletasPendientes} boletas pendientes",
            ], 422);
        }

        DB::table('unidades')->where('id', $id)->update([
            'deleted_at' => now(),
            'activa' => false,
        ]);

        return response()->json(['success' => true, 'message' => 'Unidad eliminada']);
    }

    /**
     * Estado de cuenta de la unidad
     */
    public function estadoCuenta(int $id): JsonResponse
    {
        $unidad = DB::table('unidades')
            ->where('id', $id)
            ->where('tenant_id', Auth::user()->tenant_id)
            ->first();

        if (!$unidad) {
            return response()->json(['success' => false, 'message' => 'Unidad no encontrada'], 404);
        }

        $boletas = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $id)
            ->select(
                'boletas_gc.*',
                'periodos_gc.mes',
                'periodos_gc.anio',
                DB::raw('boletas_gc.total_a_pagar - COALESCE(boletas_gc.total_abonos, 0) as saldo')
            )
            ->orderByDesc('periodos_gc.anio')
            ->orderByDesc('periodos_gc.mes')
            ->limit(24)
            ->get();

        $resumen = [
            'total_pendiente' => $boletas->whereIn('estado', ['pendiente', 'vencida'])->sum('saldo'),
            'total_vencido' => $boletas->where('estado', 'vencida')->sum('saldo'),
            'boletas_pendientes' => $boletas->whereIn('estado', ['pendiente', 'vencida'])->count(),
            'ultima_boleta' => $boletas->first(),
        ];

        return response()->json([
            'success' => true,
            'data' => [
                'unidad' => $unidad,
                'boletas' => $boletas,
                'resumen' => $resumen,
            ],
        ]);
    }

    /**
     * Historial de boletas de la unidad
     */
    public function boletas(int $id, Request $request): JsonResponse
    {
        $anio = $request->get('anio', now()->year);

        $boletas = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $id)
            ->where('periodos_gc.anio', $anio)
            ->select(
                'boletas_gc.*',
                'periodos_gc.mes',
                'periodos_gc.anio'
            )
            ->orderBy('periodos_gc.mes')
            ->get();

        return response()->json(['success' => true, 'data' => $boletas, 'anio' => $anio]);
    }

    /**
     * Historial de pagos de la unidad
     */
    public function pagos(int $id, Request $request): JsonResponse
    {
        $pagos = DB::table('pagos_gc')
            ->join('boletas_gc', 'pagos_gc.boleta_id', '=', 'boletas_gc.id')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->where('boletas_gc.unidad_id', $id)
            ->whereNull('pagos_gc.deleted_at')
            ->select(
                'pagos_gc.*',
                'periodos_gc.mes',
                'periodos_gc.anio',
                'boletas_gc.numero_boleta'
            )
            ->orderByDesc('pagos_gc.fecha_pago')
            ->paginate($request->get('per_page', 20));

        return response()->json(['success' => true, 'data' => $pagos]);
    }
}
