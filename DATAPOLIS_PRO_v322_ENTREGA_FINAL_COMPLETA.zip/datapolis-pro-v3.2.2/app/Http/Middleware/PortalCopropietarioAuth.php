<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Symfony\Component\HttpFoundation\Response;

/**
 * DATAPOLIS PRO v3.0 - Middleware Autenticación Portal Copropietarios
 */
class PortalCopropietarioAuth
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $token = $request->bearerToken();

        if (!$token) {
            return response()->json([
                'success' => false,
                'message' => 'Token de autenticación requerido.',
                'code' => 'TOKEN_REQUIRED'
            ], 401);
        }

        // Buscar sesión activa
        $tokenHash = hash('sha256', $token);
        
        $sesion = DB::table('sesiones_portal')
            ->where('token', $tokenHash)
            ->where('activa', true)
            ->where('expira_at', '>', now())
            ->first();

        if (!$sesion) {
            return response()->json([
                'success' => false,
                'message' => 'Sesión inválida o expirada.',
                'code' => 'INVALID_SESSION'
            ], 401);
        }

        // Obtener acceso
        $acceso = DB::table('accesos_portal')
            ->where('id', $sesion->acceso_id)
            ->where('activo', true)
            ->whereNull('deleted_at')
            ->first();

        if (!$acceso) {
            return response()->json([
                'success' => false,
                'message' => 'Cuenta desactivada o eliminada.',
                'code' => 'ACCOUNT_DISABLED'
            ], 403);
        }

        // Verificar si está bloqueado
        if ($acceso->bloqueado_hasta && Carbon::parse($acceso->bloqueado_hasta)->isFuture()) {
            return response()->json([
                'success' => false,
                'message' => 'Cuenta temporalmente bloqueada.',
                'code' => 'ACCOUNT_LOCKED'
            ], 423);
        }

        // Actualizar última actividad
        DB::table('sesiones_portal')
            ->where('id', $sesion->id)
            ->update(['ultima_actividad' => now()]);

        // Agregar datos al request
        $request->attributes->set('acceso_portal', $acceso);
        $request->attributes->set('sesion_portal', $sesion);

        return $next($request);
    }
}


/**
 * Middleware para verificar email verificado
 */
class PortalEmailVerificado
{
    public function handle(Request $request, Closure $next): Response
    {
        $acceso = $request->attributes->get('acceso_portal');

        if (!$acceso->email_verificado) {
            return response()->json([
                'success' => false,
                'message' => 'Debe verificar su email para acceder a esta función.',
                'code' => 'EMAIL_NOT_VERIFIED'
            ], 403);
        }

        return $next($request);
    }
}


/**
 * Middleware para rate limiting del portal
 */
class PortalRateLimit
{
    public function handle(Request $request, Closure $next): Response
    {
        $acceso = $request->attributes->get('acceso_portal');
        $key = 'portal_rate_' . $acceso->id;
        
        $requests = cache()->get($key, 0);
        
        if ($requests >= 100) { // 100 requests por minuto
            return response()->json([
                'success' => false,
                'message' => 'Demasiadas solicitudes. Intente más tarde.',
                'code' => 'RATE_LIMIT_EXCEEDED'
            ], 429);
        }

        cache()->put($key, $requests + 1, 60);

        return $next($request);
    }
}
