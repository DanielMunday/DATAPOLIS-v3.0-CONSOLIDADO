<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Builder;
use Carbon\Carbon;

/**
 * Modelo para análisis de reglamentos de copropiedad
 * 
 * Almacena evaluaciones de cumplimiento según Ley 21.442
 * con scoring detallado y plan de acción recomendado
 * 
 * @property int $id
 * @property int $edificio_id
 * @property int $usuario_id
 * @property float $score_global
 * @property string $nivel_cumplimiento
 * @property int $elementos_ok
 * @property int $elementos_faltantes
 * @property string|null $archivo_original
 * @property string|null $fecha_inscripcion_cbr
 * @property string|null $notaria
 * @property string|null $numero_inscripcion
 * @property array $resultado_completo
 * @property Carbon $created_at
 * @property Carbon $updated_at
 * 
 * @property-read Edificio $edificio
 * @property-read User $usuario
 * @property-read string $nivel_cumplimiento_badge
 * @property-read array $resumen_ejecutivo
 */
class AnalisisReglamento extends Model
{
    use HasFactory;

    protected $table = 'analisis_reglamentos';

    protected $fillable = [
        'edificio_id',
        'usuario_id',
        'score_global',
        'nivel_cumplimiento',
        'elementos_ok',
        'elementos_faltantes',
        'archivo_original',
        'fecha_inscripcion_cbr',
        'notaria',
        'numero_inscripcion',
        'resultado_completo',
    ];

    protected $casts = [
        'score_global' => 'decimal:2',
        'elementos_ok' => 'integer',
        'elementos_faltantes' => 'integer',
        'resultado_completo' => 'array',
        'fecha_inscripcion_cbr' => 'date',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected $appends = [
        'nivel_cumplimiento_badge',
        'requiere_actualizacion_urgente',
    ];

    // =========================================================================
    // CONSTANTES
    // =========================================================================

    public const NIVEL_EXCELENTE = 'excelente';
    public const NIVEL_BUENO = 'bueno';
    public const NIVEL_REGULAR = 'regular';
    public const NIVEL_DEFICIENTE = 'deficiente';
    public const NIVEL_CRITICO = 'critico';

    public const NIVELES = [
        self::NIVEL_EXCELENTE => ['min' => 90, 'max' => 100, 'color' => 'success', 'icon' => 'check-circle'],
        self::NIVEL_BUENO => ['min' => 75, 'max' => 89, 'color' => 'info', 'icon' => 'thumbs-up'],
        self::NIVEL_REGULAR => ['min' => 50, 'max' => 74, 'color' => 'warning', 'icon' => 'alert-triangle'],
        self::NIVEL_DEFICIENTE => ['min' => 25, 'max' => 49, 'color' => 'orange', 'icon' => 'alert-circle'],
        self::NIVEL_CRITICO => ['min' => 0, 'max' => 24, 'color' => 'danger', 'icon' => 'x-circle'],
    ];

    // =========================================================================
    // RELACIONES
    // =========================================================================

    /**
     * Edificio al que pertenece el análisis
     */
    public function edificio(): BelongsTo
    {
        return $this->belongsTo(Edificio::class, 'edificio_id');
    }

    /**
     * Usuario que realizó el análisis
     */
    public function usuario(): BelongsTo
    {
        return $this->belongsTo(User::class, 'usuario_id');
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    /**
     * Filtrar por edificio
     */
    public function scopeDelEdificio(Builder $query, int $edificioId): Builder
    {
        return $query->where('edificio_id', $edificioId);
    }

    /**
     * Filtrar por nivel de cumplimiento
     */
    public function scopeConNivel(Builder $query, string $nivel): Builder
    {
        return $query->where('nivel_cumplimiento', $nivel);
    }

    /**
     * Filtrar análisis con score bajo umbral
     */
    public function scopeScoreMenorA(Builder $query, float $umbral): Builder
    {
        return $query->where('score_global', '<', $umbral);
    }

    /**
     * Filtrar análisis que requieren atención urgente
     */
    public function scopeRequiereAtencion(Builder $query): Builder
    {
        return $query->whereIn('nivel_cumplimiento', [
            self::NIVEL_DEFICIENTE,
            self::NIVEL_CRITICO
        ]);
    }

    /**
     * Filtrar análisis recientes (últimos N días)
     */
    public function scopeRecientes(Builder $query, int $dias = 30): Builder
    {
        return $query->where('created_at', '>=', now()->subDays($dias));
    }

    /**
     * Ordenar por score descendente
     */
    public function scopeMejorScore(Builder $query): Builder
    {
        return $query->orderByDesc('score_global');
    }

    /**
     * Ordenar por score ascendente (peores primero)
     */
    public function scopePeorScore(Builder $query): Builder
    {
        return $query->orderBy('score_global');
    }

    /**
     * Solo el análisis más reciente por edificio
     */
    public function scopeUltimoPorEdificio(Builder $query): Builder
    {
        return $query->whereIn('id', function ($subquery) {
            $subquery->selectRaw('MAX(id)')
                ->from('analisis_reglamentos')
                ->groupBy('edificio_id');
        });
    }

    // =========================================================================
    // ACCESSORS
    // =========================================================================

    /**
     * Badge con color según nivel de cumplimiento
     */
    public function getNivelCumplimientoBadgeAttribute(): array
    {
        $config = self::NIVELES[$this->nivel_cumplimiento] ?? self::NIVELES[self::NIVEL_REGULAR];
        
        return [
            'nivel' => $this->nivel_cumplimiento,
            'label' => ucfirst($this->nivel_cumplimiento),
            'color' => $config['color'],
            'icon' => $config['icon'],
            'score' => $this->score_global,
        ];
    }

    /**
     * Indica si requiere actualización urgente
     */
    public function getRequiereActualizacionUrgenteAttribute(): bool
    {
        return in_array($this->nivel_cumplimiento, [
            self::NIVEL_DEFICIENTE,
            self::NIVEL_CRITICO
        ]);
    }

    /**
     * Resumen ejecutivo del análisis
     */
    public function getResumenEjecutivoAttribute(): array
    {
        $resultado = $this->resultado_completo ?? [];
        
        return [
            'score' => $this->score_global,
            'nivel' => $this->nivel_cumplimiento,
            'elementos_evaluados' => $this->elementos_ok + $this->elementos_faltantes,
            'elementos_ok' => $this->elementos_ok,
            'elementos_faltantes' => $this->elementos_faltantes,
            'porcentaje_cumplimiento' => $this->elementos_ok + $this->elementos_faltantes > 0
                ? round(($this->elementos_ok / ($this->elementos_ok + $this->elementos_faltantes)) * 100, 1)
                : 0,
            'categoria_principal_deficiente' => $this->obtenerCategoriaMasDeficiente(),
            'fecha_analisis' => $this->created_at->format('d/m/Y H:i'),
            'dias_desde_analisis' => $this->created_at->diffInDays(now()),
        ];
    }

    /**
     * Plan de acción resumido
     */
    public function getPlanAccionResumidoAttribute(): array
    {
        $resultado = $this->resultado_completo ?? [];
        $planAccion = $resultado['plan_accion'] ?? [];
        
        $acciones = [];
        foreach ($planAccion as $semana => $items) {
            foreach ($items as $item) {
                $acciones[] = [
                    'semana' => $semana,
                    'accion' => $item['accion'] ?? $item,
                    'prioridad' => $item['prioridad'] ?? 'media',
                ];
            }
        }
        
        return array_slice($acciones, 0, 10); // Top 10 acciones
    }

    // =========================================================================
    // MÉTODOS PÚBLICOS
    // =========================================================================

    /**
     * Obtener la categoría más deficiente del análisis
     */
    public function obtenerCategoriaMasDeficiente(): ?string
    {
        $resultado = $this->resultado_completo ?? [];
        $categorias = $resultado['categorias'] ?? [];
        
        $peorCategoria = null;
        $peorScore = 100;
        
        foreach ($categorias as $nombre => $data) {
            $score = $data['score'] ?? 100;
            if ($score < $peorScore) {
                $peorScore = $score;
                $peorCategoria = $nombre;
            }
        }
        
        return $peorCategoria;
    }

    /**
     * Obtener elementos faltantes agrupados por categoría
     */
    public function obtenerElementosFaltantesPorCategoria(): array
    {
        $resultado = $this->resultado_completo ?? [];
        $categorias = $resultado['categorias'] ?? [];
        
        $faltantes = [];
        foreach ($categorias as $nombre => $data) {
            $itemsFaltantes = $data['items_faltantes'] ?? [];
            if (!empty($itemsFaltantes)) {
                $faltantes[$nombre] = $itemsFaltantes;
            }
        }
        
        return $faltantes;
    }

    /**
     * Comparar con otro análisis
     */
    public function compararCon(AnalisisReglamento $otro): array
    {
        return [
            'score_diferencia' => $this->score_global - $otro->score_global,
            'elementos_ok_diferencia' => $this->elementos_ok - $otro->elementos_ok,
            'elementos_faltantes_diferencia' => $this->elementos_faltantes - $otro->elementos_faltantes,
            'mejoro' => $this->score_global > $otro->score_global,
            'dias_entre_analisis' => $otro->created_at->diffInDays($this->created_at),
            'cambio_nivel' => $this->nivel_cumplimiento !== $otro->nivel_cumplimiento,
            'nivel_anterior' => $otro->nivel_cumplimiento,
            'nivel_actual' => $this->nivel_cumplimiento,
        ];
    }

    /**
     * Verificar si el análisis está vigente (menos de 90 días)
     */
    public function estaVigente(int $diasVigencia = 90): bool
    {
        return $this->created_at->diffInDays(now()) <= $diasVigencia;
    }

    /**
     * Obtener recomendaciones prioritarias
     */
    public function obtenerRecomendacionesPrioritarias(int $limite = 5): array
    {
        $resultado = $this->resultado_completo ?? [];
        $recomendaciones = $resultado['recomendaciones'] ?? [];
        
        // Ordenar por prioridad
        usort($recomendaciones, function ($a, $b) {
            $prioridades = ['critica' => 0, 'alta' => 1, 'media' => 2, 'baja' => 3];
            $prioA = $prioridades[$a['prioridad'] ?? 'media'] ?? 2;
            $prioB = $prioridades[$b['prioridad'] ?? 'media'] ?? 2;
            return $prioA - $prioB;
        });
        
        return array_slice($recomendaciones, 0, $limite);
    }

    /**
     * Calcular costo estimado de actualización
     */
    public function calcularCostoEstimadoActualizacion(): array
    {
        $elementosFaltantes = $this->elementos_faltantes;
        
        // Estimaciones base en UF
        $costoBasePorElemento = 0.5; // UF por elemento faltante
        $costoNotarial = 5; // UF aproximado
        $costoCBR = 2; // UF aproximado inscripción
        
        $costoTotal = ($elementosFaltantes * $costoBasePorElemento) + $costoNotarial + $costoCBR;
        
        return [
            'elementos_a_corregir' => $elementosFaltantes,
            'costo_correccion_uf' => round($costoTotal, 2),
            'costo_notarial_uf' => $costoNotarial,
            'costo_cbr_uf' => $costoCBR,
            'tiempo_estimado_semanas' => ceil($elementosFaltantes / 5) + 2, // 5 elementos por semana + 2 semanas trámites
            'complejidad' => $this->determinarComplejidadActualizacion(),
        ];
    }

    /**
     * Determinar complejidad de actualización
     */
    protected function determinarComplejidadActualizacion(): string
    {
        $faltantes = $this->elementos_faltantes;
        
        if ($faltantes <= 3) return 'baja';
        if ($faltantes <= 8) return 'media';
        if ($faltantes <= 15) return 'alta';
        return 'muy_alta';
    }

    // =========================================================================
    // MÉTODOS ESTÁTICOS
    // =========================================================================

    /**
     * Obtener estadísticas globales de análisis
     */
    public static function obtenerEstadisticasGlobales(?int $edificioId = null): array
    {
        $query = static::query();
        
        if ($edificioId) {
            $query->where('edificio_id', $edificioId);
        }
        
        $total = $query->count();
        $promedioScore = $query->avg('score_global') ?? 0;
        
        $porNivel = static::query()
            ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
            ->selectRaw('nivel_cumplimiento, COUNT(*) as total')
            ->groupBy('nivel_cumplimiento')
            ->pluck('total', 'nivel_cumplimiento')
            ->toArray();
        
        return [
            'total_analisis' => $total,
            'promedio_score' => round($promedioScore, 2),
            'distribucion_niveles' => $porNivel,
            'requieren_atencion' => ($porNivel[self::NIVEL_DEFICIENTE] ?? 0) + ($porNivel[self::NIVEL_CRITICO] ?? 0),
            'tasa_cumplimiento_excelente' => $total > 0 
                ? round((($porNivel[self::NIVEL_EXCELENTE] ?? 0) / $total) * 100, 1) 
                : 0,
        ];
    }

    /**
     * Obtener tendencia de scores en el tiempo
     */
    public static function obtenerTendencia(int $edificioId, int $meses = 12): array
    {
        return static::where('edificio_id', $edificioId)
            ->where('created_at', '>=', now()->subMonths($meses))
            ->orderBy('created_at')
            ->get(['score_global', 'nivel_cumplimiento', 'created_at'])
            ->map(fn($item) => [
                'fecha' => $item->created_at->format('Y-m-d'),
                'score' => $item->score_global,
                'nivel' => $item->nivel_cumplimiento,
            ])
            ->toArray();
    }
}
