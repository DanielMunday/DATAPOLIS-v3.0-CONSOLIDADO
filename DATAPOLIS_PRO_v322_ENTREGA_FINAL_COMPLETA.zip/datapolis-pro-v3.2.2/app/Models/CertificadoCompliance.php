<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;
use Illuminate\Support\Str;

/**
 * Modelo para certificados de compliance tributario
 * 
 * Gestiona certificaciones de cumplimiento con verificación criptográfica,
 * control de vigencia y auditoría completa
 * 
 * @property int $id
 * @property int $edificio_id
 * @property int $emitido_por
 * @property string $codigo
 * @property string $tipo
 * @property string $estado
 * @property float $score_global
 * @property string $nivel_cumplimiento
 * @property Carbon $fecha_emision
 * @property Carbon $fecha_vencimiento
 * @property string $periodo
 * @property string $hash_verificacion
 * @property string $url_verificacion
 * @property array $evaluacion_json
 * @property string|null $observaciones
 * @property int|null $copropietario_id
 * @property int|null $unidad_id
 * @property Carbon $created_at
 * @property Carbon $updated_at
 * @property Carbon|null $deleted_at
 */
class CertificadoCompliance extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'certificados_compliance';

    protected $fillable = [
        'edificio_id',
        'emitido_por',
        'codigo',
        'tipo',
        'estado',
        'score_global',
        'nivel_cumplimiento',
        'fecha_emision',
        'fecha_vencimiento',
        'periodo',
        'hash_verificacion',
        'url_verificacion',
        'evaluacion_json',
        'observaciones',
        'copropietario_id',
        'unidad_id',
    ];

    protected $casts = [
        'score_global' => 'decimal:2',
        'evaluacion_json' => 'array',
        'fecha_emision' => 'datetime',
        'fecha_vencimiento' => 'date',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    protected $appends = [
        'esta_vigente',
        'dias_para_vencer',
        'estado_badge',
    ];

    protected $hidden = [
        'hash_verificacion', // Solo se muestra en verificación pública
    ];

    // =========================================================================
    // CONSTANTES
    // =========================================================================

    // Tipos de certificado
    public const TIPO_COMPLIANCE_GENERAL = 'compliance_general';
    public const TIPO_CUMPLIMIENTO_TRIBUTARIO = 'cumplimiento_tributario';
    public const TIPO_CUMPLIMIENTO_LEY_21442 = 'cumplimiento_ley_21442';
    public const TIPO_CUMPLIMIENTO_LEY_21713 = 'cumplimiento_ley_21713';
    public const TIPO_AUDITORIA_ANUAL = 'auditoria_anual';
    public const TIPO_SOLVENCIA_FISCAL = 'solvencia_fiscal';
    public const TIPO_BUENAS_PRACTICAS = 'buenas_practicas';

    public const TIPOS_CERTIFICADO = [
        self::TIPO_COMPLIANCE_GENERAL => [
            'nombre' => 'Certificado de Compliance General',
            'descripcion' => 'Cumplimiento integral de obligaciones legales y tributarias',
            'vigencia_meses' => 12,
            'items_evaluacion' => 25,
            'requiere_auditoria' => false,
        ],
        self::TIPO_CUMPLIMIENTO_TRIBUTARIO => [
            'nombre' => 'Certificado de Cumplimiento Tributario',
            'descripcion' => 'Cumplimiento de obligaciones ante el SII',
            'vigencia_meses' => 6,
            'items_evaluacion' => 15,
            'requiere_auditoria' => false,
        ],
        self::TIPO_CUMPLIMIENTO_LEY_21442 => [
            'nombre' => 'Certificado Ley 21.442',
            'descripcion' => 'Cumplimiento nueva ley de copropiedad inmobiliaria',
            'vigencia_meses' => 12,
            'items_evaluacion' => 30,
            'requiere_auditoria' => true,
        ],
        self::TIPO_CUMPLIMIENTO_LEY_21713 => [
            'nombre' => 'Certificado Ley 21.713',
            'descripcion' => 'Cumplimiento ley de cumplimiento tributario',
            'vigencia_meses' => 6,
            'items_evaluacion' => 20,
            'requiere_auditoria' => false,
        ],
        self::TIPO_AUDITORIA_ANUAL => [
            'nombre' => 'Certificado de Auditoría Anual',
            'descripcion' => 'Revisión anual de procedimientos y documentación',
            'vigencia_meses' => 12,
            'items_evaluacion' => 40,
            'requiere_auditoria' => true,
        ],
        self::TIPO_SOLVENCIA_FISCAL => [
            'nombre' => 'Certificado de Solvencia Fiscal',
            'descripcion' => 'Sin deudas tributarias pendientes',
            'vigencia_meses' => 3,
            'items_evaluacion' => 10,
            'requiere_auditoria' => false,
        ],
        self::TIPO_BUENAS_PRACTICAS => [
            'nombre' => 'Certificado de Buenas Prácticas',
            'descripcion' => 'Cumplimiento de estándares de gestión',
            'vigencia_meses' => 12,
            'items_evaluacion' => 20,
            'requiere_auditoria' => false,
        ],
    ];

    // Estados del certificado
    public const ESTADO_APROBADO = 'aprobado';
    public const ESTADO_CONDICIONAL = 'condicional';
    public const ESTADO_RECHAZADO = 'rechazado';
    public const ESTADO_VENCIDO = 'vencido';
    public const ESTADO_REVOCADO = 'revocado';

    public const ESTADOS = [
        self::ESTADO_APROBADO => [
            'nombre' => 'Aprobado',
            'color' => 'success',
            'icon' => 'check-circle',
            'descripcion' => 'Certificado válido y vigente',
        ],
        self::ESTADO_CONDICIONAL => [
            'nombre' => 'Aprobado Condicional',
            'color' => 'warning',
            'icon' => 'alert-triangle',
            'descripcion' => 'Aprobado con observaciones menores',
        ],
        self::ESTADO_RECHAZADO => [
            'nombre' => 'Rechazado',
            'color' => 'danger',
            'icon' => 'x-circle',
            'descripcion' => 'No cumple requisitos mínimos',
        ],
        self::ESTADO_VENCIDO => [
            'nombre' => 'Vencido',
            'color' => 'secondary',
            'icon' => 'clock',
            'descripcion' => 'Certificado expirado',
        ],
        self::ESTADO_REVOCADO => [
            'nombre' => 'Revocado',
            'color' => 'dark',
            'icon' => 'slash',
            'descripcion' => 'Certificado anulado',
        ],
    ];

    // Niveles de cumplimiento
    public const NIVEL_EXCELENTE = 'excelente';
    public const NIVEL_BUENO = 'bueno';
    public const NIVEL_ACEPTABLE = 'aceptable';
    public const NIVEL_INSUFICIENTE = 'insuficiente';

    // =========================================================================
    // BOOT
    // =========================================================================

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($certificado) {
            // Generar código único si no existe
            if (empty($certificado->codigo)) {
                $certificado->codigo = static::generarCodigoUnico();
            }
            
            // Establecer fecha de emisión
            if (empty($certificado->fecha_emision)) {
                $certificado->fecha_emision = now();
            }
            
            // Calcular fecha de vencimiento si no existe
            if (empty($certificado->fecha_vencimiento)) {
                $vigenciaMeses = static::TIPOS_CERTIFICADO[$certificado->tipo]['vigencia_meses'] ?? 12;
                $certificado->fecha_vencimiento = now()->addMonths($vigenciaMeses);
            }
            
            // Generar hash de verificación
            $certificado->hash_verificacion = static::generarHashVerificacion($certificado);
            
            // Generar URL de verificación
            $certificado->url_verificacion = config('app.url') . '/verificar/' . $certificado->codigo;
        });
    }

    // =========================================================================
    // RELACIONES
    // =========================================================================

    public function edificio(): BelongsTo
    {
        return $this->belongsTo(Edificio::class, 'edificio_id');
    }

    public function emisor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'emitido_por');
    }

    public function copropietario(): BelongsTo
    {
        return $this->belongsTo(Copropietario::class, 'copropietario_id');
    }

    public function unidad(): BelongsTo
    {
        return $this->belongsTo(Unidad::class, 'unidad_id');
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    public function scopeDelEdificio(Builder $query, int $edificioId): Builder
    {
        return $query->where('edificio_id', $edificioId);
    }

    public function scopePorTipo(Builder $query, string $tipo): Builder
    {
        return $query->where('tipo', $tipo);
    }

    public function scopePorEstado(Builder $query, string $estado): Builder
    {
        return $query->where('estado', $estado);
    }

    public function scopeVigentes(Builder $query): Builder
    {
        return $query->where('estado', self::ESTADO_APROBADO)
                     ->where('fecha_vencimiento', '>', now());
    }

    public function scopeVencidos(Builder $query): Builder
    {
        return $query->where('fecha_vencimiento', '<=', now())
                     ->where('estado', '!=', self::ESTADO_VENCIDO);
    }

    public function scopeProximosAVencer(Builder $query, int $dias = 30): Builder
    {
        return $query->where('estado', self::ESTADO_APROBADO)
                     ->whereBetween('fecha_vencimiento', [now(), now()->addDays($dias)]);
    }

    public function scopeAprobados(Builder $query): Builder
    {
        return $query->whereIn('estado', [self::ESTADO_APROBADO, self::ESTADO_CONDICIONAL]);
    }

    public function scopeDelPeriodo(Builder $query, string $periodo): Builder
    {
        return $query->where('periodo', $periodo);
    }

    public function scopeDelCopropietario(Builder $query, int $copropietarioId): Builder
    {
        return $query->where('copropietario_id', $copropietarioId);
    }

    public function scopeDeLaUnidad(Builder $query, int $unidadId): Builder
    {
        return $query->where('unidad_id', $unidadId);
    }

    // =========================================================================
    // ACCESSORS
    // =========================================================================

    /**
     * Indica si el certificado está vigente
     */
    public function getEstaVigenteAttribute(): bool
    {
        return $this->estado === self::ESTADO_APROBADO && 
               $this->fecha_vencimiento > now();
    }

    /**
     * Días restantes para vencimiento
     */
    public function getDiasParaVencerAttribute(): int
    {
        if ($this->fecha_vencimiento <= now()) {
            return 0;
        }
        return now()->diffInDays($this->fecha_vencimiento);
    }

    /**
     * Badge del estado con colores
     */
    public function getEstadoBadgeAttribute(): array
    {
        // Si está vencido pero no marcado como tal
        if ($this->estado === self::ESTADO_APROBADO && $this->fecha_vencimiento <= now()) {
            return self::ESTADOS[self::ESTADO_VENCIDO];
        }
        
        return self::ESTADOS[$this->estado] ?? self::ESTADOS[self::ESTADO_RECHAZADO];
    }

    /**
     * Información del tipo de certificado
     */
    public function getInfoTipoAttribute(): array
    {
        return self::TIPOS_CERTIFICADO[$this->tipo] ?? [
            'nombre' => 'Certificado',
            'descripcion' => 'Certificado de compliance',
            'vigencia_meses' => 12,
        ];
    }

    /**
     * Resumen del certificado
     */
    public function getResumenAttribute(): array
    {
        return [
            'codigo' => $this->codigo,
            'tipo' => $this->info_tipo['nombre'],
            'estado' => $this->estado_badge['nombre'],
            'score' => $this->score_global,
            'nivel' => $this->nivel_cumplimiento,
            'vigente' => $this->esta_vigente,
            'dias_restantes' => $this->dias_para_vencer,
            'fecha_emision' => $this->fecha_emision->format('d/m/Y'),
            'fecha_vencimiento' => $this->fecha_vencimiento->format('d/m/Y'),
            'url_verificacion' => $this->url_verificacion,
        ];
    }

    /**
     * Datos para QR code
     */
    public function getDatosQrAttribute(): array
    {
        return [
            'codigo' => $this->codigo,
            'tipo' => $this->tipo,
            'edificio' => $this->edificio->nombre ?? 'N/A',
            'rut_edificio' => $this->edificio->rut ?? 'N/A',
            'score' => $this->score_global,
            'estado' => $this->estado,
            'fecha_emision' => $this->fecha_emision->format('Y-m-d'),
            'fecha_vencimiento' => $this->fecha_vencimiento->format('Y-m-d'),
            'hash' => substr($this->hash_verificacion, 0, 16) . '...',
            'verificar_en' => $this->url_verificacion,
        ];
    }

    // =========================================================================
    // MÉTODOS PÚBLICOS
    // =========================================================================

    /**
     * Verificar autenticidad del certificado
     */
    public function verificarAutenticidad(): array
    {
        $hashCalculado = static::generarHashVerificacion($this);
        $esValido = hash_equals($this->hash_verificacion, $hashCalculado);
        
        return [
            'valido' => $esValido,
            'vigente' => $this->esta_vigente,
            'estado' => $this->estado,
            'mensaje' => $this->generarMensajeVerificacion($esValido),
            'certificado' => $esValido ? [
                'codigo' => $this->codigo,
                'tipo' => $this->info_tipo['nombre'],
                'edificio' => $this->edificio->nombre ?? 'N/A',
                'score' => $this->score_global,
                'nivel_cumplimiento' => $this->nivel_cumplimiento,
                'fecha_emision' => $this->fecha_emision->format('d/m/Y'),
                'fecha_vencimiento' => $this->fecha_vencimiento->format('d/m/Y'),
                'estado_actual' => $this->estado_badge['nombre'],
            ] : null,
            'verificado_en' => now()->format('d/m/Y H:i:s'),
        ];
    }

    /**
     * Renovar certificado
     */
    public function renovar(int $usuarioId): ?self
    {
        // Solo se pueden renovar certificados vigentes o próximos a vencer
        if (!$this->esta_vigente && $this->dias_para_vencer > 30) {
            return null;
        }
        
        $vigenciaMeses = static::TIPOS_CERTIFICADO[$this->tipo]['vigencia_meses'] ?? 12;
        
        $nuevo = static::create([
            'edificio_id' => $this->edificio_id,
            'emitido_por' => $usuarioId,
            'tipo' => $this->tipo,
            'estado' => $this->estado,
            'score_global' => $this->score_global,
            'nivel_cumplimiento' => $this->nivel_cumplimiento,
            'fecha_vencimiento' => $this->fecha_vencimiento->addMonths($vigenciaMeses),
            'periodo' => $this->calcularNuevoPeriodo(),
            'evaluacion_json' => $this->evaluacion_json,
            'observaciones' => "Renovación del certificado {$this->codigo}",
            'copropietario_id' => $this->copropietario_id,
            'unidad_id' => $this->unidad_id,
        ]);
        
        // Marcar el anterior como vencido
        $this->update(['estado' => self::ESTADO_VENCIDO]);
        
        return $nuevo;
    }

    /**
     * Revocar certificado
     */
    public function revocar(string $motivo, int $usuarioId): bool
    {
        $this->estado = self::ESTADO_REVOCADO;
        $this->observaciones = ($this->observaciones ? $this->observaciones . "\n" : '') .
                               "[REVOCADO " . now()->format('d/m/Y H:i') . "] $motivo (Usuario: $usuarioId)";
        return $this->save();
    }

    /**
     * Obtener items de evaluación con detalle
     */
    public function obtenerDetalleEvaluacion(): array
    {
        $evaluacion = $this->evaluacion_json ?? [];
        
        return [
            'items_evaluados' => $evaluacion['items'] ?? [],
            'categorias' => $evaluacion['categorias'] ?? [],
            'puntos_fuertes' => $evaluacion['puntos_fuertes'] ?? [],
            'areas_mejora' => $evaluacion['areas_mejora'] ?? [],
            'recomendaciones' => $evaluacion['recomendaciones'] ?? [],
            'documentos_revisados' => $evaluacion['documentos'] ?? [],
            'total_items' => count($evaluacion['items'] ?? []),
            'items_aprobados' => collect($evaluacion['items'] ?? [])->where('aprobado', true)->count(),
        ];
    }

    /**
     * Generar mensaje para verificación
     */
    protected function generarMensajeVerificacion(bool $esValido): string
    {
        if (!$esValido) {
            return 'CERTIFICADO NO VÁLIDO: El hash de verificación no coincide. Este certificado puede haber sido alterado.';
        }
        
        if ($this->estado === self::ESTADO_REVOCADO) {
            return 'CERTIFICADO REVOCADO: Este certificado ha sido anulado y no tiene validez.';
        }
        
        if (!$this->esta_vigente) {
            return 'CERTIFICADO VENCIDO: Este certificado expiró el ' . $this->fecha_vencimiento->format('d/m/Y') . '.';
        }
        
        if ($this->estado === self::ESTADO_CONDICIONAL) {
            return 'CERTIFICADO VÁLIDO (CONDICIONAL): Certificado vigente con observaciones.';
        }
        
        return 'CERTIFICADO VÁLIDO: Certificado auténtico y vigente hasta el ' . $this->fecha_vencimiento->format('d/m/Y') . '.';
    }

    /**
     * Calcular nuevo periodo para renovación
     */
    protected function calcularNuevoPeriodo(): string
    {
        $vigenciaMeses = static::TIPOS_CERTIFICADO[$this->tipo]['vigencia_meses'] ?? 12;
        
        if ($vigenciaMeses >= 12) {
            return now()->format('Y');
        } elseif ($vigenciaMeses >= 6) {
            $semestre = now()->month <= 6 ? '1' : '2';
            return now()->format('Y') . '-S' . $semestre;
        } elseif ($vigenciaMeses >= 3) {
            $trimestre = ceil(now()->month / 3);
            return now()->format('Y') . '-T' . $trimestre;
        } else {
            return now()->format('Y-m');
        }
    }

    // =========================================================================
    // MÉTODOS ESTÁTICOS
    // =========================================================================

    /**
     * Generar código único de certificado
     */
    public static function generarCodigoUnico(): string
    {
        do {
            $codigo = 'CERT-' . strtoupper(Str::random(4)) . '-' . 
                      now()->format('Ymd') . '-' . 
                      strtoupper(Str::random(4));
        } while (static::where('codigo', $codigo)->exists());
        
        return $codigo;
    }

    /**
     * Generar hash de verificación SHA-256
     */
    public static function generarHashVerificacion(self $certificado): string
    {
        $datos = implode('|', [
            $certificado->codigo,
            $certificado->edificio_id,
            $certificado->tipo,
            $certificado->score_global,
            $certificado->fecha_emision?->format('Y-m-d H:i:s') ?? now()->format('Y-m-d H:i:s'),
            config('app.key'),
        ]);
        
        return hash('sha256', $datos);
    }

    /**
     * Buscar certificado por código para verificación pública
     */
    public static function buscarParaVerificacion(string $codigo): ?array
    {
        $certificado = static::where('codigo', $codigo)->first();
        
        if (!$certificado) {
            return null;
        }
        
        return $certificado->verificarAutenticidad();
    }

    /**
     * Estadísticas de certificados por edificio
     */
    public static function estadisticasPorEdificio(int $edificioId): array
    {
        $certificados = static::where('edificio_id', $edificioId)->get();
        
        return [
            'total' => $certificados->count(),
            'vigentes' => $certificados->where('estado', self::ESTADO_APROBADO)
                                       ->where('fecha_vencimiento', '>', now())->count(),
            'condicionales' => $certificados->where('estado', self::ESTADO_CONDICIONAL)->count(),
            'vencidos' => $certificados->where('fecha_vencimiento', '<=', now())->count(),
            'proximos_a_vencer' => $certificados->where('estado', self::ESTADO_APROBADO)
                                                ->whereBetween('fecha_vencimiento', [now(), now()->addDays(30)])->count(),
            'por_tipo' => $certificados->groupBy('tipo')->map->count()->toArray(),
            'promedio_score' => round($certificados->avg('score_global') ?? 0, 2),
            'ultimo_certificado' => $certificados->sortByDesc('created_at')->first()?->resumen,
        ];
    }

    /**
     * Actualizar estados de certificados vencidos (para cron)
     */
    public static function actualizarEstadosVencidos(): int
    {
        return static::where('estado', self::ESTADO_APROBADO)
                     ->where('fecha_vencimiento', '<=', now())
                     ->update(['estado' => self::ESTADO_VENCIDO]);
    }

    /**
     * Obtener certificados que requieren renovación
     */
    public static function obtenerParaRenovacion(int $diasAnticipacion = 30): \Illuminate\Database\Eloquent\Collection
    {
        return static::where('estado', self::ESTADO_APROBADO)
                     ->whereBetween('fecha_vencimiento', [now(), now()->addDays($diasAnticipacion)])
                     ->with('edificio')
                     ->get();
    }
}
