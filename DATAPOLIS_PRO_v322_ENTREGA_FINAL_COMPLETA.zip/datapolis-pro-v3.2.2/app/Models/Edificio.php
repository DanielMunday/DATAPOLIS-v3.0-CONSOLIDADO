<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Edificio extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'tenant_id', 'nombre', 'direccion', 'comuna', 'region', 'rut', 'rol_avaluo', 'tipo',
        'total_unidades', 'activo', 'administrador_nombre', 'administrador_rut',
        'administrador_email', 'administrador_telefono', 'dia_vencimiento_gc', 'interes_mora',
    ];

    protected $casts = ['activo' => 'boolean', 'interes_mora' => 'decimal:2'];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function unidades()
    {
        return $this->hasMany(Unidad::class);
    }

    public function periodosGC()
    {
        return $this->hasMany(PeriodoGC::class);
    }

    public function contratos()
    {
        return $this->hasMany(ContratoArriendo::class);
    }
}
