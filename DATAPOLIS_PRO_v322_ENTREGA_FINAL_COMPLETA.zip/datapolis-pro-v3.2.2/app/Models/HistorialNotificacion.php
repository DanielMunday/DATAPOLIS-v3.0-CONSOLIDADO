<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Builder;
use Carbon\Carbon;

/**
 * Modelo HistorialNotificacion
 * 
 * Registro completo de todas las notificaciones enviadas en la plataforma
 * Incluye tracking de estados, métricas de entrega y lectura
 * 
 * @property int $id
 * @property int $edificio_id
 * @property int|null $copropietario_id
 * @property string $tipo Tipo de notificación (15 tipos)
 * @property string $categoria Categoría (6 categorías)
 * @property string $canal email|push|sms
 * @property string $prioridad baja|normal|alta|urgente
 * @property string $asunto
 * @property string|null $contenido_resumen
 * @property array $datos_envio Datos completos del envío
 * @property string $estado pendiente|enviado|entregado|fallido|leido
 * @property string|null $error_mensaje
 * @property string|null $proveedor_id ID del proveedor (SES, etc)
 * @property Carbon|null $enviado_at
 * @property Carbon|null $entregado_at
 * @property Carbon|null $leido_at
 * @property Carbon $created_at
 * @property Carbon $updated_at
 */
class HistorialNotificacion extends Model
{
    use HasFactory;

    protected $table = 'historial_notificaciones';

    protected $fillable = [
        'edificio_id',
        'copropietario_id',
        'tipo',
        'categoria',
        'canal',
        'prioridad',
        'asunto',
        'contenido_resumen',
        'datos_envio',
        'estado',
        'error_mensaje',
        'proveedor_id',
        'enviado_at',
        'entregado_at',
        'leido_at',
    ];

    protected $casts = [
        'datos_envio' => 'array',
        'enviado_at' => 'datetime',
        'entregado_at' => 'datetime',
        'leido_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected $appends = [
        'tiempo_entrega_segundos',
        'fue_leido',
        'esta_pendiente',
    ];

    // =========================================================================
    // CONSTANTES
    // =========================================================================

    public const TIPOS = [
        'vencimiento_pago' => ['categoria' => 'cobranza', 'descripcion' => 'Recordatorio de pago próximo a vencer'],
        'mora_inicial' => ['categoria' => 'cobranza', 'descripcion' => 'Primera notificación de mora'],
        'mora_grave' => ['categoria' => 'cobranza', 'descripcion' => 'Mora prolongada, acción legal posible'],
        'pago_confirmado' => ['categoria' => 'cobranza', 'descripcion' => 'Confirmación de pago recibido'],
        'asamblea_convocatoria' => ['categoria' => 'asamblea', 'descripcion' => 'Convocatoria a asamblea'],
        'asamblea_recordatorio' => ['categoria' => 'asamblea', 'descripcion' => 'Recordatorio de asamblea próxima'],
        'asamblea_acta' => ['categoria' => 'asamblea', 'descripcion' => 'Acta de asamblea disponible'],
        'compliance_vencimiento' => ['categoria' => 'compliance', 'descripcion' => 'Certificado próximo a vencer'],
        'compliance_alerta' => ['categoria' => 'compliance', 'descripcion' => 'Alerta de incumplimiento detectado'],
        'compliance_actualizacion' => ['categoria' => 'compliance', 'descripcion' => 'Actualización de estado compliance'],
        'documento_nuevo' => ['categoria' => 'documentos', 'descripcion' => 'Nuevo documento disponible'],
        'documento_firma' => ['categoria' => 'documentos', 'descripcion' => 'Documento requiere firma'],
        'mantencion_programada' => ['categoria' => 'mantencion', 'descripcion' => 'Mantención programada'],
        'mantencion_emergencia' => ['categoria' => 'mantencion', 'descripcion' => 'Mantención de emergencia'],
        'sistema_general' => ['categoria' => 'sistema', 'descripcion' => 'Notificación general del sistema'],
    ];

    public const CATEGORIAS = [
        'cobranza' => ['color' => '#dc2626', 'icono' => 'currency-dollar'],
        'asamblea' => ['color' => '#7c3aed', 'icono' => 'users'],
        'compliance' => ['color' => '#059669', 'icono' => 'shield-check'],
        'documentos' => ['color' => '#2563eb', 'icono' => 'document'],
        'mantencion' => ['color' => '#d97706', 'icono' => 'wrench'],
        'sistema' => ['color' => '#6b7280', 'icono' => 'cog'],
    ];

    public const CANALES = ['email', 'push', 'sms'];

    public const PRIORIDADES = [
        'baja' => ['orden' => 1, 'descripcion' => 'Sin urgencia'],
        'normal' => ['orden' => 2, 'descripcion' => 'Prioridad estándar'],
        'alta' => ['orden' => 3, 'descripcion' => 'Requiere atención pronta'],
        'urgente' => ['orden' => 4, 'descripcion' => 'Acción inmediata requerida'],
    ];

    public const ESTADOS = [
        'pendiente' => ['descripcion' => 'En cola de envío', 'color' => '#6b7280'],
        'enviado' => ['descripcion' => 'Enviado al proveedor', 'color' => '#2563eb'],
        'entregado' => ['descripcion' => 'Entregado al destinatario', 'color' => '#059669'],
        'fallido' => ['descripcion' => 'Error en el envío', 'color' => '#dc2626'],
        'leido' => ['descripcion' => 'Leído por el destinatario', 'color' => '#7c3aed'],
    ];

    // =========================================================================
    // RELACIONES
    // =========================================================================

    public function edificio(): BelongsTo
    {
        return $this->belongsTo(Edificio::class, 'edificio_id');
    }

    public function copropietario(): BelongsTo
    {
        return $this->belongsTo(Copropietario::class, 'copropietario_id');
    }

    // =========================================================================
    // ACCESSORS
    // =========================================================================

    public function getTiempoEntregaSegundosAttribute(): ?int
    {
        if (!$this->enviado_at || !$this->entregado_at) {
            return null;
        }
        return $this->enviado_at->diffInSeconds($this->entregado_at);
    }

    public function getFueLeidoAttribute(): bool
    {
        return $this->estado === 'leido' || $this->leido_at !== null;
    }

    public function getEstaPendienteAttribute(): bool
    {
        return $this->estado === 'pendiente';
    }

    public function getColorEstadoAttribute(): string
    {
        return self::ESTADOS[$this->estado]['color'] ?? '#6b7280';
    }

    public function getColorCategoriaAttribute(): string
    {
        return self::CATEGORIAS[$this->categoria]['color'] ?? '#6b7280';
    }

    public function getIconoCategoriaAttribute(): string
    {
        return self::CATEGORIAS[$this->categoria]['icono'] ?? 'bell';
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    public function scopeDeEdificio(Builder $query, int $edificioId): Builder
    {
        return $query->where('edificio_id', $edificioId);
    }

    public function scopeDeCopropietario(Builder $query, int $copropietarioId): Builder
    {
        return $query->where('copropietario_id', $copropietarioId);
    }

    public function scopeConEstado(Builder $query, string $estado): Builder
    {
        return $query->where('estado', $estado);
    }

    public function scopePendientes(Builder $query): Builder
    {
        return $query->where('estado', 'pendiente');
    }

    public function scopeFallidas(Builder $query): Builder
    {
        return $query->where('estado', 'fallido');
    }

    public function scopeExitosas(Builder $query): Builder
    {
        return $query->whereIn('estado', ['enviado', 'entregado', 'leido']);
    }

    public function scopeConCanal(Builder $query, string $canal): Builder
    {
        return $query->where('canal', $canal);
    }

    public function scopeConTipo(Builder $query, string $tipo): Builder
    {
        return $query->where('tipo', $tipo);
    }

    public function scopeConCategoria(Builder $query, string $categoria): Builder
    {
        return $query->where('categoria', $categoria);
    }

    public function scopeConPrioridad(Builder $query, string $prioridad): Builder
    {
        return $query->where('prioridad', $prioridad);
    }

    public function scopeUrgentes(Builder $query): Builder
    {
        return $query->whereIn('prioridad', ['alta', 'urgente']);
    }

    public function scopeEnPeriodo(Builder $query, Carbon $inicio, Carbon $fin): Builder
    {
        return $query->whereBetween('created_at', [$inicio, $fin]);
    }

    public function scopeHoy(Builder $query): Builder
    {
        return $query->whereDate('created_at', today());
    }

    public function scopeUltimaSemana(Builder $query): Builder
    {
        return $query->where('created_at', '>=', now()->subWeek());
    }

    public function scopeUltimoMes(Builder $query): Builder
    {
        return $query->where('created_at', '>=', now()->subMonth());
    }

    // =========================================================================
    // MÉTODOS DE INSTANCIA
    // =========================================================================

    /**
     * Marcar como enviado
     */
    public function marcarEnviado(?string $proveedorId = null): bool
    {
        return $this->update([
            'estado' => 'enviado',
            'enviado_at' => now(),
            'proveedor_id' => $proveedorId,
        ]);
    }

    /**
     * Marcar como entregado
     */
    public function marcarEntregado(): bool
    {
        return $this->update([
            'estado' => 'entregado',
            'entregado_at' => now(),
        ]);
    }

    /**
     * Marcar como leído
     */
    public function marcarLeido(): bool
    {
        return $this->update([
            'estado' => 'leido',
            'leido_at' => now(),
        ]);
    }

    /**
     * Marcar como fallido
     */
    public function marcarFallido(string $errorMensaje): bool
    {
        return $this->update([
            'estado' => 'fallido',
            'error_mensaje' => $errorMensaje,
        ]);
    }

    /**
     * Obtener resumen para listado
     */
    public function obtenerResumen(): array
    {
        return [
            'id' => $this->id,
            'tipo' => $this->tipo,
            'categoria' => $this->categoria,
            'canal' => $this->canal,
            'prioridad' => $this->prioridad,
            'asunto' => $this->asunto,
            'estado' => $this->estado,
            'color_estado' => $this->color_estado,
            'color_categoria' => $this->color_categoria,
            'enviado_at' => $this->enviado_at?->format('Y-m-d H:i'),
            'fue_leido' => $this->fue_leido,
            'created_at' => $this->created_at->format('Y-m-d H:i'),
        ];
    }

    // =========================================================================
    // MÉTODOS ESTÁTICOS
    // =========================================================================

    /**
     * Estadísticas de envío por edificio
     */
    public static function estadisticasEdificio(int $edificioId, ?Carbon $desde = null, ?Carbon $hasta = null): array
    {
        $query = self::deEdificio($edificioId);

        if ($desde) {
            $query->where('created_at', '>=', $desde);
        }
        if ($hasta) {
            $query->where('created_at', '<=', $hasta);
        }

        $total = $query->count();
        $porEstado = (clone $query)->selectRaw('estado, COUNT(*) as cantidad')
            ->groupBy('estado')
            ->pluck('cantidad', 'estado')
            ->toArray();

        $porCanal = (clone $query)->selectRaw('canal, COUNT(*) as cantidad')
            ->groupBy('canal')
            ->pluck('cantidad', 'canal')
            ->toArray();

        $porCategoria = (clone $query)->selectRaw('categoria, COUNT(*) as cantidad')
            ->groupBy('categoria')
            ->pluck('cantidad', 'categoria')
            ->toArray();

        $exitosas = ($porEstado['enviado'] ?? 0) + ($porEstado['entregado'] ?? 0) + ($porEstado['leido'] ?? 0);
        $fallidas = $porEstado['fallido'] ?? 0;
        $tasaExito = $total > 0 ? round(($exitosas / $total) * 100, 2) : 0;

        return [
            'total' => $total,
            'por_estado' => $porEstado,
            'por_canal' => $porCanal,
            'por_categoria' => $porCategoria,
            'exitosas' => $exitosas,
            'fallidas' => $fallidas,
            'tasa_exito' => $tasaExito,
        ];
    }

    /**
     * Crear registro de notificación
     */
    public static function registrar(array $datos): self
    {
        $tipo = $datos['tipo'];
        $categoria = self::TIPOS[$tipo]['categoria'] ?? 'sistema';

        return self::create([
            'edificio_id' => $datos['edificio_id'],
            'copropietario_id' => $datos['copropietario_id'] ?? null,
            'tipo' => $tipo,
            'categoria' => $categoria,
            'canal' => $datos['canal'],
            'prioridad' => $datos['prioridad'] ?? 'normal',
            'asunto' => $datos['asunto'],
            'contenido_resumen' => $datos['contenido_resumen'] ?? null,
            'datos_envio' => $datos['datos_envio'] ?? [],
            'estado' => 'pendiente',
        ]);
    }
}
