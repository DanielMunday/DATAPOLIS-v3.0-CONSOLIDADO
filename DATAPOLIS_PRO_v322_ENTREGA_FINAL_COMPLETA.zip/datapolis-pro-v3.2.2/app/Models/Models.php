<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

/**
 * DATAPOLIS PRO - Modelos Base
 */

// =========================================================================
// USER MODEL
// =========================================================================
class User extends Authenticatable
{
    use HasApiTokens, SoftDeletes;

    protected $fillable = [
        'tenant_id',
        'name',
        'email',
        'password',
        'rut',
        'telefono',
        'cargo',
        'activo',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'activo' => 'boolean',
        'ultimo_login' => 'datetime',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }
}

// =========================================================================
// TENANT MODEL (Multi-tenancy)
// =========================================================================
class Tenant extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'nombre',
        'rut',
        'direccion',
        'telefono',
        'email',
        'activo',
        'plan',
        'max_edificios',
        'max_usuarios',
    ];

    protected $casts = [
        'activo' => 'boolean',
    ];

    public function usuarios()
    {
        return $this->hasMany(User::class);
    }

    public function edificios()
    {
        return $this->hasMany(Edificio::class);
    }
}

// =========================================================================
// EDIFICIO MODEL
// =========================================================================
class Edificio extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'tenant_id',
        'nombre',
        'direccion',
        'comuna',
        'region',
        'rut',
        'rol_avaluo',
        'tipo',
        'total_unidades',
        'activo',
        'administrador_nombre',
        'administrador_rut',
        'administrador_email',
        'administrador_telefono',
    ];

    protected $casts = [
        'activo' => 'boolean',
    ];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function unidades()
    {
        return $this->hasMany(Unidad::class);
    }

    public function periodosGC()
    {
        return $this->hasMany(PeriodoGC::class);
    }
}

// =========================================================================
// UNIDAD MODEL
// =========================================================================
class Unidad extends Model
{
    use SoftDeletes;

    protected $table = 'unidades';

    protected $fillable = [
        'tenant_id',
        'edificio_id',
        'propietario_id',
        'numero',
        'tipo',
        'piso',
        'superficie_util',
        'superficie_terraza',
        'prorrateo',
        'rol_avaluo',
        'activa',
    ];

    protected $casts = [
        'activa' => 'boolean',
        'prorrateo' => 'decimal:4',
        'superficie_util' => 'decimal:2',
    ];

    public function edificio()
    {
        return $this->belongsTo(Edificio::class);
    }

    public function propietario()
    {
        return $this->belongsTo(Persona::class, 'propietario_id');
    }

    public function boletas()
    {
        return $this->hasMany(BoletaGC::class);
    }
}

// =========================================================================
// PERSONA MODEL
// =========================================================================
class Persona extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'tenant_id',
        'rut',
        'nombre',
        'apellido_paterno',
        'apellido_materno',
        'nombre_completo',
        'email',
        'telefono',
        'direccion',
        'tipo',
    ];

    public function unidades()
    {
        return $this->hasMany(Unidad::class, 'propietario_id');
    }
}

// =========================================================================
// PERIODO GASTOS COMUNES
// =========================================================================
class PeriodoGC extends Model
{
    protected $table = 'periodos_gc';

    protected $fillable = [
        'tenant_id',
        'edificio_id',
        'mes',
        'anio',
        'fecha_emision',
        'fecha_vencimiento',
        'estado',
        'total_emitido',
        'total_recaudado',
        'total_pendiente',
    ];

    protected $casts = [
        'fecha_emision' => 'date',
        'fecha_vencimiento' => 'date',
    ];

    public function edificio()
    {
        return $this->belongsTo(Edificio::class);
    }

    public function boletas()
    {
        return $this->hasMany(BoletaGC::class, 'periodo_id');
    }
}

// =========================================================================
// BOLETA GASTOS COMUNES
// =========================================================================
class BoletaGC extends Model
{
    protected $table = 'boletas_gc';

    protected $fillable = [
        'tenant_id',
        'edificio_id',
        'periodo_id',
        'unidad_id',
        'numero_boleta',
        'fecha_emision',
        'fecha_vencimiento',
        'saldo_anterior',
        'total_cargos',
        'total_abonos',
        'total_intereses',
        'total_a_pagar',
        'estado',
        'dias_mora',
    ];

    protected $casts = [
        'fecha_emision' => 'date',
        'fecha_vencimiento' => 'date',
        'fecha_pago' => 'date',
    ];

    public function unidad()
    {
        return $this->belongsTo(Unidad::class);
    }

    public function periodo()
    {
        return $this->belongsTo(PeriodoGC::class, 'periodo_id');
    }

    public function pagos()
    {
        return $this->hasMany(PagoGC::class, 'boleta_id');
    }
}

// =========================================================================
// PAGO GASTOS COMUNES
// =========================================================================
class PagoGC extends Model
{
    use SoftDeletes;

    protected $table = 'pagos_gc';

    protected $fillable = [
        'boleta_id',
        'fecha_pago',
        'monto',
        'medio_pago',
        'numero_comprobante',
        'referencia_externa',
        'observaciones',
    ];

    protected $casts = [
        'fecha_pago' => 'date',
    ];

    public function boleta()
    {
        return $this->belongsTo(BoletaGC::class, 'boleta_id');
    }
}

// =========================================================================
// EMPLEADO
// =========================================================================
class Empleado extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'tenant_id',
        'edificio_id',
        'rut',
        'nombre',
        'apellido_paterno',
        'apellido_materno',
        'nombre_completo',
        'fecha_nacimiento',
        'direccion',
        'telefono',
        'email',
        'cargo',
        'tipo_contrato',
        'fecha_ingreso',
        'fecha_termino',
        'sueldo_base',
        'afp',
        'isapre',
        'estado',
    ];

    protected $casts = [
        'fecha_nacimiento' => 'date',
        'fecha_ingreso' => 'date',
        'fecha_termino' => 'date',
    ];
}

// =========================================================================
// CONTRATO ARRIENDO
// =========================================================================
class ContratoArriendo extends Model
{
    use SoftDeletes;

    protected $table = 'contratos_arriendo';

    protected $fillable = [
        'tenant_id',
        'edificio_id',
        'arrendatario_id',
        'tipo_contrato',
        'descripcion',
        'fecha_inicio',
        'fecha_fin',
        'monto_mensual',
        'moneda',
        'reajuste',
        'estado',
    ];

    protected $casts = [
        'fecha_inicio' => 'date',
        'fecha_fin' => 'date',
    ];
}
