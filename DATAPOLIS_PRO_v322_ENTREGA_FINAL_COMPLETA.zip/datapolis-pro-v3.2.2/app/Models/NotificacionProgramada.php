<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Builder;
use Carbon\Carbon;

/**
 * Modelo NotificacionProgramada
 * 
 * Notificaciones programadas para envío futuro, individual o masivo
 * Soporta filtros para envíos masivos y tracking de procesamiento
 * 
 * @property int $id
 * @property int $edificio_id
 * @property int|null $copropietario_id NULL para masivas
 * @property int $creado_por Usuario que programó
 * @property string $tipo Tipo de notificación
 * @property array $datos Contenido de la notificación
 * @property array $canales Canales a usar [email, push, sms]
 * @property Carbon $fecha_envio Fecha/hora programada
 * @property bool $es_masivo Si es envío a todo el edificio
 * @property array|null $filtros_masivo Filtros para envío masivo
 * @property string $estado pendiente|procesando|completada|fallida|cancelada
 * @property array|null $resultado Resultado del procesamiento
 * @property int|null $cancelada_por Usuario que canceló
 * @property Carbon|null $cancelada_at Fecha de cancelación
 * @property Carbon|null $procesada_at Fecha de procesamiento
 * @property Carbon $created_at
 * @property Carbon $updated_at
 */
class NotificacionProgramada extends Model
{
    use HasFactory;

    protected $table = 'notificaciones_programadas';

    protected $fillable = [
        'edificio_id',
        'copropietario_id',
        'creado_por',
        'tipo',
        'datos',
        'canales',
        'fecha_envio',
        'es_masivo',
        'filtros_masivo',
        'estado',
        'resultado',
        'cancelada_por',
        'cancelada_at',
        'procesada_at',
    ];

    protected $casts = [
        'datos' => 'array',
        'canales' => 'array',
        'fecha_envio' => 'datetime',
        'es_masivo' => 'boolean',
        'filtros_masivo' => 'array',
        'resultado' => 'array',
        'cancelada_at' => 'datetime',
        'procesada_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected $attributes = [
        'estado' => 'pendiente',
        'es_masivo' => false,
    ];

    protected $appends = [
        'esta_pendiente',
        'puede_cancelarse',
        'tiempo_restante',
    ];

    // =========================================================================
    // CONSTANTES
    // =========================================================================

    public const ESTADOS = [
        'pendiente' => ['descripcion' => 'Esperando fecha de envío', 'color' => '#6b7280'],
        'procesando' => ['descripcion' => 'Enviando notificaciones', 'color' => '#2563eb'],
        'completada' => ['descripcion' => 'Envío completado', 'color' => '#059669'],
        'fallida' => ['descripcion' => 'Error en el procesamiento', 'color' => '#dc2626'],
        'cancelada' => ['descripcion' => 'Cancelada por usuario', 'color' => '#9333ea'],
    ];

    /**
     * Minutos mínimos antes de envío para permitir cancelación
     */
    public const MINUTOS_MINIMOS_CANCELACION = 5;

    // =========================================================================
    // RELACIONES
    // =========================================================================

    public function edificio(): BelongsTo
    {
        return $this->belongsTo(Edificio::class, 'edificio_id');
    }

    public function copropietario(): BelongsTo
    {
        return $this->belongsTo(Copropietario::class, 'copropietario_id');
    }

    public function creadoPor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'creado_por');
    }

    public function canceladaPor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'cancelada_por');
    }

    // =========================================================================
    // ACCESSORS
    // =========================================================================

    public function getEstaPendienteAttribute(): bool
    {
        return $this->estado === 'pendiente';
    }

    public function getPuedeCancelarseAttribute(): bool
    {
        if ($this->estado !== 'pendiente') {
            return false;
        }
        return $this->fecha_envio->diffInMinutes(now()) >= self::MINUTOS_MINIMOS_CANCELACION;
    }

    public function getTiempoRestanteAttribute(): ?int
    {
        if ($this->estado !== 'pendiente') {
            return null;
        }
        $minutos = now()->diffInMinutes($this->fecha_envio, false);
        return max(0, $minutos);
    }

    public function getColorEstadoAttribute(): string
    {
        return self::ESTADOS[$this->estado]['color'] ?? '#6b7280';
    }

    public function getDescripcionEstadoAttribute(): string
    {
        return self::ESTADOS[$this->estado]['descripcion'] ?? '';
    }

    public function getAsuntoAttribute(): string
    {
        return $this->datos['asunto'] ?? 'Sin asunto';
    }

    public function getContenidoAttribute(): string
    {
        return $this->datos['contenido'] ?? '';
    }

    public function getDestinatariosEstimadosAttribute(): ?int
    {
        if (!$this->es_masivo) {
            return 1;
        }
        // Estimación basada en filtros (se calcularía dinámicamente)
        return $this->resultado['destinatarios_estimados'] ?? null;
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    public function scopeDeEdificio(Builder $query, int $edificioId): Builder
    {
        return $query->where('edificio_id', $edificioId);
    }

    public function scopeDeCopropietario(Builder $query, int $copropietarioId): Builder
    {
        return $query->where('copropietario_id', $copropietarioId);
    }

    public function scopePendientes(Builder $query): Builder
    {
        return $query->where('estado', 'pendiente');
    }

    public function scopeListasParaProcesar(Builder $query): Builder
    {
        return $query->where('estado', 'pendiente')
            ->where('fecha_envio', '<=', now());
    }

    public function scopeConEstado(Builder $query, string $estado): Builder
    {
        return $query->where('estado', $estado);
    }

    public function scopeMasivas(Builder $query): Builder
    {
        return $query->where('es_masivo', true);
    }

    public function scopeIndividuales(Builder $query): Builder
    {
        return $query->where('es_masivo', false);
    }

    public function scopeProgramadasEntre(Builder $query, Carbon $inicio, Carbon $fin): Builder
    {
        return $query->whereBetween('fecha_envio', [$inicio, $fin]);
    }

    public function scopeProgramadasParaHoy(Builder $query): Builder
    {
        return $query->whereDate('fecha_envio', today());
    }

    public function scopeDelTipo(Builder $query, string $tipo): Builder
    {
        return $query->where('tipo', $tipo);
    }

    public function scopeCreadasPor(Builder $query, int $usuarioId): Builder
    {
        return $query->where('creado_por', $usuarioId);
    }

    // =========================================================================
    // MÉTODOS DE INSTANCIA
    // =========================================================================

    /**
     * Cancelar la notificación programada
     */
    public function cancelar(int $usuarioId): bool
    {
        if (!$this->puede_cancelarse) {
            return false;
        }

        return $this->update([
            'estado' => 'cancelada',
            'cancelada_por' => $usuarioId,
            'cancelada_at' => now(),
        ]);
    }

    /**
     * Marcar como procesando
     */
    public function iniciarProcesamiento(): bool
    {
        if ($this->estado !== 'pendiente') {
            return false;
        }

        return $this->update(['estado' => 'procesando']);
    }

    /**
     * Marcar como completada
     */
    public function completar(array $resultado): bool
    {
        return $this->update([
            'estado' => 'completada',
            'resultado' => $resultado,
            'procesada_at' => now(),
        ]);
    }

    /**
     * Marcar como fallida
     */
    public function fallar(string $error): bool
    {
        return $this->update([
            'estado' => 'fallida',
            'resultado' => ['error' => $error],
            'procesada_at' => now(),
        ]);
    }

    /**
     * Reprogramar para nueva fecha
     */
    public function reprogramar(Carbon $nuevaFecha): bool
    {
        if (!in_array($this->estado, ['pendiente', 'fallida'])) {
            return false;
        }

        return $this->update([
            'fecha_envio' => $nuevaFecha,
            'estado' => 'pendiente',
            'resultado' => null,
            'procesada_at' => null,
        ]);
    }

    /**
     * Obtener resumen para listado
     */
    public function obtenerResumen(): array
    {
        return [
            'id' => $this->id,
            'tipo' => $this->tipo,
            'asunto' => $this->asunto,
            'es_masivo' => $this->es_masivo,
            'canales' => $this->canales,
            'fecha_envio' => $this->fecha_envio->format('Y-m-d H:i'),
            'estado' => $this->estado,
            'color_estado' => $this->color_estado,
            'puede_cancelarse' => $this->puede_cancelarse,
            'tiempo_restante_minutos' => $this->tiempo_restante,
            'destinatarios' => $this->es_masivo ? 'Todo el edificio' : 'Individual',
            'created_at' => $this->created_at->format('Y-m-d H:i'),
        ];
    }

    /**
     * Obtener detalle completo
     */
    public function obtenerDetalle(): array
    {
        return [
            'id' => $this->id,
            'edificio_id' => $this->edificio_id,
            'copropietario_id' => $this->copropietario_id,
            'tipo' => $this->tipo,
            'datos' => $this->datos,
            'canales' => $this->canales,
            'fecha_envio' => $this->fecha_envio->toISOString(),
            'es_masivo' => $this->es_masivo,
            'filtros_masivo' => $this->filtros_masivo,
            'estado' => $this->estado,
            'descripcion_estado' => $this->descripcion_estado,
            'resultado' => $this->resultado,
            'creado_por' => $this->creadoPor?->only(['id', 'name', 'email']),
            'cancelada_por' => $this->canceladaPor?->only(['id', 'name', 'email']),
            'cancelada_at' => $this->cancelada_at?->toISOString(),
            'procesada_at' => $this->procesada_at?->toISOString(),
            'created_at' => $this->created_at->toISOString(),
        ];
    }

    // =========================================================================
    // MÉTODOS ESTÁTICOS
    // =========================================================================

    /**
     * Programar nueva notificación
     */
    public static function programar(array $datos): self
    {
        return self::create([
            'edificio_id' => $datos['edificio_id'],
            'copropietario_id' => $datos['copropietario_id'] ?? null,
            'creado_por' => $datos['creado_por'],
            'tipo' => $datos['tipo'],
            'datos' => [
                'asunto' => $datos['asunto'],
                'contenido' => $datos['contenido'],
                'datos_adicionales' => $datos['datos_adicionales'] ?? [],
            ],
            'canales' => $datos['canales'] ?? ['email'],
            'fecha_envio' => Carbon::parse($datos['fecha_envio']),
            'es_masivo' => $datos['es_masivo'] ?? false,
            'filtros_masivo' => $datos['filtros_masivo'] ?? null,
        ]);
    }

    /**
     * Obtener próximas programadas de un edificio
     */
    public static function proximasDeEdificio(int $edificioId, int $limite = 10): array
    {
        return self::deEdificio($edificioId)
            ->pendientes()
            ->where('fecha_envio', '>', now())
            ->orderBy('fecha_envio')
            ->limit($limite)
            ->get()
            ->map(fn($n) => $n->obtenerResumen())
            ->toArray();
    }

    /**
     * Estadísticas por edificio
     */
    public static function estadisticasEdificio(int $edificioId): array
    {
        $base = self::deEdificio($edificioId);

        $porEstado = (clone $base)
            ->selectRaw('estado, COUNT(*) as cantidad')
            ->groupBy('estado')
            ->pluck('cantidad', 'estado')
            ->toArray();

        $proximaSemana = (clone $base)
            ->pendientes()
            ->whereBetween('fecha_envio', [now(), now()->addWeek()])
            ->count();

        return [
            'por_estado' => $porEstado,
            'pendientes' => $porEstado['pendiente'] ?? 0,
            'proxima_semana' => $proximaSemana,
            'total_completadas' => $porEstado['completada'] ?? 0,
            'total_fallidas' => $porEstado['fallida'] ?? 0,
        ];
    }

    /**
     * Lote de notificaciones listas para procesar
     */
    public static function obtenerLoteParaProcesar(int $limite = 50): \Illuminate\Database\Eloquent\Collection
    {
        return self::listasParaProcesar()
            ->orderBy('fecha_envio')
            ->limit($limite)
            ->get();
    }
}
