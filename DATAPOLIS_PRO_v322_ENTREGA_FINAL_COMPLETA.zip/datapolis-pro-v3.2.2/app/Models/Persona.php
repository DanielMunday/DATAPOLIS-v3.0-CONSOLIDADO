<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Persona extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'tenant_id', 'rut', 'nombre', 'apellido_paterno', 'apellido_materno',
        'nombre_completo', 'email', 'telefono', 'direccion', 'comuna', 'tipo',
    ];

    public function unidades()
    {
        return $this->hasMany(Unidad::class, 'propietario_id');
    }
}
