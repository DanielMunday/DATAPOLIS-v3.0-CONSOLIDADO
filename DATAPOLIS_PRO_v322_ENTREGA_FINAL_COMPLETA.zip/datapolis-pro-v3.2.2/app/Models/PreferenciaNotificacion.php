<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Builder;
use Carbon\Carbon;

/**
 * Modelo PreferenciaNotificacion
 * 
 * Configuración personalizada de preferencias de notificación por copropietario
 * Incluye horarios de silencio, canales preferidos por categoría, idioma
 * 
 * @property int $id
 * @property int $copropietario_id
 * @property array $configuracion Preferencias por categoría y canal
 * @property bool $horario_silencio_activo
 * @property string|null $horario_silencio_desde HH:MM
 * @property string|null $horario_silencio_hasta HH:MM
 * @property string $idioma es|en
 * @property bool $desuscrito_global
 * @property Carbon $created_at
 * @property Carbon $updated_at
 */
class PreferenciaNotificacion extends Model
{
    use HasFactory;

    protected $table = 'preferencias_notificaciones';

    protected $fillable = [
        'copropietario_id',
        'configuracion',
        'horario_silencio_activo',
        'horario_silencio_desde',
        'horario_silencio_hasta',
        'idioma',
        'desuscrito_global',
    ];

    protected $casts = [
        'configuracion' => 'array',
        'horario_silencio_activo' => 'boolean',
        'desuscrito_global' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected $attributes = [
        'idioma' => 'es',
        'horario_silencio_activo' => false,
        'desuscrito_global' => false,
    ];

    // =========================================================================
    // CONSTANTES
    // =========================================================================

    /**
     * Configuración por defecto para nuevos usuarios
     */
    public const CONFIGURACION_DEFAULT = [
        'cobranza' => [
            'email' => true,
            'push' => true,
            'sms' => false,
        ],
        'asamblea' => [
            'email' => true,
            'push' => true,
            'sms' => false,
        ],
        'compliance' => [
            'email' => true,
            'push' => false,
            'sms' => false,
        ],
        'documentos' => [
            'email' => true,
            'push' => false,
            'sms' => false,
        ],
        'mantencion' => [
            'email' => true,
            'push' => true,
            'sms' => false,
        ],
        'sistema' => [
            'email' => true,
            'push' => false,
            'sms' => false,
        ],
    ];

    public const IDIOMAS_SOPORTADOS = ['es', 'en'];

    // =========================================================================
    // RELACIONES
    // =========================================================================

    public function copropietario(): BelongsTo
    {
        return $this->belongsTo(Copropietario::class, 'copropietario_id');
    }

    // =========================================================================
    // ACCESSORS
    // =========================================================================

    /**
     * Obtener configuración con defaults aplicados
     */
    public function getConfiguracionCompletaAttribute(): array
    {
        $config = $this->configuracion ?? [];
        
        foreach (self::CONFIGURACION_DEFAULT as $categoria => $canales) {
            if (!isset($config[$categoria])) {
                $config[$categoria] = $canales;
            } else {
                foreach ($canales as $canal => $valor) {
                    if (!isset($config[$categoria][$canal])) {
                        $config[$categoria][$canal] = $valor;
                    }
                }
            }
        }
        
        return $config;
    }

    /**
     * Verificar si está en horario de silencio ahora
     */
    public function getEnHorarioSilencioAttribute(): bool
    {
        if (!$this->horario_silencio_activo) {
            return false;
        }

        if (!$this->horario_silencio_desde || !$this->horario_silencio_hasta) {
            return false;
        }

        $ahora = now()->format('H:i');
        $desde = $this->horario_silencio_desde;
        $hasta = $this->horario_silencio_hasta;

        // Manejo de horarios que cruzan medianoche
        if ($desde > $hasta) {
            return $ahora >= $desde || $ahora <= $hasta;
        }

        return $ahora >= $desde && $ahora <= $hasta;
    }

    /**
     * Resumen de preferencias activas
     */
    public function getResumenPreferenciasAttribute(): array
    {
        $config = $this->configuracion_completa;
        $resumen = [];

        foreach ($config as $categoria => $canales) {
            $activos = array_filter($canales, fn($v) => $v === true);
            $resumen[$categoria] = array_keys($activos);
        }

        return $resumen;
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    public function scopeDeCopropietario(Builder $query, int $copropietarioId): Builder
    {
        return $query->where('copropietario_id', $copropietarioId);
    }

    public function scopeActivos(Builder $query): Builder
    {
        return $query->where('desuscrito_global', false);
    }

    public function scopeConHorarioSilencio(Builder $query): Builder
    {
        return $query->where('horario_silencio_activo', true);
    }

    public function scopeEnIdioma(Builder $query, string $idioma): Builder
    {
        return $query->where('idioma', $idioma);
    }

    // =========================================================================
    // MÉTODOS DE INSTANCIA
    // =========================================================================

    /**
     * Verificar si un canal está habilitado para una categoría
     */
    public function canalHabilitado(string $categoria, string $canal): bool
    {
        if ($this->desuscrito_global) {
            return false;
        }

        $config = $this->configuracion_completa;
        return $config[$categoria][$canal] ?? false;
    }

    /**
     * Obtener canales habilitados para una categoría
     */
    public function canalesHabilitados(string $categoria): array
    {
        if ($this->desuscrito_global) {
            return [];
        }

        $config = $this->configuracion_completa;
        $canales = $config[$categoria] ?? [];
        
        return array_keys(array_filter($canales, fn($v) => $v === true));
    }

    /**
     * Verificar si puede recibir notificación ahora
     */
    public function puedeRecibirAhora(string $prioridad = 'normal'): bool
    {
        if ($this->desuscrito_global) {
            return false;
        }

        // Las urgentes siempre se envían
        if (in_array($prioridad, ['alta', 'urgente'])) {
            return true;
        }

        return !$this->en_horario_silencio;
    }

    /**
     * Actualizar preferencias de una categoría
     */
    public function actualizarCategoria(string $categoria, array $canales): bool
    {
        $config = $this->configuracion ?? [];
        $config[$categoria] = [
            'email' => $canales['email'] ?? false,
            'push' => $canales['push'] ?? false,
            'sms' => $canales['sms'] ?? false,
        ];

        return $this->update(['configuracion' => $config]);
    }

    /**
     * Activar/desactivar canal globalmente
     */
    public function toggleCanalGlobal(string $canal, bool $activo): bool
    {
        $config = $this->configuracion_completa;

        foreach ($config as $categoria => &$canales) {
            if (isset($canales[$canal])) {
                $canales[$canal] = $activo;
            }
        }

        return $this->update(['configuracion' => $config]);
    }

    /**
     * Configurar horario de silencio
     */
    public function configurarHorarioSilencio(bool $activo, ?string $desde = null, ?string $hasta = null): bool
    {
        return $this->update([
            'horario_silencio_activo' => $activo,
            'horario_silencio_desde' => $activo ? $desde : null,
            'horario_silencio_hasta' => $activo ? $hasta : null,
        ]);
    }

    /**
     * Restaurar configuración por defecto
     */
    public function restaurarDefaults(): bool
    {
        return $this->update([
            'configuracion' => self::CONFIGURACION_DEFAULT,
            'horario_silencio_activo' => false,
            'horario_silencio_desde' => null,
            'horario_silencio_hasta' => null,
            'desuscrito_global' => false,
        ]);
    }

    /**
     * Exportar configuración para API
     */
    public function exportarConfiguracion(): array
    {
        return [
            'copropietario_id' => $this->copropietario_id,
            'categorias' => $this->configuracion_completa,
            'horario_silencio' => [
                'activo' => $this->horario_silencio_activo,
                'desde' => $this->horario_silencio_desde,
                'hasta' => $this->horario_silencio_hasta,
                'en_silencio_ahora' => $this->en_horario_silencio,
            ],
            'idioma' => $this->idioma,
            'desuscrito_global' => $this->desuscrito_global,
            'resumen_activos' => $this->resumen_preferencias,
        ];
    }

    // =========================================================================
    // MÉTODOS ESTÁTICOS
    // =========================================================================

    /**
     * Obtener o crear preferencias para copropietario
     */
    public static function obtenerOCrear(int $copropietarioId): self
    {
        return self::firstOrCreate(
            ['copropietario_id' => $copropietarioId],
            [
                'configuracion' => self::CONFIGURACION_DEFAULT,
                'idioma' => 'es',
            ]
        );
    }

    /**
     * Copropietarios que pueden recibir notificación de una categoría por un canal
     */
    public static function copropietariosParaNotificacion(
        array $copropietarioIds,
        string $categoria,
        string $canal
    ): array {
        $preferencias = self::whereIn('copropietario_id', $copropietarioIds)
            ->activos()
            ->get();

        $elegibles = [];
        foreach ($preferencias as $pref) {
            if ($pref->canalHabilitado($categoria, $canal)) {
                $elegibles[] = $pref->copropietario_id;
            }
        }

        // Incluir copropietarios sin preferencias configuradas (usan defaults)
        $conPreferencias = $preferencias->pluck('copropietario_id')->toArray();
        $sinPreferencias = array_diff($copropietarioIds, $conPreferencias);
        
        // Verificar si el default tiene el canal activo
        if (self::CONFIGURACION_DEFAULT[$categoria][$canal] ?? false) {
            $elegibles = array_merge($elegibles, $sinPreferencias);
        }

        return array_unique($elegibles);
    }
}
