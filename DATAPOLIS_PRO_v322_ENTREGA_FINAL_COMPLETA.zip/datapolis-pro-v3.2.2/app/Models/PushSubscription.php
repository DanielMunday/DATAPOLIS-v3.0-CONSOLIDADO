<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Builder;
use Carbon\Carbon;

/**
 * Modelo PushSubscription
 * 
 * Suscripciones Web Push por dispositivo para cada copropietario
 * Soporta múltiples dispositivos por usuario con tracking de uso y fallos
 * 
 * @property int $id
 * @property int $copropietario_id
 * @property string $endpoint URL del endpoint Push
 * @property string $p256dh Clave pública P-256
 * @property string $auth Token de autenticación
 * @property string|null $dispositivo Identificador del dispositivo
 * @property string|null $user_agent User Agent del navegador
 * @property string|null $ip IP de registro
 * @property bool $activo Estado de la suscripción
 * @property Carbon|null $ultimo_uso Último envío exitoso
 * @property int $fallos_consecutivos Contador de fallos
 * @property Carbon $created_at
 * @property Carbon $updated_at
 */
class PushSubscription extends Model
{
    use HasFactory;

    protected $table = 'push_subscriptions';

    protected $fillable = [
        'copropietario_id',
        'endpoint',
        'p256dh',
        'auth',
        'dispositivo',
        'user_agent',
        'ip',
        'activo',
        'ultimo_uso',
        'fallos_consecutivos',
    ];

    protected $casts = [
        'activo' => 'boolean',
        'ultimo_uso' => 'datetime',
        'fallos_consecutivos' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected $hidden = [
        'p256dh',
        'auth',
    ];

    protected $attributes = [
        'activo' => true,
        'fallos_consecutivos' => 0,
    ];

    // =========================================================================
    // CONSTANTES
    // =========================================================================

    /**
     * Máximo de fallos antes de desactivar automáticamente
     */
    public const MAX_FALLOS_CONSECUTIVOS = 3;

    /**
     * Días sin uso para considerar suscripción inactiva
     */
    public const DIAS_INACTIVIDAD = 90;

    /**
     * Máximo de suscripciones por copropietario
     */
    public const MAX_SUSCRIPCIONES_POR_USUARIO = 5;

    // =========================================================================
    // RELACIONES
    // =========================================================================

    public function copropietario(): BelongsTo
    {
        return $this->belongsTo(Copropietario::class, 'copropietario_id');
    }

    // =========================================================================
    // ACCESSORS
    // =========================================================================

    /**
     * Obtener tipo de navegador del user agent
     */
    public function getNavegadorAttribute(): string
    {
        $ua = $this->user_agent ?? '';

        if (str_contains($ua, 'Chrome')) return 'Chrome';
        if (str_contains($ua, 'Firefox')) return 'Firefox';
        if (str_contains($ua, 'Safari')) return 'Safari';
        if (str_contains($ua, 'Edge')) return 'Edge';
        if (str_contains($ua, 'Opera')) return 'Opera';

        return 'Desconocido';
    }

    /**
     * Obtener tipo de dispositivo
     */
    public function getTipoDispositivoAttribute(): string
    {
        $ua = $this->user_agent ?? '';

        if (str_contains($ua, 'Mobile') || str_contains($ua, 'Android')) return 'Móvil';
        if (str_contains($ua, 'Tablet') || str_contains($ua, 'iPad')) return 'Tablet';

        return 'Escritorio';
    }

    /**
     * Verificar si la suscripción está saludable
     */
    public function getEstaSaludableAttribute(): bool
    {
        return $this->activo && $this->fallos_consecutivos < self::MAX_FALLOS_CONSECUTIVOS;
    }

    /**
     * Verificar si está inactiva por tiempo
     */
    public function getEstaInactivaPorTiempoAttribute(): bool
    {
        if (!$this->ultimo_uso) {
            return $this->created_at->diffInDays(now()) > self::DIAS_INACTIVIDAD;
        }
        return $this->ultimo_uso->diffInDays(now()) > self::DIAS_INACTIVIDAD;
    }

    /**
     * Obtener resumen para listado
     */
    public function getResumenAttribute(): array
    {
        return [
            'id' => $this->id,
            'dispositivo' => $this->dispositivo ?? $this->tipo_dispositivo,
            'navegador' => $this->navegador,
            'tipo' => $this->tipo_dispositivo,
            'activo' => $this->activo,
            'saludable' => $this->esta_saludable,
            'ultimo_uso' => $this->ultimo_uso?->format('Y-m-d H:i'),
            'fallos' => $this->fallos_consecutivos,
            'registrado' => $this->created_at->format('Y-m-d'),
        ];
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    public function scopeDeCopropietario(Builder $query, int $copropietarioId): Builder
    {
        return $query->where('copropietario_id', $copropietarioId);
    }

    public function scopeActivas(Builder $query): Builder
    {
        return $query->where('activo', true);
    }

    public function scopeInactivas(Builder $query): Builder
    {
        return $query->where('activo', false);
    }

    public function scopeSaludables(Builder $query): Builder
    {
        return $query->where('activo', true)
            ->where('fallos_consecutivos', '<', self::MAX_FALLOS_CONSECUTIVOS);
    }

    public function scopeConFallos(Builder $query): Builder
    {
        return $query->where('fallos_consecutivos', '>', 0);
    }

    public function scopeInactivasPorTiempo(Builder $query): Builder
    {
        return $query->where(function ($q) {
            $q->whereNull('ultimo_uso')
                ->where('created_at', '<', now()->subDays(self::DIAS_INACTIVIDAD));
        })->orWhere('ultimo_uso', '<', now()->subDays(self::DIAS_INACTIVIDAD));
    }

    public function scopeConEndpoint(Builder $query, string $endpoint): Builder
    {
        return $query->where('endpoint', $endpoint);
    }

    // =========================================================================
    // MÉTODOS DE INSTANCIA
    // =========================================================================

    /**
     * Obtener datos para WebPush
     */
    public function obtenerDatosWebPush(): array
    {
        return [
            'endpoint' => $this->endpoint,
            'keys' => [
                'p256dh' => $this->p256dh,
                'auth' => $this->auth,
            ],
        ];
    }

    /**
     * Registrar uso exitoso
     */
    public function registrarExito(): bool
    {
        return $this->update([
            'ultimo_uso' => now(),
            'fallos_consecutivos' => 0,
            'activo' => true,
        ]);
    }

    /**
     * Registrar fallo de envío
     */
    public function registrarFallo(): bool
    {
        $nuevosFallos = $this->fallos_consecutivos + 1;
        $desactivar = $nuevosFallos >= self::MAX_FALLOS_CONSECUTIVOS;

        return $this->update([
            'fallos_consecutivos' => $nuevosFallos,
            'activo' => !$desactivar,
        ]);
    }

    /**
     * Desactivar suscripción
     */
    public function desactivar(): bool
    {
        return $this->update(['activo' => false]);
    }

    /**
     * Reactivar suscripción
     */
    public function reactivar(): bool
    {
        return $this->update([
            'activo' => true,
            'fallos_consecutivos' => 0,
        ]);
    }

    /**
     * Actualizar credenciales
     */
    public function actualizarCredenciales(string $p256dh, string $auth): bool
    {
        return $this->update([
            'p256dh' => $p256dh,
            'auth' => $auth,
            'activo' => true,
            'fallos_consecutivos' => 0,
        ]);
    }

    // =========================================================================
    // MÉTODOS ESTÁTICOS
    // =========================================================================

    /**
     * Registrar nueva suscripción
     */
    public static function registrar(
        int $copropietarioId,
        string $endpoint,
        string $p256dh,
        string $auth,
        ?string $dispositivo = null,
        ?string $userAgent = null,
        ?string $ip = null
    ): self {
        // Verificar si ya existe para este endpoint
        $existente = self::deCopropietario($copropietarioId)
            ->conEndpoint($endpoint)
            ->first();

        if ($existente) {
            $existente->actualizarCredenciales($p256dh, $auth);
            $existente->update([
                'dispositivo' => $dispositivo ?? $existente->dispositivo,
                'user_agent' => $userAgent ?? $existente->user_agent,
                'ip' => $ip ?? $existente->ip,
            ]);
            return $existente;
        }

        // Verificar límite de suscripciones
        $cantidad = self::deCopropietario($copropietarioId)->activas()->count();
        if ($cantidad >= self::MAX_SUSCRIPCIONES_POR_USUARIO) {
            // Eliminar la más antigua
            self::deCopropietario($copropietarioId)
                ->activas()
                ->orderBy('created_at')
                ->first()
                ?->delete();
        }

        return self::create([
            'copropietario_id' => $copropietarioId,
            'endpoint' => $endpoint,
            'p256dh' => $p256dh,
            'auth' => $auth,
            'dispositivo' => $dispositivo,
            'user_agent' => $userAgent,
            'ip' => $ip,
        ]);
    }

    /**
     * Eliminar suscripción por endpoint
     */
    public static function eliminarPorEndpoint(int $copropietarioId, string $endpoint): bool
    {
        return self::deCopropietario($copropietarioId)
            ->conEndpoint($endpoint)
            ->delete() > 0;
    }

    /**
     * Obtener todas las suscripciones activas de un copropietario
     */
    public static function obtenerActivasDeCopropietario(int $copropietarioId): array
    {
        return self::deCopropietario($copropietarioId)
            ->saludables()
            ->get()
            ->map(fn($s) => $s->obtenerDatosWebPush())
            ->toArray();
    }

    /**
     * Limpiar suscripciones inactivas
     */
    public static function limpiarInactivas(): int
    {
        return self::inactivasPorTiempo()->delete();
    }

    /**
     * Estadísticas de suscripciones
     */
    public static function estadisticas(): array
    {
        $total = self::count();
        $activas = self::activas()->count();
        $conFallos = self::conFallos()->count();
        $inactivas = self::inactivasPorTiempo()->count();

        $porNavegador = self::selectRaw("
            CASE 
                WHEN user_agent LIKE '%Chrome%' THEN 'Chrome'
                WHEN user_agent LIKE '%Firefox%' THEN 'Firefox'
                WHEN user_agent LIKE '%Safari%' THEN 'Safari'
                WHEN user_agent LIKE '%Edge%' THEN 'Edge'
                ELSE 'Otro'
            END as navegador,
            COUNT(*) as cantidad
        ")
            ->groupBy('navegador')
            ->pluck('cantidad', 'navegador')
            ->toArray();

        return [
            'total' => $total,
            'activas' => $activas,
            'inactivas' => $total - $activas,
            'con_fallos' => $conFallos,
            'por_limpiar' => $inactivas,
            'por_navegador' => $porNavegador,
            'tasa_salud' => $total > 0 ? round(($activas / $total) * 100, 2) : 0,
        ];
    }
}
