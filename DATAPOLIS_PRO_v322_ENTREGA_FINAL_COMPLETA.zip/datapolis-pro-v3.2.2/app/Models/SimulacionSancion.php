<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Builder;
use Carbon\Carbon;

/**
 * Modelo para simulaciones de sanciones tributarias
 * 
 * Almacena cálculos de multas e intereses según Art. 97 Código Tributario
 * con proyecciones y escenarios de regularización
 * 
 * @property int $id
 * @property int $edificio_id
 * @property int $usuario_id
 * @property float $monto_impuesto_original
 * @property string $tipo_infraccion
 * @property Carbon $fecha_vencimiento
 * @property int $meses_atraso
 * @property string $escenario
 * @property float $total_deuda_clp
 * @property float $total_deuda_utm
 * @property float $total_deuda_uf
 * @property float $multa_clp
 * @property float $intereses_clp
 * @property float $reajuste_clp
 * @property array $resultado_completo
 * @property bool $regularizado
 * @property Carbon|null $fecha_regularizacion
 * @property string|null $notas
 * @property Carbon $created_at
 * @property Carbon $updated_at
 */
class SimulacionSancion extends Model
{
    use HasFactory;

    protected $table = 'simulaciones_sanciones';

    protected $fillable = [
        'edificio_id',
        'usuario_id',
        'monto_impuesto_original',
        'tipo_infraccion',
        'fecha_vencimiento',
        'meses_atraso',
        'escenario',
        'total_deuda_clp',
        'total_deuda_utm',
        'total_deuda_uf',
        'multa_clp',
        'intereses_clp',
        'reajuste_clp',
        'resultado_completo',
        'regularizado',
        'fecha_regularizacion',
        'notas',
    ];

    protected $casts = [
        'monto_impuesto_original' => 'decimal:0',
        'total_deuda_clp' => 'decimal:0',
        'total_deuda_utm' => 'decimal:4',
        'total_deuda_uf' => 'decimal:4',
        'multa_clp' => 'decimal:0',
        'intereses_clp' => 'decimal:0',
        'reajuste_clp' => 'decimal:0',
        'meses_atraso' => 'integer',
        'resultado_completo' => 'array',
        'regularizado' => 'boolean',
        'fecha_vencimiento' => 'date',
        'fecha_regularizacion' => 'date',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected $appends = [
        'incremento_porcentual',
        'nivel_riesgo',
        'dias_desde_vencimiento',
    ];

    // =========================================================================
    // CONSTANTES
    // =========================================================================

    // Tipos de infracción según Código Tributario
    public const TIPO_DECLARACION_TARDIA = 'declaracion_tardia';           // Art. 97 N°2
    public const TIPO_NO_DECLARACION = 'no_declaracion';                   // Art. 97 N°2
    public const TIPO_DECLARACION_INCOMPLETA = 'declaracion_incompleta';   // Art. 97 N°3
    public const TIPO_DECLARACION_MALICIOSA = 'declaracion_maliciosa';     // Art. 97 N°4
    public const TIPO_OTROS = 'otros';

    public const TIPOS_INFRACCION = [
        self::TIPO_DECLARACION_TARDIA => [
            'nombre' => 'Declaración Tardía',
            'articulo' => 'Art. 97 N°2',
            'multa_base_utm' => 1,
            'multa_max_utm' => 30,
            'descripcion' => 'Retardo en la presentación de declaraciones',
        ],
        self::TIPO_NO_DECLARACION => [
            'nombre' => 'Omisión de Declaración',
            'articulo' => 'Art. 97 N°2',
            'multa_base_utm' => 1,
            'multa_max_utm' => 30,
            'descripcion' => 'No presentación de declaraciones obligatorias',
        ],
        self::TIPO_DECLARACION_INCOMPLETA => [
            'nombre' => 'Declaración Incompleta',
            'articulo' => 'Art. 97 N°3',
            'multa_porcentaje' => 10,
            'multa_max_porcentaje' => 30,
            'descripcion' => 'Declaración con omisión de datos relevantes',
        ],
        self::TIPO_DECLARACION_MALICIOSA => [
            'nombre' => 'Declaración Maliciosa',
            'articulo' => 'Art. 97 N°4',
            'multa_porcentaje' => 50,
            'multa_max_porcentaje' => 300,
            'descripcion' => 'Declaración fraudulenta o con dolo',
        ],
        self::TIPO_OTROS => [
            'nombre' => 'Otras Infracciones',
            'articulo' => 'Art. 97',
            'descripcion' => 'Otras infracciones tributarias',
        ],
    ];

    // Escenarios de cálculo
    public const ESCENARIO_CONSERVADOR = 'conservador';
    public const ESCENARIO_MODERADO = 'moderado';
    public const ESCENARIO_AGRESIVO = 'agresivo';
    public const ESCENARIO_PEOR_CASO = 'peor_caso';
    public const ESCENARIO_MEJOR_CASO = 'mejor_caso';

    public const ESCENARIOS = [
        self::ESCENARIO_MEJOR_CASO => [
            'nombre' => 'Mejor Caso',
            'factor_multa' => 0.5,
            'descripcion' => 'Regularización voluntaria con atenuantes',
        ],
        self::ESCENARIO_CONSERVADOR => [
            'nombre' => 'Conservador',
            'factor_multa' => 0.75,
            'descripcion' => 'Aplicación moderada de sanciones',
        ],
        self::ESCENARIO_MODERADO => [
            'nombre' => 'Moderado',
            'factor_multa' => 1.0,
            'descripcion' => 'Aplicación estándar de normativa',
        ],
        self::ESCENARIO_AGRESIVO => [
            'nombre' => 'Agresivo',
            'factor_multa' => 1.25,
            'descripcion' => 'Aplicación estricta con agravantes',
        ],
        self::ESCENARIO_PEOR_CASO => [
            'nombre' => 'Peor Caso',
            'factor_multa' => 1.5,
            'descripcion' => 'Máximas sanciones aplicables',
        ],
    ];

    // Niveles de riesgo
    public const RIESGO_BAJO = 'bajo';
    public const RIESGO_MEDIO = 'medio';
    public const RIESGO_ALTO = 'alto';
    public const RIESGO_CRITICO = 'critico';

    // =========================================================================
    // RELACIONES
    // =========================================================================

    public function edificio(): BelongsTo
    {
        return $this->belongsTo(Edificio::class, 'edificio_id');
    }

    public function usuario(): BelongsTo
    {
        return $this->belongsTo(User::class, 'usuario_id');
    }

    // =========================================================================
    // SCOPES
    // =========================================================================

    public function scopeDelEdificio(Builder $query, int $edificioId): Builder
    {
        return $query->where('edificio_id', $edificioId);
    }

    public function scopePorTipoInfraccion(Builder $query, string $tipo): Builder
    {
        return $query->where('tipo_infraccion', $tipo);
    }

    public function scopePorEscenario(Builder $query, string $escenario): Builder
    {
        return $query->where('escenario', $escenario);
    }

    public function scopeNoRegularizados(Builder $query): Builder
    {
        return $query->where('regularizado', false);
    }

    public function scopeRegularizados(Builder $query): Builder
    {
        return $query->where('regularizado', true);
    }

    public function scopeConDeudaSuperiorA(Builder $query, float $monto): Builder
    {
        return $query->where('total_deuda_clp', '>', $monto);
    }

    public function scopeVencidosHaceMasDe(Builder $query, int $meses): Builder
    {
        return $query->where('meses_atraso', '>', $meses);
    }

    public function scopeRecientes(Builder $query, int $dias = 30): Builder
    {
        return $query->where('created_at', '>=', now()->subDays($dias));
    }

    public function scopeRiesgoAlto(Builder $query): Builder
    {
        // Deuda > 50 UTM o > 12 meses atraso
        return $query->where(function ($q) {
            $q->where('total_deuda_utm', '>', 50)
              ->orWhere('meses_atraso', '>', 12);
        });
    }

    // =========================================================================
    // ACCESSORS
    // =========================================================================

    /**
     * Incremento porcentual sobre el impuesto original
     */
    public function getIncrementoPorcentualAttribute(): float
    {
        if ($this->monto_impuesto_original <= 0) {
            return 0;
        }
        
        return round(
            (($this->total_deuda_clp - $this->monto_impuesto_original) / $this->monto_impuesto_original) * 100,
            2
        );
    }

    /**
     * Nivel de riesgo basado en deuda y tiempo
     */
    public function getNivelRiesgoAttribute(): array
    {
        $deudaUtm = $this->total_deuda_utm;
        $mesesAtraso = $this->meses_atraso;
        
        // Matriz de riesgo
        if ($deudaUtm > 100 || $mesesAtraso > 24) {
            $nivel = self::RIESGO_CRITICO;
            $color = 'danger';
            $descripcion = 'Riesgo de acciones legales y cobranza ejecutiva';
        } elseif ($deudaUtm > 50 || $mesesAtraso > 12) {
            $nivel = self::RIESGO_ALTO;
            $color = 'warning';
            $descripcion = 'Alto riesgo de fiscalización intensiva';
        } elseif ($deudaUtm > 20 || $mesesAtraso > 6) {
            $nivel = self::RIESGO_MEDIO;
            $color = 'info';
            $descripcion = 'Riesgo moderado, recomendable regularizar';
        } else {
            $nivel = self::RIESGO_BAJO;
            $color = 'success';
            $descripcion = 'Riesgo controlable';
        }
        
        return [
            'nivel' => $nivel,
            'color' => $color,
            'descripcion' => $descripcion,
            'score' => $this->calcularScoreRiesgo(),
        ];
    }

    /**
     * Días desde vencimiento
     */
    public function getDiasDesdeVencimientoAttribute(): int
    {
        return $this->fecha_vencimiento->diffInDays(now());
    }

    /**
     * Desglose de componentes de la deuda
     */
    public function getDesgloseDeudaAttribute(): array
    {
        return [
            'impuesto_original' => [
                'monto' => $this->monto_impuesto_original,
                'porcentaje' => $this->total_deuda_clp > 0 
                    ? round(($this->monto_impuesto_original / $this->total_deuda_clp) * 100, 1)
                    : 0,
            ],
            'reajuste' => [
                'monto' => $this->reajuste_clp,
                'porcentaje' => $this->total_deuda_clp > 0 
                    ? round(($this->reajuste_clp / $this->total_deuda_clp) * 100, 1)
                    : 0,
            ],
            'intereses' => [
                'monto' => $this->intereses_clp,
                'porcentaje' => $this->total_deuda_clp > 0 
                    ? round(($this->intereses_clp / $this->total_deuda_clp) * 100, 1)
                    : 0,
            ],
            'multa' => [
                'monto' => $this->multa_clp,
                'porcentaje' => $this->total_deuda_clp > 0 
                    ? round(($this->multa_clp / $this->total_deuda_clp) * 100, 1)
                    : 0,
            ],
            'total' => $this->total_deuda_clp,
        ];
    }

    /**
     * Información del tipo de infracción
     */
    public function getInfoTipoInfraccionAttribute(): array
    {
        return self::TIPOS_INFRACCION[$this->tipo_infraccion] ?? self::TIPOS_INFRACCION[self::TIPO_OTROS];
    }

    /**
     * Información del escenario
     */
    public function getInfoEscenarioAttribute(): array
    {
        return self::ESCENARIOS[$this->escenario] ?? self::ESCENARIOS[self::ESCENARIO_MODERADO];
    }

    // =========================================================================
    // MÉTODOS PÚBLICOS
    // =========================================================================

    /**
     * Calcular score de riesgo (0-100)
     */
    public function calcularScoreRiesgo(): int
    {
        $score = 0;
        
        // Por monto en UTM (max 40 puntos)
        if ($this->total_deuda_utm > 100) {
            $score += 40;
        } elseif ($this->total_deuda_utm > 50) {
            $score += 30;
        } elseif ($this->total_deuda_utm > 20) {
            $score += 20;
        } elseif ($this->total_deuda_utm > 10) {
            $score += 10;
        }
        
        // Por meses de atraso (max 40 puntos)
        if ($this->meses_atraso > 24) {
            $score += 40;
        } elseif ($this->meses_atraso > 12) {
            $score += 30;
        } elseif ($this->meses_atraso > 6) {
            $score += 20;
        } elseif ($this->meses_atraso > 3) {
            $score += 10;
        }
        
        // Por tipo de infracción (max 20 puntos)
        $gravedad = [
            self::TIPO_DECLARACION_MALICIOSA => 20,
            self::TIPO_DECLARACION_INCOMPLETA => 15,
            self::TIPO_NO_DECLARACION => 10,
            self::TIPO_DECLARACION_TARDIA => 5,
            self::TIPO_OTROS => 10,
        ];
        $score += $gravedad[$this->tipo_infraccion] ?? 10;
        
        return min(100, $score);
    }

    /**
     * Proyectar deuda a futuro
     */
    public function proyectarDeuda(int $mesesAdicionales, float $tasaInteresMensual = 1.5): array
    {
        $deudaActual = $this->total_deuda_clp;
        $proyeccion = [];
        
        for ($mes = 1; $mes <= $mesesAdicionales; $mes++) {
            $interesesMes = $deudaActual * ($tasaInteresMensual / 100);
            $deudaActual += $interesesMes;
            
            $proyeccion[] = [
                'mes' => $mes,
                'fecha' => now()->addMonths($mes)->format('Y-m'),
                'deuda_acumulada' => round($deudaActual),
                'intereses_mes' => round($interesesMes),
                'incremento_total' => round($deudaActual - $this->total_deuda_clp),
            ];
        }
        
        return [
            'proyeccion_mensual' => $proyeccion,
            'deuda_inicial' => $this->total_deuda_clp,
            'deuda_final' => round($deudaActual),
            'incremento_total' => round($deudaActual - $this->total_deuda_clp),
            'incremento_porcentual' => round((($deudaActual - $this->total_deuda_clp) / $this->total_deuda_clp) * 100, 2),
            'tasa_mensual_aplicada' => $tasaInteresMensual,
        ];
    }

    /**
     * Simular convenio de pago
     */
    public function simularConvenioPago(int $numeroCuotas, float $tasaConvenio = 0): array
    {
        $deudaTotal = $this->total_deuda_clp;
        
        // Si hay tasa de convenio, calcular intereses adicionales
        $interesesConvenio = $deudaTotal * ($tasaConvenio / 100) * ($numeroCuotas / 12);
        $totalAPagar = $deudaTotal + $interesesConvenio;
        $valorCuota = $totalAPagar / $numeroCuotas;
        
        $cuotas = [];
        $saldoPendiente = $totalAPagar;
        
        for ($i = 1; $i <= $numeroCuotas; $i++) {
            $saldoPendiente -= $valorCuota;
            $cuotas[] = [
                'numero' => $i,
                'fecha_vencimiento' => now()->addMonths($i)->format('Y-m-d'),
                'valor' => round($valorCuota),
                'saldo_pendiente' => max(0, round($saldoPendiente)),
            ];
        }
        
        return [
            'deuda_original' => $deudaTotal,
            'intereses_convenio' => round($interesesConvenio),
            'total_a_pagar' => round($totalAPagar),
            'numero_cuotas' => $numeroCuotas,
            'valor_cuota' => round($valorCuota),
            'tasa_convenio' => $tasaConvenio,
            'fecha_primera_cuota' => now()->addMonth()->format('Y-m-d'),
            'fecha_ultima_cuota' => now()->addMonths($numeroCuotas)->format('Y-m-d'),
            'cuotas' => $cuotas,
            'costo_total_adicional' => round($interesesConvenio),
        ];
    }

    /**
     * Marcar como regularizado
     */
    public function marcarComoRegularizado(?string $notas = null): bool
    {
        $this->regularizado = true;
        $this->fecha_regularizacion = now();
        
        if ($notas) {
            $this->notas = ($this->notas ? $this->notas . "\n" : '') . 
                           "[" . now()->format('d/m/Y') . "] " . $notas;
        }
        
        return $this->save();
    }

    /**
     * Calcular ahorro por regularización temprana
     */
    public function calcularAhorroPorRegularizacion(int $mesesFuturos = 6): array
    {
        $proyeccion = $this->proyectarDeuda($mesesFuturos);
        $deudaFutura = $proyeccion['deuda_final'];
        
        return [
            'deuda_actual' => $this->total_deuda_clp,
            'deuda_en_' . $mesesFuturos . '_meses' => $deudaFutura,
            'ahorro_por_regularizar_hoy' => $deudaFutura - $this->total_deuda_clp,
            'porcentaje_ahorro' => round((($deudaFutura - $this->total_deuda_clp) / $this->total_deuda_clp) * 100, 2),
            'mensaje' => "Regularizando hoy se ahorraría $" . number_format($deudaFutura - $this->total_deuda_clp, 0, ',', '.') . " en $mesesFuturos meses",
        ];
    }

    // =========================================================================
    // MÉTODOS ESTÁTICOS
    // =========================================================================

    /**
     * Estadísticas de simulaciones por edificio
     */
    public static function estadisticasPorEdificio(int $edificioId): array
    {
        $query = static::where('edificio_id', $edificioId);
        
        return [
            'total_simulaciones' => $query->count(),
            'deuda_total_simulada' => $query->sum('total_deuda_clp'),
            'promedio_deuda' => round($query->avg('total_deuda_clp') ?? 0),
            'promedio_meses_atraso' => round($query->avg('meses_atraso') ?? 0, 1),
            'regularizados' => $query->clone()->where('regularizado', true)->count(),
            'pendientes' => $query->clone()->where('regularizado', false)->count(),
            'por_tipo_infraccion' => $query->clone()
                ->selectRaw('tipo_infraccion, COUNT(*) as total, SUM(total_deuda_clp) as deuda_total')
                ->groupBy('tipo_infraccion')
                ->get()
                ->keyBy('tipo_infraccion')
                ->toArray(),
            'riesgo_promedio' => static::where('edificio_id', $edificioId)
                ->get()
                ->avg(fn($s) => $s->calcularScoreRiesgo()),
        ];
    }

    /**
     * Obtener simulaciones que requieren atención urgente
     */
    public static function requierenAtencionUrgente(?int $edificioId = null): \Illuminate\Database\Eloquent\Collection
    {
        return static::query()
            ->when($edificioId, fn($q) => $q->where('edificio_id', $edificioId))
            ->where('regularizado', false)
            ->where(function ($q) {
                $q->where('total_deuda_utm', '>', 50)
                  ->orWhere('meses_atraso', '>', 12);
            })
            ->orderByDesc('total_deuda_clp')
            ->get();
    }
}
