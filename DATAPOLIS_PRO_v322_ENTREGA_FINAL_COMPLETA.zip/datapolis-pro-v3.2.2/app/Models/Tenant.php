<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Tenant extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'nombre', 'rut', 'direccion', 'telefono', 'email', 'activo', 'plan', 'max_edificios', 'max_usuarios',
    ];

    protected $casts = ['activo' => 'boolean'];

    public function usuarios()
    {
        return $this->hasMany(User::class);
    }

    public function edificios()
    {
        return $this->hasMany(Edificio::class);
    }
}
