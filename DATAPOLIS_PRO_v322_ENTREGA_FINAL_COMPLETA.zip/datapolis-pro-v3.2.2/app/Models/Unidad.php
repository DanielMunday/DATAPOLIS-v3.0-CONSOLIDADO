<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Unidad extends Model
{
    use SoftDeletes;

    protected $table = 'unidades';

    protected $fillable = [
        'tenant_id', 'edificio_id', 'propietario_id', 'numero', 'tipo', 'piso',
        'superficie_util', 'superficie_terraza', 'prorrateo', 'rol_avaluo', 'activa',
    ];

    protected $casts = [
        'activa' => 'boolean',
        'prorrateo' => 'decimal:4',
        'superficie_util' => 'decimal:2',
    ];

    public function edificio()
    {
        return $this->belongsTo(Edificio::class);
    }

    public function propietario()
    {
        return $this->belongsTo(Persona::class, 'propietario_id');
    }

    public function boletas()
    {
        return $this->hasMany(BoletaGC::class);
    }
}
