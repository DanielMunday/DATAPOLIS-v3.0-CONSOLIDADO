<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\URL;
use Illuminate\Database\Eloquent\Model;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Registrar servicios personalizados
        $this->app->singleton(\App\Services\NotificacionesService::class);
        $this->app->singleton(\App\Services\ComplianceService::class);
        $this->app->singleton(\App\Services\TributarioService::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Forzar HTTPS en producción
        if ($this->app->environment('production')) {
            URL::forceScheme('https');
        }

        // Configuración de Eloquent
        Model::shouldBeStrict(!$this->app->isProduction());
        
        // Prevenir lazy loading en desarrollo
        Model::preventLazyLoading(!$this->app->isProduction());
    }
}
