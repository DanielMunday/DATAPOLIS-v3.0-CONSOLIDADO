<?php

declare(strict_types=1);

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO - Servicio de Certificación de Compliance
 * 
 * Genera certificados de cumplimiento normativo con validez legal
 * Incluye verificación por QR, scoring de compliance y auditoría continua
 * 
 * @author DATAPOLIS
 * @version 3.0
 * @since 2025-12-28
 */
class CertificacionComplianceService
{
    /**
     * Tipos de certificados disponibles
     */
    private const TIPOS_CERTIFICADOS = [
        'COMPLIANCE_INTEGRAL' => [
            'nombre' => 'Certificado de Cumplimiento Integral',
            'descripcion' => 'Certifica cumplimiento de todas las normativas aplicables',
            'validez_meses' => 12,
            'requiere_auditoria' => true,
            'leyes_evaluadas' => ['21.442', '21.713', '21.719', 'Código Tributario']
        ],
        'LEY_21442' => [
            'nombre' => 'Certificado Ley 21.442 Copropiedad',
            'descripcion' => 'Certifica cumplimiento de Ley de Copropiedad Inmobiliaria',
            'validez_meses' => 12,
            'requiere_auditoria' => true,
            'leyes_evaluadas' => ['21.442']
        ],
        'TRIBUTARIO' => [
            'nombre' => 'Certificado de Cumplimiento Tributario',
            'descripcion' => 'Certifica cumplimiento de obligaciones tributarias SII',
            'validez_meses' => 6,
            'requiere_auditoria' => true,
            'leyes_evaluadas' => ['21.713', 'Código Tributario']
        ],
        'PROTECCION_DATOS' => [
            'nombre' => 'Certificado Protección de Datos',
            'descripcion' => 'Certifica cumplimiento de Ley 21.719 de protección de datos',
            'validez_meses' => 12,
            'requiere_auditoria' => true,
            'leyes_evaluadas' => ['21.719']
        ],
        'DISTRIBUCION_RENTAS' => [
            'nombre' => 'Certificado de Distribución de Rentas',
            'descripcion' => 'Certifica correcta distribución Art. 17 N°3 LIR',
            'validez_meses' => 12,
            'requiere_auditoria' => false,
            'leyes_evaluadas' => ['21.713', 'Art. 17 N°3 LIR']
        ],
        'NO_DEUDA' => [
            'nombre' => 'Certificado de No Deuda',
            'descripcion' => 'Certifica que copropietario está al día en sus pagos',
            'validez_meses' => 1,
            'requiere_auditoria' => false,
            'leyes_evaluadas' => []
        ],
        'RENTA_DISTRIBUIDA' => [
            'nombre' => 'Certificado de Renta Distribuida',
            'descripcion' => 'Certifica monto de renta distribuida a copropietario',
            'validez_meses' => 12,
            'requiere_auditoria' => false,
            'leyes_evaluadas' => ['21.713']
        ]
    ];

    /**
     * Criterios de evaluación por módulo
     */
    private const CRITERIOS_EVALUACION = [
        'gobernanza' => [
            'peso' => 20,
            'items' => [
                'reglamento_actualizado' => ['peso' => 30, 'critico' => true],
                'comite_constituido' => ['peso' => 20, 'critico' => true],
                'administrador_registrado' => ['peso' => 25, 'critico' => true],
                'asambleas_regulares' => ['peso' => 15, 'critico' => false],
                'actas_digitalizadas' => ['peso' => 10, 'critico' => false]
            ]
        ],
        'financiero' => [
            'peso' => 25,
            'items' => [
                'fondo_reserva_5pct' => ['peso' => 25, 'critico' => true],
                'contabilidad_al_dia' => ['peso' => 25, 'critico' => true],
                'gastos_comunes_emitidos' => ['peso' => 20, 'critico' => true],
                'morosidad_controlada' => ['peso' => 15, 'critico' => false],
                'presupuesto_aprobado' => ['peso' => 15, 'critico' => false]
            ]
        ],
        'tributario' => [
            'peso' => 30,
            'items' => [
                'declaraciones_f29_al_dia' => ['peso' => 25, 'critico' => true],
                'distribucion_art17n3' => ['peso' => 25, 'critico' => true],
                'certificados_renta_emitidos' => ['peso' => 20, 'critico' => true],
                'dj1887_presentada' => ['peso' => 20, 'critico' => true],
                'libros_contables_actualizados' => ['peso' => 10, 'critico' => false]
            ]
        ],
        'proteccion_datos' => [
            'peso' => 15,
            'items' => [
                'politica_privacidad' => ['peso' => 25, 'critico' => true],
                'consentimientos_registrados' => ['peso' => 25, 'critico' => true],
                'registro_tratamientos' => ['peso' => 20, 'critico' => true],
                'derechos_arco_implementados' => ['peso' => 20, 'critico' => true],
                'seguridad_datos' => ['peso' => 10, 'critico' => false]
            ]
        ],
        'operacional' => [
            'peso' => 10,
            'items' => [
                'contratos_vigentes' => ['peso' => 30, 'critico' => true],
                'seguros_al_dia' => ['peso' => 25, 'critico' => false],
                'mantenciones_programadas' => ['peso' => 25, 'critico' => false],
                'emergencias_documentadas' => ['peso' => 20, 'critico' => false]
            ]
        ]
    ];

    private ReglamentoCopropiedadAnalyzerService $analizadorReglamento;
    private SimuladorSancionesService $simuladorSanciones;

    public function __construct(
        ReglamentoCopropiedadAnalyzerService $analizadorReglamento,
        SimuladorSancionesService $simuladorSanciones
    ) {
        $this->analizadorReglamento = $analizadorReglamento;
        $this->simuladorSanciones = $simuladorSanciones;
    }

    /**
     * Genera certificado de compliance
     *
     * @param int $edificioId ID del edificio
     * @param string $tipoCertificado Tipo de certificado a generar
     * @param array $opciones Opciones adicionales
     * @return array Certificado generado
     */
    public function generarCertificado(int $edificioId, string $tipoCertificado, array $opciones = []): array
    {
        Log::info('Generando certificado de compliance', [
            'edificio_id' => $edificioId,
            'tipo' => $tipoCertificado
        ]);

        // Validar tipo de certificado
        if (!isset(self::TIPOS_CERTIFICADOS[$tipoCertificado])) {
            throw new \InvalidArgumentException("Tipo de certificado no válido: {$tipoCertificado}");
        }

        $configCertificado = self::TIPOS_CERTIFICADOS[$tipoCertificado];
        
        // Obtener datos del edificio
        $edificio = $this->obtenerDatosEdificio($edificioId);
        
        // Realizar evaluación de compliance
        $evaluacion = $this->evaluarCompliance($edificioId, $tipoCertificado);
        
        // Determinar si se puede emitir el certificado
        $puedeEmitir = $this->validarEmision($evaluacion, $tipoCertificado);
        
        if (!$puedeEmitir['aprobado']) {
            return [
                'exito' => false,
                'error' => 'No se puede emitir certificado',
                'motivo' => $puedeEmitir['motivo'],
                'items_pendientes' => $puedeEmitir['items_pendientes'],
                'evaluacion' => $evaluacion,
                'recomendaciones' => $this->generarRecomendacionesMejora($evaluacion)
            ];
        }

        // Generar código único del certificado
        $codigoCertificado = $this->generarCodigoCertificado($edificioId, $tipoCertificado);
        
        // Calcular fecha de vencimiento
        $fechaEmision = Carbon::now();
        $fechaVencimiento = $fechaEmision->copy()->addMonths($configCertificado['validez_meses']);
        
        // Generar hash de verificación
        $hashVerificacion = $this->generarHashVerificacion($edificioId, $codigoCertificado, $fechaEmision);
        
        // Generar URL de verificación pública
        $urlVerificacion = $this->generarUrlVerificacion($codigoCertificado);

        $certificado = [
            'exito' => true,
            'certificado' => [
                'codigo' => $codigoCertificado,
                'tipo' => $tipoCertificado,
                'nombre' => $configCertificado['nombre'],
                'descripcion' => $configCertificado['descripcion'],
                'edificio' => [
                    'id' => $edificioId,
                    'nombre' => $edificio['nombre'],
                    'direccion' => $edificio['direccion'],
                    'rut_comunidad' => $edificio['rut'] ?? 'N/A'
                ],
                'fechas' => [
                    'emision' => $fechaEmision->toIso8601String(),
                    'emision_formato' => $fechaEmision->format('d/m/Y H:i'),
                    'vencimiento' => $fechaVencimiento->toIso8601String(),
                    'vencimiento_formato' => $fechaVencimiento->format('d/m/Y'),
                    'validez_meses' => $configCertificado['validez_meses']
                ],
                'evaluacion' => [
                    'score_global' => $evaluacion['score_global'],
                    'nivel' => $evaluacion['nivel'],
                    'modulos_evaluados' => count($evaluacion['modulos']),
                    'items_cumplidos' => $evaluacion['items_cumplidos'],
                    'items_totales' => $evaluacion['items_totales']
                ],
                'leyes_certificadas' => $configCertificado['leyes_evaluadas'],
                'verificacion' => [
                    'hash' => $hashVerificacion,
                    'url' => $urlVerificacion,
                    'qr_data' => $urlVerificacion
                ],
                'emitido_por' => [
                    'sistema' => 'DATAPOLIS PRO',
                    'version' => '3.0',
                    'timestamp' => time()
                ]
            ],
            'evaluacion_detallada' => $evaluacion,
            'metadata' => [
                'generado_en' => Carbon::now()->toIso8601String(),
                'ip_solicitante' => request()->ip() ?? 'N/A',
                'usuario_id' => auth()->id() ?? null
            ]
        ];

        // Guardar certificado en base de datos
        $this->guardarCertificado($certificado);

        Log::info('Certificado generado exitosamente', [
            'codigo' => $codigoCertificado,
            'edificio_id' => $edificioId
        ]);

        return $certificado;
    }

    /**
     * Evalúa compliance completo del edificio
     */
    public function evaluarCompliance(int $edificioId, string $tipoCertificado = 'COMPLIANCE_INTEGRAL'): array
    {
        $modulos = [];
        $scoreTotal = 0;
        $pesoTotal = 0;
        $itemsCumplidos = 0;
        $itemsTotales = 0;
        $itemsCriticosFallidos = [];

        foreach (self::CRITERIOS_EVALUACION as $modulo => $config) {
            $resultadoModulo = $this->evaluarModulo($edificioId, $modulo, $config);
            $modulos[$modulo] = $resultadoModulo;
            
            $scoreTotal += $resultadoModulo['score'] * $config['peso'];
            $pesoTotal += $config['peso'];
            $itemsCumplidos += $resultadoModulo['items_cumplidos'];
            $itemsTotales += $resultadoModulo['items_totales'];
            
            // Recopilar items críticos fallidos
            foreach ($resultadoModulo['items_criticos_fallidos'] as $item) {
                $itemsCriticosFallidos[] = [
                    'modulo' => $modulo,
                    'item' => $item
                ];
            }
        }

        $scoreGlobal = round($scoreTotal / max($pesoTotal, 1), 2);
        
        $nivel = $this->determinarNivel($scoreGlobal);
        $estado = $this->determinarEstado($scoreGlobal, count($itemsCriticosFallidos));

        return [
            'edificio_id' => $edificioId,
            'tipo_evaluacion' => $tipoCertificado,
            'fecha_evaluacion' => Carbon::now()->toIso8601String(),
            'score_global' => $scoreGlobal,
            'nivel' => $nivel,
            'estado' => $estado,
            'items_cumplidos' => $itemsCumplidos,
            'items_totales' => $itemsTotales,
            'porcentaje_cumplimiento' => round(($itemsCumplidos / max($itemsTotales, 1)) * 100, 2),
            'modulos' => $modulos,
            'items_criticos_fallidos' => $itemsCriticosFallidos,
            'puede_certificar' => $estado === 'APROBADO' && count($itemsCriticosFallidos) === 0,
            'proxima_evaluacion' => Carbon::now()->addMonths(3)->format('Y-m-d')
        ];
    }

    /**
     * Evalúa un módulo específico
     */
    private function evaluarModulo(int $edificioId, string $modulo, array $config): array
    {
        $items = [];
        $scoreModulo = 0;
        $pesoTotal = 0;
        $cumplidos = 0;
        $criticos = 0;
        $criticosFallidos = [];

        foreach ($config['items'] as $item => $itemConfig) {
            $resultado = $this->evaluarItem($edificioId, $modulo, $item);
            
            $items[$item] = [
                'nombre' => $this->nombreItem($item),
                'cumple' => $resultado['cumple'],
                'score' => $resultado['score'],
                'peso' => $itemConfig['peso'],
                'critico' => $itemConfig['critico'],
                'detalle' => $resultado['detalle'],
                'evidencia' => $resultado['evidencia'] ?? null
            ];

            $scoreModulo += $resultado['score'] * $itemConfig['peso'];
            $pesoTotal += $itemConfig['peso'];
            
            if ($resultado['cumple']) {
                $cumplidos++;
            } elseif ($itemConfig['critico']) {
                $criticosFallidos[] = $item;
            }
            
            if ($itemConfig['critico']) {
                $criticos++;
            }
        }

        return [
            'nombre' => $this->nombreModulo($modulo),
            'score' => round($scoreModulo / max($pesoTotal, 1), 2),
            'peso_global' => $config['peso'],
            'items' => $items,
            'items_cumplidos' => $cumplidos,
            'items_totales' => count($config['items']),
            'items_criticos' => $criticos,
            'items_criticos_fallidos' => $criticosFallidos,
            'estado' => count($criticosFallidos) === 0 ? 'OK' : 'PENDIENTE'
        ];
    }

    /**
     * Evalúa un item específico de compliance
     */
    private function evaluarItem(int $edificioId, string $modulo, string $item): array
    {
        // Aquí se implementa la lógica de evaluación real
        // Por ahora, retornamos evaluación simulada que deberá conectarse a los datos reales
        
        return match($item) {
            'reglamento_actualizado' => $this->verificarReglamentoActualizado($edificioId),
            'comite_constituido' => $this->verificarComiteConstituido($edificioId),
            'administrador_registrado' => $this->verificarAdministradorRegistrado($edificioId),
            'fondo_reserva_5pct' => $this->verificarFondoReserva($edificioId),
            'contabilidad_al_dia' => $this->verificarContabilidadAlDia($edificioId),
            'declaraciones_f29_al_dia' => $this->verificarDeclaracionesF29($edificioId),
            'distribucion_art17n3' => $this->verificarDistribucionArt17N3($edificioId),
            'certificados_renta_emitidos' => $this->verificarCertificadosRenta($edificioId),
            'dj1887_presentada' => $this->verificarDJ1887($edificioId),
            'politica_privacidad' => $this->verificarPoliticaPrivacidad($edificioId),
            'consentimientos_registrados' => $this->verificarConsentimientos($edificioId),
            'registro_tratamientos' => $this->verificarRegistroTratamientos($edificioId),
            'derechos_arco_implementados' => $this->verificarDerechosARCO($edificioId),
            default => $this->evaluarItemGenerico($edificioId, $modulo, $item)
        };
    }

    // Métodos de verificación específicos

    private function verificarReglamentoActualizado(int $edificioId): array
    {
        // Verificar si el reglamento está actualizado según Ley 21.442
        try {
            $reglamento = DB::table('reglamentos')
                ->where('edificio_id', $edificioId)
                ->where('vigente', true)
                ->first();

            if (!$reglamento) {
                return [
                    'cumple' => false,
                    'score' => 0,
                    'detalle' => 'No se encontró reglamento vigente registrado'
                ];
            }

            $fechaLey = Carbon::parse('2022-04-01'); // Fecha promulgación Ley 21.442
            $fechaReglamento = Carbon::parse($reglamento->fecha_inscripcion ?? '2020-01-01');

            if ($fechaReglamento->lt($fechaLey)) {
                return [
                    'cumple' => false,
                    'score' => 30,
                    'detalle' => 'Reglamento anterior a Ley 21.442, requiere actualización',
                    'evidencia' => ['fecha_reglamento' => $fechaReglamento->format('Y-m-d')]
                ];
            }

            return [
                'cumple' => true,
                'score' => 100,
                'detalle' => 'Reglamento actualizado conforme a Ley 21.442',
                'evidencia' => ['fecha_inscripcion' => $fechaReglamento->format('Y-m-d')]
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar: ' . $e->getMessage()
            ];
        }
    }

    private function verificarComiteConstituido(int $edificioId): array
    {
        try {
            $comite = DB::table('comites_administracion')
                ->where('edificio_id', $edificioId)
                ->where('vigente', true)
                ->first();

            if (!$comite) {
                return [
                    'cumple' => false,
                    'score' => 0,
                    'detalle' => 'No hay comité de administración constituido'
                ];
            }

            $miembros = DB::table('miembros_comite')
                ->where('comite_id', $comite->id)
                ->where('activo', true)
                ->count();

            if ($miembros < 3) {
                return [
                    'cumple' => false,
                    'score' => 50,
                    'detalle' => "Comité incompleto: {$miembros} miembros (mínimo 3)",
                    'evidencia' => ['miembros_actuales' => $miembros]
                ];
            }

            return [
                'cumple' => true,
                'score' => 100,
                'detalle' => "Comité constituido con {$miembros} miembros",
                'evidencia' => ['miembros' => $miembros]
            ];
        } catch (\Exception $e) {
            // Si no existe la tabla, evaluar como no verificable
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'Información de comité no disponible'
            ];
        }
    }

    private function verificarAdministradorRegistrado(int $edificioId): array
    {
        try {
            $edificio = DB::table('edificios')
                ->where('id', $edificioId)
                ->first();

            if (!$edificio || !$edificio->administrador_id) {
                return [
                    'cumple' => false,
                    'score' => 0,
                    'detalle' => 'No hay administrador asignado'
                ];
            }

            return [
                'cumple' => true,
                'score' => 100,
                'detalle' => 'Administrador registrado correctamente'
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar administrador'
            ];
        }
    }

    private function verificarFondoReserva(int $edificioId): array
    {
        try {
            // Obtener total de gastos comunes del último año
            $gastosAnuales = DB::table('gastos_comunes')
                ->where('edificio_id', $edificioId)
                ->where('fecha', '>=', Carbon::now()->subYear())
                ->sum('monto_total');

            $fondoReservaRequerido = $gastosAnuales * 0.05; // 5%

            // Obtener saldo actual del fondo de reserva
            $fondoActual = DB::table('cuentas_contables')
                ->where('edificio_id', $edificioId)
                ->where('codigo', 'like', '2.1.%') // Pasivos - Fondo Reserva
                ->sum('saldo');

            if ($fondoActual >= $fondoReservaRequerido) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => 'Fondo de reserva cumple con 5% mínimo legal',
                    'evidencia' => [
                        'fondo_actual' => $fondoActual,
                        'minimo_requerido' => $fondoReservaRequerido
                    ]
                ];
            }

            $porcentajeCumplimiento = ($fondoActual / max($fondoReservaRequerido, 1)) * 100;

            return [
                'cumple' => false,
                'score' => round($porcentajeCumplimiento),
                'detalle' => 'Fondo de reserva insuficiente',
                'evidencia' => [
                    'fondo_actual' => $fondoActual,
                    'fondo_requerido' => $fondoReservaRequerido,
                    'deficit' => $fondoReservaRequerido - $fondoActual
                ]
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar fondo de reserva'
            ];
        }
    }

    private function verificarContabilidadAlDia(int $edificioId): array
    {
        try {
            $ultimoAsiento = DB::table('asientos_contables')
                ->where('edificio_id', $edificioId)
                ->orderBy('fecha', 'desc')
                ->first();

            if (!$ultimoAsiento) {
                return [
                    'cumple' => false,
                    'score' => 0,
                    'detalle' => 'No hay registros contables'
                ];
            }

            $fechaUltimo = Carbon::parse($ultimoAsiento->fecha);
            $diasAtraso = $fechaUltimo->diffInDays(Carbon::now());

            if ($diasAtraso <= 30) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => 'Contabilidad al día',
                    'evidencia' => ['ultimo_asiento' => $fechaUltimo->format('Y-m-d')]
                ];
            }

            $score = max(0, 100 - ($diasAtraso - 30) * 2);

            return [
                'cumple' => $diasAtraso <= 60,
                'score' => $score,
                'detalle' => "Contabilidad con {$diasAtraso} días de atraso",
                'evidencia' => ['dias_atraso' => $diasAtraso]
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar estado contable'
            ];
        }
    }

    private function verificarDeclaracionesF29(int $edificioId): array
    {
        try {
            $añoActual = Carbon::now()->year;
            $mesActual = Carbon::now()->month;

            // Verificar declaraciones de los últimos 12 meses
            $declaracionesRequeridas = 12;
            $declaracionesPresentadas = DB::table('declaraciones_tributarias')
                ->where('edificio_id', $edificioId)
                ->where('tipo', 'F29')
                ->where('año', '>=', $añoActual - 1)
                ->where('estado', 'PRESENTADA')
                ->count();

            if ($declaracionesPresentadas >= $declaracionesRequeridas) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => 'Todas las declaraciones F29 presentadas',
                    'evidencia' => ['declaraciones_presentadas' => $declaracionesPresentadas]
                ];
            }

            $score = round(($declaracionesPresentadas / $declaracionesRequeridas) * 100);

            return [
                'cumple' => false,
                'score' => $score,
                'detalle' => "Faltan " . ($declaracionesRequeridas - $declaracionesPresentadas) . " declaraciones F29",
                'evidencia' => [
                    'presentadas' => $declaracionesPresentadas,
                    'requeridas' => $declaracionesRequeridas
                ]
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar declaraciones F29'
            ];
        }
    }

    private function verificarDistribucionArt17N3(int $edificioId): array
    {
        try {
            $añoActual = Carbon::now()->year;

            $distribuciones = DB::table('distribuciones')
                ->where('edificio_id', $edificioId)
                ->where('año', $añoActual - 1) // Año tributario anterior
                ->where('estado', 'APROBADA')
                ->first();

            if (!$distribuciones) {
                return [
                    'cumple' => false,
                    'score' => 0,
                    'detalle' => 'No hay distribución Art. 17 N°3 para el año tributario'
                ];
            }

            return [
                'cumple' => true,
                'score' => 100,
                'detalle' => 'Distribución Art. 17 N°3 realizada correctamente',
                'evidencia' => [
                    'monto_distribuido' => $distribuciones->monto_total ?? 0,
                    'fecha_aprobacion' => $distribuciones->fecha_aprobacion ?? null
                ]
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar distribución Art. 17 N°3'
            ];
        }
    }

    private function verificarCertificadosRenta(int $edificioId): array
    {
        try {
            $añoActual = Carbon::now()->year;

            $unidadesConDistribucion = DB::table('distribucion_detalles')
                ->join('distribuciones', 'distribuciones.id', '=', 'distribucion_detalles.distribucion_id')
                ->where('distribuciones.edificio_id', $edificioId)
                ->where('distribuciones.año', $añoActual - 1)
                ->distinct()
                ->count('distribucion_detalles.unidad_id');

            $certificadosEmitidos = DB::table('certificados_renta')
                ->where('edificio_id', $edificioId)
                ->where('año_tributario', $añoActual - 1)
                ->count();

            if ($certificadosEmitidos >= $unidadesConDistribucion && $unidadesConDistribucion > 0) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => 'Todos los certificados de renta emitidos',
                    'evidencia' => ['certificados' => $certificadosEmitidos]
                ];
            }

            if ($unidadesConDistribucion === 0) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => 'No hay distribuciones que requieran certificados'
                ];
            }

            $score = round(($certificadosEmitidos / $unidadesConDistribucion) * 100);

            return [
                'cumple' => false,
                'score' => $score,
                'detalle' => "Faltan " . ($unidadesConDistribucion - $certificadosEmitidos) . " certificados",
                'evidencia' => [
                    'emitidos' => $certificadosEmitidos,
                    'requeridos' => $unidadesConDistribucion
                ]
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar certificados de renta'
            ];
        }
    }

    private function verificarDJ1887(int $edificioId): array
    {
        try {
            $añoActual = Carbon::now()->year;

            $dj = DB::table('declaraciones_juradas')
                ->where('edificio_id', $edificioId)
                ->where('tipo', '1887')
                ->where('año_tributario', $añoActual - 1)
                ->where('estado', 'PRESENTADA')
                ->first();

            if ($dj) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => 'DJ 1887 presentada correctamente',
                    'evidencia' => ['fecha_presentacion' => $dj->fecha_presentacion ?? null]
                ];
            }

            // Verificar si estamos en plazo
            $fechaLimite = Carbon::parse(($añoActual) . '-03-31'); // 31 marzo

            if (Carbon::now()->lt($fechaLimite)) {
                return [
                    'cumple' => false,
                    'score' => 50,
                    'detalle' => 'DJ 1887 pendiente de presentación (en plazo)',
                    'evidencia' => ['fecha_limite' => $fechaLimite->format('Y-m-d')]
                ];
            }

            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'DJ 1887 no presentada (fuera de plazo)'
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar DJ 1887'
            ];
        }
    }

    private function verificarPoliticaPrivacidad(int $edificioId): array
    {
        try {
            $politica = DB::table('politicas_privacidad')
                ->where('edificio_id', $edificioId)
                ->where('vigente', true)
                ->first();

            if ($politica) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => 'Política de privacidad vigente',
                    'evidencia' => ['fecha_aprobacion' => $politica->fecha_aprobacion ?? null]
                ];
            }

            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No hay política de privacidad definida'
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar política de privacidad'
            ];
        }
    }

    private function verificarConsentimientos(int $edificioId): array
    {
        try {
            $totalPersonas = DB::table('personas')
                ->where('edificio_id', $edificioId)
                ->count();

            $conConsentimiento = DB::table('consentimientos')
                ->join('personas', 'personas.id', '=', 'consentimientos.persona_id')
                ->where('personas.edificio_id', $edificioId)
                ->where('consentimientos.vigente', true)
                ->distinct()
                ->count('consentimientos.persona_id');

            if ($totalPersonas === 0) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => 'No hay personas registradas que requieran consentimiento'
                ];
            }

            $porcentaje = round(($conConsentimiento / $totalPersonas) * 100);

            if ($porcentaje >= 80) {
                return [
                    'cumple' => true,
                    'score' => $porcentaje,
                    'detalle' => "{$porcentaje}% de consentimientos registrados",
                    'evidencia' => ['con_consentimiento' => $conConsentimiento, 'total' => $totalPersonas]
                ];
            }

            return [
                'cumple' => false,
                'score' => $porcentaje,
                'detalle' => "Solo {$porcentaje}% de consentimientos (mínimo 80%)",
                'evidencia' => ['con_consentimiento' => $conConsentimiento, 'total' => $totalPersonas]
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar consentimientos'
            ];
        }
    }

    private function verificarRegistroTratamientos(int $edificioId): array
    {
        try {
            $tratamientos = DB::table('registro_tratamientos')
                ->where('edificio_id', $edificioId)
                ->count();

            if ($tratamientos > 0) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => "{$tratamientos} tratamientos de datos registrados",
                    'evidencia' => ['total_tratamientos' => $tratamientos]
                ];
            }

            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No hay registro de tratamientos de datos'
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar registro de tratamientos'
            ];
        }
    }

    private function verificarDerechosARCO(int $edificioId): array
    {
        // Verificar que exista proceso para atender derechos ARCO+
        try {
            $procedimiento = DB::table('procedimientos_arco')
                ->where('edificio_id', $edificioId)
                ->where('activo', true)
                ->first();

            if ($procedimiento) {
                return [
                    'cumple' => true,
                    'score' => 100,
                    'detalle' => 'Procedimiento ARCO+ implementado'
                ];
            }

            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No hay procedimiento ARCO+ definido'
            ];
        } catch (\Exception $e) {
            return [
                'cumple' => false,
                'score' => 0,
                'detalle' => 'No se pudo verificar procedimiento ARCO+'
            ];
        }
    }

    private function evaluarItemGenerico(int $edificioId, string $modulo, string $item): array
    {
        // Evaluación genérica para items no implementados específicamente
        return [
            'cumple' => false,
            'score' => 0,
            'detalle' => 'Verificación automática no implementada - requiere revisión manual'
        ];
    }

    // Métodos auxiliares

    private function nombreModulo(string $codigo): string
    {
        return match($codigo) {
            'gobernanza' => 'Gobernanza y Administración',
            'financiero' => 'Gestión Financiera',
            'tributario' => 'Cumplimiento Tributario',
            'proteccion_datos' => 'Protección de Datos Personales',
            'operacional' => 'Gestión Operacional',
            default => ucfirst($codigo)
        };
    }

    private function nombreItem(string $codigo): string
    {
        $nombres = [
            'reglamento_actualizado' => 'Reglamento actualizado Ley 21.442',
            'comite_constituido' => 'Comité de Administración constituido',
            'administrador_registrado' => 'Administrador registrado',
            'asambleas_regulares' => 'Asambleas ordinarias realizadas',
            'actas_digitalizadas' => 'Actas digitalizadas',
            'fondo_reserva_5pct' => 'Fondo de Reserva 5%',
            'contabilidad_al_dia' => 'Contabilidad actualizada',
            'gastos_comunes_emitidos' => 'Gastos comunes emitidos',
            'morosidad_controlada' => 'Morosidad bajo control',
            'presupuesto_aprobado' => 'Presupuesto anual aprobado',
            'declaraciones_f29_al_dia' => 'Declaraciones F29 al día',
            'distribucion_art17n3' => 'Distribución Art. 17 N°3 LIR',
            'certificados_renta_emitidos' => 'Certificados de renta emitidos',
            'dj1887_presentada' => 'DJ 1887 presentada',
            'libros_contables_actualizados' => 'Libros contables actualizados',
            'politica_privacidad' => 'Política de privacidad vigente',
            'consentimientos_registrados' => 'Consentimientos registrados',
            'registro_tratamientos' => 'Registro de tratamientos de datos',
            'derechos_arco_implementados' => 'Derechos ARCO+ implementados',
            'seguridad_datos' => 'Medidas de seguridad de datos',
            'contratos_vigentes' => 'Contratos de servicio vigentes',
            'seguros_al_dia' => 'Seguros al día',
            'mantenciones_programadas' => 'Mantenciones programadas',
            'emergencias_documentadas' => 'Procedimientos de emergencia'
        ];

        return $nombres[$codigo] ?? ucwords(str_replace('_', ' ', $codigo));
    }

    private function determinarNivel(float $score): string
    {
        return match(true) {
            $score >= 90 => 'EXCELENTE',
            $score >= 75 => 'BUENO',
            $score >= 60 => 'ACEPTABLE',
            $score >= 40 => 'DEFICIENTE',
            default => 'CRITICO'
        };
    }

    private function determinarEstado(float $score, int $criticosFallidos): string
    {
        if ($criticosFallidos > 0) {
            return 'RECHAZADO';
        }
        
        if ($score >= 70) {
            return 'APROBADO';
        }
        
        if ($score >= 50) {
            return 'CONDICIONAL';
        }
        
        return 'RECHAZADO';
    }

    private function validarEmision(array $evaluacion, string $tipoCertificado): array
    {
        $itemsPendientes = [];
        
        foreach ($evaluacion['items_criticos_fallidos'] as $item) {
            $itemsPendientes[] = $item['item'] ?? $item;
        }
        
        if (count($itemsPendientes) > 0) {
            return [
                'aprobado' => false,
                'motivo' => 'Existen items críticos que no cumplen',
                'items_pendientes' => $itemsPendientes
            ];
        }
        
        if ($evaluacion['score_global'] < 70) {
            return [
                'aprobado' => false,
                'motivo' => 'Score global inferior al mínimo requerido (70%)',
                'items_pendientes' => []
            ];
        }
        
        return [
            'aprobado' => true,
            'motivo' => null,
            'items_pendientes' => []
        ];
    }

    private function generarCodigoCertificado(int $edificioId, string $tipo): string
    {
        $prefijo = match($tipo) {
            'COMPLIANCE_INTEGRAL' => 'CI',
            'LEY_21442' => 'L4',
            'TRIBUTARIO' => 'TR',
            'PROTECCION_DATOS' => 'PD',
            'DISTRIBUCION_RENTAS' => 'DR',
            'NO_DEUDA' => 'ND',
            'RENTA_DISTRIBUIDA' => 'RD',
            default => 'XX'
        };
        
        $año = Carbon::now()->format('Y');
        $random = strtoupper(Str::random(6));
        
        return "{$prefijo}-{$año}-{$edificioId}-{$random}";
    }

    private function generarHashVerificacion(int $edificioId, string $codigo, Carbon $fecha): string
    {
        $datos = "{$edificioId}|{$codigo}|{$fecha->timestamp}|DATAPOLIS";
        return hash('sha256', $datos);
    }

    private function generarUrlVerificacion(string $codigo): string
    {
        $baseUrl = config('app.url', 'https://datapolis.cl');
        return "{$baseUrl}/verificar/{$codigo}";
    }

    private function obtenerDatosEdificio(int $edificioId): array
    {
        try {
            $edificio = DB::table('edificios')->find($edificioId);
            
            return [
                'id' => $edificioId,
                'nombre' => $edificio->nombre ?? 'Edificio #' . $edificioId,
                'direccion' => $edificio->direccion ?? 'Sin dirección',
                'rut' => $edificio->rut ?? null
            ];
        } catch (\Exception $e) {
            return [
                'id' => $edificioId,
                'nombre' => 'Edificio #' . $edificioId,
                'direccion' => 'Sin dirección',
                'rut' => null
            ];
        }
    }

    private function generarRecomendacionesMejora(array $evaluacion): array
    {
        $recomendaciones = [];
        
        foreach ($evaluacion['items_criticos_fallidos'] as $item) {
            $recomendaciones[] = [
                'prioridad' => 'CRITICA',
                'item' => $item['item'] ?? $item,
                'accion' => 'Resolver inmediatamente para poder certificar'
            ];
        }
        
        foreach ($evaluacion['modulos'] as $modulo => $datos) {
            if ($datos['score'] < 70) {
                $recomendaciones[] = [
                    'prioridad' => 'ALTA',
                    'modulo' => $datos['nombre'],
                    'accion' => "Mejorar cumplimiento en {$datos['nombre']} (actual: {$datos['score']}%)"
                ];
            }
        }
        
        return $recomendaciones;
    }

    private function guardarCertificado(array $certificado): void
    {
        try {
            DB::table('certificados_compliance')->insert([
                'codigo' => $certificado['certificado']['codigo'],
                'tipo' => $certificado['certificado']['tipo'],
                'edificio_id' => $certificado['certificado']['edificio']['id'],
                'score' => $certificado['certificado']['evaluacion']['score_global'],
                'nivel' => $certificado['certificado']['evaluacion']['nivel'],
                'fecha_emision' => Carbon::parse($certificado['certificado']['fechas']['emision']),
                'fecha_vencimiento' => Carbon::parse($certificado['certificado']['fechas']['vencimiento']),
                'hash_verificacion' => $certificado['certificado']['verificacion']['hash'],
                'datos_json' => json_encode($certificado),
                'created_at' => now(),
                'updated_at' => now()
            ]);
        } catch (\Exception $e) {
            Log::warning('No se pudo guardar certificado en BD', [
                'error' => $e->getMessage(),
                'codigo' => $certificado['certificado']['codigo']
            ]);
        }
    }

    /**
     * Verifica un certificado por su código
     */
    public function verificarCertificado(string $codigo): array
    {
        try {
            $certificado = DB::table('certificados_compliance')
                ->where('codigo', $codigo)
                ->first();

            if (!$certificado) {
                return [
                    'valido' => false,
                    'motivo' => 'Certificado no encontrado'
                ];
            }

            $vencimiento = Carbon::parse($certificado->fecha_vencimiento);
            
            if ($vencimiento->isPast()) {
                return [
                    'valido' => false,
                    'motivo' => 'Certificado vencido',
                    'fecha_vencimiento' => $vencimiento->format('d/m/Y'),
                    'certificado' => json_decode($certificado->datos_json, true)
                ];
            }

            return [
                'valido' => true,
                'fecha_emision' => Carbon::parse($certificado->fecha_emision)->format('d/m/Y'),
                'fecha_vencimiento' => $vencimiento->format('d/m/Y'),
                'dias_vigencia' => Carbon::now()->diffInDays($vencimiento, false),
                'certificado' => json_decode($certificado->datos_json, true)
            ];
        } catch (\Exception $e) {
            return [
                'valido' => false,
                'motivo' => 'Error al verificar: ' . $e->getMessage()
            ];
        }
    }
}
