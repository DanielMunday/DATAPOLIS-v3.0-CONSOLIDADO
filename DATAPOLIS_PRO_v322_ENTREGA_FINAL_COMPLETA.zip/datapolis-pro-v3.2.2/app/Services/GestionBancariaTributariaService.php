<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO v3.1 - Servicio de Gestión Bancaria y Tributaria
 * 
 * Implementa:
 * - Gestión de cuentas bancarias según Art. 40 Ley 21.442 y Art. 23 DS 7-2025
 * - Traspasos entre cuentas con asientos automáticos
 * - Lógica del Art. 17 N°3 LIR (Ley 21.713) - Determinación de renta/no renta
 * - Conciliación bancaria
 * - Generación de planillas detalladas por copropietario
 */
class GestionBancariaTributariaService
{
    // =========================================================================
    // CONSTANTES LEGALES
    // =========================================================================
    
    /**
     * Según Art. 17 N°3 LIR modificado por Ley 21.713:
     * Los ingresos por arriendos de bienes comunes que se destinen 
     * ÍNTEGRAMENTE a pagar gastos comunes NO constituyen renta.
     */
    const BASE_LEGAL_NO_RENTA = 'Art. 17 N°3 LIR - Ley 21.713';
    
    /**
     * Los REMANENTES (excedentes no usados en GC) SÍ constituyen renta
     * y deben tributar según Art. 42 N°2 LIR
     */
    const BASE_LEGAL_RENTA = 'Art. 42 N°2 LIR';
    
    /**
     * Cuenta corriente exclusiva para GC según Art. 40 Ley 21.442
     */
    const BASE_LEGAL_CUENTA_GC = 'Art. 40 Ley 21.442';
    
    /**
     * Cuenta separada para arriendos según Art. 23 DS 7-2025
     */
    const BASE_LEGAL_CUENTA_ARRIENDOS = 'Art. 23 DS 7-2025';

    // =========================================================================
    // GESTIÓN DE CUENTAS BANCARIAS
    // =========================================================================

    /**
     * Crear cuenta bancaria para la comunidad
     */
    public function crearCuentaBancaria(array $data): array
    {
        $tenantId = Auth::user()->tenant_id;
        
        // Validar que no exista cuenta con mismo propósito
        $existe = DB::table('cuentas_bancarias_comunidad')
            ->where('edificio_id', $data['edificio_id'])
            ->where('proposito', $data['proposito'])
            ->whereNull('deleted_at')
            ->exists();
            
        if ($existe) {
            return [
                'success' => false,
                'message' => "Ya existe una cuenta con propósito '{$data['proposito']}' para este edificio"
            ];
        }
        
        // Determinar base legal según propósito
        $baseLegal = match($data['proposito']) {
            'gastos_comunes' => self::BASE_LEGAL_CUENTA_GC,
            'arriendos' => self::BASE_LEGAL_CUENTA_ARRIENDOS,
            'fondo_reserva' => 'Art. 23 Ley 21.442',
            default => null
        };
        
        // Buscar o crear cuenta contable asociada
        $cuentaContableId = $this->obtenerOCrearCuentaContable($tenantId, $data['edificio_id'], $data['proposito']);
        
        $id = DB::table('cuentas_bancarias_comunidad')->insertGetId([
            'tenant_id' => $tenantId,
            'edificio_id' => $data['edificio_id'],
            'banco_codigo' => $data['banco_codigo'],
            'banco_nombre' => $data['banco_nombre'],
            'tipo_cuenta' => $data['tipo_cuenta'] ?? 'corriente',
            'numero_cuenta' => $data['numero_cuenta'],
            'rut_titular' => $data['rut_titular'],
            'nombre_titular' => $data['nombre_titular'],
            'proposito' => $data['proposito'],
            'base_legal' => $baseLegal,
            'cuenta_contable_id' => $cuentaContableId,
            'saldo_contable' => $data['saldo_inicial'] ?? 0,
            'saldo_banco' => $data['saldo_inicial'] ?? 0,
            'saldo_disponible' => $data['saldo_inicial'] ?? 0,
            'activa' => true,
            'es_principal' => $data['proposito'] === 'gastos_comunes',
            'firmantes' => json_encode($data['firmantes'] ?? []),
            'saldo_minimo_alerta' => $data['saldo_minimo_alerta'] ?? 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        
        return [
            'success' => true,
            'message' => 'Cuenta bancaria creada exitosamente',
            'id' => $id,
            'base_legal' => $baseLegal
        ];
    }

    /**
     * Obtener cuentas bancarias de un edificio
     */
    public function obtenerCuentasBancarias(int $edificioId): array
    {
        $cuentas = DB::table('cuentas_bancarias_comunidad')
            ->where('edificio_id', $edificioId)
            ->whereNull('deleted_at')
            ->orderBy('es_principal', 'desc')
            ->orderBy('proposito')
            ->get();
            
        return $cuentas->toArray();
    }

    /**
     * Obtener cuenta por propósito
     */
    public function obtenerCuentaPorProposito(int $edificioId, string $proposito): ?object
    {
        return DB::table('cuentas_bancarias_comunidad')
            ->where('edificio_id', $edificioId)
            ->where('proposito', $proposito)
            ->where('activa', true)
            ->whereNull('deleted_at')
            ->first();
    }

    // =========================================================================
    // TRASPASOS ENTRE CUENTAS (Art. 17 N°3 LIR)
    // =========================================================================

    /**
     * Crear traspaso de cuenta de arriendos a cuenta de GC
     * Este es el traspaso clave que determina si el ingreso constituye renta o no
     */
    public function crearTraspasoArriendosAGC(array $data): array
    {
        $tenantId = Auth::user()->tenant_id;
        $edificioId = $data['edificio_id'];
        
        // Obtener cuentas
        $cuentaArriendos = $this->obtenerCuentaPorProposito($edificioId, 'arriendos');
        $cuentaGC = $this->obtenerCuentaPorProposito($edificioId, 'gastos_comunes');
        
        if (!$cuentaArriendos || !$cuentaGC) {
            return [
                'success' => false,
                'message' => 'No se encontraron las cuentas bancarias necesarias (arriendos y/o GC)'
            ];
        }
        
        // Validar saldo suficiente
        if ($cuentaArriendos->saldo_disponible < $data['monto']) {
            return [
                'success' => false,
                'message' => 'Saldo insuficiente en cuenta de arriendos',
                'saldo_disponible' => $cuentaArriendos->saldo_disponible,
                'monto_solicitado' => $data['monto']
            ];
        }
        
        // Generar número de traspaso
        $numeroTraspaso = $this->generarNumeroTraspaso($edificioId, 'AGC');
        
        DB::beginTransaction();
        
        try {
            // Crear traspaso
            $traspasoId = DB::table('traspasos_cuentas')->insertGetId([
                'tenant_id' => $tenantId,
                'edificio_id' => $edificioId,
                'numero_traspaso' => $numeroTraspaso,
                'cuenta_origen_id' => $cuentaArriendos->id,
                'cuenta_destino_id' => $cuentaGC->id,
                'fecha' => $data['fecha'] ?? now()->toDateString(),
                'monto' => $data['monto'],
                'concepto' => $data['concepto'] ?? 'Traspaso ingresos arriendos para pago de gastos comunes',
                'tipo' => 'arriendos_a_gc',
                'base_legal' => self::BASE_LEGAL_NO_RENTA,
                'distribucion_id' => $data['distribucion_id'] ?? null,
                'periodo' => $data['periodo'] ?? now()->format('Y-m'),
                'unidad_id' => $data['unidad_id'] ?? null,
                'persona_id' => $data['persona_id'] ?? null,
                'es_pago_gc' => true,
                'constituye_renta' => false,  // Art. 17 N°3 - NO constituye renta
                'monto_no_renta' => $data['monto'],
                'monto_renta' => 0,
                'estado' => 'pendiente',
                'solicitado_por' => Auth::id(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            
            DB::commit();
            
            return [
                'success' => true,
                'message' => 'Traspaso creado. Pendiente de aprobación.',
                'id' => $traspasoId,
                'numero_traspaso' => $numeroTraspaso,
                'base_legal' => self::BASE_LEGAL_NO_RENTA,
                'constituye_renta' => false
            ];
            
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'success' => false,
                'message' => 'Error al crear traspaso: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Crear traspaso de remanente a copropietario
     * Este monto SÍ constituye renta según Art. 17 N°3 inciso 2°
     */
    public function crearTraspasoRemanenteCopropietario(array $data): array
    {
        $tenantId = Auth::user()->tenant_id;
        $edificioId = $data['edificio_id'];
        
        $cuentaArriendos = $this->obtenerCuentaPorProposito($edificioId, 'arriendos');
        
        if (!$cuentaArriendos) {
            return [
                'success' => false,
                'message' => 'No se encontró cuenta de arriendos'
            ];
        }
        
        if ($cuentaArriendos->saldo_disponible < $data['monto']) {
            return [
                'success' => false,
                'message' => 'Saldo insuficiente en cuenta de arriendos'
            ];
        }
        
        $numeroTraspaso = $this->generarNumeroTraspaso($edificioId, 'REM');
        
        DB::beginTransaction();
        
        try {
            // Calcular PPM si corresponde
            $ppm = $this->calcularPPM($data['monto'], $data['persona_id'] ?? null);
            $montoNeto = $data['monto'] - $ppm['monto_retencion'];
            
            $traspasoId = DB::table('traspasos_cuentas')->insertGetId([
                'tenant_id' => $tenantId,
                'edificio_id' => $edificioId,
                'numero_traspaso' => $numeroTraspaso,
                'cuenta_origen_id' => $cuentaArriendos->id,
                'cuenta_destino_id' => null,  // Pago externo
                'fecha' => $data['fecha'] ?? now()->toDateString(),
                'monto' => $data['monto'],
                'concepto' => 'Pago remanente distribución arriendos a copropietario',
                'tipo' => 'arriendos_a_copropietario',
                'base_legal' => self::BASE_LEGAL_RENTA,
                'distribucion_id' => $data['distribucion_id'] ?? null,
                'periodo' => $data['periodo'],
                'unidad_id' => $data['unidad_id'],
                'persona_id' => $data['persona_id'],
                'rut_beneficiario' => $data['rut_beneficiario'],
                'nombre_beneficiario' => $data['nombre_beneficiario'],
                'banco_beneficiario' => $data['banco_beneficiario'] ?? null,
                'cuenta_beneficiario' => $data['cuenta_beneficiario'] ?? null,
                'tipo_cuenta_beneficiario' => $data['tipo_cuenta_beneficiario'] ?? null,
                'es_pago_gc' => false,
                'constituye_renta' => true,  // SÍ constituye renta
                'monto_no_renta' => 0,
                'monto_renta' => $data['monto'],
                'estado' => 'pendiente',
                'solicitado_por' => Auth::id(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            
            // Registrar PPM si aplica
            if ($ppm['monto_retencion'] > 0) {
                DB::table('ppm_retenciones')->insert([
                    'tenant_id' => $tenantId,
                    'edificio_id' => $edificioId,
                    'mes' => Carbon::parse($data['periodo'] . '-01')->month,
                    'anio' => Carbon::parse($data['periodo'] . '-01')->year,
                    'periodo' => $data['periodo'],
                    'tipo' => 'ppm_arriendos',
                    'persona_id' => $data['persona_id'],
                    'rut_retenido' => $data['rut_beneficiario'],
                    'nombre_retenido' => $data['nombre_beneficiario'],
                    'base_imponible' => $data['monto'],
                    'tasa_retencion' => $ppm['tasa'],
                    'monto_retencion' => $ppm['monto_retencion'],
                    'tipo_documento' => 'traspaso',
                    'documento_id' => $traspasoId,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
            
            DB::commit();
            
            return [
                'success' => true,
                'message' => 'Traspaso de remanente creado',
                'id' => $traspasoId,
                'numero_traspaso' => $numeroTraspaso,
                'constituye_renta' => true,
                'base_legal' => self::BASE_LEGAL_RENTA,
                'ppm_retenido' => $ppm['monto_retencion'],
                'monto_neto' => $montoNeto
            ];
            
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Ejecutar traspaso aprobado
     */
    public function ejecutarTraspaso(int $traspasoId): array
    {
        $traspaso = DB::table('traspasos_cuentas')
            ->where('id', $traspasoId)
            ->first();
            
        if (!$traspaso) {
            return ['success' => false, 'message' => 'Traspaso no encontrado'];
        }
        
        if ($traspaso->estado !== 'aprobado') {
            return ['success' => false, 'message' => 'El traspaso debe estar aprobado para ejecutarse'];
        }
        
        DB::beginTransaction();
        
        try {
            // Crear movimiento de cargo (salida) en cuenta origen
            $movimientoOrigenId = DB::table('movimientos_bancarios')->insertGetId([
                'cuenta_bancaria_id' => $traspaso->cuenta_origen_id,
                'fecha' => $traspaso->fecha,
                'tipo' => 'traspaso_interno_salida',
                'numero_documento' => $traspaso->numero_traspaso,
                'descripcion' => $traspaso->concepto,
                'cargo' => $traspaso->monto,
                'abono' => 0,
                'cuenta_contraparte_id' => $traspaso->cuenta_destino_id,
                'traspaso_id' => $traspasoId,
                'estado' => 'procesado',
                'created_at' => now(),
            ]);
            
            // Si hay cuenta destino (traspaso interno), crear abono
            $movimientoDestinoId = null;
            if ($traspaso->cuenta_destino_id) {
                $movimientoDestinoId = DB::table('movimientos_bancarios')->insertGetId([
                    'cuenta_bancaria_id' => $traspaso->cuenta_destino_id,
                    'fecha' => $traspaso->fecha,
                    'tipo' => 'traspaso_interno_entrada',
                    'numero_documento' => $traspaso->numero_traspaso,
                    'descripcion' => $traspaso->concepto,
                    'cargo' => 0,
                    'abono' => $traspaso->monto,
                    'cuenta_contraparte_id' => $traspaso->cuenta_origen_id,
                    'traspaso_id' => $traspasoId,
                    'estado' => 'procesado',
                    'created_at' => now(),
                ]);
            }
            
            // Actualizar saldos de cuentas
            DB::table('cuentas_bancarias_comunidad')
                ->where('id', $traspaso->cuenta_origen_id)
                ->decrement('saldo_contable', $traspaso->monto);
                
            DB::table('cuentas_bancarias_comunidad')
                ->where('id', $traspaso->cuenta_origen_id)
                ->decrement('saldo_disponible', $traspaso->monto);
                
            if ($traspaso->cuenta_destino_id) {
                DB::table('cuentas_bancarias_comunidad')
                    ->where('id', $traspaso->cuenta_destino_id)
                    ->increment('saldo_contable', $traspaso->monto);
                    
                DB::table('cuentas_bancarias_comunidad')
                    ->where('id', $traspaso->cuenta_destino_id)
                    ->increment('saldo_disponible', $traspaso->monto);
            }
            
            // Crear asiento contable automático
            $asientoId = $this->crearAsientoTraspaso($traspaso);
            
            // Actualizar traspaso
            DB::table('traspasos_cuentas')
                ->where('id', $traspasoId)
                ->update([
                    'estado' => 'ejecutado',
                    'movimiento_origen_id' => $movimientoOrigenId,
                    'movimiento_destino_id' => $movimientoDestinoId,
                    'asiento_id' => $asientoId,
                    'ejecutado_por' => Auth::id(),
                    'ejecutado_at' => now(),
                    'updated_at' => now(),
                ]);
            
            DB::commit();
            
            return [
                'success' => true,
                'message' => 'Traspaso ejecutado exitosamente',
                'asiento_id' => $asientoId
            ];
            
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'success' => false,
                'message' => 'Error al ejecutar traspaso: ' . $e->getMessage()
            ];
        }
    }

    // =========================================================================
    // DISTRIBUCIÓN MENSUAL CON LÓGICA ART. 17 N°3
    // =========================================================================

    /**
     * Procesar distribución mensual de arriendos aplicando Art. 17 N°3
     */
    public function procesarDistribucionMensual(int $edificioId, int $mes, int $anio): array
    {
        $tenantId = Auth::user()->tenant_id;
        $periodo = sprintf('%04d-%02d', $anio, $mes);
        
        // Obtener ingresos por arriendos del período
        $ingresosArriendos = DB::table('facturas_arriendo')
            ->join('contratos_arriendo', 'facturas_arriendo.contrato_id', '=', 'contratos_arriendo.id')
            ->where('contratos_arriendo.edificio_id', $edificioId)
            ->where('facturas_arriendo.periodo_mes', $mes)
            ->where('facturas_arriendo.periodo_anio', $anio)
            ->where('facturas_arriendo.estado', 'pagada')
            ->sum('facturas_arriendo.monto_total');
            
        if ($ingresosArriendos <= 0) {
            return [
                'success' => false,
                'message' => 'No hay ingresos por arriendos pagados en el período'
            ];
        }
        
        // Obtener unidades con sus prorrateos
        $unidades = DB::table('unidades')
            ->leftJoin('personas', 'unidades.propietario_id', '=', 'personas.id')
            ->where('unidades.edificio_id', $edificioId)
            ->where('unidades.activa', true)
            ->whereNull('unidades.deleted_at')
            ->select(
                'unidades.id as unidad_id',
                'unidades.numero',
                'unidades.prorrateo',
                'personas.id as persona_id',
                'personas.rut',
                'personas.nombre_completo'
            )
            ->get();
            
        $totalProrrateo = $unidades->sum('prorrateo');
        
        if ($totalProrrateo <= 0) {
            return [
                'success' => false,
                'message' => 'Las unidades no tienen prorrateo configurado'
            ];
        }
        
        DB::beginTransaction();
        
        try {
            $resultados = [];
            
            foreach ($unidades as $unidad) {
                $porcentaje = $unidad->prorrateo / $totalProrrateo;
                $ingresoProporcional = round($ingresosArriendos * $porcentaje, 0);
                
                // Obtener deuda de GC del período
                $deudaGC = DB::table('boletas_gc')
                    ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
                    ->where('boletas_gc.unidad_id', $unidad->unidad_id)
                    ->where('periodos_gc.mes', $mes)
                    ->where('periodos_gc.anio', $anio)
                    ->whereIn('boletas_gc.estado', ['pendiente', 'parcial'])
                    ->sum(DB::raw('boletas_gc.total_a_pagar - COALESCE(boletas_gc.total_pagado, 0)'));
                
                // Calcular traspaso a GC (máximo = deuda o ingreso, lo que sea menor)
                $traspasoAGC = min($ingresoProporcional, $deudaGC);
                
                // Calcular monto Art. 17 N°3 (NO renta)
                $montoNoRenta = $traspasoAGC;
                
                // Calcular remanente (SÍ renta)
                $remanente = $ingresoProporcional - $traspasoAGC;
                
                // Calcular PPM sobre remanente si aplica
                $ppm = 0;
                if ($remanente > 0) {
                    $ppmCalc = $this->calcularPPM($remanente, $unidad->persona_id);
                    $ppm = $ppmCalc['monto_retencion'];
                }
                
                $netoAPagar = $remanente - $ppm;
                
                // Insertar en planilla
                DB::table('planilla_distribucion_arriendos')->updateOrInsert(
                    [
                        'edificio_id' => $edificioId,
                        'unidad_id' => $unidad->unidad_id,
                        'mes' => $mes,
                        'anio' => $anio,
                    ],
                    [
                        'tenant_id' => $tenantId,
                        'periodo' => $periodo,
                        'persona_id' => $unidad->persona_id,
                        'rut_copropietario' => $unidad->rut,
                        'nombre_copropietario' => $unidad->nombre_completo,
                        'numero_unidad' => $unidad->numero,
                        'porcentaje_dominio' => $porcentaje * 100,
                        'ingreso_bruto_arriendos' => $ingresoProporcional,
                        'deuda_gc_periodo' => $deudaGC,
                        'traspaso_a_gc' => $traspasoAGC,
                        'monto_art_17_n3' => $montoNoRenta,
                        'remanente_gravable' => $remanente,
                        'ppm_retenido' => $ppm,
                        'neto_a_pagar' => $netoAPagar,
                        'estado_pago_remanente' => $netoAPagar > 0 ? 'pendiente' : 'no_aplica',
                        'updated_at' => now(),
                    ]
                );
                
                $resultados[] = [
                    'unidad' => $unidad->numero,
                    'copropietario' => $unidad->nombre_completo,
                    'ingreso_bruto' => $ingresoProporcional,
                    'traspaso_gc' => $traspasoAGC,
                    'monto_no_renta' => $montoNoRenta,
                    'remanente_gravable' => $remanente,
                    'ppm' => $ppm,
                    'neto' => $netoAPagar,
                ];
            }
            
            DB::commit();
            
            // Calcular totales
            $totales = [
                'total_ingreso_bruto' => collect($resultados)->sum('ingreso_bruto'),
                'total_traspaso_gc' => collect($resultados)->sum('traspaso_gc'),
                'total_no_renta' => collect($resultados)->sum('monto_no_renta'),
                'total_remanente' => collect($resultados)->sum('remanente_gravable'),
                'total_ppm' => collect($resultados)->sum('ppm'),
                'total_neto' => collect($resultados)->sum('neto'),
            ];
            
            return [
                'success' => true,
                'message' => 'Distribución procesada exitosamente',
                'periodo' => $periodo,
                'ingresos_totales' => $ingresosArriendos,
                'unidades_procesadas' => count($resultados),
                'detalle' => $resultados,
                'totales' => $totales,
                'nota_legal' => 'Montos según Art. 17 N°3 LIR (Ley 21.713): Los traspasos a GC NO constituyen renta. Los remanentes SÍ constituyen renta.'
            ];
            
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ];
        }
    }

    // =========================================================================
    // GENERACIÓN DE CERTIFICADOS Y PLANILLAS
    // =========================================================================

    /**
     * Generar resumen anual por copropietario
     */
    public function generarResumenAnualCopropietario(int $edificioId, int $anio): array
    {
        $tenantId = Auth::user()->tenant_id;
        
        // Obtener planilla mensual del año
        $datosAnuales = DB::table('planilla_distribucion_arriendos')
            ->where('edificio_id', $edificioId)
            ->where('anio', $anio)
            ->select(
                'unidad_id',
                'persona_id',
                'rut_copropietario',
                'nombre_copropietario',
                'numero_unidad',
                DB::raw('AVG(porcentaje_dominio) as porcentaje_dominio'),
                DB::raw('SUM(ingreso_bruto_arriendos) as total_ingreso_bruto'),
                DB::raw('SUM(traspaso_a_gc) as total_traspasado_gc'),
                DB::raw('SUM(monto_art_17_n3) as total_art_17_n3'),
                DB::raw('SUM(remanente_gravable) as total_remanente'),
                DB::raw('SUM(ppm_retenido) as total_ppm'),
                DB::raw('SUM(neto_a_pagar) as total_neto')
            )
            ->groupBy('unidad_id', 'persona_id', 'rut_copropietario', 'nombre_copropietario', 'numero_unidad')
            ->get();
            
        DB::beginTransaction();
        
        try {
            $resumenes = [];
            
            foreach ($datosAnuales as $datos) {
                // Obtener detalle mensual
                $detalleMensual = DB::table('planilla_distribucion_arriendos')
                    ->where('unidad_id', $datos->unidad_id)
                    ->where('anio', $anio)
                    ->orderBy('mes')
                    ->get()
                    ->map(fn($m) => [
                        'mes' => $m->mes,
                        'ingreso' => $m->ingreso_bruto_arriendos,
                        'traspaso_gc' => $m->traspaso_a_gc,
                        'remanente' => $m->remanente_gravable,
                    ])
                    ->toArray();
                    
                // Generar código de verificación
                $codigoVerificacion = strtoupper(substr(md5($datos->rut_copropietario . $anio . time()), 0, 12));
                $numeroCertificado = sprintf('CERT-%s-%04d-%05d', $datos->rut_copropietario, $anio, $datos->unidad_id);
                
                DB::table('resumen_anual_copropietario')->updateOrInsert(
                    [
                        'edificio_id' => $edificioId,
                        'unidad_id' => $datos->unidad_id,
                        'anio' => $anio,
                    ],
                    [
                        'tenant_id' => $tenantId,
                        'persona_id' => $datos->persona_id,
                        'rut_copropietario' => $datos->rut_copropietario,
                        'nombre_copropietario' => $datos->nombre_copropietario,
                        'numero_unidad' => $datos->numero_unidad,
                        'porcentaje_dominio' => $datos->porcentaje_dominio,
                        'total_ingreso_bruto_arriendos' => $datos->total_ingreso_bruto,
                        'total_traspasado_gc' => $datos->total_traspasado_gc,
                        'total_monto_art_17_n3' => $datos->total_art_17_n3,
                        'total_remanente_gravable' => $datos->total_remanente,
                        'total_ppm_retenido' => $datos->total_ppm,
                        'total_neto_pagado' => $datos->total_neto,
                        'detalle_mensual' => json_encode($detalleMensual),
                        'numero_certificado' => $numeroCertificado,
                        'fecha_certificado' => now()->toDateString(),
                        'codigo_verificacion' => $codigoVerificacion,
                        'updated_at' => now(),
                    ]
                );
                
                $resumenes[] = [
                    'unidad' => $datos->numero_unidad,
                    'copropietario' => $datos->nombre_copropietario,
                    'rut' => $datos->rut_copropietario,
                    'total_ingreso_bruto' => $datos->total_ingreso_bruto,
                    'total_no_renta' => $datos->total_art_17_n3,
                    'total_remanente' => $datos->total_remanente,
                    'numero_certificado' => $numeroCertificado,
                    'codigo_verificacion' => $codigoVerificacion,
                ];
            }
            
            DB::commit();
            
            return [
                'success' => true,
                'message' => 'Resumen anual generado',
                'anio' => $anio,
                'total_copropietarios' => count($resumenes),
                'resumenes' => $resumenes,
            ];
            
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Obtener planilla completa para SII
     */
    public function obtenerPlanillaCompletaSII(int $edificioId, int $anio): array
    {
        $edificio = DB::table('edificios')->find($edificioId);
        
        $resumenes = DB::table('resumen_anual_copropietario')
            ->where('edificio_id', $edificioId)
            ->where('anio', $anio)
            ->orderBy('numero_unidad')
            ->get();
            
        $totales = [
            'total_ingreso_bruto' => $resumenes->sum('total_ingreso_bruto_arriendos'),
            'total_traspasado_gc' => $resumenes->sum('total_traspasado_gc'),
            'total_art_17_n3' => $resumenes->sum('total_monto_art_17_n3'),
            'total_remanente' => $resumenes->sum('total_remanente_gravable'),
            'total_ppm' => $resumenes->sum('total_ppm_retenido'),
            'total_neto' => $resumenes->sum('total_neto_pagado'),
        ];
        
        return [
            'edificio' => [
                'nombre' => $edificio->nombre,
                'rut' => $edificio->rut,
                'direccion' => $edificio->direccion,
            ],
            'anio_tributario' => $anio,
            'fecha_generacion' => now()->format('d/m/Y'),
            'cantidad_copropietarios' => $resumenes->count(),
            'detalle' => $resumenes->toArray(),
            'totales' => $totales,
            'notas_legales' => [
                'base_legal' => 'Ley 21.713 - Art. 17 N°3 LIR',
                'no_renta' => 'Los montos traspasados a gastos comunes NO constituyen renta para el copropietario',
                'renta' => 'Los remanentes (excedentes) SÍ constituyen renta y deben declararse en F22',
            ]
        ];
    }

    // =========================================================================
    // CONCILIACIÓN BANCARIA
    // =========================================================================

    /**
     * Iniciar conciliación bancaria del período
     */
    public function iniciarConciliacion(int $cuentaBancariaId, int $mes, int $anio): array
    {
        $tenantId = Auth::user()->tenant_id;
        
        $cuenta = DB::table('cuentas_bancarias_comunidad')
            ->where('id', $cuentaBancariaId)
            ->first();
            
        if (!$cuenta) {
            return ['success' => false, 'message' => 'Cuenta no encontrada'];
        }
        
        // Calcular fechas del período
        $fechaInicio = Carbon::create($anio, $mes, 1)->startOfMonth();
        $fechaCierre = Carbon::create($anio, $mes, 1)->endOfMonth();
        
        // Obtener saldo inicial (saldo al cierre del mes anterior)
        $conciliacionAnterior = DB::table('conciliaciones_bancarias')
            ->where('cuenta_bancaria_id', $cuentaBancariaId)
            ->where(function($q) use ($mes, $anio) {
                $q->where('anio', '<', $anio)
                  ->orWhere(function($q2) use ($mes, $anio) {
                      $q2->where('anio', $anio)->where('mes', '<', $mes);
                  });
            })
            ->orderByDesc('anio')
            ->orderByDesc('mes')
            ->first();
            
        $saldoInicialLibro = $conciliacionAnterior ? $conciliacionAnterior->saldo_final_libro : 0;
        $saldoInicialBanco = $conciliacionAnterior ? $conciliacionAnterior->saldo_final_banco : 0;
        
        // Calcular movimientos del período
        $movimientos = DB::table('movimientos_bancarios')
            ->where('cuenta_bancaria_id', $cuentaBancariaId)
            ->whereBetween('fecha', [$fechaInicio, $fechaCierre])
            ->where('estado', '!=', 'anulado')
            ->selectRaw('
                SUM(cargo) as total_cargos,
                SUM(abono) as total_abonos
            ')
            ->first();
            
        $saldoFinalLibro = $saldoInicialLibro - ($movimientos->total_cargos ?? 0) + ($movimientos->total_abonos ?? 0);
        
        // Crear o actualizar conciliación
        $id = DB::table('conciliaciones_bancarias')->updateOrInsert(
            [
                'cuenta_bancaria_id' => $cuentaBancariaId,
                'mes' => $mes,
                'anio' => $anio,
            ],
            [
                'tenant_id' => $tenantId,
                'fecha_inicio' => $fechaInicio,
                'fecha_cierre' => $fechaCierre,
                'saldo_inicial_libro' => $saldoInicialLibro,
                'saldo_inicial_banco' => $saldoInicialBanco,
                'saldo_final_libro' => $saldoFinalLibro,
                'total_cargos_libro' => $movimientos->total_cargos ?? 0,
                'total_abonos_libro' => $movimientos->total_abonos ?? 0,
                'estado' => 'en_proceso',
                'elaborada_por' => Auth::id(),
                'updated_at' => now(),
            ]
        );
        
        return [
            'success' => true,
            'message' => 'Conciliación iniciada',
            'periodo' => sprintf('%04d-%02d', $anio, $mes),
            'saldo_inicial_libro' => $saldoInicialLibro,
            'saldo_final_libro' => $saldoFinalLibro,
        ];
    }

    // =========================================================================
    // MÉTODOS AUXILIARES
    // =========================================================================

    /**
     * Calcular PPM según normativa
     */
    private function calcularPPM(float $monto, ?int $personaId): array
    {
        // Simplificación: Para arriendos de personas naturales no hay PPM obligatorio
        // salvo que el arrendador sea empresa o persona con inicio de actividades
        // Este es un cálculo simplificado
        
        $tasa = 0; // Por defecto sin retención
        
        // Aquí se podría implementar lógica más compleja según el tipo de contribuyente
        
        return [
            'base_imponible' => $monto,
            'tasa' => $tasa,
            'monto_retencion' => round($monto * ($tasa / 100), 0),
        ];
    }

    /**
     * Generar número de traspaso
     */
    private function generarNumeroTraspaso(int $edificioId, string $prefijo): string
    {
        $ultimoNumero = DB::table('traspasos_cuentas')
            ->where('edificio_id', $edificioId)
            ->whereYear('created_at', now()->year)
            ->max(DB::raw("CAST(SUBSTRING(numero_traspaso, -5) AS UNSIGNED)"));
            
        $siguiente = ($ultimoNumero ?? 0) + 1;
        
        return sprintf('TRF-%s-%04d-%05d', $prefijo, now()->year, $siguiente);
    }

    /**
     * Obtener o crear cuenta contable para banco
     */
    private function obtenerOCrearCuentaContable(int $tenantId, int $edificioId, string $proposito): ?int
    {
        $codigoCuenta = match($proposito) {
            'gastos_comunes' => '1.1.2.1',
            'arriendos' => '1.1.2.2',
            'fondo_reserva' => '1.1.2.3',
            'operacional' => '1.1.2.4',
            'inversiones' => '1.1.2.5',
            'remuneraciones' => '1.1.2.6',
            default => '1.1.2.9'
        };
        
        $nombre = match($proposito) {
            'gastos_comunes' => 'Banco Cuenta Gastos Comunes',
            'arriendos' => 'Banco Cuenta Arriendos',
            'fondo_reserva' => 'Banco Fondo de Reserva',
            'operacional' => 'Banco Cuenta Operacional',
            'inversiones' => 'Banco Inversiones',
            'remuneraciones' => 'Banco Remuneraciones',
            default => 'Banco Otros'
        };
        
        $cuenta = DB::table('plan_cuentas')
            ->where('tenant_id', $tenantId)
            ->where('codigo', $codigoCuenta)
            ->first();
            
        if ($cuenta) {
            return $cuenta->id;
        }
        
        // Crear cuenta si no existe
        return DB::table('plan_cuentas')->insertGetId([
            'tenant_id' => $tenantId,
            'codigo' => $codigoCuenta,
            'nombre' => $nombre,
            'tipo' => 'activo',
            'naturaleza' => 'deudora',
            'nivel' => 4,
            'permite_movimientos' => true,
            'activa' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    /**
     * Crear asiento contable para traspaso
     */
    private function crearAsientoTraspaso(object $traspaso): int
    {
        $cuentaOrigen = DB::table('cuentas_bancarias_comunidad')
            ->where('id', $traspaso->cuenta_origen_id)
            ->first();
            
        $cuentaDestino = $traspaso->cuenta_destino_id 
            ? DB::table('cuentas_bancarias_comunidad')->where('id', $traspaso->cuenta_destino_id)->first()
            : null;
        
        // Generar número de asiento
        $ultimoNumero = DB::table('asientos')
            ->where('edificio_id', $traspaso->edificio_id)
            ->whereYear('fecha', Carbon::parse($traspaso->fecha)->year)
            ->max('numero');
            
        $numero = str_pad(($ultimoNumero ? intval($ultimoNumero) + 1 : 1), 6, '0', STR_PAD_LEFT);
        
        $asientoId = DB::table('asientos')->insertGetId([
            'tenant_id' => $traspaso->tenant_id,
            'edificio_id' => $traspaso->edificio_id,
            'numero' => $numero,
            'fecha' => $traspaso->fecha,
            'tipo' => 'traspaso',
            'glosa' => "Traspaso {$traspaso->numero_traspaso}: {$traspaso->concepto}",
            'total_debe' => $traspaso->monto,
            'total_haber' => $traspaso->monto,
            'estado' => 'contabilizado',
            'es_automatico' => true,
            'origen_modulo' => 'traspasos',
            'origen_id' => $traspaso->id,
            'creado_por' => Auth::id(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        
        // Línea de cargo (cuenta origen)
        DB::table('asiento_lineas')->insert([
            'asiento_id' => $asientoId,
            'cuenta_id' => $cuentaDestino ? $cuentaDestino->cuenta_contable_id : $this->obtenerCuentaGastosPorPagar($traspaso->tenant_id),
            'glosa' => $traspaso->concepto,
            'debe' => $traspaso->monto,
            'haber' => 0,
            'created_at' => now(),
        ]);
        
        // Línea de abono (cuenta origen)
        DB::table('asiento_lineas')->insert([
            'asiento_id' => $asientoId,
            'cuenta_id' => $cuentaOrigen->cuenta_contable_id,
            'glosa' => $traspaso->concepto,
            'debe' => 0,
            'haber' => $traspaso->monto,
            'created_at' => now(),
        ]);
        
        return $asientoId;
    }

    /**
     * Obtener cuenta de gastos por pagar (para traspasos externos)
     */
    private function obtenerCuentaGastosPorPagar(int $tenantId): int
    {
        $cuenta = DB::table('plan_cuentas')
            ->where('tenant_id', $tenantId)
            ->where('codigo', 'like', '2.1.%')
            ->where('nombre', 'like', '%por pagar%')
            ->first();
            
        return $cuenta ? $cuenta->id : 1;
    }
}
