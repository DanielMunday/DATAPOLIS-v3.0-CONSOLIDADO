<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

/**
 * DATAPOLIS PRO v3.1 - Servicio de Importación de Cartolas Bancarias
 * 
 * Soporta formatos de los principales bancos chilenos:
 * - Banco de Chile
 * - BancoEstado
 * - Santander
 * - BCI
 * - Scotiabank
 * - Itaú
 * - BICE
 * - Security
 * 
 * Formatos soportados: CSV, XLS, XLSX
 */
class ImportadorCartolasService
{
    // =========================================================================
    // CONFIGURACIÓN DE FORMATOS POR BANCO
    // =========================================================================
    
    /**
     * Configuración de columnas por banco
     * Cada banco tiene su propio formato de exportación de cartolas
     */
    protected array $formatosBancos = [
        'banco_chile' => [
            'nombre' => 'Banco de Chile',
            'codigo' => 'BCHI',
            'separador_csv' => ';',
            'encoding' => 'ISO-8859-1',
            'fila_inicio' => 1,  // 0-indexed, primera fila con datos
            'columnas' => [
                'fecha' => 0,           // Columna A
                'descripcion' => 1,     // Columna B
                'numero_documento' => 2, // Columna C
                'cargo' => 3,           // Columna D
                'abono' => 4,           // Columna E
                'saldo' => 5,           // Columna F
            ],
            'formato_fecha' => 'd/m/Y',
            'formato_monto' => 'punto_miles',  // 1.234.567
        ],
        'banco_estado' => [
            'nombre' => 'BancoEstado',
            'codigo' => 'BICE',
            'separador_csv' => ';',
            'encoding' => 'UTF-8',
            'fila_inicio' => 2,
            'columnas' => [
                'fecha' => 0,
                'descripcion' => 2,
                'numero_documento' => 1,
                'cargo' => 3,
                'abono' => 4,
                'saldo' => 5,
            ],
            'formato_fecha' => 'd-m-Y',
            'formato_monto' => 'punto_miles',
        ],
        'santander' => [
            'nombre' => 'Banco Santander',
            'codigo' => 'BSAN',
            'separador_csv' => ';',
            'encoding' => 'ISO-8859-1',
            'fila_inicio' => 1,
            'columnas' => [
                'fecha' => 0,
                'fecha_valor' => 1,
                'descripcion' => 2,
                'numero_documento' => 3,
                'cargo' => 4,
                'abono' => 5,
                'saldo' => 6,
            ],
            'formato_fecha' => 'd/m/Y',
            'formato_monto' => 'punto_miles',
        ],
        'bci' => [
            'nombre' => 'Banco de Crédito e Inversiones',
            'codigo' => 'BBCI',
            'separador_csv' => ',',
            'encoding' => 'UTF-8',
            'fila_inicio' => 1,
            'columnas' => [
                'fecha' => 0,
                'descripcion' => 1,
                'numero_documento' => 2,
                'cargo' => 3,
                'abono' => 4,
                'saldo' => 5,
            ],
            'formato_fecha' => 'Y-m-d',
            'formato_monto' => 'decimal',  // 1234567.00
        ],
        'scotiabank' => [
            'nombre' => 'Scotiabank Chile',
            'codigo' => 'SCOT',
            'separador_csv' => ';',
            'encoding' => 'UTF-8',
            'fila_inicio' => 3,
            'columnas' => [
                'fecha' => 0,
                'descripcion' => 1,
                'numero_documento' => 2,
                'cargo' => 4,
                'abono' => 3,
                'saldo' => 5,
            ],
            'formato_fecha' => 'd/m/Y',
            'formato_monto' => 'punto_miles',
        ],
        'itau' => [
            'nombre' => 'Banco Itaú Chile',
            'codigo' => 'ITAU',
            'separador_csv' => ';',
            'encoding' => 'UTF-8',
            'fila_inicio' => 1,
            'columnas' => [
                'fecha' => 0,
                'descripcion' => 1,
                'numero_documento' => 2,
                'cargo' => 3,
                'abono' => 4,
                'saldo' => 5,
            ],
            'formato_fecha' => 'd/m/Y',
            'formato_monto' => 'punto_miles',
        ],
        'bice' => [
            'nombre' => 'Banco BICE',
            'codigo' => 'BICE',
            'separador_csv' => ';',
            'encoding' => 'UTF-8',
            'fila_inicio' => 2,
            'columnas' => [
                'fecha' => 0,
                'descripcion' => 2,
                'numero_documento' => 1,
                'cargo' => 3,
                'abono' => 4,
                'saldo' => 5,
            ],
            'formato_fecha' => 'd-m-Y',
            'formato_monto' => 'punto_miles',
        ],
        'security' => [
            'nombre' => 'Banco Security',
            'codigo' => 'SECU',
            'separador_csv' => ';',
            'encoding' => 'ISO-8859-1',
            'fila_inicio' => 1,
            'columnas' => [
                'fecha' => 0,
                'descripcion' => 1,
                'numero_documento' => 2,
                'cargo' => 3,
                'abono' => 4,
                'saldo' => 5,
            ],
            'formato_fecha' => 'd/m/Y',
            'formato_monto' => 'punto_miles',
        ],
        'generico' => [
            'nombre' => 'Formato Genérico',
            'codigo' => 'GENE',
            'separador_csv' => ';',
            'encoding' => 'UTF-8',
            'fila_inicio' => 1,
            'columnas' => [
                'fecha' => 0,
                'descripcion' => 1,
                'numero_documento' => 2,
                'cargo' => 3,
                'abono' => 4,
                'saldo' => 5,
            ],
            'formato_fecha' => 'd/m/Y',
            'formato_monto' => 'punto_miles',
        ],
    ];

    // =========================================================================
    // MÉTODOS PRINCIPALES
    // =========================================================================

    /**
     * Obtener bancos soportados
     */
    public function getBancosSoportados(): array
    {
        $bancos = [];
        foreach ($this->formatosBancos as $codigo => $config) {
            $bancos[] = [
                'codigo' => $codigo,
                'nombre' => $config['nombre'],
                'codigo_swift' => $config['codigo'],
            ];
        }
        return $bancos;
    }

    /**
     * Importar cartola desde archivo
     */
    public function importarCartola(
        int $cuentaBancariaId,
        string $rutaArchivo,
        string $bancoFormato,
        array $opciones = []
    ): array {
        // Validar cuenta bancaria
        $cuenta = DB::table('cuentas_bancarias_comunidad')
            ->where('id', $cuentaBancariaId)
            ->first();

        if (!$cuenta) {
            return ['success' => false, 'message' => 'Cuenta bancaria no encontrada'];
        }

        // Validar formato de banco
        if (!isset($this->formatosBancos[$bancoFormato])) {
            return ['success' => false, 'message' => 'Formato de banco no soportado'];
        }

        $config = $this->formatosBancos[$bancoFormato];

        // Detectar tipo de archivo
        $extension = strtolower(pathinfo($rutaArchivo, PATHINFO_EXTENSION));

        try {
            // Leer datos según tipo de archivo
            if ($extension === 'csv') {
                $datos = $this->leerCSV($rutaArchivo, $config);
            } elseif (in_array($extension, ['xls', 'xlsx'])) {
                $datos = $this->leerExcel($rutaArchivo, $config);
            } else {
                return ['success' => false, 'message' => 'Formato de archivo no soportado. Use CSV, XLS o XLSX'];
            }

            if (empty($datos)) {
                return ['success' => false, 'message' => 'No se encontraron datos en el archivo'];
            }

            // Procesar e insertar movimientos
            $resultado = $this->procesarMovimientos($cuentaBancariaId, $datos, $config, $opciones);

            // Guardar referencia del archivo
            $archivoNombre = basename($rutaArchivo);
            DB::table('cuentas_bancarias_comunidad')
                ->where('id', $cuentaBancariaId)
                ->update([
                    'fecha_ultimo_movimiento' => now()->toDateString(),
                    'updated_at' => now(),
                ]);

            return [
                'success' => true,
                'message' => 'Cartola importada exitosamente',
                'archivo' => $archivoNombre,
                'banco' => $config['nombre'],
                'movimientos_leidos' => count($datos),
                'movimientos_importados' => $resultado['importados'],
                'movimientos_duplicados' => $resultado['duplicados'],
                'movimientos_errores' => $resultado['errores'],
                'detalle_errores' => $resultado['detalle_errores'] ?? [],
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al procesar archivo: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Vista previa de importación (sin guardar)
     */
    public function previsualizarCartola(
        string $rutaArchivo,
        string $bancoFormato,
        int $lineas = 10
    ): array {
        if (!isset($this->formatosBancos[$bancoFormato])) {
            return ['success' => false, 'message' => 'Formato de banco no soportado'];
        }

        $config = $this->formatosBancos[$bancoFormato];
        $extension = strtolower(pathinfo($rutaArchivo, PATHINFO_EXTENSION));

        try {
            if ($extension === 'csv') {
                $datos = $this->leerCSV($rutaArchivo, $config, $lineas);
            } else {
                $datos = $this->leerExcel($rutaArchivo, $config, $lineas);
            }

            return [
                'success' => true,
                'banco' => $config['nombre'],
                'total_lineas' => count($datos),
                'preview' => array_slice($datos, 0, $lineas),
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Error al leer archivo: ' . $e->getMessage(),
            ];
        }
    }

    // =========================================================================
    // LECTORES DE ARCHIVOS
    // =========================================================================

    /**
     * Leer archivo CSV
     */
    protected function leerCSV(string $ruta, array $config, ?int $limite = null): array
    {
        $datos = [];
        $separador = $config['separador_csv'];
        $encoding = $config['encoding'];
        $filaInicio = $config['fila_inicio'];
        $columnas = $config['columnas'];

        // Leer archivo
        $contenido = file_get_contents($ruta);

        // Convertir encoding si es necesario
        if ($encoding !== 'UTF-8') {
            $contenido = mb_convert_encoding($contenido, 'UTF-8', $encoding);
        }

        // Parsear líneas
        $lineas = explode("\n", $contenido);
        $filaActual = 0;
        $contadorDatos = 0;

        foreach ($lineas as $linea) {
            $linea = trim($linea);
            if (empty($linea)) continue;

            // Saltar encabezados
            if ($filaActual < $filaInicio) {
                $filaActual++;
                continue;
            }

            // Parsear columnas
            $campos = str_getcsv($linea, $separador);

            // Validar que tenga suficientes columnas
            $maxColumna = max(array_values($columnas));
            if (count($campos) <= $maxColumna) {
                $filaActual++;
                continue;
            }

            // Extraer datos
            $registro = $this->extraerRegistro($campos, $columnas, $config, $filaActual + 1);
            if ($registro) {
                $datos[] = $registro;
                $contadorDatos++;

                if ($limite && $contadorDatos >= $limite) {
                    break;
                }
            }

            $filaActual++;
        }

        return $datos;
    }

    /**
     * Leer archivo Excel (XLS/XLSX)
     */
    protected function leerExcel(string $ruta, array $config, ?int $limite = null): array
    {
        $datos = [];
        $filaInicio = $config['fila_inicio'];
        $columnas = $config['columnas'];

        // Cargar archivo
        $spreadsheet = IOFactory::load($ruta);
        $hoja = $spreadsheet->getActiveSheet();
        $filaMax = $hoja->getHighestRow();

        $contadorDatos = 0;

        for ($fila = $filaInicio + 1; $fila <= $filaMax; $fila++) {
            $campos = [];

            // Leer columnas necesarias
            $maxColumna = max(array_values($columnas)) + 1;
            for ($col = 0; $col < $maxColumna; $col++) {
                $celda = $hoja->getCellByColumnAndRow($col + 1, $fila);
                $campos[$col] = $celda->getValue();
            }

            // Validar fila no vacía
            if (empty(array_filter($campos))) continue;

            // Extraer registro
            $registro = $this->extraerRegistro($campos, $columnas, $config, $fila);
            if ($registro) {
                $datos[] = $registro;
                $contadorDatos++;

                if ($limite && $contadorDatos >= $limite) {
                    break;
                }
            }
        }

        return $datos;
    }

    /**
     * Extraer registro normalizado desde campos
     */
    protected function extraerRegistro(array $campos, array $columnas, array $config, int $lineaArchivo): ?array
    {
        try {
            // Fecha
            $fechaRaw = trim($campos[$columnas['fecha']] ?? '');
            $fecha = $this->parsearFecha($fechaRaw, $config['formato_fecha']);
            if (!$fecha) return null;

            // Fecha valor (opcional)
            $fechaValor = null;
            if (isset($columnas['fecha_valor'])) {
                $fechaValorRaw = trim($campos[$columnas['fecha_valor']] ?? '');
                if ($fechaValorRaw) {
                    $fechaValor = $this->parsearFecha($fechaValorRaw, $config['formato_fecha']);
                }
            }

            // Descripción
            $descripcion = trim($campos[$columnas['descripcion']] ?? '');
            if (empty($descripcion)) return null;

            // Número de documento
            $numeroDocumento = trim($campos[$columnas['numero_documento']] ?? '');

            // Montos
            $cargo = $this->parsearMonto($campos[$columnas['cargo']] ?? '', $config['formato_monto']);
            $abono = $this->parsearMonto($campos[$columnas['abono']] ?? '', $config['formato_monto']);
            $saldo = $this->parsearMonto($campos[$columnas['saldo']] ?? '', $config['formato_monto']);

            // Validar que tenga al menos un movimiento
            if ($cargo == 0 && $abono == 0) return null;

            return [
                'fecha' => $fecha,
                'fecha_valor' => $fechaValor,
                'descripcion' => $descripcion,
                'numero_documento' => $numeroDocumento,
                'cargo' => $cargo,
                'abono' => $abono,
                'saldo' => $saldo,
                'linea_archivo' => $lineaArchivo,
            ];

        } catch (\Exception $e) {
            return null;
        }
    }

    // =========================================================================
    // PROCESAMIENTO DE MOVIMIENTOS
    // =========================================================================

    /**
     * Procesar e insertar movimientos
     */
    protected function procesarMovimientos(
        int $cuentaBancariaId,
        array $datos,
        array $config,
        array $opciones
    ): array {
        $importados = 0;
        $duplicados = 0;
        $errores = 0;
        $detalleErrores = [];

        $nombreArchivo = $opciones['nombre_archivo'] ?? 'cartola_' . now()->format('YmdHis');

        DB::beginTransaction();

        try {
            foreach ($datos as $index => $registro) {
                // Verificar duplicado
                $existe = $this->verificarDuplicado($cuentaBancariaId, $registro);

                if ($existe) {
                    $duplicados++;
                    continue;
                }

                // Detectar tipo de movimiento
                $tipo = $this->detectarTipoMovimiento($registro['descripcion'], $registro['cargo'], $registro['abono']);

                // Insertar movimiento
                try {
                    DB::table('movimientos_bancarios')->insert([
                        'cuenta_bancaria_id' => $cuentaBancariaId,
                        'fecha' => $registro['fecha'],
                        'fecha_valor' => $registro['fecha_valor'],
                        'tipo' => $tipo,
                        'numero_documento' => $registro['numero_documento'] ?: null,
                        'descripcion' => $registro['descripcion'],
                        'cargo' => $registro['cargo'],
                        'abono' => $registro['abono'],
                        'saldo_posterior' => $registro['saldo'] > 0 ? $registro['saldo'] : null,
                        'conciliado' => false,
                        'importado_cartola' => true,
                        'linea_cartola' => $registro['linea_archivo'],
                        'archivo_cartola' => $nombreArchivo,
                        'estado' => 'pendiente',
                        'created_at' => now(),
                    ]);

                    $importados++;

                } catch (\Exception $e) {
                    $errores++;
                    $detalleErrores[] = [
                        'linea' => $registro['linea_archivo'],
                        'error' => $e->getMessage(),
                    ];
                }
            }

            // Actualizar saldo de la cuenta si hay movimientos
            if ($importados > 0 && !empty($datos)) {
                $ultimoSaldo = $datos[count($datos) - 1]['saldo'] ?? null;
                if ($ultimoSaldo) {
                    DB::table('cuentas_bancarias_comunidad')
                        ->where('id', $cuentaBancariaId)
                        ->update([
                            'saldo_banco' => $ultimoSaldo,
                            'updated_at' => now(),
                        ]);
                }
            }

            DB::commit();

            return [
                'importados' => $importados,
                'duplicados' => $duplicados,
                'errores' => $errores,
                'detalle_errores' => $detalleErrores,
            ];

        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Verificar si el movimiento ya existe
     */
    protected function verificarDuplicado(int $cuentaId, array $registro): bool
    {
        // Buscar por fecha, monto y número de documento
        $query = DB::table('movimientos_bancarios')
            ->where('cuenta_bancaria_id', $cuentaId)
            ->where('fecha', $registro['fecha'])
            ->where('cargo', $registro['cargo'])
            ->where('abono', $registro['abono']);

        if (!empty($registro['numero_documento'])) {
            $query->where('numero_documento', $registro['numero_documento']);
        } else {
            // Si no tiene número, comparar también descripción
            $query->where('descripcion', 'like', '%' . substr($registro['descripcion'], 0, 50) . '%');
        }

        return $query->exists();
    }

    /**
     * Detectar tipo de movimiento según descripción
     */
    protected function detectarTipoMovimiento(string $descripcion, float $cargo, float $abono): string
    {
        $desc = strtoupper($descripcion);

        // Patrones de depósitos/abonos
        if ($abono > 0) {
            if (str_contains($desc, 'TRANSFERENCIA') || str_contains($desc, 'TEF')) {
                return 'transferencia_recibida';
            }
            if (str_contains($desc, 'DEPOSITO') || str_contains($desc, 'DEP')) {
                return 'deposito';
            }
            if (str_contains($desc, 'ABONO') || str_contains($desc, 'NOMINA')) {
                return 'abono_nomina';
            }
            if (str_contains($desc, 'WEBPAY') || str_contains($desc, 'TRANSBANK')) {
                return 'pago_webpay';
            }
            if (str_contains($desc, 'KHIPU')) {
                return 'pago_khipu';
            }
            if (str_contains($desc, 'INTERES')) {
                return 'interes_ganado';
            }
            return 'abono_nomina';
        }

        // Patrones de cargos
        if ($cargo > 0) {
            if (str_contains($desc, 'TRANSFERENCIA') || str_contains($desc, 'TEF')) {
                return 'transferencia_enviada';
            }
            if (str_contains($desc, 'CHEQUE') || str_contains($desc, 'CHQ')) {
                if (str_contains($desc, 'COBRADO') || str_contains($desc, 'PAGO')) {
                    return 'cheque_cobrado';
                }
                return 'cheque_girado';
            }
            if (str_contains($desc, 'PAC') || str_contains($desc, 'AUTOMATICO')) {
                return 'cargo_automatico';
            }
            if (str_contains($desc, 'COMISION') || str_contains($desc, 'MANT')) {
                return 'comision_bancaria';
            }
            if (str_contains($desc, 'PAGO') && str_contains($desc, 'PROV')) {
                return 'pago_proveedor';
            }
            if (str_contains($desc, 'SUELDO') || str_contains($desc, 'REMUN')) {
                return 'pago_remuneracion';
            }
            if (str_contains($desc, 'AFP') || str_contains($desc, 'ISAPRE') || str_contains($desc, 'PREVIRED')) {
                return 'pago_cotizaciones';
            }
            return 'transferencia_enviada';
        }

        return 'transferencia_enviada';
    }

    // =========================================================================
    // UTILIDADES DE PARSEO
    // =========================================================================

    /**
     * Parsear fecha según formato
     */
    protected function parsearFecha(string $fecha, string $formato): ?string
    {
        if (empty($fecha)) return null;

        try {
            // Limpiar fecha
            $fecha = trim($fecha);

            // Intentar parsear con formato especificado
            $carbon = Carbon::createFromFormat($formato, $fecha);
            if ($carbon) {
                return $carbon->format('Y-m-d');
            }

            // Intentar formatos comunes
            $formatosComunes = [
                'd/m/Y', 'd-m-Y', 'Y-m-d', 'd.m.Y',
                'd/m/y', 'd-m-y',
            ];

            foreach ($formatosComunes as $fmt) {
                try {
                    $carbon = Carbon::createFromFormat($fmt, $fecha);
                    if ($carbon) {
                        return $carbon->format('Y-m-d');
                    }
                } catch (\Exception $e) {
                    continue;
                }
            }

            // Último intento con parse genérico
            return Carbon::parse($fecha)->format('Y-m-d');

        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Parsear monto según formato
     */
    protected function parsearMonto(string $monto, string $formato): float
    {
        if (empty($monto)) return 0;

        // Limpiar espacios y caracteres especiales
        $monto = trim($monto);
        $monto = preg_replace('/[^0-9.,\-]/', '', $monto);

        if (empty($monto)) return 0;

        // Manejar negativos
        $negativo = str_contains($monto, '-');
        $monto = str_replace('-', '', $monto);

        switch ($formato) {
            case 'punto_miles':
                // 1.234.567 o 1.234.567,89
                $monto = str_replace('.', '', $monto);
                $monto = str_replace(',', '.', $monto);
                break;

            case 'coma_miles':
                // 1,234,567 o 1,234,567.89
                $monto = str_replace(',', '', $monto);
                break;

            case 'decimal':
                // 1234567.89 (ya está en formato correcto)
                break;

            default:
                // Detectar automáticamente
                if (preg_match('/^\d{1,3}(\.\d{3})+,\d{2}$/', $monto)) {
                    // Formato 1.234.567,89
                    $monto = str_replace('.', '', $monto);
                    $monto = str_replace(',', '.', $monto);
                } elseif (preg_match('/^\d{1,3}(,\d{3})+\.\d{2}$/', $monto)) {
                    // Formato 1,234,567.89
                    $monto = str_replace(',', '', $monto);
                }
                break;
        }

        $valor = floatval($monto);
        return $negativo ? -$valor : $valor;
    }

    // =========================================================================
    // MATCH AUTOMÁTICO
    // =========================================================================

    /**
     * Ejecutar match automático de movimientos importados
     */
    public function matchAutomatico(int $cuentaBancariaId, array $opciones = []): array
    {
        $cuenta = DB::table('cuentas_bancarias_comunidad')
            ->where('id', $cuentaBancariaId)
            ->first();

        if (!$cuenta) {
            return ['success' => false, 'message' => 'Cuenta no encontrada'];
        }

        $matcheados = 0;
        $noMatcheados = 0;
        $detalleMatches = [];

        // Obtener movimientos pendientes de match
        $movimientos = DB::table('movimientos_bancarios')
            ->where('cuenta_bancaria_id', $cuentaBancariaId)
            ->where('conciliado', false)
            ->whereNull('boleta_gc_id')
            ->whereNull('factura_arriendo_id')
            ->whereNull('traspaso_id')
            ->orderBy('fecha')
            ->get();

        foreach ($movimientos as $mov) {
            $match = null;

            // 1. Intentar match con pagos de GC (abonos)
            if ($mov->abono > 0) {
                $match = $this->matchPagoGC($mov, $cuenta->edificio_id);
                if ($match) {
                    $matcheados++;
                    $detalleMatches[] = [
                        'movimiento_id' => $mov->id,
                        'tipo' => 'pago_gc',
                        'referencia_id' => $match['boleta_id'],
                        'confianza' => $match['confianza'],
                    ];
                    continue;
                }
            }

            // 2. Intentar match con pagos de arriendos (abonos)
            if ($mov->abono > 0) {
                $match = $this->matchPagoArriendo($mov, $cuenta->edificio_id);
                if ($match) {
                    $matcheados++;
                    $detalleMatches[] = [
                        'movimiento_id' => $mov->id,
                        'tipo' => 'pago_arriendo',
                        'referencia_id' => $match['factura_id'],
                        'confianza' => $match['confianza'],
                    ];
                    continue;
                }
            }

            // 3. Intentar match con traspasos (cargos internos)
            if ($mov->cargo > 0) {
                $match = $this->matchTraspaso($mov, $cuenta->edificio_id);
                if ($match) {
                    $matcheados++;
                    $detalleMatches[] = [
                        'movimiento_id' => $mov->id,
                        'tipo' => 'traspaso',
                        'referencia_id' => $match['traspaso_id'],
                        'confianza' => $match['confianza'],
                    ];
                    continue;
                }
            }

            $noMatcheados++;
        }

        return [
            'success' => true,
            'message' => 'Match automático completado',
            'total_movimientos' => count($movimientos),
            'matcheados' => $matcheados,
            'no_matcheados' => $noMatcheados,
            'porcentaje_match' => count($movimientos) > 0 
                ? round($matcheados / count($movimientos) * 100, 2) 
                : 0,
            'detalle' => $detalleMatches,
        ];
    }

    /**
     * Match con pagos de GC
     */
    protected function matchPagoGC(object $movimiento, int $edificioId): ?array
    {
        // Buscar boletas con monto similar pendientes de conciliar
        $tolerancia = 100; // Tolerancia de $100 por diferencias de redondeo

        $boleta = DB::table('boletas_gc')
            ->join('periodos_gc', 'boletas_gc.periodo_id', '=', 'periodos_gc.id')
            ->join('pagos_gc', 'pagos_gc.boleta_id', '=', 'boletas_gc.id')
            ->where('periodos_gc.edificio_id', $edificioId)
            ->whereRaw('ABS(pagos_gc.monto - ?) <= ?', [$movimiento->abono, $tolerancia])
            ->where('pagos_gc.fecha_pago', '>=', Carbon::parse($movimiento->fecha)->subDays(3))
            ->where('pagos_gc.fecha_pago', '<=', Carbon::parse($movimiento->fecha)->addDays(3))
            ->whereNull('pagos_gc.movimiento_bancario_id')
            ->select('boletas_gc.id as boleta_id', 'pagos_gc.id as pago_id', 'pagos_gc.monto')
            ->first();

        if ($boleta) {
            // Calcular confianza del match
            $diferenciaMontos = abs($boleta->monto - $movimiento->abono);
            $confianza = $diferenciaMontos == 0 ? 100 : (100 - ($diferenciaMontos / $movimiento->abono * 100));

            // Actualizar movimiento
            DB::table('movimientos_bancarios')
                ->where('id', $movimiento->id)
                ->update([
                    'boleta_gc_id' => $boleta->boleta_id,
                    'conciliado' => $confianza >= 95,
                    'fecha_conciliacion' => $confianza >= 95 ? now()->toDateString() : null,
                    'estado' => $confianza >= 95 ? 'conciliado' : 'procesado',
                ]);

            // Actualizar pago
            DB::table('pagos_gc')
                ->where('id', $boleta->pago_id)
                ->update(['movimiento_bancario_id' => $movimiento->id]);

            return [
                'boleta_id' => $boleta->boleta_id,
                'pago_id' => $boleta->pago_id,
                'confianza' => round($confianza, 2),
            ];
        }

        return null;
    }

    /**
     * Match con pagos de arriendos
     */
    protected function matchPagoArriendo(object $movimiento, int $edificioId): ?array
    {
        $tolerancia = 100;

        $factura = DB::table('facturas_arriendo')
            ->join('contratos_arriendo', 'facturas_arriendo.contrato_id', '=', 'contratos_arriendo.id')
            ->where('contratos_arriendo.edificio_id', $edificioId)
            ->whereRaw('ABS(facturas_arriendo.monto_total - ?) <= ?', [$movimiento->abono, $tolerancia])
            ->where('facturas_arriendo.estado', '!=', 'pagada')
            ->where('facturas_arriendo.fecha_emision', '<=', $movimiento->fecha)
            ->select('facturas_arriendo.id as factura_id', 'facturas_arriendo.monto_total')
            ->first();

        if ($factura) {
            $diferenciaMontos = abs($factura->monto_total - $movimiento->abono);
            $confianza = $diferenciaMontos == 0 ? 100 : (100 - ($diferenciaMontos / $movimiento->abono * 100));

            // Actualizar movimiento
            DB::table('movimientos_bancarios')
                ->where('id', $movimiento->id)
                ->update([
                    'factura_arriendo_id' => $factura->factura_id,
                    'conciliado' => $confianza >= 95,
                    'fecha_conciliacion' => $confianza >= 95 ? now()->toDateString() : null,
                    'estado' => $confianza >= 95 ? 'conciliado' : 'procesado',
                ]);

            // Actualizar factura si confianza alta
            if ($confianza >= 95) {
                DB::table('facturas_arriendo')
                    ->where('id', $factura->factura_id)
                    ->update([
                        'estado' => 'pagada',
                        'fecha_pago' => $movimiento->fecha,
                        'monto_pagado' => $movimiento->abono,
                    ]);
            }

            return [
                'factura_id' => $factura->factura_id,
                'confianza' => round($confianza, 2),
            ];
        }

        return null;
    }

    /**
     * Match con traspasos
     */
    protected function matchTraspaso(object $movimiento, int $edificioId): ?array
    {
        $tolerancia = 10;

        $traspaso = DB::table('traspasos_cuentas')
            ->where('edificio_id', $edificioId)
            ->whereRaw('ABS(monto - ?) <= ?', [$movimiento->cargo, $tolerancia])
            ->where('fecha', '>=', Carbon::parse($movimiento->fecha)->subDays(2))
            ->where('fecha', '<=', Carbon::parse($movimiento->fecha)->addDays(2))
            ->where('estado', 'ejecutado')
            ->whereNull('movimiento_origen_id')
            ->select('id', 'monto')
            ->first();

        if ($traspaso) {
            $confianza = abs($traspaso->monto - $movimiento->cargo) == 0 ? 100 : 95;

            DB::table('movimientos_bancarios')
                ->where('id', $movimiento->id)
                ->update([
                    'traspaso_id' => $traspaso->id,
                    'conciliado' => true,
                    'fecha_conciliacion' => now()->toDateString(),
                    'estado' => 'conciliado',
                ]);

            DB::table('traspasos_cuentas')
                ->where('id', $traspaso->id)
                ->update(['movimiento_origen_id' => $movimiento->id]);

            return [
                'traspaso_id' => $traspaso->id,
                'confianza' => $confianza,
            ];
        }

        return null;
    }

    // =========================================================================
    // PLANTILLAS DE IMPORTACIÓN
    // =========================================================================

    /**
     * Generar plantilla de importación para un banco
     */
    public function generarPlantilla(string $bancoFormato): array
    {
        if (!isset($this->formatosBancos[$bancoFormato])) {
            return ['success' => false, 'message' => 'Formato no soportado'];
        }

        $config = $this->formatosBancos[$bancoFormato];

        $encabezados = [
            'Fecha',
            'Descripción',
            'N° Documento',
            'Cargo',
            'Abono',
            'Saldo',
        ];

        $ejemplos = [
            [$this->formatearFechaEjemplo($config['formato_fecha']), 'TRANSFERENCIA RECIBIDA - PAGO GC', '12345', '', '150000', '500000'],
            [$this->formatearFechaEjemplo($config['formato_fecha']), 'PAGO PROVEEDOR MANTENCIÓN', '12346', '80000', '', '420000'],
            [$this->formatearFechaEjemplo($config['formato_fecha']), 'COMISIÓN BANCARIA', '', '5000', '', '415000'],
        ];

        return [
            'success' => true,
            'banco' => $config['nombre'],
            'separador' => $config['separador_csv'],
            'formato_fecha' => $config['formato_fecha'],
            'formato_monto' => $config['formato_monto'],
            'encabezados' => $encabezados,
            'ejemplos' => $ejemplos,
            'notas' => [
                'Use el separador indicado (' . $config['separador_csv'] . ') para archivos CSV',
                'Formato de fecha: ' . $config['formato_fecha'],
                'Montos sin símbolo de peso ($)',
                'Puede dejar en blanco cargo o abono según corresponda',
            ],
        ];
    }

    protected function formatearFechaEjemplo(string $formato): string
    {
        return now()->format($formato);
    }
}
