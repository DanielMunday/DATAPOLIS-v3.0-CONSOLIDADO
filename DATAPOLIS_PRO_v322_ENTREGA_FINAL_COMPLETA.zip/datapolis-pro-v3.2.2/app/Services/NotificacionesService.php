<?php

declare(strict_types=1);

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO - Servicio de Notificaciones
 * 
 * Sistema centralizado de notificaciones multicanal
 * Incluye email, push web, y preparación para WhatsApp Business
 * 
 * @author DATAPOLIS
 * @version 3.0
 * @since 2025-12-28
 */
class NotificacionesService
{
    /**
     * Tipos de notificación disponibles
     */
    private const TIPOS_NOTIFICACION = [
        // Gastos Comunes
        'BOLETA_EMITIDA' => [
            'nombre' => 'Boleta de Gastos Comunes Emitida',
            'categoria' => 'gastos_comunes',
            'prioridad' => 'alta',
            'canales' => ['email', 'push'],
            'plantilla_email' => 'emails.gastos.boleta-emitida'
        ],
        'PAGO_RECIBIDO' => [
            'nombre' => 'Pago Recibido',
            'categoria' => 'gastos_comunes',
            'prioridad' => 'media',
            'canales' => ['email'],
            'plantilla_email' => 'emails.gastos.pago-recibido'
        ],
        'MOROSIDAD_ALERTA' => [
            'nombre' => 'Alerta de Morosidad',
            'categoria' => 'gastos_comunes',
            'prioridad' => 'alta',
            'canales' => ['email', 'push'],
            'plantilla_email' => 'emails.gastos.morosidad'
        ],
        
        // Asambleas
        'ASAMBLEA_CONVOCATORIA' => [
            'nombre' => 'Convocatoria a Asamblea',
            'categoria' => 'asambleas',
            'prioridad' => 'alta',
            'canales' => ['email', 'push'],
            'plantilla_email' => 'emails.asambleas.convocatoria'
        ],
        'ASAMBLEA_RECORDATORIO' => [
            'nombre' => 'Recordatorio de Asamblea',
            'categoria' => 'asambleas',
            'prioridad' => 'media',
            'canales' => ['email', 'push'],
            'plantilla_email' => 'emails.asambleas.recordatorio'
        ],
        'ASAMBLEA_ACTA' => [
            'nombre' => 'Acta de Asamblea Disponible',
            'categoria' => 'asambleas',
            'prioridad' => 'media',
            'canales' => ['email'],
            'plantilla_email' => 'emails.asambleas.acta'
        ],
        
        // Tributario
        'CERTIFICADO_RENTA' => [
            'nombre' => 'Certificado de Renta Disponible',
            'categoria' => 'tributario',
            'prioridad' => 'alta',
            'canales' => ['email'],
            'plantilla_email' => 'emails.tributario.certificado-renta'
        ],
        'DISTRIBUCION_APROBADA' => [
            'nombre' => 'Distribución de Rentas Aprobada',
            'categoria' => 'tributario',
            'prioridad' => 'media',
            'canales' => ['email'],
            'plantilla_email' => 'emails.tributario.distribucion'
        ],
        
        // Compliance
        'CERTIFICADO_COMPLIANCE' => [
            'nombre' => 'Certificado de Compliance Emitido',
            'categoria' => 'compliance',
            'prioridad' => 'media',
            'canales' => ['email'],
            'plantilla_email' => 'emails.compliance.certificado'
        ],
        'ALERTA_CUMPLIMIENTO' => [
            'nombre' => 'Alerta de Cumplimiento',
            'categoria' => 'compliance',
            'prioridad' => 'alta',
            'canales' => ['email', 'push'],
            'plantilla_email' => 'emails.compliance.alerta'
        ],
        
        // Administración
        'COMUNICADO_GENERAL' => [
            'nombre' => 'Comunicado General',
            'categoria' => 'administracion',
            'prioridad' => 'media',
            'canales' => ['email'],
            'plantilla_email' => 'emails.admin.comunicado'
        ],
        'MANTENCION_PROGRAMADA' => [
            'nombre' => 'Mantención Programada',
            'categoria' => 'administracion',
            'prioridad' => 'media',
            'canales' => ['email', 'push'],
            'plantilla_email' => 'emails.admin.mantencion'
        ],
        
        // Protección de Datos
        'ARCO_SOLICITUD_RECIBIDA' => [
            'nombre' => 'Solicitud ARCO Recibida',
            'categoria' => 'proteccion_datos',
            'prioridad' => 'alta',
            'canales' => ['email'],
            'plantilla_email' => 'emails.arco.solicitud-recibida'
        ],
        'ARCO_SOLICITUD_RESUELTA' => [
            'nombre' => 'Solicitud ARCO Resuelta',
            'categoria' => 'proteccion_datos',
            'prioridad' => 'alta',
            'canales' => ['email'],
            'plantilla_email' => 'emails.arco.solicitud-resuelta'
        ],
        'BRECHA_SEGURIDAD' => [
            'nombre' => 'Notificación de Brecha de Seguridad',
            'categoria' => 'proteccion_datos',
            'prioridad' => 'critica',
            'canales' => ['email', 'push'],
            'plantilla_email' => 'emails.arco.brecha-seguridad'
        ]
    ];

    /**
     * Envía una notificación
     *
     * @param string $tipo Tipo de notificación
     * @param array $destinatarios Lista de destinatarios
     * @param array $datos Datos para la notificación
     * @param array $opciones Opciones adicionales
     * @return array Resultado del envío
     */
    public function enviar(string $tipo, array $destinatarios, array $datos, array $opciones = []): array
    {
        Log::info('Enviando notificación', [
            'tipo' => $tipo,
            'destinatarios_count' => count($destinatarios)
        ]);

        $config = self::TIPOS_NOTIFICACION[$tipo] ?? null;
        
        if (!$config) {
            throw new \InvalidArgumentException("Tipo de notificación no válido: {$tipo}");
        }

        $resultados = [
            'tipo' => $tipo,
            'enviados' => 0,
            'fallidos' => 0,
            'detalles' => []
        ];

        foreach ($destinatarios as $destinatario) {
            foreach ($config['canales'] as $canal) {
                // Verificar preferencias del destinatario
                if (!$this->canalHabilitado($destinatario, $canal, $config['categoria'])) {
                    continue;
                }

                try {
                    $resultado = match($canal) {
                        'email' => $this->enviarEmail($destinatario, $tipo, $datos, $config, $opciones),
                        'push' => $this->enviarPush($destinatario, $tipo, $datos, $config),
                        default => ['exito' => false, 'error' => 'Canal no soportado']
                    };

                    if ($resultado['exito']) {
                        $resultados['enviados']++;
                    } else {
                        $resultados['fallidos']++;
                    }

                    $resultados['detalles'][] = [
                        'destinatario' => $destinatario['email'] ?? $destinatario['id'] ?? 'desconocido',
                        'canal' => $canal,
                        'resultado' => $resultado
                    ];
                } catch (\Exception $e) {
                    $resultados['fallidos']++;
                    $resultados['detalles'][] = [
                        'destinatario' => $destinatario['email'] ?? $destinatario['id'] ?? 'desconocido',
                        'canal' => $canal,
                        'resultado' => ['exito' => false, 'error' => $e->getMessage()]
                    ];
                }
            }
        }

        // Registrar en historial
        $this->registrarEnvio($tipo, $resultados);

        return $resultados;
    }

    /**
     * Envía email
     */
    private function enviarEmail(array $destinatario, string $tipo, array $datos, array $config, array $opciones): array
    {
        if (empty($destinatario['email'])) {
            return ['exito' => false, 'error' => 'Email no disponible'];
        }

        $datosEmail = array_merge($datos, [
            'destinatario' => $destinatario,
            'tipo_notificacion' => $tipo,
            'config' => $config,
            'fecha' => Carbon::now()->format('d/m/Y H:i'),
            'url_portal' => config('app.url') . '/portal'
        ]);

        // Determinar si usar cola o envío inmediato
        $usarCola = $opciones['usar_cola'] ?? ($config['prioridad'] !== 'critica');

        if ($usarCola) {
            // Encolar para envío asíncrono
            Queue::push(new \App\Jobs\EnviarEmailNotificacion(
                $destinatario['email'],
                $config['plantilla_email'],
                $datosEmail,
                $this->obtenerAsunto($tipo, $datos)
            ));

            return [
                'exito' => true,
                'metodo' => 'cola',
                'mensaje' => 'Email encolado para envío'
            ];
        }

        // Envío inmediato (solo para críticos)
        try {
            Mail::send($config['plantilla_email'], $datosEmail, function ($message) use ($destinatario, $tipo, $datos) {
                $message->to($destinatario['email'], $destinatario['nombre'] ?? '')
                    ->subject($this->obtenerAsunto($tipo, $datos))
                    ->from(config('mail.from.address'), config('mail.from.name'));
            });

            return [
                'exito' => true,
                'metodo' => 'inmediato',
                'mensaje' => 'Email enviado'
            ];
        } catch (\Exception $e) {
            return [
                'exito' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Envía notificación push web
     */
    private function enviarPush(array $destinatario, string $tipo, array $datos, array $config): array
    {
        // Verificar si tiene suscripción push
        $suscripcion = $this->obtenerSuscripcionPush($destinatario['id'] ?? null);
        
        if (!$suscripcion) {
            return ['exito' => false, 'error' => 'Sin suscripción push'];
        }

        $payload = [
            'title' => $config['nombre'],
            'body' => $this->generarMensajeCorto($tipo, $datos),
            'icon' => '/icons/datapolis-128.png',
            'badge' => '/icons/badge-72.png',
            'tag' => $tipo,
            'data' => [
                'tipo' => $tipo,
                'url' => $datos['url'] ?? '/portal',
                'timestamp' => time()
            ]
        ];

        // Encolar envío push
        Queue::push(new \App\Jobs\EnviarPushNotificacion($suscripcion, $payload));

        return [
            'exito' => true,
            'metodo' => 'cola',
            'mensaje' => 'Push notification encolada'
        ];
    }

    /**
     * Obtiene asunto del email según tipo
     */
    private function obtenerAsunto(string $tipo, array $datos): string
    {
        $edificio = $datos['edificio_nombre'] ?? 'Su Edificio';
        
        return match($tipo) {
            'BOLETA_EMITIDA' => "[{$edificio}] Boleta de Gastos Comunes - " . ($datos['periodo'] ?? 'Período Actual'),
            'PAGO_RECIBIDO' => "[{$edificio}] Confirmación de Pago Recibido",
            'MOROSIDAD_ALERTA' => "⚠️ [{$edificio}] Aviso Importante: Estado de Cuenta",
            'ASAMBLEA_CONVOCATORIA' => "📋 [{$edificio}] Convocatoria a Asamblea - " . ($datos['fecha_asamblea'] ?? ''),
            'ASAMBLEA_RECORDATORIO' => "⏰ [{$edificio}] Recordatorio: Asamblea Mañana",
            'ASAMBLEA_ACTA' => "[{$edificio}] Acta de Asamblea Disponible",
            'CERTIFICADO_RENTA' => "[{$edificio}] Su Certificado de Renta está Disponible",
            'DISTRIBUCION_APROBADA' => "[{$edificio}] Distribución de Rentas Aprobada",
            'CERTIFICADO_COMPLIANCE' => "[{$edificio}] Certificado de Cumplimiento Emitido",
            'ALERTA_CUMPLIMIENTO' => "⚠️ [{$edificio}] Alerta de Cumplimiento Normativo",
            'COMUNICADO_GENERAL' => "[{$edificio}] Comunicado de la Administración",
            'MANTENCION_PROGRAMADA' => "[{$edificio}] Aviso de Mantención Programada",
            'ARCO_SOLICITUD_RECIBIDA' => "[{$edificio}] Confirmación: Solicitud ARCO Recibida",
            'ARCO_SOLICITUD_RESUELTA' => "[{$edificio}] Su Solicitud ARCO ha sido Resuelta",
            'BRECHA_SEGURIDAD' => "🔴 URGENTE: Notificación de Seguridad - {$edificio}",
            default => "[{$edificio}] Notificación DATAPOLIS"
        };
    }

    /**
     * Genera mensaje corto para push
     */
    private function generarMensajeCorto(string $tipo, array $datos): string
    {
        return match($tipo) {
            'BOLETA_EMITIDA' => "Nueva boleta disponible: $" . number_format($datos['monto'] ?? 0, 0, ',', '.'),
            'PAGO_RECIBIDO' => "Pago recibido por $" . number_format($datos['monto'] ?? 0, 0, ',', '.'),
            'MOROSIDAD_ALERTA' => "Tiene pagos pendientes por $" . number_format($datos['monto_pendiente'] ?? 0, 0, ',', '.'),
            'ASAMBLEA_CONVOCATORIA' => "Asamblea programada para " . ($datos['fecha_asamblea'] ?? 'próximamente'),
            'ASAMBLEA_RECORDATORIO' => "Recuerde: Asamblea mañana a las " . ($datos['hora'] ?? ''),
            'CERTIFICADO_RENTA' => "Su certificado de renta está disponible para descarga",
            'BRECHA_SEGURIDAD' => "URGENTE: Se ha detectado un incidente de seguridad",
            default => $datos['mensaje'] ?? 'Nueva notificación disponible'
        };
    }

    /**
     * Verifica si el canal está habilitado para el destinatario
     */
    private function canalHabilitado(array $destinatario, string $canal, string $categoria): bool
    {
        // Si no hay ID, asumimos que es una notificación administrativa (siempre enviar)
        if (!isset($destinatario['id'])) {
            return true;
        }

        try {
            $preferencias = DB::table('preferencias_notificaciones')
                ->where('persona_id', $destinatario['id'])
                ->first();

            if (!$preferencias) {
                // Sin preferencias = todo habilitado por defecto
                return true;
            }

            $prefJson = json_decode($preferencias->preferencias ?? '{}', true);
            
            return $prefJson[$categoria][$canal] ?? true;
        } catch (\Exception $e) {
            // En caso de error, enviar
            return true;
        }
    }

    /**
     * Obtiene suscripción push del usuario
     */
    private function obtenerSuscripcionPush(?int $personaId): ?array
    {
        if (!$personaId) {
            return null;
        }

        try {
            $suscripcion = DB::table('push_subscriptions')
                ->where('persona_id', $personaId)
                ->where('activa', true)
                ->first();

            if ($suscripcion) {
                return [
                    'endpoint' => $suscripcion->endpoint,
                    'keys' => [
                        'p256dh' => $suscripcion->p256dh,
                        'auth' => $suscripcion->auth
                    ]
                ];
            }
        } catch (\Exception $e) {
            Log::warning('Error al obtener suscripción push', ['error' => $e->getMessage()]);
        }

        return null;
    }

    /**
     * Registra envío en historial
     */
    private function registrarEnvio(string $tipo, array $resultados): void
    {
        try {
            DB::table('historial_notificaciones')->insert([
                'tipo' => $tipo,
                'enviados' => $resultados['enviados'],
                'fallidos' => $resultados['fallidos'],
                'detalles' => json_encode($resultados['detalles']),
                'created_at' => now()
            ]);
        } catch (\Exception $e) {
            Log::warning('Error al registrar historial de notificaciones', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Envía notificación masiva a todo un edificio
     */
    public function enviarMasivo(int $edificioId, string $tipo, array $datos, array $filtros = []): array
    {
        // Obtener todos los copropietarios del edificio
        $query = DB::table('personas')
            ->join('unidades', 'unidades.id', '=', 'personas.unidad_id')
            ->where('unidades.edificio_id', $edificioId)
            ->where('personas.recibe_notificaciones', true)
            ->select('personas.*');

        // Aplicar filtros
        if (isset($filtros['tipo_persona'])) {
            $query->where('personas.tipo', $filtros['tipo_persona']);
        }

        if (isset($filtros['unidades'])) {
            $query->whereIn('personas.unidad_id', $filtros['unidades']);
        }

        $destinatarios = $query->get()->map(function ($p) {
            return [
                'id' => $p->id,
                'nombre' => $p->nombre,
                'email' => $p->email
            ];
        })->toArray();

        return $this->enviar($tipo, $destinatarios, $datos);
    }

    /**
     * Programa notificación para envío futuro
     */
    public function programar(string $tipo, array $destinatarios, array $datos, Carbon $fechaEnvio): array
    {
        $job = new \App\Jobs\EnviarNotificacionProgramada($tipo, $destinatarios, $datos);
        
        Queue::later($fechaEnvio, $job);

        // Registrar programación
        $programacionId = DB::table('notificaciones_programadas')->insertGetId([
            'tipo' => $tipo,
            'destinatarios' => json_encode($destinatarios),
            'datos' => json_encode($datos),
            'fecha_programada' => $fechaEnvio,
            'estado' => 'PENDIENTE',
            'created_at' => now()
        ]);

        return [
            'exito' => true,
            'programacion_id' => $programacionId,
            'fecha_envio' => $fechaEnvio->format('d/m/Y H:i'),
            'destinatarios_count' => count($destinatarios)
        ];
    }

    /**
     * Obtiene historial de notificaciones
     */
    public function obtenerHistorial(array $filtros = []): array
    {
        $query = DB::table('historial_notificaciones')
            ->orderBy('created_at', 'desc');

        if (isset($filtros['tipo'])) {
            $query->where('tipo', $filtros['tipo']);
        }

        if (isset($filtros['desde'])) {
            $query->where('created_at', '>=', $filtros['desde']);
        }

        if (isset($filtros['hasta'])) {
            $query->where('created_at', '<=', $filtros['hasta']);
        }

        $limite = $filtros['limite'] ?? 50;

        return $query->limit($limite)->get()->toArray();
    }

    /**
     * Obtiene estadísticas de notificaciones
     */
    public function obtenerEstadisticas(Carbon $desde, Carbon $hasta): array
    {
        $stats = DB::table('historial_notificaciones')
            ->whereBetween('created_at', [$desde, $hasta])
            ->selectRaw('
                tipo,
                SUM(enviados) as total_enviados,
                SUM(fallidos) as total_fallidos,
                COUNT(*) as total_envios
            ')
            ->groupBy('tipo')
            ->get();

        $totales = [
            'enviados' => 0,
            'fallidos' => 0,
            'envios' => 0
        ];

        foreach ($stats as $stat) {
            $totales['enviados'] += $stat->total_enviados;
            $totales['fallidos'] += $stat->total_fallidos;
            $totales['envios'] += $stat->total_envios;
        }

        return [
            'periodo' => [
                'desde' => $desde->format('Y-m-d'),
                'hasta' => $hasta->format('Y-m-d')
            ],
            'totales' => $totales,
            'tasa_exito' => $totales['enviados'] > 0 
                ? round(($totales['enviados'] / ($totales['enviados'] + $totales['fallidos'])) * 100, 2)
                : 0,
            'por_tipo' => $stats->toArray()
        ];
    }

    /**
     * Registra preferencias de notificación de un usuario
     */
    public function guardarPreferencias(int $personaId, array $preferencias): bool
    {
        try {
            DB::table('preferencias_notificaciones')->updateOrInsert(
                ['persona_id' => $personaId],
                [
                    'preferencias' => json_encode($preferencias),
                    'updated_at' => now()
                ]
            );

            return true;
        } catch (\Exception $e) {
            Log::error('Error al guardar preferencias de notificación', [
                'persona_id' => $personaId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Registra suscripción push
     */
    public function registrarSuscripcionPush(int $personaId, array $suscripcion): bool
    {
        try {
            DB::table('push_subscriptions')->updateOrInsert(
                ['persona_id' => $personaId],
                [
                    'endpoint' => $suscripcion['endpoint'],
                    'p256dh' => $suscripcion['keys']['p256dh'] ?? null,
                    'auth' => $suscripcion['keys']['auth'] ?? null,
                    'activa' => true,
                    'updated_at' => now()
                ]
            );

            return true;
        } catch (\Exception $e) {
            Log::error('Error al registrar suscripción push', ['error' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * Lista tipos de notificación disponibles
     */
    public function listarTipos(): array
    {
        $tipos = [];
        
        foreach (self::TIPOS_NOTIFICACION as $codigo => $config) {
            $tipos[] = [
                'codigo' => $codigo,
                'nombre' => $config['nombre'],
                'categoria' => $config['categoria'],
                'prioridad' => $config['prioridad'],
                'canales' => $config['canales']
            ];
        }

        return $tipos;
    }
}
