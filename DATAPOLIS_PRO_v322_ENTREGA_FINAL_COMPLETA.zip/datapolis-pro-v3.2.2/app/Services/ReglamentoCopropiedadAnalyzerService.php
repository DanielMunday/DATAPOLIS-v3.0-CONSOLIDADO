<?php

declare(strict_types=1);

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Collection;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO - Servicio de Análisis de Reglamentos de Copropiedad
 * 
 * Analiza reglamentos de copropiedad según Ley 21.442 y DS 7-2025
 * Identifica cláusulas críticas, gaps de cumplimiento y genera recomendaciones
 * 
 * @author DATAPOLIS
 * @version 3.0
 * @since 2025-12-28
 */
class ReglamentoCopropiedadAnalyzerService
{
    /**
     * Elementos críticos requeridos por Ley 21.442
     */
    private const ELEMENTOS_CRITICOS_LEY_21442 = [
        'fondo_reserva' => [
            'titulo' => 'Fondo de Reserva (Art. 7)',
            'descripcion' => 'Constitución obligatoria del 5% de gastos comunes para fondo de reserva',
            'criterios' => [
                'porcentaje_minimo' => 5,
                'uso_exclusivo' => ['reparaciones', 'mantención', 'gastos imprevistos'],
                'administracion' => 'Cuenta separada'
            ],
            'severidad' => 'CRITICO',
            'multa_referencial' => '5-50 UTM'
        ],
        'asambleas_telematicas' => [
            'titulo' => 'Asambleas Telemáticas (Art. 17)',
            'descripcion' => 'Posibilidad de realizar asambleas por medios telemáticos',
            'criterios' => [
                'plataforma_segura' => true,
                'verificacion_identidad' => true,
                'registro_participacion' => true,
                'grabacion_opcional' => true
            ],
            'severidad' => 'ALTO',
            'multa_referencial' => '1-10 UTM'
        ],
        'quorum_diferenciado' => [
            'titulo' => 'Quórum Diferenciado (Art. 19)',
            'descripcion' => 'Quórum según tipo de decisión: mayoría simple, 2/3, unanimidad',
            'criterios' => [
                'ordinarias' => 'mayoría simple',
                'modificacion_reglamento' => '2/3 de los copropietarios',
                'venta_bienes_comunes' => 'unanimidad',
                'cambio_destino' => '2/3 de los copropietarios'
            ],
            'severidad' => 'CRITICO',
            'multa_referencial' => '5-30 UTM'
        ],
        'administrador_profesional' => [
            'titulo' => 'Administrador Profesional (Art. 23)',
            'descripcion' => 'Requisitos y funciones del administrador',
            'criterios' => [
                'certificacion' => 'Registro público administradores',
                'fianza' => 'Obligatoria para condominios >20 unidades',
                'rendicion_cuentas' => 'Mensual obligatoria',
                'plazo_maximo' => '3 años renovables'
            ],
            'severidad' => 'ALTO',
            'multa_referencial' => '3-20 UTM'
        ],
        'registro_copropietarios' => [
            'titulo' => 'Registro de Copropietarios (Art. 24)',
            'descripcion' => 'Mantenimiento de registro actualizado de copropietarios',
            'criterios' => [
                'datos_contacto' => 'Obligatorio',
                'porcentaje_dominio' => 'Según escritura',
                'actualizacion' => 'Continua',
                'acceso' => 'Digital preferente'
            ],
            'severidad' => 'MEDIO',
            'multa_referencial' => '1-5 UTM'
        ],
        'arriendos_antenas' => [
            'titulo' => 'Arriendos Telecomunicaciones (Art. 31)',
            'descripcion' => 'Regulación de arriendos de espacios para antenas',
            'criterios' => [
                'aprobacion_asamblea' => '2/3 copropietarios',
                'distribucion_ingresos' => 'Proporcional al dominio',
                'tributacion' => 'Art. 17 N°3 LIR',
                'contrato_escrito' => 'Obligatorio'
            ],
            'severidad' => 'CRITICO',
            'multa_referencial' => 'Según Art. 97 N°2 Código Tributario'
        ],
        'mediacion_conflictos' => [
            'titulo' => 'Mediación de Conflictos (Art. 33)',
            'descripcion' => 'Procedimientos de mediación obligatoria antes de judicializar',
            'criterios' => [
                'instancia_previa' => 'Comité Administración',
                'mediacion_externa' => 'Opcional para escalamiento',
                'plazos' => 'Definidos en reglamento'
            ],
            'severidad' => 'MEDIO',
            'multa_referencial' => 'N/A'
        ],
        'subadministradores' => [
            'titulo' => 'Subadministradores (Art. 22 bis)',
            'descripcion' => 'Regulación de condominios con sectores',
            'criterios' => [
                'autonomia_sectores' => 'Permitida',
                'gastos_comunes_sector' => 'Diferenciados',
                'representacion' => 'En comité general'
            ],
            'severidad' => 'BAJO',
            'multa_referencial' => 'N/A'
        ],
        'proteccion_datos' => [
            'titulo' => 'Protección de Datos (Ley 21.719)',
            'descripcion' => 'Cumplimiento de protección de datos personales',
            'criterios' => [
                'consentimiento' => 'Explícito',
                'finalidad' => 'Específica',
                'derechos_arco' => 'Garantizados',
                'seguridad' => 'Medidas técnicas'
            ],
            'severidad' => 'CRITICO',
            'multa_referencial' => 'Hasta 5.000 UTM'
        ],
        'actualizacion_reglamento' => [
            'titulo' => 'Actualización Reglamento (DS 7-2025)',
            'descripcion' => 'Plazo máximo para actualizar reglamento según nueva ley',
            'criterios' => [
                'plazo_maximo' => '2026-01-09',
                'inscripcion_cbr' => 'Obligatoria',
                'notificacion' => 'A todos los copropietarios'
            ],
            'severidad' => 'CRITICO',
            'multa_referencial' => '10-100 UTM'
        ]
    ];

    /**
     * Palabras clave para detección de cláusulas
     */
    private const KEYWORDS_DETECCION = [
        'fondo_reserva' => ['fondo de reserva', 'fondo reserva', '5%', 'cinco por ciento', 'reparaciones mayores'],
        'asambleas_telematicas' => ['telemática', 'videoconferencia', 'asamblea virtual', 'medios electrónicos', 'reunión remota'],
        'quorum_diferenciado' => ['quórum', 'quorum', 'mayoría', 'dos tercios', '2/3', 'unanimidad', 'votación'],
        'administrador_profesional' => ['administrador', 'fianza', 'rendición', 'cuentas', 'certificación'],
        'registro_copropietarios' => ['registro', 'copropietarios', 'nómina', 'actualización', 'datos'],
        'arriendos_antenas' => ['antena', 'telecomunicación', 'arriendo', 'telefonía', 'arrendamiento espacios'],
        'mediacion_conflictos' => ['mediación', 'conflicto', 'resolución', 'controversia', 'arbitraje'],
        'subadministradores' => ['sector', 'subadministrador', 'sub-administrador', 'gastos sector'],
        'proteccion_datos' => ['datos personales', 'privacidad', 'consentimiento', 'ARCO', 'tratamiento datos'],
        'actualizacion_reglamento' => ['actualización', 'adecuación', 'ley 21.442', '21442']
    ];

    /**
     * Analiza un reglamento de copropiedad completo
     *
     * @param string $contenidoReglamento Texto del reglamento
     * @param array $metadatos Información adicional del condominio
     * @return array Resultado del análisis completo
     */
    public function analizarReglamento(string $contenidoReglamento, array $metadatos = []): array
    {
        Log::info('Iniciando análisis de reglamento', [
            'edificio_id' => $metadatos['edificio_id'] ?? null,
            'longitud_documento' => strlen($contenidoReglamento)
        ]);

        $inicioAnalisis = microtime(true);
        
        // Normalizar texto
        $textoNormalizado = $this->normalizarTexto($contenidoReglamento);
        
        // Análisis de cada elemento crítico
        $analisisElementos = [];
        $scoreTotal = 0;
        $maxScore = count(self::ELEMENTOS_CRITICOS_LEY_21442) * 100;
        
        foreach (self::ELEMENTOS_CRITICOS_LEY_21442 as $codigo => $elemento) {
            $resultado = $this->analizarElemento($codigo, $elemento, $textoNormalizado);
            $analisisElementos[$codigo] = $resultado;
            $scoreTotal += $resultado['score'];
        }

        // Detectar cláusulas adicionales relevantes
        $clausulasAdicionales = $this->detectarClausulasAdicionales($textoNormalizado);
        
        // Detectar posibles conflictos con la ley
        $conflictosLey = $this->detectarConflictosLey($textoNormalizado);
        
        // Generar recomendaciones priorizadas
        $recomendaciones = $this->generarRecomendaciones($analisisElementos);
        
        // Calcular score global
        $scoreGlobal = round(($scoreTotal / $maxScore) * 100, 2);
        
        // Determinar nivel de cumplimiento
        $nivelCumplimiento = $this->determinarNivelCumplimiento($scoreGlobal);
        
        // Generar plan de acción
        $planAccion = $this->generarPlanAccion($analisisElementos, $metadatos);
        
        // Calcular riesgo legal
        $riesgoLegal = $this->calcularRiesgoLegal($analisisElementos);
        
        $tiempoAnalisis = round(microtime(true) - $inicioAnalisis, 3);

        $resultado = [
            'meta' => [
                'version_analisis' => '3.0',
                'fecha_analisis' => Carbon::now()->toIso8601String(),
                'tiempo_proceso_segundos' => $tiempoAnalisis,
                'longitud_documento' => strlen($contenidoReglamento),
                'edificio_id' => $metadatos['edificio_id'] ?? null,
                'edificio_nombre' => $metadatos['edificio_nombre'] ?? null
            ],
            'resumen_ejecutivo' => [
                'score_global' => $scoreGlobal,
                'nivel_cumplimiento' => $nivelCumplimiento,
                'elementos_cumplidos' => $this->contarElementosCumplidos($analisisElementos),
                'elementos_parciales' => $this->contarElementosParciales($analisisElementos),
                'elementos_faltantes' => $this->contarElementosFaltantes($analisisElementos),
                'riesgo_legal' => $riesgoLegal,
                'requiere_actualizacion_urgente' => $scoreGlobal < 70
            ],
            'analisis_detallado' => $analisisElementos,
            'clausulas_adicionales' => $clausulasAdicionales,
            'conflictos_detectados' => $conflictosLey,
            'recomendaciones' => $recomendaciones,
            'plan_accion' => $planAccion,
            'deadline_legal' => [
                'fecha' => '2026-01-09',
                'dias_restantes' => Carbon::now()->diffInDays(Carbon::parse('2026-01-09'), false),
                'urgencia' => $this->calcularUrgenciaDeadline()
            ],
            'estimacion_costos' => $this->estimarCostosAdecuacion($analisisElementos),
            'proximos_pasos' => $this->generarProximosPasos($analisisElementos, $scoreGlobal)
        ];

        Log::info('Análisis de reglamento completado', [
            'edificio_id' => $metadatos['edificio_id'] ?? null,
            'score_global' => $scoreGlobal,
            'nivel_cumplimiento' => $nivelCumplimiento
        ]);

        return $resultado;
    }

    /**
     * Normaliza el texto del reglamento para análisis
     */
    private function normalizarTexto(string $texto): string
    {
        // Convertir a minúsculas
        $texto = mb_strtolower($texto, 'UTF-8');
        
        // Normalizar acentos para búsqueda
        $texto = $this->normalizarAcentos($texto);
        
        // Eliminar saltos de línea múltiples
        $texto = preg_replace('/\s+/', ' ', $texto);
        
        return trim($texto);
    }

    /**
     * Normaliza acentos manteniendo legibilidad
     */
    private function normalizarAcentos(string $texto): string
    {
        $buscar = ['á', 'é', 'í', 'ó', 'ú', 'ñ', 'ü'];
        $reemplazar = ['a', 'e', 'i', 'o', 'u', 'n', 'u'];
        
        return str_replace($buscar, $reemplazar, $texto);
    }

    /**
     * Analiza un elemento específico del reglamento
     */
    private function analizarElemento(string $codigo, array $elemento, string $texto): array
    {
        $keywords = self::KEYWORDS_DETECCION[$codigo] ?? [];
        $coincidencias = [];
        $score = 0;
        
        foreach ($keywords as $keyword) {
            $keywordNormalizado = $this->normalizarAcentos(mb_strtolower($keyword, 'UTF-8'));
            if (str_contains($texto, $keywordNormalizado)) {
                $coincidencias[] = $keyword;
            }
        }
        
        // Calcular score basado en coincidencias
        $porcentajeCoincidencias = count($coincidencias) / max(count($keywords), 1);
        
        if ($porcentajeCoincidencias >= 0.6) {
            $score = 100;
            $estado = 'CUMPLE';
        } elseif ($porcentajeCoincidencias >= 0.3) {
            $score = 50;
            $estado = 'PARCIAL';
        } else {
            $score = 0;
            $estado = 'NO_CUMPLE';
        }
        
        // Extraer contexto donde aparecen las keywords
        $contextosEncontrados = $this->extraerContextos($texto, $coincidencias);
        
        return [
            'titulo' => $elemento['titulo'],
            'descripcion' => $elemento['descripcion'],
            'estado' => $estado,
            'score' => $score,
            'severidad' => $elemento['severidad'],
            'multa_referencial' => $elemento['multa_referencial'],
            'criterios_evaluados' => $elemento['criterios'],
            'keywords_detectadas' => $coincidencias,
            'keywords_faltantes' => array_diff($keywords, $coincidencias),
            'porcentaje_coincidencias' => round($porcentajeCoincidencias * 100, 2),
            'contextos_encontrados' => $contextosEncontrados,
            'accion_requerida' => $this->determinarAccionRequerida($estado, $elemento['severidad'])
        ];
    }

    /**
     * Extrae contexto donde aparecen las keywords
     */
    private function extraerContextos(string $texto, array $keywords): array
    {
        $contextos = [];
        
        foreach ($keywords as $keyword) {
            $keywordNorm = $this->normalizarAcentos(mb_strtolower($keyword, 'UTF-8'));
            $posicion = strpos($texto, $keywordNorm);
            
            if ($posicion !== false) {
                $inicio = max(0, $posicion - 100);
                $fin = min(strlen($texto), $posicion + strlen($keywordNorm) + 100);
                $contexto = substr($texto, $inicio, $fin - $inicio);
                
                $contextos[] = [
                    'keyword' => $keyword,
                    'contexto' => '...' . trim($contexto) . '...',
                    'posicion' => $posicion
                ];
            }
        }
        
        return array_slice($contextos, 0, 3); // Máximo 3 contextos
    }

    /**
     * Detecta cláusulas adicionales relevantes
     */
    private function detectarClausulasAdicionales(string $texto): array
    {
        $clausulasAdicionales = [
            'mascotas' => ['mascota', 'animal', 'perro', 'gato'],
            'ruidos' => ['ruido', 'molestia', 'horario silencio', 'tranquilidad'],
            'estacionamientos' => ['estacionamiento', 'vehiculo', 'aparcamiento'],
            'areas_comunes' => ['area comun', 'espacio comun', 'piscina', 'gimnasio', 'salon'],
            'mudanzas' => ['mudanza', 'traslado', 'horario mudanza'],
            'arrendamiento_unidades' => ['arriendo unidad', 'arrendamiento', 'subarriendo'],
            'modificaciones' => ['modificacion', 'remodelacion', 'obra', 'construccion'],
            'seguros' => ['seguro', 'poliza', 'cobertura'],
            'sanciones' => ['sancion', 'multa', 'penalidad', 'infraccion']
        ];

        $detectadas = [];
        
        foreach ($clausulasAdicionales as $tipo => $keywords) {
            $encontradas = 0;
            foreach ($keywords as $keyword) {
                if (str_contains($texto, $this->normalizarAcentos($keyword))) {
                    $encontradas++;
                }
            }
            
            if ($encontradas > 0) {
                $detectadas[] = [
                    'tipo' => $tipo,
                    'descripcion' => ucfirst(str_replace('_', ' ', $tipo)),
                    'nivel_detalle' => $encontradas >= 2 ? 'DETALLADO' : 'BASICO',
                    'keywords_encontradas' => $encontradas
                ];
            }
        }

        return $detectadas;
    }

    /**
     * Detecta posibles conflictos con la legislación vigente
     */
    private function detectarConflictosLey(string $texto): array
    {
        $conflictos = [];
        
        // Patrones que podrían indicar conflicto con Ley 21.442
        $patronesConflicto = [
            [
                'patron' => 'prohib.*antena',
                'conflicto' => 'Posible restricción ilegal a instalación de antenas',
                'articulo_ley' => 'Art. 31 Ley 21.442',
                'severidad' => 'ALTO'
            ],
            [
                'patron' => 'prohib.*arrend',
                'conflicto' => 'Posible restricción ilegal a arrendamiento',
                'articulo_ley' => 'Art. 8 Ley 21.442',
                'severidad' => 'MEDIO'
            ],
            [
                'patron' => 'unanimidad.*ordinaria',
                'conflicto' => 'Quórum excesivo para decisiones ordinarias',
                'articulo_ley' => 'Art. 19 Ley 21.442',
                'severidad' => 'ALTO'
            ],
            [
                'patron' => 'administrador.*indefinido',
                'conflicto' => 'Plazo indefinido para administrador viola límite legal',
                'articulo_ley' => 'Art. 23 Ley 21.442',
                'severidad' => 'MEDIO'
            ]
        ];

        foreach ($patronesConflicto as $patron) {
            if (preg_match('/' . $patron['patron'] . '/i', $texto)) {
                $conflictos[] = [
                    'descripcion' => $patron['conflicto'],
                    'articulo_ley' => $patron['articulo_ley'],
                    'severidad' => $patron['severidad'],
                    'recomendacion' => 'Revisar y modificar cláusula para cumplir con legislación vigente'
                ];
            }
        }

        return $conflictos;
    }

    /**
     * Genera recomendaciones priorizadas
     */
    private function generarRecomendaciones(array $analisis): array
    {
        $recomendaciones = [];
        
        // Ordenar por severidad y estado
        $prioridad = ['CRITICO' => 1, 'ALTO' => 2, 'MEDIO' => 3, 'BAJO' => 4];
        
        foreach ($analisis as $codigo => $elemento) {
            if ($elemento['estado'] !== 'CUMPLE') {
                $recomendaciones[] = [
                    'elemento' => $codigo,
                    'titulo' => $elemento['titulo'],
                    'prioridad' => $prioridad[$elemento['severidad']] ?? 5,
                    'severidad' => $elemento['severidad'],
                    'estado_actual' => $elemento['estado'],
                    'accion' => $elemento['accion_requerida'],
                    'multa_riesgo' => $elemento['multa_referencial'],
                    'keywords_faltantes' => $elemento['keywords_faltantes']
                ];
            }
        }

        // Ordenar por prioridad
        usort($recomendaciones, fn($a, $b) => $a['prioridad'] <=> $b['prioridad']);

        return $recomendaciones;
    }

    /**
     * Determina acción requerida según estado y severidad
     */
    private function determinarAccionRequerida(string $estado, string $severidad): string
    {
        if ($estado === 'CUMPLE') {
            return 'Ninguna - Elemento cumplido';
        }
        
        if ($estado === 'PARCIAL') {
            return match($severidad) {
                'CRITICO' => 'URGENTE: Completar cláusula inmediatamente',
                'ALTO' => 'Completar cláusula en próxima asamblea',
                default => 'Revisar y mejorar redacción'
            };
        }
        
        return match($severidad) {
            'CRITICO' => 'CRÍTICO: Agregar cláusula obligatoria inmediatamente',
            'ALTO' => 'Agregar cláusula en próxima asamblea extraordinaria',
            'MEDIO' => 'Incluir en próxima actualización de reglamento',
            default => 'Considerar incluir para mejora continua'
        };
    }

    /**
     * Genera plan de acción detallado
     */
    private function generarPlanAccion(array $analisis, array $metadatos): array
    {
        $acciones = [];
        $semana = 1;
        
        // Fase 1: Críticos (Semanas 1-2)
        foreach ($analisis as $codigo => $elemento) {
            if ($elemento['severidad'] === 'CRITICO' && $elemento['estado'] !== 'CUMPLE') {
                $acciones[] = [
                    'fase' => 1,
                    'semana' => $semana,
                    'elemento' => $elemento['titulo'],
                    'accion' => $elemento['accion_requerida'],
                    'responsable' => 'Administrador + Abogado',
                    'entregable' => 'Borrador cláusula modificada',
                    'prioridad' => 'CRITICA'
                ];
                $semana = min($semana + 1, 2);
            }
        }
        
        // Fase 2: Altos (Semanas 3-4)
        $semana = 3;
        foreach ($analisis as $codigo => $elemento) {
            if ($elemento['severidad'] === 'ALTO' && $elemento['estado'] !== 'CUMPLE') {
                $acciones[] = [
                    'fase' => 2,
                    'semana' => $semana,
                    'elemento' => $elemento['titulo'],
                    'accion' => $elemento['accion_requerida'],
                    'responsable' => 'Comité Administración',
                    'entregable' => 'Propuesta para asamblea',
                    'prioridad' => 'ALTA'
                ];
                $semana = min($semana + 1, 4);
            }
        }
        
        // Fase 3: Asamblea y aprobación (Semana 5)
        $acciones[] = [
            'fase' => 3,
            'semana' => 5,
            'elemento' => 'Asamblea Extraordinaria',
            'accion' => 'Convocar asamblea para aprobar modificaciones',
            'responsable' => 'Administrador',
            'entregable' => 'Acta de asamblea con aprobación',
            'prioridad' => 'CRITICA'
        ];
        
        // Fase 4: Inscripción CBR (Semana 6)
        $acciones[] = [
            'fase' => 4,
            'semana' => 6,
            'elemento' => 'Inscripción CBR',
            'accion' => 'Inscribir reglamento modificado en Conservador de Bienes Raíces',
            'responsable' => 'Abogado',
            'entregable' => 'Certificado inscripción CBR',
            'prioridad' => 'CRITICA'
        ];

        return [
            'resumen' => [
                'total_semanas' => 6,
                'total_acciones' => count($acciones),
                'fecha_inicio_sugerida' => Carbon::now()->format('Y-m-d'),
                'fecha_termino_estimada' => Carbon::now()->addWeeks(6)->format('Y-m-d')
            ],
            'acciones' => $acciones
        ];
    }

    /**
     * Calcula riesgo legal general
     */
    private function calcularRiesgoLegal(array $analisis): array
    {
        $riesgoTotal = 0;
        $factoresRiesgo = [];
        
        foreach ($analisis as $codigo => $elemento) {
            $pesoSeveridad = match($elemento['severidad']) {
                'CRITICO' => 4,
                'ALTO' => 3,
                'MEDIO' => 2,
                default => 1
            };
            
            $pesoEstado = match($elemento['estado']) {
                'NO_CUMPLE' => 3,
                'PARCIAL' => 1.5,
                default => 0
            };
            
            $riesgoElemento = $pesoSeveridad * $pesoEstado;
            $riesgoTotal += $riesgoElemento;
            
            if ($riesgoElemento > 0) {
                $factoresRiesgo[] = [
                    'elemento' => $elemento['titulo'],
                    'riesgo' => $riesgoElemento,
                    'severidad' => $elemento['severidad'],
                    'multa_potencial' => $elemento['multa_referencial']
                ];
            }
        }
        
        // Normalizar a escala 0-100
        $maxRiesgo = count($analisis) * 12; // 4 (severidad max) * 3 (estado max)
        $riesgoNormalizado = round(($riesgoTotal / $maxRiesgo) * 100, 2);
        
        $nivelRiesgo = match(true) {
            $riesgoNormalizado >= 60 => 'CRITICO',
            $riesgoNormalizado >= 40 => 'ALTO',
            $riesgoNormalizado >= 20 => 'MEDIO',
            default => 'BAJO'
        };

        return [
            'score' => $riesgoNormalizado,
            'nivel' => $nivelRiesgo,
            'factores_principales' => array_slice($factoresRiesgo, 0, 5),
            'descripcion' => $this->descripcionRiesgo($nivelRiesgo)
        ];
    }

    /**
     * Descripción del nivel de riesgo
     */
    private function descripcionRiesgo(string $nivel): string
    {
        return match($nivel) {
            'CRITICO' => 'Riesgo legal crítico. Exposición a multas significativas y posibles demandas. Acción inmediata requerida.',
            'ALTO' => 'Riesgo legal alto. Varios elementos críticos no cumplen con la legislación. Actualización urgente necesaria.',
            'MEDIO' => 'Riesgo legal moderado. Algunos elementos requieren atención. Se recomienda actualización planificada.',
            default => 'Riesgo legal bajo. Reglamento mayormente conforme. Mantener monitoreo regular.'
        };
    }

    /**
     * Determina nivel de cumplimiento
     */
    private function determinarNivelCumplimiento(float $score): string
    {
        return match(true) {
            $score >= 90 => 'EXCELENTE',
            $score >= 75 => 'BUENO',
            $score >= 60 => 'REGULAR',
            $score >= 40 => 'DEFICIENTE',
            default => 'CRITICO'
        };
    }

    /**
     * Cuenta elementos cumplidos
     */
    private function contarElementosCumplidos(array $analisis): int
    {
        return count(array_filter($analisis, fn($e) => $e['estado'] === 'CUMPLE'));
    }

    /**
     * Cuenta elementos parciales
     */
    private function contarElementosParciales(array $analisis): int
    {
        return count(array_filter($analisis, fn($e) => $e['estado'] === 'PARCIAL'));
    }

    /**
     * Cuenta elementos faltantes
     */
    private function contarElementosFaltantes(array $analisis): int
    {
        return count(array_filter($analisis, fn($e) => $e['estado'] === 'NO_CUMPLE'));
    }

    /**
     * Calcula urgencia del deadline
     */
    private function calcularUrgenciaDeadline(): string
    {
        $diasRestantes = Carbon::now()->diffInDays(Carbon::parse('2026-01-09'), false);
        
        return match(true) {
            $diasRestantes <= 0 => 'VENCIDO',
            $diasRestantes <= 30 => 'CRITICA',
            $diasRestantes <= 60 => 'ALTA',
            $diasRestantes <= 90 => 'MEDIA',
            default => 'NORMAL'
        };
    }

    /**
     * Estima costos de adecuación
     */
    private function estimarCostosAdecuacion(array $analisis): array
    {
        $elementosFaltantes = $this->contarElementosFaltantes($analisis);
        $elementosParciales = $this->contarElementosParciales($analisis);
        
        // Costos estimados en UF
        $costoAbogado = ($elementosFaltantes * 5) + ($elementosParciales * 2); // UF por elemento
        $costoCBR = 3; // UF aproximado inscripción
        $costoAsamblea = 2; // UF gastos asamblea extraordinaria
        
        $costoTotalUF = $costoAbogado + $costoCBR + $costoAsamblea;
        $valorUF = 38500; // Valor aproximado UF en CLP
        
        return [
            'desglose' => [
                'honorarios_abogado_uf' => $costoAbogado,
                'inscripcion_cbr_uf' => $costoCBR,
                'gastos_asamblea_uf' => $costoAsamblea
            ],
            'total_uf' => $costoTotalUF,
            'total_clp_estimado' => $costoTotalUF * $valorUF,
            'valor_uf_referencia' => $valorUF,
            'nota' => 'Estimación referencial. Costos reales pueden variar según complejidad y profesionales contratados.'
        ];
    }

    /**
     * Genera próximos pasos concretos
     */
    private function generarProximosPasos(array $analisis, float $scoreGlobal): array
    {
        $pasos = [];
        
        if ($scoreGlobal < 70) {
            $pasos[] = [
                'paso' => 1,
                'accion' => 'Contratar abogado especialista en copropiedad',
                'plazo' => 'Inmediato',
                'responsable' => 'Comité Administración'
            ];
        }
        
        $pasos[] = [
            'paso' => count($pasos) + 1,
            'accion' => 'Revisar elementos críticos identificados en este análisis',
            'plazo' => '1 semana',
            'responsable' => 'Administrador'
        ];
        
        $pasos[] = [
            'paso' => count($pasos) + 1,
            'accion' => 'Preparar borrador de modificaciones al reglamento',
            'plazo' => '2 semanas',
            'responsable' => 'Abogado'
        ];
        
        $pasos[] = [
            'paso' => count($pasos) + 1,
            'accion' => 'Convocar asamblea extraordinaria',
            'plazo' => '3 semanas',
            'responsable' => 'Administrador'
        ];
        
        $pasos[] = [
            'paso' => count($pasos) + 1,
            'accion' => 'Aprobar e inscribir reglamento actualizado',
            'plazo' => 'Antes del 09/01/2026',
            'responsable' => 'Abogado + Administrador'
        ];

        return $pasos;
    }

    /**
     * Genera reporte en formato PDF-ready
     */
    public function generarReportePDF(array $analisis): array
    {
        return [
            'titulo' => 'Análisis de Cumplimiento - Reglamento de Copropiedad',
            'subtitulo' => 'Según Ley 21.442 y DS 7-2025',
            'fecha' => Carbon::now()->format('d/m/Y'),
            'secciones' => [
                [
                    'titulo' => 'Resumen Ejecutivo',
                    'contenido' => $analisis['resumen_ejecutivo']
                ],
                [
                    'titulo' => 'Análisis Detallado por Elemento',
                    'contenido' => $analisis['analisis_detallado']
                ],
                [
                    'titulo' => 'Recomendaciones Priorizadas',
                    'contenido' => $analisis['recomendaciones']
                ],
                [
                    'titulo' => 'Plan de Acción',
                    'contenido' => $analisis['plan_accion']
                ],
                [
                    'titulo' => 'Estimación de Costos',
                    'contenido' => $analisis['estimacion_costos']
                ]
            ],
            'anexos' => [
                'conflictos_detectados' => $analisis['conflictos_detectados'],
                'clausulas_adicionales' => $analisis['clausulas_adicionales']
            ],
            'disclaimer' => 'Este análisis es referencial y no constituye asesoría legal. Se recomienda validar con abogado especialista.'
        ];
    }
}
