<?php

declare(strict_types=1);

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

/**
 * DATAPOLIS PRO - Simulador de Sanciones Tributarias
 * 
 * Calcula multas e intereses según Art. 97 N°2 del Código Tributario
 * Simula escenarios de regularización y genera estrategias de mitigación
 * 
 * @author DATAPOLIS
 * @version 3.0
 * @since 2025-12-28
 */
class SimuladorSancionesService
{
    /**
     * Tasas de interés moratorio SII (actualizadas 2025)
     */
    private const TASA_INTERES_MENSUAL = 1.5; // 1.5% mensual
    private const TASA_INTERES_ANUAL = 18; // 18% anual simple

    /**
     * Multas según Art. 97 N°2 Código Tributario
     */
    private const MULTAS_ART_97_N2 = [
        'retardo_declaracion' => [
            'descripcion' => 'Retardo en presentar declaración',
            'base' => 'Por cada mes o fracción de mes de retardo',
            'porcentaje_minimo' => 10,
            'porcentaje_maximo' => 30,
            'tope_utm' => 8
        ],
        'omision_declaracion' => [
            'descripcion' => 'Omisión de declaración',
            'base' => 'Del impuesto adeudado',
            'porcentaje_minimo' => 20,
            'porcentaje_maximo' => 60,
            'tope_utm' => null
        ],
        'declaracion_incompleta' => [
            'descripcion' => 'Declaración incompleta o errónea',
            'base' => 'Diferencia de impuesto',
            'porcentaje_minimo' => 5,
            'porcentaje_maximo' => 20,
            'tope_utm' => null
        ],
        'declaracion_maliciosa' => [
            'descripcion' => 'Declaración maliciosamente falsa',
            'base' => 'Del impuesto evadido',
            'porcentaje_minimo' => 50,
            'porcentaje_maximo' => 300,
            'tope_utm' => null,
            'pena_corporal' => true
        ]
    ];

    /**
     * Escenarios predefinidos
     */
    private const ESCENARIOS = [
        'regularizacion_voluntaria' => [
            'nombre' => 'Regularización Voluntaria',
            'descripcion' => 'El contribuyente se presenta voluntariamente a regularizar',
            'reduccion_multa' => 0.5, // 50% reducción
            'beneficios' => ['Condonación parcial', 'Posible convenio de pago', 'Sin acción penal']
        ],
        'fiscalizacion_detectada' => [
            'nombre' => 'Detectado en Fiscalización',
            'descripcion' => 'El SII detecta la irregularidad en fiscalización',
            'reduccion_multa' => 0,
            'agravantes' => ['Multa completa', 'Posible auditoría extendida']
        ],
        'denuncia_terceros' => [
            'nombre' => 'Denuncia de Terceros',
            'descripcion' => 'Irregularidad denunciada por terceros',
            'reduccion_multa' => 0,
            'agravantes' => ['Posible fiscalización integral', 'Riesgo reputacional']
        ],
        'omision_historica' => [
            'nombre' => 'Omisión Histórica (>3 años)',
            'descripcion' => 'Irregularidad prolongada en el tiempo',
            'reduccion_multa' => 0,
            'agravantes' => ['Multas acumuladas', 'Intereses compuestos', 'Posible calificación dolosa']
        ],
        'primera_infraccion' => [
            'nombre' => 'Primera Infracción',
            'descripcion' => 'Contribuyente sin historial de incumplimientos',
            'reduccion_multa' => 0.25, // 25% reducción
            'beneficios' => ['Posible condonación', 'Fiscalización menos intensiva']
        ]
    ];

    /**
     * Valor UTM (actualizado mensualmente)
     */
    private float $valorUTM;

    /**
     * Valor UF (actualizado diariamente)
     */
    private float $valorUF;

    public function __construct()
    {
        // Valores de diciembre 2025 (deben actualizarse automáticamente)
        $this->valorUTM = 67000; // Valor referencial
        $this->valorUF = 38500; // Valor referencial
    }

    /**
     * Simula sanción completa para un caso específico
     *
     * @param array $datos Datos del caso
     * @return array Resultado de la simulación
     */
    public function simularSancion(array $datos): array
    {
        Log::info('Iniciando simulación de sanción', $datos);

        $impuestoAdeudado = $datos['impuesto_adeudado'] ?? 0;
        $fechaVencimiento = Carbon::parse($datos['fecha_vencimiento'] ?? now());
        $fechaActual = Carbon::parse($datos['fecha_calculo'] ?? now());
        $tipoInfraccion = $datos['tipo_infraccion'] ?? 'retardo_declaracion';
        $escenario = $datos['escenario'] ?? 'fiscalizacion_detectada';
        $esVoluntario = $datos['es_voluntario'] ?? false;
        $esPrimeraInfraccion = $datos['es_primera_infraccion'] ?? true;

        // Calcular meses de atraso
        $mesesAtraso = max(1, $fechaVencimiento->diffInMonths($fechaActual));
        
        // Calcular intereses moratorios
        $intereses = $this->calcularIntereses($impuestoAdeudado, $mesesAtraso);
        
        // Calcular multa base
        $multaBase = $this->calcularMultaBase($impuestoAdeudado, $tipoInfraccion, $mesesAtraso);
        
        // Aplicar reducciones según escenario
        $factorReduccion = $this->calcularFactorReduccion($escenario, $esVoluntario, $esPrimeraInfraccion);
        $multaFinal = $multaBase * (1 - $factorReduccion);
        
        // Calcular reajuste IPC
        $reajusteIPC = $this->calcularReajusteIPC($impuestoAdeudado, $fechaVencimiento, $fechaActual);
        
        // Total a pagar
        $totalDeuda = $impuestoAdeudado + $reajusteIPC + $intereses + $multaFinal;

        $resultado = [
            'meta' => [
                'fecha_simulacion' => Carbon::now()->toIso8601String(),
                'version' => '3.0',
                'valor_utm' => $this->valorUTM,
                'valor_uf' => $this->valorUF
            ],
            'datos_entrada' => [
                'impuesto_original' => $impuestoAdeudado,
                'fecha_vencimiento' => $fechaVencimiento->format('Y-m-d'),
                'fecha_calculo' => $fechaActual->format('Y-m-d'),
                'tipo_infraccion' => $tipoInfraccion,
                'escenario' => $escenario
            ],
            'calculo_temporal' => [
                'meses_atraso' => $mesesAtraso,
                'dias_atraso' => $fechaVencimiento->diffInDays($fechaActual),
                'años_atraso' => round($mesesAtraso / 12, 2)
            ],
            'desglose_deuda' => [
                'impuesto_original' => $impuestoAdeudado,
                'reajuste_ipc' => round($reajusteIPC, 0),
                'impuesto_reajustado' => round($impuestoAdeudado + $reajusteIPC, 0),
                'intereses_moratorios' => round($intereses, 0),
                'multa_base' => round($multaBase, 0),
                'reduccion_aplicada' => round($multaBase * $factorReduccion, 0),
                'multa_final' => round($multaFinal, 0)
            ],
            'total' => [
                'total_a_pagar_clp' => round($totalDeuda, 0),
                'total_utm' => round($totalDeuda / $this->valorUTM, 2),
                'total_uf' => round($totalDeuda / $this->valorUF, 2)
            ],
            'analisis_multa' => $this->analizarMulta($tipoInfraccion, $multaBase, $multaFinal),
            'escenario_aplicado' => self::ESCENARIOS[$escenario] ?? null,
            'proyeccion' => $this->generarProyeccion($impuestoAdeudado, $fechaVencimiento),
            'estrategias_mitigacion' => $this->generarEstrategiasMitigacion($datos, $totalDeuda),
            'convenio_pago' => $this->simularConvenioPago($totalDeuda),
            'comparativa_escenarios' => $this->compararEscenarios($datos),
            'riesgos' => $this->evaluarRiesgos($datos, $mesesAtraso),
            'recomendaciones' => $this->generarRecomendaciones($datos, $mesesAtraso, $totalDeuda)
        ];

        Log::info('Simulación completada', [
            'total_deuda' => $totalDeuda,
            'meses_atraso' => $mesesAtraso
        ]);

        return $resultado;
    }

    /**
     * Calcula intereses moratorios
     */
    private function calcularIntereses(float $impuesto, int $meses): float
    {
        // Interés simple mensual según Art. 53 Código Tributario
        // Tasa: 1.5% mensual
        return $impuesto * (self::TASA_INTERES_MENSUAL / 100) * $meses;
    }

    /**
     * Calcula multa base según tipo de infracción
     */
    private function calcularMultaBase(float $impuesto, string $tipo, int $meses): float
    {
        $config = self::MULTAS_ART_97_N2[$tipo] ?? self::MULTAS_ART_97_N2['retardo_declaracion'];
        
        // Para retardo: porcentaje progresivo por mes
        if ($tipo === 'retardo_declaracion') {
            // 10% primer mes, luego 2% adicional por mes hasta máximo 30%
            $porcentaje = min($config['porcentaje_minimo'] + (($meses - 1) * 2), $config['porcentaje_maximo']);
            $multa = $impuesto * ($porcentaje / 100);
            
            // Aplicar tope en UTM si existe
            if ($config['tope_utm']) {
                $topeClp = $config['tope_utm'] * $this->valorUTM;
                $multa = min($multa, $topeClp);
            }
            
            return $multa;
        }
        
        // Para otros tipos: usar porcentaje medio
        $porcentajeMedio = ($config['porcentaje_minimo'] + $config['porcentaje_maximo']) / 2;
        return $impuesto * ($porcentajeMedio / 100);
    }

    /**
     * Calcula factor de reducción según circunstancias
     */
    private function calcularFactorReduccion(string $escenario, bool $esVoluntario, bool $esPrimerInfraccion): float
    {
        $reduccion = 0;
        
        // Reducción por escenario
        $reduccion += self::ESCENARIOS[$escenario]['reduccion_multa'] ?? 0;
        
        // Reducción adicional por voluntariedad
        if ($esVoluntario && $escenario !== 'regularizacion_voluntaria') {
            $reduccion += 0.2;
        }
        
        // Reducción por primera infracción
        if ($esPrimerInfraccion && $escenario !== 'primera_infraccion') {
            $reduccion += 0.1;
        }
        
        // Máximo 70% de reducción
        return min($reduccion, 0.7);
    }

    /**
     * Calcula reajuste IPC
     */
    private function calcularReajusteIPC(float $impuesto, Carbon $fechaVencimiento, Carbon $fechaActual): float
    {
        // IPC promedio anual estimado: 4%
        $ipcMensual = 0.33; // 4% anual / 12 meses
        $meses = $fechaVencimiento->diffInMonths($fechaActual);
        
        return $impuesto * ($ipcMensual / 100) * $meses;
    }

    /**
     * Analiza la multa aplicada
     */
    private function analizarMulta(string $tipo, float $multaBase, float $multaFinal): array
    {
        $config = self::MULTAS_ART_97_N2[$tipo] ?? null;
        
        return [
            'tipo_infraccion' => $tipo,
            'descripcion' => $config['descripcion'] ?? 'Infracción tributaria',
            'base_legal' => 'Artículo 97 N°2 Código Tributario',
            'rango_legal' => [
                'minimo' => $config['porcentaje_minimo'] ?? 10,
                'maximo' => $config['porcentaje_maximo'] ?? 30
            ],
            'multa_sin_reduccion' => round($multaBase, 0),
            'multa_con_reduccion' => round($multaFinal, 0),
            'reduccion_obtenida' => round($multaBase - $multaFinal, 0),
            'porcentaje_reduccion' => round((1 - ($multaFinal / max($multaBase, 1))) * 100, 2),
            'incluye_pena_corporal' => $config['pena_corporal'] ?? false
        ];
    }

    /**
     * Genera proyección de deuda si no se regulariza
     */
    private function generarProyeccion(float $impuesto, Carbon $fechaVencimiento): array
    {
        $proyecciones = [];
        $fechaActual = Carbon::now();
        
        $periodos = [3, 6, 12, 24, 36]; // Meses futuros
        
        foreach ($periodos as $meses) {
            $fechaFutura = $fechaActual->copy()->addMonths($meses);
            $mesesTotales = $fechaVencimiento->diffInMonths($fechaFutura);
            
            $intereses = $this->calcularIntereses($impuesto, $mesesTotales);
            $multa = $this->calcularMultaBase($impuesto, 'retardo_declaracion', $mesesTotales);
            $reajuste = $this->calcularReajusteIPC($impuesto, $fechaVencimiento, $fechaFutura);
            
            $total = $impuesto + $reajuste + $intereses + $multa;
            
            $proyecciones[] = [
                'fecha' => $fechaFutura->format('Y-m-d'),
                'meses_adicionales' => $meses,
                'meses_totales_atraso' => $mesesTotales,
                'deuda_proyectada' => round($total, 0),
                'incremento_mensual' => round(($intereses + $multa) / max($meses, 1), 0),
                'incremento_porcentual' => round((($total / $impuesto) - 1) * 100, 2)
            ];
        }

        return [
            'proyecciones' => $proyecciones,
            'tendencia' => 'CRECIENTE',
            'alerta' => 'La deuda crece exponencialmente. Se recomienda regularización inmediata.',
            'costo_por_dia_espera' => round(($proyecciones[0]['deuda_proyectada'] - $impuesto) / 90, 0)
        ];
    }

    /**
     * Genera estrategias de mitigación
     */
    private function generarEstrategiasMitigacion(array $datos, float $totalDeuda): array
    {
        $estrategias = [];
        
        // Estrategia 1: Regularización inmediata voluntaria
        $estrategias[] = [
            'nombre' => 'Regularización Voluntaria Inmediata',
            'descripcion' => 'Presentarse voluntariamente ante el SII a regularizar',
            'ahorro_estimado' => round($totalDeuda * 0.3, 0),
            'ahorro_porcentaje' => 30,
            'pasos' => [
                'Preparar documentación completa',
                'Solicitar audiencia en SII',
                'Presentar declaraciones rectificatorias',
                'Negociar condonación de multas',
                'Acordar convenio de pago si es necesario'
            ],
            'plazo_recomendado' => '2 semanas',
            'probabilidad_exito' => 'ALTA',
            'requisitos' => ['Sin fiscalización en curso', 'Documentación completa']
        ];
        
        // Estrategia 2: Solicitud de condonación
        $estrategias[] = [
            'nombre' => 'Solicitud de Condonación Art. 192',
            'descripcion' => 'Solicitar condonación de intereses y multas bajo Art. 192 Código Tributario',
            'ahorro_estimado' => round($totalDeuda * 0.4, 0),
            'ahorro_porcentaje' => 40,
            'pasos' => [
                'Pagar impuesto y reajuste',
                'Presentar solicitud formal de condonación',
                'Demostrar buena fe y capacidad de pago',
                'Esperar resolución (30-60 días)'
            ],
            'plazo_recomendado' => '1-2 meses',
            'probabilidad_exito' => 'MEDIA-ALTA',
            'requisitos' => ['Primera infracción', 'Capacidad de pago demostrable']
        ];
        
        // Estrategia 3: Convenio de pago
        $estrategias[] = [
            'nombre' => 'Convenio de Pago',
            'descripcion' => 'Negociar pago en cuotas con el SII',
            'ahorro_estimado' => round($totalDeuda * 0.1, 0),
            'ahorro_porcentaje' => 10,
            'pasos' => [
                'Reconocer la deuda completa',
                'Presentar propuesta de pago en cuotas',
                'Ofrecer garantías si son requeridas',
                'Cumplir estrictamente el convenio'
            ],
            'plazo_recomendado' => 'Hasta 24 meses',
            'probabilidad_exito' => 'ALTA',
            'requisitos' => ['Capacidad de pago', 'Sin convenios incumplidos previos']
        ];
        
        // Estrategia 4: Reconsideración administrativa
        if ($datos['tipo_infraccion'] === 'declaracion_incompleta') {
            $estrategias[] = [
                'nombre' => 'Reconsideración Administrativa',
                'descripcion' => 'Solicitar reconsideración si hay errores en la fiscalización',
                'ahorro_estimado' => round($totalDeuda * 0.5, 0),
                'ahorro_porcentaje' => 50,
                'pasos' => [
                    'Revisar acta de fiscalización',
                    'Identificar errores o inconsistencias',
                    'Preparar descargos con pruebas',
                    'Presentar recurso de reposición'
                ],
                'plazo_recomendado' => '15 días desde notificación',
                'probabilidad_exito' => 'VARIABLE',
                'requisitos' => ['Errores demostrables en fiscalización']
            ];
        }

        return $estrategias;
    }

    /**
     * Simula convenio de pago
     */
    private function simularConvenioPago(float $totalDeuda): array
    {
        $opciones = [];
        
        $plazos = [3, 6, 12, 18, 24];
        
        foreach ($plazos as $cuotas) {
            $cuotaMensual = $totalDeuda / $cuotas;
            
            $opciones[] = [
                'cuotas' => $cuotas,
                'monto_cuota' => round($cuotaMensual, 0),
                'total_a_pagar' => round($totalDeuda, 0),
                'fecha_primera_cuota' => Carbon::now()->addMonth()->format('Y-m-d'),
                'fecha_ultima_cuota' => Carbon::now()->addMonths($cuotas)->format('Y-m-d'),
                'viable' => $cuotaMensual <= 5000000 // Límite referencial
            ];
        }

        return [
            'opciones' => $opciones,
            'requisitos_generales' => [
                'Estar al día en declaraciones',
                'No tener convenios incumplidos',
                'Presentar garantías si deuda > 100 UTM'
            ],
            'nota' => 'Convenios sobre 12 cuotas requieren aprobación especial'
        ];
    }

    /**
     * Compara todos los escenarios posibles
     */
    private function compararEscenarios(array $datosBase): array
    {
        $comparativa = [];
        
        foreach (array_keys(self::ESCENARIOS) as $escenario) {
            $datosEscenario = array_merge($datosBase, ['escenario' => $escenario]);
            
            // Simulación simplificada para cada escenario
            $impuesto = $datosBase['impuesto_adeudado'] ?? 0;
            $meses = Carbon::parse($datosBase['fecha_vencimiento'] ?? now())
                ->diffInMonths(Carbon::now());
            
            $intereses = $this->calcularIntereses($impuesto, $meses);
            $multa = $this->calcularMultaBase($impuesto, $datosBase['tipo_infraccion'] ?? 'retardo_declaracion', $meses);
            $reduccion = $this->calcularFactorReduccion($escenario, false, true);
            $multaFinal = $multa * (1 - $reduccion);
            
            $total = $impuesto + $intereses + $multaFinal;
            
            $comparativa[] = [
                'escenario' => $escenario,
                'nombre' => self::ESCENARIOS[$escenario]['nombre'],
                'total_estimado' => round($total, 0),
                'ahorro_vs_peor' => 0, // Se calcula después
                'reduccion_multa' => round($multa - $multaFinal, 0),
                'recomendado' => in_array($escenario, ['regularizacion_voluntaria', 'primera_infraccion'])
            ];
        }
        
        // Calcular ahorro vs peor escenario
        $peorCaso = max(array_column($comparativa, 'total_estimado'));
        foreach ($comparativa as &$item) {
            $item['ahorro_vs_peor'] = round($peorCaso - $item['total_estimado'], 0);
        }
        
        // Ordenar por total (mejor primero)
        usort($comparativa, fn($a, $b) => $a['total_estimado'] <=> $b['total_estimado']);

        return $comparativa;
    }

    /**
     * Evalúa riesgos del caso
     */
    private function evaluarRiesgos(array $datos, int $mesesAtraso): array
    {
        $riesgos = [];
        
        // Riesgo por tiempo
        if ($mesesAtraso > 36) {
            $riesgos[] = [
                'tipo' => 'TEMPORAL',
                'nivel' => 'CRITICO',
                'descripcion' => 'Omisión prolongada (>3 años) puede calificarse como dolosa',
                'consecuencia' => 'Multas máximas + posible querella'
            ];
        } elseif ($mesesAtraso > 12) {
            $riesgos[] = [
                'tipo' => 'TEMPORAL',
                'nivel' => 'ALTO',
                'descripcion' => 'Omisión superior a 1 año genera multas elevadas',
                'consecuencia' => 'Fiscalización extendida probable'
            ];
        }
        
        // Riesgo por monto
        $impuesto = $datos['impuesto_adeudado'] ?? 0;
        if ($impuesto > 100 * $this->valorUTM) {
            $riesgos[] = [
                'tipo' => 'MONTO',
                'nivel' => 'ALTO',
                'descripcion' => 'Monto superior a 100 UTM',
                'consecuencia' => 'Fiscalización prioritaria, garantías requeridas'
            ];
        }
        
        // Riesgo por tipo de infracción
        if (($datos['tipo_infraccion'] ?? '') === 'declaracion_maliciosa') {
            $riesgos[] = [
                'tipo' => 'PENAL',
                'nivel' => 'CRITICO',
                'descripcion' => 'Declaración maliciosa puede constituir delito tributario',
                'consecuencia' => 'Penas corporales + multas hasta 300%'
            ];
        }
        
        // Riesgo reputacional
        if (($datos['es_persona_expuesta'] ?? false)) {
            $riesgos[] = [
                'tipo' => 'REPUTACIONAL',
                'nivel' => 'ALTO',
                'descripcion' => 'Persona políticamente expuesta o de alta visibilidad',
                'consecuencia' => 'Mayor escrutinio, impacto público'
            ];
        }

        // Calcular score de riesgo global
        $scoreRiesgo = array_reduce($riesgos, function($carry, $r) {
            return $carry + match($r['nivel']) {
                'CRITICO' => 30,
                'ALTO' => 20,
                'MEDIO' => 10,
                default => 5
            };
        }, 0);

        return [
            'score_riesgo' => min($scoreRiesgo, 100),
            'nivel_global' => match(true) {
                $scoreRiesgo >= 60 => 'CRITICO',
                $scoreRiesgo >= 40 => 'ALTO',
                $scoreRiesgo >= 20 => 'MEDIO',
                default => 'BAJO'
            },
            'riesgos_identificados' => $riesgos,
            'total_riesgos' => count($riesgos)
        ];
    }

    /**
     * Genera recomendaciones finales
     */
    private function generarRecomendaciones(array $datos, int $mesesAtraso, float $totalDeuda): array
    {
        $recomendaciones = [];
        
        // Recomendación principal según urgencia
        if ($mesesAtraso <= 3) {
            $recomendaciones[] = [
                'prioridad' => 1,
                'accion' => 'Regularizar inmediatamente',
                'razon' => 'Multas aún son bajas, máximo beneficio por voluntariedad',
                'plazo' => 'Esta semana'
            ];
        } elseif ($mesesAtraso <= 12) {
            $recomendaciones[] = [
                'prioridad' => 1,
                'accion' => 'Preparar regularización con asesoría profesional',
                'razon' => 'Deuda creciendo, pero aún manejable',
                'plazo' => 'Próximas 2 semanas'
            ];
        } else {
            $recomendaciones[] = [
                'prioridad' => 1,
                'accion' => 'Contratar abogado tributarista inmediatamente',
                'razon' => 'Situación compleja requiere estrategia legal',
                'plazo' => 'Inmediato'
            ];
        }
        
        // Recomendación de documentación
        $recomendaciones[] = [
            'prioridad' => 2,
            'accion' => 'Recopilar toda la documentación de respaldo',
            'razon' => 'Fundamental para cualquier negociación con SII',
            'documentos' => [
                'Contratos de arriendo',
                'Comprobantes de pago',
                'Actas de asamblea',
                'Distribución de ingresos'
            ]
        ];
        
        // Recomendación de provisión
        $recomendaciones[] = [
            'prioridad' => 3,
            'accion' => 'Provisionar fondos para pago',
            'razon' => 'Capacidad de pago mejora posición negociadora',
            'monto_sugerido' => round($totalDeuda * 0.7, 0) // 70% como mínimo
        ];
        
        // Recomendación preventiva
        $recomendaciones[] = [
            'prioridad' => 4,
            'accion' => 'Implementar sistema de control tributario',
            'razon' => 'Evitar reincidencia y mantener cumplimiento',
            'herramienta' => 'DATAPOLIS PRO - Módulo Tributario'
        ];

        return $recomendaciones;
    }

    /**
     * Simula múltiples periodos tributarios
     */
    public function simularMultiplesPeriodos(array $periodos): array
    {
        $resultados = [];
        $totalGeneral = 0;
        
        foreach ($periodos as $periodo) {
            $simulacion = $this->simularSancion($periodo);
            $resultados[] = [
                'periodo' => $periodo['periodo'] ?? 'N/A',
                'impuesto' => $periodo['impuesto_adeudado'],
                'total_deuda' => $simulacion['total']['total_a_pagar_clp'],
                'simulacion_completa' => $simulacion
            ];
            $totalGeneral += $simulacion['total']['total_a_pagar_clp'];
        }

        return [
            'periodos_analizados' => count($periodos),
            'total_consolidado' => round($totalGeneral, 0),
            'total_utm' => round($totalGeneral / $this->valorUTM, 2),
            'detalle_por_periodo' => $resultados,
            'estrategia_consolidada' => $this->generarEstrategiaConsolidada($totalGeneral, count($periodos))
        ];
    }

    /**
     * Genera estrategia para múltiples periodos
     */
    private function generarEstrategiaConsolidada(float $totalDeuda, int $numPeriodos): array
    {
        return [
            'enfoque' => $numPeriodos > 3 ? 'NEGOCIACION_GLOBAL' : 'POR_PERIODO',
            'descripcion' => $numPeriodos > 3 
                ? 'Con múltiples periodos, conviene negociar solución integral con SII'
                : 'Regularizar periodo por periodo comenzando por el más antiguo',
            'ventaja' => 'Posible mayor condonación por regularización integral',
            'convenio_sugerido' => [
                'cuotas' => min($numPeriodos * 6, 24),
                'monto_cuota' => round($totalDeuda / min($numPeriodos * 6, 24), 0)
            ]
        ];
    }

    /**
     * Actualiza valores de referencia (UTM, UF)
     */
    public function actualizarValores(float $utm, float $uf): void
    {
        $this->valorUTM = $utm;
        $this->valorUF = $uf;
        
        Log::info('Valores actualizados', [
            'utm' => $utm,
            'uf' => $uf
        ]);
    }
}
