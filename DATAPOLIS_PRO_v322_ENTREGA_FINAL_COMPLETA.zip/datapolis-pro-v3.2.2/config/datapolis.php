<?php

return [

    /*
    |--------------------------------------------------------------------------
    | DATAPOLIS PRO - Configuración del Sistema
    |--------------------------------------------------------------------------
    |
    | Configuración específica para la administración de condominios en Chile
    | cumpliendo con Ley 21.442, Ley 21.713, Ley 21.719 y Código del Trabajo
    |
    */

    // =========================================================================
    // CONFIGURACIÓN GENERAL
    // =========================================================================

    'tenant_default' => env('DATAPOLIS_TENANT_DEFAULT', 1),

    // =========================================================================
    // GASTOS COMUNES - LEY 21.442
    // =========================================================================

    'gastos_comunes' => [
        // Interés máximo por mora (Art. 5 Ley 21.442)
        'interes_mora_maximo' => env('DATAPOLIS_INTERES_MORA_MAX', 3), // 3% mensual
        
        // Días de gracia antes de aplicar mora
        'dias_gracia' => env('DATAPOLIS_DIAS_GRACIA', 5),
        
        // Método de cálculo de interés
        'metodo_interes' => 'simple', // 'simple' o 'compuesto'
        
        // Fondo de reserva mínimo (% del presupuesto)
        'fondo_reserva_minimo' => 5,
    ],

    // =========================================================================
    // VALORES TRIBUTARIOS CHILE 2024
    // =========================================================================

    'tributario' => [
        'uf' => env('UF_VALOR', 37000),
        'utm' => env('UTM_VALOR', 65000),
        'uta' => env('UTA_VALOR', 780000),
        'sueldo_minimo' => env('SUELDO_MINIMO', 460000),
        
        // Topes imponibles (en UF)
        'tope_imponible_afp' => env('TOPE_IMPONIBLE_AFP', 81.6),
        'tope_imponible_seguro_cesantia' => env('TOPE_IMPONIBLE_SEGURO_CESANTIA', 126.6),
        
        // Tasas AFP 2024
        'tasas_afp' => [
            'capital' => 11.44,
            'cuprum' => 11.44,
            'habitat' => 11.27,
            'modelo' => 10.58,
            'planvital' => 11.16,
            'provida' => 11.45,
            'uno' => 10.69,
        ],
        
        // Tasa seguro de cesantía
        'seguro_cesantia' => [
            'trabajador' => 0.6,
            'empleador_indefinido' => 2.4,
            'empleador_plazo_fijo' => 3.0,
        ],
        
        // Impuesto único segunda categoría 2024
        'impuesto_unico' => [
            ['desde' => 0, 'hasta' => 13.5, 'tasa' => 0, 'rebaja' => 0],
            ['desde' => 13.5, 'hasta' => 30, 'tasa' => 4, 'rebaja' => 0.54],
            ['desde' => 30, 'hasta' => 50, 'tasa' => 8, 'rebaja' => 1.74],
            ['desde' => 50, 'hasta' => 70, 'tasa' => 13.5, 'rebaja' => 4.49],
            ['desde' => 70, 'hasta' => 90, 'tasa' => 23, 'rebaja' => 11.14],
            ['desde' => 90, 'hasta' => 120, 'tasa' => 30.4, 'rebaja' => 17.8],
            ['desde' => 120, 'hasta' => 310, 'tasa' => 35, 'rebaja' => 23.32],
            ['desde' => 310, 'hasta' => PHP_FLOAT_MAX, 'tasa' => 40, 'rebaja' => 38.82],
        ],
    ],

    // =========================================================================
    // SANCIONES - ART. 97 N°2 CÓDIGO TRIBUTARIO
    // =========================================================================

    'sanciones' => [
        'art_97_n2' => [
            'multa_minima_utm' => 0.5,
            'multa_maxima_utm' => 1.0,
            'multa_por_mes' => 2, // 2% por mes o fracción
            'tope_multa_porcentaje' => 30, // Máximo 30% del impuesto
            'reajuste' => true, // Aplicar reajuste IPC
        ],
    ],

    // =========================================================================
    // PROTECCIÓN DE DATOS - LEY 21.719
    // =========================================================================

    'proteccion_datos' => [
        // Plazo máximo para responder solicitudes ARCO (días hábiles)
        'plazo_arco' => 10,
        
        // Extensión máxima del plazo (días hábiles)
        'extension_arco' => 10,
        
        // Retención de logs de acceso (días)
        'retencion_logs' => 365,
        
        // Categorías de datos sensibles
        'datos_sensibles' => [
            'salud',
            'origen_etnico',
            'afiliacion_politica',
            'religion',
            'orientacion_sexual',
            'datos_biometricos',
            'datos_geneticos',
        ],
    ],

    // =========================================================================
    // ASAMBLEAS - LEY 21.442
    // =========================================================================

    'asambleas' => [
        // Quórums (en porcentaje de derechos)
        'quorum' => [
            'primera_citacion' => 60,
            'segunda_citacion' => 33.33,
            'extraordinaria' => 66.67,
            'unanimidad' => 100,
        ],
        
        // Anticipación mínima de citación (días)
        'anticipacion_citacion' => 5,
        
        // Habilitar asambleas telemáticas
        'telemática_habilitada' => true,
    ],

    // =========================================================================
    // NOTIFICACIONES
    // =========================================================================

    'notificaciones' => [
        // Canales habilitados
        'canales' => ['email', 'push', 'sms', 'database'],
        
        // Reintentos máximos
        'max_reintentos' => 3,
        
        // Tiempo entre reintentos (minutos)
        'intervalo_reintento' => 15,
        
        // Retención de historial (días)
        'retencion_historial' => 90,
    ],

    // =========================================================================
    // PAGOS ONLINE
    // =========================================================================

    'pagos' => [
        // Pasarelas habilitadas
        'pasarelas' => ['webpay', 'khipu'],
        
        // Monto mínimo de pago (CLP)
        'monto_minimo' => 1000,
        
        // Monto máximo por transacción (CLP)
        'monto_maximo' => 10000000,
        
        // Tiempo de expiración de transacción (minutos)
        'expiracion_transaccion' => 120,
        
        // WebPay
        'webpay' => [
            'environment' => env('WEBPAY_ENVIRONMENT', 'integration'),
            'commerce_code' => env('WEBPAY_COMMERCE_CODE'),
            'api_key' => env('WEBPAY_API_KEY'),
        ],
        
        // Khipu
        'khipu' => [
            'environment' => env('KHIPU_ENVIRONMENT', 'sandbox'),
            'receiver_id' => env('KHIPU_RECEIVER_ID'),
            'secret' => env('KHIPU_SECRET'),
        ],
    ],

    // =========================================================================
    // PORTAL COPROPIETARIOS
    // =========================================================================

    'portal' => [
        // Sesión (días)
        'sesion_duracion' => 7,
        
        // Intentos de login antes de bloqueo
        'max_intentos_login' => 5,
        
        // Tiempo de bloqueo (minutos)
        'tiempo_bloqueo' => 30,
        
        // Reservas máximas por mes por unidad
        'reservas_maximas_mes' => 2,
    ],

    // =========================================================================
    // CERTIFICADOS Y COMPLIANCE
    // =========================================================================

    'certificados' => [
        // Vigencia de certificados (días)
        'vigencia_no_deuda' => 30,
        'vigencia_compliance' => 365,
        
        // Algoritmo de hash para verificación
        'hash_algorithm' => 'sha256',
    ],

];
