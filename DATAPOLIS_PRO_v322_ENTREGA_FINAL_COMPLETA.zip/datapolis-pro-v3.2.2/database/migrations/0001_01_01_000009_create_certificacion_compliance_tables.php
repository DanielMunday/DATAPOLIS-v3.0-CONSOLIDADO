<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migración para Módulo de Certificación, Análisis de Reglamentos y Simulación de Sanciones
 * 
 * Tablas:
 * - certificaciones_compliance: Certificaciones de cumplimiento integral
 * - reglamentos_copropiedad: Registro de reglamentos
 * - analisis_reglamentos: Análisis de cumplimiento de reglamentos
 * - simulaciones_sanciones: Simulaciones de sanciones tributarias
 * 
 * @package DATAPOLIS PRO v2.5
 */
return new class extends Migration
{
    public function up(): void
    {
        // =============================================
        // TABLA: CERTIFICACIONES DE COMPLIANCE
        // =============================================
        Schema::create('certificaciones_compliance', function (Blueprint $table) {
            $table->id();
            $table->string('numero_certificacion', 50)->unique();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            $table->year('anio_tributario');
            $table->integer('score_total')->default(0);
            $table->enum('estado', ['OPTIMO', 'REGULAR', 'DEFICIENTE', 'CRITICO'])->default('REGULAR');
            
            // Evaluaciones detalladas (JSON)
            $table->json('evaluaciones')->nullable()->comment('Evaluaciones por ley');
            $table->json('alertas')->nullable()->comment('Alertas generadas');
            $table->json('recomendaciones')->nullable()->comment('Recomendaciones de acción');
            $table->json('documentos')->nullable()->comment('Documentos generados');
            
            // Fechas
            $table->timestamp('fecha_vencimiento')->nullable();
            $table->timestamps();
            
            // Índices
            $table->index(['edificio_id', 'anio_tributario']);
            $table->index('estado');
        });

        // =============================================
        // TABLA: REGLAMENTOS DE COPROPIEDAD
        // =============================================
        Schema::create('reglamentos_copropiedad', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            
            // Datos de inscripción CBR
            $table->date('fecha_inscripcion')->nullable();
            $table->string('numero_inscripcion', 50)->nullable();
            $table->string('fojas', 20)->nullable();
            $table->string('numero', 20)->nullable();
            $table->year('anio_inscripcion')->nullable();
            $table->string('conservador', 200)->nullable();
            
            // Estado
            $table->enum('estado', [
                'ACTUALIZADO',
                'REQUIERE_ACTUALIZACION',
                'DESACTUALIZADO',
                'EN_PROCESO'
            ])->default('DESACTUALIZADO');
            
            // Contenido
            $table->text('contenido_texto')->nullable()->comment('Texto OCR del reglamento');
            $table->string('archivo_pdf', 255)->nullable();
            $table->string('hash_documento', 64)->nullable();
            
            // Metadatos
            $table->json('clausulas_identificadas')->nullable();
            $table->json('modificaciones_pendientes')->nullable();
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['edificio_id', 'estado']);
        });

        // =============================================
        // TABLA: ANÁLISIS DE REGLAMENTOS
        // =============================================
        Schema::create('analisis_reglamentos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            $table->timestamp('fecha_analisis');
            
            // Resultados del análisis
            $table->enum('estado', [
                'ACTUALIZADO',
                'REQUIERE_ACTUALIZACION',
                'DESACTUALIZADO',
                'INEXISTENTE'
            ])->default('DESACTUALIZADO');
            
            $table->integer('score_cumplimiento')->default(0);
            
            // Detalles (JSON)
            $table->json('cumplimiento_legal')->nullable()->comment('Evaluación artículos Ley 21.442');
            $table->json('clausulas_antenas')->nullable()->comment('Análisis cláusulas telecomunicaciones');
            $table->json('modificaciones_sugeridas')->nullable()->comment('Propuestas de modificación');
            $table->json('conclusion')->nullable()->comment('Conclusión general');
            $table->json('plan_actualizacion')->nullable()->comment('Plan de actualización');
            
            $table->timestamps();
            
            $table->index(['edificio_id', 'fecha_analisis']);
        });

        // =============================================
        // TABLA: SIMULACIONES DE SANCIONES
        // =============================================
        Schema::create('simulaciones_sanciones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            $table->year('anio');
            
            // Datos de la simulación (JSON)
            $table->json('datos_base')->nullable()->comment('Datos base para cálculo');
            $table->json('escenarios')->nullable()->comment('5 escenarios simulados');
            $table->json('resumen')->nullable()->comment('Resumen comparativo');
            $table->json('ahorro_potencial')->nullable()->comment('Cálculo ROI DATAPOLIS');
            $table->json('recomendacion')->nullable()->comment('Recomendaciones');
            
            $table->timestamps();
            
            $table->index(['edificio_id', 'anio']);
        });

        // =============================================
        // TABLA: PROPUESTAS DE REDACCIÓN
        // =============================================
        Schema::create('propuestas_redaccion', function (Blueprint $table) {
            $table->id();
            $table->foreignId('analisis_id')->constrained('analisis_reglamentos')->cascadeOnDelete();
            
            $table->string('codigo', 50)->comment('Código del elemento crítico');
            $table->string('titulo', 255);
            $table->text('texto_propuesto');
            $table->string('fundamentacion', 255)->nullable();
            $table->enum('tipo', ['agregar', 'modificar', 'eliminar'])->default('agregar');
            $table->enum('prioridad', ['alta', 'media', 'baja'])->default('media');
            $table->enum('estado', ['pendiente', 'aprobada', 'rechazada', 'implementada'])->default('pendiente');
            
            $table->timestamps();
        });

        // =============================================
        // TABLA: HISTORIAL DE ACTUALIZACIONES DE REGLAMENTO
        // =============================================
        Schema::create('historial_reglamentos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('reglamento_id')->constrained('reglamentos_copropiedad')->cascadeOnDelete();
            
            $table->date('fecha_modificacion');
            $table->string('tipo_modificacion', 100);
            $table->text('descripcion');
            $table->string('acta_asamblea', 100)->nullable()->comment('Referencia al acta');
            $table->string('escritura_publica', 100)->nullable();
            $table->string('inscripcion_cbr', 100)->nullable();
            
            $table->foreignId('usuario_id')->nullable()->constrained('users');
            
            $table->timestamps();
        });

        // =============================================
        // TABLA: ALERTAS DE CUMPLIMIENTO
        // =============================================
        Schema::create('alertas_cumplimiento', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            $table->foreignId('certificacion_id')->nullable()->constrained('certificaciones_compliance');
            
            $table->string('codigo', 20);
            $table->enum('tipo', ['critico', 'advertencia', 'informativo'])->default('informativo');
            $table->string('mensaje', 500);
            $table->string('evaluacion', 50)->nullable();
            $table->date('fecha_vencimiento')->nullable();
            
            $table->boolean('leida')->default(false);
            $table->boolean('resuelta')->default(false);
            $table->timestamp('fecha_resolucion')->nullable();
            $table->text('notas_resolucion')->nullable();
            
            $table->timestamps();
            
            $table->index(['edificio_id', 'resuelta']);
            $table->index('tipo');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('alertas_cumplimiento');
        Schema::dropIfExists('historial_reglamentos');
        Schema::dropIfExists('propuestas_redaccion');
        Schema::dropIfExists('simulaciones_sanciones');
        Schema::dropIfExists('analisis_reglamentos');
        Schema::dropIfExists('reglamentos_copropiedad');
        Schema::dropIfExists('certificaciones_compliance');
    }
};
