<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migración: Análisis de Reglamentos de Copropiedad
 * 
 * Almacena resultados de análisis de reglamentos según Ley 21.442 y DS 7-2025
 * 
 * @package DATAPOLIS PRO v3.0
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('analisis_reglamentos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->constrained('edificios')->onDelete('cascade');
            $table->foreignId('usuario_id')->nullable()->constrained('users')->onDelete('set null');
            
            // Resultados del análisis
            $table->decimal('score_global', 5, 2)->comment('Score 0-100');
            $table->enum('nivel_cumplimiento', ['EXCELENTE', 'BUENO', 'REGULAR', 'DEFICIENTE', 'CRÍTICO']);
            $table->unsignedTinyInteger('elementos_ok')->default(0);
            $table->unsignedTinyInteger('elementos_faltantes')->default(0);
            
            // Datos del reglamento analizado
            $table->date('fecha_inscripcion_cbr')->nullable();
            $table->string('notaria', 255)->nullable();
            $table->string('numero_inscripcion', 100)->nullable();
            
            // Resultado completo en JSON
            $table->json('resultado_completo');
            
            // Auditoría
            $table->timestamps();
            
            // Índices
            $table->index(['edificio_id', 'created_at']);
            $table->index('nivel_cumplimiento');
        });

        // Agregar comentario a la tabla
        \DB::statement("ALTER TABLE analisis_reglamentos COMMENT 'Análisis de reglamentos según Ley 21.442 y DS 7-2025'");
    }

    public function down(): void
    {
        Schema::dropIfExists('analisis_reglamentos');
    }
};
