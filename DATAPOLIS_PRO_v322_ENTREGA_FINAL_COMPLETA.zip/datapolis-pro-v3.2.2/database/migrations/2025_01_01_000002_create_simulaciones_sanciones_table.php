<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migración: Simulaciones de Sanciones Tributarias
 * 
 * Almacena simulaciones de sanciones Art. 97 N°2 Código Tributario
 * 
 * @package DATAPOLIS PRO v3.0
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('simulaciones_sanciones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->constrained('edificios')->onDelete('cascade');
            $table->foreignId('usuario_id')->nullable()->constrained('users')->onDelete('set null');
            
            // Parámetros de entrada
            $table->decimal('monto_impuesto_original', 15, 2);
            $table->enum('tipo_infraccion', ['retardo', 'omision', 'incompleta', 'maliciosa']);
            $table->date('fecha_vencimiento');
            $table->unsignedSmallInteger('meses_atraso');
            $table->string('escenario', 50)->nullable()->comment('regularizacion_voluntaria, fiscalizacion, etc.');
            
            // Resultados calculados
            $table->decimal('total_deuda_clp', 15, 2);
            $table->decimal('total_deuda_utm', 10, 4);
            $table->decimal('total_deuda_uf', 10, 4)->nullable();
            
            // Desglose
            $table->decimal('multa_clp', 15, 2)->nullable();
            $table->decimal('intereses_clp', 15, 2)->nullable();
            $table->decimal('reajuste_clp', 15, 2)->nullable();
            
            // Resultado completo
            $table->json('resultado_completo');
            
            // Seguimiento
            $table->boolean('regularizado')->default(false);
            $table->date('fecha_regularizacion')->nullable();
            $table->text('notas')->nullable();
            
            $table->timestamps();
            
            // Índices
            $table->index(['edificio_id', 'created_at']);
            $table->index('tipo_infraccion');
            $table->index('regularizado');
        });

        \DB::statement("ALTER TABLE simulaciones_sanciones COMMENT 'Simulaciones Art. 97 N°2 Código Tributario'");
    }

    public function down(): void
    {
        Schema::dropIfExists('simulaciones_sanciones');
    }
};
