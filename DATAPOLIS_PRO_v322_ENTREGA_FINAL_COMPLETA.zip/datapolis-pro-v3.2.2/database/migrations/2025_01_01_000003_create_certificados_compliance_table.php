<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migración: Certificados de Compliance
 * 
 * Almacena certificados emitidos para cumplimiento normativo
 * 
 * @package DATAPOLIS PRO v3.0
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('certificados_compliance', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->constrained('edificios')->onDelete('cascade');
            $table->foreignId('emitido_por')->nullable()->constrained('users')->onDelete('set null');
            
            // Identificación del certificado
            $table->string('codigo', 50)->unique()->comment('Código único verificable');
            $table->enum('tipo', [
                'COMPLIANCE_INTEGRAL',
                'LEY_21442',
                'TRIBUTARIO',
                'PROTECCION_DATOS',
                'DISTRIBUCION_RENTAS',
                'NO_DEUDA',
                'RENTA_DISTRIBUIDA'
            ]);
            
            // Estado y evaluación
            $table->enum('estado', ['APROBADO', 'CONDICIONAL', 'RECHAZADO']);
            $table->decimal('score_global', 5, 2);
            $table->enum('nivel_cumplimiento', ['EXCELENTE', 'BUENO', 'ACEPTABLE', 'DEFICIENTE', 'CRÍTICO']);
            
            // Vigencia
            $table->date('fecha_vencimiento');
            $table->string('periodo', 20)->nullable()->comment('Año o mes del periodo certificado');
            
            // Verificación
            $table->string('hash_verificacion', 64)->comment('SHA-256 para autenticidad');
            $table->string('url_verificacion', 255);
            
            // Datos adicionales
            $table->json('evaluacion_json')->comment('Evaluación detallada por módulos');
            $table->text('observaciones')->nullable();
            
            // Para certificados de copropietario específico
            $table->foreignId('copropietario_id')->nullable()->constrained('copropietarios')->onDelete('cascade');
            $table->foreignId('unidad_id')->nullable()->constrained('unidades')->onDelete('cascade');
            
            // Auditoría
            $table->timestamps();
            $table->softDeletes();
            
            // Índices
            $table->index(['edificio_id', 'tipo']);
            $table->index(['edificio_id', 'fecha_vencimiento']);
            $table->index('estado');
            $table->index('codigo');
        });

        \DB::statement("ALTER TABLE certificados_compliance COMMENT 'Certificados de cumplimiento normativo'");
    }

    public function down(): void
    {
        Schema::dropIfExists('certificados_compliance');
    }
};
