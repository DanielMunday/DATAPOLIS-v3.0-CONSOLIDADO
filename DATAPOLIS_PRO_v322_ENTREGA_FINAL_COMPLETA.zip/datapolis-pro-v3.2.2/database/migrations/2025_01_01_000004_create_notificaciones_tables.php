<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migración: Sistema de Notificaciones Multicanal
 * 
 * Incluye: historial, preferencias, suscripciones push, programadas
 * 
 * @package DATAPOLIS PRO v3.0
 */
return new class extends Migration
{
    public function up(): void
    {
        // 1. Historial de notificaciones enviadas
        Schema::create('historial_notificaciones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->constrained('edificios')->onDelete('cascade');
            $table->foreignId('copropietario_id')->nullable()->constrained('copropietarios')->onDelete('cascade');
            
            // Tipo y contenido
            $table->string('tipo', 50)->comment('BOLETA_EMITIDA, CONVOCATORIA, etc.');
            $table->string('categoria', 30)->comment('gastos_comunes, asambleas, etc.');
            $table->enum('canal', ['email', 'push', 'whatsapp', 'sms']);
            $table->enum('prioridad', ['critica', 'alta', 'media', 'baja'])->default('media');
            
            // Contenido enviado
            $table->string('asunto', 255)->nullable();
            $table->text('contenido_resumen')->nullable()->comment('Resumen del contenido enviado');
            $table->json('datos_envio')->nullable()->comment('Datos completos del envío');
            
            // Estado
            $table->enum('estado', ['pendiente', 'enviado', 'fallido', 'entregado', 'leido'])->default('pendiente');
            $table->text('error_mensaje')->nullable();
            $table->string('proveedor_id', 100)->nullable()->comment('ID del proveedor (Mailgun, etc.)');
            
            // Timestamps
            $table->timestamp('enviado_at')->nullable();
            $table->timestamp('entregado_at')->nullable();
            $table->timestamp('leido_at')->nullable();
            $table->timestamps();
            
            // Índices
            $table->index(['edificio_id', 'created_at']);
            $table->index(['copropietario_id', 'created_at']);
            $table->index(['tipo', 'estado']);
            $table->index('canal');
        });

        // 2. Preferencias de notificación por copropietario
        Schema::create('preferencias_notificaciones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropietario_id')->unique()->constrained('copropietarios')->onDelete('cascade');
            
            // Configuración completa en JSON
            $table->json('configuracion')->comment('Preferencias por categoría y canal');
            
            // Horario de silencio
            $table->boolean('horario_silencio_activo')->default(true);
            $table->time('horario_silencio_desde')->default('22:00:00');
            $table->time('horario_silencio_hasta')->default('08:00:00');
            
            // Idioma preferido
            $table->string('idioma', 5)->default('es');
            
            // Opt-out global
            $table->boolean('desuscrito_global')->default(false);
            $table->timestamp('desuscrito_at')->nullable();
            
            $table->timestamps();
        });

        // 3. Suscripciones push web
        Schema::create('push_subscriptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropietario_id')->constrained('copropietarios')->onDelete('cascade');
            
            // Datos de suscripción Web Push
            $table->text('endpoint');
            $table->string('p256dh', 255)->comment('Clave pública');
            $table->string('auth', 100)->comment('Token de autenticación');
            
            // Metadata
            $table->string('dispositivo', 100)->nullable()->comment('Navegador/dispositivo');
            $table->string('user_agent', 255)->nullable();
            $table->ipAddress('ip')->nullable();
            
            // Estado
            $table->boolean('activo')->default(true);
            $table->timestamp('ultimo_uso')->nullable();
            $table->unsignedInteger('fallos_consecutivos')->default(0);
            
            $table->timestamps();
            
            // Índices
            $table->index('copropietario_id');
            $table->index('activo');
            $table->unique(['copropietario_id', 'endpoint']);
        });

        // 4. Notificaciones programadas
        Schema::create('notificaciones_programadas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->constrained('edificios')->onDelete('cascade');
            $table->foreignId('copropietario_id')->nullable()->constrained('copropietarios')->onDelete('cascade');
            $table->foreignId('creado_por')->constrained('users')->onDelete('cascade');
            
            // Tipo y datos
            $table->string('tipo', 50);
            $table->json('datos');
            $table->json('canales');
            
            // Programación
            $table->timestamp('fecha_envio');
            $table->boolean('es_masivo')->default(false);
            $table->json('filtros_masivo')->nullable();
            
            // Estado
            $table->enum('estado', ['pendiente', 'procesando', 'completada', 'fallida', 'cancelada'])->default('pendiente');
            $table->text('resultado')->nullable();
            
            // Cancelación
            $table->foreignId('cancelada_por')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamp('cancelada_at')->nullable();
            
            // Ejecución
            $table->timestamp('procesada_at')->nullable();
            
            $table->timestamps();
            
            // Índices
            $table->index(['fecha_envio', 'estado']);
            $table->index('edificio_id');
        });

        // 5. Plantillas de notificación personalizables
        Schema::create('plantillas_notificacion', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edificio_id')->nullable()->constrained('edificios')->onDelete('cascade');
            
            // Identificación
            $table->string('tipo', 50);
            $table->enum('canal', ['email', 'push', 'whatsapp', 'sms']);
            $table->string('idioma', 5)->default('es');
            
            // Contenido
            $table->string('asunto', 255)->nullable()->comment('Para email');
            $table->text('contenido')->comment('Plantilla con variables {{variable}}');
            
            // Estado
            $table->boolean('activo')->default(true);
            $table->boolean('es_default')->default(false);
            
            $table->timestamps();
            
            // Índices
            $table->unique(['edificio_id', 'tipo', 'canal', 'idioma']);
            $table->index('tipo');
        });

        // Comentarios
        \DB::statement("ALTER TABLE historial_notificaciones COMMENT 'Historial de todas las notificaciones enviadas'");
        \DB::statement("ALTER TABLE preferencias_notificaciones COMMENT 'Preferencias de notificación por copropietario'");
        \DB::statement("ALTER TABLE push_subscriptions COMMENT 'Suscripciones Web Push por dispositivo'");
        \DB::statement("ALTER TABLE notificaciones_programadas COMMENT 'Cola de notificaciones programadas para envío futuro'");
        \DB::statement("ALTER TABLE plantillas_notificacion COMMENT 'Plantillas personalizables de notificación'");
    }

    public function down(): void
    {
        Schema::dropIfExists('plantillas_notificacion');
        Schema::dropIfExists('notificaciones_programadas');
        Schema::dropIfExists('push_subscriptions');
        Schema::dropIfExists('preferencias_notificaciones');
        Schema::dropIfExists('historial_notificaciones');
    }
};
