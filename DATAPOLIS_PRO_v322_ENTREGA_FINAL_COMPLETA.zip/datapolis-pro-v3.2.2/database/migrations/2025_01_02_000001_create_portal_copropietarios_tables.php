<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * DATAPOLIS PRO v3.0 - Portal Copropietarios y Pagos Online
     * Fase 2: Sistema completo de autogestión para copropietarios
     */
    public function up(): void
    {
        // =====================================================
        // 1. ACCESOS PORTAL COPROPIETARIOS
        // =====================================================
        Schema::create('accesos_portal', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('copropietario_id')->constrained('personas')->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained('unidades')->cascadeOnDelete();
            
            // Credenciales
            $table->string('email')->unique();
            $table->string('password');
            $table->string('pin', 6)->nullable()->comment('PIN para app móvil');
            $table->boolean('activo')->default(true);
            $table->boolean('email_verificado')->default(false);
            $table->timestamp('email_verificado_at')->nullable();
            $table->string('token_verificacion', 64)->nullable();
            
            // Seguridad
            $table->string('remember_token', 100)->nullable();
            $table->timestamp('ultimo_acceso')->nullable();
            $table->string('ultimo_ip', 45)->nullable();
            $table->string('ultimo_dispositivo')->nullable();
            $table->integer('intentos_fallidos')->default(0);
            $table->timestamp('bloqueado_hasta')->nullable();
            
            // Preferencias
            $table->json('preferencias')->nullable()->comment('Notificaciones, idioma, etc.');
            $table->boolean('acepta_notificaciones_email')->default(true);
            $table->boolean('acepta_notificaciones_push')->default(true);
            $table->boolean('acepta_notificaciones_sms')->default(false);
            
            // Multi-unidad
            $table->boolean('es_principal')->default(true)->comment('Acceso principal si tiene múltiples unidades');
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['tenant_id', 'email']);
            $table->index(['copropietario_id', 'unidad_id']);
        });

        // =====================================================
        // 2. SESIONES PORTAL
        // =====================================================
        Schema::create('sesiones_portal', function (Blueprint $table) {
            $table->id();
            $table->foreignId('acceso_id')->constrained('accesos_portal')->cascadeOnDelete();
            $table->string('token', 64)->unique();
            $table->string('ip', 45);
            $table->string('user_agent')->nullable();
            $table->string('dispositivo')->nullable()->comment('mobile, desktop, tablet');
            $table->string('navegador')->nullable();
            $table->string('sistema_operativo')->nullable();
            $table->timestamp('expira_at');
            $table->timestamp('ultima_actividad')->nullable();
            $table->boolean('activa')->default(true);
            $table->timestamps();
            
            $table->index(['token', 'activa']);
            $table->index('expira_at');
        });

        // =====================================================
        // 3. TRANSACCIONES DE PAGO
        // =====================================================
        Schema::create('transacciones_pago', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained('unidades')->cascadeOnDelete();
            $table->foreignId('acceso_id')->nullable()->constrained('accesos_portal')->nullOnDelete();
            
            // Identificación
            $table->string('codigo_transaccion', 32)->unique();
            $table->string('orden_compra', 26)->unique()->comment('ID único para pasarela');
            
            // Tipo y estado
            $table->enum('tipo', ['gasto_comun', 'multa', 'fondo_reserva', 'otro']);
            $table->enum('estado', [
                'pendiente',      // Creada, esperando pago
                'procesando',     // En proceso con pasarela
                'aprobada',       // Pago exitoso
                'rechazada',      // Pago rechazado
                'anulada',        // Anulada por usuario/admin
                'reembolsada',    // Dinero devuelto
                'expirada'        // Tiempo límite excedido
            ])->default('pendiente');
            
            // Montos
            $table->decimal('monto_original', 12, 2);
            $table->decimal('monto_interes', 12, 2)->default(0);
            $table->decimal('monto_descuento', 12, 2)->default(0);
            $table->decimal('monto_total', 12, 2);
            $table->string('moneda', 3)->default('CLP');
            
            // Pasarela de pago
            $table->enum('pasarela', ['webpay', 'khipu', 'transferencia', 'efectivo', 'cheque']);
            $table->string('pasarela_id')->nullable()->comment('ID de transacción en pasarela');
            $table->string('pasarela_token')->nullable();
            $table->json('pasarela_respuesta')->nullable()->comment('Respuesta completa de pasarela');
            
            // WebPay específico
            $table->string('webpay_token', 64)->nullable();
            $table->string('webpay_authorization_code', 6)->nullable();
            $table->string('webpay_card_number', 4)->nullable()->comment('Últimos 4 dígitos');
            $table->string('webpay_payment_type')->nullable();
            $table->integer('webpay_installments')->nullable();
            
            // Khipu específico
            $table->string('khipu_payment_id', 12)->nullable();
            $table->string('khipu_payment_url')->nullable();
            $table->string('khipu_simplified_url')->nullable();
            $table->string('khipu_app_url')->nullable();
            $table->string('khipu_notification_token', 64)->nullable();
            
            // Boletas asociadas
            $table->json('boletas_ids')->nullable()->comment('IDs de boletas pagadas');
            
            // Comprobante
            $table->string('comprobante_numero')->nullable();
            $table->string('comprobante_url')->nullable();
            $table->timestamp('comprobante_enviado_at')->nullable();
            
            // Fechas
            $table->timestamp('iniciada_at')->nullable();
            $table->timestamp('completada_at')->nullable();
            $table->timestamp('expira_at')->nullable();
            
            // Auditoría
            $table->string('ip_origen', 45)->nullable();
            $table->string('user_agent')->nullable();
            $table->text('notas')->nullable();
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['tenant_id', 'estado']);
            $table->index(['unidad_id', 'estado']);
            $table->index('orden_compra');
            $table->index('pasarela_id');
            $table->index('webpay_token');
            $table->index('khipu_payment_id');
        });

        // =====================================================
        // 4. CONFIGURACIÓN PASARELAS DE PAGO
        // =====================================================
        Schema::create('configuracion_pasarelas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('edificio_id')->nullable()->constrained('edificios')->nullOnDelete();
            
            // Pasarela
            $table->enum('pasarela', ['webpay', 'khipu']);
            $table->boolean('activa')->default(false);
            $table->boolean('modo_produccion')->default(false);
            
            // Credenciales (encriptadas)
            $table->text('api_key')->nullable();
            $table->text('api_secret')->nullable();
            $table->string('commerce_code', 20)->nullable()->comment('WebPay commerce code');
            $table->string('receiver_id', 20)->nullable()->comment('Khipu receiver ID');
            
            // URLs de callback
            $table->string('url_retorno')->nullable();
            $table->string('url_final')->nullable();
            $table->string('url_notificacion')->nullable();
            
            // Configuración
            $table->json('configuracion')->nullable()->comment('Configuración adicional');
            $table->decimal('comision_porcentaje', 5, 2)->default(0);
            $table->decimal('comision_fija', 10, 2)->default(0);
            $table->decimal('monto_minimo', 10, 2)->default(1000);
            $table->decimal('monto_maximo', 12, 2)->default(10000000);
            
            $table->timestamps();
            
            $table->unique(['tenant_id', 'edificio_id', 'pasarela']);
        });

        // =====================================================
        // 5. SOLICITUDES DE COPROPIETARIOS
        // =====================================================
        Schema::create('solicitudes_copropietarios', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained('unidades')->cascadeOnDelete();
            $table->foreignId('acceso_id')->constrained('accesos_portal')->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            
            // Identificación
            $table->string('numero_ticket', 20)->unique();
            
            // Categorización
            $table->enum('tipo', [
                'reclamo',
                'sugerencia', 
                'consulta',
                'solicitud_reparacion',
                'solicitud_certificado',
                'solicitud_documentos',
                'denuncia',
                'felicitacion',
                'otro'
            ]);
            $table->enum('categoria', [
                'administracion',
                'mantencion',
                'seguridad',
                'areas_comunes',
                'ruidos_molestias',
                'estacionamientos',
                'mascotas',
                'gastos_comunes',
                'otro'
            ]);
            $table->enum('prioridad', ['baja', 'media', 'alta', 'urgente'])->default('media');
            
            // Contenido
            $table->string('asunto', 200);
            $table->text('descripcion');
            $table->json('archivos_adjuntos')->nullable()->comment('URLs de archivos');
            
            // Estado y seguimiento
            $table->enum('estado', [
                'abierta',
                'en_revision',
                'en_proceso',
                'pendiente_respuesta',
                'resuelta',
                'cerrada',
                'rechazada'
            ])->default('abierta');
            $table->foreignId('asignado_a')->nullable()->constrained('users')->nullOnDelete();
            
            // Respuesta
            $table->text('respuesta')->nullable();
            $table->timestamp('respondida_at')->nullable();
            $table->foreignId('respondida_por')->nullable()->constrained('users')->nullOnDelete();
            
            // Satisfacción
            $table->tinyInteger('calificacion')->nullable()->comment('1-5 estrellas');
            $table->text('comentario_calificacion')->nullable();
            
            // Fechas
            $table->timestamp('fecha_limite')->nullable();
            $table->timestamp('primera_respuesta_at')->nullable();
            $table->timestamp('cerrada_at')->nullable();
            
            // Visibilidad
            $table->boolean('visible_otros_copropietarios')->default(false);
            $table->boolean('es_anonima')->default(false);
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['tenant_id', 'estado']);
            $table->index(['edificio_id', 'tipo', 'estado']);
            $table->index('numero_ticket');
        });

        // =====================================================
        // 6. SEGUIMIENTO DE SOLICITUDES
        // =====================================================
        Schema::create('seguimiento_solicitudes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('solicitud_id')->constrained('solicitudes_copropietarios')->cascadeOnDelete();
            $table->foreignId('usuario_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('acceso_id')->nullable()->constrained('accesos_portal')->nullOnDelete();
            
            $table->enum('tipo', [
                'comentario',
                'cambio_estado',
                'asignacion',
                'archivo_adjunto',
                'nota_interna',
                'respuesta_automatica'
            ]);
            $table->string('estado_anterior')->nullable();
            $table->string('estado_nuevo')->nullable();
            $table->text('contenido')->nullable();
            $table->json('archivos')->nullable();
            $table->boolean('visible_copropietario')->default(true);
            
            $table->timestamps();
            
            $table->index('solicitud_id');
        });

        // =====================================================
        // 7. DOCUMENTOS COMPARTIDOS
        // =====================================================
        Schema::create('documentos_compartidos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            $table->foreignId('subido_por')->constrained('users')->cascadeOnDelete();
            
            // Categorización
            $table->enum('categoria', [
                'reglamento',
                'acta_asamblea',
                'balance',
                'presupuesto',
                'contrato',
                'comunicado',
                'informe',
                'cotizacion',
                'poliza_seguro',
                'certificado',
                'plano',
                'manual',
                'otro'
            ]);
            
            // Documento
            $table->string('nombre', 200);
            $table->text('descripcion')->nullable();
            $table->string('archivo_nombre');
            $table->string('archivo_path');
            $table->string('archivo_mime', 100);
            $table->bigInteger('archivo_size');
            $table->string('archivo_hash', 64)->comment('SHA-256 del archivo');
            
            // Visibilidad
            $table->boolean('visible_portal')->default(true);
            $table->boolean('destacado')->default(false);
            $table->boolean('requiere_aceptacion')->default(false);
            
            // Vigencia
            $table->date('fecha_documento')->nullable();
            $table->date('vigente_desde')->nullable();
            $table->date('vigente_hasta')->nullable();
            
            // Estadísticas
            $table->integer('descargas_count')->default(0);
            $table->integer('visualizaciones_count')->default(0);
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['edificio_id', 'categoria', 'visible_portal']);
        });

        // =====================================================
        // 8. DESCARGAS DE DOCUMENTOS (LOG)
        // =====================================================
        Schema::create('log_descargas_documentos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('documento_id')->constrained('documentos_compartidos')->cascadeOnDelete();
            $table->foreignId('acceso_id')->nullable()->constrained('accesos_portal')->nullOnDelete();
            $table->foreignId('usuario_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('ip', 45);
            $table->string('user_agent')->nullable();
            $table->timestamp('created_at');
            
            $table->index(['documento_id', 'created_at']);
        });

        // =====================================================
        // 9. RESERVAS DE ESPACIOS COMUNES
        // =====================================================
        Schema::create('espacios_comunes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            
            $table->string('nombre', 100);
            $table->text('descripcion')->nullable();
            $table->enum('tipo', [
                'salon_eventos',
                'quincho',
                'piscina',
                'gimnasio',
                'cancha',
                'sala_reuniones',
                'terraza',
                'estacionamiento_visita',
                'otro'
            ]);
            
            // Capacidad
            $table->integer('capacidad_maxima')->nullable();
            
            // Disponibilidad
            $table->boolean('activo')->default(true);
            $table->boolean('requiere_reserva')->default(true);
            $table->json('horarios_disponibles')->nullable()->comment('Por día de semana');
            $table->integer('duracion_minima_minutos')->default(60);
            $table->integer('duracion_maxima_minutos')->default(480);
            $table->integer('anticipacion_minima_horas')->default(24);
            $table->integer('anticipacion_maxima_dias')->default(30);
            
            // Costos
            $table->boolean('tiene_costo')->default(false);
            $table->decimal('costo_hora', 10, 2)->default(0);
            $table->decimal('garantia', 10, 2)->default(0);
            
            // Reglas
            $table->integer('reservas_maximas_mes')->default(2)->comment('Por unidad');
            $table->text('reglas_uso')->nullable();
            $table->json('imagenes')->nullable();
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['edificio_id', 'activo']);
        });

        // =====================================================
        // 10. RESERVAS
        // =====================================================
        Schema::create('reservas_espacios', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('espacio_id')->constrained('espacios_comunes')->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained('unidades')->cascadeOnDelete();
            $table->foreignId('acceso_id')->constrained('accesos_portal')->cascadeOnDelete();
            
            // Identificación
            $table->string('codigo_reserva', 10)->unique();
            
            // Fechas
            $table->date('fecha');
            $table->time('hora_inicio');
            $table->time('hora_fin');
            
            // Detalles
            $table->integer('cantidad_personas')->nullable();
            $table->text('motivo')->nullable();
            $table->text('observaciones')->nullable();
            
            // Estado
            $table->enum('estado', [
                'pendiente',
                'confirmada',
                'cancelada',
                'completada',
                'no_show'
            ])->default('pendiente');
            
            // Costos
            $table->decimal('costo_total', 10, 2)->default(0);
            $table->decimal('garantia', 10, 2)->default(0);
            $table->boolean('garantia_devuelta')->default(false);
            
            // Pago
            $table->foreignId('transaccion_id')->nullable()->constrained('transacciones_pago')->nullOnDelete();
            $table->boolean('pagada')->default(false);
            
            // Cancelación
            $table->timestamp('cancelada_at')->nullable();
            $table->string('motivo_cancelacion')->nullable();
            $table->foreignId('cancelada_por')->nullable();
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['espacio_id', 'fecha', 'estado']);
            $table->index(['unidad_id', 'fecha']);
            $table->unique(['espacio_id', 'fecha', 'hora_inicio'], 'reserva_unica');
        });

        // =====================================================
        // 11. VOTACIONES ONLINE
        // =====================================================
        Schema::create('votaciones_online', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            $table->foreignId('reunion_id')->nullable()->comment('Si está asociada a una asamblea');
            $table->foreignId('creada_por')->constrained('users')->cascadeOnDelete();
            
            // Identificación
            $table->string('codigo', 10)->unique();
            $table->string('titulo', 200);
            $table->text('descripcion');
            
            // Tipo
            $table->enum('tipo', [
                'ordinaria',        // Mayoría simple
                'extraordinaria',   // 2/3
                'unanimidad'        // 100%
            ])->default('ordinaria');
            $table->enum('metodo_conteo', ['por_unidad', 'por_prorrateo'])->default('por_prorrateo');
            
            // Opciones
            $table->json('opciones')->comment('Array de opciones de voto');
            $table->boolean('permite_abstencion')->default(true);
            
            // Vigencia
            $table->timestamp('inicio_votacion');
            $table->timestamp('fin_votacion');
            
            // Estado
            $table->enum('estado', [
                'borrador',
                'programada',
                'activa',
                'cerrada',
                'anulada'
            ])->default('borrador');
            
            // Quórum
            $table->decimal('quorum_requerido', 5, 2)->default(50.00);
            $table->decimal('quorum_alcanzado', 5, 2)->default(0);
            
            // Resultados
            $table->json('resultados')->nullable();
            $table->boolean('resultado_publicado')->default(false);
            $table->timestamp('resultado_publicado_at')->nullable();
            
            // Documentos
            $table->json('documentos_adjuntos')->nullable();
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['edificio_id', 'estado']);
            $table->index(['inicio_votacion', 'fin_votacion']);
        });

        // =====================================================
        // 12. VOTOS
        // =====================================================
        Schema::create('votos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('votacion_id')->constrained('votaciones_online')->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained('unidades')->cascadeOnDelete();
            $table->foreignId('acceso_id')->constrained('accesos_portal')->cascadeOnDelete();
            
            // Voto
            $table->string('opcion_seleccionada', 50);
            $table->decimal('prorrateo_unidad', 8, 4);
            
            // Verificación
            $table->string('hash_voto', 64)->comment('SHA-256 para verificación');
            $table->string('ip', 45);
            $table->string('user_agent')->nullable();
            
            // Delegación
            $table->boolean('es_delegado')->default(false);
            $table->foreignId('delegado_por')->nullable();
            
            $table->timestamps();
            
            $table->unique(['votacion_id', 'unidad_id']);
            $table->index('hash_voto');
        });

        // =====================================================
        // 13. COMUNICADOS
        // =====================================================
        Schema::create('comunicados', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained('edificios')->cascadeOnDelete();
            $table->foreignId('creado_por')->constrained('users')->cascadeOnDelete();
            
            // Contenido
            $table->string('titulo', 200);
            $table->text('contenido');
            $table->json('archivos_adjuntos')->nullable();
            
            // Categorización
            $table->enum('tipo', [
                'informativo',
                'urgente',
                'mantencion',
                'seguridad',
                'evento',
                'recordatorio',
                'normativo'
            ])->default('informativo');
            $table->enum('prioridad', ['baja', 'normal', 'alta', 'urgente'])->default('normal');
            
            // Publicación
            $table->boolean('publicado')->default(false);
            $table->timestamp('publicado_at')->nullable();
            $table->timestamp('vigente_hasta')->nullable();
            $table->boolean('destacado')->default(false);
            $table->boolean('fijado')->default(false)->comment('Siempre visible arriba');
            
            // Notificaciones
            $table->boolean('enviar_email')->default(false);
            $table->boolean('enviar_push')->default(false);
            $table->timestamp('notificado_at')->nullable();
            
            // Estadísticas
            $table->integer('lecturas_count')->default(0);
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['edificio_id', 'publicado', 'publicado_at']);
        });

        // =====================================================
        // 14. LECTURAS DE COMUNICADOS
        // =====================================================
        Schema::create('lecturas_comunicados', function (Blueprint $table) {
            $table->id();
            $table->foreignId('comunicado_id')->constrained('comunicados')->cascadeOnDelete();
            $table->foreignId('acceso_id')->constrained('accesos_portal')->cascadeOnDelete();
            $table->timestamp('leido_at');
            
            $table->unique(['comunicado_id', 'acceso_id']);
        });

        // =====================================================
        // 15. NOTIFICACIONES PORTAL
        // =====================================================
        Schema::create('notificaciones_portal', function (Blueprint $table) {
            $table->id();
            $table->foreignId('acceso_id')->constrained('accesos_portal')->cascadeOnDelete();
            
            $table->string('tipo', 50);
            $table->string('titulo', 200);
            $table->text('mensaje');
            $table->string('icono', 50)->nullable();
            $table->string('color', 20)->nullable();
            $table->string('enlace')->nullable();
            $table->json('datos')->nullable();
            
            $table->boolean('leida')->default(false);
            $table->timestamp('leida_at')->nullable();
            
            $table->timestamps();
            
            $table->index(['acceso_id', 'leida', 'created_at']);
        });

        // =====================================================
        // 16. LOG DE ACTIVIDAD PORTAL
        // =====================================================
        Schema::create('log_actividad_portal', function (Blueprint $table) {
            $table->id();
            $table->foreignId('acceso_id')->constrained('accesos_portal')->cascadeOnDelete();
            
            $table->string('accion', 100);
            $table->string('modulo', 50);
            $table->string('descripcion')->nullable();
            $table->json('datos_anteriores')->nullable();
            $table->json('datos_nuevos')->nullable();
            $table->string('ip', 45);
            $table->string('user_agent')->nullable();
            
            $table->timestamp('created_at');
            
            $table->index(['acceso_id', 'created_at']);
            $table->index(['modulo', 'accion']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('log_actividad_portal');
        Schema::dropIfExists('notificaciones_portal');
        Schema::dropIfExists('lecturas_comunicados');
        Schema::dropIfExists('comunicados');
        Schema::dropIfExists('votos');
        Schema::dropIfExists('votaciones_online');
        Schema::dropIfExists('reservas_espacios');
        Schema::dropIfExists('espacios_comunes');
        Schema::dropIfExists('log_descargas_documentos');
        Schema::dropIfExists('documentos_compartidos');
        Schema::dropIfExists('seguimiento_solicitudes');
        Schema::dropIfExists('solicitudes_copropietarios');
        Schema::dropIfExists('configuracion_pasarelas');
        Schema::dropIfExists('transacciones_pago');
        Schema::dropIfExists('sesiones_portal');
        Schema::dropIfExists('accesos_portal');
    }
};
