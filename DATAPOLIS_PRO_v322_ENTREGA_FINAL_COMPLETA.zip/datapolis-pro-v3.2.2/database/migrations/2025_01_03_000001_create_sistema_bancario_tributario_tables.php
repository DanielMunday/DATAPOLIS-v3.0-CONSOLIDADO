<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * DATAPOLIS PRO v3.1 - Sistema Contable-Tributario Integral
 * 
 * Migración para:
 * - Cuentas Bancarias de la Comunidad (Art. 40 Ley 21.442, Art. 23 DS 7-2025)
 * - Movimientos Bancarios
 * - Traspasos entre Cuentas (Art. 17 N°3 LIR - Ley 21.713)
 * - Conciliación Bancaria
 * - Planilla Detallada por Copropietario
 * - PPM y Retenciones
 */
return new class extends Migration
{
    public function up(): void
    {
        // =====================================================
        // CUENTAS BANCARIAS DE LA COMUNIDAD
        // Según Art. 40 Ley 21.442 y Art. 23 DS 7-2025
        // =====================================================
        Schema::create('cuentas_bancarias_comunidad', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained()->cascadeOnDelete();
            
            // Datos del banco
            $table->string('banco_codigo', 10);  // BCI, SANTANDER, BICE, ESTADO, etc.
            $table->string('banco_nombre', 100);
            $table->enum('tipo_cuenta', ['corriente', 'vista', 'ahorro', 'rut'])->default('corriente');
            $table->string('numero_cuenta', 30);
            $table->string('rut_titular', 12);   // RUT de la comunidad
            $table->string('nombre_titular', 200);
            
            // Propósito según ley
            $table->enum('proposito', [
                'gastos_comunes',       // Art. 40 Ley 21.442 - Cuenta principal obligatoria
                'arriendos',            // Art. 23 DS 7-2025 - Cuenta separada para arriendos
                'fondo_reserva',        // Art. 23 Ley 21.442 - Fondo de reserva
                'operacional',          // Cuenta operacional general
                'inversiones',          // Excedentes invertidos
                'remuneraciones'        // Para pago de sueldos
            ])->default('gastos_comunes');
            
            // Referencia legal
            $table->string('base_legal', 100)->nullable();  // Ej: "Art. 40 Ley 21.442"
            
            // Cuenta contable asociada (para integración automática)
            $table->foreignId('cuenta_contable_id')->nullable()->constrained('plan_cuentas')->nullOnDelete();
            
            // Saldos
            $table->decimal('saldo_contable', 18, 2)->default(0);  // Según libros
            $table->decimal('saldo_banco', 18, 2)->default(0);     // Según cartola
            $table->decimal('saldo_disponible', 18, 2)->default(0); // Disponible real
            $table->date('fecha_ultimo_movimiento')->nullable();
            $table->date('fecha_ultima_conciliacion')->nullable();
            
            // Estado
            $table->boolean('activa')->default(true);
            $table->boolean('es_principal')->default(false);
            $table->boolean('permite_sobregiro')->default(false);
            $table->decimal('linea_sobregiro', 18, 2)->default(0);
            
            // Firmas autorizadas
            $table->json('firmantes')->nullable();
            /*
            [
                {"rut": "12.345.678-9", "nombre": "Juan Pérez", "cargo": "Administrador", "tipo_firma": "A"},
                {"rut": "13.456.789-0", "nombre": "María López", "cargo": "Presidente", "tipo_firma": "B"}
            ]
            */
            
            // Configuración de alertas
            $table->decimal('saldo_minimo_alerta', 18, 2)->default(0);
            $table->boolean('enviar_alertas')->default(true);
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->unique(['edificio_id', 'proposito'], 'cuenta_proposito_unico');
            $table->index(['tenant_id', 'activa']);
        });

        // =====================================================
        // MOVIMIENTOS BANCARIOS
        // =====================================================
        Schema::create('movimientos_bancarios', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cuenta_bancaria_id')->constrained('cuentas_bancarias_comunidad')->cascadeOnDelete();
            
            // Datos del movimiento
            $table->date('fecha');
            $table->date('fecha_valor')->nullable();  // Fecha efectiva del banco
            $table->time('hora')->nullable();
            
            $table->enum('tipo', [
                // Ingresos
                'deposito',
                'transferencia_recibida',
                'abono_nomina',
                'pago_webpay',
                'pago_khipu',
                'interes_ganado',
                
                // Egresos
                'transferencia_enviada',
                'cheque_girado',
                'cheque_cobrado',
                'cargo_automatico',
                'comision_bancaria',
                'pago_proveedor',
                'pago_remuneracion',
                'pago_cotizaciones',
                
                // Traspasos internos
                'traspaso_interno_salida',
                'traspaso_interno_entrada',
                
                // Ajustes
                'ajuste_conciliacion',
                'anulacion'
            ]);
            
            $table->string('numero_documento', 50)->nullable();  // N° cheque, transferencia
            $table->string('numero_operacion', 50)->nullable();  // N° operación banco
            $table->string('descripcion', 500);
            
            // Montos (uno u otro, no ambos)
            $table->decimal('cargo', 18, 2)->default(0);   // Debe (salida)
            $table->decimal('abono', 18, 2)->default(0);   // Haber (entrada)
            $table->decimal('saldo_posterior', 18, 2)->nullable();
            
            // Contrapartida (para traspasos)
            $table->foreignId('cuenta_contraparte_id')->nullable()
                ->constrained('cuentas_bancarias_comunidad')->nullOnDelete();
            $table->foreignId('traspaso_id')->nullable();  // Referencia al traspaso
            
            // Referencias a otros módulos
            $table->string('modulo_origen', 50)->nullable();  // gastos_comunes, arriendos, rrhh, etc.
            $table->unsignedBigInteger('registro_origen_id')->nullable();
            
            // Referencias específicas
            $table->foreignId('boleta_gc_id')->nullable();
            $table->foreignId('factura_arriendo_id')->nullable();
            $table->foreignId('liquidacion_id')->nullable();
            $table->foreignId('distribucion_detalle_id')->nullable();
            
            // Tercero relacionado
            $table->string('rut_tercero', 12)->nullable();
            $table->string('nombre_tercero', 200)->nullable();
            $table->string('banco_tercero', 100)->nullable();
            $table->string('cuenta_tercero', 30)->nullable();
            
            // Conciliación
            $table->boolean('conciliado')->default(false);
            $table->date('fecha_conciliacion')->nullable();
            $table->foreignId('conciliado_por')->nullable()->constrained('users')->nullOnDelete();
            
            // Contabilización
            $table->foreignId('asiento_id')->nullable()->constrained('asientos')->nullOnDelete();
            $table->boolean('contabilizado')->default(false);
            
            // Importación desde cartola
            $table->boolean('importado_cartola')->default(false);
            $table->integer('linea_cartola')->nullable();
            $table->string('archivo_cartola', 255)->nullable();
            
            // Estado
            $table->enum('estado', ['pendiente', 'procesado', 'conciliado', 'anulado'])->default('pendiente');
            
            $table->timestamps();
            
            $table->index(['cuenta_bancaria_id', 'fecha']);
            $table->index(['conciliado', 'fecha']);
        });

        // =====================================================
        // TRASPASOS ENTRE CUENTAS
        // Fundamental para cumplimiento Art. 17 N°3 LIR (Ley 21.713)
        // =====================================================
        Schema::create('traspasos_cuentas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained()->cascadeOnDelete();
            
            // Número de traspaso
            $table->string('numero_traspaso', 30)->unique();
            
            // Cuentas involucradas
            $table->foreignId('cuenta_origen_id')->constrained('cuentas_bancarias_comunidad');
            $table->foreignId('cuenta_destino_id')->constrained('cuentas_bancarias_comunidad');
            
            // Datos del traspaso
            $table->date('fecha');
            $table->decimal('monto', 18, 2);
            $table->string('concepto', 500);
            
            // Tipo de traspaso (crucial para Ley 21.713)
            $table->enum('tipo', [
                'arriendos_a_gc',               // Ingresos arriendos → Pago GC (Art. 17 N°3 - NO RENTA)
                'arriendos_a_copropietario',    // Remanente arriendos → Pago a copropietario (SÍ RENTA)
                'gc_a_fondo_reserva',           // Aporte mensual a fondo de reserva
                'fondo_reserva_a_gc',           // Uso del fondo de reserva (debe estar aprobado)
                'operacional',                  // Traspaso operacional general
                'remuneraciones',               // Provisión para pago de sueldos
                'inversiones',                  // Traspaso a cuenta de inversiones
                'ajuste'                        // Ajuste contable
            ]);
            
            // Base legal aplicable
            $table->string('base_legal', 100)->nullable();  // Ej: "Art. 17 N°3 LIR"
            
            // Referencias
            $table->foreignId('distribucion_id')->nullable()->constrained('distribuciones')->nullOnDelete();
            $table->string('periodo', 7)->nullable();       // YYYY-MM
            $table->foreignId('unidad_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('persona_id')->nullable()->constrained('personas')->nullOnDelete();
            
            // Para traspasos a copropietarios
            $table->string('rut_beneficiario', 12)->nullable();
            $table->string('nombre_beneficiario', 200)->nullable();
            $table->string('banco_beneficiario', 100)->nullable();
            $table->string('cuenta_beneficiario', 30)->nullable();
            $table->enum('tipo_cuenta_beneficiario', ['corriente', 'vista', 'ahorro', 'rut'])->nullable();
            
            // Información tributaria (para Art. 17 N°3)
            $table->boolean('es_pago_gc')->default(false);          // ¿Es para pagar GC?
            $table->boolean('constituye_renta')->default(false);    // ¿Constituye renta para el copropietario?
            $table->decimal('monto_no_renta', 18, 2)->default(0);   // Monto Art. 17 N°3
            $table->decimal('monto_renta', 18, 2)->default(0);      // Monto gravable
            
            // Movimientos bancarios generados
            $table->foreignId('movimiento_origen_id')->nullable();   // Cargo en cuenta origen
            $table->foreignId('movimiento_destino_id')->nullable();  // Abono en cuenta destino
            
            // Contabilización
            $table->foreignId('asiento_id')->nullable()->constrained('asientos')->nullOnDelete();
            
            // Aprobación
            $table->boolean('requiere_aprobacion')->default(true);
            $table->foreignId('solicitado_por')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('aprobado_por')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('aprobado_at')->nullable();
            $table->text('motivo_rechazo')->nullable();
            
            // Estado
            $table->enum('estado', ['borrador', 'pendiente', 'aprobado', 'ejecutado', 'rechazado', 'anulado'])
                ->default('borrador');
            
            $table->foreignId('ejecutado_por')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('ejecutado_at')->nullable();
            
            $table->text('observaciones')->nullable();
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['edificio_id', 'tipo', 'fecha']);
            $table->index(['tipo', 'periodo']);
        });

        // =====================================================
        // CONCILIACIÓN BANCARIA
        // =====================================================
        Schema::create('conciliaciones_bancarias', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('cuenta_bancaria_id')->constrained('cuentas_bancarias_comunidad')->cascadeOnDelete();
            
            // Período
            $table->integer('mes');
            $table->integer('anio');
            $table->date('fecha_inicio');
            $table->date('fecha_cierre');
            
            // Saldos
            $table->decimal('saldo_inicial_libro', 18, 2)->default(0);
            $table->decimal('saldo_inicial_banco', 18, 2)->default(0);
            $table->decimal('saldo_final_libro', 18, 2)->default(0);
            $table->decimal('saldo_final_banco', 18, 2)->default(0);
            
            // Movimientos del período
            $table->decimal('total_cargos_libro', 18, 2)->default(0);
            $table->decimal('total_abonos_libro', 18, 2)->default(0);
            $table->decimal('total_cargos_banco', 18, 2)->default(0);
            $table->decimal('total_abonos_banco', 18, 2)->default(0);
            
            // Partidas pendientes
            $table->integer('depositos_en_transito')->default(0);
            $table->decimal('monto_depositos_transito', 18, 2)->default(0);
            $table->integer('cheques_pendientes')->default(0);
            $table->decimal('monto_cheques_pendientes', 18, 2)->default(0);
            $table->integer('cargos_no_registrados')->default(0);
            $table->decimal('monto_cargos_no_registrados', 18, 2)->default(0);
            $table->integer('abonos_no_registrados')->default(0);
            $table->decimal('monto_abonos_no_registrados', 18, 2)->default(0);
            
            // Resultado
            $table->decimal('diferencia', 18, 2)->default(0);
            $table->boolean('conciliada')->default(false);  // Diferencia = 0
            
            // Detalle de partidas pendientes
            $table->json('partidas_pendientes')->nullable();
            
            // Estado
            $table->enum('estado', ['en_proceso', 'conciliada', 'cerrada', 'con_diferencia'])->default('en_proceso');
            
            // Archivo de cartola importado
            $table->string('archivo_cartola', 255)->nullable();
            $table->timestamp('cartola_importada_at')->nullable();
            
            // Aprobación
            $table->foreignId('elaborada_por')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('aprobada_por')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('aprobada_at')->nullable();
            
            $table->text('observaciones')->nullable();
            $table->timestamps();
            
            $table->unique(['cuenta_bancaria_id', 'mes', 'anio']);
        });

        // =====================================================
        // PLANILLA DETALLADA DISTRIBUCIÓN ARRIENDOS
        // Para cumplimiento Ley 21.713 y certificados SII
        // =====================================================
        Schema::create('planilla_distribucion_arriendos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained()->cascadeOnDelete();
            
            // Período
            $table->integer('mes');
            $table->integer('anio');
            $table->string('periodo', 7);  // YYYY-MM
            
            // Unidad y propietario
            $table->foreignId('unidad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('persona_id')->constrained('personas')->cascadeOnDelete();
            $table->string('rut_copropietario', 12);
            $table->string('nombre_copropietario', 200);
            $table->string('numero_unidad', 20);
            $table->decimal('porcentaje_dominio', 10, 6);
            
            // INGRESOS POR ARRIENDOS (proporcional)
            $table->decimal('ingreso_bruto_arriendos', 18, 2)->default(0);
            
            // Desglose por tipo de arriendo
            $table->decimal('ingreso_antenas', 18, 2)->default(0);
            $table->decimal('ingreso_publicidad', 18, 2)->default(0);
            $table->decimal('ingreso_estacionamientos', 18, 2)->default(0);
            $table->decimal('ingreso_locales', 18, 2)->default(0);
            $table->decimal('ingreso_bodegas', 18, 2)->default(0);
            $table->decimal('ingreso_concesiones', 18, 2)->default(0);
            $table->decimal('ingreso_sala_eventos', 18, 2)->default(0);
            $table->decimal('ingreso_otros', 18, 2)->default(0);
            
            // DEUDA DE GASTOS COMUNES del período
            $table->decimal('deuda_gc_periodo', 18, 2)->default(0);
            $table->foreignId('boleta_gc_id')->nullable()->constrained('boletas_gc')->nullOnDelete();
            
            // TRASPASO A GC (Art. 17 N°3 - NO constituye renta)
            $table->decimal('traspaso_a_gc', 18, 2)->default(0);
            $table->foreignId('traspaso_id')->nullable()->constrained('traspasos_cuentas')->nullOnDelete();
            $table->string('comprobante_traspaso', 50)->nullable();
            $table->date('fecha_traspaso')->nullable();
            
            // Monto que NO constituye renta (Art. 17 N°3 LIR)
            $table->decimal('monto_art_17_n3', 18, 2)->default(0);
            
            // REMANENTE (SÍ constituye renta)
            $table->decimal('remanente_gravable', 18, 2)->default(0);
            
            // PPM retenido (si aplica)
            $table->decimal('ppm_retenido', 18, 2)->default(0);
            $table->decimal('tasa_ppm', 5, 2)->default(0);
            
            // NETO A PAGAR al copropietario (si hay remanente positivo)
            $table->decimal('neto_a_pagar', 18, 2)->default(0);
            
            // Estado del pago del remanente
            $table->enum('estado_pago_remanente', ['no_aplica', 'pendiente', 'pagado', 'compensado'])->default('no_aplica');
            $table->date('fecha_pago_remanente')->nullable();
            $table->string('comprobante_pago_remanente', 50)->nullable();
            
            // Verificación
            $table->boolean('verificado')->default(false);
            $table->foreignId('verificado_por')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('verificado_at')->nullable();
            
            $table->timestamps();
            
            $table->unique(['edificio_id', 'unidad_id', 'mes', 'anio'], 'planilla_unidad_periodo');
            $table->index(['rut_copropietario', 'anio']);
        });

        // =====================================================
        // RESUMEN ANUAL POR COPROPIETARIO
        // Para certificados tributarios
        // =====================================================
        Schema::create('resumen_anual_copropietario', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained()->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('persona_id')->constrained('personas')->cascadeOnDelete();
            
            $table->integer('anio');
            $table->string('rut_copropietario', 12);
            $table->string('nombre_copropietario', 200);
            $table->string('numero_unidad', 20);
            $table->decimal('porcentaje_dominio', 10, 6);
            
            // TOTALES ANUALES
            $table->decimal('total_ingreso_bruto_arriendos', 18, 2)->default(0);
            $table->decimal('total_traspasado_gc', 18, 2)->default(0);
            $table->decimal('total_monto_art_17_n3', 18, 2)->default(0);  // NO renta
            $table->decimal('total_remanente_gravable', 18, 2)->default(0);  // SÍ renta
            $table->decimal('total_ppm_retenido', 18, 2)->default(0);
            $table->decimal('total_neto_pagado', 18, 2)->default(0);
            
            // Desglose anual por tipo
            $table->json('desglose_por_tipo')->nullable();
            /*
            {
                "antenas": 120000,
                "publicidad": 30000,
                "estacionamientos": 24000,
                ...
            }
            */
            
            // Detalle mensual
            $table->json('detalle_mensual')->nullable();
            /*
            [
                {"mes": 1, "ingreso": 20750, "traspaso_gc": 18000, "remanente": 2750},
                {"mes": 2, "ingreso": 20750, "traspaso_gc": 17500, "remanente": 3250},
                ...
            ]
            */
            
            // Información para certificado
            $table->string('numero_certificado', 30)->nullable();
            $table->date('fecha_certificado')->nullable();
            $table->string('codigo_verificacion', 20)->nullable();
            
            // Datos de pago anuales
            $table->integer('cantidad_pagos')->default(0);
            $table->date('fecha_primer_pago')->nullable();
            $table->date('fecha_ultimo_pago')->nullable();
            
            // Para copropietarios con múltiples propiedades
            $table->boolean('tiene_otras_propiedades')->default(false);
            $table->integer('cantidad_propiedades_total')->default(1);
            
            $table->timestamps();
            
            $table->unique(['edificio_id', 'unidad_id', 'anio']);
            $table->index(['rut_copropietario', 'anio']);
        });

        // =====================================================
        // PPM Y RETENCIONES
        // =====================================================
        Schema::create('ppm_retenciones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('edificio_id')->constrained()->cascadeOnDelete();
            
            $table->integer('mes');
            $table->integer('anio');
            $table->string('periodo', 7);  // YYYY-MM
            
            // Tipo de retención
            $table->enum('tipo', [
                'ppm_arriendos',           // PPM sobre arriendos
                'retencion_honorarios',    // 10.75% honorarios
                'retencion_arriendos_terceros', // Si aplica
                'otro'
            ]);
            
            // Datos del retenido
            $table->foreignId('persona_id')->nullable()->constrained('personas')->nullOnDelete();
            $table->string('rut_retenido', 12);
            $table->string('nombre_retenido', 200);
            
            // Montos
            $table->decimal('base_imponible', 18, 2);
            $table->decimal('tasa_retencion', 5, 2);  // Porcentaje
            $table->decimal('monto_retencion', 18, 2);
            
            // Documento origen
            $table->string('tipo_documento', 50)->nullable();
            $table->unsignedBigInteger('documento_id')->nullable();
            $table->string('numero_documento', 50)->nullable();
            
            // Declaración
            $table->boolean('declarado_f29')->default(false);
            $table->string('folio_f29', 30)->nullable();
            $table->date('fecha_declaracion')->nullable();
            
            // Pago al fisco
            $table->boolean('pagado_fisco')->default(false);
            $table->date('fecha_pago_fisco')->nullable();
            $table->string('folio_pago', 50)->nullable();
            
            $table->timestamps();
            
            $table->index(['edificio_id', 'tipo', 'periodo']);
        });

        // =====================================================
        // AMPLIACIÓN DE TIPOS DE ARRIENDO
        // =====================================================
        Schema::table('contratos_arriendo', function (Blueprint $table) {
            // Cambiar ENUM a más opciones (si la BD lo permite, sino crear nueva columna)
            // En MySQL no se puede alterar ENUM fácilmente, así que agregamos columna nueva
            $table->string('tipo_espacio_detallado', 50)->after('tipo_espacio')->nullable();
            $table->string('categoria_tributaria', 50)->after('tipo_espacio_detallado')->nullable();
            
            // Información adicional para ciertos tipos
            $table->boolean('es_arriendo_copropietario')->default(false)->after('categoria_tributaria');
            $table->foreignId('copropietario_arrendatario_id')->nullable()->after('es_arriendo_copropietario');
        });
    }

    public function down(): void
    {
        Schema::table('contratos_arriendo', function (Blueprint $table) {
            $table->dropColumn(['tipo_espacio_detallado', 'categoria_tributaria', 
                               'es_arriendo_copropietario', 'copropietario_arrendatario_id']);
        });
        
        Schema::dropIfExists('ppm_retenciones');
        Schema::dropIfExists('resumen_anual_copropietario');
        Schema::dropIfExists('planilla_distribucion_arriendos');
        Schema::dropIfExists('conciliaciones_bancarias');
        Schema::dropIfExists('traspasos_cuentas');
        Schema::dropIfExists('movimientos_bancarios');
        Schema::dropIfExists('cuentas_bancarias_comunidad');
    }
};
