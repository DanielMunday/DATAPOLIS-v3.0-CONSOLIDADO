<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

/**
 * DATAPOLIS PRO v3.1 - Ampliación de Tipos de Arriendo
 * 
 * Agrega soporte para:
 * - Estacionamientos (visitas, comunes, terceros)
 * - Publicidad (fachada, hall, ascensor, tótem)
 * - Locales comerciales
 * - Bodegas comunes
 * - Salas de eventos / Quinchos
 * - Concesiones (cafetería, lavandería, minimarket, gimnasio)
 * - Espacios comunes de uso privado
 */
return new class extends Migration
{
    public function up(): void
    {
        // =====================================================================
        // TABLA: CATEGORÍAS DE ARRIENDO
        // =====================================================================
        Schema::create('categorias_arriendo', function (Blueprint $table) {
            $table->id();
            $table->string('codigo', 50)->unique();
            $table->string('nombre', 100);
            $table->text('descripcion')->nullable();
            $table->string('icono', 50)->nullable();
            $table->string('color', 20)->nullable();
            $table->boolean('requiere_permiso_municipal')->default(false);
            $table->boolean('requiere_contrato_especial')->default(false);
            $table->boolean('genera_iva')->default(true);
            $table->decimal('tasa_retencion', 5, 2)->default(0);
            $table->integer('orden')->default(0);
            $table->boolean('activa')->default(true);
            $table->timestamps();
        });

        // =====================================================================
        // TABLA: TIPOS DE ESPACIO ARRENDABLE
        // =====================================================================
        Schema::create('tipos_espacio_arriendo', function (Blueprint $table) {
            $table->id();
            $table->foreignId('categoria_id')->constrained('categorias_arriendo')->onDelete('cascade');
            $table->string('codigo', 50)->unique();
            $table->string('nombre', 100);
            $table->text('descripcion')->nullable();
            $table->enum('unidad_medida', ['unidad', 'm2', 'hora', 'dia', 'mes'])->default('mes');
            $table->decimal('precio_sugerido', 12, 0)->nullable();
            $table->boolean('permite_reserva')->default(false);
            $table->boolean('requiere_garantia')->default(false);
            $table->decimal('monto_garantia_sugerido', 12, 0)->nullable();
            $table->integer('dias_anticipacion_minimo')->nullable();
            $table->json('horarios_disponibles')->nullable();
            $table->json('reglas_uso')->nullable();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        // =====================================================================
        // TABLA: ESPACIOS ARRENDABLES
        // =====================================================================
        Schema::create('espacios_arrendables', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->onDelete('cascade');
            $table->foreignId('edificio_id')->constrained('edificios')->onDelete('cascade');
            $table->foreignId('tipo_espacio_id')->constrained('tipos_espacio_arriendo')->onDelete('restrict');
            
            $table->string('codigo', 50);
            $table->string('nombre', 100);
            $table->text('descripcion')->nullable();
            $table->string('ubicacion', 200)->nullable();
            
            // Dimensiones
            $table->decimal('superficie_m2', 8, 2)->nullable();
            $table->decimal('altura_m', 5, 2)->nullable();
            $table->integer('capacidad_personas')->nullable();
            
            // Para estacionamientos
            $table->string('numero_estacionamiento', 20)->nullable();
            $table->enum('tipo_vehiculo', ['auto', 'moto', 'bicicleta', 'discapacitado', 'carga'])->nullable();
            $table->boolean('tiene_techo')->nullable();
            
            // Para publicidad
            $table->decimal('dimension_ancho_m', 5, 2)->nullable();
            $table->decimal('dimension_alto_m', 5, 2)->nullable();
            $table->enum('orientacion', ['norte', 'sur', 'este', 'oeste', 'interior'])->nullable();
            $table->boolean('iluminado')->nullable();
            
            // Características
            $table->json('amenidades')->nullable(); // wifi, aire_acondicionado, etc.
            $table->json('equipamiento')->nullable();
            $table->json('fotos')->nullable();
            
            // Estado
            $table->enum('estado', ['disponible', 'arrendado', 'reservado', 'mantencion', 'no_disponible'])->default('disponible');
            $table->date('disponible_desde')->nullable();
            
            // Precios
            $table->decimal('precio_base', 12, 0)->nullable();
            $table->enum('periodo_precio', ['hora', 'dia', 'semana', 'mes', 'anio'])->default('mes');
            $table->decimal('precio_copropietario', 12, 0)->nullable(); // Precio especial
            $table->decimal('garantia_requerida', 12, 0)->nullable();
            
            $table->boolean('activo')->default(true);
            $table->timestamps();
            $table->softDeletes();
            
            $table->unique(['edificio_id', 'codigo']);
            $table->index(['edificio_id', 'tipo_espacio_id', 'estado']);
        });

        // =====================================================================
        // TABLA: RESERVAS DE ESPACIOS
        // =====================================================================
        Schema::create('reservas_espacios', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->onDelete('cascade');
            $table->foreignId('espacio_id')->constrained('espacios_arrendables')->onDelete('cascade');
            $table->foreignId('solicitante_id')->constrained('personas')->onDelete('cascade');
            $table->foreignId('unidad_id')->nullable()->constrained('unidades')->nullOnDelete();
            
            $table->string('numero_reserva', 20)->unique();
            $table->date('fecha_reserva');
            $table->time('hora_inicio')->nullable();
            $table->time('hora_fin')->nullable();
            $table->date('fecha_fin')->nullable(); // Para reservas de varios días
            
            $table->text('motivo')->nullable();
            $table->integer('cantidad_personas')->nullable();
            
            $table->decimal('monto_arriendo', 12, 0);
            $table->decimal('monto_garantia', 12, 0)->default(0);
            $table->decimal('monto_total', 12, 0);
            
            $table->enum('estado', [
                'pendiente',
                'confirmada',
                'pagada',
                'en_uso',
                'finalizada',
                'cancelada',
                'no_show'
            ])->default('pendiente');
            
            $table->timestamp('confirmada_at')->nullable();
            $table->timestamp('pagada_at')->nullable();
            $table->timestamp('cancelada_at')->nullable();
            $table->text('motivo_cancelacion')->nullable();
            
            $table->boolean('garantia_devuelta')->default(false);
            $table->decimal('descuento_garantia', 12, 0)->default(0);
            $table->text('observaciones_devolucion')->nullable();
            
            $table->timestamps();
            $table->softDeletes();
            
            $table->index(['espacio_id', 'fecha_reserva']);
            $table->index(['solicitante_id', 'estado']);
        });

        // =====================================================================
        // TABLA: CONTRATOS DE CONCESIÓN
        // =====================================================================
        Schema::create('contratos_concesion', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->onDelete('cascade');
            $table->foreignId('edificio_id')->constrained('edificios')->onDelete('cascade');
            $table->foreignId('espacio_id')->constrained('espacios_arrendables')->onDelete('cascade');
            $table->foreignId('concesionario_id')->constrained('personas')->onDelete('cascade');
            
            $table->string('numero_contrato', 30)->unique();
            $table->string('tipo_concesion', 50); // cafeteria, lavanderia, minimarket, gym
            $table->string('nombre_comercial', 100)->nullable();
            $table->string('giro', 100)->nullable();
            $table->string('patente_municipal', 50)->nullable();
            
            $table->date('fecha_inicio');
            $table->date('fecha_termino');
            $table->boolean('renovacion_automatica')->default(false);
            $table->integer('meses_aviso_no_renovacion')->default(3);
            
            // Pagos
            $table->enum('tipo_pago', ['fijo', 'porcentaje_ventas', 'mixto'])->default('fijo');
            $table->decimal('monto_fijo_mensual', 12, 0)->nullable();
            $table->decimal('porcentaje_ventas', 5, 2)->nullable();
            $table->decimal('minimo_garantizado', 12, 0)->nullable();
            $table->integer('dia_pago')->default(5);
            
            // Garantía
            $table->decimal('monto_garantia', 12, 0)->nullable();
            $table->enum('tipo_garantia', ['efectivo', 'boleta_garantia', 'pagare', 'seguro'])->nullable();
            $table->string('numero_documento_garantia', 50)->nullable();
            $table->date('vencimiento_garantia')->nullable();
            
            // Servicios incluidos
            $table->json('servicios_incluidos')->nullable(); // agua, luz, gas, wifi
            $table->decimal('gastos_comunes_fijos', 12, 0)->nullable();
            
            $table->enum('estado', ['borrador', 'vigente', 'suspendido', 'terminado', 'renovado'])->default('borrador');
            
            $table->text('clausulas_especiales')->nullable();
            $table->text('observaciones')->nullable();
            
            $table->timestamps();
            $table->softDeletes();
        });

        // =====================================================================
        // TABLA: PAGOS DE CONCESIÓN
        // =====================================================================
        Schema::create('pagos_concesion', function (Blueprint $table) {
            $table->id();
            $table->foreignId('contrato_id')->constrained('contratos_concesion')->onDelete('cascade');
            $table->string('periodo', 7); // YYYY-MM
            $table->date('fecha_vencimiento');
            
            $table->decimal('monto_fijo', 12, 0)->default(0);
            $table->decimal('ventas_declaradas', 12, 0)->default(0);
            $table->decimal('porcentaje_aplicado', 5, 2)->default(0);
            $table->decimal('monto_variable', 12, 0)->default(0);
            $table->decimal('gastos_comunes', 12, 0)->default(0);
            $table->decimal('otros_cargos', 12, 0)->default(0);
            $table->decimal('monto_total', 12, 0);
            
            $table->enum('estado', ['pendiente', 'pagado', 'parcial', 'vencido', 'anulado'])->default('pendiente');
            $table->date('fecha_pago')->nullable();
            $table->decimal('monto_pagado', 12, 0)->default(0);
            
            $table->string('comprobante', 100)->nullable();
            
            $table->timestamps();
            
            $table->unique(['contrato_id', 'periodo']);
        });

        // =====================================================================
        // MODIFICAR TABLA CONTRATOS_ARRIENDO
        // =====================================================================
        Schema::table('contratos_arriendo', function (Blueprint $table) {
            // Agregar referencia al espacio
            $table->foreignId('espacio_id')->nullable()->after('edificio_id')->constrained('espacios_arrendables')->nullOnDelete();
            
            // Categoría tributaria
            $table->enum('categoria_tributaria', [
                'telecomunicaciones',
                'estacionamientos',
                'publicidad',
                'locales',
                'bodegas',
                'eventos',
                'concesiones',
                'otros'
            ])->default('telecomunicaciones')->after('tipo_ubicacion');
            
            // Tipo de espacio detallado (texto para más flexibilidad)
            $table->string('tipo_espacio_detallado', 100)->nullable()->after('categoria_tributaria');
            
            // Información adicional según tipo
            $table->json('datos_adicionales')->nullable()->after('tipo_espacio_detallado');
        });

        // =====================================================================
        // INSERTAR DATOS INICIALES
        // =====================================================================
        
        // Categorías
        DB::table('categorias_arriendo')->insert([
            [
                'codigo' => 'TELECOM',
                'nombre' => 'Telecomunicaciones',
                'descripcion' => 'Arriendo de espacios para antenas y equipos de telecomunicaciones',
                'icono' => 'signal',
                'color' => 'blue',
                'requiere_permiso_municipal' => true,
                'requiere_contrato_especial' => true,
                'genera_iva' => true,
                'tasa_retencion' => 10,
                'orden' => 1,
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'codigo' => 'ESTACIONAMIENTOS',
                'nombre' => 'Estacionamientos',
                'descripcion' => 'Arriendo de estacionamientos de visitas y comunes',
                'icono' => 'car',
                'color' => 'gray',
                'requiere_permiso_municipal' => false,
                'requiere_contrato_especial' => false,
                'genera_iva' => false,
                'tasa_retencion' => 0,
                'orden' => 2,
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'codigo' => 'PUBLICIDAD',
                'nombre' => 'Publicidad',
                'descripcion' => 'Arriendo de espacios para publicidad exterior e interior',
                'icono' => 'megaphone',
                'color' => 'yellow',
                'requiere_permiso_municipal' => true,
                'requiere_contrato_especial' => false,
                'genera_iva' => true,
                'tasa_retencion' => 10,
                'orden' => 3,
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'codigo' => 'LOCALES',
                'nombre' => 'Locales Comerciales',
                'descripcion' => 'Arriendo de locales comerciales en el edificio',
                'icono' => 'store',
                'color' => 'green',
                'requiere_permiso_municipal' => true,
                'requiere_contrato_especial' => true,
                'genera_iva' => true,
                'tasa_retencion' => 10,
                'orden' => 4,
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'codigo' => 'BODEGAS',
                'nombre' => 'Bodegas',
                'descripcion' => 'Arriendo de bodegas de almacenamiento',
                'icono' => 'archive',
                'color' => 'brown',
                'requiere_permiso_municipal' => false,
                'requiere_contrato_especial' => false,
                'genera_iva' => false,
                'tasa_retencion' => 0,
                'orden' => 5,
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'codigo' => 'EVENTOS',
                'nombre' => 'Salas y Eventos',
                'descripcion' => 'Arriendo de salas de eventos, quinchos y terrazas',
                'icono' => 'calendar',
                'color' => 'purple',
                'requiere_permiso_municipal' => false,
                'requiere_contrato_especial' => false,
                'genera_iva' => false,
                'tasa_retencion' => 0,
                'orden' => 6,
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'codigo' => 'CONCESIONES',
                'nombre' => 'Concesiones',
                'descripcion' => 'Concesiones de servicios (cafetería, lavandería, etc.)',
                'icono' => 'handshake',
                'color' => 'orange',
                'requiere_permiso_municipal' => true,
                'requiere_contrato_especial' => true,
                'genera_iva' => true,
                'tasa_retencion' => 10,
                'orden' => 7,
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        // Tipos de espacio
        $categorias = DB::table('categorias_arriendo')->pluck('id', 'codigo');

        DB::table('tipos_espacio_arriendo')->insert([
            // Telecomunicaciones
            ['categoria_id' => $categorias['TELECOM'], 'codigo' => 'ANTENA_AZOTEA', 'nombre' => 'Antena en Azotea', 'unidad_medida' => 'unidad', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['TELECOM'], 'codigo' => 'ANTENA_FACHADA', 'nombre' => 'Antena en Fachada', 'unidad_medida' => 'unidad', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['TELECOM'], 'codigo' => 'SALA_TECNICA', 'nombre' => 'Sala Técnica', 'unidad_medida' => 'm2', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['TELECOM'], 'codigo' => 'CABLEADO', 'nombre' => 'Canalización y Cableado', 'unidad_medida' => 'unidad', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            
            // Estacionamientos
            ['categoria_id' => $categorias['ESTACIONAMIENTOS'], 'codigo' => 'EST_VISITA', 'nombre' => 'Estacionamiento Visitas', 'unidad_medida' => 'mes', 'permite_reserva' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['ESTACIONAMIENTOS'], 'codigo' => 'EST_COMUN', 'nombre' => 'Estacionamiento Común', 'unidad_medida' => 'mes', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['ESTACIONAMIENTOS'], 'codigo' => 'EST_TERCERO', 'nombre' => 'Estacionamiento a Terceros', 'unidad_medida' => 'mes', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['ESTACIONAMIENTOS'], 'codigo' => 'EST_MOTO', 'nombre' => 'Estacionamiento Motos', 'unidad_medida' => 'mes', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['ESTACIONAMIENTOS'], 'codigo' => 'EST_BICI', 'nombre' => 'Estacionamiento Bicicletas', 'unidad_medida' => 'mes', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            
            // Publicidad
            ['categoria_id' => $categorias['PUBLICIDAD'], 'codigo' => 'PUB_FACHADA', 'nombre' => 'Publicidad Fachada', 'unidad_medida' => 'm2', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['PUBLICIDAD'], 'codigo' => 'PUB_HALL', 'nombre' => 'Publicidad Hall', 'unidad_medida' => 'unidad', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['PUBLICIDAD'], 'codigo' => 'PUB_ASCENSOR', 'nombre' => 'Publicidad Ascensores', 'unidad_medida' => 'unidad', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['PUBLICIDAD'], 'codigo' => 'PUB_TOTEM', 'nombre' => 'Tótem Publicitario', 'unidad_medida' => 'unidad', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['PUBLICIDAD'], 'codigo' => 'PUB_DIGITAL', 'nombre' => 'Pantalla Digital', 'unidad_medida' => 'unidad', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            
            // Locales
            ['categoria_id' => $categorias['LOCALES'], 'codigo' => 'LOCAL_COMERCIAL', 'nombre' => 'Local Comercial', 'unidad_medida' => 'm2', 'requiere_garantia' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['LOCALES'], 'codigo' => 'OFICINA', 'nombre' => 'Oficina', 'unidad_medida' => 'm2', 'requiere_garantia' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            
            // Bodegas
            ['categoria_id' => $categorias['BODEGAS'], 'codigo' => 'BODEGA_COMUN', 'nombre' => 'Bodega Común', 'unidad_medida' => 'm2', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['BODEGAS'], 'codigo' => 'LOCKER', 'nombre' => 'Locker/Casillero', 'unidad_medida' => 'unidad', 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            
            // Eventos
            ['categoria_id' => $categorias['EVENTOS'], 'codigo' => 'SALA_EVENTOS', 'nombre' => 'Sala de Eventos', 'unidad_medida' => 'hora', 'permite_reserva' => true, 'requiere_garantia' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['EVENTOS'], 'codigo' => 'QUINCHO', 'nombre' => 'Quincho', 'unidad_medida' => 'hora', 'permite_reserva' => true, 'requiere_garantia' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['EVENTOS'], 'codigo' => 'TERRAZA', 'nombre' => 'Terraza Común', 'unidad_medida' => 'hora', 'permite_reserva' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['EVENTOS'], 'codigo' => 'PISCINA', 'nombre' => 'Piscina (Uso Privado)', 'unidad_medida' => 'hora', 'permite_reserva' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            
            // Concesiones
            ['categoria_id' => $categorias['CONCESIONES'], 'codigo' => 'CONC_CAFETERIA', 'nombre' => 'Concesión Cafetería', 'unidad_medida' => 'mes', 'requiere_garantia' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['CONCESIONES'], 'codigo' => 'CONC_LAVANDERIA', 'nombre' => 'Concesión Lavandería', 'unidad_medida' => 'mes', 'requiere_garantia' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['CONCESIONES'], 'codigo' => 'CONC_MINIMARKET', 'nombre' => 'Concesión Minimarket', 'unidad_medida' => 'mes', 'requiere_garantia' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['CONCESIONES'], 'codigo' => 'CONC_GYM', 'nombre' => 'Concesión Gimnasio', 'unidad_medida' => 'mes', 'requiere_garantia' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
            ['categoria_id' => $categorias['CONCESIONES'], 'codigo' => 'CONC_GUARDERIA', 'nombre' => 'Concesión Guardería', 'unidad_medida' => 'mes', 'requiere_garantia' => true, 'activo' => true, 'created_at' => now(), 'updated_at' => now()],
        ]);
    }

    public function down(): void
    {
        // Quitar columnas de contratos_arriendo
        Schema::table('contratos_arriendo', function (Blueprint $table) {
            $table->dropConstrainedForeignId('espacio_id');
            $table->dropColumn(['categoria_tributaria', 'tipo_espacio_detallado', 'datos_adicionales']);
        });

        Schema::dropIfExists('pagos_concesion');
        Schema::dropIfExists('contratos_concesion');
        Schema::dropIfExists('reservas_espacios');
        Schema::dropIfExists('espacios_arrendables');
        Schema::dropIfExists('tipos_espacio_arriendo');
        Schema::dropIfExists('categorias_arriendo');
    }
};
