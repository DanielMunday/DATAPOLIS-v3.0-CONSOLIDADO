<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Crear Tenant por defecto
        $tenantId = DB::table('tenants')->insertGetId([
            'nombre' => 'DATAPOLIS Demo',
            'rut' => '76.000.000-0',
            'direccion' => 'Santiago, Chile',
            'email' => 'admin@datapolis.cl',
            'activo' => true,
            'plan' => 'enterprise',
            'max_edificios' => 100,
            'max_usuarios' => 50,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Crear Usuario Admin
        DB::table('users')->insert([
            'tenant_id' => $tenantId,
            'name' => 'Administrador',
            'email' => 'admin@datapolis.cl',
            'password' => Hash::make('admin123'),
            'rut' => '11.111.111-1',
            'activo' => true,
            'email_verified_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Crear Edificio de ejemplo
        $edificioId = DB::table('edificios')->insertGetId([
            'tenant_id' => $tenantId,
            'nombre' => 'Edificio Demo',
            'direccion' => 'Av. Providencia 1234',
            'comuna' => 'Providencia',
            'region' => 'Metropolitana',
            'rut' => '76.100.000-1',
            'tipo' => 'residencial',
            'total_unidades' => 50,
            'activo' => true,
            'administrador_nombre' => 'Juan Pérez',
            'administrador_email' => 'admin@edificiodemo.cl',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Crear algunas unidades de ejemplo
        $tipos = ['departamento', 'estacionamiento', 'bodega'];
        for ($i = 1; $i <= 10; $i++) {
            DB::table('unidades')->insert([
                'tenant_id' => $tenantId,
                'edificio_id' => $edificioId,
                'numero' => $i <= 8 ? (string)($i * 100 + 1) : ($i == 9 ? 'E-01' : 'B-01'),
                'tipo' => $i <= 8 ? 'departamento' : ($i == 9 ? 'estacionamiento' : 'bodega'),
                'piso' => $i <= 8 ? $i : 0,
                'superficie_util' => $i <= 8 ? rand(50, 120) : rand(10, 20),
                'prorrateo' => round(100 / 10, 4),
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        // Crear Plan de Cuentas básico
        $cuentas = [
            ['codigo' => '1', 'nombre' => 'ACTIVOS', 'tipo' => 'activo', 'nivel' => 1],
            ['codigo' => '1.1', 'nombre' => 'Activo Corriente', 'tipo' => 'activo', 'nivel' => 2],
            ['codigo' => '1.1.01', 'nombre' => 'Caja', 'tipo' => 'activo', 'nivel' => 3],
            ['codigo' => '1.1.02', 'nombre' => 'Banco', 'tipo' => 'activo', 'nivel' => 3],
            ['codigo' => '1.1.03', 'nombre' => 'Cuentas por Cobrar', 'tipo' => 'activo', 'nivel' => 3],
            ['codigo' => '2', 'nombre' => 'PASIVOS', 'tipo' => 'pasivo', 'nivel' => 1],
            ['codigo' => '2.1', 'nombre' => 'Pasivo Corriente', 'tipo' => 'pasivo', 'nivel' => 2],
            ['codigo' => '2.1.01', 'nombre' => 'Cuentas por Pagar', 'tipo' => 'pasivo', 'nivel' => 3],
            ['codigo' => '2.1.02', 'nombre' => 'Remuneraciones por Pagar', 'tipo' => 'pasivo', 'nivel' => 3],
            ['codigo' => '3', 'nombre' => 'PATRIMONIO', 'tipo' => 'patrimonio', 'nivel' => 1],
            ['codigo' => '3.1', 'nombre' => 'Fondo Común', 'tipo' => 'patrimonio', 'nivel' => 2],
            ['codigo' => '3.2', 'nombre' => 'Fondo de Reserva', 'tipo' => 'patrimonio', 'nivel' => 2],
            ['codigo' => '4', 'nombre' => 'INGRESOS', 'tipo' => 'ingreso', 'nivel' => 1],
            ['codigo' => '4.1', 'nombre' => 'Ingresos Operacionales', 'tipo' => 'ingreso', 'nivel' => 2],
            ['codigo' => '4.1.01', 'nombre' => 'Gastos Comunes', 'tipo' => 'ingreso', 'nivel' => 3],
            ['codigo' => '4.1.02', 'nombre' => 'Arriendos', 'tipo' => 'ingreso', 'nivel' => 3],
            ['codigo' => '4.1.03', 'nombre' => 'Multas e Intereses', 'tipo' => 'ingreso', 'nivel' => 3],
            ['codigo' => '5', 'nombre' => 'GASTOS', 'tipo' => 'gasto', 'nivel' => 1],
            ['codigo' => '5.1', 'nombre' => 'Gastos Operacionales', 'tipo' => 'gasto', 'nivel' => 2],
            ['codigo' => '5.1.01', 'nombre' => 'Remuneraciones', 'tipo' => 'gasto', 'nivel' => 3],
            ['codigo' => '5.1.02', 'nombre' => 'Servicios Básicos', 'tipo' => 'gasto', 'nivel' => 3],
            ['codigo' => '5.1.03', 'nombre' => 'Mantención', 'tipo' => 'gasto', 'nivel' => 3],
        ];

        foreach ($cuentas as $cuenta) {
            DB::table('cuentas_contables')->insert([
                'tenant_id' => $tenantId,
                'edificio_id' => $edificioId,
                'codigo' => $cuenta['codigo'],
                'nombre' => $cuenta['nombre'],
                'tipo' => $cuenta['tipo'],
                'nivel' => $cuenta['nivel'],
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $this->command->info('✅ Base de datos inicializada con datos de ejemplo');
        $this->command->info('   Usuario: admin@datapolis.cl');
        $this->command->info('   Contraseña: admin123');
    }
}
