# 📦 DATAPOLIS PRO v3.0 - MÓDULOS FUNCIONALES (SERVICIOS)

## Documentación Completa de Funcionalidades, Testing e Integraciones

---

## 📑 ÍNDICE DE MÓDULOS

| # | Módulo | Controlador Principal | Endpoints |
|:-:|--------|----------------------|:---------:|
| 1 | [Autenticación y Seguridad](#1-autenticación-y-seguridad) | AuthController | 7 |
| 2 | [Dashboard Central](#2-dashboard-central) | DashboardController | 4 |
| 3 | [Gestión de Edificios](#3-gestión-de-edificios) | EdificioController | 6 |
| 4 | [Gestión de Unidades](#4-gestión-de-unidades) | UnidadController | 6 |
| 5 | [Gestión de Personas](#5-gestión-de-personas) | PersonaController | 5 |
| 6 | [Gastos Comunes](#6-gastos-comunes) | GastosComunesController | 14 |
| 7 | [Arriendos (Antenas)](#7-arriendos-de-antenas) | ArriendosController | 12 |
| 8 | [Distribución de Ingresos](#8-distribución-de-ingresos) | DistribucionController | 8 |
| 9 | [Recursos Humanos](#9-recursos-humanos-rrhh) | RRHHController | 12 |
| 10 | [Contabilidad](#10-contabilidad) | ContabilidadController | 14 |
| 11 | [Reuniones y Asambleas](#11-reuniones-y-asambleas) | ReunionesController | 15 |
| 12 | [Asistente Legal](#12-asistente-legal) | AsistenteLegalController | 3 |
| 13 | [Protección de Datos](#13-protección-de-datos-personales) | ProteccionDatosController | 18 |
| 14 | [Reportes Tributarios](#14-reportes-tributarios-sii) | ReportesTributariosController | 25+ |
| 15 | [Notificaciones](#15-sistema-de-notificaciones) | NotificacionesController | 15 |
| 16 | [Análisis de Reglamentos](#16-análisis-de-reglamentos) | ReglamentoAnalisisController | 8 |
| 17 | [Simulador de Sanciones](#17-simulador-de-sanciones-tributarias) | SimuladorSancionesController | 10 |
| 18 | [Certificación Compliance](#18-certificación-de-compliance) | CertificacionComplianceController | 12 |
| 19 | [Portal Copropietarios](#19-portal-de-copropietarios) | Portal/* (5 controllers) | 40+ |

**TOTAL: 240+ Endpoints API REST**

---

# 1. AUTENTICACIÓN Y SEGURIDAD

## Descripción
Sistema de autenticación multi-tenant basado en Laravel Sanctum con gestión de roles y permisos mediante Spatie Permission.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Login | `/api/auth/login` | POST | Autenticación con email/password |
| Logout | `/api/auth/logout` | POST | Cierre de sesión |
| Registro | `/api/auth/register` | POST | Registro de nuevos usuarios |
| Usuario actual | `/api/auth/me` | GET | Obtener datos del usuario logueado |
| Actualizar perfil | `/api/auth/profile` | PUT | Actualizar datos personales |
| Cambiar password | `/api/auth/password` | PUT | Cambio de contraseña |
| Refresh token | `/api/auth/refresh` | POST | Renovar token de sesión |

## Guía de Testing

```bash
# 1. Login
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@datapolis.cl","password":"password"}'

# Respuesta esperada:
{
  "success": true,
  "data": {
    "user": { "id": 1, "name": "Admin", "email": "admin@datapolis.cl" },
    "token": "1|abc123...",
    "roles": ["admin"]
  }
}

# 2. Obtener usuario actual (autenticado)
curl -X GET http://localhost:8000/api/auth/me \
  -H "Authorization: Bearer 1|abc123..."
```

## Integraciones

| Integra con | Tipo | Descripción |
|-------------|:----:|-------------|
| Todos los módulos | Requerido | Middleware auth:sanctum |
| Roles/Permisos | Spatie | Control de acceso granular |
| Portal Copropietarios | Separado | Auth independiente con PIN |

---

# 2. DASHBOARD CENTRAL

## Descripción
Panel de control centralizado que muestra métricas en tiempo real, alertas y resúmenes de todos los módulos del sistema.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Resumen general | `/api/dashboard` | GET | KPIs principales |
| Alertas | `/api/dashboard/alertas` | GET | Alertas activas del sistema |
| Métricas financieras | `/api/dashboard/finanzas` | GET | Recaudación, morosidad |
| Cumplimiento legal | `/api/dashboard/compliance` | GET | Estado de cumplimiento |

## Datos que muestra

```json
{
  "edificios": {
    "total": 12,
    "unidades_totales": 847,
    "unidades_habitadas": 823
  },
  "finanzas": {
    "recaudacion_mes": 45200000,
    "morosidad_total": 12800000,
    "tasa_morosidad": 28.3
  },
  "compliance": {
    "ley_21442": { "cumplimiento": 95, "estado": "ok" },
    "ley_21713": { "cumplimiento": 88, "estado": "warning" },
    "ley_21719": { "cumplimiento": 92, "estado": "ok" },
    "ds_7_2025": { "cumplimiento": 78, "estado": "warning" }
  },
  "alertas": [
    { "tipo": "vencimiento", "mensaje": "DJ 1835 vence en 15 días", "prioridad": "alta" }
  ]
}
```

## Guía de Testing

```bash
# Obtener dashboard completo
curl -X GET http://localhost:8000/api/dashboard \
  -H "Authorization: Bearer TOKEN"
```

## Integraciones

| Integra con | Datos obtenidos |
|-------------|-----------------|
| Edificios | Conteo total, ocupación |
| Gastos Comunes | Recaudación, morosidad |
| Arriendos | Ingresos antenas |
| Compliance | Estado cumplimiento |
| Notificaciones | Alertas pendientes |

---

# 3. GESTIÓN DE EDIFICIOS

## Descripción
Administración completa de comunidades y edificios, incluyendo datos generales, configuración de cargos y parámetros operativos.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Listar edificios | `/api/edificios` | GET | Lista paginada |
| Ver edificio | `/api/edificios/{id}` | GET | Detalle completo |
| Crear edificio | `/api/edificios` | POST | Nuevo edificio |
| Actualizar | `/api/edificios/{id}` | PUT | Modificar datos |
| Eliminar | `/api/edificios/{id}` | DELETE | Eliminar edificio |
| Estadísticas | `/api/edificios/{id}/stats` | GET | Métricas del edificio |

## Modelo de Datos

```json
{
  "id": 1,
  "nombre": "Edificio Central",
  "direccion": "Av. Providencia 1234",
  "comuna": "Providencia",
  "ciudad": "Santiago",
  "region": "Metropolitana",
  "rut_comunidad": "65.123.456-7",
  "fecha_recepcion_municipal": "2020-01-15",
  "total_unidades": 120,
  "total_estacionamientos": 80,
  "total_bodegas": 40,
  "superficie_total": 15000.50,
  "fondo_reserva_porcentaje": 5,
  "interes_mora_porcentaje": 3,
  "dias_gracia": 5,
  "configuracion": {
    "permite_mascotas": true,
    "horario_mudanza": "09:00-18:00",
    "areas_comunes": ["piscina", "gimnasio", "quincho"]
  }
}
```

## Guía de Testing

```bash
# Crear edificio
curl -X POST http://localhost:8000/api/edificios \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Torres del Parque",
    "direccion": "Av. Apoquindo 5000",
    "comuna": "Las Condes",
    "rut_comunidad": "65.987.654-3",
    "total_unidades": 200
  }'

# Obtener estadísticas
curl -X GET http://localhost:8000/api/edificios/1/stats \
  -H "Authorization: Bearer TOKEN"
```

## Integraciones

| Integra con | Relación |
|-------------|----------|
| Unidades | 1:N - Un edificio tiene muchas unidades |
| Gastos Comunes | Períodos y boletas por edificio |
| Arriendos | Contratos de antenas por edificio |
| Reuniones | Asambleas por comunidad |

---

# 4. GESTIÓN DE UNIDADES

## Descripción
Administración de departamentos, estacionamientos y bodegas, incluyendo propietarios, arrendatarios y porcentajes de participación.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Listar unidades | `/api/unidades` | GET | Lista paginada con filtros |
| Ver unidad | `/api/unidades/{id}` | GET | Detalle con propietario |
| Crear unidad | `/api/unidades` | POST | Nueva unidad |
| Actualizar | `/api/unidades/{id}` | PUT | Modificar datos |
| Eliminar | `/api/unidades/{id}` | DELETE | Eliminar unidad |
| Estado cuenta | `/api/unidades/{id}/estado-cuenta` | GET | Deudas y pagos |

## Modelo de Datos

```json
{
  "id": 1,
  "edificio_id": 1,
  "numero": "101",
  "tipo": "departamento",
  "piso": 1,
  "superficie_util": 85.5,
  "superficie_terraza": 12.0,
  "porcentaje_dominio": 0.83,
  "porcentaje_gc": 0.85,
  "habitaciones": 3,
  "banos": 2,
  "propietario": {
    "id": 5,
    "nombre": "Juan Pérez",
    "rut": "12.345.678-9",
    "email": "juan@email.com"
  },
  "arrendatario": null,
  "estado": "habitado"
}
```

## Guía de Testing

```bash
# Listar unidades de un edificio
curl -X GET "http://localhost:8000/api/unidades?edificio_id=1&tipo=departamento" \
  -H "Authorization: Bearer TOKEN"

# Ver estado de cuenta
curl -X GET http://localhost:8000/api/unidades/1/estado-cuenta \
  -H "Authorization: Bearer TOKEN"
```

## Integraciones

| Integra con | Relación |
|-------------|----------|
| Edificios | N:1 - Pertenece a un edificio |
| Personas | Propietario/Arrendatario |
| Gastos Comunes | Boletas por unidad |
| Portal | Acceso del copropietario |

---

# 5. GESTIÓN DE PERSONAS

## Descripción
Registro centralizado de propietarios, arrendatarios, y otros roles relacionados con el condominio.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Listar personas | `/api/personas` | GET | Lista con filtros |
| Ver persona | `/api/personas/{id}` | GET | Detalle completo |
| Crear persona | `/api/personas` | POST | Nueva persona |
| Actualizar | `/api/personas/{id}` | PUT | Modificar datos |
| Buscar por RUT | `/api/personas/rut/{rut}` | GET | Búsqueda por RUT |

## Modelo de Datos

```json
{
  "id": 1,
  "rut": "12.345.678-9",
  "nombre": "Juan",
  "apellido_paterno": "Pérez",
  "apellido_materno": "González",
  "email": "juan@email.com",
  "telefono": "+56912345678",
  "direccion": "Av. Providencia 1234, Depto 101",
  "tipo": "propietario",
  "fecha_nacimiento": "1980-05-15",
  "nacionalidad": "Chilena",
  "estado_civil": "casado",
  "profesion": "Ingeniero",
  "unidades": [
    { "id": 1, "numero": "101", "rol": "propietario" }
  ]
}
```

## Integraciones

| Integra con | Relación |
|-------------|----------|
| Unidades | Propietario/Arrendatario |
| RRHH | Empleados del condominio |
| Protección Datos | Titular de datos ARCO |

---

# 6. GASTOS COMUNES

## Descripción
**Módulo central del sistema.** Gestión completa del ciclo de gastos comunes: períodos, cargos, boletas, pagos y cobranza con cumplimiento de Ley 21.442.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Períodos | `/api/gastos-comunes/periodos` | GET/POST | Gestión de períodos |
| Cargos | `/api/gastos-comunes/cargos` | GET/POST | Tipos de cargo |
| Boletas | `/api/gastos-comunes/boletas` | GET | Boletas emitidas |
| Generar boletas | `/api/gastos-comunes/generar` | POST | Generación masiva |
| Registrar pago | `/api/gastos-comunes/pagos` | POST | Registrar pago |
| Mora | `/api/gastos-comunes/mora` | GET | Cálculo de mora |
| Cobranza | `/api/gastos-comunes/cobranza` | POST | Proceso de cobranza |
| Estado cuenta | `/api/gastos-comunes/estado-cuenta/{unidad}` | GET | Estado por unidad |
| Proyección | `/api/gastos-comunes/proyeccion` | GET | Proyección anual |
| Certificado | `/api/gastos-comunes/certificado/{unidad}` | GET | Certificado deuda |

## Modelo de Boleta

```json
{
  "id": 1,
  "unidad_id": 1,
  "periodo_id": 12,
  "periodo": "2025-01",
  "fecha_emision": "2025-01-05",
  "fecha_vencimiento": "2025-01-15",
  "cargos": [
    { "concepto": "Gasto Común Ordinario", "monto": 85000 },
    { "concepto": "Fondo de Reserva", "monto": 4250 },
    { "concepto": "Agua Caliente", "monto": 12500 }
  ],
  "subtotal": 101750,
  "descuentos": 0,
  "interes_mora": 0,
  "total": 101750,
  "estado": "pendiente",
  "dias_mora": 0
}
```

## Cálculo de Mora (Ley 21.442)

```php
// Límite máximo: 3% mensual según Ley 21.442 Art. 5
$interes = min($dias_mora * ($tasa_diaria), $monto * 0.03);

// Con días de gracia configurables (default: 5 días)
if ($dias_desde_vencimiento <= $dias_gracia) {
    $interes = 0;
}
```

## Guía de Testing

```bash
# Generar boletas del período
curl -X POST http://localhost:8000/api/gastos-comunes/generar \
  -H "Authorization: Bearer TOKEN" \
  -d '{"edificio_id": 1, "periodo": "2025-01"}'

# Registrar pago
curl -X POST http://localhost:8000/api/gastos-comunes/pagos \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "boleta_id": 1,
    "monto": 101750,
    "medio_pago": "transferencia",
    "fecha_pago": "2025-01-10",
    "comprobante": "TRF-12345"
  }'

# Ver estado de cuenta
curl -X GET http://localhost:8000/api/gastos-comunes/estado-cuenta/1 \
  -H "Authorization: Bearer TOKEN"
```

## Integraciones

| Integra con | Función |
|-------------|---------|
| Edificios | Configuración de períodos |
| Unidades | Generación de boletas |
| Contabilidad | Asientos automáticos |
| Notificaciones | Avisos de cobranza |
| Portal | Pago online |
| Reportes | Estadísticas financieras |

---

# 7. ARRIENDOS DE ANTENAS

## Descripción
Gestión de contratos de arriendo de espacios comunes para antenas de telecomunicaciones, con cumplimiento tributario según Ley 21.713.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Contratos | `/api/arriendos/contratos` | GET/POST | Gestión contratos |
| Facturas | `/api/arriendos/facturas` | GET/POST | Facturación |
| Pagos recibidos | `/api/arriendos/pagos` | GET/POST | Control pagos |
| Distribución | `/api/arriendos/distribucion` | POST | Distribuir a copropietarios |
| Proyección | `/api/arriendos/proyeccion` | GET | Proyección anual |
| Retención | `/api/arriendos/retencion` | GET | Cálculo retención |
| Reporte tributario | `/api/arriendos/reporte-tributario` | GET | Para DJ 1835 |

## Modelo de Contrato

```json
{
  "id": 1,
  "edificio_id": 1,
  "arrendatario": {
    "rut": "96.575.990-0",
    "razon_social": "Entel PCS Telecomunicaciones S.A.",
    "representante": "Carlos Silva",
    "email": "arriendos@entel.cl"
  },
  "fecha_inicio": "2023-01-01",
  "fecha_termino": "2027-12-31",
  "monto_mensual": 2500000,
  "reajuste": "IPC",
  "ubicacion": "Azotea Torre A",
  "equipamiento": "2 antenas + equipos transmisión",
  "estado": "vigente",
  "proximo_reajuste": "2025-07-01"
}
```

## Cálculo Tributario (Ley 21.713)

```php
// Para cada copropietario según % de dominio
$ingreso_proporcional = $monto_arriendo * $porcentaje_dominio;

// Tributación según tramo
if ($ingreso_proporcional <= 10 * $UTA) {
    // Exento o tasa reducida
} else {
    // Impuesto según tabla Art. 42 LIR
}
```

## Guía de Testing

```bash
# Crear contrato
curl -X POST http://localhost:8000/api/arriendos/contratos \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "edificio_id": 1,
    "arrendatario_rut": "96.575.990-0",
    "monto_mensual": 2500000,
    "fecha_inicio": "2025-01-01",
    "duracion_meses": 60
  }'

# Distribuir ingresos
curl -X POST http://localhost:8000/api/arriendos/distribucion \
  -H "Authorization: Bearer TOKEN" \
  -d '{"contrato_id": 1, "periodo": "2025-01"}'
```

## Integraciones

| Integra con | Función |
|-------------|---------|
| Edificios | Contratos por edificio |
| Distribución | Reparto a copropietarios |
| Contabilidad | Registro de ingresos |
| Reportes Tributarios | DJ 1835 automática |
| Notificaciones | Alertas vencimientos |

---

# 8. DISTRIBUCIÓN DE INGRESOS

## Descripción
Cálculo y distribución de ingresos por arriendos entre copropietarios según porcentaje de dominio, con trazabilidad completa.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Calcular | `/api/distribucion/calcular` | POST | Calcular distribución |
| Ejecutar | `/api/distribucion/ejecutar` | POST | Aplicar distribución |
| Historial | `/api/distribucion/historial` | GET | Distribuciones pasadas |
| Por unidad | `/api/distribucion/unidad/{id}` | GET | Distribución por unidad |
| Certificado | `/api/distribucion/certificado/{id}` | GET | Certificado para SII |
| Proyección | `/api/distribucion/proyeccion` | GET | Proyección anual |

## Modelo de Distribución

```json
{
  "id": 1,
  "contrato_arriendo_id": 1,
  "periodo": "2025-01",
  "monto_total": 2500000,
  "fecha_distribucion": "2025-02-05",
  "detalle": [
    {
      "unidad_id": 1,
      "numero": "101",
      "propietario": "Juan Pérez",
      "rut": "12.345.678-9",
      "porcentaje_dominio": 0.83,
      "monto_bruto": 20750,
      "retencion": 0,
      "monto_neto": 20750
    }
  ],
  "estado": "ejecutada"
}
```

## Integraciones

| Integra con | Función |
|-------------|---------|
| Arriendos | Origen de ingresos |
| Unidades | Porcentajes de dominio |
| Reportes Tributarios | Información para DJ |
| Notificaciones | Aviso de distribución |

---

# 9. RECURSOS HUMANOS (RRHH)

## Descripción
Gestión completa de personal del condominio: contratos, liquidaciones, vacaciones, finiquitos y cumplimiento laboral.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Empleados | `/api/rrhh/empleados` | GET/POST | Gestión empleados |
| Contratos | `/api/rrhh/contratos` | GET/POST | Contratos laborales |
| Liquidaciones | `/api/rrhh/liquidaciones` | GET/POST | Liquidaciones sueldo |
| Generar liquidación | `/api/rrhh/liquidaciones/generar` | POST | Generación masiva |
| Vacaciones | `/api/rrhh/vacaciones` | GET/POST | Control vacaciones |
| Finiquitos | `/api/rrhh/finiquitos` | GET/POST | Proceso finiquito |
| Libro remuneraciones | `/api/rrhh/libro-remuneraciones` | GET | Libro legal |
| Previred | `/api/rrhh/previred` | GET | Archivo Previred |

## Modelo de Liquidación

```json
{
  "id": 1,
  "empleado_id": 1,
  "periodo": "2025-01",
  "dias_trabajados": 30,
  "haberes": {
    "sueldo_base": 600000,
    "gratificacion": 50000,
    "colacion": 30000,
    "movilizacion": 25000,
    "horas_extra": 45000
  },
  "total_haberes": 750000,
  "descuentos": {
    "afp": 75000,
    "salud": 52500,
    "seguro_cesantia": 4500,
    "impuesto_unico": 0,
    "anticipos": 100000
  },
  "total_descuentos": 232000,
  "liquido_a_pagar": 518000
}
```

## Cálculos Previsionales

```php
// AFP (10.XX% según AFP)
$descuento_afp = $imponible * $tasa_afp;

// Salud (7% o ISAPRE)
$descuento_salud = $imponible * 0.07;

// Seguro Cesantía (0.6% trabajador)
$descuento_cesantia = $imponible * 0.006;

// Topes imponibles
$tope_afp = 81.6 * $UF; // ~3.1M CLP
$tope_cesantia = 126.6 * $UF; // ~4.8M CLP
```

## Guía de Testing

```bash
# Generar liquidaciones del mes
curl -X POST http://localhost:8000/api/rrhh/liquidaciones/generar \
  -H "Authorization: Bearer TOKEN" \
  -d '{"edificio_id": 1, "periodo": "2025-01"}'

# Generar archivo Previred
curl -X GET "http://localhost:8000/api/rrhh/previred?periodo=2025-01" \
  -H "Authorization: Bearer TOKEN"
```

## Integraciones

| Integra con | Función |
|-------------|---------|
| Contabilidad | Provisiones y gastos |
| Gastos Comunes | Costo de personal |
| Reportes Tributarios | F29, DJ |
| Notificaciones | Alertas vencimientos |

---

# 10. CONTABILIDAD

## Descripción
Sistema contable completo con plan de cuentas chileno, libro diario, mayor, balance y estados financieros.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Plan de cuentas | `/api/contabilidad/cuentas` | GET/POST | Gestión cuentas |
| Asientos | `/api/contabilidad/asientos` | GET/POST | Libro diario |
| Mayor | `/api/contabilidad/mayor/{cuenta}` | GET | Libro mayor |
| Balance | `/api/contabilidad/balance` | GET | Balance de comprobación |
| Estado resultados | `/api/contabilidad/estado-resultados` | GET | Resultado del ejercicio |
| Balance general | `/api/contabilidad/balance-general` | GET | Activos y pasivos |
| Conciliación | `/api/contabilidad/conciliacion` | GET/POST | Conciliación bancaria |
| Cierre | `/api/contabilidad/cierre` | POST | Cierre de período |

## Plan de Cuentas (Estructura)

```
1. ACTIVOS
   1.1 Activo Circulante
       1.1.1 Caja
       1.1.2 Banco
       1.1.3 Cuentas por Cobrar (Gastos Comunes)
       1.1.4 Deudores Morosos
   1.2 Activo Fijo
       1.2.1 Equipamiento
       1.2.2 Depreciación Acumulada

2. PASIVOS
   2.1 Pasivo Circulante
       2.1.1 Proveedores
       2.1.2 Remuneraciones por Pagar
       2.1.3 Retenciones por Pagar

3. PATRIMONIO
   3.1 Fondo de Reserva
   3.2 Resultado del Ejercicio

4. INGRESOS
   4.1 Gastos Comunes
   4.2 Arriendos Antenas
   4.3 Multas y Recargos

5. GASTOS
   5.1 Remuneraciones
   5.2 Servicios Básicos
   5.3 Mantención
   5.4 Seguros
```

## Guía de Testing

```bash
# Crear asiento contable
curl -X POST http://localhost:8000/api/contabilidad/asientos \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "fecha": "2025-01-15",
    "glosa": "Pago gastos comunes Depto 101",
    "movimientos": [
      {"cuenta": "1.1.2", "debe": 101750, "haber": 0},
      {"cuenta": "1.1.3", "debe": 0, "haber": 101750}
    ]
  }'

# Obtener balance
curl -X GET "http://localhost:8000/api/contabilidad/balance?periodo=2025-01" \
  -H "Authorization: Bearer TOKEN"
```

## Integraciones

| Integra con | Función |
|-------------|---------|
| Gastos Comunes | Asientos automáticos cobros |
| Arriendos | Asientos ingresos antenas |
| RRHH | Asientos remuneraciones |
| Reportes Tributarios | Base para declaraciones |

---

# 11. REUNIONES Y ASAMBLEAS

## Descripción
Gestión completa de asambleas de copropietarios: convocatorias, quórum, votaciones, actas y seguimiento de acuerdos según Ley 21.442.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Reuniones | `/api/reuniones` | GET/POST | Gestión reuniones |
| Convocatoria | `/api/reuniones/{id}/convocar` | POST | Enviar convocatoria |
| Asistencia | `/api/reuniones/{id}/asistencia` | GET/POST | Control asistencia |
| Quórum | `/api/reuniones/{id}/quorum` | GET | Verificar quórum |
| Votaciones | `/api/reuniones/{id}/votaciones` | GET/POST | Gestión votaciones |
| Votar | `/api/reuniones/{id}/votar` | POST | Registrar voto |
| Acta | `/api/reuniones/{id}/acta` | GET/POST | Generar acta |
| Acuerdos | `/api/reuniones/{id}/acuerdos` | GET | Acuerdos tomados |
| Seguimiento | `/api/reuniones/acuerdos/seguimiento` | GET | Estado acuerdos |

## Modelo de Reunión

```json
{
  "id": 1,
  "edificio_id": 1,
  "tipo": "ordinaria",
  "fecha": "2025-03-15",
  "hora": "19:00",
  "lugar": "Sala de eventos",
  "tabla": [
    "Lectura acta anterior",
    "Rendición cuentas 2024",
    "Aprobación presupuesto 2025",
    "Elección comité administración"
  ],
  "quorum_requerido": "mayoria_absoluta",
  "estado": "convocada",
  "asistentes_confirmados": 45,
  "porcentaje_representado": 67.5
}
```

## Quórum Legal (Ley 21.442)

```php
// Mayoría absoluta: >50% de derechos representados
// Mayoría calificada: >66.67% para temas específicos
// Unanimidad: 100% para modificación reglamento interno

$quorum_tipos = [
    'simple' => 0.50,
    'absoluta' => 0.50,
    'calificada' => 0.6667,
    'unanimidad' => 1.00
];
```

## Guía de Testing

```bash
# Crear asamblea
curl -X POST http://localhost:8000/api/reuniones \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "edificio_id": 1,
    "tipo": "ordinaria",
    "fecha": "2025-03-15",
    "hora": "19:00",
    "tabla": ["Aprobación presupuesto", "Elección comité"]
  }'

# Enviar convocatoria
curl -X POST http://localhost:8000/api/reuniones/1/convocar \
  -H "Authorization: Bearer TOKEN"
```

## Integraciones

| Integra con | Función |
|-------------|---------|
| Unidades | Derechos de voto |
| Notificaciones | Envío convocatorias |
| Portal | Votación online |
| Documentos | Actas generadas |

---

# 12. ASISTENTE LEGAL

## Descripción
Consultor de normativa legal chilena relacionada con copropiedad, tributación y protección de datos.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Consulta | `/api/legal/consulta` | POST | Consultar normativa |
| Artículos | `/api/legal/articulos` | GET | Buscar artículos |
| Leyes | `/api/legal/leyes` | GET | Base de leyes |

## Base de Conocimiento

```
LEYES INCLUIDAS:
├── Ley 21.442 - Copropiedad Inmobiliaria (2022)
├── Ley 21.713 - Cumplimiento Tributario (2024)
├── Ley 21.719 - Protección de Datos (2024)
├── DS 7-2025 - Reglamento Copropiedad
├── DFL 2 - Viviendas Económicas
└── Código Civil - Artículos relacionados
```

## Guía de Testing

```bash
# Consultar sobre mora
curl -X POST http://localhost:8000/api/legal/consulta \
  -H "Authorization: Bearer TOKEN" \
  -d '{"pregunta": "¿Cuál es el interés máximo por mora?"}'

# Respuesta:
{
  "respuesta": "Según el Art. 5 de la Ley 21.442, el interés por mora no puede exceder el 3% mensual sobre el monto adeudado.",
  "referencias": [
    {"ley": "21.442", "articulo": "5", "texto": "..."}
  ]
}
```

---

# 13. PROTECCIÓN DE DATOS PERSONALES

## Descripción
Cumplimiento de Ley 21.719 de Protección de Datos Personales: registro de tratamientos, derechos ARCO, consentimientos y brechas.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Registro tratamientos | `/api/proteccion-datos/tratamientos` | GET/POST | Registro legal |
| Consentimientos | `/api/proteccion-datos/consentimientos` | GET/POST | Gestión consentimientos |
| Solicitudes ARCO | `/api/proteccion-datos/arco` | GET/POST | Derechos ARCO |
| Procesar ARCO | `/api/proteccion-datos/arco/{id}/procesar` | POST | Responder solicitud |
| Brechas | `/api/proteccion-datos/brechas` | GET/POST | Registro brechas |
| Exportar datos | `/api/proteccion-datos/exportar/{persona}` | GET | Portabilidad |
| Eliminar datos | `/api/proteccion-datos/eliminar/{persona}` | DELETE | Derecho olvido |

## Derechos ARCO

```
A - Acceso: Conocer qué datos se tienen
R - Rectificación: Corregir datos inexactos
C - Cancelación: Eliminar datos
O - Oposición: Oponerse al tratamiento
```

## Guía de Testing

```bash
# Crear solicitud ARCO
curl -X POST http://localhost:8000/api/proteccion-datos/arco \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "tipo": "acceso",
    "solicitante_rut": "12.345.678-9",
    "descripcion": "Solicito copia de todos mis datos personales"
  }'

# Exportar datos (portabilidad)
curl -X GET http://localhost:8000/api/proteccion-datos/exportar/1 \
  -H "Authorization: Bearer TOKEN"
```

## Integraciones

| Integra con | Función |
|-------------|---------|
| Personas | Titulares de datos |
| Notificaciones | Respuestas ARCO |
| Compliance | Verificación cumplimiento |

---

# 14. REPORTES TRIBUTARIOS (SII)

## Descripción
Generación automática de declaraciones juradas y reportes tributarios para el Servicio de Impuestos Internos.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| DJ 1835 | `/api/reportes-tributarios/dj1835` | GET/POST | Arriendos inmuebles |
| DJ 1887 | `/api/reportes-tributarios/dj1887` | GET/POST | Honorarios |
| DJ 1879 | `/api/reportes-tributarios/dj1879` | GET/POST | Retenciones |
| F29 | `/api/reportes-tributarios/f29` | GET | Formulario 29 |
| Certificados | `/api/reportes-tributarios/certificados` | GET | Certificados anuales |
| Validar | `/api/reportes-tributarios/validar` | POST | Validar antes envío |
| Histórico | `/api/reportes-tributarios/historico` | GET | Declaraciones pasadas |

## DJ 1835 - Arriendos de Bienes Raíces

```json
{
  "año_tributario": 2025,
  "rut_declarante": "65.123.456-7",
  "tipo_declarante": "comunidad",
  "informados": [
    {
      "rut_arrendatario": "96.575.990-0",
      "razon_social": "Entel PCS",
      "monto_anual": 30000000,
      "meses_arriendo": 12,
      "tipo_bien": "espacio_azotea"
    }
  ],
  "total_informado": 30000000
}
```

## Guía de Testing

```bash
# Generar DJ 1835
curl -X POST http://localhost:8000/api/reportes-tributarios/dj1835 \
  -H "Authorization: Bearer TOKEN" \
  -d '{"edificio_id": 1, "año": 2024}'

# Validar antes de enviar
curl -X POST http://localhost:8000/api/reportes-tributarios/validar \
  -H "Authorization: Bearer TOKEN" \
  -d '{"tipo": "dj1835", "edificio_id": 1, "año": 2024}'
```

## Integraciones

| Integra con | Función |
|-------------|---------|
| Arriendos | Datos de contratos |
| Distribución | Montos por copropietario |
| RRHH | Retenciones empleados |
| Contabilidad | Cifras de respaldo |

---

# 15. SISTEMA DE NOTIFICACIONES

## Descripción
Sistema multicanal de notificaciones: email, SMS, push notifications y WhatsApp con plantillas y programación.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Enviar | `/api/notificaciones/enviar` | POST | Envío inmediato |
| Programar | `/api/notificaciones/programar` | POST | Programar envío |
| Plantillas | `/api/notificaciones/plantillas` | GET/POST | Gestión plantillas |
| Historial | `/api/notificaciones/historial` | GET | Envíos realizados |
| Preferencias | `/api/notificaciones/preferencias/{user}` | GET/PUT | Preferencias usuario |
| Push subscribe | `/api/notificaciones/push/subscribe` | POST | Suscribir push |
| Masivo | `/api/notificaciones/masivo` | POST | Envío masivo |

## Canales Disponibles

```
EMAIL     - SMTP / Mailgun / SES
SMS       - Twilio
PUSH      - Web Push (VAPID)
WHATSAPP  - WhatsApp Business API
IN-APP    - Notificaciones en sistema
```

## Plantillas Disponibles

| Plantilla | Canal | Trigger |
|-----------|:-----:|---------|
| Cobranza mora | Email | Automático día 20 |
| Pago confirmado | Email/Push | Post-pago |
| Convocatoria asamblea | Email | Manual |
| Acta disponible | Email | Post-asamblea |
| Alerta compliance | Email | Automático |
| Vencimiento contrato | Email | 30 días antes |

## Guía de Testing

```bash
# Enviar notificación
curl -X POST http://localhost:8000/api/notificaciones/enviar \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "destinatarios": [1, 2, 3],
    "plantilla": "cobranza_mora",
    "canales": ["email", "push"],
    "datos": {"periodo": "2025-01", "monto": 150000}
  }'
```

## Integraciones

| Integra con | Función |
|-------------|---------|
| Gastos Comunes | Cobranza automática |
| Reuniones | Convocatorias |
| Compliance | Alertas vencimiento |
| Portal | Notificaciones en app |

---

# 16. ANÁLISIS DE REGLAMENTOS

## Descripción
Análisis automático de reglamentos de copropiedad para verificar cumplimiento con Ley 21.442 y DS 7-2025.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Analizar | `/api/reglamentos/analizar` | POST | Subir y analizar |
| Resultado | `/api/reglamentos/{id}` | GET | Ver análisis |
| Cumplimiento | `/api/reglamentos/{id}/cumplimiento` | GET | % cumplimiento |
| Sugerencias | `/api/reglamentos/{id}/sugerencias` | GET | Mejoras sugeridas |
| Comparar | `/api/reglamentos/comparar` | POST | Comparar versiones |
| Historial | `/api/reglamentos/historial` | GET | Análisis previos |

## Resultado de Análisis

```json
{
  "id": 1,
  "edificio_id": 1,
  "fecha_analisis": "2025-01-15",
  "version_reglamento": "2023-05-01",
  "cumplimiento_general": 78,
  "secciones": {
    "derechos_propietarios": { "score": 90, "estado": "ok" },
    "obligaciones": { "score": 85, "estado": "ok" },
    "gastos_comunes": { "score": 70, "estado": "warning" },
    "asambleas": { "score": 65, "estado": "warning" },
    "administracion": { "score": 80, "estado": "ok" }
  },
  "hallazgos": [
    {
      "tipo": "warning",
      "seccion": "gastos_comunes",
      "descripcion": "No especifica límite de interés por mora",
      "referencia_legal": "Art. 5 Ley 21.442",
      "sugerencia": "Agregar cláusula limitando interés a 3% mensual"
    }
  ]
}
```

## Guía de Testing

```bash
# Subir reglamento para análisis
curl -X POST http://localhost:8000/api/reglamentos/analizar \
  -H "Authorization: Bearer TOKEN" \
  -F "edificio_id=1" \
  -F "archivo=@reglamento.pdf"
```

---

# 17. SIMULADOR DE SANCIONES TRIBUTARIAS

## Descripción
Simulación de sanciones por incumplimiento tributario según Art. 97 del Código Tributario.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Simular | `/api/sanciones/simular` | POST | Calcular sanción |
| Escenarios | `/api/sanciones/escenarios` | POST | Múltiples escenarios |
| Art 97 N°2 | `/api/sanciones/art97n2` | POST | Retardo declaración |
| Art 97 N°4 | `/api/sanciones/art97n4` | POST | Declaración maliciosa |
| Historial | `/api/sanciones/historial` | GET | Simulaciones previas |
| Comparar | `/api/sanciones/comparar` | POST | Comparar escenarios |

## Cálculo Art. 97 N°2 (Retardo)

```php
// Multa por retardo en declaración jurada
$meses_atraso = calcular_meses_atraso($fecha_vencimiento, $fecha_actual);
$uta = obtener_valor_uta();

// Mínimo: 1 UTM, Máximo: 1 UTA
$multa_base = min(max($meses_atraso * 0.1 * $uta, $utm), $uta);

// Reajuste por IPC
$multa_reajustada = aplicar_ipc($multa_base, $fecha_vencimiento);
```

## Guía de Testing

```bash
# Simular sanción por retardo
curl -X POST http://localhost:8000/api/sanciones/simular \
  -H "Authorization: Bearer TOKEN" \
  -d '{
    "tipo": "art97n2",
    "declaracion": "DJ1835",
    "fecha_vencimiento": "2025-03-31",
    "fecha_presentacion": "2025-06-15",
    "monto_omitido": 30000000
  }'
```

---

# 18. CERTIFICACIÓN DE COMPLIANCE

## Descripción
Evaluación integral del cumplimiento normativo y generación de certificados de compliance.

## Funcionalidades

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Evaluar | `/api/compliance/evaluar` | POST | Evaluación completa |
| Resultado | `/api/compliance/{id}` | GET | Ver evaluación |
| Certificado | `/api/compliance/{id}/certificado` | GET | Generar PDF |
| Plan mejora | `/api/compliance/{id}/plan-mejora` | GET | Acciones sugeridas |
| Historial | `/api/compliance/historial` | GET | Evaluaciones previas |
| Dashboard | `/api/compliance/dashboard` | GET | Resumen estado |

## Áreas Evaluadas

```
1. LEY 21.442 - Copropiedad
   ├── Gastos comunes (límite mora)
   ├── Asambleas (quórum)
   ├── Administración
   └── Fondo reserva

2. LEY 21.713 - Tributario
   ├── Declaraciones juradas
   ├── Retenciones
   └── Certificados

3. LEY 21.719 - Protección Datos
   ├── Registro tratamientos
   ├── Consentimientos
   └── Derechos ARCO

4. DS 7-2025 - Reglamento
   ├── Actualización reglamento
   ├── Comité administración
   └── Documentación
```

## Guía de Testing

```bash
# Evaluar compliance
curl -X POST http://localhost:8000/api/compliance/evaluar \
  -H "Authorization: Bearer TOKEN" \
  -d '{"edificio_id": 1}'

# Generar certificado PDF
curl -X GET http://localhost:8000/api/compliance/1/certificado \
  -H "Authorization: Bearer TOKEN" \
  --output certificado.pdf
```

---

# 19. PORTAL DE COPROPIETARIOS

## Descripción
Portal web de autoservicio para copropietarios con acceso a estado de cuenta, pagos online, documentos y participación en votaciones.

## Controladores

| Controlador | Funciones |
|-------------|-----------|
| PortalCopropietarioController | Dashboard, perfil |
| EstadoCuentaController | Boletas, historial |
| PagosOnlineController | WebPay, Khipu |
| SolicitudesController | Tickets soporte |
| DocumentosComunicadosController | Docs, avisos, votaciones |

## Funcionalidades Portal

| Función | Endpoint | Método | Descripción |
|---------|----------|:------:|-------------|
| Dashboard | `/api/portal/dashboard` | GET | Resumen cuenta |
| Estado cuenta | `/api/portal/estado-cuenta` | GET | Boletas pendientes |
| Historial pagos | `/api/portal/pagos/historial` | GET | Pagos realizados |
| Pagar WebPay | `/api/portal/pagos/webpay/iniciar` | POST | Iniciar pago |
| Pagar Khipu | `/api/portal/pagos/khipu/iniciar` | POST | Iniciar pago |
| Documentos | `/api/portal/documentos` | GET | Documentos comunidad |
| Comunicados | `/api/portal/comunicados` | GET | Avisos administración |
| Reservas | `/api/portal/reservas` | GET/POST | Reservar espacios |
| Votaciones | `/api/portal/votaciones` | GET | Votaciones activas |
| Votar | `/api/portal/votaciones/{id}/votar` | POST | Emitir voto |
| Solicitudes | `/api/portal/solicitudes` | GET/POST | Crear tickets |

## Flujo de Pago WebPay

```
1. Copropietario selecciona boletas
2. POST /api/portal/pagos/webpay/iniciar
3. Redirect a WebPay
4. Usuario paga en WebPay
5. WebPay redirect a /api/portal/pagos/webpay/retorno
6. Verificación de transacción
7. Actualización de boletas
8. Envío de comprobante
```

## Guía de Testing

```bash
# Login portal (con PIN)
curl -X POST http://localhost:8000/api/portal/auth/login \
  -d '{"rut": "12.345.678-9", "pin": "1234"}'

# Ver estado de cuenta
curl -X GET http://localhost:8000/api/portal/estado-cuenta \
  -H "Authorization: Bearer PORTAL_TOKEN"

# Iniciar pago WebPay
curl -X POST http://localhost:8000/api/portal/pagos/webpay/iniciar \
  -H "Authorization: Bearer PORTAL_TOKEN" \
  -d '{"boletas": [1, 2], "monto": 250000}'
```

---

# 📊 MATRIZ DE INTEGRACIONES

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                    DATAPOLIS PRO v3.0                        │
                    │              Matriz de Integraciones entre Módulos           │
                    └─────────────────────────────────────────────────────────────┘

     Auth ←──────────────── TODOS LOS MÓDULOS ───────────────→ Auth
      │
      ├── Dashboard ←─── Edificios, GC, Arriendos, Compliance
      │
      ├── Edificios ←──→ Unidades ←──→ Personas
      │        │              │
      │        └──────────────┼──→ Gastos Comunes ←──→ Portal
      │                       │           │
      │                       │           └──→ Contabilidad
      │                       │
      ├── Arriendos ──────────┼──→ Distribución ──→ Reportes Tributarios
      │        │              │
      │        └──────────────┴──→ Notificaciones
      │
      ├── RRHH ────────────────────→ Contabilidad ──→ Reportes Tributarios
      │
      ├── Reuniones ←──────────────→ Portal (Votaciones)
      │        │
      │        └──────────────────→ Notificaciones
      │
      ├── Protección Datos ←──────→ Personas
      │
      ├── Compliance ←─── Análisis Reglamentos
      │        │
      │        └──────────────────→ Simulador Sanciones
      │
      └── Todos ──────────────────→ Notificaciones

```

---

# ✅ ESTADO FINAL CONSOLIDADO

## Componentes Incluidos

| Componente | Archivos | Líneas | Estado |
|------------|:--------:|:------:|:------:|
| Controladores API | 24 | ~11,000 | ✅ |
| Servicios | 4 | ~3,300 | ✅ |
| Modelos | 12 | ~3,200 | ✅ |
| Migraciones | 14 | ~4,000 | ✅ |
| Frontend Admin | 15 páginas | ~3,700 | ✅ |
| Frontend Portal | 3 archivos | ~2,200 | ✅ |
| Templates Email | 10 | ~500 | ✅ |
| Templates PDF | 2 | ~200 | ✅ |
| Documentación | 10 | ~5,200 | ✅ |
| **TOTAL** | **~85** | **~35,000** | ✅ |

## Endpoints API

```
Total endpoints: 240+
├── Admin API: ~200 endpoints
└── Portal API: ~40 endpoints
```

---

© 2024-2025 DATAPOLIS SpA. Todos los derechos reservados.
