# DATAPOLIS PRO v3.0

**Plataforma Integral de Gestión de Condominios - Cumplimiento Ley 21.442**

![Version](https://img.shields.io/badge/version-3.0.0-blue.svg)
![Laravel](https://img.shields.io/badge/Laravel-11.x-red.svg)
![PHP](https://img.shields.io/badge/PHP-8.2+-purple.svg)
![License](https://img.shields.io/badge/license-Proprietary-green.svg)

---

## 📋 Descripción

DATAPOLIS PRO es una plataforma PropTech/FinTech diseñada específicamente para la gestión integral de condominios en Chile, con foco en:

- **Cumplimiento Normativo**: Automatización de cumplimiento Ley 21.442 de Copropiedad Inmobiliaria
- **Gestión Tributaria**: Compliance tributario para condominios con contratos de arriendo de antenas de telecomunicaciones
- **Automatización**: Procesos automatizados de declaraciones, certificaciones y notificaciones

### 🎯 Propuesta de Valor Única

1. **Simulador de Sanciones Art. 97 N°2**: Único en el mercado chileno
2. **Certificación de Compliance Verificable**: Con código QR y hash SHA-256
3. **Análisis de Reglamentos con IA**: Evaluación automática de cumplimiento Ley 21.442
4. **Sistema de Notificaciones Inteligente**: Multicanal con preferencias granulares

---

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────────────────────────────┐
│                        DATAPOLIS PRO v3.0                        │
├─────────────────────────────────────────────────────────────────┤
│  Frontend (React/Next.js)          │  Mobile (React Native)     │
├─────────────────────────────────────────────────────────────────┤
│                         API Gateway                              │
│                    Laravel 11 + Sanctum                          │
├─────────────────┬─────────────────┬─────────────────────────────┤
│   Reglamentos   │    Sanciones    │    Compliance    │ Notific. │
│    Service      │     Service     │     Service      │  Service │
├─────────────────┴─────────────────┴─────────────────────────────┤
│                     Queue Workers (Redis)                        │
├─────────────────────────────────────────────────────────────────┤
│   PostgreSQL    │     Redis      │   S3/MinIO    │    SES      │
└─────────────────┴────────────────┴───────────────┴──────────────┘
```

---

## 📁 Estructura del Proyecto

```
datapolis-complete/
├── backend/                          # Laravel 11 Backend
│   ├── app/
│   │   ├── Http/
│   │   │   └── Controllers/Api/      # Controladores REST
│   │   ├── Models/                   # Modelos Eloquent
│   │   ├── Services/                 # Servicios de negocio
│   │   ├── Jobs/                     # Jobs asíncronos
│   │   ├── Mail/                     # Mailables
│   │   └── Policies/                 # Políticas de autorización
│   ├── database/
│   │   ├── migrations/               # Migraciones de BD
│   │   └── seeders/                  # Datos de demostración
│   ├── resources/views/emails/       # Plantillas de email
│   ├── routes/api.php                # Rutas API v1
│   ├── tests/                        # Tests unitarios e integración
│   └── docs/openapi.yaml             # Documentación API
└── frontend/                         # React/Next.js Frontend
```

---

## 🚀 Módulos Principales

### 1. Análisis de Reglamentos de Copropiedad
- Evaluación automática de cumplimiento Ley 21.442
- Score de 0-100 con niveles (CRITICO → EXCELENTE)
- Detección de 25+ elementos obligatorios
- Plan de acción de 6 semanas para regularización
- Comparación histórica de análisis

### 2. Simulador de Sanciones Tributarias
- Cálculo preciso Art. 97 N°2 Código Tributario
- 5 escenarios: optimista, moderado, pesimista, condonación, sin acción
- Proyección de deuda hasta 36 meses
- Simulación de convenios de pago (3-24 cuotas)
- Integración con valores UTM/UF actualizados

### 3. Certificación de Compliance
- 7 tipos de certificados verificables
- Estados: APROBADO, CONDICIONAL, RECHAZADO
- Verificación pública con código QR
- Hash SHA-256 anti-falsificación
- Alertas de vencimiento automáticas

### 4. Sistema de Notificaciones
- 15 tipos de notificación en 6 categorías
- Canales: Email, Web Push, SMS
- Preferencias granulares por usuario
- Horario de silencio configurable
- Programación de envíos futuros
- Colas priorizadas (crítico → normal)

---

## ⚙️ Instalación

### Requisitos
- PHP 8.2+
- Composer 2.x
- PostgreSQL 15+ / MySQL 8+
- Redis 7+
- Node.js 20+

### Backend

```bash
# Clonar repositorio
git clone https://github.com/datapolis/datapolis-pro.git
cd datapolis-pro/backend

# Instalar dependencias
composer install

# Configurar entorno
cp .env.example .env
php artisan key:generate

# Configurar base de datos en .env
# DB_CONNECTION=pgsql
# DB_HOST=127.0.0.1
# DB_PORT=5432
# DB_DATABASE=datapolis
# DB_USERNAME=postgres
# DB_PASSWORD=secret

# Ejecutar migraciones y seeders
php artisan migrate --seed

# Iniciar servidor
php artisan serve

# Iniciar queue workers
php artisan queue:work redis --queue=notifications-critical,notifications-high,notifications
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

---

## 🔌 API Reference

Base URL: `https://api.datapolis.cl/api/v1`

### Autenticación
```bash
# Obtener token
POST /auth/login
{
  "email": "admin@datapolis.cl",
  "password": "Demo2024!"
}

# Usar token
Authorization: Bearer {token}
```

### Endpoints Principales

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/reglamentos/analizar` | Analizar reglamento |
| GET | `/reglamentos/historial/{edificioId}` | Historial de análisis |
| POST | `/sanciones/simular` | Simular sanción |
| POST | `/sanciones/comparar-escenarios` | Comparar 4 escenarios |
| POST | `/compliance/certificar` | Emitir certificado |
| GET | `/public/compliance/verificar/{codigo}` | Verificar certificado |
| POST | `/notificaciones/enviar` | Enviar notificación |
| POST | `/notificaciones/programar` | Programar notificación |

📖 Documentación completa: `docs/openapi.yaml`

---

## 🧪 Testing

```bash
# Todos los tests
php artisan test

# Tests unitarios
php artisan test --testsuite=Unit

# Tests de integración
php artisan test --testsuite=Feature

# Con cobertura
php artisan test --coverage
```

---

## 📊 Modelos de Datos

### Principales Entidades

```
┌─────────────────┐     ┌──────────────────────┐
│    Edificio     │────<│  AnalisisReglamento  │
└─────────────────┘     └──────────────────────┘
        │
        │              ┌──────────────────────┐
        ├─────────────<│  SimulacionSancion   │
        │              └──────────────────────┘
        │
        │              ┌──────────────────────┐
        ├─────────────<│ CertificadoCompliance│
        │              └──────────────────────┘
        │
        │              ┌──────────────────────┐
        └─────────────<│HistorialNotificacion │
                       └──────────────────────┘
```

---

## 🔐 Seguridad

- **Autenticación**: Laravel Sanctum (tokens API)
- **Autorización**: Policies granulares por rol
- **Roles**: super_admin, admin, administrador_edificio, contador, copropietario
- **Encriptación**: Hash SHA-256 para certificados
- **Rate Limiting**: 60-300 req/min según rol

---

## 📈 Métricas del Proyecto

| Métrica | Valor |
|---------|-------|
| Líneas de código | 25,000+ |
| Tablas de BD | 95+ |
| Endpoints API | 160+ |
| Tipos de notificación | 15 |
| Tests unitarios | 100+ |

---

## 🗓️ Roadmap

### Fase 1 (Completada) ✅
- [x] Servicios core (Reglamentos, Sanciones, Compliance, Notificaciones)
- [x] Controladores API REST
- [x] Migraciones y Modelos
- [x] Sistema de Jobs y Colas
- [x] Policies de autorización
- [x] Plantillas de email
- [x] Tests unitarios

### Fase 2 (En progreso) 🔄
- [ ] Portal de Copropietarios
- [ ] Dashboard administrativo
- [ ] Integración pagos (WebPay/Khipu)
- [ ] Reportería avanzada

### Fase 3 (Planificada) 📋
- [ ] Integración SII (API DTE)
- [ ] Firma electrónica avanzada
- [ ] App móvil nativa
- [ ] Machine Learning predictivo

---

## 📞 Soporte

- **Email**: soporte@datapolis.cl
- **Documentación**: https://docs.datapolis.cl
- **API Status**: https://status.datapolis.cl

---

## 📄 Licencia

Copyright © 2024-2025 DATAPOLIS. Todos los derechos reservados.

Este software es propietario y confidencial. Su uso está sujeto a los términos del contrato de licencia.

---

## 👥 Equipo

Desarrollado por **DATAPOLIS** - PropTech Innovation for Chile 🇨🇱

---

*Última actualización: Diciembre 2024*
