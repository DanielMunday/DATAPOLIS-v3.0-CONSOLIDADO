# 📘 GUÍA COMPLETA DE INSTALACIÓN - DATAPOLIS PRO v3.0

## 📋 ÍNDICE

1. [Requisitos del Sistema](#requisitos-del-sistema)
2. [Instalación Local (Desarrollo)](#instalación-local)
3. [Instalación en Servidor Virtual (Producción)](#instalación-servidor-virtual)
4. [Comparativa de Proveedores Cloud](#comparativa-proveedores)
5. [Configuración Post-Instalación](#configuración-post-instalación)
6. [Troubleshooting](#troubleshooting)

---

## 1. REQUISITOS DEL SISTEMA

### Hardware Mínimo

| Componente | Desarrollo | Producción |
|------------|:----------:|:----------:|
| CPU | 2 cores | 4 cores |
| RAM | 4 GB | 8 GB |
| Almacenamiento | 20 GB SSD | 50 GB SSD |
| Ancho de banda | 10 Mbps | 100 Mbps |

### Software Requerido

| Software | Versión Mínima | Recomendada |
|----------|:--------------:|:-----------:|
| PHP | 8.2 | 8.3 |
| Composer | 2.5 | 2.7+ |
| MySQL | 8.0 | 8.0.35 |
| PostgreSQL | 14 | 16 |
| Node.js | 18 | 20 LTS |
| Redis | 6.0 | 7.2 |
| Nginx | 1.20 | 1.25 |

### Extensiones PHP Requeridas

```bash
# Extensiones obligatorias
php-bcmath
php-ctype
php-curl
php-dom
php-fileinfo
php-json
php-mbstring
php-openssl
php-pdo
php-pdo_mysql    # o php-pdo_pgsql
php-tokenizer
php-xml
php-zip
php-gd
php-intl
php-redis        # opcional, para colas
```

---

## 2. INSTALACIÓN LOCAL (DESARROLLO)

### Opción A: Laravel Herd (⭐ RECOMENDADO para macOS/Windows)

**Ventajas:** Instalación en 1 click, incluye PHP, MySQL, Redis

```bash
# 1. Descargar Laravel Herd
# macOS: https://herd.laravel.com
# Windows: https://herd.laravel.com/windows

# 2. Instalar Herd (siguiente, siguiente, finalizar)

# 3. Extraer proyecto
cd ~/Herd
tar -xzf datapolis-pro-v3-consolidado-final.tar.gz
cd datapolis-pro-final

# 4. Instalar dependencias
composer install

# 5. Configurar
cp .env.example .env
php artisan key:generate

# 6. Crear base de datos (usando DBngin incluido o TablePlus)
# Nombre: datapolis

# 7. Configurar .env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=datapolis
DB_USERNAME=root
DB_PASSWORD=

# 8. Migrar
php artisan migrate
php artisan db:seed

# 9. Acceder
# http://datapolis-pro-final.test
```

**Tiempo estimado:** 5-10 minutos

---

### Opción B: Laragon (⭐ RECOMENDADO para Windows)

**Ventajas:** Todo incluido, portable, muy rápido

```bash
# 1. Descargar Laragon Full
# https://laragon.org/download/

# 2. Instalar en C:\laragon

# 3. Iniciar Laragon (Start All)

# 4. Extraer proyecto en C:\laragon\www\datapolis-pro-final

# 5. Click derecho en Laragon > Quick create > Laravel
# O abrir Terminal:
cd C:\laragon\www\datapolis-pro-final
composer install
cp .env.example .env
php artisan key:generate

# 6. Click derecho en Laragon > MySQL > Create database > datapolis

# 7. Editar .env con los datos de MySQL

# 8. Terminal:
php artisan migrate
php artisan db:seed

# 9. Acceder
# http://datapolis-pro-final.test
```

**Tiempo estimado:** 10 minutos

---

### Opción C: Docker (Multiplataforma)

**Ventajas:** Idéntico en todos los sistemas, reproducible

```bash
# 1. Instalar Docker Desktop
# https://www.docker.com/products/docker-desktop/

# 2. Crear docker-compose.yml en el proyecto:
```

```yaml
version: '3.8'

services:
  app:
    image: serversideup/php:8.3-fpm-nginx
    ports:
      - "8000:80"
    volumes:
      - .:/var/www/html
    environment:
      PHP_MEMORY_LIMIT: 512M
    depends_on:
      - mysql
      - redis

  mysql:
    image: mysql:8.0
    ports:
      - "3306:3306"
    environment:
      MYSQL_ROOT_PASSWORD: secret
      MYSQL_DATABASE: datapolis
    volumes:
      - mysql_data:/var/lib/mysql

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  mailpit:
    image: axllent/mailpit
    ports:
      - "8025:8025"
      - "1025:1025"

volumes:
  mysql_data:
```

```bash
# 3. Iniciar
docker-compose up -d

# 4. Instalar dependencias
docker-compose exec app composer install
docker-compose exec app php artisan key:generate
docker-compose exec app php artisan migrate
docker-compose exec app php artisan db:seed

# 5. Acceder
# http://localhost:8000
# Mailpit: http://localhost:8025
```

**Tiempo estimado:** 15-20 minutos

---

### Opción D: XAMPP/WAMP (Clásico)

```bash
# 1. Descargar XAMPP con PHP 8.2+
# https://www.apachefriends.org/

# 2. Instalar y activar Apache + MySQL

# 3. Extraer proyecto en:
# Windows: C:\xampp\htdocs\datapolis
# macOS: /Applications/XAMPP/htdocs/datapolis

# 4. Abrir terminal en el proyecto
composer install
cp .env.example .env
php artisan key:generate

# 5. phpMyAdmin: crear BD "datapolis"

# 6. Configurar .env

# 7. Migrar
php artisan migrate
php artisan db:seed

# 8. Acceder
# http://localhost/datapolis/public
```

---

## 3. INSTALACIÓN EN SERVIDOR VIRTUAL (PRODUCCIÓN)

### Opción A: Railway (⭐⭐⭐ MÁS FÁCIL)

**Ventajas:** Deploy automático, $5/mes inicial, sin configuración de servidor

```bash
# 1. Crear cuenta en https://railway.app

# 2. Nuevo proyecto > Deploy from GitHub

# 3. Conectar repositorio

# 4. Railway detecta Laravel automáticamente

# 5. Agregar servicio MySQL:
# + New > Database > MySQL

# 6. Variables de entorno se configuran automáticamente

# 7. Agregar variable:
APP_KEY=base64:XXXXXX  # (php artisan key:generate --show)

# 8. Deploy automático cada push

# Costo: ~$5-20/mes según uso
```

**Tiempo estimado:** 10 minutos

---

### Opción B: DigitalOcean App Platform (⭐⭐⭐ RECOMENDADO)

**Ventajas:** Escalable, confiable, buen soporte

```bash
# 1. Crear cuenta en https://www.digitalocean.com
# (Usa código referido para $200 crédito gratis)

# 2. Create > Apps > GitHub

# 3. Seleccionar repositorio

# 4. Configurar:
# - Build Command: composer install --no-dev --optimize-autoloader
# - Run Command: php artisan migrate --force && php-fpm

# 5. Agregar Database > MySQL

# 6. Variables de entorno:
APP_ENV=production
APP_DEBUG=false
APP_KEY=base64:XXXXX
DB_CONNECTION=mysql
DB_HOST=${db.HOSTNAME}
DB_DATABASE=${db.DATABASE}
DB_USERNAME=${db.USERNAME}
DB_PASSWORD=${db.PASSWORD}

# Costo: $12-25/mes
```

---

### Opción C: Render (⭐⭐ ECONÓMICO)

**Ventajas:** Tier gratuito disponible, simple

```bash
# 1. Crear cuenta en https://render.com

# 2. New > Web Service > Connect GitHub

# 3. Configurar:
# - Environment: PHP
# - Build Command: composer install --no-dev
# - Start Command: php artisan serve --host=0.0.0.0 --port=$PORT

# 4. New > PostgreSQL (gratis 90 días)

# 5. Environment Variables desde el panel

# Costo: $0-7/mes
```

---

### Opción D: VPS Manual (DigitalOcean/Vultr/Linode)

**Ventajas:** Control total, mejor precio a escala

```bash
# 1. Crear Droplet Ubuntu 22.04 ($6/mes mínimo)

# 2. Conectar por SSH
ssh root@TU_IP

# 3. Actualizar sistema
apt update && apt upgrade -y

# 4. Instalar dependencias
apt install -y nginx mysql-server redis-server supervisor

# 5. Instalar PHP 8.3
add-apt-repository ppa:ondrej/php -y
apt update
apt install -y php8.3-fpm php8.3-mysql php8.3-mbstring php8.3-xml \
    php8.3-bcmath php8.3-curl php8.3-zip php8.3-gd php8.3-redis

# 6. Instalar Composer
curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/local/bin/composer

# 7. Configurar MySQL
mysql_secure_installation
mysql -u root -p
CREATE DATABASE datapolis;
CREATE USER 'datapolis'@'localhost' IDENTIFIED BY 'TU_PASSWORD_SEGURO';
GRANT ALL ON datapolis.* TO 'datapolis'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# 8. Clonar proyecto
cd /var/www
git clone TU_REPOSITORIO datapolis
cd datapolis
composer install --no-dev --optimize-autoloader

# 9. Configurar permisos
chown -R www-data:www-data /var/www/datapolis
chmod -R 755 /var/www/datapolis
chmod -R 775 /var/www/datapolis/storage
chmod -R 775 /var/www/datapolis/bootstrap/cache

# 10. Configurar .env
cp .env.example .env
php artisan key:generate
nano .env  # Configurar BD y demás

# 11. Migrar
php artisan migrate --force
php artisan db:seed --force

# 12. Configurar Nginx
nano /etc/nginx/sites-available/datapolis
```

```nginx
server {
    listen 80;
    server_name tu-dominio.com;
    root /var/www/datapolis/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;
    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.3-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

```bash
# 13. Activar sitio
ln -s /etc/nginx/sites-available/datapolis /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx

# 14. SSL con Certbot
apt install certbot python3-certbot-nginx -y
certbot --nginx -d tu-dominio.com

# 15. Configurar cron
crontab -e
# Agregar:
* * * * * cd /var/www/datapolis && php artisan schedule:run >> /dev/null 2>&1

# 16. Configurar Supervisor para colas
nano /etc/supervisor/conf.d/datapolis-worker.conf
```

```ini
[program:datapolis-worker]
process_name=%(program_name)s_%(process_num)02d
command=php /var/www/datapolis/artisan queue:work --sleep=3 --tries=3
autostart=true
autorestart=true
user=www-data
numprocs=2
redirect_stderr=true
stdout_logfile=/var/www/datapolis/storage/logs/worker.log
```

```bash
supervisorctl reread
supervisorctl update
supervisorctl start datapolis-worker:*
```

---

## 4. COMPARATIVA DE PROVEEDORES CLOUD

### Para DATAPOLIS PRO (Laravel + MySQL)

| Proveedor | Facilidad | Costo/mes | Escalabilidad | Recomendación |
|-----------|:---------:|:---------:|:-------------:|:-------------:|
| **Railway** | ⭐⭐⭐⭐⭐ | $5-20 | Media | 🥇 Startups |
| **DigitalOcean App** | ⭐⭐⭐⭐ | $12-25 | Alta | 🥇 Producción |
| **Render** | ⭐⭐⭐⭐ | $0-15 | Media | 🥈 Económico |
| **Vercel** | ⭐⭐⭐ | $0-20 | Alta | ❌ No ideal para Laravel |
| **Heroku** | ⭐⭐⭐ | $7-25 | Media | ⚠️ Caro para lo que ofrece |
| **AWS Lightsail** | ⭐⭐⭐ | $5-20 | Alta | 🥈 Técnicos |
| **VPS (DO/Vultr)** | ⭐⭐ | $6-24 | Alta | 🥇 Control total |

### Sobre GROQ

**Aclaración importante:** Groq es una empresa de chips de IA para inferencia de modelos LLM, **NO es un servicio de hosting web**. Quizás te referías a:

- **Vercel** - Para frontends (no ideal para Laravel backend)
- **Render** - Buena opción económica
- **Railway** - Excelente para Laravel

Si necesitas **inferencia de IA** en DATAPOLIS (como el asistente legal), Groq sería una opción para conectar, pero no para hospedar la aplicación.

---

## 5. RECOMENDACIÓN FINAL

### Para tu caso (DATAPOLIS PRO):

| Escenario | Recomendación | Por qué |
|-----------|---------------|---------|
| **Desarrollo local** | Laravel Herd o Laragon | Setup en 5 minutos |
| **MVP/Demo** | Railway | Deploy en 10 minutos, económico |
| **Producción Chile** | DigitalOcean Santiago | Latencia baja, confiable |
| **Escalabilidad** | VPS + Load Balancer | Control total |

### Stack Recomendado Producción:

```
┌─────────────────────────────────────────┐
│           Cloudflare (CDN + SSL)        │
├─────────────────────────────────────────┤
│         DigitalOcean App Platform       │
│    ┌─────────────────────────────────┐  │
│    │   Laravel App (PHP 8.3-FPM)    │  │
│    │   + Nginx + Redis              │  │
│    └─────────────────────────────────┘  │
│    ┌─────────────────────────────────┐  │
│    │   MySQL 8.0 (Managed DB)       │  │
│    └─────────────────────────────────┘  │
│    ┌─────────────────────────────────┐  │
│    │   Spaces (S3 - Documentos)     │  │
│    └─────────────────────────────────┘  │
└─────────────────────────────────────────┘
```

**Costo mensual estimado:** $25-50 USD

---

## 6. CONFIGURACIÓN POST-INSTALACIÓN

### Checklist de Seguridad

```bash
# 1. Cambiar credenciales por defecto
php artisan tinker
>>> User::where('email', 'admin@datapolis.cl')->update(['password' => bcrypt('NUEVA_CLAVE_SEGURA')]);

# 2. Configurar HTTPS obligatorio (.env)
APP_URL=https://tu-dominio.com
FORCE_HTTPS=true

# 3. Deshabilitar debug en producción
APP_DEBUG=false

# 4. Cachear configuración
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 5. Optimizar autoloader
composer install --optimize-autoloader --no-dev
```

### Valores Tributarios Chile 2025

```env
# .env - Actualizar anualmente
UF_VALOR=38500
UTM_VALOR=67000
UTA_VALOR=804000
SUELDO_MINIMO=500000
```

---

## SOPORTE

**DATAPOLIS SpA**
- 📧 soporte@datapolis.cl
- 📱 +56 9 XXXX XXXX
- 🌐 www.datapolis.cl

---

*Guía actualizada: Enero 2025*
