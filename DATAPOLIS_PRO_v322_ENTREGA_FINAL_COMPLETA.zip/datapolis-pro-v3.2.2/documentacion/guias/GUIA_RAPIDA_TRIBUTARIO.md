# 📊 Guía Rápida - Sistema Tributario DATAPOLIS PRO v3.2

## 🚀 Inicio Rápido

### Acceso al Dashboard Tributario

1. Ingresar a DATAPOLIS PRO
2. Menú lateral → **"Tributario"**
3. Seleccionar edificio (si hay múltiples)

---

## 📝 Operaciones Frecuentes

### ✅ Registrar Factura de Compra

```
Dashboard → [Agregar Compra] →
  ├── Tipo: Factura (FAC)
  ├── Folio: número de factura
  ├── Fecha: fecha del documento
  ├── RUT Emisor: 76.XXX.XXX-X
  ├── Razón Social: nombre proveedor
  ├── Tipo Gasto: seleccionar categoría
  ├── Monto Neto: $XXX.XXX
  └── [Guardar]
```

> 💡 **Tip:** El IVA (19%) se calcula automáticamente

### ✅ Registrar Factura de Venta (Arriendo)

```
Dashboard → [Agregar Venta] →
  ├── Vincular Contrato: (opcional)
  ├── Tipo: Factura (FAC)
  ├── Folio: número de factura
  ├── Fecha: fecha del documento
  ├── RUT Receptor: 76.XXX.XXX-X
  ├── Razón Social: nombre arrendatario
  ├── Tipo Ingreso: Arriendo Antenas ✓ NO RENTA
  ├── Monto Neto: $XXX.XXX
  └── [Guardar]
```

> ⚠️ **Importante:** Los arriendos de antenas, estacionamientos, locales, etc. son **NO RENTA** según Art. 17 N°3 LIR Ley 21.713 si se destinan íntegramente a gastos comunes.

### ✅ Registrar Boleta de Honorarios (Retención)

```
Dashboard → Tab [Retenciones] → [Nueva Retención] →
  ├── N° Boleta: XXX-XXXX
  ├── Fecha: fecha de boleta
  ├── RUT Prestador: XX.XXX.XXX-X
  ├── Nombre Prestador: nombre profesional
  ├── Tipo Servicio: seleccionar
  ├── Monto Bruto: $XXX.XXX
  └── [Guardar]
```

> 💡 **Tip:** La retención (13.75%) se calcula automáticamente

### ✅ Generar Formulario 29

```
Dashboard → [Generar F29] →
  │
  ├── PASO 1: Seleccionar Período
  │   ├── Mes: Enero, Febrero...
  │   └── Año: 2026
  │
  ├── PASO 2: Revisar Datos
  │   ├── Débito Fiscal: $XXX.XXX
  │   ├── Crédito Fiscal: $XXX.XXX
  │   ├── IVA Determinado: $XXX.XXX
  │   ├── PPM: $XX.XXX
  │   └── Retenciones: $XX.XXX
  │
  ├── PASO 3: Validar
  │   └── ✓ Sin errores
  │
  └── PASO 4: Generar
      ├── [Descargar PDF]
      └── [Previsualizar]
```

---

## 📊 Códigos F29 Principales

| Código | Descripción | Dónde lo veo |
|--------|-------------|--------------|
| [537] | Débito Fiscal del Mes | Panel Ventas |
| [77] | Crédito Fiscal del Mes | Panel Compras |
| [89] | IVA Determinado | Resumen F29 |
| [116] | PPM Arriendos | Resumen F29 |
| [548] | Retención Honorarios | Tab Retenciones |
| [93] | Total a Pagar | Resumen F29 |

---

## 🚦 Significado de Colores

### Alertas

| Color | Días | Acción |
|-------|------|--------|
| 🔴 Rojo | ≤3 días | ¡URGENTE! Declarar hoy |
| 🟡 Amarillo | ≤7 días | Preparar declaración |
| 🟢 Verde | >7 días | Sin urgencia |

### Clasificación de Ingresos

| Color | Clasificación | Tributación |
|-------|---------------|-------------|
| 🟢 Verde | NO RENTA | No paga impuestos |
| 🟡 Amarillo | RENTA | Sí paga impuestos |

---

## 📅 Fechas Importantes

### Formulario 29 - Vencimiento

> El F29 vence el **día 12** del mes siguiente al período tributario.

| Período | Vencimiento |
|---------|-------------|
| Enero 2026 | 12 Febrero 2026 |
| Febrero 2026 | 12 Marzo 2026 |
| Marzo 2026 | 12 Abril 2026 |
| ... | ... |

### Declaración Anual F22

> Vence en **Abril** de cada año para el ejercicio anterior.

---

## ❓ Preguntas Frecuentes

### ¿Cuándo un arriendo es NO RENTA?

✅ **Es NO RENTA cuando:**
- El ingreso se destina íntegramente a gastos comunes
- El arriendo es de espacios comunes (antenas, estacionamientos, locales, bodegas, publicidad)
- Cumple con Art. 17 N°3 LIR Ley 21.713

⚠️ **Es RENTA cuando:**
- Son multas e intereses por morosidad
- Los ingresos no se destinan a gastos comunes
- Son remanentes no reinvertidos

### ¿Cómo sé si debo pagar PPM?

El PPM (Pago Provisional Mensual) del 10% aplica a:
- Arriendos de contribuyentes con inicio de actividades
- Régimen renta efectiva (14 A/B o 14 ter)
- Sin exención especial

### ¿Qué hago si me equivoqué en una declaración?

1. Ir a **Dashboard → Declaraciones Pendientes**
2. Seleccionar el F29 a corregir
3. Click en **"Generar Rectificatoria"**
4. El sistema genera un nuevo F29 corregido

---

## 🆘 Soporte

| Canal | Contacto |
|-------|----------|
| Email | soporte@datapolis.cl |
| Teléfono | +56 2 2XXX XXXX |
| Horario | Lunes a Viernes 9:00 - 18:00 |

---

*DATAPOLIS PRO v3.2 - Sistema Tributario para Copropiedades Chilenas*
*© 2026 DATAPOLIS SpA*
