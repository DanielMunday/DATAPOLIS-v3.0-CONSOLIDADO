# DATAPOLIS PRO v3.2 - Módulo Integrado de Alícuotas y Tipo de Copropiedad

## Actualizado: 7 Enero 2026

---

## 📋 RESUMEN EJECUTIVO

Este módulo implementa la integración completa de:

1. **Alícuotas según Ley 21.442 Art. 2 y 3**
   - Porcentaje de derechos sobre bienes de dominio común
   - Validación suma = 100%
   - Historial de cambios
   - Alícuotas diferenciadas por tipo de gasto

2. **Tipo de Copropiedad según Res. Ex. SII N°209 del 31.12.2025**
   - Copropiedad Vertical
   - Copropiedad en Extensión
   - Copropiedad Mixta
   - Calidad de construcciones (Anexo N°6)

3. **Integración con Gastos Comunes**
   - Prorrateo usando alícuotas registradas
   - Configuración tributaria por tipo
   - Validación de requisitos normativos

---

## 📚 BASE LEGAL IMPLEMENTADA

### Ley 21.442 de Copropiedad Inmobiliaria

| Artículo | Contenido | Implementación |
|----------|-----------|----------------|
| **Art. 2 N°1** | Definición de Unidad | ✅ Tabla `unidades` con subtipos |
| **Art. 2 N°3** | Bienes de dominio común | ✅ Concepto en gastos comunes |
| **Art. 3 inc.1** | Porcentaje según reglamento | ✅ Tabla `alicuotas_unidades` |
| **Art. 3 inc.2** | Porcentajes diferenciados | ✅ Campos alícuota por tipo gasto |
| **Art. 3 supletorio** | Proporción a avalúo fiscal | ✅ Método de cálculo alternativo |
| **Art. 6** | Gastos Comunes | ✅ Servicio completo |
| **Art. 7** | Fondo de Reserva (5%) | ✅ Cálculo automático |
| **Art. 8** | Cuotas Extraordinarias | ✅ Tipo de gasto incluido |

### Res. Ex. SII N°209 del 31.12.2025

| Concepto | Definición Oficial | Implementación |
|----------|-------------------|----------------|
| **UNIDAD** | "Inmuebles acogidos a la Ley N°21.442, que forman parte de un condominio y sobre los cuales es posible constituir dominio exclusivo" | ✅ Campo `tipo` y `subtipo_destino` |
| **Copropiedad en Extensión** | "Copropiedades compuestas por viviendas unifamiliares u otros destinos, no asociados a edificaciones en altura" | ✅ `tipo_copropiedad = 'extension'` |
| **Copropiedad Vertical** | "Copropiedades compuestas por edificios de departamentos u otros destinos" | ✅ `tipo_copropiedad = 'vertical'` |
| **Anexo N°6** | Guías para definir la calidad de las construcciones | ✅ Campo `calidad_construccion` |

---

## 🗄️ ESTRUCTURA DE BASE DE DATOS

### Tablas Nuevas

```
┌─────────────────────────────────────────────────────────────┐
│  TABLAS DE ALÍCUOTAS (Ley 21.442 Art. 3)                    │
├─────────────────────────────────────────────────────────────┤
│  alicuotas_unidades          - Porcentajes por unidad       │
│  alicuotas_historial         - Historial de cambios         │
│  alicuotas_validacion        - Validación suma = 100%       │
│  configuracion_prorrateo     - Métodos de cálculo           │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  TABLAS DE TIPO COPROPIEDAD (Res. Ex. SII N°209)            │
├─────────────────────────────────────────────────────────────┤
│  configuracion_tributaria_copropiedad - Config. por tipo    │
│  clasificacion_copropiedad_historial  - Historial cambios   │
└─────────────────────────────────────────────────────────────┘
```

### Campos Agregados a Tablas Existentes

**Tabla `edificios`:**
```sql
tipo_copropiedad        ENUM('vertical', 'extension', 'mixta')
cantidad_pisos          INTEGER
es_edificacion_altura   BOOLEAN
clasificacion_sii       VARCHAR(50)
resolucion_sii_aplicable VARCHAR(100)
```

**Tabla `unidades`:**
```sql
alicuota                DECIMAL(10,6)
alicuota_validada       BOOLEAN
fecha_inscripcion       DATE
subtipo_destino         ENUM('vivienda_unifamiliar', 'departamento', ...)
en_edificacion_altura   BOOLEAN
calidad_construccion    ENUM('clase_a', 'clase_b', 'clase_c', 'clase_d')
anio_construccion       INTEGER
materialidad            ENUM('hormigon_armado', 'albanileria_reforzada', ...)
```

---

## 🔧 SERVICIOS IMPLEMENTADOS

### AlicuotasLey21442Service

| Método | Descripción |
|--------|-------------|
| `registrarAlicuota()` | Registrar alícuota con datos de escritura |
| `getAlicuotaUnidad()` | Obtener alícuota vigente de una unidad |
| `getAlicuotasEdificio()` | Listar todas las alícuotas de un edificio |
| `validarSumaAlicuotas()` | Verificar que suma = 100% |
| `calcularCuotaUnidad()` | Calcular cuota de gastos para una unidad |
| `calcularProrrateoEdificio()` | Prorratear gastos a todas las unidades |
| `migrarAlicuotasLegacy()` | Migrar desde campo `prorrateo` antiguo |

### GastosComunesIntegradoService

| Método | Descripción |
|--------|-------------|
| `clasificarCopropiedad()` | Clasificar edificio según Res. SII N°209 |
| `clasificarUnidad()` | Clasificar subtipo de destino de unidad |
| `getClasificacionEdificio()` | Obtener clasificación completa |
| `calcularGastosComunesIntegrado()` | Calcular usando alícuotas y tipo |
| `getResumenPorTipoUnidad()` | Resumen de gastos por subtipo |

---

## 🔌 API REST ENDPOINTS

### Alícuotas (`/api/alicuotas`)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/edificio/{id}` | Listar alícuotas del edificio |
| GET | `/unidad/{id}` | Obtener alícuota de unidad |
| GET | `/validar/{id}` | Validar suma = 100% |
| POST | `/` | Registrar nueva alícuota |
| PUT | `/{id}` | Actualizar alícuota |
| POST | `/calcular-cuota` | Calcular cuota de unidad |
| POST | `/calcular-prorrateo` | Prorratear todo el edificio |
| POST | `/migrar/{id}` | Migrar desde legacy |
| GET | `/metodos-calculo` | Catálogo de métodos |
| GET | `/origenes-porcentaje` | Catálogo de orígenes |
| GET | `/base-legal` | Información legal |

### Gastos Comunes Integrado (`/api/gastos-comunes`)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/clasificar-copropiedad` | Clasificar tipo edificio |
| POST | `/clasificar-unidad` | Clasificar subtipo unidad |
| GET | `/clasificacion/{id}` | Obtener clasificación |
| POST | `/calcular-integrado` | Calcular gastos comunes |
| GET | `/resumen-tipo-unidad/{id}/{mes}/{anio}` | Resumen por tipo |
| GET | `/validar-requisitos/{id}` | Validar prerrequisitos |
| GET | `/tipos-copropiedad` | Catálogo tipos |
| GET | `/subtipos-destino` | Catálogo subtipos |
| GET | `/calidades-construccion` | Catálogo calidades |
| GET | `/tipos-gastos` | Catálogo gastos |
| GET | `/base-legal` | Información legal completa |

---

## 🖥️ PÁGINAS FRONTEND

### AlicuotasLey21442Page.tsx

- Dashboard de validación (suma = 100%)
- Registro de alícuotas con datos de escritura
- Gráfico de distribución de porcentajes
- Calculadora de prorrateo
- Migración desde sistema legacy
- Panel de base legal

### GastosComunesIntegradoPage.tsx

- Stepper de configuración (3 pasos)
- Clasificación de copropiedad con selector visual
- Tabla de unidades con subtipos
- Validación de requisitos normativos
- Cálculo integrado de gastos
- Panel de base legal

---

## 💾 COMANDOS DE EJECUCIÓN

```bash
# Ejecutar migraciones
php artisan migrate --path=database/migrations/2026_01_06_000002_create_alicuotas_ley21442_tables.php
php artisan migrate --path=database/migrations/2026_01_06_000003_add_tipo_copropiedad_res_sii_209.php

# Verificar estructura
php artisan schema:dump

# Migrar alícuotas existentes
php artisan tinker
>>> app(\App\Services\AlicuotasLey21442Service::class)->migrarAlicuotasLegacy(1);

# Clasificar un edificio
>>> app(\App\Services\GastosComunesIntegradoService::class)->clasificarCopropiedad(1, [
    'cantidad_pisos' => 15,
    'tiene_edificios' => true
]);
```

---

## 📊 MÉTRICAS DEL MÓDULO

| Componente | Líneas | Archivos |
|------------|--------|----------|
| Migraciones | 487 | 2 |
| Servicios | 1,535 | 2 |
| Controladores | 619 | 2 |
| Rutas API | 210 | 2 |
| Frontend | 1,814 | 2 |
| **TOTAL** | **4,665** | **10** |

---

## ✅ CUMPLIMIENTO NORMATIVO

| Requisito | Estado | Ubicación |
|-----------|--------|-----------|
| Alícuotas según escritura | ✅ | `alicuotas_unidades` |
| Suma alícuotas = 100% | ✅ | `validarSumaAlicuotas()` |
| Alícuotas diferenciadas | ✅ | Campos por tipo de gasto |
| Historial de cambios | ✅ | `alicuotas_historial` |
| Copropiedad Vertical | ✅ | `tipo_copropiedad` |
| Copropiedad Extensión | ✅ | `tipo_copropiedad` |
| Calidad construcción | ✅ | `calidad_construccion` |
| Fondo Reserva 5% | ✅ | Cálculo automático |
| Integración tributaria | ✅ | `configuracion_tributaria_copropiedad` |

---

## 🔗 RELACIONES CON OTROS MÓDULOS

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   ALÍCUOTAS     │────▶│ GASTOS COMUNES  │────▶│  TRIBUTARIO     │
│  (Ley 21.442)   │     │   (Integrado)   │     │  (Ley 21.713)   │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                       │                       │
        ▼                       ▼                       ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│     UNIDADES    │     │   EDIFICIOS     │     │     F29/PPM     │
│  (Subtipos)     │     │ (Tipo Coprop.)  │     │  (Retenciones)  │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

---

## 📞 REFERENCIAS

- Ley 21.442: https://www.bcn.cl/leychile/navegar?idNorma=1177308
- Res. Ex. SII N°209: (31.12.2025)
- DS 7-2025: Reglamento de Copropiedad Inmobiliaria

---

*Última actualización: 7 Enero 2026*
*Autor: DATAPOLIS SpA*
