# DATAPOLIS PRO v3.2 - Módulo Tributario Integrado

## 📊 Sistema de Gestión Tributaria para Copropiedades Chilenas

**Versión:** 3.2.0  
**Fecha:** Enero 2026  
**Estado:** Producción  
**Desarrollado por:** DATAPOLIS SpA

---

## 📋 Índice

1. [Resumen Ejecutivo](#resumen-ejecutivo)
2. [Arquitectura del Sistema](#arquitectura-del-sistema)
3. [Base Legal](#base-legal)
4. [Funcionalidades](#funcionalidades)
5. [Instalación y Configuración](#instalación-y-configuración)
6. [API REST](#api-rest)
7. [Componentes Frontend](#componentes-frontend)
8. [Guía de Usuario](#guía-de-usuario)
9. [Testing](#testing)
10. [Roadmap](#roadmap)

---

## Resumen Ejecutivo

El Módulo Tributario v3.2 de DATAPOLIS PRO es una solución integral para la gestión tributaria de copropiedades chilenas bajo la Ley 21.442 (Copropiedad Inmobiliaria) y Ley 21.713 (Cumplimiento Tributario).

### Características Principales

| Funcionalidad | Estado | Descripción |
|---------------|--------|-------------|
| Libro IVA Compras/Ventas | ✅ 100% | Gestión completa según DL 825 |
| Formulario 29 | ✅ 95% | Generación automática con códigos SII |
| PPM Arriendos | ✅ 100% | Art. 17 N°3 LIR Ley 21.713 |
| Retenciones Honorarios | ✅ 100% | Art. 74 N°2 LIR (13.75%) |
| IECV XML | ✅ 90% | Res. Ex. SII N° 45/2003 |
| Dashboard Tributario | ✅ 100% | Panel de control integrado |
| Integración SII DTE | ⚠️ 70% | Requiere certificado digital |

### Métricas del Módulo

```
Total Líneas Backend:     +5,880 líneas
Total Líneas Frontend:    +6,020 líneas
Total Módulo v3.2:        +11,900 líneas
Tablas Base de Datos:     12 tablas
Endpoints API:            45+ endpoints
Componentes React:        6 componentes principales
```

---

## Arquitectura del Sistema

### Diagrama de Componentes

```
┌─────────────────────────────────────────────────────────────────┐
│                    FRONTEND (React + TypeScript)                │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌──────────────────┐  ┌────────────────┐ │
│  │ Dashboard       │  │ Dialogs CRUD     │  │ Services API   │ │
│  │ Tributario      │  │ • Compra         │  │ • libroIVA     │ │
│  │ (1,935 líneas)  │  │ • Venta          │  │ • formularioF29│ │
│  │                 │  │ • Retención      │  │ • retenciones  │ │
│  │ • KPIs          │  │ • Contribuyente  │  │ • contribuyen  │ │
│  │ • Gráficos      │  │ • F29 Wizard     │  │                │ │
│  │ • Tablas        │  │ (~2,970 líneas)  │  │ (850 líneas)   │ │
│  │ • Alertas       │  └──────────────────┘  └────────────────┘ │
│  └─────────────────┘                                           │
└────────────────────────────────┬────────────────────────────────┘
                                 │ HTTP REST
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                   BACKEND (Laravel 11 + PHP 8.3)                │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌──────────────────┐  ┌────────────────┐ │
│  │ Controllers     │  │ Services         │  │ Models         │ │
│  │ • LibroIVA      │  │ • LibroIVA       │  │ • DocumentoIVA │ │
│  │   Controller    │  │   Service        │  │ • CompraIVA    │ │
│  │ • DeclaracionF29│  │ • DeclaracionF29 │  │ • VentaIVA     │ │
│  │   Controller    │  │   Service        │  │ • FormularioF29│ │
│  │ • RetencionesCtr│  │ • PPMService     │  │ • RetencionHon │ │
│  │                 │  │ • IECVService    │  │ • Contribuyente│ │
│  │ (~1,800 líneas) │  │ (~1,350 líneas)  │  │ (~800 líneas)  │ │
│  └─────────────────┘  └──────────────────┘  └────────────────┘ │
└────────────────────────────────┬────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                    BASE DE DATOS (PostgreSQL/MySQL)             │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ libro_iva_compras      │ libro_iva_ventas               │   │
│  │ resumen_iva_mensual    │ formularios_f29                │   │
│  │ retenciones_honorarios │ clasificacion_contribuyentes   │   │
│  │ configuracion_ppm      │ codigos_f29                    │   │
│  │ informacion_f22        │ iecv_archivos                  │   │
│  │ sincronizacion_sii     │ logs_tributarios               │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

### Flujo de Datos

```
OPERACIÓN TRIBUTARIA
        │
        ▼
┌───────────────────┐
│ 1. REGISTRO       │  Usuario registra documento (compra/venta/retención)
│    DOCUMENTO      │  Validación RUT, montos, fechas
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 2. LIBRO IVA      │  Documento se registra en Libro IVA
│    ACTUALIZACIÓN  │  Cálculo automático IVA (19%)
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 3. RESUMEN        │  Actualización resumen mensual
│    MENSUAL        │  Débito - Crédito = IVA Determinado
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 4. CÓDIGOS F29    │  Mapeo a códigos oficiales SII
│    GENERACIÓN     │  [91][538][520][537][77][89][93]
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 5. FORMULARIO 29  │  Generación borrador F29
│    BORRADOR       │  Validación coherencia datos
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ 6. DECLARACIÓN    │  Descarga PDF / Envío SII
│    FINAL          │  Generación IECV XML
└───────────────────┘
```

---

## Base Legal

### Normativa Implementada

| Norma | Artículo | Descripción | Implementación |
|-------|----------|-------------|----------------|
| DL 825 | Art. 8 | Hecho Gravado IVA | Cálculo automático débito fiscal |
| DL 825 | Art. 23 | Crédito Fiscal IVA | Gestión con factor proporcionalidad |
| DL 825 | Art. 64 | Libro Compras/Ventas | Libro IVA electrónico completo |
| LIR | Art. 84 | Pagos Provisionales Mensuales | Cálculo PPM 10% arriendos |
| LIR | Art. 74 N°2 | Retención Honorarios | Retención 13.75% boletas |
| LIR | Art. 17 N°3 | Ingresos NO Renta | Ley 21.713 arriendos GC |
| LIR | Art. 42 N°2 | Remanentes Renta | Excedentes SÍ tributan |
| Res. Ex. SII | N° 45/2003 | IECV Obligatorio | Generación XML estándar |
| Res. Ex. SII | N° 6.509 | Formato IECV | Estructura campos XML |
| Ley 21.442 | Art. 13 | Administración Copropiedad | Integración condominios |
| Ley 21.713 | Disposiciones | Cumplimiento Tributario | Plazos y obligaciones |

### Clasificación Tributaria Arriendos (Art. 17 N°3 LIR Ley 21.713)

```
┌───────────────────────────────────────────────────────────────────┐
│               CLASIFICACIÓN DE INGRESOS POR ARRIENDO              │
├───────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ✅ INGRESOS NO RENTA (Art. 17 N°3 LIR)                          │
│  Destinados íntegramente a Gastos Comunes                         │
│  ─────────────────────────────────────────                        │
│  • Arriendo de antenas telecomunicaciones                         │
│  • Publicidad en espacios comunes                                 │
│  • Estacionamientos                                               │
│  • Locales comerciales                                            │
│  • Bodegas                                                        │
│  • Eventos en áreas comunes                                       │
│  • Concesiones espacios comunes                                   │
│                                                                   │
│  ⚠️ INGRESOS RENTA GRAVABLE (Art. 42 N°2 LIR)                    │
│  Remanentes o no destinados a GC                                  │
│  ─────────────────────────────────────────                        │
│  • Multas e intereses por morosidad                               │
│  • Ingresos por servicios a terceros                              │
│  • Excedentes no reinvertidos en GC                               │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

### Códigos Formulario 29 Implementados

| Código | Descripción | Línea F29 |
|--------|-------------|-----------|
| [91] | Cantidad Facturas Emitidas | Débito Fiscal |
| [538] | Monto Neto Ventas | Débito Fiscal |
| [502] | Cantidad Notas Crédito Emitidas | Débito Fiscal |
| [92] | Monto Notas Crédito Emitidas | Débito Fiscal |
| [537] | Débito Fiscal del Mes | Total IVA Débito |
| [519] | Cantidad Facturas Recibidas | Crédito Fiscal |
| [520] | Monto Neto Compras | Crédito Fiscal |
| [521] | Cantidad Notas Crédito Recibidas | Crédito Fiscal |
| [528] | Monto Notas Crédito Recibidas | Crédito Fiscal |
| [77] | Crédito Fiscal del Mes | Total IVA Crédito |
| [89] | IVA Determinado | Débito - Crédito |
| [504] | Remanente Mes Anterior | Crédito acumulado |
| [77] | Remanente Período Siguiente | Crédito a favor |
| [116] | PPM Arriendos | Art. 84 LIR |
| [548] | Retención Honorarios | Art. 74 N°2 LIR |
| [93] | Total a Pagar | Suma determinada |

---

## Funcionalidades

### 1. Libro IVA Compras

**Endpoint:** `POST /api/v1/edificios/{id}/libro-iva/compras`

```typescript
interface CompraIVA {
  tipo_documento: 'FAC' | 'FEX' | 'NC' | 'ND' | 'FC' | 'LF';
  folio: number;
  fecha_documento: string;          // ISO 8601
  rut_emisor: string;               // Con dígito verificador
  razon_social_emisor: string;
  tipo_gasto: 'servicios_basicos' | 'mantenciones' | 'seguros' | 
              'servicios_profesionales' | 'suministros' | 
              'equipamiento' | 'administracion' | 'otros';
  monto_neto: number;               // Base imponible
  monto_iva: number;                // 19% automático
  monto_total: number;              // Neto + IVA
  con_derecho_cf: boolean;          // Derecho a crédito fiscal
  factor_proporcionalidad: number;  // 0-100%
  iva_no_recuperable: number;       // IVA sin derecho a CF
}
```

**Cálculos Automáticos:**
- IVA = Math.round(monto_neto × 19 / 100)
- Total = monto_neto + monto_iva
- IVA recuperable = monto_iva × (factor_proporcionalidad / 100)
- IVA no recuperable = monto_iva - IVA recuperable

### 2. Libro IVA Ventas

**Endpoint:** `POST /api/v1/edificios/{id}/libro-iva/ventas`

```typescript
interface VentaIVA {
  tipo_documento: 'FAC' | 'FEX' | 'BOL' | 'BEX' | 'NC' | 'ND';
  folio: number;
  fecha_documento: string;
  rut_receptor: string;
  razon_social_receptor: string;
  tipo_ingreso: 'arriendo_antenas' | 'publicidad' | 'estacionamientos' | 
                'locales' | 'bodegas' | 'eventos' | 'concesion' | 
                'multas_e_intereses' | 'otros';
  monto_neto: number;
  monto_iva: number;
  monto_total: number;
  es_ingreso_no_renta: boolean;     // Art. 17 N°3 LIR
  contrato_arriendo_id?: number;    // Vinculación opcional
}
```

**Clasificación Automática:**
- arriendo_antenas → NO RENTA ✅
- publicidad → NO RENTA ✅
- estacionamientos → NO RENTA ✅
- locales → NO RENTA ✅
- bodegas → NO RENTA ✅
- eventos → NO RENTA ✅
- concesion → NO RENTA ✅
- multas_e_intereses → RENTA GRAVABLE ⚠️
- otros → Evaluar caso a caso

### 3. Retenciones Honorarios

**Endpoint:** `POST /api/v1/edificios/{id}/retenciones`

```typescript
interface RetencionHonorarios {
  numero_boleta: string;
  fecha_boleta: string;
  rut_prestador: string;
  nombre_prestador: string;
  tipo_servicio: 'administracion' | 'contabilidad' | 'legal' | 
                 'auditoria' | 'arquitectura' | 'ingenieria' | 
                 'mantenciones' | 'otros';
  monto_bruto: number;              // Total boleta
  tasa_retencion: number;           // 13.75% fijo
  monto_retenido: number;           // Calculado automático
  monto_liquido: number;            // Bruto - Retenido
}
```

**Cálculo Automático:**
- Monto Retenido = Math.round(monto_bruto × 13.75 / 100)
- Monto Líquido = monto_bruto - monto_retenido

### 4. Formulario 29 (Wizard)

**Proceso de 4 pasos:**

```
┌─────────────────────────────────────────────────────────────┐
│ PASO 1: SELECCIONAR PERÍODO                                 │
│ ─────────────────────────────                               │
│ • Selección mes (1-12)                                      │
│ • Selección año (2024-2026)                                 │
│ • Visualización fecha vencimiento (día 12 mes siguiente)   │
│ • Indicador días restantes con código de colores           │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ PASO 2: REVISAR DATOS                                       │
│ ─────────────────────                                       │
│ • Fetch resumenMensual() desde API                          │
│ • Grid Débito Fiscal (rojo) + Crédito Fiscal (verde)       │
│ • Tablas con códigos F29 oficiales                          │
│ • Paper resumen: IVA, PPM, Retenciones, Total              │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ PASO 3: VALIDAR                                             │
│ ─────────────────                                           │
│ • Validación automática coherencia datos                    │
│ • Verificación existencia movimientos período               │
│ • Alertas montos superiores $10M                            │
│ • Lista errores y advertencias                              │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ PASO 4: GENERAR F29                                         │
│ ─────────────────────                                       │
│ • POST generarBorrador() a API                              │
│ • Generación PDF descargable                                │
│ • Almacenamiento borrador en BD                             │
│ • Botones: Descargar PDF, Previsualizar                    │
└─────────────────────────────────────────────────────────────┘
```

### 5. Dashboard Tributario

**Componentes principales:**

| Sección | Descripción | Datos |
|---------|-------------|-------|
| KPIs | 4 indicadores principales | IVA, PPM, Retenciones, Alertas |
| Gráfico Tendencias | Evolución 12 meses | Débito, Crédito, Determinado |
| Alertas | Vencimientos próximos | Código colores urgencia |
| Libro Compras | Tabla paginada | Últimos documentos |
| Libro Ventas | Tabla paginada | Últimos documentos |
| Retenciones | Tabla paginada | Boletas honorarios |
| Declaraciones | F29 pendientes | Estado y acciones |

---

## Instalación y Configuración

### Requisitos Previos

```bash
# Backend
PHP >= 8.3
Laravel 11.x
PostgreSQL 15+ o MySQL 8+
Composer 2.x

# Frontend
Node.js >= 20.x
npm >= 10.x
React 18.x
TypeScript 5.x
```

### 1. Backend Laravel

```bash
# Clonar repositorio
cd /path/to/datapolis-consolidado-real

# Instalar dependencias
composer install

# Configurar .env
cp .env.example .env
php artisan key:generate

# Configurar base de datos en .env
DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=datapolis_pro
DB_USERNAME=postgres
DB_PASSWORD=your_password

# Ejecutar migraciones tributarias
php artisan migrate

# Ejecutar seeders tributarios
php artisan db:seed --class=ConfiguracionPPMSeeder
php artisan db:seed --class=CodigosF29Seeder

# Verificar rutas
php artisan route:list --path=libro-iva
php artisan route:list --path=f29
```

### 2. Frontend React

```bash
# Ir a directorio frontend
cd frontend

# Instalar dependencias
npm install

# Dependencias adicionales requeridas
npm install @mui/x-date-pickers date-fns

# Configurar API URL en .env
VITE_API_URL=http://localhost:8000/api

# Iniciar desarrollo
npm run dev

# Build producción
npm run build
```

### 3. Verificación de Instalación

```bash
# Backend - Test endpoints
curl -X GET http://localhost:8000/api/v1/edificios/1/libro-iva/compras \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Accept: application/json"

# Frontend - Verificar componentes
npm run lint
npm run type-check
```

---

## API REST

### Autenticación

```http
Authorization: Bearer {token}
Content-Type: application/json
Accept: application/json
```

### Endpoints Libro IVA

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/v1/edificios/{id}/libro-iva/compras` | Listar compras |
| POST | `/api/v1/edificios/{id}/libro-iva/compras` | Registrar compra |
| GET | `/api/v1/edificios/{id}/libro-iva/compras/{compraId}` | Detalle compra |
| POST | `/api/v1/edificios/{id}/libro-iva/compras/{compraId}/anular` | Anular compra |
| GET | `/api/v1/edificios/{id}/libro-iva/compras/exportar/pdf` | Exportar PDF |
| GET | `/api/v1/edificios/{id}/libro-iva/ventas` | Listar ventas |
| POST | `/api/v1/edificios/{id}/libro-iva/ventas` | Registrar venta |
| GET | `/api/v1/edificios/{id}/libro-iva/ventas/{ventaId}` | Detalle venta |
| POST | `/api/v1/edificios/{id}/libro-iva/ventas/{ventaId}/anular` | Anular venta |
| GET | `/api/v1/edificios/{id}/libro-iva/ventas/exportar/pdf` | Exportar PDF |
| GET | `/api/v1/edificios/{id}/libro-iva/resumen/mensual` | Resumen mensual |
| GET | `/api/v1/edificios/{id}/libro-iva/resumen/historial` | Historial |

### Endpoints Formulario 29

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/v1/edificios/{id}/f29/dashboard` | Dashboard tributario |
| GET | `/api/v1/edificios/{id}/f29/pendientes` | Declaraciones pendientes |
| POST | `/api/v1/edificios/{id}/f29/generar-borrador` | Generar borrador |
| GET | `/api/v1/edificios/{id}/f29/{f29Id}` | Detalle F29 |
| GET | `/api/v1/edificios/{id}/f29/{f29Id}/pdf` | Exportar PDF |
| POST | `/api/v1/edificios/{id}/f29/{f29Id}/rectificar` | Generar rectificatoria |

### Endpoints Retenciones

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/v1/edificios/{id}/retenciones` | Listar retenciones |
| POST | `/api/v1/edificios/{id}/retenciones` | Registrar retención |
| GET | `/api/v1/edificios/{id}/retenciones/{retencionId}` | Detalle |
| POST | `/api/v1/edificios/{id}/retenciones/{retencionId}/anular` | Anular |
| GET | `/api/v1/edificios/{id}/retenciones/resumen-mensual` | Resumen |

### Ejemplo de Respuesta API

```json
{
  "success": true,
  "message": "Compra registrada exitosamente",
  "data": {
    "id": 123,
    "tipo_documento": "FAC",
    "folio": 45678,
    "fecha_documento": "2026-01-03",
    "rut_emisor": "76.123.456-7",
    "razon_social_emisor": "PROVEEDOR SpA",
    "tipo_gasto": "servicios_basicos",
    "monto_neto": 100000,
    "monto_iva": 19000,
    "monto_total": 119000,
    "con_derecho_cf": true,
    "factor_proporcionalidad": 100,
    "iva_no_recuperable": 0,
    "created_at": "2026-01-03T14:30:00Z"
  }
}
```

---

## Componentes Frontend

### Estructura de Archivos

```
frontend/src/
├── components/
│   └── tributario/
│       ├── FormularioCompraDialog.tsx      # ~600 líneas
│       ├── FormularioVentaDialog.tsx       # ~550 líneas
│       ├── FormularioRetencionDialog.tsx   # ~450 líneas
│       ├── FormularioContribuyenteDialog.tsx # ~700 líneas
│       ├── FormularioF29Dialog.tsx         # ~650 líneas
│       └── index.ts                        # Exports
├── pages/
│   └── tributario/
│       └── DashboardTributarioPage.tsx     # ~1,935 líneas
├── services/
│   └── api/
│       └── tributarioService.ts            # ~850 líneas
├── types/
│   └── tributario.types.ts                 # ~650 líneas
└── utils/
    └── formatters.ts                       # ~450 líneas
```

### Props de Componentes

#### FormularioCompraDialog

```typescript
interface FormularioCompraDialogProps {
  open: boolean;
  onClose: () => void;
  onSuccess: (compra: ICompraIVA) => void;
  edificioId: number;
  mesActual: number;
  anioActual: number;
  compraEditar?: ICompraIVA | null;
}
```

#### FormularioVentaDialog

```typescript
interface FormularioVentaDialogProps {
  open: boolean;
  onClose: () => void;
  onSuccess: (venta: IVentaIVA) => void;
  edificioId: number;
  mesActual: number;
  anioActual: number;
  ventaEditar?: IVentaIVA | null;
}
```

#### FormularioF29Dialog

```typescript
interface FormularioF29DialogProps {
  open: boolean;
  onClose: () => void;
  onSuccess: (f29: IFormularioF29) => void;
  edificioId: number;
  mesInicial: number;
  anioInicial: number;
}
```

### Uso de Componentes

```tsx
import {
  FormularioCompraDialog,
  FormularioVentaDialog,
  FormularioRetencionDialog,
  FormularioContribuyenteDialog,
  FormularioF29Dialog,
} from '@/components/tributario';

function MiComponente() {
  const [dialogCompra, setDialogCompra] = useState(false);
  
  const handleCompraSuccess = (compra: ICompraIVA) => {
    console.log('Compra registrada:', compra);
    // Refrescar datos...
    setDialogCompra(false);
  };
  
  return (
    <>
      <Button onClick={() => setDialogCompra(true)}>
        Nueva Compra
      </Button>
      
      <FormularioCompraDialog
        open={dialogCompra}
        onClose={() => setDialogCompra(false)}
        onSuccess={handleCompraSuccess}
        edificioId={1}
        mesActual={1}
        anioActual={2026}
      />
    </>
  );
}
```

---

## Guía de Usuario

### 1. Registrar Documento de Compra

1. Acceder al **Dashboard Tributario**
2. Click en **"Agregar Compra"**
3. Completar formulario:
   - Seleccionar tipo de documento (Factura, Nota Crédito, etc.)
   - Ingresar folio y fecha
   - Ingresar RUT y razón social del emisor
   - Clasificar tipo de gasto
   - Ingresar monto neto (IVA se calcula automáticamente)
   - Verificar si tiene derecho a crédito fiscal
4. Click **"Guardar"**

### 2. Registrar Documento de Venta

1. Acceder al **Dashboard Tributario**
2. Click en **"Agregar Venta"**
3. Completar formulario:
   - Opcionalmente vincular a contrato de arriendo existente
   - Seleccionar tipo de documento
   - Ingresar folio y fecha
   - Ingresar RUT y razón social del receptor
   - Clasificar tipo de ingreso (el sistema determina si es NO RENTA)
   - Ingresar monto neto
4. Click **"Guardar"**

### 3. Registrar Retención de Honorarios

1. Acceder al **Dashboard Tributario** → Tab **"Retenciones"**
2. Click en **"Nueva Retención"**
3. Completar formulario:
   - Número de boleta
   - Fecha de boleta
   - RUT y nombre del prestador
   - Tipo de servicio
   - Monto bruto (retención 13.75% se calcula automáticamente)
4. Click **"Guardar"**

### 4. Generar Formulario 29

1. Acceder al **Dashboard Tributario**
2. Click en **"Generar F29"** (botón azul principal)
3. **Paso 1:** Seleccionar período (mes y año)
4. **Paso 2:** Revisar datos (débito, crédito, retenciones)
5. **Paso 3:** Validar (el sistema verifica coherencia)
6. **Paso 4:** Generar borrador y descargar PDF
7. Revisar PDF y presentar en SII

### 5. Interpretar Alertas

| Color | Significado | Acción |
|-------|-------------|--------|
| 🔴 Rojo | Vencimiento ≤3 días | Acción URGENTE |
| 🟡 Amarillo | Vencimiento ≤7 días | Planificar acción |
| 🟢 Verde | Sin urgencia | Monitorear |
| 🔵 Azul | Informativo | Tomar nota |

---

## Testing

### Backend (PHPUnit)

```bash
# Ejecutar todos los tests
php artisan test

# Tests específicos del módulo tributario
php artisan test --filter=LibroIVAServiceTest
php artisan test --filter=DeclaracionF29ServiceTest

# Test con cobertura
php artisan test --coverage
```

### Frontend (Jest + Testing Library)

```bash
# Ejecutar tests
npm run test

# Tests específicos
npm run test -- --grep="FormularioCompraDialog"

# Cobertura
npm run test:coverage
```

### E2E (Cypress)

```bash
# Abrir Cypress
npm run cypress:open

# Ejecutar headless
npm run cypress:run
```

---

## Roadmap

### v3.2.1 (Q1 2026) - Mejoras Inmediatas

- [ ] Integración SII DTE con certificado digital
- [ ] Envío automático IECV XML
- [ ] Notificaciones email vencimientos
- [ ] Dashboard móvil responsive

### v3.3.0 (Q2 2026) - Expansión

- [ ] Multi-edificio simultáneo
- [ ] Consolidación tributaria holding
- [ ] Reportes avanzados BI
- [ ] Integración contable ERP

### v4.0.0 (Q3 2026) - Transformación

- [ ] AI para clasificación automática documentos
- [ ] Predicción flujo de caja tributario
- [ ] Alertas inteligentes compliance
- [ ] API abierta para integradores

---

## Soporte

### Contacto

- **Email:** soporte@datapolis.cl
- **Teléfono:** +56 2 2XXX XXXX
- **Web:** https://datapolis.cl

### Recursos

- [Documentación API](https://docs.datapolis.cl/api)
- [Guías de Usuario](https://docs.datapolis.cl/guides)
- [FAQ](https://datapolis.cl/faq)
- [Changelog](https://github.com/datapolis/pro/releases)

---

## Licencia

Copyright © 2026 DATAPOLIS SpA. Todos los derechos reservados.

Este software es propietario y confidencial. No está permitida su reproducción, distribución o modificación sin autorización expresa de DATAPOLIS SpA.

---

*Documento generado automáticamente por DATAPOLIS PRO v3.2*
*Última actualización: Enero 2026*
