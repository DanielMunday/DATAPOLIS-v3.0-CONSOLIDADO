# DATAPOLIS PRO v3.2 - Módulo Tributario Integral

## Sistema de Gestión Tributaria para Copropiedades Chilenas

---

## 📋 Índice

1. [Descripción General](#descripción-general)
2. [Base Legal Implementada](#base-legal-implementada)
3. [Arquitectura del Sistema](#arquitectura-del-sistema)
4. [Componentes Frontend](#componentes-frontend)
5. [Servicios Backend](#servicios-backend)
6. [API REST Endpoints](#api-rest-endpoints)
7. [Guía de Uso](#guía-de-uso)
8. [Configuración e Instalación](#configuración-e-instalación)
9. [Flujos de Trabajo](#flujos-de-trabajo)
10. [Integración SII](#integración-sii)
11. [FAQ y Troubleshooting](#faq-y-troubleshooting)

---

## 📌 Descripción General

El **Módulo Tributario v3.2** de DATAPOLIS PRO es un sistema integral diseñado específicamente para la gestión tributaria de copropiedades chilenas, con especial énfasis en:

- **Arriendos de antenas de telecomunicaciones** (Ley 21.713 Art. 17 N°3 LIR)
- **Libro IVA Compras/Ventas** (DL 825 Art. 64)
- **Formulario 29** con simulación y generación
- **Retenciones de honorarios** (Art. 74 N°2 LIR - 13.75%)
- **PPM Arriendos** (Art. 84 LIR - 10%)
- **IECV** (Información Electrónica Compras Ventas)

### Características Principales

| Característica | Descripción |
|---------------|-------------|
| **Dashboard Tributario** | Panel integral con indicadores, gráficos y alertas |
| **Libro IVA Completo** | Registro detallado de compras y ventas |
| **Generador F29** | Wizard de 4 pasos con validación y previsualización |
| **Retenciones Automáticas** | Cálculo automático al 13.75% vigente |
| **Clasificación Art. 17 N°3** | Identificación automática de ingresos NO renta |
| **Exportación PDF** | Libros IVA y F29 en formato oficial |
| **IECV XML** | Generación para envío al SII |

---

## ⚖️ Base Legal Implementada

### Normativa IVA (DL 825)

```
Art. 8:  Hecho gravado IVA - Débito Fiscal
Art. 23: Crédito Fiscal IVA
Art. 64: Obligación Libro IVA Compras/Ventas
```

### Normativa Renta (DL 824)

```
Art. 17 N°3 LIR (Ley 21.713): Ingresos NO constituyen renta
  - Arriendos antenas telecomunicaciones
  - Publicidad en áreas comunes
  - Estacionamientos
  - Bodegas y locales
  - Eventos y concesiones
  CONDICIÓN: Destinados íntegramente a gastos comunes

Art. 42 N°2 LIR: Remanentes SÍ constituyen renta gravable

Art. 74 N°2 LIR: Retención honorarios 13.75%

Art. 84 LIR: PPM arriendos 10%
```

### Resoluciones SII

```
Res. Ex. N° 45/2003: Formato IECV
Res. Ex. N° 6.509: Estructura XML IECV
Circular N° 53/2024: Procedimientos Ley 21.713
```

---

## 🏗️ Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND (React)                          │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌──────────────────┐  ┌────────────────┐ │
│  │   Dashboard     │  │  Dialogs CRUD    │  │   Services     │ │
│  │   Tributario    │  │  - Compra        │  │  tributario    │ │
│  │   (~1,700L)     │  │  - Venta         │  │  Service.ts    │ │
│  │                 │  │  - Retención     │  │  (~1,170L)     │ │
│  │  - KPIs         │  │  - Contribuyente │  │                │ │
│  │  - Gráficos     │  │  - F29 Wizard    │  │  - libroIVA    │ │
│  │  - Tablas       │  │                  │  │  - F29         │ │
│  │  - Alertas      │  │  (~2,950L)       │  │  - retenciones │ │
│  └─────────────────┘  └──────────────────┘  └────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ API REST
┌─────────────────────────────────────────────────────────────────┐
│                        BACKEND (Laravel)                         │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌──────────────────┐  ┌────────────────┐ │
│  │   Controllers   │  │    Services      │  │    Models      │ │
│  │                 │  │                  │  │                │ │
│  │ LibroIVA        │  │ LibroIVAService  │  │ LibroIVACompra │ │
│  │ Controller      │  │ (~700L)          │  │ LibroIVAVenta  │ │
│  │ (~850L)         │  │                  │  │ ResumenIVA     │ │
│  │                 │  │ DeclaracionF29   │  │ FormularioF29  │ │
│  │ DeclaracionF29  │  │ Service (~650L)  │  │ RetencionHon.  │ │
│  │ Controller      │  │                  │  │ Contribuyente  │ │
│  │ (~950L)         │  │ RetencionesServ. │  │ ConfigPPM      │ │
│  │                 │  │ PPMService       │  │                │ │
│  └─────────────────┘  └──────────────────┘  └────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      DATABASE (MySQL/PostgreSQL)                 │
├─────────────────────────────────────────────────────────────────┤
│  libro_iva_compras    │ libro_iva_ventas     │ resumen_iva      │
│  formularios_f29      │ retenciones_honor.   │ contribuyentes   │
│  configuracion_ppm    │ codigos_f29          │ info_f22         │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎨 Componentes Frontend

### 1. DashboardTributarioPage

**Ubicación:** `/frontend/src/pages/tributario/DashboardTributarioPage.tsx`

Panel principal con:
- **4 KPIs principales**: IVA Determinado, PPM, Retenciones, Total a Pagar
- **Gráfico de tendencias**: 12 meses de histórico
- **Tabs**: Compras, Ventas, Retenciones
- **Alertas**: Vencimientos y pendientes
- **Acciones rápidas**: Generar F29, Descargar PDFs

### 2. FormularioCompraDialog

**Ubicación:** `/frontend/src/components/tributario/FormularioCompraDialog.tsx`

| Campo | Descripción | Validación |
|-------|-------------|------------|
| tipo_documento | FAC, FEX, NC, ND, FC, LF | Requerido |
| folio | Número de documento | > 0 |
| fecha_documento | Fecha del documento | No futura |
| rut_emisor | RUT proveedor | Módulo 11 |
| razon_social_emisor | Nombre proveedor | Mín. 3 chars |
| tipo_gasto | Clasificación | 8 categorías |
| monto_neto | Monto sin IVA | >= 0 |
| monto_iva | IVA calculado | Auto 19% |
| con_derecho_cf | Crédito fiscal | Boolean |
| factor_proporcionalidad | 0-100% | Crédito proporcional |

**Cálculos Automáticos:**
```typescript
IVA = Math.round(monto_neto * 0.19)
Total = monto_neto + IVA
IVA_recuperable = IVA * (factor / 100)
IVA_no_recuperable = IVA - IVA_recuperable
```

### 3. FormularioVentaDialog

**Ubicación:** `/frontend/src/components/tributario/FormularioVentaDialog.tsx`

**Tipos de Ingreso con clasificación Art. 17 N°3:**

| Tipo | NO Renta | Base Legal |
|------|----------|------------|
| arriendo_antenas | ✅ | Art. 17 N°3 LIR |
| publicidad | ✅ | Art. 17 N°3 LIR |
| estacionamientos | ✅ | Art. 17 N°3 LIR |
| locales | ✅ | Art. 17 N°3 LIR |
| bodegas | ✅ | Art. 17 N°3 LIR |
| eventos | ✅ | Art. 17 N°3 LIR |
| concesion | ✅ | Art. 17 N°3 LIR |
| multas_e_intereses | ❌ | Art. 42 N°2 LIR |
| otros | ⚠️ | Evaluar caso |

### 4. FormularioRetencionDialog

**Ubicación:** `/frontend/src/components/tributario/FormularioRetencionDialog.tsx`

**Cálculo Retención Art. 74 N°2 LIR:**
```typescript
Tasa vigente: 13.75%
Monto_retenido = Math.round(monto_bruto * 0.1375)
Monto_liquido = monto_bruto - monto_retenido
```

### 5. FormularioContribuyenteDialog

**Ubicación:** `/frontend/src/components/tributario/FormularioContribuyenteDialog.tsx`

**Clasificación PPM:**

| Tipo Contribuyente | Paga PPM | Tasa |
|-------------------|----------|------|
| Persona Natural sin Giro | ❌ | 0% |
| Persona Natural con Giro | ✅ | 10% |
| Sociedad de Personas | ✅ | 10% |
| Sociedad Anónima | ✅ | 10% |
| Sociedad Inmobiliaria | ✅ | 10% |
| Fondo de Inversión | ❌ | 0% |

### 6. FormularioF29Dialog (Wizard)

**Ubicación:** `/frontend/src/components/tributario/FormularioF29Dialog.tsx`

**Wizard de 4 Pasos:**

1. **Seleccionar Período**: Mes/Año con cálculo vencimiento
2. **Revisar Datos**: Resumen IVA con códigos F29
3. **Validar**: Verificación de coherencia
4. **Generar**: Creación borrador y descarga PDF

**Códigos F29 Implementados:**

| Código | Descripción | Sección |
|--------|-------------|---------|
| [91] | Cantidad facturas emitidas | Débito |
| [538] | Monto neto facturas emitidas | Débito |
| [502] | Cantidad NC recibidas | Débito |
| [92] | Monto NC recibidas | Débito |
| [537] | DÉBITO FISCAL | Débito |
| [519] | Cantidad facturas recibidas | Crédito |
| [520] | Monto neto facturas recibidas | Crédito |
| [521] | Cantidad NC emitidas | Crédito |
| [528] | Monto NC emitidas | Crédito |
| [77] | CRÉDITO FISCAL | Crédito |
| [89] | IVA Determinado | Resultado |
| [116] | PPM | Resultado |
| [548] | Retenciones Honorarios | Resultado |
| [93] | TOTAL A PAGAR | Total |

---

## 🔧 Servicios Backend

### LibroIVAService

```php
// Métodos principales
registrarCompra(array $data): LibroIVACompra
registrarVenta(array $data): LibroIVAVenta
calcularResumenMensual(int $mes, int $anio): ResumenIVAMensual
sincronizarFacturasArriendo(int $mes, int $anio): array
generarIECV(int $mes, int $anio): string
```

### DeclaracionF29Service

```php
// Métodos principales
generarBorrador(int $mes, int $anio): FormularioF29
calcularIVA(ResumenIVAMensual $resumen): array
calcularPPM(Collection $arriendos): array
calcularRetenciones(Collection $boletas): array
validarF29(FormularioF29 $f29): ValidationResult
exportarPDF(FormularioF29 $f29): string
```

### RetencionesService

```php
// Métodos principales
registrarRetencion(array $data): RetencionHonorarios
calcularRetencion(float $montoBruto): array
listarPorPeriodo(int $mes, int $anio): Collection
marcarDeclarado(int $retencionId): RetencionHonorarios
```

---

## 🌐 API REST Endpoints

### Libro IVA

```
GET    /api/v1/edificios/{id}/libro-iva/compras
POST   /api/v1/edificios/{id}/libro-iva/compras
GET    /api/v1/edificios/{id}/libro-iva/compras/{compraId}
POST   /api/v1/edificios/{id}/libro-iva/compras/{compraId}/anular
GET    /api/v1/edificios/{id}/libro-iva/compras/exportar/pdf

GET    /api/v1/edificios/{id}/libro-iva/ventas
POST   /api/v1/edificios/{id}/libro-iva/ventas
GET    /api/v1/edificios/{id}/libro-iva/ventas/{ventaId}
POST   /api/v1/edificios/{id}/libro-iva/ventas/{ventaId}/anular
GET    /api/v1/edificios/{id}/libro-iva/ventas/exportar/pdf

GET    /api/v1/edificios/{id}/libro-iva/resumen/mensual
GET    /api/v1/edificios/{id}/libro-iva/resumen/historial
GET    /api/v1/edificios/{id}/libro-iva/resumen/estadisticas
```

### Formulario 29

```
POST   /api/v1/edificios/{id}/f29/generar
GET    /api/v1/edificios/{id}/f29
GET    /api/v1/edificios/{id}/f29/{f29Id}
POST   /api/v1/edificios/{id}/f29/{f29Id}/aprobar
POST   /api/v1/edificios/{id}/f29/{f29Id}/pago
POST   /api/v1/edificios/{id}/f29/{f29Id}/rectificatoria
GET    /api/v1/edificios/{id}/f29/{f29Id}/validar
GET    /api/v1/edificios/{id}/f29/{f29Id}/pdf
GET    /api/v1/edificios/{id}/f29/{f29Id}/previsualizar
GET    /api/v1/edificios/{id}/f29/historial/anual
GET    /api/v1/edificios/{id}/f29/pendientes/lista
GET    /api/v1/edificios/{id}/f29/dashboard/resumen
```

### Retenciones

```
GET    /api/v1/edificios/{id}/retenciones
POST   /api/v1/edificios/{id}/retenciones
POST   /api/v1/edificios/{id}/retenciones/{retencionId}/anular
```

### Contribuyentes

```
GET    /api/v1/edificios/{id}/contribuyentes-arriendo
PUT    /api/v1/edificios/{id}/contribuyentes-arriendo/{contribuyenteId}
```

### IECV

```
POST   /api/v1/edificios/{id}/libro-iva/iecv/generar
GET    /api/v1/edificios/{id}/libro-iva/iecv/descargar
```

---

## 📖 Guía de Uso

### Flujo Mensual Típico

```mermaid
graph TD
    A[Inicio de Mes] --> B[Registrar Compras]
    B --> C[Registrar Ventas]
    C --> D[Registrar Retenciones]
    D --> E[Revisar Dashboard]
    E --> F{Datos OK?}
    F -->|No| G[Corregir Registros]
    G --> E
    F -->|Sí| H[Generar F29]
    H --> I[Validar F29]
    I --> J{Válido?}
    J -->|No| K[Revisar Errores]
    K --> G
    J -->|Sí| L[Aprobar F29]
    L --> M[Pagar en SII]
    M --> N[Registrar Pago]
    N --> O[Generar IECV]
    O --> P[Fin de Mes]
```

### Registrar una Compra

1. Acceder al **Dashboard Tributario**
2. Ir a pestaña **Compras**
3. Click en **"+ Agregar Compra"**
4. Completar datos del documento
5. Verificar cálculo automático de IVA
6. Configurar crédito fiscal si aplica
7. Guardar

### Generar Formulario 29

1. Click en **"Generar F29"** o usar el wizard
2. **Paso 1**: Seleccionar período (mes/año)
3. **Paso 2**: Revisar resumen IVA
4. **Paso 3**: Validar coherencia de datos
5. **Paso 4**: Generar y descargar PDF
6. Declarar en portal SII

---

## ⚙️ Configuración e Instalación

### Requisitos

```bash
# Backend
PHP >= 8.2
Laravel >= 11.0
MySQL >= 8.0 / PostgreSQL >= 15

# Frontend
Node.js >= 18.0
npm >= 9.0
React >= 18.0
```

### Instalación Backend

```bash
# Clonar repositorio
cd datapolis-consolidado-real

# Instalar dependencias
composer install

# Configurar .env
cp .env.example .env
php artisan key:generate

# Ejecutar migraciones
php artisan migrate

# Ejecutar seeders
php artisan db:seed --class=ConfiguracionPPMSeeder
php artisan db:seed --class=CodigosF29Seeder

# Verificar rutas
php artisan route:list --path=libro-iva
php artisan route:list --path=f29
```

### Instalación Frontend

```bash
cd frontend

# Instalar dependencias
npm install

# Instalar date picker
npm install @mui/x-date-pickers date-fns

# Configurar API URL en .env
VITE_API_URL=http://localhost:8000/api

# Iniciar desarrollo
npm run dev
```

### Variables de Entorno

```env
# Backend .env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=datapolis
DB_USERNAME=root
DB_PASSWORD=

# Configuración SII (opcional)
SII_AMBIENTE=certificacion
SII_RUT_EMPRESA=76.xxx.xxx-x
SII_CERTIFICADO_PATH=/path/to/cert.pfx
SII_CERTIFICADO_PASS=password

# Frontend .env
VITE_API_URL=http://localhost:8000/api
VITE_APP_NAME="DATAPOLIS PRO"
```

---

## 🔄 Flujos de Trabajo

### Clasificación Automática Art. 17 N°3

El sistema clasifica automáticamente los ingresos como **NO RENTA** cuando:

1. El **tipo_ingreso** corresponde a arriendos/servicios en áreas comunes
2. El **contrato de arriendo** está vinculado correctamente
3. Los fondos se destinan a **gastos comunes** (verificación anual)

### Cálculo PPM Arriendos

```php
// Lógica de cálculo
if ($contribuyente->tipo !== 'persona_natural_sin_giro' 
    && $contribuyente->tiene_inicio_actividades
    && $contribuyente->regimen_tributario !== 'renta_presunta'
    && !$contribuyente->exento_ppm) {
    $ppm = $monto_arriendo * 0.10; // 10% Art. 84 LIR
}
```

### Validación F29

El sistema valida automáticamente:

- ✅ Coherencia débito/crédito fiscal
- ✅ Retenciones vs boletas registradas
- ✅ PPM vs arriendos del período
- ✅ Montos > $10M (advertencia)
- ✅ Documentos sin procesar
- ✅ Período cerrado previamente

---

## 🔗 Integración SII

### Estado Actual

| Funcionalidad | Estado | Notas |
|--------------|--------|-------|
| Generación F29 | ✅ 100% | Local, para declaración manual |
| Exportación PDF | ✅ 100% | Formato oficial |
| IECV XML | ✅ 100% | Res. Ex. N° 45/2003 |
| Envío DTE | ⚠️ 70% | Requiere certificado |
| Consulta Estado | ⚠️ 70% | Requiere certificado |
| Firma Electrónica | 🔜 0% | Próxima versión |

### Configuración Certificado Digital

```php
// config/sii.php
return [
    'ambiente' => env('SII_AMBIENTE', 'certificacion'),
    'rut_empresa' => env('SII_RUT_EMPRESA'),
    'certificado' => [
        'path' => env('SII_CERTIFICADO_PATH'),
        'password' => env('SII_CERTIFICADO_PASS'),
    ],
    'urls' => [
        'certificacion' => 'https://maullin.sii.cl',
        'produccion' => 'https://palena.sii.cl',
    ],
];
```

---

## ❓ FAQ y Troubleshooting

### Error: "No se encontraron datos del período"

**Causa**: No hay documentos registrados en el período seleccionado.
**Solución**: Verificar que existan compras/ventas en el mes/año seleccionado.

### Error: "IVA no coincide con cálculo esperado"

**Causa**: Tolerancia de $10 en validación.
**Solución**: Verificar redondeos, usar Math.round() en cálculos.

### Error: "RUT inválido"

**Causa**: Falla validación módulo 11.
**Solución**: Verificar formato XX.XXX.XXX-X con dígito verificador correcto.

### Error: "API no disponible"

**Causa**: Backend no iniciado o ruta incorrecta.
**Solución**: 
1. Verificar `php artisan serve`
2. Verificar `VITE_API_URL` en frontend
3. Verificar `php artisan route:list`

### ¿Cómo corrijo un documento ya registrado?

1. Si estado = 'procesado': Usar botón Editar
2. Si estado = 'declarado': Crear Nota de Crédito

### ¿Cómo genero una rectificatoria?

1. Ir al F29 original ya declarado
2. Click en "Generar Rectificatoria"
3. Ingresar motivo
4. Modificar datos
5. Declarar nuevamente en SII

---

## 📊 Métricas del Módulo

```
Total Líneas de Código: ~12,000L

Backend:
- Servicios:     ~1,350L
- Controllers:   ~1,800L
- Models:        ~800L
- Migraciones:   ~1,000L
- Vistas PDF:    ~500L
- Rutas:         ~350L

Frontend:
- Dashboard:     ~1,700L
- Dialogs CRUD:  ~2,950L
- Services:      ~1,170L
- Types:         ~650L
- Utils:         ~450L

Cobertura Funcional: 95%
Integración SII:     70%
Testing:             En desarrollo
```

---

## 📝 Changelog

### v3.2.0 (2026-01-06)

- ✨ Dashboard Tributario completo con KPIs y gráficos
- ✨ 5 Dialogs CRUD (Compra, Venta, Retención, Contribuyente, F29)
- ✨ Wizard F29 de 4 pasos con validación
- ✨ Integración API real con fallback
- ✨ Clasificación automática Art. 17 N°3 LIR
- ✨ Cálculo PPM según tipo contribuyente
- ✨ Exportación PDF Libros IVA y F29
- ✨ Generación IECV XML
- 🔧 Servicios API TypeScript completos
- 🔧 Tipos TypeScript exhaustivos
- 📝 Documentación completa

---

## 👥 Soporte

**DATAPOLIS SpA**
- Email: soporte@datapolis.cl
- Web: https://datapolis.cl
- Docs: https://docs.datapolis.cl

---

*Documento generado el 06 de enero de 2026*
*DATAPOLIS PRO v3.2 - Sistema Tributario Integral*
*© 2026 DATAPOLIS SpA - Todos los derechos reservados*
