# 🚀 DATAPOLIS PRO - Executive Summary para Inversionistas

## La Oportunidad

**DATAPOLIS PRO** es una plataforma PropTech/FinTech B2B que automatiza la gestión de condominios en Chile, con enfoque especial en el cumplimiento tributario de arriendos de espacios comunes (antenas telecom, publicidad).

---

## El Problema

### Contexto Legal Urgente

| Ley | Descripción | Deadline |
|-----|-------------|:--------:|
| **Ley 21.442** | Nueva regulación de copropiedad | **9 enero 2026** |
| **Ley 21.713** | Distribución de ingresos (Art. 17 N°3 LIR) | Vigente |
| **Ley 21.719** | Protección de datos (multas hasta 20,000 UTM) | Vigente |

### Dolor del Cliente

- **12,000+ condominios** en Chile con contratos telecom
- Administradores usan Excel para gestión tributaria compleja
- Riesgo de sanciones SII por errores en distribución de ingresos
- Sin herramientas que cumplan las 4 leyes simultáneamente

---

## La Solución

### Stack Tecnológico

```
Frontend: React 18 + TypeScript + Vite + Tailwind
Backend:  Laravel 11 + MySQL + Redis
Infra:    Docker + Ubuntu 24 LTS
```

### Diferenciadores Clave

| Feature | DATAPOLIS | Competencia |
|---------|:---------:|:-----------:|
| Cumplimiento Ley 21.442 | ✅ | ⚠️ Parcial |
| Distribución Art. 17 N°3 | ✅ | ❌ |
| DJ 1887 automática | ✅ | ❌ |
| Certificados renta | ✅ | ❌ |
| Protección datos ARCO+ | ✅ | ❌ |
| Multi-tenant | ✅ | ⚠️ |

---

## Tracción y Métricas

### Desarrollo

| Métrica | Valor |
|---------|:-----:|
| Líneas de código | 22,014 |
| Endpoints API | ~160 |
| Tablas BD | ~95 |
| Leyes implementadas | 4 |
| Completitud | 99% |

### Mercado

| Segmento | TAM Chile |
|----------|:---------:|
| Condominios con telecom | $300M CLP/año |
| Edificios grandes | $360M CLP/año |
| RRHH interno | $180M CLP/año |
| **Total Chile** | **$840M CLP/año** |

---

## Modelo de Negocio

### Pricing SaaS

| Plan | Precio/mes | Margen |
|------|:----------:|:------:|
| Starter | $49.990 CLP | 85% |
| Professional | $149.990 CLP | 90% |
| Enterprise | $349.990 CLP | 92% |

### Unit Economics (Proyectado)

- **CAC:** $150.000 CLP
- **LTV:** $1.800.000 CLP (3 años)
- **LTV/CAC:** 12x
- **Churn mensual:** <2%

---

## Equipo

**Daniel Rivas - Founder & CEO**
- Arquitecto y Urbanista
- Expertise en regulación chilena de copropiedad
- Desarrollo técnico completo del MVP

### Necesidades de Equipo

| Rol | Prioridad | Salario Anual |
|-----|:---------:|:-------------:|
| CTO | Alta | $48M CLP |
| Full-stack Developer | Alta | $36M CLP |
| Sales Lead | Alta | $30M CLP |
| Customer Success | Media | $24M CLP |

---

## Financiamiento

### Ronda Actual: Pre-Seed / Seed

| Métrica | Valor |
|---------|:-----:|
| Valoración pre-money | $400-600M CLP |
| Levantamiento objetivo | $150-200M CLP |
| Uso de fondos | Equipo + Go-to-market |

### Uso de Fondos

```
Desarrollo producto:  40% ($60-80M CLP)
Equipo comercial:     30% ($45-60M CLP)
Marketing:            15% ($22-30M CLP)
Operaciones:          10% ($15-20M CLP)
Legal:                 5% ($7-10M CLP)
```

---

## Roadmap

### Q1 2026
- [ ] Lanzamiento comercial Chile
- [ ] 50 clientes piloto
- [ ] Integración Transbank

### Q2-Q3 2026
- [ ] 200 clientes activos
- [ ] App móvil
- [ ] Facturación electrónica SII

### Q4 2026
- [ ] Break-even operacional
- [ ] Expansión Colombia (VehiMax synergy)
- [ ] Ronda Serie A

---

## Competencia

| Competidor | Fortaleza | Debilidad |
|------------|-----------|-----------|
| **Comunidapp** | Base instalada | Sin tributario avanzado |
| **Edificium** | UX simple | Sin cumplimiento legal |
| **KSP Admin** | Tradición | Tecnología legacy |
| **DATAPOLIS** | **Compliance + Tech** | **Nuevo en mercado** |

---

## Por Qué Ahora

1. **Deadline 9 enero 2026** - Urgencia regulatoria
2. **Ley 21.713 nueva** - Sin soluciones existentes
3. **Multas Ley 21.719** - Hasta $1.400M CLP por incumplimiento
4. **COVID aceleró** - Digitalización de condominios

---

## Call to Action

### Buscamos

- **Smart money** con experiencia en PropTech/FinTech
- **Red de contactos** en inmobiliarias y administradores
- **Expertise** en go-to-market B2B Chile

### Contacto

```
Daniel Rivas
Founder & CEO, DATAPOLIS SpA
Email: daniel@datapolis.cl
LinkedIn: /in/danielrivas
```

---

**DATAPOLIS - Compliance automatizado para condominios inteligentes**

*"El único software que cumple las 4 leyes que afectan a tu comunidad"*
