import React, { useState, useEffect } from 'react';
import { 
  Building2, CreditCard, ArrowLeftRight, FileCheck, 
  Upload, Plus, Search, Filter, Download, RefreshCw,
  ChevronRight, AlertCircle, CheckCircle, Clock, 
  TrendingUp, TrendingDown, Wallet, ArrowUpDown
} from 'lucide-react';

// ============================================================================
// TIPOS
// ============================================================================

interface CuentaBancaria {
  id: number;
  banco_nombre: string;
  banco_codigo: string;
  numero_cuenta: string;
  tipo_cuenta: string;
  proposito: string;
  base_legal: string | null;
  saldo_contable: number;
  saldo_banco: number;
  saldo_disponible: number;
  activa: boolean;
  es_principal: boolean;
}

interface Movimiento {
  id: number;
  fecha: string;
  tipo: string;
  descripcion: string;
  numero_documento: string | null;
  cargo: number;
  abono: number;
  saldo_posterior: number | null;
  conciliado: boolean;
  estado: string;
}

interface Traspaso {
  id: number;
  numero_traspaso: string;
  fecha: string;
  monto: number;
  tipo: string;
  concepto: string;
  estado: string;
  constituye_renta: boolean;
  base_legal: string | null;
  banco_origen: string;
  banco_destino: string | null;
}

interface Edificio {
  id: number;
  nombre: string;
}

// ============================================================================
// COMPONENTE PRINCIPAL
// ============================================================================

const CuentasBancariasPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'cuentas' | 'movimientos' | 'traspasos' | 'conciliacion' | 'importar'>('cuentas');
  const [edificios, setEdificios] = useState<Edificio[]>([]);
  const [selectedEdificio, setSelectedEdificio] = useState<number | null>(null);
  const [cuentas, setCuentas] = useState<CuentaBancaria[]>([]);
  const [selectedCuenta, setSelectedCuenta] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [showCrearCuenta, setShowCrearCuenta] = useState(false);

  // Cargar edificios al inicio
  useEffect(() => {
    fetchEdificios();
  }, []);

  // Cargar cuentas cuando se selecciona edificio
  useEffect(() => {
    if (selectedEdificio) {
      fetchCuentas(selectedEdificio);
    }
  }, [selectedEdificio]);

  const fetchEdificios = async () => {
    try {
      const res = await fetch('/api/edificios', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setEdificios(data.data || []);
      if (data.data?.length > 0) {
        setSelectedEdificio(data.data[0].id);
      }
    } catch (error) {
      console.error('Error cargando edificios:', error);
    }
  };

  const fetchCuentas = async (edificioId: number) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/bancos/cuentas?edificio_id=${edificioId}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setCuentas(data.data || []);
    } catch (error) {
      console.error('Error cargando cuentas:', error);
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'cuentas', label: 'Cuentas', icon: CreditCard },
    { id: 'movimientos', label: 'Movimientos', icon: ArrowUpDown },
    { id: 'traspasos', label: 'Traspasos', icon: ArrowLeftRight },
    { id: 'conciliacion', label: 'Conciliación', icon: FileCheck },
    { id: 'importar', label: 'Importar Cartola', icon: Upload },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Building2 className="w-7 h-7 text-blue-600" />
              Gestión Bancaria
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              Control de cuentas, movimientos y conciliación bancaria
            </p>
          </div>
          
          {/* Selector de Edificio */}
          <select
            value={selectedEdificio || ''}
            onChange={(e) => setSelectedEdificio(Number(e.target.value))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Seleccionar edificio...</option>
            {edificios.map(e => (
              <option key={e.id} value={e.id}>{e.nombre}</option>
            ))}
          </select>
        </div>

        {/* Tabs */}
        <div className="flex space-x-1 mt-4 border-b border-gray-200">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 font-medium text-sm rounded-t-lg transition-colors
                  ${activeTab === tab.id 
                    ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' 
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'}`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Contenido */}
      <div className="p-6">
        {!selectedEdificio ? (
          <div className="bg-white rounded-lg shadow p-8 text-center">
            <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">Seleccione un edificio</h3>
            <p className="text-gray-500 mt-2">Para ver las cuentas bancarias, seleccione un edificio del selector superior.</p>
          </div>
        ) : (
          <>
            {activeTab === 'cuentas' && (
              <CuentasTab 
                cuentas={cuentas} 
                loading={loading}
                onRefresh={() => fetchCuentas(selectedEdificio)}
                onCrear={() => setShowCrearCuenta(true)}
                onSelect={(id) => {
                  setSelectedCuenta(id);
                  setActiveTab('movimientos');
                }}
              />
            )}
            {activeTab === 'movimientos' && (
              <MovimientosTab 
                cuentas={cuentas}
                selectedCuenta={selectedCuenta}
                onSelectCuenta={setSelectedCuenta}
              />
            )}
            {activeTab === 'traspasos' && (
              <TraspasosTab 
                edificioId={selectedEdificio}
                cuentas={cuentas}
              />
            )}
            {activeTab === 'conciliacion' && (
              <ConciliacionTab 
                cuentas={cuentas}
                selectedCuenta={selectedCuenta}
                onSelectCuenta={setSelectedCuenta}
              />
            )}
            {activeTab === 'importar' && (
              <ImportarCartolaTab 
                cuentas={cuentas}
                selectedCuenta={selectedCuenta}
                onSelectCuenta={setSelectedCuenta}
                onSuccess={() => fetchCuentas(selectedEdificio)}
              />
            )}
          </>
        )}
      </div>

      {/* Modal Crear Cuenta */}
      {showCrearCuenta && selectedEdificio && (
        <CrearCuentaModal
          edificioId={selectedEdificio}
          onClose={() => setShowCrearCuenta(false)}
          onSuccess={() => {
            setShowCrearCuenta(false);
            fetchCuentas(selectedEdificio);
          }}
        />
      )}
    </div>
  );
};

// ============================================================================
// TAB: CUENTAS
// ============================================================================

interface CuentasTabProps {
  cuentas: CuentaBancaria[];
  loading: boolean;
  onRefresh: () => void;
  onCrear: () => void;
  onSelect: (id: number) => void;
}

const CuentasTab: React.FC<CuentasTabProps> = ({ cuentas, loading, onRefresh, onCrear, onSelect }) => {
  const formatMonto = (monto: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(monto);
  };

  const getPropositoColor = (proposito: string) => {
    const colores: Record<string, string> = {
      'gastos_comunes': 'bg-blue-100 text-blue-800',
      'arriendos': 'bg-green-100 text-green-800',
      'fondo_reserva': 'bg-purple-100 text-purple-800',
      'operacional': 'bg-gray-100 text-gray-800',
      'remuneraciones': 'bg-orange-100 text-orange-800',
    };
    return colores[proposito] || 'bg-gray-100 text-gray-800';
  };

  const getPropositoLabel = (proposito: string) => {
    const labels: Record<string, string> = {
      'gastos_comunes': 'Gastos Comunes',
      'arriendos': 'Arriendos',
      'fondo_reserva': 'Fondo Reserva',
      'operacional': 'Operacional',
      'remuneraciones': 'Remuneraciones',
    };
    return labels[proposito] || proposito;
  };

  // Calcular totales
  const totalSaldo = cuentas.reduce((sum, c) => sum + c.saldo_contable, 0);
  const totalDisponible = cuentas.reduce((sum, c) => sum + c.saldo_disponible, 0);

  return (
    <div className="space-y-6">
      {/* Resumen */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total en Cuentas</p>
              <p className="text-2xl font-bold text-gray-900">{formatMonto(totalSaldo)}</p>
            </div>
            <Wallet className="w-10 h-10 text-blue-500" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Saldo Disponible</p>
              <p className="text-2xl font-bold text-green-600">{formatMonto(totalDisponible)}</p>
            </div>
            <TrendingUp className="w-10 h-10 text-green-500" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Cuentas Activas</p>
              <p className="text-2xl font-bold text-gray-900">{cuentas.filter(c => c.activa).length}</p>
            </div>
            <CreditCard className="w-10 h-10 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Acciones */}
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-900">Cuentas Bancarias</h2>
        <div className="flex gap-2">
          <button
            onClick={onRefresh}
            className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
          >
            <RefreshCw className="w-4 h-4" />
            Actualizar
          </button>
          <button
            onClick={onCrear}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-4 h-4" />
            Nueva Cuenta
          </button>
        </div>
      </div>

      {/* Lista de Cuentas */}
      {loading ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <RefreshCw className="w-8 h-8 text-gray-400 animate-spin mx-auto mb-2" />
          <p className="text-gray-500">Cargando cuentas...</p>
        </div>
      ) : cuentas.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <CreditCard className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900">Sin cuentas bancarias</h3>
          <p className="text-gray-500 mt-2">
            Este edificio no tiene cuentas bancarias registradas.
          </p>
          <button
            onClick={onCrear}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Crear primera cuenta
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {cuentas.map((cuenta) => (
            <div
              key={cuenta.id}
              className="bg-white rounded-lg shadow hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onSelect(cuenta.id)}
            >
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-gray-900">{cuenta.banco_nombre}</h3>
                      {cuenta.es_principal && (
                        <span className="px-2 py-0.5 text-xs bg-yellow-100 text-yellow-800 rounded-full">
                          Principal
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      {cuenta.tipo_cuenta.charAt(0).toUpperCase() + cuenta.tipo_cuenta.slice(1)} N° {cuenta.numero_cuenta}
                    </p>
                  </div>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getPropositoColor(cuenta.proposito)}`}>
                    {getPropositoLabel(cuenta.proposito)}
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-gray-500">Saldo Contable</p>
                    <p className="text-lg font-semibold text-gray-900">{formatMonto(cuenta.saldo_contable)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Saldo Banco</p>
                    <p className="text-lg font-semibold text-gray-900">{formatMonto(cuenta.saldo_banco)}</p>
                  </div>
                </div>

                {cuenta.base_legal && (
                  <div className="mt-4 p-2 bg-blue-50 rounded text-xs text-blue-700">
                    <strong>Base Legal:</strong> {cuenta.base_legal}
                  </div>
                )}

                <div className="mt-4 flex items-center justify-between text-sm">
                  <span className={`flex items-center gap-1 ${cuenta.activa ? 'text-green-600' : 'text-red-600'}`}>
                    {cuenta.activa ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                    {cuenta.activa ? 'Activa' : 'Inactiva'}
                  </span>
                  <span className="text-blue-600 flex items-center gap-1">
                    Ver movimientos <ChevronRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ============================================================================
// TAB: MOVIMIENTOS
// ============================================================================

interface MovimientosTabProps {
  cuentas: CuentaBancaria[];
  selectedCuenta: number | null;
  onSelectCuenta: (id: number | null) => void;
}

const MovimientosTab: React.FC<MovimientosTabProps> = ({ cuentas, selectedCuenta, onSelectCuenta }) => {
  const [movimientos, setMovimientos] = useState<Movimiento[]>([]);
  const [loading, setLoading] = useState(false);
  const [filtros, setFiltros] = useState({
    fechaDesde: '',
    fechaHasta: '',
    tipo: '',
    conciliado: '',
  });

  useEffect(() => {
    if (selectedCuenta) {
      fetchMovimientos();
    }
  }, [selectedCuenta]);

  const fetchMovimientos = async () => {
    if (!selectedCuenta) return;
    setLoading(true);
    try {
      let url = `/api/bancos/movimientos?cuenta_id=${selectedCuenta}`;
      if (filtros.fechaDesde) url += `&fecha_desde=${filtros.fechaDesde}`;
      if (filtros.fechaHasta) url += `&fecha_hasta=${filtros.fechaHasta}`;
      if (filtros.tipo) url += `&tipo=${filtros.tipo}`;
      if (filtros.conciliado) url += `&conciliado=${filtros.conciliado}`;

      const res = await fetch(url, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setMovimientos(data.data?.data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatMonto = (monto: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(monto);
  };

  const formatFecha = (fecha: string) => {
    return new Date(fecha).toLocaleDateString('es-CL');
  };

  const getTipoLabel = (tipo: string) => {
    const labels: Record<string, string> = {
      'deposito': 'Depósito',
      'transferencia_recibida': 'TEF Recibida',
      'transferencia_enviada': 'TEF Enviada',
      'cheque_girado': 'Cheque Girado',
      'cheque_cobrado': 'Cheque Cobrado',
      'cargo_automatico': 'Cargo Automático',
      'comision_bancaria': 'Comisión',
      'pago_remuneracion': 'Pago Sueldo',
      'pago_cotizaciones': 'Pago Cotizaciones',
      'traspaso_interno_entrada': 'Traspaso Entrada',
      'traspaso_interno_salida': 'Traspaso Salida',
    };
    return labels[tipo] || tipo;
  };

  return (
    <div className="space-y-6">
      {/* Selector de Cuenta */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center gap-4">
          <label className="text-sm font-medium text-gray-700">Cuenta:</label>
          <select
            value={selectedCuenta || ''}
            onChange={(e) => onSelectCuenta(Number(e.target.value) || null)}
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Seleccionar cuenta...</option>
            {cuentas.map(c => (
              <option key={c.id} value={c.id}>
                {c.banco_nombre} - {c.numero_cuenta} ({c.proposito})
              </option>
            ))}
          </select>
        </div>

        {/* Filtros */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
          <input
            type="date"
            placeholder="Desde"
            value={filtros.fechaDesde}
            onChange={(e) => setFiltros({...filtros, fechaDesde: e.target.value})}
            className="px-3 py-2 border border-gray-300 rounded-lg"
          />
          <input
            type="date"
            placeholder="Hasta"
            value={filtros.fechaHasta}
            onChange={(e) => setFiltros({...filtros, fechaHasta: e.target.value})}
            className="px-3 py-2 border border-gray-300 rounded-lg"
          />
          <select
            value={filtros.conciliado}
            onChange={(e) => setFiltros({...filtros, conciliado: e.target.value})}
            className="px-3 py-2 border border-gray-300 rounded-lg"
          >
            <option value="">Todos</option>
            <option value="1">Conciliados</option>
            <option value="0">Pendientes</option>
          </select>
          <button
            onClick={fetchMovimientos}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2"
          >
            <Search className="w-4 h-4" />
            Buscar
          </button>
        </div>
      </div>

      {/* Tabla de Movimientos */}
      {!selectedCuenta ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <ArrowUpDown className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">Seleccione una cuenta para ver sus movimientos</p>
        </div>
      ) : loading ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <RefreshCw className="w-8 h-8 text-gray-400 animate-spin mx-auto" />
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipo</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Descripción</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Cargo</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Abono</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Saldo</th>
                <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Estado</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {movimientos.map((mov) => (
                <tr key={mov.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm text-gray-900">{formatFecha(mov.fecha)}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{getTipoLabel(mov.tipo)}</td>
                  <td className="px-4 py-3 text-sm text-gray-900 max-w-xs truncate">{mov.descripcion}</td>
                  <td className="px-4 py-3 text-sm text-right text-red-600 font-medium">
                    {mov.cargo > 0 ? formatMonto(mov.cargo) : '-'}
                  </td>
                  <td className="px-4 py-3 text-sm text-right text-green-600 font-medium">
                    {mov.abono > 0 ? formatMonto(mov.abono) : '-'}
                  </td>
                  <td className="px-4 py-3 text-sm text-right text-gray-900">
                    {mov.saldo_posterior ? formatMonto(mov.saldo_posterior) : '-'}
                  </td>
                  <td className="px-4 py-3 text-center">
                    {mov.conciliado ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Conciliado
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-yellow-100 text-yellow-800">
                        <Clock className="w-3 h-3 mr-1" />
                        Pendiente
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {movimientos.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              No se encontraron movimientos
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// ============================================================================
// TAB: TRASPASOS
// ============================================================================

interface TraspasosTabProps {
  edificioId: number;
  cuentas: CuentaBancaria[];
}

const TraspasosTab: React.FC<TraspasosTabProps> = ({ edificioId, cuentas }) => {
  const [traspasos, setTraspasos] = useState<Traspaso[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCrear, setShowCrear] = useState(false);
  const [tipoTraspaso, setTipoTraspaso] = useState<'arriendos_gc' | 'remanente' | null>(null);

  useEffect(() => {
    fetchTraspasos();
  }, [edificioId]);

  const fetchTraspasos = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/bancos/traspasos?edificio_id=${edificioId}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setTraspasos(data.data?.data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatMonto = (monto: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(monto);
  };

  const getEstadoColor = (estado: string) => {
    const colores: Record<string, string> = {
      'borrador': 'bg-gray-100 text-gray-800',
      'pendiente': 'bg-yellow-100 text-yellow-800',
      'aprobado': 'bg-blue-100 text-blue-800',
      'ejecutado': 'bg-green-100 text-green-800',
      'rechazado': 'bg-red-100 text-red-800',
    };
    return colores[estado] || 'bg-gray-100 text-gray-800';
  };

  const aprobarTraspaso = async (id: number) => {
    try {
      await fetch(`/api/bancos/traspasos/${id}/aprobar`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      fetchTraspasos();
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const ejecutarTraspaso = async (id: number) => {
    try {
      await fetch(`/api/bancos/traspasos/${id}/ejecutar`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      fetchTraspasos();
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Acciones */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-900">Traspasos entre Cuentas</h2>
          <div className="flex gap-2">
            <button
              onClick={() => { setTipoTraspaso('arriendos_gc'); setShowCrear(true); }}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              <Plus className="w-4 h-4" />
              Arriendos → GC (Art. 17 N°3)
            </button>
            <button
              onClick={() => { setTipoTraspaso('remanente'); setShowCrear(true); }}
              className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
            >
              <Plus className="w-4 h-4" />
              Remanente a Copropietario
            </button>
          </div>
        </div>
      </div>

      {/* Info Art. 17 N°3 */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
          <div>
            <h4 className="font-medium text-blue-900">Ley 21.713 - Art. 17 N°3 LIR</h4>
            <p className="text-sm text-blue-700 mt-1">
              Los traspasos de <strong>Arriendos → GC</strong> no constituyen renta para el copropietario.
              Los <strong>remanentes</strong> (excedentes no usados en GC) sí constituyen renta y deben declararse.
            </p>
          </div>
        </div>
      </div>

      {/* Tabla */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">N° Traspaso</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipo</th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Monto</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">¿Renta?</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Estado</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {traspasos.map((t) => (
              <tr key={t.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-medium text-gray-900">{t.numero_traspaso}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{new Date(t.fecha).toLocaleDateString('es-CL')}</td>
                <td className="px-4 py-3 text-sm text-gray-900">{t.tipo.replace(/_/g, ' ')}</td>
                <td className="px-4 py-3 text-sm text-right font-medium text-gray-900">{formatMonto(t.monto)}</td>
                <td className="px-4 py-3 text-center">
                  {t.constituye_renta ? (
                    <span className="px-2 py-0.5 text-xs rounded bg-orange-100 text-orange-800">SÍ</span>
                  ) : (
                    <span className="px-2 py-0.5 text-xs rounded bg-green-100 text-green-800">NO</span>
                  )}
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`px-2 py-0.5 text-xs rounded ${getEstadoColor(t.estado)}`}>
                    {t.estado}
                  </span>
                </td>
                <td className="px-4 py-3 text-center">
                  {t.estado === 'pendiente' && (
                    <button
                      onClick={() => aprobarTraspaso(t.id)}
                      className="text-xs text-blue-600 hover:text-blue-800 mr-2"
                    >
                      Aprobar
                    </button>
                  )}
                  {t.estado === 'aprobado' && (
                    <button
                      onClick={() => ejecutarTraspaso(t.id)}
                      className="text-xs text-green-600 hover:text-green-800"
                    >
                      Ejecutar
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {traspasos.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            No hay traspasos registrados
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// TAB: CONCILIACIÓN
// ============================================================================

interface ConciliacionTabProps {
  cuentas: CuentaBancaria[];
  selectedCuenta: number | null;
  onSelectCuenta: (id: number | null) => void;
}

const ConciliacionTab: React.FC<ConciliacionTabProps> = ({ cuentas, selectedCuenta, onSelectCuenta }) => {
  const [mes, setMes] = useState(new Date().getMonth() + 1);
  const [anio, setAnio] = useState(new Date().getFullYear());
  const [conciliacion, setConciliacion] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const iniciarConciliacion = async () => {
    if (!selectedCuenta) return;
    setLoading(true);
    try {
      const res = await fetch('/api/bancos/conciliacion/iniciar', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ cuenta_id: selectedCuenta, mes, anio })
      });
      const data = await res.json();
      if (data.success) {
        fetchConciliacion();
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchConciliacion = async () => {
    if (!selectedCuenta) return;
    try {
      const res = await fetch(`/api/bancos/conciliacion?cuenta_id=${selectedCuenta}&mes=${mes}&anio=${anio}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setConciliacion(data.data || null);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const formatMonto = (monto: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(monto);
  };

  return (
    <div className="space-y-6">
      {/* Selector */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <select
            value={selectedCuenta || ''}
            onChange={(e) => onSelectCuenta(Number(e.target.value) || null)}
            className="px-3 py-2 border border-gray-300 rounded-lg"
          >
            <option value="">Seleccionar cuenta...</option>
            {cuentas.map(c => (
              <option key={c.id} value={c.id}>{c.banco_nombre} - {c.numero_cuenta}</option>
            ))}
          </select>
          <select
            value={mes}
            onChange={(e) => setMes(Number(e.target.value))}
            className="px-3 py-2 border border-gray-300 rounded-lg"
          >
            {Array.from({length: 12}, (_, i) => (
              <option key={i+1} value={i+1}>{new Date(2000, i).toLocaleString('es', {month: 'long'})}</option>
            ))}
          </select>
          <select
            value={anio}
            onChange={(e) => setAnio(Number(e.target.value))}
            className="px-3 py-2 border border-gray-300 rounded-lg"
          >
            {[2024, 2025, 2026].map(a => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
          <button
            onClick={iniciarConciliacion}
            disabled={!selectedCuenta || loading}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? 'Procesando...' : 'Iniciar Conciliación'}
          </button>
        </div>
      </div>

      {/* Estado de Conciliación */}
      {conciliacion && (
        <div className="bg-white rounded-lg shadow">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900">
              Conciliación {new Date(2000, mes - 1).toLocaleString('es', {month: 'long'})} {anio}
            </h3>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-xs text-gray-500">Saldo Libro</p>
                <p className="text-lg font-bold">{formatMonto(conciliacion.saldo_final_libro)}</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-xs text-gray-500">Saldo Banco</p>
                <p className="text-lg font-bold">{formatMonto(conciliacion.saldo_final_banco)}</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-xs text-gray-500">Diferencia</p>
                <p className={`text-lg font-bold ${conciliacion.diferencia === 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatMonto(conciliacion.diferencia)}
                </p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-xs text-gray-500">Estado</p>
                <p className={`text-lg font-bold ${conciliacion.conciliada ? 'text-green-600' : 'text-yellow-600'}`}>
                  {conciliacion.conciliada ? '✓ Cuadra' : 'Pendiente'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// TAB: IMPORTAR CARTOLA
// ============================================================================

interface ImportarCartolaTabProps {
  cuentas: CuentaBancaria[];
  selectedCuenta: number | null;
  onSelectCuenta: (id: number | null) => void;
  onSuccess: () => void;
}

const ImportarCartolaTab: React.FC<ImportarCartolaTabProps> = ({ 
  cuentas, selectedCuenta, onSelectCuenta, onSuccess 
}) => {
  const [banco, setBanco] = useState('');
  const [archivo, setArchivo] = useState<File | null>(null);
  const [preview, setPreview] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<any>(null);

  const bancos = [
    { codigo: 'banco_chile', nombre: 'Banco de Chile' },
    { codigo: 'banco_estado', nombre: 'BancoEstado' },
    { codigo: 'santander', nombre: 'Santander' },
    { codigo: 'bci', nombre: 'BCI' },
    { codigo: 'scotiabank', nombre: 'Scotiabank' },
    { codigo: 'itau', nombre: 'Itaú' },
    { codigo: 'bice', nombre: 'BICE' },
    { codigo: 'security', nombre: 'Security' },
    { codigo: 'generico', nombre: 'Genérico' },
  ];

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setArchivo(file);
      setPreview(null);
      setResultado(null);
    }
  };

  const previsualizarArchivo = async () => {
    if (!archivo || !banco) return;
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('archivo', archivo);
      formData.append('banco', banco);

      const res = await fetch('/api/bancos/importador/preview', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
        body: formData
      });
      const data = await res.json();
      setPreview(data);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const importarArchivo = async () => {
    if (!archivo || !banco || !selectedCuenta) return;
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('archivo', archivo);
      formData.append('banco', banco);
      formData.append('cuenta_id', selectedCuenta.toString());

      const res = await fetch('/api/bancos/importador/importar', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
        body: formData
      });
      const data = await res.json();
      setResultado(data);
      if (data.success) {
        onSuccess();
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Formulario */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Importar Cartola Bancaria</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Cuenta Bancaria</label>
            <select
              value={selectedCuenta || ''}
              onChange={(e) => onSelectCuenta(Number(e.target.value) || null)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            >
              <option value="">Seleccionar...</option>
              {cuentas.map(c => (
                <option key={c.id} value={c.id}>{c.banco_nombre} - {c.numero_cuenta}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Formato del Banco</label>
            <select
              value={banco}
              onChange={(e) => setBanco(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            >
              <option value="">Seleccionar banco...</option>
              {bancos.map(b => (
                <option key={b.codigo} value={b.codigo}>{b.nombre}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Archivo</label>
            <input
              type="file"
              accept=".csv,.xls,.xlsx"
              onChange={handleFileChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          <button
            onClick={previsualizarArchivo}
            disabled={!archivo || !banco || loading}
            className="px-4 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 disabled:opacity-50"
          >
            Vista Previa
          </button>
          <button
            onClick={importarArchivo}
            disabled={!archivo || !banco || !selectedCuenta || loading}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? 'Importando...' : 'Importar'}
          </button>
        </div>
      </div>

      {/* Preview */}
      {preview && preview.success && (
        <div className="bg-white rounded-lg shadow p-4">
          <h3 className="font-medium text-gray-900 mb-2">Vista Previa ({preview.total_lineas} líneas)</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-3 py-2 text-left">Fecha</th>
                  <th className="px-3 py-2 text-left">Descripción</th>
                  <th className="px-3 py-2 text-right">Cargo</th>
                  <th className="px-3 py-2 text-right">Abono</th>
                  <th className="px-3 py-2 text-right">Saldo</th>
                </tr>
              </thead>
              <tbody>
                {preview.preview?.map((row: any, i: number) => (
                  <tr key={i} className="border-b">
                    <td className="px-3 py-2">{row.fecha}</td>
                    <td className="px-3 py-2 max-w-xs truncate">{row.descripcion}</td>
                    <td className="px-3 py-2 text-right text-red-600">{row.cargo || '-'}</td>
                    <td className="px-3 py-2 text-right text-green-600">{row.abono || '-'}</td>
                    <td className="px-3 py-2 text-right">{row.saldo || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Resultado */}
      {resultado && (
        <div className={`rounded-lg shadow p-4 ${resultado.success ? 'bg-green-50' : 'bg-red-50'}`}>
          <h3 className={`font-medium ${resultado.success ? 'text-green-900' : 'text-red-900'}`}>
            {resultado.success ? '✓ Importación Exitosa' : '✗ Error en Importación'}
          </h3>
          {resultado.success && (
            <div className="mt-2 grid grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Importados:</span>
                <span className="ml-2 font-bold text-green-600">{resultado.movimientos_importados}</span>
              </div>
              <div>
                <span className="text-gray-600">Duplicados:</span>
                <span className="ml-2 font-bold text-yellow-600">{resultado.movimientos_duplicados}</span>
              </div>
              <div>
                <span className="text-gray-600">Errores:</span>
                <span className="ml-2 font-bold text-red-600">{resultado.movimientos_errores}</span>
              </div>
            </div>
          )}
          {resultado.message && (
            <p className="mt-2 text-sm text-gray-600">{resultado.message}</p>
          )}
        </div>
      )}
    </div>
  );
};

// ============================================================================
// MODAL: CREAR CUENTA
// ============================================================================

interface CrearCuentaModalProps {
  edificioId: number;
  onClose: () => void;
  onSuccess: () => void;
}

const CrearCuentaModal: React.FC<CrearCuentaModalProps> = ({ edificioId, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    banco_codigo: '',
    banco_nombre: '',
    tipo_cuenta: 'corriente',
    numero_cuenta: '',
    rut_titular: '',
    nombre_titular: '',
    proposito: 'gastos_comunes',
    saldo_inicial: 0,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const bancos = [
    { codigo: 'BCHI', nombre: 'Banco de Chile' },
    { codigo: 'BEST', nombre: 'BancoEstado' },
    { codigo: 'BSAN', nombre: 'Banco Santander' },
    { codigo: 'BBCI', nombre: 'BCI' },
    { codigo: 'SCOT', nombre: 'Scotiabank' },
    { codigo: 'ITAU', nombre: 'Banco Itaú' },
    { codigo: 'BICE', nombre: 'Banco BICE' },
    { codigo: 'SECU', nombre: 'Banco Security' },
  ];

  const propositos = [
    { value: 'gastos_comunes', label: 'Gastos Comunes (Art. 40 Ley 21.442)', color: 'blue' },
    { value: 'arriendos', label: 'Arriendos (Art. 23 DS 7-2025)', color: 'green' },
    { value: 'fondo_reserva', label: 'Fondo de Reserva', color: 'purple' },
    { value: 'operacional', label: 'Operacional', color: 'gray' },
    { value: 'remuneraciones', label: 'Remuneraciones', color: 'orange' },
  ];

  const handleBancoChange = (codigo: string) => {
    const banco = bancos.find(b => b.codigo === codigo);
    setFormData({
      ...formData,
      banco_codigo: codigo,
      banco_nombre: banco?.nombre || '',
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/bancos/cuentas', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ ...formData, edificio_id: edificioId })
      });

      const data = await res.json();

      if (data.success) {
        onSuccess();
      } else {
        setError(data.message || 'Error al crear cuenta');
      }
    } catch (err) {
      setError('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-lg w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Nueva Cuenta Bancaria</h2>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Banco *</label>
            <select
              value={formData.banco_codigo}
              onChange={(e) => handleBancoChange(e.target.value)}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Seleccionar banco...</option>
              {bancos.map(b => (
                <option key={b.codigo} value={b.codigo}>{b.nombre}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Cuenta *</label>
              <select
                value={formData.tipo_cuenta}
                onChange={(e) => setFormData({...formData, tipo_cuenta: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              >
                <option value="corriente">Corriente</option>
                <option value="vista">Vista</option>
                <option value="ahorro">Ahorro</option>
                <option value="rut">Cuenta RUT</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">N° Cuenta *</label>
              <input
                type="text"
                value={formData.numero_cuenta}
                onChange={(e) => setFormData({...formData, numero_cuenta: e.target.value})}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Propósito *</label>
            <select
              value={formData.proposito}
              onChange={(e) => setFormData({...formData, proposito: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            >
              {propositos.map(p => (
                <option key={p.value} value={p.value}>{p.label}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">RUT Titular *</label>
              <input
                type="text"
                value={formData.rut_titular}
                onChange={(e) => setFormData({...formData, rut_titular: e.target.value})}
                required
                placeholder="12.345.678-9"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Saldo Inicial</label>
              <input
                type="number"
                value={formData.saldo_inicial}
                onChange={(e) => setFormData({...formData, saldo_inicial: Number(e.target.value)})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nombre Titular *</label>
            <input
              type="text"
              value={formData.nombre_titular}
              onChange={(e) => setFormData({...formData, nombre_titular: e.target.value})}
              required
              placeholder="Comunidad Edificio Central"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Creando...' : 'Crear Cuenta'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CuentasBancariasPage;
