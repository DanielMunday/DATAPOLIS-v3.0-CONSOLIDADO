import React, { useState, useEffect } from 'react';
import { 
  MapPin, Car, Megaphone, Store, Archive, Calendar, Handshake,
  Plus, Search, Filter, Eye, Edit, Clock, CheckCircle, XCircle,
  Building2, Users, DollarSign, TrendingUp
} from 'lucide-react';

// ============================================================================
// TIPOS
// ============================================================================

interface Categoria {
  id: number;
  codigo: string;
  nombre: string;
  descripcion: string;
  icono: string;
  color: string;
}

interface TipoEspacio {
  id: number;
  codigo: string;
  nombre: string;
  categoria_nombre: string;
  categoria_codigo: string;
  unidad_medida: string;
  permite_reserva: boolean;
}

interface Espacio {
  id: number;
  codigo: string;
  nombre: string;
  descripcion: string;
  ubicacion: string;
  tipo_nombre: string;
  categoria_nombre: string;
  categoria_color: string;
  estado: string;
  precio_base: number;
  periodo_precio: string;
  contrato_activo: {
    id: number;
    arrendatario: string;
    fecha_termino: string;
    monto_mensual: number;
  } | null;
}

interface Reserva {
  id: number;
  numero_reserva: string;
  fecha_reserva: string;
  hora_inicio: string | null;
  hora_fin: string | null;
  espacio_nombre: string;
  solicitante_nombre: string;
  monto_total: number;
  estado: string;
}

interface Edificio {
  id: number;
  nombre: string;
}

// ============================================================================
// ICONOS POR CATEGORÍA
// ============================================================================

const iconosCategoria: Record<string, React.FC<{className?: string}>> = {
  'TELECOM': (props) => <MapPin {...props} />,
  'ESTACIONAMIENTOS': (props) => <Car {...props} />,
  'PUBLICIDAD': (props) => <Megaphone {...props} />,
  'LOCALES': (props) => <Store {...props} />,
  'BODEGAS': (props) => <Archive {...props} />,
  'EVENTOS': (props) => <Calendar {...props} />,
  'CONCESIONES': (props) => <Handshake {...props} />,
};

// ============================================================================
// COMPONENTE PRINCIPAL
// ============================================================================

const EspaciosArrendablesPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'espacios' | 'reservas' | 'concesiones'>('espacios');
  const [edificios, setEdificios] = useState<Edificio[]>([]);
  const [selectedEdificio, setSelectedEdificio] = useState<number | null>(null);
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [selectedCategoria, setSelectedCategoria] = useState<string | null>(null);
  const [espacios, setEspacios] = useState<Espacio[]>([]);
  const [reservas, setReservas] = useState<Reserva[]>([]);
  const [stats, setStats] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [showCrearEspacio, setShowCrearEspacio] = useState(false);
  const [showCrearReserva, setShowCrearReserva] = useState(false);

  useEffect(() => {
    fetchEdificios();
    fetchCategorias();
  }, []);

  useEffect(() => {
    if (selectedEdificio) {
      fetchEspacios();
    }
  }, [selectedEdificio, selectedCategoria]);

  const fetchEdificios = async () => {
    try {
      const res = await fetch('/api/edificios', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setEdificios(data.data || []);
      if (data.data?.length > 0) {
        setSelectedEdificio(data.data[0].id);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchCategorias = async () => {
    try {
      const res = await fetch('/api/espacios/categorias', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setCategorias(data.data || []);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const fetchEspacios = async () => {
    if (!selectedEdificio) return;
    setLoading(true);
    try {
      let url = `/api/espacios?edificio_id=${selectedEdificio}`;
      if (selectedCategoria) {
        const cat = categorias.find(c => c.codigo === selectedCategoria);
        if (cat) url += `&categoria_id=${cat.id}`;
      }

      const res = await fetch(url, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setEspacios(data.data || []);
      setStats(data.stats || {});
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchReservas = async () => {
    if (!selectedEdificio) return;
    try {
      const res = await fetch(`/api/reservas?edificio_id=${selectedEdificio}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setReservas(data.data?.data || []);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const tabs = [
    { id: 'espacios', label: 'Espacios', icon: Building2 },
    { id: 'reservas', label: 'Reservas', icon: Calendar },
    { id: 'concesiones', label: 'Concesiones', icon: Handshake },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <MapPin className="w-7 h-7 text-green-600" />
              Espacios Arrendables
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              Gestión de estacionamientos, publicidad, locales, bodegas y concesiones
            </p>
          </div>
          
          <select
            value={selectedEdificio || ''}
            onChange={(e) => setSelectedEdificio(Number(e.target.value))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
          >
            <option value="">Seleccionar edificio...</option>
            {edificios.map(e => (
              <option key={e.id} value={e.id}>{e.nombre}</option>
            ))}
          </select>
        </div>

        {/* Tabs */}
        <div className="flex space-x-1 mt-4 border-b border-gray-200">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  if (tab.id === 'reservas') fetchReservas();
                }}
                className={`flex items-center gap-2 px-4 py-2 font-medium text-sm rounded-t-lg transition-colors
                  ${activeTab === tab.id 
                    ? 'bg-green-50 text-green-600 border-b-2 border-green-600' 
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'}`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Contenido */}
      <div className="p-6">
        {!selectedEdificio ? (
          <div className="bg-white rounded-lg shadow p-8 text-center">
            <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">Seleccione un edificio</h3>
            <p className="text-gray-500 mt-2">Para ver los espacios arrendables</p>
          </div>
        ) : (
          <>
            {activeTab === 'espacios' && (
              <EspaciosTab
                espacios={espacios}
                categorias={categorias}
                selectedCategoria={selectedCategoria}
                onSelectCategoria={setSelectedCategoria}
                stats={stats}
                loading={loading}
                onCrear={() => setShowCrearEspacio(true)}
                onRefresh={fetchEspacios}
              />
            )}
            {activeTab === 'reservas' && (
              <ReservasTab
                reservas={reservas}
                onCrear={() => setShowCrearReserva(true)}
                onRefresh={fetchReservas}
              />
            )}
            {activeTab === 'concesiones' && (
              <ConcesionesTab edificioId={selectedEdificio} />
            )}
          </>
        )}
      </div>

      {/* Modal Crear Espacio */}
      {showCrearEspacio && selectedEdificio && (
        <CrearEspacioModal
          edificioId={selectedEdificio}
          categorias={categorias}
          onClose={() => setShowCrearEspacio(false)}
          onSuccess={() => {
            setShowCrearEspacio(false);
            fetchEspacios();
          }}
        />
      )}
    </div>
  );
};

// ============================================================================
// TAB: ESPACIOS
// ============================================================================

interface EspaciosTabProps {
  espacios: Espacio[];
  categorias: Categoria[];
  selectedCategoria: string | null;
  onSelectCategoria: (cat: string | null) => void;
  stats: any;
  loading: boolean;
  onCrear: () => void;
  onRefresh: () => void;
}

const EspaciosTab: React.FC<EspaciosTabProps> = ({
  espacios, categorias, selectedCategoria, onSelectCategoria, stats, loading, onCrear, onRefresh
}) => {
  const formatMonto = (monto: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(monto);
  };

  const getEstadoColor = (estado: string) => {
    const colores: Record<string, string> = {
      'disponible': 'bg-green-100 text-green-800',
      'arrendado': 'bg-blue-100 text-blue-800',
      'reservado': 'bg-yellow-100 text-yellow-800',
      'mantencion': 'bg-orange-100 text-orange-800',
      'no_disponible': 'bg-gray-100 text-gray-800',
    };
    return colores[estado] || 'bg-gray-100 text-gray-800';
  };

  const getEstadoIcon = (estado: string) => {
    switch (estado) {
      case 'disponible': return <CheckCircle className="w-3 h-3" />;
      case 'arrendado': return <Users className="w-3 h-3" />;
      case 'reservado': return <Clock className="w-3 h-3" />;
      default: return <XCircle className="w-3 h-3" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Espacios</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total || 0}</p>
            </div>
            <MapPin className="w-10 h-10 text-gray-400" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Disponibles</p>
              <p className="text-2xl font-bold text-green-600">{stats.disponibles || 0}</p>
            </div>
            <CheckCircle className="w-10 h-10 text-green-500" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Arrendados</p>
              <p className="text-2xl font-bold text-blue-600">{stats.arrendados || 0}</p>
            </div>
            <Users className="w-10 h-10 text-blue-500" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Ocupación</p>
              <p className="text-2xl font-bold text-purple-600">
                {stats.total > 0 ? Math.round((stats.arrendados / stats.total) * 100) : 0}%
              </p>
            </div>
            <TrendingUp className="w-10 h-10 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Filtros por Categoría */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-gray-900">Filtrar por Categoría</h3>
          <button
            onClick={onCrear}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          >
            <Plus className="w-4 h-4" />
            Nuevo Espacio
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => onSelectCategoria(null)}
            className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors
              ${!selectedCategoria 
                ? 'bg-gray-900 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
          >
            Todos
          </button>
          {categorias.map(cat => {
            const IconComponent = iconosCategoria[cat.codigo] || MapPin;
            return (
              <button
                key={cat.codigo}
                onClick={() => onSelectCategoria(cat.codigo)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium transition-colors
                  ${selectedCategoria === cat.codigo 
                    ? 'bg-green-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
              >
                <IconComponent className="w-3.5 h-3.5" />
                {cat.nombre}
              </button>
            );
          })}
        </div>
      </div>

      {/* Lista de Espacios */}
      {loading ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <div className="animate-spin w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full mx-auto"></div>
          <p className="text-gray-500 mt-2">Cargando espacios...</p>
        </div>
      ) : espacios.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900">Sin espacios registrados</h3>
          <p className="text-gray-500 mt-2">Comience agregando espacios arrendables</p>
          <button
            onClick={onCrear}
            className="mt-4 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          >
            Crear primer espacio
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {espacios.map((espacio) => {
            const IconComponent = iconosCategoria[espacio.categoria_nombre?.toUpperCase()] || MapPin;
            return (
              <div
                key={espacio.id}
                className="bg-white rounded-lg shadow hover:shadow-md transition-shadow"
              >
                <div className="p-5">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg bg-${espacio.categoria_color || 'gray'}-100`}>
                        <IconComponent className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{espacio.nombre}</h3>
                        <p className="text-sm text-gray-500">{espacio.codigo}</p>
                      </div>
                    </div>
                    <span className={`flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full ${getEstadoColor(espacio.estado)}`}>
                      {getEstadoIcon(espacio.estado)}
                      {espacio.estado}
                    </span>
                  </div>

                  <div className="mt-4 space-y-2">
                    <div className="flex items-center text-sm text-gray-600">
                      <span className="font-medium w-24">Tipo:</span>
                      <span>{espacio.tipo_nombre}</span>
                    </div>
                    {espacio.ubicacion && (
                      <div className="flex items-center text-sm text-gray-600">
                        <span className="font-medium w-24">Ubicación:</span>
                        <span>{espacio.ubicacion}</span>
                      </div>
                    )}
                    {espacio.precio_base > 0 && (
                      <div className="flex items-center text-sm text-gray-600">
                        <span className="font-medium w-24">Precio:</span>
                        <span className="font-semibold text-green-600">
                          {formatMonto(espacio.precio_base)} / {espacio.periodo_precio}
                        </span>
                      </div>
                    )}
                  </div>

                  {espacio.contrato_activo && (
                    <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                      <p className="text-xs text-blue-600 font-medium mb-1">Contrato Activo</p>
                      <p className="text-sm text-gray-900">{espacio.contrato_activo.arrendatario}</p>
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>Hasta: {new Date(espacio.contrato_activo.fecha_termino).toLocaleDateString('es-CL')}</span>
                        <span>{formatMonto(espacio.contrato_activo.monto_mensual)}/mes</span>
                      </div>
                    </div>
                  )}

                  <div className="mt-4 flex gap-2">
                    <button className="flex-1 flex items-center justify-center gap-1 px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Eye className="w-4 h-4" />
                      Ver
                    </button>
                    <button className="flex-1 flex items-center justify-center gap-1 px-3 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Edit className="w-4 h-4" />
                      Editar
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

// ============================================================================
// TAB: RESERVAS
// ============================================================================

interface ReservasTabProps {
  reservas: Reserva[];
  onCrear: () => void;
  onRefresh: () => void;
}

const ReservasTab: React.FC<ReservasTabProps> = ({ reservas, onCrear, onRefresh }) => {
  const formatMonto = (monto: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(monto);
  };

  const getEstadoColor = (estado: string) => {
    const colores: Record<string, string> = {
      'pendiente': 'bg-yellow-100 text-yellow-800',
      'confirmada': 'bg-blue-100 text-blue-800',
      'pagada': 'bg-green-100 text-green-800',
      'en_uso': 'bg-purple-100 text-purple-800',
      'finalizada': 'bg-gray-100 text-gray-800',
      'cancelada': 'bg-red-100 text-red-800',
    };
    return colores[estado] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-900">Reservas de Espacios</h2>
        <button
          onClick={onCrear}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          <Plus className="w-4 h-4" />
          Nueva Reserva
        </button>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">N° Reserva</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Espacio</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Horario</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Solicitante</th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Monto</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Estado</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {reservas.map((r) => (
              <tr key={r.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-medium text-gray-900">{r.numero_reserva}</td>
                <td className="px-4 py-3 text-sm text-gray-900">{r.espacio_nombre}</td>
                <td className="px-4 py-3 text-sm text-gray-500">
                  {new Date(r.fecha_reserva).toLocaleDateString('es-CL')}
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">
                  {r.hora_inicio && r.hora_fin ? `${r.hora_inicio} - ${r.hora_fin}` : 'Todo el día'}
                </td>
                <td className="px-4 py-3 text-sm text-gray-900">{r.solicitante_nombre}</td>
                <td className="px-4 py-3 text-sm text-right font-medium text-gray-900">
                  {formatMonto(r.monto_total)}
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getEstadoColor(r.estado)}`}>
                    {r.estado}
                  </span>
                </td>
                <td className="px-4 py-3 text-center">
                  <button className="text-blue-600 hover:text-blue-800 text-sm">Ver</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {reservas.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            No hay reservas registradas
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// TAB: CONCESIONES
// ============================================================================

interface ConcesionesTabProps {
  edificioId: number;
}

const ConcesionesTab: React.FC<ConcesionesTabProps> = ({ edificioId }) => {
  const [concesiones, setConcesiones] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchConcesiones();
  }, [edificioId]);

  const fetchConcesiones = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/concesiones?edificio_id=${edificioId}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setConcesiones(data.data?.data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatMonto = (monto: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(monto);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-900">Contratos de Concesión</h2>
        <button className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
          <Plus className="w-4 h-4" />
          Nueva Concesión
        </button>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">N° Contrato</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipo</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Concesionario</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Espacio</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Vigencia</th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Monto Mensual</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Estado</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {concesiones.map((c) => (
              <tr key={c.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-medium text-gray-900">{c.numero_contrato}</td>
                <td className="px-4 py-3 text-sm text-gray-900">{c.tipo_concesion}</td>
                <td className="px-4 py-3 text-sm text-gray-900">{c.concesionario_nombre}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{c.espacio_nombre}</td>
                <td className="px-4 py-3 text-sm text-gray-500">
                  {new Date(c.fecha_inicio).toLocaleDateString('es-CL')} - {new Date(c.fecha_termino).toLocaleDateString('es-CL')}
                </td>
                <td className="px-4 py-3 text-sm text-right font-medium text-gray-900">
                  {formatMonto(c.monto_fijo_mensual || 0)}
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full
                    ${c.estado === 'vigente' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                    {c.estado}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {concesiones.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            No hay concesiones registradas
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// MODAL: CREAR ESPACIO
// ============================================================================

interface CrearEspacioModalProps {
  edificioId: number;
  categorias: Categoria[];
  onClose: () => void;
  onSuccess: () => void;
}

const CrearEspacioModal: React.FC<CrearEspacioModalProps> = ({ edificioId, categorias, onClose, onSuccess }) => {
  const [tipos, setTipos] = useState<TipoEspacio[]>([]);
  const [formData, setFormData] = useState({
    tipo_espacio_id: '',
    codigo: '',
    nombre: '',
    descripcion: '',
    ubicacion: '',
    precio_base: '',
    periodo_precio: 'mes',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchTipos();
  }, []);

  const fetchTipos = async () => {
    try {
      const res = await fetch('/api/espacios/tipos', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      setTipos(data.data || []);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/espacios', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          ...formData,
          edificio_id: edificioId,
          precio_base: formData.precio_base ? Number(formData.precio_base) : null,
          tipo_espacio_id: Number(formData.tipo_espacio_id),
        })
      });

      const data = await res.json();

      if (data.success) {
        onSuccess();
      } else {
        setError(data.message || 'Error al crear espacio');
      }
    } catch (err) {
      setError('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  // Agrupar tipos por categoría
  const tiposPorCategoria = tipos.reduce((acc, tipo) => {
    if (!acc[tipo.categoria_nombre]) {
      acc[tipo.categoria_nombre] = [];
    }
    acc[tipo.categoria_nombre].push(tipo);
    return acc;
  }, {} as Record<string, TipoEspacio[]>);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-lg w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Nuevo Espacio Arrendable</h2>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Espacio *</label>
            <select
              value={formData.tipo_espacio_id}
              onChange={(e) => setFormData({...formData, tipo_espacio_id: e.target.value})}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
            >
              <option value="">Seleccionar tipo...</option>
              {Object.entries(tiposPorCategoria).map(([categoria, tipos]) => (
                <optgroup key={categoria} label={categoria}>
                  {tipos.map(tipo => (
                    <option key={tipo.id} value={tipo.id}>{tipo.nombre}</option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Código *</label>
              <input
                type="text"
                value={formData.codigo}
                onChange={(e) => setFormData({...formData, codigo: e.target.value.toUpperCase()})}
                required
                placeholder="EST-001"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nombre *</label>
              <input
                type="text"
                value={formData.nombre}
                onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                required
                placeholder="Estacionamiento Visita 1"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Ubicación</label>
            <input
              type="text"
              value={formData.ubicacion}
              onChange={(e) => setFormData({...formData, ubicacion: e.target.value})}
              placeholder="Subterráneo -1"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
            <textarea
              value={formData.descripcion}
              onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Precio Base</label>
              <input
                type="number"
                value={formData.precio_base}
                onChange={(e) => setFormData({...formData, precio_base: e.target.value})}
                placeholder="50000"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Período</label>
              <select
                value={formData.periodo_precio}
                onChange={(e) => setFormData({...formData, periodo_precio: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              >
                <option value="hora">Por Hora</option>
                <option value="dia">Por Día</option>
                <option value="semana">Por Semana</option>
                <option value="mes">Por Mes</option>
                <option value="anio">Por Año</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
            >
              {loading ? 'Creando...' : 'Crear Espacio'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EspaciosArrendablesPage;
