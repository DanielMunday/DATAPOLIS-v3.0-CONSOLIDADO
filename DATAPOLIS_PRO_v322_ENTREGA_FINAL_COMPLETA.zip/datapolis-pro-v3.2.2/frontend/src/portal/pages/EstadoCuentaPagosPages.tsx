// ============================================================
// src/portal/pages/EstadoCuentaPage.tsx
// ============================================================
import React, { useEffect, useState } from 'react';
import { portalApi } from '../services/api';
import {
  DocumentArrowDownIcon,
  DocumentCheckIcon,
  ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';

interface Boleta {
  id: number;
  periodo: string;
  total_a_pagar: number;
  total_abonos: number;
  saldo_pendiente: number;
  interes_mora: number;
  estado: string;
  fecha_vencimiento: string;
  dias_mora: number;
}

interface EstadoCuentaData {
  resumen: {
    total_pendiente: number;
    total_vencido: number;
    total_intereses: number;
    boletas_pendientes: number;
    boletas_vencidas: number;
  };
  boletas_pendientes: Boleta[];
  resumen_anual: Array<{
    anio: number;
    total_emitido: number;
    total_pagado: number;
    saldo: number;
  }>;
}

export default function EstadoCuentaPage() {
  const [data, setData] = useState<EstadoCuentaData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedBoletas, setSelectedBoletas] = useState<number[]>([]);

  useEffect(() => {
    loadEstadoCuenta();
  }, []);

  const loadEstadoCuenta = async () => {
    try {
      const response = await portalApi.get('/estado-cuenta');
      setData(response.data.data);
    } catch (error) {
      console.error('Error loading estado cuenta:', error);
    } finally {
      setLoading(false);
    }
  };

  const downloadPdf = async () => {
    try {
      const response = await portalApi.get('/estado-cuenta/pdf', { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `estado-cuenta-${new Date().toISOString().split('T')[0]}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error('Error downloading PDF:', error);
    }
  };

  const downloadBoletaPdf = async (boletaId: number) => {
    try {
      const response = await portalApi.get(`/estado-cuenta/boleta/${boletaId}/pdf`, { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `boleta-${boletaId}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error('Error downloading boleta PDF:', error);
    }
  };

  const downloadCertificado = async () => {
    try {
      const response = await portalApi.get('/estado-cuenta/certificado-no-deuda', { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `certificado-no-deuda.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error: any) {
      if (error.response?.status === 400) {
        alert('No es posible emitir certificado de no deuda. Tiene saldo pendiente.');
      }
    }
  };

  const toggleBoleta = (id: number) => {
    setSelectedBoletas((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const formatMoney = (amount: number) =>
    new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(amount);

  if (loading) {
    return <div className="flex justify-center py-12">Cargando...</div>;
  }

  if (!data) return null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Estado de Cuenta</h1>
        <div className="flex gap-2">
          <button
            onClick={downloadPdf}
            className="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50"
          >
            <DocumentArrowDownIcon className="w-5 h-5 mr-2" />
            Descargar PDF
          </button>
          <button
            onClick={downloadCertificado}
            className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700"
          >
            <DocumentCheckIcon className="w-5 h-5 mr-2" />
            Certificado No Deuda
          </button>
        </div>
      </div>

      {/* Resumen */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className={`bg-white rounded-xl shadow-sm border p-6 ${data.resumen.total_pendiente > 0 ? 'border-l-4 border-l-red-500' : 'border-l-4 border-l-green-500'}`}>
          <p className="text-sm text-gray-600">Total Pendiente</p>
          <p className={`text-3xl font-bold ${data.resumen.total_pendiente > 0 ? 'text-red-600' : 'text-green-600'}`}>
            {formatMoney(data.resumen.total_pendiente)}
          </p>
          <p className="text-sm text-gray-500 mt-1">
            {data.resumen.boletas_pendientes} boleta(s) pendiente(s)
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border p-6">
          <p className="text-sm text-gray-600">Total Vencido</p>
          <p className="text-3xl font-bold text-orange-600">
            {formatMoney(data.resumen.total_vencido)}
          </p>
          <p className="text-sm text-gray-500 mt-1">
            {data.resumen.boletas_vencidas} boleta(s) vencida(s)
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border p-6">
          <p className="text-sm text-gray-600">Intereses por Mora</p>
          <p className="text-3xl font-bold text-gray-900">
            {formatMoney(data.resumen.total_intereses)}
          </p>
        </div>
      </div>

      {/* Boletas Pendientes */}
      {data.boletas_pendientes.length > 0 ? (
        <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
          <div className="p-4 border-b bg-gray-50">
            <h2 className="text-lg font-semibold text-gray-900">Boletas Pendientes</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Seleccionar</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Período</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Abonos</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Saldo</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Estado</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Vencimiento</th>
                  <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {data.boletas_pendientes.map((boleta) => (
                  <tr key={boleta.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={selectedBoletas.includes(boleta.id)}
                        onChange={() => toggleBoleta(boleta.id)}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                    </td>
                    <td className="px-4 py-3 font-medium text-gray-900">{boleta.periodo}</td>
                    <td className="px-4 py-3 text-right text-gray-900">{formatMoney(boleta.total_a_pagar)}</td>
                    <td className="px-4 py-3 text-right text-gray-500">{formatMoney(boleta.total_abonos)}</td>
                    <td className="px-4 py-3 text-right font-semibold text-gray-900">{formatMoney(boleta.saldo_pendiente)}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        boleta.estado === 'vencida' 
                          ? 'bg-red-100 text-red-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {boleta.estado === 'vencida' && <ExclamationTriangleIcon className="w-3 h-3 mr-1" />}
                        {boleta.estado.toUpperCase()}
                        {boleta.dias_mora > 0 && ` (${boleta.dias_mora}d)`}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center text-sm text-gray-500">
                      {new Date(boleta.fecha_vencimiento).toLocaleDateString('es-CL')}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        onClick={() => downloadBoletaPdf(boleta.id)}
                        className="text-blue-600 hover:text-blue-800"
                        title="Descargar PDF"
                      >
                        <DocumentArrowDownIcon className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {selectedBoletas.length > 0 && (
            <div className="p-4 bg-blue-50 border-t flex items-center justify-between">
              <span className="text-sm text-gray-700">
                {selectedBoletas.length} boleta(s) seleccionada(s) - Total:{' '}
                <strong>
                  {formatMoney(
                    data.boletas_pendientes
                      .filter((b) => selectedBoletas.includes(b.id))
                      .reduce((sum, b) => sum + b.saldo_pendiente, 0)
                  )}
                </strong>
              </span>
              <a
                href={`/portal/pagos?boletas=${selectedBoletas.join(',')}`}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"
              >
                Pagar Seleccionadas
              </a>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-green-50 rounded-xl p-8 text-center">
          <DocumentCheckIcon className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-green-800">¡Felicitaciones!</h3>
          <p className="text-green-700">No tienes boletas pendientes de pago.</p>
        </div>
      )}

      {/* Resumen Anual */}
      {data.resumen_anual.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
          <div className="p-4 border-b bg-gray-50">
            <h2 className="text-lg font-semibold text-gray-900">Resumen por Año</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Año</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Emitido</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Pagado</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Saldo</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {data.resumen_anual.map((anio) => (
                  <tr key={anio.anio} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">{anio.anio}</td>
                    <td className="px-4 py-3 text-right text-gray-900">{formatMoney(anio.total_emitido)}</td>
                    <td className="px-4 py-3 text-right text-green-600">{formatMoney(anio.total_pagado)}</td>
                    <td className="px-4 py-3 text-right font-semibold text-gray-900">{formatMoney(anio.saldo)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}


// ============================================================
// src/portal/pages/PagosPage.tsx
// ============================================================
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { portalApi } from '../services/api';
import {
  CreditCardIcon,
  BanknotesIcon,
  CheckCircleIcon,
  XCircleIcon,
} from '@heroicons/react/24/outline';

interface Pasarela {
  id: string;
  nombre: string;
  descripcion: string;
  monto_minimo: number;
  monto_maximo: number;
}

interface BoletaPendiente {
  id: number;
  periodo: string;
  saldo: number;
  estado: string;
  vencimiento: string;
}

interface PagosData {
  pasarelas: Pasarela[];
  boletas_pendientes: BoletaPendiente[];
  total_pendiente: number;
}

export default function PagosPage() {
  const [searchParams] = useSearchParams();
  const [data, setData] = useState<PagosData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedBoletas, setSelectedBoletas] = useState<number[]>([]);
  const [selectedPasarela, setSelectedPasarela] = useState<string>('');
  const [procesando, setProcesando] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadOpciones();
  }, []);

  useEffect(() => {
    const boletasParam = searchParams.get('boletas');
    if (boletasParam) {
      setSelectedBoletas(boletasParam.split(',').map(Number));
    }
  }, [searchParams]);

  const loadOpciones = async () => {
    try {
      const response = await portalApi.get('/pagos/opciones');
      setData(response.data.data);
      
      // Seleccionar primera pasarela por defecto
      if (response.data.data.pasarelas.length > 0) {
        setSelectedPasarela(response.data.data.pasarelas[0].id);
      }
    } catch (error) {
      console.error('Error loading opciones:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleBoleta = (id: number) => {
    setSelectedBoletas((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    if (data) {
      setSelectedBoletas(data.boletas_pendientes.map((b) => b.id));
    }
  };

  const calcularTotal = () => {
    if (!data) return 0;
    return data.boletas_pendientes
      .filter((b) => selectedBoletas.includes(b.id))
      .reduce((sum, b) => sum + b.saldo, 0);
  };

  const iniciarPago = async () => {
    if (selectedBoletas.length === 0) {
      setError('Seleccione al menos una boleta');
      return;
    }

    if (!selectedPasarela) {
      setError('Seleccione un método de pago');
      return;
    }

    setError('');
    setProcesando(true);

    try {
      const response = await portalApi.post('/pagos/iniciar', {
        pasarela: selectedPasarela,
        boletas_ids: selectedBoletas,
      });

      if (response.data.success) {
        // Redirigir a la pasarela de pago
        window.location.href = response.data.data.url_pago;
      } else {
        setError(response.data.message || 'Error al iniciar el pago');
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Error al procesar el pago');
    } finally {
      setProcesando(false);
    }
  };

  const formatMoney = (amount: number) =>
    new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(amount);

  if (loading) {
    return <div className="flex justify-center py-12">Cargando...</div>;
  }

  if (!data) return null;

  if (data.boletas_pendientes.length === 0) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-green-50 rounded-xl p-8 text-center">
          <CheckCircleIcon className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-green-800">Sin Saldo Pendiente</h3>
          <p className="text-green-700">No tienes boletas pendientes de pago.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Pagar Online</h1>

      {error && (
        <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg flex items-center">
          <XCircleIcon className="w-5 h-5 mr-2" />
          {error}
        </div>
      )}

      {/* Selección de Boletas */}
      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Seleccionar Boletas a Pagar</h2>
          <button
            onClick={selectAll}
            className="text-sm text-blue-600 hover:underline"
          >
            Seleccionar todas
          </button>
        </div>
        <div className="divide-y divide-gray-200">
          {data.boletas_pendientes.map((boleta) => (
            <label
              key={boleta.id}
              className={`flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50 ${
                selectedBoletas.includes(boleta.id) ? 'bg-blue-50' : ''
              }`}
            >
              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={selectedBoletas.includes(boleta.id)}
                  onChange={() => toggleBoleta(boleta.id)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-4"
                />
                <div>
                  <p className="font-medium text-gray-900">Período {boleta.periodo}</p>
                  <p className="text-sm text-gray-500">
                    Vencimiento: {new Date(boleta.vencimiento).toLocaleDateString('es-CL')}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-gray-900">{formatMoney(boleta.saldo)}</p>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  boleta.estado === 'vencida' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {boleta.estado.toUpperCase()}
                </span>
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Método de Pago */}
      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-gray-50">
          <h2 className="text-lg font-semibold text-gray-900">Método de Pago</h2>
        </div>
        <div className="p-4 space-y-3">
          {data.pasarelas.map((pasarela) => (
            <label
              key={pasarela.id}
              className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
                selectedPasarela === pasarela.id
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="radio"
                name="pasarela"
                value={pasarela.id}
                checked={selectedPasarela === pasarela.id}
                onChange={(e) => setSelectedPasarela(e.target.value)}
                className="sr-only"
              />
              <div className="mr-4">
                {pasarela.id === 'webpay' ? (
                  <CreditCardIcon className="w-8 h-8 text-blue-600" />
                ) : (
                  <BanknotesIcon className="w-8 h-8 text-green-600" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">{pasarela.nombre}</p>
                <p className="text-sm text-gray-500">{pasarela.descripcion}</p>
              </div>
              <div className={`w-5 h-5 rounded-full border-2 ${
                selectedPasarela === pasarela.id
                  ? 'border-blue-500 bg-blue-500'
                  : 'border-gray-300'
              }`}>
                {selectedPasarela === pasarela.id && (
                  <svg className="w-full h-full text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                )}
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Resumen y Botón de Pago */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-sm text-gray-600">Total a Pagar</p>
            <p className="text-3xl font-bold text-gray-900">{formatMoney(calcularTotal())}</p>
            <p className="text-sm text-gray-500">{selectedBoletas.length} boleta(s) seleccionada(s)</p>
          </div>
        </div>
        
        <button
          onClick={iniciarPago}
          disabled={procesando || selectedBoletas.length === 0}
          className="w-full py-4 px-6 bg-blue-600 text-white text-lg font-semibold rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {procesando ? 'Procesando...' : 'Pagar Ahora'}
        </button>
        
        <p className="mt-4 text-xs text-center text-gray-500">
          Al continuar, serás redirigido a la plataforma de pago segura.
        </p>
      </div>
    </div>
  );
}


// ============================================================
// src/portal/pages/ResultadoPagoPage.tsx
// ============================================================
import React, { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { portalApi } from '../services/api';
import {
  CheckCircleIcon,
  XCircleIcon,
  ExclamationCircleIcon,
  ArrowDownTrayIcon,
} from '@heroicons/react/24/outline';

export default function ResultadoPagoPage() {
  const [searchParams] = useSearchParams();
  const status = searchParams.get('status');
  const codigo = searchParams.get('codigo');
  const [transaccion, setTransaccion] = useState<any>(null);

  useEffect(() => {
    if (codigo) {
      loadTransaccion();
    }
  }, [codigo]);

  const loadTransaccion = async () => {
    try {
      const response = await portalApi.get(`/pagos/estado/${codigo}`);
      setTransaccion(response.data.data);
    } catch (error) {
      console.error('Error loading transaccion:', error);
    }
  };

  const downloadComprobante = async () => {
    try {
      const response = await portalApi.get(`/pagos/comprobante/${codigo}`, { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `comprobante-${codigo}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error('Error downloading comprobante:', error);
    }
  };

  const formatMoney = (amount: number) =>
    new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(amount);

  const renderContent = () => {
    switch (status) {
      case 'aprobado':
        return (
          <div className="text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircleIcon className="w-12 h-12 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">¡Pago Exitoso!</h1>
            <p className="text-gray-600 mb-6">Tu pago ha sido procesado correctamente.</p>
            
            {transaccion && (
              <div className="bg-gray-50 rounded-lg p-4 mb-6 text-left">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Código</p>
                    <p className="font-medium">{transaccion.codigo}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Monto</p>
                    <p className="font-medium text-green-600">{formatMoney(transaccion.monto)}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Fecha</p>
                    <p className="font-medium">
                      {new Date(transaccion.fecha_completada).toLocaleString('es-CL')}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500">Método</p>
                    <p className="font-medium uppercase">{transaccion.pasarela}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-3">
              <button
                onClick={downloadComprobante}
                className="w-full inline-flex items-center justify-center px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <ArrowDownTrayIcon className="w-5 h-5 mr-2" />
                Descargar Comprobante
              </button>
              <Link
                to="/portal/dashboard"
                className="block w-full px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Volver al Inicio
              </Link>
            </div>
          </div>
        );

      case 'rechazado':
        return (
          <div className="text-center">
            <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <XCircleIcon className="w-12 h-12 text-red-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Pago Rechazado</h1>
            <p className="text-gray-600 mb-6">
              El pago no pudo ser procesado. Verifica los datos de tu tarjeta e intenta nuevamente.
            </p>
            <div className="space-y-3">
              <Link
                to="/portal/pagos"
                className="block w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Intentar Nuevamente
              </Link>
              <Link
                to="/portal/dashboard"
                className="block w-full px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Volver al Inicio
              </Link>
            </div>
          </div>
        );

      case 'anulado':
      case 'cancelado':
        return (
          <div className="text-center">
            <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <ExclamationCircleIcon className="w-12 h-12 text-yellow-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Pago Cancelado</h1>
            <p className="text-gray-600 mb-6">El proceso de pago fue cancelado.</p>
            <div className="space-y-3">
              <Link
                to="/portal/pagos"
                className="block w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Volver a Pagar
              </Link>
              <Link
                to="/portal/dashboard"
                className="block w-full px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Volver al Inicio
              </Link>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <ExclamationCircleIcon className="w-12 h-12 text-gray-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Estado Desconocido</h1>
            <p className="text-gray-600 mb-6">No pudimos determinar el estado de tu pago.</p>
            <Link
              to="/portal/dashboard"
              className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Volver al Inicio
            </Link>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full">
        {renderContent()}
      </div>
    </div>
  );
}
