// ============================================================
// DATAPOLIS PRO v3.0 - Portal Copropietarios Frontend
// React + TypeScript + Tailwind CSS
// ============================================================

// src/portal/App.tsx
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import PortalLayout from './layouts/PortalLayout';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import EstadoCuentaPage from './pages/EstadoCuentaPage';
import PagosPage from './pages/PagosPage';
import SolicitudesPage from './pages/SolicitudesPage';
import DocumentosPage from './pages/DocumentosPage';
import ComunicadosPage from './pages/ComunicadosPage';
import ReservasPage from './pages/ReservasPage';
import VotacionesPage from './pages/VotacionesPage';
import PerfilPage from './pages/PerfilPage';
import ResultadoPagoPage from './pages/ResultadoPagoPage';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  
  if (loading) return <div className="flex items-center justify-center h-screen">Cargando...</div>;
  if (!isAuthenticated) return <Navigate to="/portal/login" replace />;
  
  return <>{children}</>;
};

export default function PortalApp() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/portal/login" element={<LoginPage />} />
          <Route path="/portal/pagos/resultado" element={<ResultadoPagoPage />} />
          
          <Route path="/portal" element={
            <ProtectedRoute>
              <PortalLayout />
            </ProtectedRoute>
          }>
            <Route index element={<Navigate to="/portal/dashboard" replace />} />
            <Route path="dashboard" element={<DashboardPage />} />
            <Route path="estado-cuenta" element={<EstadoCuentaPage />} />
            <Route path="pagos" element={<PagosPage />} />
            <Route path="solicitudes/*" element={<SolicitudesPage />} />
            <Route path="documentos" element={<DocumentosPage />} />
            <Route path="comunicados" element={<ComunicadosPage />} />
            <Route path="reservas" element={<ReservasPage />} />
            <Route path="votaciones/*" element={<VotacionesPage />} />
            <Route path="perfil" element={<PerfilPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}


// ============================================================
// src/portal/contexts/AuthContext.tsx
// ============================================================
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { portalApi } from '../services/api';

interface User {
  id: number;
  email: string;
  nombre: string;
  unidad: {
    id: number;
    numero: string;
    tipo: string;
    edificio: string;
    direccion: string;
  };
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('portal_token');
    const savedUser = localStorage.getItem('portal_user');
    
    if (token && savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    const response = await portalApi.post('/login', { email, password });
    
    if (response.data.success) {
      const { token, copropietario, unidad } = response.data;
      
      localStorage.setItem('portal_token', token);
      
      const userData: User = {
        id: copropietario.id,
        email: copropietario.email,
        nombre: copropietario.nombre,
        unidad: {
          id: unidad.id,
          numero: unidad.numero,
          tipo: unidad.tipo,
          edificio: unidad.edificio,
          direccion: unidad.direccion,
        },
      };
      
      localStorage.setItem('portal_user', JSON.stringify(userData));
      setUser(userData);
    } else {
      throw new Error(response.data.message || 'Error al iniciar sesión');
    }
  };

  const logout = async () => {
    try {
      await portalApi.post('/logout');
    } catch (e) {
      // Ignorar errores de logout
    }
    
    localStorage.removeItem('portal_token');
    localStorage.removeItem('portal_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};


// ============================================================
// src/portal/services/api.ts
// ============================================================
import axios from 'axios';

const BASE_URL = import.meta.env.VITE_API_URL || '/api/portal';

export const portalApi = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

portalApi.interceptors.request.use((config) => {
  const token = localStorage.getItem('portal_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

portalApi.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('portal_token');
      localStorage.removeItem('portal_user');
      window.location.href = '/portal/login';
    }
    return Promise.reject(error);
  }
);


// ============================================================
// src/portal/layouts/PortalLayout.tsx
// ============================================================
import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import {
  HomeIcon,
  DocumentTextIcon,
  CreditCardIcon,
  ChatBubbleLeftRightIcon,
  FolderIcon,
  MegaphoneIcon,
  CalendarIcon,
  HandRaisedIcon,
  UserCircleIcon,
  ArrowRightOnRectangleIcon,
  Bars3Icon,
  XMarkIcon,
  BellIcon,
} from '@heroicons/react/24/outline';

const navigation = [
  { name: 'Dashboard', href: '/portal/dashboard', icon: HomeIcon },
  { name: 'Estado de Cuenta', href: '/portal/estado-cuenta', icon: DocumentTextIcon },
  { name: 'Pagar Online', href: '/portal/pagos', icon: CreditCardIcon },
  { name: 'Mis Solicitudes', href: '/portal/solicitudes', icon: ChatBubbleLeftRightIcon },
  { name: 'Documentos', href: '/portal/documentos', icon: FolderIcon },
  { name: 'Comunicados', href: '/portal/comunicados', icon: MegaphoneIcon },
  { name: 'Reservas', href: '/portal/reservas', icon: CalendarIcon },
  { name: 'Votaciones', href: '/portal/votaciones', icon: HandRaisedIcon },
];

export default function PortalLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/portal/login');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between h-16 px-4 bg-blue-600">
            <span className="text-xl font-bold text-white">Portal Vecino</span>
            <button className="lg:hidden text-white" onClick={() => setSidebarOpen(false)}>
              <XMarkIcon className="w-6 h-6" />
            </button>
          </div>

          {/* User info */}
          <div className="p-4 border-b bg-blue-50">
            <p className="font-medium text-gray-900">{user?.nombre}</p>
            <p className="text-sm text-gray-600">{user?.unidad.tipo} {user?.unidad.numero}</p>
            <p className="text-xs text-gray-500">{user?.unidad.edificio}</p>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
            {navigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) =>
                  `flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`
                }
                onClick={() => setSidebarOpen(false)}
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.name}
              </NavLink>
            ))}
          </nav>

          {/* Footer actions */}
          <div className="p-4 border-t">
            <NavLink
              to="/portal/perfil"
              className="flex items-center px-3 py-2 text-sm text-gray-700 rounded-lg hover:bg-gray-100"
            >
              <UserCircleIcon className="w-5 h-5 mr-3" />
              Mi Perfil
            </NavLink>
            <button
              onClick={handleLogout}
              className="flex items-center w-full px-3 py-2 text-sm text-red-600 rounded-lg hover:bg-red-50"
            >
              <ArrowRightOnRectangleIcon className="w-5 h-5 mr-3" />
              Cerrar Sesión
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Top bar */}
        <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 bg-white shadow-sm">
          <button
            className="lg:hidden p-2 rounded-md hover:bg-gray-100"
            onClick={() => setSidebarOpen(true)}
          >
            <Bars3Icon className="w-6 h-6" />
          </button>

          <div className="flex items-center space-x-4">
            <button className="relative p-2 rounded-full hover:bg-gray-100">
              <BellIcon className="w-6 h-6 text-gray-600" />
              <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}


// ============================================================
// src/portal/pages/LoginPage.tsx
// ============================================================
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(email, password);
      navigate('/portal/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Error al iniciar sesión');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-blue-800 px-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Portal Vecino</h1>
            <p className="text-gray-600 mt-2">Accede a tu cuenta de copropietario</p>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Correo electrónico
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="tu@email.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Contraseña
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="••••••••"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {loading ? 'Ingresando...' : 'Ingresar'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <a href="#" className="text-sm text-blue-600 hover:underline">
              ¿Olvidaste tu contraseña?
            </a>
          </div>

          <div className="mt-4 text-center">
            <p className="text-sm text-gray-600">
              ¿No tienes cuenta?{' '}
              <a href="#" className="text-blue-600 hover:underline">
                Regístrate aquí
              </a>
            </p>
          </div>
        </div>

        <p className="text-center text-white text-sm mt-6 opacity-75">
          Powered by DATAPOLIS PRO
        </p>
      </div>
    </div>
  );
}


// ============================================================
// src/portal/pages/DashboardPage.tsx
// ============================================================
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { portalApi } from '../services/api';
import {
  BanknotesIcon,
  DocumentTextIcon,
  ChatBubbleLeftRightIcon,
  MegaphoneIcon,
  CalendarIcon,
  HandRaisedIcon,
} from '@heroicons/react/24/outline';

interface DashboardData {
  resumen_financiero: {
    saldo_pendiente: number;
    ultima_boleta: { periodo: string; monto: number; estado: string } | null;
    proximo_vencimiento: { fecha: string; monto: number } | null;
  };
  actividad: {
    solicitudes_activas: number;
    comunicados_no_leidos: number;
    votaciones_activas: number;
    notificaciones_no_leidas: number;
  };
  reservas_proximas: Array<{ fecha: string; espacio_nombre: string; hora_inicio: string }>;
  ultimos_pagos: Array<{ codigo_transaccion: string; monto_total: number; completada_at: string }>;
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const response = await portalApi.get('/dashboard');
      setData(response.data.data);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-12">Cargando...</div>;
  }

  if (!data) return null;

  const formatMoney = (amount: number) => 
    new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(amount);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>

      {/* Resumen Financiero */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Resumen Financiero</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className={`p-4 rounded-lg ${data.resumen_financiero.saldo_pendiente > 0 ? 'bg-red-50' : 'bg-green-50'}`}>
            <p className="text-sm text-gray-600">Saldo Pendiente</p>
            <p className={`text-2xl font-bold ${data.resumen_financiero.saldo_pendiente > 0 ? 'text-red-600' : 'text-green-600'}`}>
              {formatMoney(data.resumen_financiero.saldo_pendiente)}
            </p>
          </div>
          
          {data.resumen_financiero.ultima_boleta && (
            <div className="p-4 rounded-lg bg-blue-50">
              <p className="text-sm text-gray-600">Última Boleta ({data.resumen_financiero.ultima_boleta.periodo})</p>
              <p className="text-2xl font-bold text-blue-600">
                {formatMoney(data.resumen_financiero.ultima_boleta.monto)}
              </p>
              <span className={`text-xs px-2 py-1 rounded-full ${
                data.resumen_financiero.ultima_boleta.estado === 'pagada' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
              }`}>
                {data.resumen_financiero.ultima_boleta.estado.toUpperCase()}
              </span>
            </div>
          )}
          
          {data.resumen_financiero.proximo_vencimiento && (
            <div className="p-4 rounded-lg bg-yellow-50">
              <p className="text-sm text-gray-600">Próximo Vencimiento</p>
              <p className="text-2xl font-bold text-yellow-600">
                {formatMoney(data.resumen_financiero.proximo_vencimiento.monto)}
              </p>
              <p className="text-xs text-gray-500">
                {new Date(data.resumen_financiero.proximo_vencimiento.fecha).toLocaleDateString('es-CL')}
              </p>
            </div>
          )}
        </div>

        {data.resumen_financiero.saldo_pendiente > 0 && (
          <Link
            to="/portal/pagos"
            className="mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <BanknotesIcon className="w-5 h-5 mr-2" />
            Pagar Ahora
          </Link>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Link to="/portal/estado-cuenta" className="bg-white p-4 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
          <DocumentTextIcon className="w-8 h-8 text-blue-600 mb-2" />
          <h3 className="font-medium text-gray-900">Estado de Cuenta</h3>
          <p className="text-sm text-gray-500">Ver boletas</p>
        </Link>

        <Link to="/portal/solicitudes" className="bg-white p-4 rounded-xl shadow-sm border hover:shadow-md transition-shadow relative">
          <ChatBubbleLeftRightIcon className="w-8 h-8 text-green-600 mb-2" />
          <h3 className="font-medium text-gray-900">Solicitudes</h3>
          <p className="text-sm text-gray-500">Crear o ver</p>
          {data.actividad.solicitudes_activas > 0 && (
            <span className="absolute top-2 right-2 bg-green-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {data.actividad.solicitudes_activas}
            </span>
          )}
        </Link>

        <Link to="/portal/comunicados" className="bg-white p-4 rounded-xl shadow-sm border hover:shadow-md transition-shadow relative">
          <MegaphoneIcon className="w-8 h-8 text-yellow-600 mb-2" />
          <h3 className="font-medium text-gray-900">Comunicados</h3>
          <p className="text-sm text-gray-500">Noticias</p>
          {data.actividad.comunicados_no_leidos > 0 && (
            <span className="absolute top-2 right-2 bg-yellow-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {data.actividad.comunicados_no_leidos}
            </span>
          )}
        </Link>

        <Link to="/portal/votaciones" className="bg-white p-4 rounded-xl shadow-sm border hover:shadow-md transition-shadow relative">
          <HandRaisedIcon className="w-8 h-8 text-purple-600 mb-2" />
          <h3 className="font-medium text-gray-900">Votaciones</h3>
          <p className="text-sm text-gray-500">Participar</p>
          {data.actividad.votaciones_activas > 0 && (
            <span className="absolute top-2 right-2 bg-purple-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {data.actividad.votaciones_activas}
            </span>
          )}
        </Link>
      </div>

      {/* Reservas Próximas */}
      {data.reservas_proximas.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Mis Reservas Próximas</h2>
          <div className="space-y-3">
            {data.reservas_proximas.map((reserva, index) => (
              <div key={index} className="flex items-center p-3 bg-gray-50 rounded-lg">
                <CalendarIcon className="w-5 h-5 text-blue-600 mr-3" />
                <div>
                  <p className="font-medium text-gray-900">{reserva.espacio_nombre}</p>
                  <p className="text-sm text-gray-500">
                    {new Date(reserva.fecha).toLocaleDateString('es-CL')} - {reserva.hora_inicio}
                  </p>
                </div>
              </div>
            ))}
          </div>
          <Link to="/portal/reservas" className="mt-3 inline-block text-sm text-blue-600 hover:underline">
            Ver todas mis reservas →
          </Link>
        </div>
      )}

      {/* Últimos Pagos */}
      {data.ultimos_pagos.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Últimos Pagos</h2>
          <div className="space-y-2">
            {data.ultimos_pagos.map((pago, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{formatMoney(pago.monto_total)}</p>
                  <p className="text-xs text-gray-500">{pago.codigo_transaccion}</p>
                </div>
                <span className="text-sm text-gray-500">
                  {new Date(pago.completada_at).toLocaleDateString('es-CL')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
