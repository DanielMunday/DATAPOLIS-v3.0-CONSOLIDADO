import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  CreditCard, FileText, MessageSquare, Calendar, 
  Bell, User, LogOut, Home, Download, AlertCircle,
  CheckCircle, Clock, ChevronRight, DollarSign
} from 'lucide-react';

// =========================================================
// DATAPOLIS PRO v3.0 - Portal Copropietarios Frontend
// =========================================================

interface DashboardData {
  resumen_financiero: {
    saldo_pendiente: number;
    ultima_boleta: { periodo: string; monto: number; estado: string } | null;
    proximo_vencimiento: { fecha: string; monto: number } | null;
  };
  actividad: {
    solicitudes_activas: number;
    comunicados_no_leidos: number;
    votaciones_activas: number;
    notificaciones_no_leidas: number;
  };
  reservas_proximas: Array<{ espacio_nombre: string; fecha: string; hora_inicio: string }>;
  ultimos_pagos: Array<{ codigo_transaccion: string; monto_total: number; completada_at: string }>;
}

// Hook para API
const useApi = () => {
  const token = localStorage.getItem('portal_token');
  
  const fetchApi = async (endpoint: string, options: RequestInit = {}) => {
    const response = await fetch(`/api/portal${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...options.headers,
      },
    });
    
    if (response.status === 401) {
      localStorage.removeItem('portal_token');
      window.location.href = '/portal/login';
      throw new Error('Sesión expirada');
    }
    
    return response.json();
  };
  
  return { fetchApi, token };
};

// =========================================================
// LOGIN PAGE
// =========================================================
export const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/portal/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (data.success) {
        localStorage.setItem('portal_token', data.token);
        localStorage.setItem('portal_user', JSON.stringify(data.copropietario));
        localStorage.setItem('portal_unidad', JSON.stringify(data.unidad));
        navigate('/portal/dashboard');
      } else {
        setError(data.message || 'Error al iniciar sesión');
      }
    } catch (err) {
      setError('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Home className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">Portal Copropietarios</h1>
          <p className="text-gray-500 mt-2">Accede a tu cuenta</p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6 flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Correo electrónico
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="tu@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Contraseña
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="••••••••"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition disabled:opacity-50"
          >
            {loading ? 'Ingresando...' : 'Ingresar'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <a href="/portal/recuperar" className="text-blue-600 hover:underline text-sm">
            ¿Olvidaste tu contraseña?
          </a>
        </div>
      </div>
    </div>
  );
};

// =========================================================
// DASHBOARD PAGE
// =========================================================
export const DashboardPage: React.FC = () => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const { fetchApi } = useApi();
  const navigate = useNavigate();
  
  const user = JSON.parse(localStorage.getItem('portal_user') || '{}');
  const unidad = JSON.parse(localStorage.getItem('portal_unidad') || '{}');

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const response = await fetchApi('/dashboard');
      if (response.success) {
        setData(response.data);
      }
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await fetchApi('/logout', { method: 'POST' });
    localStorage.clear();
    navigate('/portal/login');
  };

  const formatMoney = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
              <Home className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-gray-800">Portal Copropietarios</h1>
              <p className="text-sm text-gray-500">{unidad.edificio} - Unidad {unidad.numero}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-gray-500 hover:text-gray-700">
              <Bell className="w-6 h-6" />
              {data?.actividad.notificaciones_no_leidas > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {data.actividad.notificaciones_no_leidas}
                </span>
              )}
            </button>
            <button onClick={() => navigate('/portal/perfil')} className="p-2 text-gray-500 hover:text-gray-700">
              <User className="w-6 h-6" />
            </button>
            <button onClick={handleLogout} className="p-2 text-gray-500 hover:text-red-600">
              <LogOut className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Saludo */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-800">
            Hola, {user.nombre?.split(' ')[0] || 'Copropietario'}
          </h2>
          <p className="text-gray-500">Bienvenido a tu portal de administración</p>
        </div>

        {/* Resumen Financiero */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className={`bg-white rounded-xl shadow-sm p-6 border-l-4 ${
            (data?.resumen_financiero.saldo_pendiente || 0) > 0 ? 'border-red-500' : 'border-green-500'
          }`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Saldo Pendiente</p>
                <p className="text-2xl font-bold text-gray-800">
                  {formatMoney(data?.resumen_financiero.saldo_pendiente || 0)}
                </p>
              </div>
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                (data?.resumen_financiero.saldo_pendiente || 0) > 0 ? 'bg-red-100' : 'bg-green-100'
              }`}>
                <DollarSign className={`w-6 h-6 ${
                  (data?.resumen_financiero.saldo_pendiente || 0) > 0 ? 'text-red-600' : 'text-green-600'
                }`} />
              </div>
            </div>
            {(data?.resumen_financiero.saldo_pendiente || 0) > 0 && (
              <button 
                onClick={() => navigate('/portal/pagos')}
                className="mt-4 w-full bg-blue-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-blue-700"
              >
                Pagar Ahora
              </button>
            )}
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-gray-500">Última Boleta</p>
              <FileText className="w-5 h-5 text-gray-400" />
            </div>
            {data?.resumen_financiero.ultima_boleta ? (
              <>
                <p className="text-lg font-bold text-gray-800">
                  {data.resumen_financiero.ultima_boleta.periodo}
                </p>
                <p className="text-gray-600">
                  {formatMoney(data.resumen_financiero.ultima_boleta.monto)}
                </p>
                <span className={`inline-block mt-2 px-2 py-1 rounded text-xs font-medium ${
                  data.resumen_financiero.ultima_boleta.estado === 'pagada' 
                    ? 'bg-green-100 text-green-700'
                    : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {data.resumen_financiero.ultima_boleta.estado}
                </span>
              </>
            ) : (
              <p className="text-gray-400">Sin boletas</p>
            )}
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-gray-500">Próximo Vencimiento</p>
              <Clock className="w-5 h-5 text-gray-400" />
            </div>
            {data?.resumen_financiero.proximo_vencimiento ? (
              <>
                <p className="text-lg font-bold text-gray-800">
                  {new Date(data.resumen_financiero.proximo_vencimiento.fecha).toLocaleDateString('es-CL')}
                </p>
                <p className="text-gray-600">
                  {formatMoney(data.resumen_financiero.proximo_vencimiento.monto)}
                </p>
              </>
            ) : (
              <p className="text-green-600 font-medium flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Sin deudas pendientes
              </p>
            )}
          </div>
        </div>

        {/* Accesos Rápidos */}
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Accesos Rápidos</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: FileText, label: 'Estado de Cuenta', path: '/portal/estado-cuenta', color: 'blue' },
            { icon: CreditCard, label: 'Pagar Online', path: '/portal/pagos', color: 'green' },
            { icon: MessageSquare, label: 'Solicitudes', path: '/portal/solicitudes', badge: data?.actividad.solicitudes_activas, color: 'purple' },
            { icon: Calendar, label: 'Reservas', path: '/portal/reservas', color: 'orange' },
          ].map((item) => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition flex flex-col items-center gap-3 relative"
            >
              <div className={`w-12 h-12 rounded-full bg-${item.color}-100 flex items-center justify-center`}>
                <item.icon className={`w-6 h-6 text-${item.color}-600`} />
              </div>
              <span className="text-sm font-medium text-gray-700">{item.label}</span>
              {item.badge && item.badge > 0 && (
                <span className="absolute top-2 right-2 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Actividad Reciente */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Últimos Pagos */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">Últimos Pagos</h3>
              <button 
                onClick={() => navigate('/portal/estado-cuenta')}
                className="text-blue-600 text-sm hover:underline flex items-center gap-1"
              >
                Ver todos <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            {data?.ultimos_pagos && data.ultimos_pagos.length > 0 ? (
              <div className="space-y-3">
                {data.ultimos_pagos.slice(0, 3).map((pago) => (
                  <div key={pago.codigo_transaccion} className="flex items-center justify-between py-2 border-b border-gray-100">
                    <div>
                      <p className="font-medium text-gray-800">{formatMoney(pago.monto_total)}</p>
                      <p className="text-xs text-gray-500">{pago.codigo_transaccion}</p>
                    </div>
                    <span className="text-sm text-gray-500">
                      {new Date(pago.completada_at).toLocaleDateString('es-CL')}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-400 text-center py-4">Sin pagos recientes</p>
            )}
          </div>

          {/* Próximas Reservas */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-800">Próximas Reservas</h3>
              <button 
                onClick={() => navigate('/portal/reservas')}
                className="text-blue-600 text-sm hover:underline flex items-center gap-1"
              >
                Ver todas <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            {data?.reservas_proximas && data.reservas_proximas.length > 0 ? (
              <div className="space-y-3">
                {data.reservas_proximas.map((reserva, idx) => (
                  <div key={idx} className="flex items-center gap-3 py-2 border-b border-gray-100">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">{reserva.espacio_nombre}</p>
                      <p className="text-xs text-gray-500">
                        {new Date(reserva.fecha).toLocaleDateString('es-CL')} - {reserva.hora_inicio}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-400 text-center py-4">Sin reservas próximas</p>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

// =========================================================
// ESTADO DE CUENTA PAGE
// =========================================================
export const EstadoCuentaPage: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { fetchApi } = useApi();
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const response = await fetchApi('/estado-cuenta');
      if (response.success) {
        setData(response.data);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatMoney = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const descargarPDF = async () => {
    window.open('/api/portal/estado-cuenta/pdf', '_blank');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-4">
          <button onClick={() => navigate('/portal/dashboard')} className="text-gray-500 hover:text-gray-700">
            ← Volver
          </button>
          <h1 className="text-xl font-bold text-gray-800">Estado de Cuenta</h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Resumen */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Resumen</h2>
            <button 
              onClick={descargarPDF}
              className="flex items-center gap-2 text-blue-600 hover:underline"
            >
              <Download className="w-4 h-4" />
              Descargar PDF
            </button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Total Pendiente</p>
              <p className="text-xl font-bold text-red-600">
                {formatMoney(data?.resumen?.total_pendiente || 0)}
              </p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Total Vencido</p>
              <p className="text-xl font-bold text-orange-600">
                {formatMoney(data?.resumen?.total_vencido || 0)}
              </p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Boletas Pendientes</p>
              <p className="text-xl font-bold text-gray-800">
                {data?.resumen?.boletas_pendientes || 0}
              </p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Intereses</p>
              <p className="text-xl font-bold text-gray-800">
                {formatMoney(data?.resumen?.total_intereses || 0)}
              </p>
            </div>
          </div>

          {(data?.resumen?.total_pendiente || 0) > 0 && (
            <button 
              onClick={() => navigate('/portal/pagos')}
              className="mt-6 w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700"
            >
              Pagar {formatMoney(data?.resumen?.total_pendiente || 0)}
            </button>
          )}
        </div>

        {/* Boletas Pendientes */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100">
            <h2 className="text-lg font-semibold">Boletas Pendientes</h2>
          </div>
          
          {data?.boletas_pendientes && data.boletas_pendientes.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Período</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Abonos</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Saldo</th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Estado</th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Vencimiento</th>
                    <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {data.boletas_pendientes.map((boleta: any) => (
                    <tr key={boleta.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-medium">{boleta.periodo}</td>
                      <td className="px-6 py-4 text-right">{formatMoney(boleta.total_a_pagar)}</td>
                      <td className="px-6 py-4 text-right">{formatMoney(boleta.total_abonos)}</td>
                      <td className="px-6 py-4 text-right font-semibold">{formatMoney(boleta.saldo_pendiente)}</td>
                      <td className="px-6 py-4 text-center">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          boleta.estado === 'vencida' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {boleta.estado}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center text-sm">
                        {new Date(boleta.fecha_vencimiento).toLocaleDateString('es-CL')}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button 
                          onClick={() => window.open(`/api/portal/estado-cuenta/boleta/${boleta.id}/pdf`, '_blank')}
                          className="text-blue-600 hover:underline text-sm"
                        >
                          Ver PDF
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="px-6 py-12 text-center text-gray-500">
              <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
              <p>¡Felicitaciones! No tienes boletas pendientes.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

// =========================================================
// PAGOS PAGE
// =========================================================
export const PagosPage: React.FC = () => {
  const [opciones, setOpciones] = useState<any>(null);
  const [selectedBoletas, setSelectedBoletas] = useState<number[]>([]);
  const [selectedPasarela, setSelectedPasarela] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [procesando, setProcesando] = useState(false);
  const { fetchApi } = useApi();
  const navigate = useNavigate();

  useEffect(() => {
    loadOpciones();
  }, []);

  const loadOpciones = async () => {
    try {
      const response = await fetchApi('/pagos/opciones');
      if (response.success) {
        setOpciones(response.data);
        // Seleccionar todas las boletas por defecto
        if (response.data.boletas_pendientes) {
          setSelectedBoletas(response.data.boletas_pendientes.map((b: any) => b.id));
        }
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleBoleta = (id: number) => {
    setSelectedBoletas(prev => 
      prev.includes(id) ? prev.filter(b => b !== id) : [...prev, id]
    );
  };

  const totalSeleccionado = opciones?.boletas_pendientes
    ?.filter((b: any) => selectedBoletas.includes(b.id))
    ?.reduce((sum: number, b: any) => sum + b.saldo, 0) || 0;

  const formatMoney = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const iniciarPago = async () => {
    if (selectedBoletas.length === 0 || !selectedPasarela) return;
    
    setProcesando(true);
    try {
      const response = await fetchApi('/pagos/iniciar', {
        method: 'POST',
        body: JSON.stringify({
          pasarela: selectedPasarela,
          boletas_ids: selectedBoletas,
        }),
      });

      if (response.success && response.data.url_pago) {
        window.location.href = response.data.url_pago;
      } else {
        alert(response.message || 'Error al iniciar pago');
      }
    } catch (error) {
      alert('Error de conexión');
    } finally {
      setProcesando(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-4">
          <button onClick={() => navigate('/portal/dashboard')} className="text-gray-500 hover:text-gray-700">
            ← Volver
          </button>
          <h1 className="text-xl font-bold text-gray-800">Pagar Online</h1>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-8">
        {/* Selección de Boletas */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Selecciona las boletas a pagar</h2>
          
          {opciones?.boletas_pendientes?.length > 0 ? (
            <div className="space-y-3">
              {opciones.boletas_pendientes.map((boleta: any) => (
                <label 
                  key={boleta.id}
                  className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition ${
                    selectedBoletas.includes(boleta.id) 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={selectedBoletas.includes(boleta.id)}
                      onChange={() => toggleBoleta(boleta.id)}
                      className="w-5 h-5 text-blue-600 rounded"
                    />
                    <div>
                      <p className="font-medium">{boleta.periodo}</p>
                      <p className={`text-xs ${boleta.estado === 'vencida' ? 'text-red-500' : 'text-gray-500'}`}>
                        {boleta.estado === 'vencida' ? 'Vencida' : `Vence: ${boleta.vencimiento}`}
                      </p>
                    </div>
                  </div>
                  <span className="font-semibold">{formatMoney(boleta.saldo)}</span>
                </label>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-8">No hay boletas pendientes de pago</p>
          )}
        </div>

        {/* Selección de Pasarela */}
        {opciones?.pasarelas?.length > 0 && selectedBoletas.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
            <h2 className="text-lg font-semibold mb-4">Selecciona medio de pago</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {opciones.pasarelas.map((pasarela: any) => (
                <button
                  key={pasarela.id}
                  onClick={() => setSelectedPasarela(pasarela.id)}
                  className={`p-4 border rounded-lg text-left transition ${
                    selectedPasarela === pasarela.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <p className="font-semibold text-gray-800">{pasarela.nombre}</p>
                  <p className="text-sm text-gray-500">{pasarela.descripcion}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Resumen y Botón de Pago */}
        {selectedBoletas.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="text-sm text-gray-500">Total a Pagar</p>
                <p className="text-3xl font-bold text-gray-800">{formatMoney(totalSeleccionado)}</p>
                <p className="text-sm text-gray-500">{selectedBoletas.length} boleta(s) seleccionada(s)</p>
              </div>
            </div>
            
            <button
              onClick={iniciarPago}
              disabled={!selectedPasarela || procesando}
              className="w-full bg-green-600 text-white py-4 rounded-lg font-semibold text-lg hover:bg-green-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {procesando ? 'Procesando...' : `Pagar ${formatMoney(totalSeleccionado)}`}
            </button>
            
            <p className="text-xs text-gray-400 text-center mt-4">
              Serás redirigido a la pasarela de pago segura
            </p>
          </div>
        )}
      </main>
    </div>
  );
};

export default { LoginPage, DashboardPage, EstadoCuentaPage, PagosPage };
