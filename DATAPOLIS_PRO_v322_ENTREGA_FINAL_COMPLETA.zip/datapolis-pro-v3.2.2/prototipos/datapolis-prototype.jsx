import React, { useState } from 'react';
import { Building2, Users, FileText, DollarSign, Calendar, Shield, Bell, Settings, LogOut, Search, ChevronDown, TrendingUp, TrendingDown, AlertCircle, CheckCircle, Clock, Home, BarChart3, Wallet, UserCheck, Scale, FileCheck, Menu, X } from 'lucide-react';

const DATAPOLISPrototype = () => {
  const [activeModule, setActiveModule] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showNotifications, setShowNotifications] = useState(false);

  const modules = [
    { id: 'dashboard', name: 'Dashboard', icon: Home },
    { id: 'edificios', name: 'Edificios', icon: Building2 },
    { id: 'gastos', name: 'Gastos Comunes', icon: Wallet },
    { id: 'arriendos', name: 'Arriendos', icon: DollarSign },
    { id: 'rrhh', name: 'RRHH', icon: Users },
    { id: 'contabilidad', name: 'Contabilidad', icon: BarChart3 },
    { id: 'reuniones', name: 'Reuniones', icon: Calendar },
    { id: 'compliance', name: 'Compliance', icon: Shield },
    { id: 'proteccion', name: 'Protección Datos', icon: FileCheck },
    { id: 'reportes', name: 'Reportes SII', icon: FileText },
  ];

  const stats = [
    { label: 'Edificios', value: '12', change: '+2', positive: true, icon: Building2 },
    { label: 'Unidades', value: '847', change: '+15', positive: true, icon: Home },
    { label: 'Recaudación Mes', value: '$45.2M', change: '+8.3%', positive: true, icon: TrendingUp },
    { label: 'Morosidad', value: '$12.8M', change: '-2.1%', positive: true, icon: TrendingDown },
  ];

  const alerts = [
    { type: 'error', message: '23 boletas con más de 30 días de mora', time: 'Hace 2h' },
    { type: 'warning', message: '5 contratos vencen en 60 días', time: 'Hace 4h' },
    { type: 'info', message: 'Asamblea programada para el 15 de enero', time: 'Ayer' },
    { type: 'success', message: 'DJ 1887 generada exitosamente', time: 'Ayer' },
  ];

  const recentPayments = [
    { unidad: '101-A', edificio: 'Torre Norte', monto: '$185.000', fecha: 'Hoy 10:30', estado: 'confirmado' },
    { unidad: '205-B', edificio: 'Edificio Central', monto: '$142.500', fecha: 'Hoy 09:15', estado: 'confirmado' },
    { unidad: '302-C', edificio: 'Torre Sur', monto: '$198.000', fecha: 'Ayer 16:45', estado: 'confirmado' },
    { unidad: '408-A', edificio: 'Torre Norte', monto: '$156.800', fecha: 'Ayer 14:20', estado: 'pendiente' },
  ];

  const morosos = [
    { unidad: '503-B', propietario: 'Juan Pérez', deuda: '$892.500', dias: 45 },
    { unidad: '201-A', propietario: 'María González', deuda: '$654.200', dias: 38 },
    { unidad: '704-C', propietario: 'Carlos Muñoz', deuda: '$423.100', dias: 32 },
  ];

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 font-medium">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                <span className={`text-sm font-medium ${stat.positive ? 'text-emerald-600' : 'text-red-600'}`}>
                  {stat.change}
                </span>
              </div>
              <div className={`p-3 rounded-xl ${stat.positive ? 'bg-emerald-50' : 'bg-red-50'}`}>
                <stat.icon className={`w-6 h-6 ${stat.positive ? 'text-emerald-600' : 'text-red-600'}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recaudación Chart */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recaudación Mensual</h3>
          <div className="h-48 flex items-end justify-between gap-2">
            {['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'].map((mes, i) => {
              const height = 30 + Math.random() * 70;
              return (
                <div key={mes} className="flex-1 flex flex-col items-center">
                  <div 
                    className="w-full bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-md transition-all hover:from-blue-700 hover:to-blue-500"
                    style={{ height: `${height}%` }}
                  />
                  <span className="text-xs text-gray-500 mt-2">{mes}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Distribución Morosidad */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Distribución Morosidad</h3>
          <div className="flex items-center justify-center h-48">
            <div className="relative w-40 h-40">
              <svg className="w-full h-full transform -rotate-90">
                <circle cx="80" cy="80" r="60" fill="none" stroke="#E5E7EB" strokeWidth="20" />
                <circle cx="80" cy="80" r="60" fill="none" stroke="#10B981" strokeWidth="20" 
                        strokeDasharray="251" strokeDashoffset="75" />
                <circle cx="80" cy="80" r="60" fill="none" stroke="#F59E0B" strokeWidth="20" 
                        strokeDasharray="251" strokeDashoffset="200" />
                <circle cx="80" cy="80" r="60" fill="none" stroke="#EF4444" strokeWidth="20" 
                        strokeDasharray="251" strokeDashoffset="235" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-900">70%</p>
                  <p className="text-xs text-gray-500">Al día</p>
                </div>
              </div>
            </div>
            <div className="ml-6 space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="text-sm text-gray-600">Al día (70%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-amber-500" />
                <span className="text-sm text-gray-600">1-30 días (20%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <span className="text-sm text-gray-600">+30 días (10%)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tables Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Payments */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900">Últimos Pagos</h3>
          </div>
          <div className="divide-y divide-gray-100">
            {recentPayments.map((pago, i) => (
              <div key={i} className="px-6 py-3 flex items-center justify-between hover:bg-gray-50">
                <div>
                  <p className="font-medium text-gray-900">{pago.unidad}</p>
                  <p className="text-sm text-gray-500">{pago.edificio}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">{pago.monto}</p>
                  <p className="text-xs text-gray-500">{pago.fecha}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Morosos */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900">Mayor Morosidad</h3>
          </div>
          <div className="divide-y divide-gray-100">
            {morosos.map((moroso, i) => (
              <div key={i} className="px-6 py-3 flex items-center justify-between hover:bg-gray-50">
                <div>
                  <p className="font-medium text-gray-900">{moroso.unidad}</p>
                  <p className="text-sm text-gray-500">{moroso.propietario}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-red-600">{moroso.deuda}</p>
                  <p className="text-xs text-red-500">{moroso.dias} días mora</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Alerts */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900">Alertas del Sistema</h3>
        </div>
        <div className="divide-y divide-gray-100">
          {alerts.map((alert, i) => (
            <div key={i} className="px-6 py-3 flex items-center gap-4 hover:bg-gray-50">
              {alert.type === 'error' && <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />}
              {alert.type === 'warning' && <Clock className="w-5 h-5 text-amber-500 flex-shrink-0" />}
              {alert.type === 'info' && <Bell className="w-5 h-5 text-blue-500 flex-shrink-0" />}
              {alert.type === 'success' && <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />}
              <div className="flex-1">
                <p className="text-gray-900">{alert.message}</p>
              </div>
              <span className="text-sm text-gray-500">{alert.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderEdificios = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-900">Gestión de Edificios</h2>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          + Nuevo Edificio
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {['Torre Norte', 'Edificio Central', 'Torre Sur', 'Condominio Parque', 'Edificio Plaza'].map((nombre, i) => (
          <div key={i} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-gray-900">{nombre}</h3>
                <p className="text-sm text-gray-500 mt-1">RUT: 65.XXX.XXX-{i}</p>
              </div>
              <span className="px-2 py-1 text-xs font-medium bg-emerald-100 text-emerald-700 rounded-full">
                Activo
              </span>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Unidades</p>
                <p className="text-lg font-semibold text-gray-900">{50 + i * 20}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Morosidad</p>
                <p className="text-lg font-semibold text-red-600">${(1.2 + i * 0.5).toFixed(1)}M</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCompliance = () => (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">Centro de Compliance</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl p-6 text-white">
          <Shield className="w-8 h-8 mb-3" />
          <h3 className="text-lg font-semibold">Ley 21.442</h3>
          <p className="text-emerald-100 text-sm mt-1">Copropiedad Inmobiliaria</p>
          <div className="mt-4 flex items-center gap-2">
            <div className="flex-1 bg-emerald-400/30 rounded-full h-2">
              <div className="bg-white rounded-full h-2 w-[95%]" />
            </div>
            <span className="text-sm font-medium">95%</span>
          </div>
        </div>
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
          <FileText className="w-8 h-8 mb-3" />
          <h3 className="text-lg font-semibold">Ley 21.713</h3>
          <p className="text-blue-100 text-sm mt-1">Tributación Arriendos</p>
          <div className="mt-4 flex items-center gap-2">
            <div className="flex-1 bg-blue-400/30 rounded-full h-2">
              <div className="bg-white rounded-full h-2 w-[88%]" />
            </div>
            <span className="text-sm font-medium">88%</span>
          </div>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white">
          <UserCheck className="w-8 h-8 mb-3" />
          <h3 className="text-lg font-semibold">Ley 21.719</h3>
          <p className="text-purple-100 text-sm mt-1">Protección de Datos</p>
          <div className="mt-4 flex items-center gap-2">
            <div className="flex-1 bg-purple-400/30 rounded-full h-2">
              <div className="bg-white rounded-full h-2 w-[92%]" />
            </div>
            <span className="text-sm font-medium">92%</span>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Certificaciones Disponibles</h3>
        <div className="space-y-3">
          {[
            { nombre: 'Certificado Cumplimiento Tributario', estado: 'Vigente', vence: '31/12/2025' },
            { nombre: 'Certificado Protección de Datos', estado: 'Por renovar', vence: '15/01/2025' },
            { nombre: 'Certificado Ley Copropiedad', estado: 'Vigente', vence: '30/06/2025' },
          ].map((cert, i) => (
            <div key={i} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">{cert.nombre}</p>
                <p className="text-sm text-gray-500">Vence: {cert.vence}</p>
              </div>
              <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                cert.estado === 'Vigente' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
              }`}>
                {cert.estado}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard': return renderDashboard();
      case 'edificios': return renderEdificios();
      case 'compliance': return renderCompliance();
      default: return (
        <div className="bg-white rounded-xl p-12 shadow-sm border border-gray-100 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            {modules.find(m => m.id === activeModule)?.icon && 
              React.createElement(modules.find(m => m.id === activeModule).icon, { className: "w-8 h-8 text-gray-400" })}
          </div>
          <h3 className="text-lg font-semibold text-gray-900">
            Módulo: {modules.find(m => m.id === activeModule)?.name}
          </h3>
          <p className="text-gray-500 mt-2">
            Este módulo está completamente desarrollado en el backend.<br/>
            240+ endpoints API disponibles.
          </p>
          <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Ver documentación API
          </button>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-slate-900 text-white transition-all duration-300 flex flex-col`}>
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
              <Building2 className="w-6 h-6" />
            </div>
            {sidebarOpen && (
              <div>
                <h1 className="font-bold text-lg">DATAPOLIS</h1>
                <p className="text-xs text-slate-400">PRO v3.0</p>
              </div>
            )}
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          {modules.map((module) => (
            <button
              key={module.id}
              onClick={() => setActiveModule(module.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                activeModule === module.id 
                  ? 'bg-blue-600 text-white' 
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              <module.icon className="w-5 h-5 flex-shrink-0" />
              {sidebarOpen && <span className="text-sm">{module.name}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-700">
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-slate-400 hover:text-white transition-colors"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-h-screen">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h2 className="text-xl font-semibold text-gray-900">
                {modules.find(m => m.id === activeModule)?.name}
              </h2>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Buscar..." 
                  className="pl-10 pr-4 py-2 bg-gray-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-64"
                />
              </div>
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 text-gray-500 hover:bg-gray-100 rounded-lg"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
              </button>
              <div className="flex items-center gap-3 pl-4 border-l border-gray-200">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-medium">
                  DA
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-gray-900">Daniel Admin</p>
                  <p className="text-xs text-gray-500">Administrador</p>
                </div>
                <ChevronDown className="w-4 h-4 text-gray-400" />
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 p-6 overflow-auto">
          {renderModule()}
        </div>

        {/* Footer */}
        <footer className="bg-white border-t border-gray-200 px-6 py-3">
          <div className="flex items-center justify-between text-sm text-gray-500">
            <p>© 2025 DATAPOLIS SpA - Sistema Integral de Administración de Condominios</p>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 bg-emerald-500 rounded-full" />
                Sistema Online
              </span>
              <span>v3.0 Consolidado</span>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default DATAPOLISPrototype;
