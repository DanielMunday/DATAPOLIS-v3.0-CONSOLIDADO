@extends('emails.layout')

@section('titulo', '📄 Acta de Asamblea Disponible')

@section('contenido')
    <h2>Estimado/a {{ $copropietarioNombre ?? 'Copropietario/a' }},</h2>
    
    <p>Le informamos que el acta de la <strong>{{ $tipoAsamblea ?? 'Asamblea' }}</strong> realizada el <strong>{{ $fechaAsamblea ?? '-' }}</strong> ya se encuentra disponible.</p>
    
    <div class="highlight-box success">
        <table class="data-table" style="margin: 0;">
            <tr>
                <th>Tipo de Asamblea</th>
                <td>{{ $tipoAsamblea ?? 'Ordinaria' }}</td>
            </tr>
            <tr>
                <th>Fecha de Realización</th>
                <td>{{ $fechaAsamblea ?? '-' }}</td>
            </tr>
            <tr>
                <th>Asistencia</th>
                <td>{{ $porcentajeAsistencia ?? '-' }}% de los derechos</td>
            </tr>
            <tr>
                <th>N° de Acta</th>
                <td>{{ $numeroActa ?? '-' }}</td>
            </tr>
        </table>
    </div>
    
    <h3 style="color: #111827; margin-top: 24px;">📋 Resumen de Acuerdos</h3>
    
    @if(isset($acuerdos) && is_array($acuerdos))
        <ul style="color: #4b5563; padding-left: 20px;">
            @foreach($acuerdos as $acuerdo)
                <li style="margin-bottom: 8px;">
                    <strong>{{ $acuerdo['titulo'] ?? 'Acuerdo' }}</strong>
                    @if(isset($acuerdo['resultado']))
                        - <span class="badge {{ $acuerdo['resultado'] === 'Aprobado' ? 'badge-success' : 'badge-danger' }}">
                            {{ $acuerdo['resultado'] }}
                        </span>
                    @endif
                    @if(isset($acuerdo['votacion']))
                        <br><small class="text-muted">Votación: {{ $acuerdo['votacion'] }}</small>
                    @endif
                </li>
            @endforeach
        </ul>
    @else
        <p class="text-muted">Consulte el acta completa para ver los acuerdos adoptados.</p>
    @endif
    
    <div class="text-center">
        <a href="{{ $urlActa ?? '#' }}" class="btn btn-primary">Descargar Acta Completa</a>
    </div>
    
    @if(isset($plazoObservaciones) && $plazoObservaciones > 0)
        <div class="highlight-box warning">
            <p style="margin: 0;">
                <strong>Plazo para observaciones:</strong> Tiene {{ $plazoObservaciones }} días hábiles para presentar observaciones al acta.
                @if(isset($urlObservaciones))
                    <br><a href="{{ $urlObservaciones }}">Enviar observación</a>
                @endif
            </p>
        </div>
    @endif
    
    <div class="divider"></div>
    
    <p class="text-muted" style="font-size: 12px;">
        El acta constituye documento legal vinculante para todos los copropietarios, conforme al Artículo 20 de la Ley 21.442.
        Los acuerdos son obligatorios desde su adopción para todos los copropietarios, incluyendo los ausentes.
    </p>
@endsection
