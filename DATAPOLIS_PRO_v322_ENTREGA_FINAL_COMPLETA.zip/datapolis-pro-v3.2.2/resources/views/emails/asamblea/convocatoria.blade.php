@extends('emails.layout')

@section('titulo', ($esRecordatorio ?? false) ? '🔔 Recordatorio de Asamblea' : '📋 Convocatoria a Asamblea')

@section('contenido')
    <h2>Estimado/a {{ $copropietarioNombre ?? 'Copropietario/a' }},</h2>
    
    @if($esRecordatorio ?? false)
        <div class="highlight-box warning">
            <p style="margin: 0; font-weight: 600; color: #92400e;">
                🔔 Le recordamos que la asamblea está programada para <strong>{{ $fechaAsamblea ?? 'próximamente' }}</strong>
            </p>
        </div>
    @endif
    
    <p>
        @if($esRecordatorio ?? false)
            Como es de su conocimiento, se realizará
        @else
            Por medio de la presente, se le convoca a
        @endif
        la <strong>{{ $tipoAsamblea ?? 'Asamblea Ordinaria' }}</strong> de copropietarios de <strong>{{ $edificioNombre ?? 'el edificio' }}</strong>.
    </p>
    
    <div class="highlight-box">
        <table class="data-table" style="margin: 0;">
            <tr>
                <th>📅 Fecha</th>
                <td><strong>{{ $fechaAsamblea ?? '-' }}</strong></td>
            </tr>
            <tr>
                <th>🕐 Hora</th>
                <td>
                    Primera citación: {{ $horaPrimeraCitacion ?? '-' }}<br>
                    Segunda citación: {{ $horaSegundaCitacion ?? '-' }}
                </td>
            </tr>
            <tr>
                <th>📍 Lugar</th>
                <td>{{ $lugar ?? 'Sala de eventos del edificio' }}</td>
            </tr>
            @if(isset($modalidad))
            <tr>
                <th>💻 Modalidad</th>
                <td>{{ $modalidad }}</td>
            </tr>
            @endif
        </table>
    </div>
    
    <h3 style="color: #111827; margin-top: 24px;">📋 Tabla de Materias</h3>
    
    <ol style="color: #4b5563; padding-left: 20px;">
        @if(isset($tablaMaterias) && is_array($tablaMaterias))
            @foreach($tablaMaterias as $materia)
                <li style="margin-bottom: 8px;">{{ $materia }}</li>
            @endforeach
        @else
            <li>Lectura y aprobación del acta anterior</li>
            <li>Cuenta de la administración</li>
            <li>Aprobación de presupuesto</li>
            <li>Varios</li>
        @endif
    </ol>
    
    @if(isset($documentosAdjuntos) && count($documentosAdjuntos) > 0)
        <div class="highlight-box">
            <p style="margin: 0 0 12px 0; font-weight: 600;">📎 Documentos para la asamblea:</p>
            <ul style="margin: 0; padding-left: 20px;">
                @foreach($documentosAdjuntos as $doc)
                    <li><a href="{{ $doc['url'] ?? '#' }}">{{ $doc['nombre'] ?? 'Documento' }}</a></li>
                @endforeach
            </ul>
        </div>
    @endif
    
    @if(isset($urlVotacionOnline))
        <div class="text-center">
            <a href="{{ $urlVotacionOnline }}" class="btn btn-primary">Participar Online</a>
        </div>
    @endif
    
    @if(isset($urlConfirmarAsistencia))
        <div class="text-center">
            <a href="{{ $urlConfirmarAsistencia }}" class="btn btn-secondary">Confirmar Asistencia</a>
        </div>
    @endif
    
    <div class="divider"></div>
    
    <p><strong>Información importante:</strong></p>
    <ul style="color: #4b5563; font-size: 14px; padding-left: 20px;">
        <li>Los copropietarios pueden hacerse representar mediante poder simple.</li>
        <li>Se requiere quórum de {{ $quorumRequerido ?? '50%+1' }} para sesionar en primera citación.</li>
        <li>En segunda citación se sesionará con los asistentes.</li>
        @if(isset($derechosVotacion))
            <li>Sus derechos de votación: {{ $derechosVotacion }}%</li>
        @endif
    </ul>
    
    <p class="text-muted" style="font-size: 12px;">
        Esta convocatoria se realiza en conformidad con los Artículos 17 al 20 de la Ley 21.442 sobre Copropiedad Inmobiliaria 
        y el Reglamento de Copropiedad del edificio.
    </p>
@endsection
