@extends('emails.layout')

@section('titulo', $esMoraGrave ?? false ? '⚠️ Aviso de Mora Grave' : 'Aviso de Mora')

@section('contenido')
    <h2>Estimado/a {{ $copropietarioNombre ?? 'Copropietario/a' }},</h2>
    
    @if($esMoraGrave ?? false)
        <div class="highlight-box danger">
            <p style="margin: 0; font-weight: 600; color: #991b1b;">
                ⚠️ AVISO IMPORTANTE: Su deuda presenta mora prolongada que podría derivar en acciones de cobranza judicial conforme al Artículo 27 de la Ley 21.442.
            </p>
        </div>
    @endif
    
    <p>Le informamos que registra una deuda pendiente de pago correspondiente a su unidad <strong>{{ $unidad ?? '-' }}</strong> en <strong>{{ $edificioNombre ?? 'el edificio' }}</strong>.</p>
    
    <div class="highlight-box {{ ($esMoraGrave ?? false) ? 'danger' : 'warning' }}">
        <table class="data-table" style="margin: 0;">
            <tr>
                <th>Deuda Original</th>
                <td>${{ number_format($deudaOriginal ?? 0, 0, ',', '.') }} CLP</td>
            </tr>
            <tr>
                <th>Intereses Mora</th>
                <td>${{ number_format($intereses ?? 0, 0, ',', '.') }} CLP</td>
            </tr>
            <tr>
                <th>Reajustes</th>
                <td>${{ number_format($reajustes ?? 0, 0, ',', '.') }} CLP</td>
            </tr>
            <tr>
                <th>Meses en Mora</th>
                <td><span class="badge {{ ($mesesMora ?? 0) > 3 ? 'badge-danger' : 'badge-warning' }}">{{ $mesesMora ?? 0 }} meses</span></td>
            </tr>
            <tr>
                <th style="font-size: 18px;">TOTAL A PAGAR</th>
                <td style="font-size: 18px; font-weight: 700; color: #dc2626;">${{ number_format($totalDeuda ?? 0, 0, ',', '.') }} CLP</td>
            </tr>
        </table>
    </div>
    
    @if($esMoraGrave ?? false)
        <p><strong>Consecuencias de no regularizar:</strong></p>
        <ul style="color: #4b5563; padding-left: 20px;">
            <li>Inicio de cobranza judicial</li>
            <li>Publicación en boletín comercial</li>
            <li>Suspensión de servicios no esenciales</li>
            <li>Costas judiciales adicionales</li>
        </ul>
        
        <div class="text-center">
            <a href="{{ $urlConvenio ?? '#' }}" class="btn btn-danger">Solicitar Convenio de Pago</a>
        </div>
    @else
        <div class="text-center">
            <a href="{{ $urlPago ?? '#' }}" class="btn btn-primary">Regularizar Ahora</a>
        </div>
    @endif
    
    <div class="divider"></div>
    
    <p>Si ya realizó el pago, por favor ignore este mensaje. El sistema puede demorar hasta 48 horas en reflejar su pago.</p>
    
    <p>Para consultas o convenios de pago, contáctenos a:</p>
    <p>
        📧 {{ $emailContacto ?? 'administracion@edificio.cl' }}<br>
        📞 {{ $telefonoContacto ?? '+56 2 XXXX XXXX' }}
    </p>
    
    <p class="text-muted" style="font-size: 12px;">
        Este aviso se emite en conformidad con el Artículo 27 de la Ley 21.442 sobre Copropiedad Inmobiliaria. 
        Los intereses moratorios se calculan según lo establecido en el reglamento de copropiedad y la normativa vigente.
    </p>
@endsection
