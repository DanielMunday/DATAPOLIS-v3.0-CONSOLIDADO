@extends('emails.layout')

@section('titulo', '✅ Pago Confirmado')

@section('contenido')
    <h2>Estimado/a {{ $copropietarioNombre ?? 'Copropietario/a' }},</h2>
    
    <div class="highlight-box success">
        <p style="margin: 0; font-weight: 600; color: #065f46; text-align: center;">
            ✅ Su pago ha sido recibido y procesado exitosamente
        </p>
    </div>
    
    <p>Confirmamos la recepción de su pago correspondiente a la unidad <strong>{{ $unidad ?? '-' }}</strong> en <strong>{{ $edificioNombre ?? 'el edificio' }}</strong>.</p>
    
    <div class="highlight-box">
        <table class="data-table" style="margin: 0;">
            <tr>
                <th>N° Comprobante</th>
                <td><strong>{{ $numeroComprobante ?? '-' }}</strong></td>
            </tr>
            <tr>
                <th>Fecha de Pago</th>
                <td>{{ $fechaPago ?? now()->format('d/m/Y H:i') }}</td>
            </tr>
            <tr>
                <th>Concepto</th>
                <td>{{ $concepto ?? 'Gastos Comunes' }}</td>
            </tr>
            <tr>
                <th>Período</th>
                <td>{{ $periodo ?? '-' }}</td>
            </tr>
            <tr>
                <th>Método de Pago</th>
                <td>{{ $metodoPago ?? 'Transferencia' }}</td>
            </tr>
        </table>
    </div>
    
    <div class="amount-display" style="color: #059669;">
        ${{ number_format($monto ?? 0, 0, ',', '.') }} CLP
    </div>
    
    @if(isset($saldoPendiente) && $saldoPendiente > 0)
        <div class="highlight-box warning">
            <p style="margin: 0;">
                <strong>Nota:</strong> Aún mantiene un saldo pendiente de <strong>${{ number_format($saldoPendiente, 0, ',', '.') }} CLP</strong>.
            </p>
        </div>
    @else
        <p class="text-center">
            <span class="badge badge-success" style="font-size: 14px; padding: 8px 16px;">🎉 Sin deudas pendientes</span>
        </p>
    @endif
    
    <div class="text-center">
        <a href="{{ $urlComprobante ?? '#' }}" class="btn btn-success">Descargar Comprobante PDF</a>
    </div>
    
    <div class="divider"></div>
    
    <p class="text-muted text-center">
        Gracias por su pago oportuno. Su contribución permite mantener las áreas comunes y servicios del edificio.
    </p>
@endsection
