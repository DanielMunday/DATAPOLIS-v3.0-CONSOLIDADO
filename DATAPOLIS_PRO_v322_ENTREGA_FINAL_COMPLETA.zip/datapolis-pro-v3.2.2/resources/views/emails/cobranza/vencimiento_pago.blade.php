@extends('emails.layout')

@section('titulo', 'Recordatorio de Pago')

@section('contenido')
    <h2>Estimado/a {{ $copropietarioNombre ?? 'Copropietario/a' }},</h2>
    
    <p>Le recordamos que tiene un pago próximo a vencer correspondiente a su unidad en <strong>{{ $edificioNombre ?? 'el edificio' }}</strong>.</p>
    
    <div class="highlight-box warning">
        <table class="data-table" style="margin: 0;">
            <tr>
                <th>Concepto</th>
                <td>{{ $concepto ?? 'Gastos Comunes' }}</td>
            </tr>
            <tr>
                <th>Período</th>
                <td>{{ $periodo ?? 'Mes actual' }}</td>
            </tr>
            <tr>
                <th>Unidad</th>
                <td>{{ $unidad ?? '-' }}</td>
            </tr>
            <tr>
                <th>Fecha de Vencimiento</th>
                <td><strong>{{ $fechaVencimiento ?? 'Próximamente' }}</strong></td>
            </tr>
        </table>
    </div>
    
    <div class="amount-display">
        ${{ number_format($monto ?? 0, 0, ',', '.') }} CLP
    </div>
    
    <p>Le invitamos a realizar el pago antes de la fecha indicada para evitar recargos por mora.</p>
    
    @if(isset($urlPago))
        <div class="text-center">
            <a href="{{ $urlPago }}" class="btn btn-primary">Pagar Ahora</a>
        </div>
    @endif
    
    <div class="divider"></div>
    
    <p class="text-muted">
        <strong>Formas de pago disponibles:</strong><br>
        • Transferencia bancaria<br>
        • Pago en línea a través del portal<br>
        • Depósito en cuenta corriente
    </p>
    
    @if(isset($datosBancarios))
        <div class="highlight-box">
            <p style="margin: 0;"><strong>Datos para transferencia:</strong></p>
            <p style="margin: 8px 0 0 0;">
                Banco: {{ $datosBancarios['banco'] ?? '-' }}<br>
                Cuenta: {{ $datosBancarios['cuenta'] ?? '-' }}<br>
                RUT: {{ $datosBancarios['rut'] ?? '-' }}<br>
                Email: {{ $datosBancarios['email'] ?? '-' }}
            </p>
        </div>
    @endif
@endsection
