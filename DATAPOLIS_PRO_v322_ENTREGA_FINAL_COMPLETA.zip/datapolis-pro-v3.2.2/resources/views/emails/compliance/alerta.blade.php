@extends('emails.layout')

@section('titulo', ($esAlerta ?? false) ? '⚠️ Alerta de Compliance' : '📋 Certificado Próximo a Vencer')

@section('contenido')
    <h2>Estimado/a {{ $destinatarioNombre ?? 'Administrador/a' }},</h2>
    
    @if($esAlerta ?? false)
        <div class="highlight-box danger">
            <p style="margin: 0; font-weight: 600; color: #991b1b;">
                ⚠️ Se ha detectado un incumplimiento en {{ $edificioNombre ?? 'el edificio' }} que requiere atención inmediata.
            </p>
        </div>
        
        <p>Nuestro sistema de monitoreo ha identificado el siguiente problema de compliance:</p>
        
        <div class="highlight-box">
            <table class="data-table" style="margin: 0;">
                <tr>
                    <th>Tipo de Incumplimiento</th>
                    <td><span class="badge badge-danger">{{ $tipoIncumplimiento ?? 'No especificado' }}</span></td>
                </tr>
                <tr>
                    <th>Área Afectada</th>
                    <td>{{ $areaAfectada ?? '-' }}</td>
                </tr>
                <tr>
                    <th>Nivel de Riesgo</th>
                    <td>
                        <span class="badge {{ ($nivelRiesgo ?? 'medio') === 'alto' ? 'badge-danger' : (($nivelRiesgo ?? 'medio') === 'medio' ? 'badge-warning' : 'badge-info') }}">
                            {{ strtoupper($nivelRiesgo ?? 'MEDIO') }}
                        </span>
                    </td>
                </tr>
                <tr>
                    <th>Fecha de Detección</th>
                    <td>{{ $fechaDeteccion ?? now()->format('d/m/Y H:i') }}</td>
                </tr>
            </table>
        </div>
        
        <h3 style="color: #dc2626;">Acciones Requeridas:</h3>
        @if(isset($accionesRequeridas) && is_array($accionesRequeridas))
            <ol style="color: #4b5563; padding-left: 20px;">
                @foreach($accionesRequeridas as $accion)
                    <li style="margin-bottom: 8px;">{{ $accion }}</li>
                @endforeach
            </ol>
        @endif
        
        <div class="text-center">
            <a href="{{ $urlResolver ?? '#' }}" class="btn btn-danger">Resolver Incumplimiento</a>
        </div>
        
    @else
        <p>Le informamos que el siguiente certificado de compliance está próximo a vencer:</p>
        
        <div class="highlight-box warning">
            <table class="data-table" style="margin: 0;">
                <tr>
                    <th>Tipo de Certificado</th>
                    <td>{{ $tipoCertificado ?? '-' }}</td>
                </tr>
                <tr>
                    <th>Código</th>
                    <td><code>{{ $codigoCertificado ?? '-' }}</code></td>
                </tr>
                <tr>
                    <th>Fecha de Emisión</th>
                    <td>{{ $fechaEmision ?? '-' }}</td>
                </tr>
                <tr>
                    <th>Fecha de Vencimiento</th>
                    <td><strong style="color: #dc2626;">{{ $fechaVencimiento ?? '-' }}</strong></td>
                </tr>
                <tr>
                    <th>Días Restantes</th>
                    <td>
                        <span class="badge {{ ($diasRestantes ?? 30) <= 7 ? 'badge-danger' : 'badge-warning' }}">
                            {{ $diasRestantes ?? '-' }} días
                        </span>
                    </td>
                </tr>
            </table>
        </div>
        
        <p>Para mantener su cumplimiento normativo, le recomendamos renovar el certificado antes de su vencimiento.</p>
        
        <div class="text-center">
            <a href="{{ $urlRenovar ?? '#' }}" class="btn btn-primary">Renovar Certificado</a>
        </div>
    @endif
    
    <div class="divider"></div>
    
    <p><strong>¿Por qué es importante el compliance?</strong></p>
    <ul style="color: #6b7280; font-size: 14px; padding-left: 20px;">
        <li>Cumplimiento de la Ley 21.442 de Copropiedad Inmobiliaria</li>
        <li>Evita sanciones y multas administrativas</li>
        <li>Protege a la comunidad de copropietarios</li>
        <li>Facilita trámites legales y comerciales</li>
    </ul>
    
    <p class="text-muted" style="font-size: 12px;">
        Este monitoreo se realiza conforme a los estándares de compliance definidos por la normativa chilena 
        de copropiedad inmobiliaria y las mejores prácticas de administración de condominios.
    </p>
@endsection
