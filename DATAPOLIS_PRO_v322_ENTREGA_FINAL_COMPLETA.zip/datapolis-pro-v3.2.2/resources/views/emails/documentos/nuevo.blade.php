@extends('emails.layout')

@section('titulo', ($requiereFirma ?? false) ? '✍️ Documento Requiere su Firma' : '📄 Nuevo Documento Disponible')

@section('contenido')
    <h2>Estimado/a {{ $copropietarioNombre ?? 'Copropietario/a' }},</h2>
    
    @if($requiereFirma ?? false)
        <div class="highlight-box warning">
            <p style="margin: 0; font-weight: 600; color: #92400e;">
                ✍️ El siguiente documento requiere su firma electrónica
            </p>
        </div>
        
        <p>Se ha generado un documento que necesita su revisión y firma para <strong>{{ $edificioNombre ?? 'el edificio' }}</strong>.</p>
    @else
        <p>Le informamos que hay un nuevo documento disponible en el portal de <strong>{{ $edificioNombre ?? 'el edificio' }}</strong>.</p>
    @endif
    
    <div class="highlight-box">
        <table class="data-table" style="margin: 0;">
            <tr>
                <th>📄 Documento</th>
                <td><strong>{{ $nombreDocumento ?? 'Documento' }}</strong></td>
            </tr>
            <tr>
                <th>📁 Categoría</th>
                <td>{{ $categoriaDocumento ?? 'General' }}</td>
            </tr>
            <tr>
                <th>📅 Fecha</th>
                <td>{{ $fechaDocumento ?? now()->format('d/m/Y') }}</td>
            </tr>
            @if(isset($tamanoDocumento))
            <tr>
                <th>📦 Tamaño</th>
                <td>{{ $tamanoDocumento }}</td>
            </tr>
            @endif
            @if($requiereFirma ?? false)
            <tr>
                <th>⏰ Plazo para Firmar</th>
                <td><strong style="color: #dc2626;">{{ $plazoFirma ?? '7 días' }}</strong></td>
            </tr>
            @endif
        </table>
    </div>
    
    @if(isset($descripcionDocumento))
        <p><strong>Descripción:</strong></p>
        <p style="background-color: #f9fafb; padding: 16px; border-radius: 8px; color: #4b5563;">
            {{ $descripcionDocumento }}
        </p>
    @endif
    
    @if($requiereFirma ?? false)
        <div class="text-center">
            <a href="{{ $urlFirmar ?? '#' }}" class="btn btn-primary">Revisar y Firmar</a>
        </div>
        
        <p class="text-muted text-center" style="font-size: 14px;">
            La firma electrónica tiene la misma validez legal que la firma manuscrita según la Ley 19.799.
        </p>
    @else
        <div class="text-center">
            <a href="{{ $urlDescargar ?? '#' }}" class="btn btn-primary">Ver Documento</a>
            @if(isset($urlDescargarPdf))
                <a href="{{ $urlDescargarPdf }}" class="btn btn-secondary">Descargar PDF</a>
            @endif
        </div>
    @endif
    
    @if(isset($documentosRelacionados) && count($documentosRelacionados) > 0)
        <div class="divider"></div>
        
        <p><strong>Documentos relacionados:</strong></p>
        <ul style="color: #4b5563; padding-left: 20px;">
            @foreach($documentosRelacionados as $doc)
                <li><a href="{{ $doc['url'] ?? '#' }}">{{ $doc['nombre'] ?? 'Documento' }}</a></li>
            @endforeach
        </ul>
    @endif
    
    <div class="divider"></div>
    
    <p class="text-muted" style="font-size: 12px;">
        Todos los documentos quedan almacenados en el repositorio digital del edificio conforme a la Ley 21.442 
        y pueden ser consultados en cualquier momento a través del portal de copropietarios.
    </p>
@endsection
