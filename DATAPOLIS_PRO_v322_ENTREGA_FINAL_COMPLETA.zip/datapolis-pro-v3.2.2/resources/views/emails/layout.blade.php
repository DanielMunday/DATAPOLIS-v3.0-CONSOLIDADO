<!DOCTYPE html>
<html lang="{{ $idioma ?? 'es' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>{{ $asunto ?? 'Notificación DATAPOLIS' }}</title>
    <!--[if mso]>
    <noscript>
        <xml>
            <o:OfficeDocumentSettings>
                <o:PixelsPerInch>96</o:PixelsPerInch>
            </o:OfficeDocumentSettings>
        </xml>
    </noscript>
    <![endif]-->
    <style>
        /* Reset */
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
        body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; }
        a[x-apple-data-detectors] { color: inherit !important; text-decoration: none !important; font-size: inherit !important; font-family: inherit !important; font-weight: inherit !important; line-height: inherit !important; }
        
        /* Base Styles */
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: #374151;
            background-color: #f3f4f6;
        }
        
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
        }
        
        .email-header {
            background-color: {{ $colorCategoria ?? '#2563eb' }};
            padding: 30px 40px;
            text-align: center;
        }
        
        .email-header h1 {
            color: #ffffff;
            font-size: 24px;
            font-weight: 600;
            margin: 0;
        }
        
        .email-header .logo {
            margin-bottom: 15px;
        }
        
        .email-body {
            padding: 40px;
        }
        
        .email-body h2 {
            color: #111827;
            font-size: 20px;
            font-weight: 600;
            margin: 0 0 20px 0;
        }
        
        .email-body p {
            color: #4b5563;
            margin: 0 0 16px 0;
        }
        
        .highlight-box {
            background-color: #f9fafb;
            border-left: 4px solid {{ $colorCategoria ?? '#2563eb' }};
            padding: 20px;
            margin: 24px 0;
            border-radius: 0 8px 8px 0;
        }
        
        .highlight-box.warning {
            background-color: #fef3c7;
            border-left-color: #f59e0b;
        }
        
        .highlight-box.danger {
            background-color: #fee2e2;
            border-left-color: #dc2626;
        }
        
        .highlight-box.success {
            background-color: #d1fae5;
            border-left-color: #059669;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin: 24px 0;
        }
        
        .data-table th,
        .data-table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .data-table th {
            background-color: #f9fafb;
            font-weight: 600;
            color: #374151;
        }
        
        .data-table tr:last-child td {
            border-bottom: none;
        }
        
        .btn {
            display: inline-block;
            padding: 14px 28px;
            font-size: 16px;
            font-weight: 600;
            text-decoration: none;
            border-radius: 8px;
            margin: 16px 0;
        }
        
        .btn-primary {
            background-color: {{ $colorCategoria ?? '#2563eb' }};
            color: #ffffff !important;
        }
        
        .btn-secondary {
            background-color: #6b7280;
            color: #ffffff !important;
        }
        
        .btn-success {
            background-color: #059669;
            color: #ffffff !important;
        }
        
        .btn-danger {
            background-color: #dc2626;
            color: #ffffff !important;
        }
        
        .amount-display {
            font-size: 32px;
            font-weight: 700;
            color: {{ $colorCategoria ?? '#2563eb' }};
            text-align: center;
            margin: 20px 0;
        }
        
        .amount-display.danger {
            color: #dc2626;
        }
        
        .email-footer {
            background-color: #f9fafb;
            padding: 30px 40px;
            text-align: center;
            border-top: 1px solid #e5e7eb;
        }
        
        .email-footer p {
            color: #6b7280;
            font-size: 14px;
            margin: 0 0 8px 0;
        }
        
        .email-footer a {
            color: {{ $colorCategoria ?? '#2563eb' }};
            text-decoration: none;
        }
        
        .social-links {
            margin-top: 20px;
        }
        
        .social-links a {
            display: inline-block;
            margin: 0 8px;
        }
        
        .divider {
            height: 1px;
            background-color: #e5e7eb;
            margin: 24px 0;
        }
        
        .text-muted {
            color: #9ca3af;
            font-size: 14px;
        }
        
        .text-center {
            text-align: center;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 12px;
            font-size: 12px;
            font-weight: 600;
            border-radius: 9999px;
            text-transform: uppercase;
        }
        
        .badge-success {
            background-color: #d1fae5;
            color: #065f46;
        }
        
        .badge-warning {
            background-color: #fef3c7;
            color: #92400e;
        }
        
        .badge-danger {
            background-color: #fee2e2;
            color: #991b1b;
        }
        
        .badge-info {
            background-color: #dbeafe;
            color: #1e40af;
        }
        
        /* Responsive */
        @media only screen and (max-width: 600px) {
            .email-container {
                width: 100% !important;
            }
            .email-header,
            .email-body,
            .email-footer {
                padding: 20px !important;
            }
            .btn {
                display: block !important;
                width: 100% !important;
                text-align: center !important;
            }
        }
    </style>
</head>
<body>
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f3f4f6;">
        <tr>
            <td align="center" style="padding: 40px 20px;">
                <table role="presentation" cellspacing="0" cellpadding="0" border="0" class="email-container" width="600">
                    <!-- Header -->
                    <tr>
                        <td class="email-header">
                            <div class="logo">
                                <img src="{{ config('app.url') }}/images/logo-white.png" alt="DATAPOLIS" width="150" style="max-width: 150px;">
                            </div>
                            <h1>@yield('titulo', $asunto ?? 'Notificación')</h1>
                        </td>
                    </tr>
                    
                    <!-- Body -->
                    <tr>
                        <td class="email-body">
                            @yield('contenido')
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td class="email-footer">
                            @hasSection('footer')
                                @yield('footer')
                            @else
                                <p><strong>{{ $edificioNombre ?? 'DATAPOLIS PRO' }}</strong></p>
                                <p>Esta notificación fue enviada automáticamente.</p>
                                <p>Si no desea recibir más notificaciones, puede <a href="{{ $urlPreferencias ?? '#' }}">actualizar sus preferencias</a>.</p>
                                
                                <div class="divider"></div>
                                
                                <p class="text-muted">
                                    © {{ date('Y') }} DATAPOLIS PRO - Gestión Inteligente de Condominios<br>
                                    Desarrollado conforme a Ley 21.442
                                </p>
                            @endif
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
