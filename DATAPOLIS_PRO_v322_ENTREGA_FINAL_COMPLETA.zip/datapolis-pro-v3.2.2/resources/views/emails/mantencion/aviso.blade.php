@extends('emails.layout')

@section('titulo', ($esEmergencia ?? false) ? '🚨 Mantención de Emergencia' : '🔧 Mantención Programada')

@section('contenido')
    <h2>Estimado/a {{ $copropietarioNombre ?? 'Copropietario/a' }},</h2>
    
    @if($esEmergencia ?? false)
        <div class="highlight-box danger">
            <p style="margin: 0; font-weight: 600; color: #991b1b;">
                🚨 AVISO URGENTE: Se realizará una mantención de emergencia que podría afectar servicios del edificio.
            </p>
        </div>
    @endif
    
    <p>
        @if($esEmergencia ?? false)
            Debido a una situación que requiere atención inmediata, se realizará la siguiente mantención de emergencia en <strong>{{ $edificioNombre ?? 'el edificio' }}</strong>:
        @else
            Le informamos que se ha programado la siguiente mantención en <strong>{{ $edificioNombre ?? 'el edificio' }}</strong>:
        @endif
    </p>
    
    <div class="highlight-box {{ ($esEmergencia ?? false) ? 'danger' : '' }}">
        <table class="data-table" style="margin: 0;">
            <tr>
                <th>🔧 Tipo de Mantención</th>
                <td><strong>{{ $tipoMantencion ?? 'General' }}</strong></td>
            </tr>
            <tr>
                <th>📍 Área Afectada</th>
                <td>{{ $areaAfectada ?? 'Áreas comunes' }}</td>
            </tr>
            <tr>
                <th>📅 Fecha</th>
                <td>{{ $fechaMantencion ?? '-' }}</td>
            </tr>
            <tr>
                <th>🕐 Horario</th>
                <td>{{ $horaInicio ?? '-' }} - {{ $horaTermino ?? '-' }}</td>
            </tr>
            <tr>
                <th>⏱️ Duración Estimada</th>
                <td>{{ $duracionEstimada ?? '-' }}</td>
            </tr>
            @if(isset($empresaContratista))
            <tr>
                <th>🏢 Empresa</th>
                <td>{{ $empresaContratista }}</td>
            </tr>
            @endif
        </table>
    </div>
    
    @if(isset($serviciosAfectados) && count($serviciosAfectados) > 0)
        <h3 style="color: {{ ($esEmergencia ?? false) ? '#dc2626' : '#111827' }};">⚡ Servicios que podrían verse afectados:</h3>
        <ul style="color: #4b5563; padding-left: 20px;">
            @foreach($serviciosAfectados as $servicio)
                <li style="margin-bottom: 4px;">{{ $servicio }}</li>
            @endforeach
        </ul>
    @endif
    
    @if(isset($recomendaciones) && count($recomendaciones) > 0)
        <div class="highlight-box warning">
            <p style="margin: 0 0 12px 0; font-weight: 600;">📋 Recomendaciones:</p>
            <ul style="margin: 0; padding-left: 20px; color: #4b5563;">
                @foreach($recomendaciones as $recomendacion)
                    <li style="margin-bottom: 4px;">{{ $recomendacion }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    
    @if(isset($descripcionTrabajo))
        <p><strong>Descripción del trabajo:</strong></p>
        <p style="background-color: #f9fafb; padding: 16px; border-radius: 8px; color: #4b5563;">
            {{ $descripcionTrabajo }}
        </p>
    @endif
    
    @if($esEmergencia ?? false)
        <p style="color: #dc2626; font-weight: 600;">
            Pedimos disculpas por los inconvenientes. Esta mantención es necesaria para garantizar la seguridad y funcionamiento del edificio.
        </p>
    @endif
    
    <div class="divider"></div>
    
    <p><strong>Contacto para consultas:</strong></p>
    <p>
        👤 {{ $contactoNombre ?? 'Administración' }}<br>
        📞 {{ $contactoTelefono ?? '+56 2 XXXX XXXX' }}<br>
        📧 {{ $contactoEmail ?? 'administracion@edificio.cl' }}
    </p>
    
    @if(!($esEmergencia ?? false))
        <p class="text-muted" style="font-size: 12px;">
            Las mantenciones programadas forman parte del plan de mantenimiento preventivo del edificio, 
            contribuyendo a preservar el valor de su propiedad y garantizar el buen funcionamiento de las instalaciones.
        </p>
    @endif
@endsection
