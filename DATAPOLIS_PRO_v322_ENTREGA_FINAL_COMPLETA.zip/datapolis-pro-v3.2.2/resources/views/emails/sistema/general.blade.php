@extends('emails.layout')

@section('titulo', $titulo ?? 'Notificación del Sistema')

@section('contenido')
    <h2>{{ $saludo ?? 'Estimado/a Usuario/a' }},</h2>
    
    @if(isset($mensajePrincipal))
        <p>{{ $mensajePrincipal }}</p>
    @endif
    
    @if(isset($contenidoHtml))
        {!! $contenidoHtml !!}
    @endif
    
    @if(isset($datosTabla) && is_array($datosTabla) && count($datosTabla) > 0)
        <div class="highlight-box">
            <table class="data-table" style="margin: 0;">
                @foreach($datosTabla as $label => $valor)
                    <tr>
                        <th>{{ $label }}</th>
                        <td>{{ $valor }}</td>
                    </tr>
                @endforeach
            </table>
        </div>
    @endif
    
    @if(isset($listaItems) && is_array($listaItems) && count($listaItems) > 0)
        <ul style="color: #4b5563; padding-left: 20px;">
            @foreach($listaItems as $item)
                <li style="margin-bottom: 8px;">{{ $item }}</li>
            @endforeach
        </ul>
    @endif
    
    @if(isset($destacado))
        <div class="highlight-box {{ $destacadoTipo ?? '' }}">
            <p style="margin: 0;">{{ $destacado }}</p>
        </div>
    @endif
    
    @if(isset($botonPrincipal) && isset($botonUrl))
        <div class="text-center">
            <a href="{{ $botonUrl }}" class="btn {{ $botonClase ?? 'btn-primary' }}">{{ $botonPrincipal }}</a>
        </div>
    @endif
    
    @if(isset($botonSecundario) && isset($botonSecundarioUrl))
        <div class="text-center">
            <a href="{{ $botonSecundarioUrl }}" class="btn btn-secondary">{{ $botonSecundario }}</a>
        </div>
    @endif
    
    @if(isset($mensajeSecundario))
        <p class="text-muted">{{ $mensajeSecundario }}</p>
    @endif
    
    @if(isset($firma))
        <div class="divider"></div>
        <p>
            Atentamente,<br>
            <strong>{{ $firma }}</strong>
        </p>
    @endif
@endsection

@section('footer')
    <p><strong>{{ $edificioNombre ?? 'DATAPOLIS PRO' }}</strong></p>
    
    @if(isset($infoAdicionalFooter))
        <p>{{ $infoAdicionalFooter }}</p>
    @endif
    
    <p>
        @if(isset($urlPreferencias))
            <a href="{{ $urlPreferencias }}">Gestionar preferencias</a> |
        @endif
        @if(isset($urlPortal))
            <a href="{{ $urlPortal }}">Acceder al portal</a> |
        @endif
        @if(isset($urlAyuda))
            <a href="{{ $urlAyuda }}">Centro de ayuda</a>
        @endif
    </p>
    
    <div class="divider"></div>
    
    <p class="text-muted">
        © {{ date('Y') }} DATAPOLIS PRO - Gestión Inteligente de Condominios<br>
        <small>Conforme a Ley 21.442 de Copropiedad Inmobiliaria</small>
    </p>
    
    @if(isset($idNotificacion))
        <p class="text-muted" style="font-size: 11px;">
            ID: {{ $idNotificacion }}
        </p>
    @endif
@endsection
