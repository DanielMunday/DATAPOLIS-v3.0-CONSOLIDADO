<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Certificado de Distribución de Ingresos por Arriendos</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Helvetica', 'Arial', sans-serif;
            font-size: 10pt;
            line-height: 1.4;
            color: #333;
            padding: 20px;
        }
        .header {
            text-align: center;
            border-bottom: 3px solid #1a365d;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .header h1 {
            font-size: 14pt;
            color: #1a365d;
            margin-bottom: 5px;
        }
        .header h2 {
            font-size: 11pt;
            color: #2c5282;
            font-weight: normal;
        }
        .legal-badge {
            background: #e6fffa;
            border: 1px solid #38b2ac;
            border-radius: 4px;
            padding: 8px 15px;
            text-align: center;
            margin: 15px 0;
            font-size: 9pt;
        }
        .legal-badge strong {
            color: #234e52;
        }
        .info-grid {
            display: table;
            width: 100%;
            margin-bottom: 15px;
        }
        .info-row {
            display: table-row;
        }
        .info-cell {
            display: table-cell;
            padding: 5px 10px;
            border-bottom: 1px solid #e2e8f0;
        }
        .info-cell.label {
            background: #f7fafc;
            font-weight: bold;
            width: 35%;
            color: #4a5568;
        }
        .section {
            margin: 20px 0;
        }
        .section-title {
            background: #1a365d;
            color: white;
            padding: 8px 15px;
            font-size: 11pt;
            font-weight: bold;
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        th {
            background: #2c5282;
            color: white;
            padding: 8px;
            text-align: left;
            font-size: 9pt;
        }
        td {
            padding: 6px 8px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 9pt;
        }
        tr:nth-child(even) {
            background: #f7fafc;
        }
        .amount {
            text-align: right;
            font-family: 'Courier New', monospace;
        }
        .total-row {
            background: #edf2f7 !important;
            font-weight: bold;
        }
        .highlight-box {
            border: 2px solid #38a169;
            background: #f0fff4;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }
        .highlight-box.warning {
            border-color: #d69e2e;
            background: #fffff0;
        }
        .highlight-box h4 {
            color: #22543d;
            margin-bottom: 10px;
        }
        .highlight-box.warning h4 {
            color: #744210;
        }
        .summary-grid {
            display: table;
            width: 100%;
        }
        .summary-item {
            display: table-cell;
            text-align: center;
            padding: 10px;
            border: 1px solid #e2e8f0;
        }
        .summary-item .value {
            font-size: 14pt;
            font-weight: bold;
            color: #1a365d;
        }
        .summary-item .label {
            font-size: 8pt;
            color: #718096;
        }
        .verification {
            background: #2d3748;
            color: white;
            padding: 15px;
            text-align: center;
            margin-top: 20px;
        }
        .verification .code {
            font-family: 'Courier New', monospace;
            font-size: 16pt;
            letter-spacing: 3px;
            margin: 10px 0;
        }
        .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #e2e8f0;
            font-size: 8pt;
            color: #718096;
        }
        .legal-note {
            background: #ebf8ff;
            border-left: 4px solid #3182ce;
            padding: 10px 15px;
            margin: 15px 0;
            font-size: 8pt;
        }
        .qr-placeholder {
            width: 80px;
            height: 80px;
            border: 1px solid #ccc;
            display: inline-block;
            vertical-align: middle;
            margin-right: 15px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>CERTIFICADO DE DISTRIBUCIÓN DE INGRESOS POR ARRIENDOS</h1>
        <h2>Comunidades de Copropietarios - Ley 21.713</h2>
    </div>

    <div class="legal-badge">
        <strong>BASE LEGAL:</strong> Artículo 17 N°3 de la Ley sobre Impuesto a la Renta, modificado por Ley 21.713
    </div>

    <!-- Datos del Edificio -->
    <div class="section">
        <div class="section-title">DATOS DE LA COMUNIDAD</div>
        <div class="info-grid">
            <div class="info-row">
                <div class="info-cell label">Comunidad:</div>
                <div class="info-cell">{{ $certificado->edificio_nombre }}</div>
            </div>
            <div class="info-row">
                <div class="info-cell label">RUT Comunidad:</div>
                <div class="info-cell">{{ $certificado->edificio_rut }}</div>
            </div>
            <div class="info-row">
                <div class="info-cell label">Dirección:</div>
                <div class="info-cell">{{ $certificado->edificio_direccion }}</div>
            </div>
        </div>
    </div>

    <!-- Datos del Copropietario -->
    <div class="section">
        <div class="section-title">DATOS DEL COPROPIETARIO</div>
        <div class="info-grid">
            <div class="info-row">
                <div class="info-cell label">Nombre/Razón Social:</div>
                <div class="info-cell">{{ $certificado->nombre_copropietario }}</div>
            </div>
            <div class="info-row">
                <div class="info-cell label">RUT:</div>
                <div class="info-cell">{{ $certificado->rut_copropietario }}</div>
            </div>
            <div class="info-row">
                <div class="info-cell label">Unidad:</div>
                <div class="info-cell">{{ $certificado->numero_unidad }}</div>
            </div>
            <div class="info-row">
                <div class="info-cell label">Porcentaje de Dominio:</div>
                <div class="info-cell">{{ number_format($certificado->porcentaje_dominio, 4) }}%</div>
            </div>
            <div class="info-row">
                <div class="info-cell label">Año Tributario:</div>
                <div class="info-cell">{{ $certificado->anio }}</div>
            </div>
        </div>
    </div>

    <!-- Resumen de Montos -->
    <div class="section">
        <div class="section-title">RESUMEN ANUAL DE DISTRIBUCIÓN</div>
        
        <div class="summary-grid">
            <div class="summary-item">
                <div class="value">${{ number_format($certificado->total_ingreso_bruto_arriendos, 0, ',', '.') }}</div>
                <div class="label">INGRESO BRUTO<br>POR ARRIENDOS</div>
            </div>
            <div class="summary-item">
                <div class="value">${{ number_format($certificado->total_traspasado_gc, 0, ',', '.') }}</div>
                <div class="label">TRASPASADO A<br>GASTOS COMUNES</div>
            </div>
            <div class="summary-item">
                <div class="value">${{ number_format($certificado->total_monto_art_17_n3, 0, ',', '.') }}</div>
                <div class="label">MONTO ART. 17 N°3<br>(NO RENTA)</div>
            </div>
            <div class="summary-item">
                <div class="value">${{ number_format($certificado->total_remanente_gravable, 0, ',', '.') }}</div>
                <div class="label">REMANENTE<br>(SÍ RENTA)</div>
            </div>
        </div>
    </div>

    <!-- Detalle Mensual -->
    <div class="section">
        <div class="section-title">DETALLE MENSUAL</div>
        <table>
            <thead>
                <tr>
                    <th>Mes</th>
                    <th style="text-align:right">Ingreso Arriendos</th>
                    <th style="text-align:right">Traspaso a GC</th>
                    <th style="text-align:right">Art. 17 N°3</th>
                    <th style="text-align:right">Remanente</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
                              'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
                @endphp
                @foreach($detalle_mensual as $mes)
                <tr>
                    <td>{{ $meses[$mes['mes'] - 1] }}</td>
                    <td class="amount">${{ number_format($mes['ingreso'], 0, ',', '.') }}</td>
                    <td class="amount">${{ number_format($mes['traspaso_gc'], 0, ',', '.') }}</td>
                    <td class="amount">${{ number_format($mes['traspaso_gc'], 0, ',', '.') }}</td>
                    <td class="amount">${{ number_format($mes['remanente'], 0, ',', '.') }}</td>
                </tr>
                @endforeach
                <tr class="total-row">
                    <td><strong>TOTAL ANUAL</strong></td>
                    <td class="amount"><strong>${{ number_format($certificado->total_ingreso_bruto_arriendos, 0, ',', '.') }}</strong></td>
                    <td class="amount"><strong>${{ number_format($certificado->total_traspasado_gc, 0, ',', '.') }}</strong></td>
                    <td class="amount"><strong>${{ number_format($certificado->total_monto_art_17_n3, 0, ',', '.') }}</strong></td>
                    <td class="amount"><strong>${{ number_format($certificado->total_remanente_gravable, 0, ',', '.') }}</strong></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Explicación Art. 17 N°3 -->
    <div class="highlight-box">
        <h4>✓ MONTO QUE NO CONSTITUYE RENTA (Art. 17 N°3 LIR)</h4>
        <p><strong>${{ number_format($certificado->total_monto_art_17_n3, 0, ',', '.') }}</strong></p>
        <p style="margin-top:8px; font-size:9pt;">
            Según el Art. 17 N°3 de la Ley sobre Impuesto a la Renta, modificado por Ley 21.713, 
            los ingresos por arriendos de bienes comunes que se destinan <strong>íntegramente</strong> 
            al pago de gastos comunes <strong>NO constituyen renta</strong> para el copropietario.
        </p>
        <p style="margin-top:5px; font-size:9pt;">
            Este monto <strong>NO debe declararse</strong> en el Formulario 22 de Renta Anual.
        </p>
    </div>

    @if($certificado->total_remanente_gravable > 0)
    <div class="highlight-box warning">
        <h4>⚠ REMANENTE QUE SÍ CONSTITUYE RENTA</h4>
        <p><strong>${{ number_format($certificado->total_remanente_gravable, 0, ',', '.') }}</strong></p>
        <p style="margin-top:8px; font-size:9pt;">
            El remanente (excedente no utilizado en gastos comunes) <strong>SÍ constituye renta</strong> 
            y debe ser declarado por el copropietario en su Declaración Anual de Impuesto a la Renta (F22).
        </p>
        @if($certificado->total_ppm_retenido > 0)
        <p style="margin-top:5px; font-size:9pt;">
            <strong>PPM Retenido:</strong> ${{ number_format($certificado->total_ppm_retenido, 0, ',', '.') }}
        </p>
        @endif
    </div>
    @endif

    <!-- Nota Legal -->
    <div class="legal-note">
        <strong>NOTA LEGAL:</strong> Este certificado se emite para efectos tributarios en cumplimiento de la 
        Ley 21.713 sobre Cumplimiento de Obligaciones Tributarias. El contribuyente es responsable de verificar 
        los montos y realizar su declaración de impuestos según corresponda. La comunidad de copropietarios 
        informará estos valores al Servicio de Impuestos Internos mediante la Declaración Jurada correspondiente.
    </div>

    <!-- Verificación -->
    <div class="verification">
        <div style="display: inline-block; text-align: left;">
            <div class="qr-placeholder">[QR]</div>
            <div style="display: inline-block; vertical-align: middle;">
                <p><strong>CÓDIGO DE VERIFICACIÓN</strong></p>
                <p class="code">{{ $certificado->codigo_verificacion }}</p>
                <p style="font-size:8pt;">Certificado N°: {{ $certificado->numero_certificado }}</p>
                <p style="font-size:8pt;">Fecha de emisión: {{ \Carbon\Carbon::parse($certificado->fecha_certificado)->format('d/m/Y') }}</p>
            </div>
        </div>
    </div>

    <!-- Pie de página -->
    <div class="footer">
        <p>Este documento ha sido generado electrónicamente por DATAPOLIS PRO.</p>
        <p>Para verificar su autenticidad, ingrese el código de verificación en: www.datapolis.cl/verificar</p>
        <p style="margin-top:10px;">
            <strong>Base Legal:</strong> Ley 21.713 (Cumplimiento Tributario) | Ley 21.442 (Copropiedad Inmobiliaria) | 
            DS 7-2025 (Reglamento de Copropiedad)
        </p>
    </div>
</body>
</html>
