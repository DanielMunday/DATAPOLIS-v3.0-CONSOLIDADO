<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Planilla de Distribución de Ingresos por Arriendos - Formato SII</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        @page {
            size: landscape;
            margin: 15mm;
        }
        body {
            font-family: 'Helvetica', 'Arial', sans-serif;
            font-size: 8pt;
            line-height: 1.3;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #1a365d;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        .header h1 {
            font-size: 12pt;
            color: #1a365d;
        }
        .header h2 {
            font-size: 10pt;
            color: #2c5282;
            font-weight: normal;
        }
        .info-box {
            background: #f7fafc;
            border: 1px solid #e2e8f0;
            padding: 10px;
            margin-bottom: 15px;
        }
        .info-grid {
            display: table;
            width: 100%;
        }
        .info-col {
            display: table-cell;
            width: 33.33%;
            vertical-align: top;
        }
        .info-item {
            margin-bottom: 5px;
        }
        .info-item .label {
            font-weight: bold;
            color: #4a5568;
            font-size: 7pt;
        }
        .legal-banner {
            background: #1a365d;
            color: white;
            padding: 8px 15px;
            text-align: center;
            margin-bottom: 15px;
            font-size: 9pt;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            font-size: 7pt;
        }
        th {
            background: #2c5282;
            color: white;
            padding: 5px 3px;
            text-align: center;
            font-size: 7pt;
            border: 1px solid #1a365d;
        }
        th.sub {
            background: #4a5568;
            font-size: 6pt;
        }
        td {
            padding: 4px 3px;
            border: 1px solid #e2e8f0;
            font-size: 7pt;
        }
        td.amount {
            text-align: right;
            font-family: 'Courier New', monospace;
        }
        td.center {
            text-align: center;
        }
        tr:nth-child(even) {
            background: #f7fafc;
        }
        tr.total {
            background: #edf2f7;
            font-weight: bold;
        }
        tr.total td {
            border-top: 2px solid #2c5282;
        }
        .summary-section {
            margin-top: 20px;
            page-break-inside: avoid;
        }
        .summary-title {
            background: #38a169;
            color: white;
            padding: 5px 10px;
            font-weight: bold;
            font-size: 9pt;
        }
        .summary-title.warning {
            background: #d69e2e;
        }
        .summary-content {
            border: 1px solid #e2e8f0;
            padding: 10px;
        }
        .summary-grid {
            display: table;
            width: 100%;
        }
        .summary-item {
            display: table-cell;
            text-align: center;
            padding: 10px;
            border-right: 1px solid #e2e8f0;
        }
        .summary-item:last-child {
            border-right: none;
        }
        .summary-item .value {
            font-size: 11pt;
            font-weight: bold;
            color: #1a365d;
        }
        .summary-item .label {
            font-size: 7pt;
            color: #718096;
        }
        .footer {
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #e2e8f0;
            font-size: 7pt;
            color: #718096;
        }
        .legal-notes {
            background: #ebf8ff;
            border-left: 3px solid #3182ce;
            padding: 8px 12px;
            margin-top: 15px;
            font-size: 7pt;
        }
        .page-break {
            page-break-before: always;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>PLANILLA DE DISTRIBUCIÓN DE INGRESOS POR ARRIENDOS DE BIENES COMUNES</h1>
        <h2>Formato para presentación ante el Servicio de Impuestos Internos (SII)</h2>
    </div>

    <div class="legal-banner">
        LEY 21.713 - ARTÍCULO 17 N°3 DE LA LEY SOBRE IMPUESTO A LA RENTA
    </div>

    <!-- Información del Edificio -->
    <div class="info-box">
        <div class="info-grid">
            <div class="info-col">
                <div class="info-item">
                    <div class="label">COMUNIDAD DE COPROPIETARIOS</div>
                    <div>{{ $planilla['edificio']['nombre'] }}</div>
                </div>
                <div class="info-item">
                    <div class="label">RUT COMUNIDAD</div>
                    <div>{{ $planilla['edificio']['rut'] }}</div>
                </div>
            </div>
            <div class="info-col">
                <div class="info-item">
                    <div class="label">DIRECCIÓN</div>
                    <div>{{ $planilla['edificio']['direccion'] }}</div>
                </div>
                <div class="info-item">
                    <div class="label">AÑO TRIBUTARIO</div>
                    <div><strong>{{ $planilla['anio_tributario'] }}</strong></div>
                </div>
            </div>
            <div class="info-col">
                <div class="info-item">
                    <div class="label">FECHA DE GENERACIÓN</div>
                    <div>{{ $planilla['fecha_generacion'] }}</div>
                </div>
                <div class="info-item">
                    <div class="label">TOTAL COPROPIETARIOS</div>
                    <div>{{ $planilla['cantidad_copropietarios'] }}</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabla Principal -->
    <table>
        <thead>
            <tr>
                <th rowspan="2" style="width:4%">N°</th>
                <th rowspan="2" style="width:6%">UNIDAD</th>
                <th rowspan="2" style="width:10%">RUT<br>COPROPIETARIO</th>
                <th rowspan="2" style="width:15%">NOMBRE/RAZÓN SOCIAL</th>
                <th rowspan="2" style="width:5%">%<br>DOMINIO</th>
                <th colspan="2" style="background:#38a169;">INGRESOS</th>
                <th colspan="2" style="background:#3182ce;">ART. 17 N°3 (NO RENTA)</th>
                <th colspan="3" style="background:#d69e2e;">GRAVABLE (SÍ RENTA)</th>
            </tr>
            <tr>
                <th class="sub" style="width:8%">INGRESO BRUTO<br>ARRIENDOS</th>
                <th class="sub" style="width:8%">TRASPASO<br>A GC</th>
                <th class="sub" style="width:8%">MONTO<br>NO RENTA</th>
                <th class="sub" style="width:8%">BASE<br>LEGAL</th>
                <th class="sub" style="width:8%">REMANENTE<br>GRAVABLE</th>
                <th class="sub" style="width:6%">PPM<br>RETENIDO</th>
                <th class="sub" style="width:7%">NETO<br>PAGADO</th>
            </tr>
        </thead>
        <tbody>
            @foreach($planilla['detalle'] as $index => $item)
            <tr>
                <td class="center">{{ $index + 1 }}</td>
                <td class="center">{{ $item->numero_unidad }}</td>
                <td class="center">{{ $item->rut_copropietario }}</td>
                <td>{{ $item->nombre_copropietario }}</td>
                <td class="center">{{ number_format($item->porcentaje_dominio, 2) }}%</td>
                <td class="amount">${{ number_format($item->total_ingreso_bruto_arriendos, 0, ',', '.') }}</td>
                <td class="amount">${{ number_format($item->total_traspasado_gc, 0, ',', '.') }}</td>
                <td class="amount">${{ number_format($item->total_monto_art_17_n3, 0, ',', '.') }}</td>
                <td class="center" style="font-size:6pt;">Art.17 N°3</td>
                <td class="amount">${{ number_format($item->total_remanente_gravable, 0, ',', '.') }}</td>
                <td class="amount">${{ number_format($item->total_ppm_retenido, 0, ',', '.') }}</td>
                <td class="amount">${{ number_format($item->total_neto_pagado, 0, ',', '.') }}</td>
            </tr>
            @endforeach
            <tr class="total">
                <td colspan="5" style="text-align:right;"><strong>TOTALES:</strong></td>
                <td class="amount"><strong>${{ number_format($planilla['totales']['total_ingreso_bruto'], 0, ',', '.') }}</strong></td>
                <td class="amount"><strong>${{ number_format($planilla['totales']['total_traspasado_gc'], 0, ',', '.') }}</strong></td>
                <td class="amount"><strong>${{ number_format($planilla['totales']['total_art_17_n3'], 0, ',', '.') }}</strong></td>
                <td></td>
                <td class="amount"><strong>${{ number_format($planilla['totales']['total_remanente'], 0, ',', '.') }}</strong></td>
                <td class="amount"><strong>${{ number_format($planilla['totales']['total_ppm'], 0, ',', '.') }}</strong></td>
                <td class="amount"><strong>${{ number_format($planilla['totales']['total_neto'], 0, ',', '.') }}</strong></td>
            </tr>
        </tbody>
    </table>

    <!-- Resumen -->
    <div class="summary-section">
        <div class="summary-title">RESUMEN - MONTOS QUE NO CONSTITUYEN RENTA (Art. 17 N°3 LIR)</div>
        <div class="summary-content">
            <div class="summary-grid">
                <div class="summary-item">
                    <div class="value">${{ number_format($planilla['totales']['total_ingreso_bruto'], 0, ',', '.') }}</div>
                    <div class="label">TOTAL INGRESOS BRUTOS<br>POR ARRIENDOS</div>
                </div>
                <div class="summary-item">
                    <div class="value">${{ number_format($planilla['totales']['total_traspasado_gc'], 0, ',', '.') }}</div>
                    <div class="label">TOTAL TRASPASADO A<br>GASTOS COMUNES</div>
                </div>
                <div class="summary-item" style="background:#f0fff4;">
                    <div class="value" style="color:#22543d;">${{ number_format($planilla['totales']['total_art_17_n3'], 0, ',', '.') }}</div>
                    <div class="label">MONTO ART. 17 N°3<br><strong>NO CONSTITUYE RENTA</strong></div>
                </div>
            </div>
        </div>
    </div>

    <div class="summary-section">
        <div class="summary-title warning">RESUMEN - MONTOS GRAVABLES (SÍ CONSTITUYEN RENTA)</div>
        <div class="summary-content">
            <div class="summary-grid">
                <div class="summary-item" style="background:#fffff0;">
                    <div class="value" style="color:#744210;">${{ number_format($planilla['totales']['total_remanente'], 0, ',', '.') }}</div>
                    <div class="label">TOTAL REMANENTES<br><strong>SÍ CONSTITUYE RENTA</strong></div>
                </div>
                <div class="summary-item">
                    <div class="value">${{ number_format($planilla['totales']['total_ppm'], 0, ',', '.') }}</div>
                    <div class="label">TOTAL PPM<br>RETENIDO</div>
                </div>
                <div class="summary-item">
                    <div class="value">${{ number_format($planilla['totales']['total_neto'], 0, ',', '.') }}</div>
                    <div class="label">TOTAL NETO<br>PAGADO</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Notas Legales -->
    <div class="legal-notes">
        <p><strong>NOTAS LEGALES:</strong></p>
        <p style="margin-top:5px;">
            <strong>1. Art. 17 N°3 LIR (Ley 21.713):</strong> "No constituye renta... las sumas percibidas por los 
            copropietarios de edificios o condominios, provenientes del arriendo de bienes de dominio común, 
            en la parte que corresponda a la proporción de cada copropietario en dichos bienes comunes, 
            siempre que dichas sumas se destinen íntegramente al pago de los gastos comunes del respectivo edificio o condominio."
        </p>
        <p style="margin-top:5px;">
            <strong>2. Remanentes:</strong> Los excedentes no utilizados en el pago de gastos comunes SÍ constituyen renta 
            y deben ser declarados por cada copropietario en su Declaración Anual de Impuesto a la Renta (F22).
        </p>
        <p style="margin-top:5px;">
            <strong>3. Base Legal:</strong> Ley 21.713 | Ley 21.442 (Copropiedad Inmobiliaria) | DS 7-2025 (Reglamento) | 
            Circular SII N° 42/2024
        </p>
    </div>

    <!-- Pie de página -->
    <div class="footer">
        <p>Documento generado por DATAPOLIS PRO - Sistema de Gestión de Copropiedades</p>
        <p>Este documento tiene carácter de declaración jurada. La información contenida es responsabilidad del administrador de la comunidad.</p>
        <p>Para verificación, conserve este documento junto con los comprobantes de traspaso entre cuentas bancarias.</p>
    </div>
</body>
</html>
