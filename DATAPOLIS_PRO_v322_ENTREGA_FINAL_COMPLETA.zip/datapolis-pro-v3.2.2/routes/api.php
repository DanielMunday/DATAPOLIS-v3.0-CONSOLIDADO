<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\EdificioController;
use App\Http\Controllers\Api\UnidadController;
use App\Http\Controllers\Api\PersonaController;
use App\Http\Controllers\Api\GastosComunesController;
use App\Http\Controllers\Api\ArriendosController;
use App\Http\Controllers\Api\DistribucionController;
use App\Http\Controllers\Api\RRHHController;
use App\Http\Controllers\Api\ContabilidadController;
use App\Http\Controllers\Api\ReunionesController;
use App\Http\Controllers\Api\AsistenteLegalController;
use App\Http\Controllers\Api\ProteccionDatosController;
use App\Http\Controllers\Api\ReportesTributariosController;
use App\Http\Controllers\Api\CertificacionComplianceController;
use App\Http\Controllers\Api\NotificacionesController;
use App\Http\Controllers\Api\ReglamentoAnalisisController;
use App\Http\Controllers\Api\SimuladorSancionesController;

/*
|--------------------------------------------------------------------------
| DATAPOLIS PRO v3.0 - API Routes
|--------------------------------------------------------------------------
*/

// Health check
Route::get('/health', fn() => response()->json([
    'status' => 'ok',
    'timestamp' => now(),
    'version' => '3.0',
]));

// =========================================================================
// AUTENTICACIÓN
// =========================================================================
Route::prefix('auth')->group(function () {
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);
    
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/user', [AuthController::class, 'user']);
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::put('/profile', [AuthController::class, 'updateProfile']);
    });
});

// =========================================================================
// RUTAS PROTEGIDAS
// =========================================================================
Route::middleware('auth:sanctum')->group(function () {

    // -----------------------------------------------------------------
    // DASHBOARD
    // -----------------------------------------------------------------
    Route::prefix('dashboard')->group(function () {
        Route::get('/stats', [DashboardController::class, 'stats']);
        Route::get('/morosidad', [DashboardController::class, 'morosidad']);
        Route::get('/ingresos', [DashboardController::class, 'ingresos']);
        Route::get('/alertas', [DashboardController::class, 'alertas']);
    });

    // -----------------------------------------------------------------
    // EDIFICIOS
    // -----------------------------------------------------------------
    Route::apiResource('edificios', EdificioController::class);
    Route::get('edificios/{id}/estadisticas', [EdificioController::class, 'estadisticas']);

    // -----------------------------------------------------------------
    // UNIDADES
    // -----------------------------------------------------------------
    Route::apiResource('unidades', UnidadController::class);
    Route::get('unidades/{id}/estado-cuenta', [UnidadController::class, 'estadoCuenta']);
    Route::get('unidades/{id}/boletas', [UnidadController::class, 'boletas']);

    // -----------------------------------------------------------------
    // PERSONAS / COPROPIETARIOS
    // -----------------------------------------------------------------
    Route::apiResource('personas', PersonaController::class);

    // -----------------------------------------------------------------
    // GASTOS COMUNES
    // -----------------------------------------------------------------
    Route::prefix('gastos-comunes')->group(function () {
        // Períodos
        Route::get('/periodos', [GastosComunesController::class, 'periodos']);
        Route::post('/periodos', [GastosComunesController::class, 'crearPeriodo']);
        Route::get('/periodos/{id}', [GastosComunesController::class, 'showPeriodo']);
        Route::post('/periodos/{id}/generar-boletas', [GastosComunesController::class, 'generarBoletas']);
        Route::post('/periodos/{id}/cerrar', [GastosComunesController::class, 'cerrarPeriodo']);
        
        // Boletas
        Route::get('/boletas', [GastosComunesController::class, 'boletas']);
        Route::get('/boletas/{id}', [GastosComunesController::class, 'showBoleta']);
        Route::get('/boletas/{id}/pdf', [GastosComunesController::class, 'boletaPdf']);
        
        // Pagos
        Route::get('/pagos', [GastosComunesController::class, 'pagos']);
        Route::post('/pagos', [GastosComunesController::class, 'registrarPago']);
        Route::delete('/pagos/{id}', [GastosComunesController::class, 'anularPago']);
        
        // Morosidad
        Route::get('/morosidad', [GastosComunesController::class, 'morosidad']);
        Route::post('/morosidad/calcular-intereses', [GastosComunesController::class, 'calcularIntereses']);
    });

    // -----------------------------------------------------------------
    // ARRIENDOS Y CONTRATOS
    // -----------------------------------------------------------------
    Route::prefix('arriendos')->group(function () {
        Route::get('/contratos', [ArriendosController::class, 'contratos']);
        Route::post('/contratos', [ArriendosController::class, 'crearContrato']);
        Route::get('/contratos/{id}', [ArriendosController::class, 'showContrato']);
        Route::put('/contratos/{id}', [ArriendosController::class, 'updateContrato']);
        Route::post('/contratos/{id}/renovar', [ArriendosController::class, 'renovarContrato']);
        Route::post('/contratos/{id}/terminar', [ArriendosController::class, 'terminarContrato']);
        
        // Facturación
        Route::get('/facturacion', [ArriendosController::class, 'facturacion']);
        Route::post('/facturacion/generar', [ArriendosController::class, 'generarFacturacion']);
        Route::get('/facturacion/{id}/pdf', [ArriendosController::class, 'facturaPdf']);
    });

    // -----------------------------------------------------------------
    // DISTRIBUCIÓN LEY 21.713
    // -----------------------------------------------------------------
    Route::prefix('distribucion')->group(function () {
        Route::get('/', [DistribucionController::class, 'index']);
        Route::post('/calcular', [DistribucionController::class, 'calcular']);
        Route::get('/periodos', [DistribucionController::class, 'periodos']);
        Route::get('/periodos/{id}', [DistribucionController::class, 'showPeriodo']);
        Route::post('/periodos/{id}/aprobar', [DistribucionController::class, 'aprobarPeriodo']);
        Route::get('/certificados/{unidadId}', [DistribucionController::class, 'certificadoUnidad']);
    });

    // -----------------------------------------------------------------
    // RECURSOS HUMANOS
    // -----------------------------------------------------------------
    Route::prefix('rrhh')->group(function () {
        // Empleados
        Route::get('/empleados', [RRHHController::class, 'empleados']);
        Route::post('/empleados', [RRHHController::class, 'crearEmpleado']);
        Route::get('/empleados/{id}', [RRHHController::class, 'showEmpleado']);
        Route::put('/empleados/{id}', [RRHHController::class, 'updateEmpleado']);
        Route::post('/empleados/{id}/finiquito', [RRHHController::class, 'generarFiniquito']);
        
        // Liquidaciones
        Route::get('/liquidaciones', [RRHHController::class, 'liquidaciones']);
        Route::post('/liquidaciones/calcular', [RRHHController::class, 'calcularLiquidacion']);
        Route::get('/liquidaciones/{id}', [RRHHController::class, 'showLiquidacion']);
        Route::get('/liquidaciones/{id}/pdf', [RRHHController::class, 'liquidacionPdf']);
        Route::post('/liquidaciones/{id}/aprobar', [RRHHController::class, 'aprobarLiquidacion']);
        
        // Libro de remuneraciones
        Route::get('/libro-remuneraciones', [RRHHController::class, 'libroRemuneraciones']);
    });

    // -----------------------------------------------------------------
    // CONTABILIDAD
    // -----------------------------------------------------------------
    Route::prefix('contabilidad')->group(function () {
        // Plan de cuentas
        Route::get('/cuentas', [ContabilidadController::class, 'cuentas']);
        Route::post('/cuentas', [ContabilidadController::class, 'crearCuenta']);
        Route::put('/cuentas/{id}', [ContabilidadController::class, 'updateCuenta']);
        
        // Asientos
        Route::get('/asientos', [ContabilidadController::class, 'asientos']);
        Route::post('/asientos', [ContabilidadController::class, 'crearAsiento']);
        Route::get('/asientos/{id}', [ContabilidadController::class, 'showAsiento']);
        Route::post('/asientos/{id}/anular', [ContabilidadController::class, 'anularAsiento']);
        
        // Libro Mayor
        Route::get('/libro-mayor', [ContabilidadController::class, 'libroMayor']);
        Route::get('/libro-diario', [ContabilidadController::class, 'libroDiario']);
        
        // Estados Financieros
        Route::get('/balance', [ContabilidadController::class, 'balance']);
        Route::get('/estado-resultados', [ContabilidadController::class, 'estadoResultados']);
        
        // Cierres
        Route::post('/cierre-mensual', [ContabilidadController::class, 'cierreMensual']);
        Route::post('/cierre-anual', [ContabilidadController::class, 'cierreAnual']);
    });

    // -----------------------------------------------------------------
    // REUNIONES Y ASAMBLEAS
    // -----------------------------------------------------------------
    Route::prefix('reuniones')->group(function () {
        Route::get('/', [ReunionesController::class, 'index']);
        Route::post('/', [ReunionesController::class, 'crear']);
        Route::get('/{id}', [ReunionesController::class, 'show']);
        Route::put('/{id}', [ReunionesController::class, 'update']);
        Route::post('/{id}/convocar', [ReunionesController::class, 'convocar']);
        Route::post('/{id}/iniciar', [ReunionesController::class, 'iniciar']);
        Route::post('/{id}/finalizar', [ReunionesController::class, 'finalizar']);
        Route::get('/{id}/acta', [ReunionesController::class, 'acta']);
        Route::get('/{id}/acta/pdf', [ReunionesController::class, 'actaPdf']);
        
        // Asistencia
        Route::post('/{id}/asistencia', [ReunionesController::class, 'registrarAsistencia']);
        
        // Votaciones
        Route::post('/{id}/votacion', [ReunionesController::class, 'crearVotacion']);
        Route::post('/votaciones/{votacionId}/votar', [ReunionesController::class, 'votar']);
    });

    // -----------------------------------------------------------------
    // PROTECCIÓN DE DATOS - LEY 21.719
    // -----------------------------------------------------------------
    Route::prefix('proteccion-datos')->group(function () {
        // Solicitudes ARCO+
        Route::get('/solicitudes', [ProteccionDatosController::class, 'solicitudes']);
        Route::post('/solicitudes', [ProteccionDatosController::class, 'crearSolicitud']);
        Route::get('/solicitudes/{id}', [ProteccionDatosController::class, 'showSolicitud']);
        Route::post('/solicitudes/{id}/responder', [ProteccionDatosController::class, 'responderSolicitud']);
        
        // Consentimientos
        Route::get('/consentimientos', [ProteccionDatosController::class, 'consentimientos']);
        Route::post('/consentimientos', [ProteccionDatosController::class, 'registrarConsentimiento']);
        Route::post('/consentimientos/{id}/revocar', [ProteccionDatosController::class, 'revocarConsentimiento']);
        
        // Brechas
        Route::get('/brechas', [ProteccionDatosController::class, 'brechas']);
        Route::post('/brechas', [ProteccionDatosController::class, 'reportarBrecha']);
        Route::put('/brechas/{id}', [ProteccionDatosController::class, 'updateBrecha']);
        
        // Registro de tratamiento
        Route::get('/registro-tratamiento', [ProteccionDatosController::class, 'registroTratamiento']);
    });

    // -----------------------------------------------------------------
    // REPORTES TRIBUTARIOS - LEY 21.713
    // -----------------------------------------------------------------
    Route::prefix('reportes-tributarios')->group(function () {
        Route::get('/balance-sii', [ReportesTributariosController::class, 'balanceSII']);
        Route::get('/estado-resultados-sii', [ReportesTributariosController::class, 'estadoResultadosSII']);
        Route::get('/dj1887', [ReportesTributariosController::class, 'dj1887']);
        Route::get('/dj1887/csv', [ReportesTributariosController::class, 'dj1887Csv']);
        Route::get('/certificados-renta', [ReportesTributariosController::class, 'certificadosRenta']);
        Route::get('/certificados-renta/{unidadId}', [ReportesTributariosController::class, 'certificadoRentaUnidad']);
        Route::get('/certificados-renta/{unidadId}/pdf', [ReportesTributariosController::class, 'certificadoRentaPdf']);
        Route::get('/certificados-no-deuda/{unidadId}', [ReportesTributariosController::class, 'certificadoNoDeuda']);
        Route::get('/checklist-cumplimiento', [ReportesTributariosController::class, 'checklistCumplimiento']);
    });

    // -----------------------------------------------------------------
    // COMPLIANCE Y CERTIFICACIÓN
    // -----------------------------------------------------------------
    Route::prefix('compliance')->group(function () {
        // Análisis de reglamentos
        Route::post('/reglamentos/analizar', [ReglamentoAnalisisController::class, 'analizar']);
        Route::get('/reglamentos', [ReglamentoAnalisisController::class, 'listar']);
        Route::get('/reglamentos/{id}', [ReglamentoAnalisisController::class, 'show']);
        
        // Simulador de sanciones
        Route::post('/sanciones/simular', [SimuladorSancionesController::class, 'simular']);
        Route::get('/sanciones/historial', [SimuladorSancionesController::class, 'historial']);
        Route::get('/sanciones/valores-tributarios', [SimuladorSancionesController::class, 'valoresTributarios']);
        
        // Certificación
        Route::post('/certificados/emitir', [CertificacionComplianceController::class, 'emitir']);
        Route::get('/certificados', [CertificacionComplianceController::class, 'listar']);
        Route::get('/certificados/{id}', [CertificacionComplianceController::class, 'show']);
        Route::get('/certificados/{codigo}/verificar', [CertificacionComplianceController::class, 'verificar']);
        
        // Dashboard de compliance
        Route::get('/dashboard', [CertificacionComplianceController::class, 'dashboard']);
        Route::get('/alertas', [CertificacionComplianceController::class, 'alertas']);
    });

    // -----------------------------------------------------------------
    // NOTIFICACIONES
    // -----------------------------------------------------------------
    Route::prefix('notificaciones')->group(function () {
        Route::get('/', [NotificacionesController::class, 'index']);
        Route::post('/', [NotificacionesController::class, 'enviar']);
        Route::get('/plantillas', [NotificacionesController::class, 'plantillas']);
        Route::post('/plantillas', [NotificacionesController::class, 'crearPlantilla']);
        Route::get('/preferencias', [NotificacionesController::class, 'preferencias']);
        Route::put('/preferencias', [NotificacionesController::class, 'actualizarPreferencias']);
        Route::get('/historial', [NotificacionesController::class, 'historial']);
        Route::post('/programar', [NotificacionesController::class, 'programar']);
    });

    // -----------------------------------------------------------------
    // ASISTENTE LEGAL
    // -----------------------------------------------------------------
    Route::prefix('asistente-legal')->group(function () {
        Route::post('/consulta', [AsistenteLegalController::class, 'consulta']);
        Route::get('/leyes', [AsistenteLegalController::class, 'leyes']);
        Route::get('/articulos/{ley}', [AsistenteLegalController::class, 'articulos']);
    });
});

// =========================================================================
// RUTAS PÚBLICAS
// =========================================================================
Route::prefix('public')->group(function () {
    // Verificación de certificados
    Route::get('/verificar/{codigo}', [CertificacionComplianceController::class, 'verificarPublico']);
    
    // Valores tributarios
    Route::get('/valores-tributarios', [SimuladorSancionesController::class, 'valoresTributarios']);
});
