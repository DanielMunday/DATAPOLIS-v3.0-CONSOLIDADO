<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\SistemaBancarioTributarioController;
use App\Http\Controllers\Api\ImportadorCartolasController;
use App\Http\Controllers\Api\EspaciosArrendablesController;

/*
|--------------------------------------------------------------------------
| Rutas API - Módulos v3.1
| DATAPOLIS PRO
|--------------------------------------------------------------------------
|
| Nuevas rutas para:
| - Sistema Bancario y Tributario (Art. 17 N°3 LIR, Ley 21.713)
| - Importador de Cartolas Bancarias
| - Espacios Arrendables Ampliados
| - Reservas de Espacios
| - Contratos de Concesión
|
*/

Route::middleware(['auth:sanctum'])->prefix('api')->group(function () {

    // =========================================================================
    // SISTEMA BANCARIO
    // =========================================================================
    Route::prefix('bancos')->group(function () {
        
        // Cuentas Bancarias
        Route::get('cuentas', [SistemaBancarioTributarioController::class, 'listarCuentas']);
        Route::post('cuentas', [SistemaBancarioTributarioController::class, 'crearCuenta']);
        Route::get('cuentas/{id}', [SistemaBancarioTributarioController::class, 'mostrarCuenta']);
        Route::put('cuentas/{id}', [SistemaBancarioTributarioController::class, 'actualizarCuenta']);
        
        // Movimientos Bancarios
        Route::get('movimientos', [SistemaBancarioTributarioController::class, 'listarMovimientos']);
        Route::post('movimientos', [SistemaBancarioTributarioController::class, 'registrarMovimiento']);
        
        // Traspasos entre Cuentas (Art. 17 N°3)
        Route::get('traspasos', [SistemaBancarioTributarioController::class, 'listarTraspasos']);
        Route::post('traspasos/arriendos-gc', [SistemaBancarioTributarioController::class, 'crearTraspasoArriendosGC']);
        Route::post('traspasos/remanente-copropietario', [SistemaBancarioTributarioController::class, 'crearTraspasoRemanente']);
        Route::post('traspasos/{id}/aprobar', [SistemaBancarioTributarioController::class, 'aprobarTraspaso']);
        Route::post('traspasos/{id}/ejecutar', [SistemaBancarioTributarioController::class, 'ejecutarTraspaso']);
        Route::post('traspasos/{id}/rechazar', [SistemaBancarioTributarioController::class, 'rechazarTraspaso']);
        
        // Conciliación Bancaria
        Route::post('conciliacion/iniciar', [SistemaBancarioTributarioController::class, 'iniciarConciliacion']);
        Route::get('conciliacion', [SistemaBancarioTributarioController::class, 'obtenerConciliacion']);
        Route::post('conciliacion/conciliar-movimiento', [SistemaBancarioTributarioController::class, 'conciliarMovimiento']);
        Route::put('conciliacion/saldo-banco', [SistemaBancarioTributarioController::class, 'actualizarSaldoBanco']);
        
        // Importador de Cartolas
        Route::prefix('importador')->group(function () {
            Route::get('bancos', [ImportadorCartolasController::class, 'bancosSoportados']);
            Route::post('preview', [ImportadorCartolasController::class, 'preview']);
            Route::post('importar', [ImportadorCartolasController::class, 'importar']);
            Route::post('match', [ImportadorCartolasController::class, 'matchAutomatico']);
            Route::get('plantilla/{banco}', [ImportadorCartolasController::class, 'plantilla']);
            Route::get('plantilla/{banco}/csv', [ImportadorCartolasController::class, 'descargarPlantilla']);
        });
    });

    // =========================================================================
    // TRIBUTARIO
    // =========================================================================
    Route::prefix('tributario')->group(function () {
        
        // Distribución mensual Art. 17 N°3
        Route::post('distribucion-mensual', [SistemaBancarioTributarioController::class, 'procesarDistribucionMensual']);
        Route::get('planilla-distribucion', [SistemaBancarioTributarioController::class, 'obtenerPlanillaDistribucion']);
        
        // Resumen anual
        Route::post('resumen-anual', [SistemaBancarioTributarioController::class, 'generarResumenAnual']);
        
        // Planilla SII
        Route::get('planilla-sii', [SistemaBancarioTributarioController::class, 'obtenerPlanillaSII']);
        Route::get('planilla-sii/pdf', [SistemaBancarioTributarioController::class, 'descargarPlanillaSIIPdf']);
        
        // Certificados por copropietario
        Route::get('certificado/{unidadId}', [SistemaBancarioTributarioController::class, 'obtenerCertificadoCopropietario']);
        Route::get('certificado/{unidadId}/pdf', [SistemaBancarioTributarioController::class, 'descargarCertificadoPdf']);
        
        // PPM y retenciones
        Route::get('ppm', [SistemaBancarioTributarioController::class, 'listarPPM']);
        
        // Resumen tributario
        Route::get('resumen', [SistemaBancarioTributarioController::class, 'resumenTributario']);
    });

    // =========================================================================
    // ESPACIOS ARRENDABLES
    // =========================================================================
    Route::prefix('espacios')->group(function () {
        
        // Categorías y Tipos
        Route::get('categorias', [EspaciosArrendablesController::class, 'listarCategorias']);
        Route::get('tipos', [EspaciosArrendablesController::class, 'listarTiposEspacio']);
        
        // Espacios
        Route::get('/', [EspaciosArrendablesController::class, 'listarEspacios']);
        Route::post('/', [EspaciosArrendablesController::class, 'crearEspacio']);
        Route::get('/{id}', [EspaciosArrendablesController::class, 'mostrarEspacio']);
        Route::put('/{id}', [EspaciosArrendablesController::class, 'actualizarEspacio']);
        
        // Disponibilidad
        Route::get('/disponibilidad', [EspaciosArrendablesController::class, 'disponibilidadEspacio']);
    });

    // =========================================================================
    // RESERVAS
    // =========================================================================
    Route::prefix('reservas')->group(function () {
        Route::get('/', [EspaciosArrendablesController::class, 'listarReservas']);
        Route::post('/', [EspaciosArrendablesController::class, 'crearReserva']);
        Route::post('/{id}/confirmar', [EspaciosArrendablesController::class, 'confirmarReserva']);
        Route::post('/{id}/cancelar', [EspaciosArrendablesController::class, 'cancelarReserva']);
    });

    // =========================================================================
    // CONCESIONES
    // =========================================================================
    Route::prefix('concesiones')->group(function () {
        Route::get('/', [EspaciosArrendablesController::class, 'listarConcesiones']);
        Route::post('/', [EspaciosArrendablesController::class, 'crearConcesion']);
        Route::post('/{id}/activar', [EspaciosArrendablesController::class, 'activarConcesion']);
        Route::post('/pagos', [EspaciosArrendablesController::class, 'registrarPagoConcesion']);
    });
});
