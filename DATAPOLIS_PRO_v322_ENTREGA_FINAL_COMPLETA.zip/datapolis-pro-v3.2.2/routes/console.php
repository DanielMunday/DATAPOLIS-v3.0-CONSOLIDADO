<?php

use Illuminate\Support\Facades\Schedule;

// Calcular intereses de mora (diario a las 6:00 AM)
Schedule::command('datapolis:calcular-intereses')->dailyAt('06:00');

// Procesar notificaciones programadas (cada 5 minutos)
Schedule::command('datapolis:procesar-notificaciones')->everyFiveMinutes();

// Actualizar estado de boletas vencidas (diario)
Schedule::command('datapolis:actualizar-boletas-vencidas')->dailyAt('00:30');

// Alertas de vencimiento de contratos (semanal)
Schedule::command('datapolis:alertas-contratos')->weeklyOn(1, '08:00');

// Backup de base de datos (diario a las 3:00 AM)
Schedule::command('backup:run')->dailyAt('03:00');
