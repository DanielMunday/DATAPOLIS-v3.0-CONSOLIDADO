<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\Portal\PortalCopropietarioController;
use App\Http\Controllers\Api\Portal\EstadoCuentaController;
use App\Http\Controllers\Api\Portal\PagosOnlineController;
use App\Http\Controllers\Api\Portal\SolicitudesController;
use App\Http\Controllers\Api\Portal\DocumentosComunicadosController;

/*
|--------------------------------------------------------------------------
| DATAPOLIS PRO v3.0 - API Routes Portal Copropietarios
|--------------------------------------------------------------------------
*/

Route::prefix('portal')->name('portal.')->group(function () {

    // =========================================================
    // RUTAS PÚBLICAS (Sin autenticación)
    // =========================================================
    
    Route::post('/login', [PortalCopropietarioController::class, 'login'])
        ->name('login');
    
    Route::post('/registrar', [PortalCopropietarioController::class, 'registrar'])
        ->name('registrar');
    
    Route::post('/verificar-email', [PortalCopropietarioController::class, 'verificarEmail'])
        ->name('verificar-email');
    
    Route::post('/recuperar-password', [PortalCopropietarioController::class, 'solicitarRecuperacion'])
        ->name('recuperar-password');
    
    Route::post('/resetear-password', [PortalCopropietarioController::class, 'resetearPassword'])
        ->name('resetear-password');

    // Callbacks de pasarelas de pago (sin auth de portal)
    Route::get('/pagos/webpay/retorno', [PagosOnlineController::class, 'webpayRetorno'])
        ->name('pagos.webpay.retorno');
    
    Route::post('/pagos/khipu/notificacion', [PagosOnlineController::class, 'khipuNotificacion'])
        ->name('pagos.khipu.notificacion');

    // =========================================================
    // RUTAS PROTEGIDAS (Con autenticación)
    // =========================================================
    
    Route::middleware(['portal.auth'])->group(function () {

        // ---------------------------------------------------------
        // Autenticación y Perfil
        // ---------------------------------------------------------
        Route::post('/logout', [PortalCopropietarioController::class, 'logout'])
            ->name('logout');
        
        Route::get('/dashboard', [PortalCopropietarioController::class, 'dashboard'])
            ->name('dashboard');
        
        Route::get('/perfil', [PortalCopropietarioController::class, 'perfil'])
            ->name('perfil');
        
        Route::put('/perfil', [PortalCopropietarioController::class, 'actualizarPerfil'])
            ->name('perfil.actualizar');
        
        Route::post('/cambiar-password', [PortalCopropietarioController::class, 'cambiarPassword'])
            ->name('cambiar-password');

        // ---------------------------------------------------------
        // Estado de Cuenta y Boletas
        // ---------------------------------------------------------
        Route::prefix('estado-cuenta')->name('estado-cuenta.')->group(function () {
            Route::get('/', [EstadoCuentaController::class, 'index'])
                ->name('index');
            
            Route::get('/historial', [EstadoCuentaController::class, 'historial'])
                ->name('historial');
            
            Route::get('/boleta/{id}', [EstadoCuentaController::class, 'detalleBoleta'])
                ->name('boleta.detalle');
            
            Route::get('/boleta/{id}/pdf', [EstadoCuentaController::class, 'descargarBoletaPdf'])
                ->name('boleta.pdf');
            
            Route::get('/pdf', [EstadoCuentaController::class, 'descargarEstadoCuentaPdf'])
                ->name('pdf');
            
            Route::get('/pagos', [EstadoCuentaController::class, 'historialPagos'])
                ->name('pagos');
            
            Route::get('/certificado-no-deuda', [EstadoCuentaController::class, 'certificadoNoDeuda'])
                ->name('certificado-no-deuda');
        });

        // ---------------------------------------------------------
        // Pagos Online
        // ---------------------------------------------------------
        Route::prefix('pagos')->name('pagos.')->group(function () {
            Route::get('/opciones', [PagosOnlineController::class, 'opcionesPago'])
                ->name('opciones');
            
            Route::post('/iniciar', [PagosOnlineController::class, 'iniciarPago'])
                ->name('iniciar');
            
            Route::get('/estado/{codigo}', [PagosOnlineController::class, 'estadoTransaccion'])
                ->name('estado');
            
            Route::get('/historial', [PagosOnlineController::class, 'historialTransacciones'])
                ->name('historial');
            
            Route::get('/comprobante/{codigo}', [PagosOnlineController::class, 'descargarComprobante'])
                ->name('comprobante');
        });

        // ---------------------------------------------------------
        // Solicitudes y Reclamos
        // ---------------------------------------------------------
        Route::prefix('solicitudes')->name('solicitudes.')->group(function () {
            Route::get('/', [SolicitudesController::class, 'index'])
                ->name('index');
            
            Route::post('/', [SolicitudesController::class, 'store'])
                ->name('store');
            
            Route::get('/catalogos', [SolicitudesController::class, 'catalogos'])
                ->name('catalogos');
            
            Route::get('/{id}', [SolicitudesController::class, 'show'])
                ->name('show');
            
            Route::post('/{id}/comentario', [SolicitudesController::class, 'agregarComentario'])
                ->name('comentario');
            
            Route::post('/{id}/calificar', [SolicitudesController::class, 'calificar'])
                ->name('calificar');
            
            Route::post('/{id}/cerrar', [SolicitudesController::class, 'cerrar'])
                ->name('cerrar');
        });

        // ---------------------------------------------------------
        // Documentos Compartidos
        // ---------------------------------------------------------
        Route::prefix('documentos')->name('documentos.')->group(function () {
            Route::get('/', [DocumentosComunicadosController::class, 'documentos'])
                ->name('index');
            
            Route::get('/{id}/descargar', [DocumentosComunicadosController::class, 'descargarDocumento'])
                ->name('descargar');
        });

        // ---------------------------------------------------------
        // Comunicados
        // ---------------------------------------------------------
        Route::prefix('comunicados')->name('comunicados.')->group(function () {
            Route::get('/', [DocumentosComunicadosController::class, 'comunicados'])
                ->name('index');
            
            Route::get('/{id}', [DocumentosComunicadosController::class, 'verComunicado'])
                ->name('ver');
        });

        // ---------------------------------------------------------
        // Reservas de Espacios Comunes
        // ---------------------------------------------------------
        Route::prefix('reservas')->name('reservas.')->group(function () {
            Route::get('/espacios', [DocumentosComunicadosController::class, 'espaciosComunes'])
                ->name('espacios');
            
            Route::get('/espacios/{id}/disponibilidad', [DocumentosComunicadosController::class, 'disponibilidadEspacio'])
                ->name('disponibilidad');
            
            Route::post('/', [DocumentosComunicadosController::class, 'crearReserva'])
                ->name('crear');
            
            Route::get('/mis-reservas', [DocumentosComunicadosController::class, 'misReservas'])
                ->name('mis-reservas');
            
            Route::delete('/{id}', [DocumentosComunicadosController::class, 'cancelarReserva'])
                ->name('cancelar');
        });

        // ---------------------------------------------------------
        // Votaciones
        // ---------------------------------------------------------
        Route::prefix('votaciones')->name('votaciones.')->group(function () {
            Route::get('/', [DocumentosComunicadosController::class, 'votaciones'])
                ->name('index');
            
            Route::get('/{id}', [DocumentosComunicadosController::class, 'verVotacion'])
                ->name('ver');
            
            Route::post('/{id}/votar', [DocumentosComunicadosController::class, 'votar'])
                ->name('votar');
        });

        // ---------------------------------------------------------
        // Notificaciones
        // ---------------------------------------------------------
        Route::prefix('notificaciones')->name('notificaciones.')->group(function () {
            Route::get('/', [DocumentosComunicadosController::class, 'notificaciones'])
                ->name('index');
            
            Route::post('/{id}/leer', [DocumentosComunicadosController::class, 'marcarLeida'])
                ->name('leer');
            
            Route::post('/leer-todas', [DocumentosComunicadosController::class, 'marcarTodasLeidas'])
                ->name('leer-todas');
        });

    });
});
