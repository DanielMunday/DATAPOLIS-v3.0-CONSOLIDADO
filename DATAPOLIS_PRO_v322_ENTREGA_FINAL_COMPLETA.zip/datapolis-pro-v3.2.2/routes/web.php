<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return response()->json([
        'app' => 'DATAPOLIS PRO',
        'version' => '3.0',
        'api' => '/api',
    ]);
});
