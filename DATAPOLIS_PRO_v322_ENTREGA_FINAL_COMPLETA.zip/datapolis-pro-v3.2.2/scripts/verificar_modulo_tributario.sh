#!/bin/bash

# ============================================================
# DATAPOLIS PRO v3.2 - Script de Verificación Módulo Tributario
# ============================================================
# Verifica que todos los componentes del módulo tributario
# estén correctamente instalados y configurados.
#
# Uso: ./verificar_modulo_tributario.sh
# ============================================================

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Contadores
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNINGS=0

# Función para verificar archivo
check_file() {
    local file=$1
    local description=$2
    ((TOTAL_CHECKS++))
    
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $description"
        ((PASSED_CHECKS++))
        return 0
    else
        echo -e "${RED}✗${NC} $description - FALTA: $file"
        ((FAILED_CHECKS++))
        return 1
    fi
}

# Función para verificar directorio
check_dir() {
    local dir=$1
    local description=$2
    ((TOTAL_CHECKS++))
    
    if [ -d "$dir" ]; then
        echo -e "${GREEN}✓${NC} $description"
        ((PASSED_CHECKS++))
        return 0
    else
        echo -e "${RED}✗${NC} $description - FALTA: $dir"
        ((FAILED_CHECKS++))
        return 1
    fi
}

# Función para verificar contenido en archivo
check_content() {
    local file=$1
    local content=$2
    local description=$3
    ((TOTAL_CHECKS++))
    
    if grep -q "$content" "$file" 2>/dev/null; then
        echo -e "${GREEN}✓${NC} $description"
        ((PASSED_CHECKS++))
        return 0
    else
        echo -e "${RED}✗${NC} $description"
        ((FAILED_CHECKS++))
        return 1
    fi
}

# Función para advertencia
warn() {
    echo -e "${YELLOW}⚠${NC} $1"
    ((WARNINGS++))
}

# Header
echo ""
echo -e "${BLUE}=================================================================${NC}"
echo -e "${BLUE}  DATAPOLIS PRO v3.2 - Verificación Módulo Tributario${NC}"
echo -e "${BLUE}=================================================================${NC}"
echo ""

# ============================================================
# VERIFICAR BACKEND
# ============================================================
echo -e "${YELLOW}▶ Verificando Backend Laravel...${NC}"
echo ""

echo "  Servicios:"
check_file "app/Services/LibroIVAService.php" "    LibroIVAService"
check_file "app/Services/DeclaracionF29Service.php" "    DeclaracionF29Service"

echo ""
echo "  Controladores:"
check_file "app/Http/Controllers/Api/LibroIVAController.php" "    LibroIVAController"
check_file "app/Http/Controllers/Api/DeclaracionF29Controller.php" "    DeclaracionF29Controller"

echo ""
echo "  Rutas API:"
check_file "routes/api_tributario_v32.php" "    api_tributario_v32.php"
check_content "routes/api.php" "api_tributario_v32" "    Inclusión en api.php"

echo ""
echo "  Migraciones:"
check_file "database/migrations/2025_01_03_000003_create_libro_iva_tables.php" "    Libro IVA"
check_file "database/migrations/2025_01_03_000004_create_formulario_f29_tables.php" "    Formulario F29"
check_file "database/migrations/2025_01_03_000005_create_retenciones_honorarios_table.php" "    Retenciones"

echo ""
echo "  Seeders:"
check_file "database/seeders/ConfiguracionPPMSeeder.php" "    ConfiguracionPPMSeeder"
check_file "database/seeders/CodigosF29Seeder.php" "    CodigosF29Seeder"

echo ""
echo "  Vistas PDF:"
check_file "resources/views/pdf/libro-compras.blade.php" "    libro-compras.blade.php"
check_file "resources/views/pdf/libro-ventas.blade.php" "    libro-ventas.blade.php"
check_file "resources/views/pdf/formulario-f29.blade.php" "    formulario-f29.blade.php"

# ============================================================
# VERIFICAR FRONTEND
# ============================================================
echo ""
echo -e "${YELLOW}▶ Verificando Frontend React...${NC}"
echo ""

echo "  Páginas:"
check_file "frontend/src/pages/tributario/DashboardTributarioPage.tsx" "    DashboardTributarioPage"

echo ""
echo "  Componentes CRUD:"
check_dir "frontend/src/components/tributario" "    Directorio componentes"
check_file "frontend/src/components/tributario/FormularioCompraDialog.tsx" "    FormularioCompraDialog"
check_file "frontend/src/components/tributario/FormularioVentaDialog.tsx" "    FormularioVentaDialog"
check_file "frontend/src/components/tributario/FormularioRetencionDialog.tsx" "    FormularioRetencionDialog"
check_file "frontend/src/components/tributario/FormularioContribuyenteDialog.tsx" "    FormularioContribuyenteDialog"
check_file "frontend/src/components/tributario/FormularioF29Dialog.tsx" "    FormularioF29Dialog"
check_file "frontend/src/components/tributario/index.ts" "    index.ts (exports)"

echo ""
echo "  Servicios API:"
check_file "frontend/src/services/api/tributarioService.ts" "    tributarioService"

echo ""
echo "  Tipos TypeScript:"
check_file "frontend/src/types/tributario.types.ts" "    tributario.types.ts"

echo ""
echo "  Utilidades:"
check_file "frontend/src/utils/formatters.ts" "    formatters.ts"

# ============================================================
# VERIFICAR DOCUMENTACIÓN
# ============================================================
echo ""
echo -e "${YELLOW}▶ Verificando Documentación...${NC}"
echo ""

check_file "docs/MODULO_TRIBUTARIO_V32.md" "    Documentación técnica"
check_file "docs/GUIA_RAPIDA_TRIBUTARIO.md" "    Guía rápida usuario"

# ============================================================
# VERIFICAR DEPENDENCIAS FRONTEND
# ============================================================
echo ""
echo -e "${YELLOW}▶ Verificando Dependencias Frontend...${NC}"
echo ""

if [ -f "frontend/package.json" ]; then
    check_content "frontend/package.json" "@mui/material" "    Material-UI"
    check_content "frontend/package.json" "recharts" "    Recharts (gráficos)"
    
    # Verificar @mui/x-date-pickers (puede ser advertencia)
    if grep -q "@mui/x-date-pickers" frontend/package.json 2>/dev/null; then
        echo -e "${GREEN}✓${NC}     @mui/x-date-pickers"
        ((PASSED_CHECKS++))
        ((TOTAL_CHECKS++))
    else
        warn "    @mui/x-date-pickers no encontrado - ejecutar: npm install @mui/x-date-pickers date-fns"
        ((TOTAL_CHECKS++))
    fi
fi

# ============================================================
# RESUMEN
# ============================================================
echo ""
echo -e "${BLUE}=================================================================${NC}"
echo -e "${BLUE}  RESUMEN DE VERIFICACIÓN${NC}"
echo -e "${BLUE}=================================================================${NC}"
echo ""

echo -e "  Total verificaciones: ${TOTAL_CHECKS}"
echo -e "  ${GREEN}Exitosas: ${PASSED_CHECKS}${NC}"
echo -e "  ${RED}Fallidas: ${FAILED_CHECKS}${NC}"
echo -e "  ${YELLOW}Advertencias: ${WARNINGS}${NC}"
echo ""

# Calcular porcentaje
PERCENTAGE=$((PASSED_CHECKS * 100 / TOTAL_CHECKS))

if [ $FAILED_CHECKS -eq 0 ]; then
    echo -e "${GREEN}✓ MÓDULO TRIBUTARIO v3.2 - INSTALACIÓN COMPLETA (${PERCENTAGE}%)${NC}"
    echo ""
    echo "  Siguiente paso: Ejecutar migraciones y seeders:"
    echo "    php artisan migrate"
    echo "    php artisan db:seed --class=ConfiguracionPPMSeeder"
    echo "    php artisan db:seed --class=CodigosF29Seeder"
    echo ""
    exit 0
elif [ $FAILED_CHECKS -le 3 ]; then
    echo -e "${YELLOW}⚠ MÓDULO TRIBUTARIO v3.2 - INSTALACIÓN PARCIAL (${PERCENTAGE}%)${NC}"
    echo ""
    echo "  Revisar archivos faltantes antes de continuar."
    echo ""
    exit 1
else
    echo -e "${RED}✗ MÓDULO TRIBUTARIO v3.2 - INSTALACIÓN INCOMPLETA (${PERCENTAGE}%)${NC}"
    echo ""
    echo "  Múltiples archivos faltantes. Verificar instalación."
    echo ""
    exit 2
fi
