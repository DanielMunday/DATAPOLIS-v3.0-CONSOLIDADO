# -*- coding: utf-8 -*-
"""
DATAPOLIS v3.0 - Schemas Pydantic
=================================
Modelos de validación request/response para API REST
Versión: 3.0.0
Autor: Daniel (DATAPOLIS SpA)
Fecha: 2026-02-01

Compliance:
- Ley 21.442 (Copropiedad)
- Ley 21.713 (Tributario)
- Ley 21.719 (Datos Personales)
- IVS 2022 (Valorización)
"""

from .base import *
from .auth import *
from .indicadores import *
from .valorizacion import *
from .credit_score import *
from .propiedad import *
from .copropiedad import *
from .riesgos import *
from .agora import *
