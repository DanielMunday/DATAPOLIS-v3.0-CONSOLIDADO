# DATAPOLIS v3.0 - Ecosistema PropTech/FinTech/RegTech
## Sistema de Administración de Copropiedades para Chile

![Version](https://img.shields.io/badge/version-3.0.0-blue)
![Status](https://img.shields.io/badge/status-production--ready-green)
![License](https://img.shields.io/badge/license-proprietary-red)

---

## 📋 Resumen Ejecutivo

**DATAPOLIS v3.0** es un ecosistema integral para la administración de copropiedades en Chile, cumpliendo con la **Ley 21.442**, **DS 7/2025** y normativa **SII**. Incluye 23 módulos integrados, motor de análisis precesional (PAE), contabilidad completa por copropiedad, y sincronización con ÁGORA para inteligencia territorial.

---

## 🏗️ Arquitectura del Sistema

```
┌────────────────────────────────────────────────────────────┐
│                    DATAPOLIS v3.0                          │
├────────────────────────────────────────────────────────────┤
│  Frontend: Next.js 14 / React Native                       │
│  Backend:  Laravel 11 / PHP 8.3                            │
│  Database: MySQL 8.0 / PostgreSQL 15                       │
│  Cache:    Redis 7                                          │
│  Queue:    Laravel Horizon                                  │
├────────────────────────────────────────────────────────────┤
│  PAE Engine: PHP Nativo (4 engines, ~4,000 líneas)         │
│  ÁGORA:      Inteligencia Territorial                      │
│  Multi-Agente: 10 módulos + RLM Engine                     │
└────────────────────────────────────────────────────────────┘
```

---

## 📦 Contenido del Repositorio

### Código Fuente

| Archivo | Descripción | Líneas |
|---------|-------------|--------|
| `app/Models/AllModels.php` | 50+ modelos Eloquent con relaciones | ~1,500 |
| `app/Http/Controllers/Api/AllControllers.php` | 10 controladores principales | ~1,200 |
| `app/Services/AllServices.php` | Servicios de negocio | ~1,000 |
| `app/Services/PAE/PaeEngines.php` | Motor PAE nativo | ~800 |
| `routes/api.php` | 100+ endpoints REST | ~250 |
| `database/migrations/*.php` | Migración maestra (60+ tablas) | ~1,800 |
| `database/seeders/AllSeeders.php` | Datos iniciales | ~800 |

### Documentación

| Documento | Descripción |
|-----------|-------------|
| `docs/CIERRE_FINAL.md` | Matriz de avance 100%, especificaciones |
| `docs/MASTER_PLAN.md` | Arquitectura, flujos, escalabilidad |
| `docs/PAPERS_METODOLOGICOS.md` | 22 papers por módulo |
| `docs/GUIA_INSTALACION_CPANEL.md` | Instalación paso a paso |

---

## 🎯 23 Módulos al 100%

| # | Módulo | Estado |
|---|--------|--------|
| M01 | Infraestructura Multi-Tenant | ✅ 100% |
| M02 | Usuarios y Autenticación | ✅ 100% |
| M03 | Copropiedades (Core) | ✅ 100% |
| M04 | **Antenas y Telecomunicaciones** | ✅ 100% |
| M05 | Gastos Comunes | ✅ 100% |
| M06 | Morosidad y Cobranza | ✅ 100% |
| M07 | Proveedores y Contratos | ✅ 100% |
| M08 | **Contabilidad por Copropiedad** | ✅ 100% |
| M09 | **Certificados Tributarios** | ✅ 100% |
| M10 | **Declaraciones Juradas SII** | ✅ 100% |
| M11 | Fondo de Reserva (Ley 21.442) | ✅ 100% |
| M12 | Asambleas y Actas | ✅ 100% |
| M13 | **Compliance y Normativa** | ✅ 100% |
| M14 | Valorización y Avalúos | ✅ 100% |
| M15 | **PAE - Precession Analytics** | ✅ 100% |
| M16 | Arriendos y Contratos | ✅ 100% |
| M17 | Mantenciones y OT | ✅ 100% |
| M18 | Comunicaciones | ✅ 100% |
| M19 | Reportes y Dashboards | ✅ 100% |
| M20 | Documentos y Archivos | ✅ 100% |
| M21 | Configuraciones | ✅ 100% |
| M22 | Notificaciones | ✅ 100% |
| M23 | Jobs y Automatizaciones | ✅ 100% |

---

## 🔑 Funcionalidades Clave

### Submódulo Antenas (M04)
- Gestión completa de contratos con operadores de telecomunicaciones
- Tratamiento tributario IVA según Ley de Rentas
- Facturación mensual automática con envío a SII
- Distribución de ingresos: Fondo Común, Fondo Reserva, Propietarios
- Contabilización automática

### Contabilidad (M08)
- Plan de cuentas estándar (40+ cuentas)
- Asientos automáticos desde documentos fuente
- Libros: Diario, Mayor, Balance, Estado de Resultados
- Cierre de períodos con validaciones
- Saldos actualizados en tiempo real

### PAE - Precession Analytics (M15)
- **PrecessionGraphEngine**: Ontología de 12+ nodos y 15+ aristas
- **PrecessionScoringEngine**: Scores multi-dimensionales
- **PrecessionAlertEngine**: Alertas por vencimientos, riesgos, oportunidades
- **PrecessionSyncService**: Integración con ÁGORA
- Análisis BFS hasta 4 niveles de profundidad

### Compliance (M13)
- Evaluación automática multi-dimensión
- Ley 21.442, DS 7/2025, SII, Contable, Transparencia
- Score global 0-100
- Brechas identificadas con severidad
- Plan de acción con plazos

---

## 🚀 Instalación Rápida

### Requisitos
- PHP 8.2+
- MySQL 8.0+ o PostgreSQL 15+
- Composer 2.x
- Node.js 18+ (para frontend)

### Pasos

```bash
# 1. Clonar repositorio
git clone https://github.com/datapolis/datapolis-v3.git
cd datapolis-v3

# 2. Instalar dependencias
composer install

# 3. Configurar entorno
cp .env.example .env
php artisan key:generate

# 4. Configurar base de datos en .env
# DB_DATABASE=datapolis
# DB_USERNAME=usuario
# DB_PASSWORD=password

# 5. Ejecutar migraciones
php artisan migrate --force
php artisan db:seed --force

# 6. Iniciar servidor
php artisan serve
```

### Acceso Inicial
```
URL: http://localhost:8000
Email: admin@datapolis.cl
Password: DataPolis2024!
```

---

## 📊 API Endpoints

### Autenticación
```
POST /api/v1/auth/login
POST /api/v1/auth/logout
GET  /api/v1/auth/me
```

### Copropiedades
```
GET    /api/v1/copropiedades
POST   /api/v1/copropiedades
GET    /api/v1/copropiedades/{id}
GET    /api/v1/copropiedades/{id}/dashboard
```

### Antenas
```
GET    /api/v1/copropiedades/{id}/antenas
POST   /api/v1/copropiedades/{id}/antenas
POST   /api/v1/copropiedades/{id}/antenas/{antenaId}/facturar
```

### Contabilidad
```
GET    /api/v1/copropiedades/{id}/contabilidad/plan-cuentas
POST   /api/v1/copropiedades/{id}/contabilidad/asientos
GET    /api/v1/copropiedades/{id}/contabilidad/balance
GET    /api/v1/copropiedades/{id}/contabilidad/estado-resultados
```

### PAE
```
POST   /api/v1/copropiedades/{id}/pae/analyze
GET    /api/v1/copropiedades/{id}/pae/dashboard
GET    /api/v1/copropiedades/{id}/pae/alerts
```

---

## 📈 Métricas de Calidad

| Métrica | Valor |
|---------|-------|
| Líneas de código | ~10,000 |
| Tablas de base de datos | 60+ |
| Endpoints API | 100+ |
| Cobertura de tests (objetivo) | 80% |
| Tiempo de respuesta API | <200ms |
| Disponibilidad objetivo | 99.9% |

---

## 🔒 Seguridad

- Autenticación: Laravel Sanctum con tokens
- Autorización: RBAC con 5 roles y 30+ permisos
- Encriptación: AES-256 at-rest, TLS 1.3 in-transit
- Auditoría: Log completo de acciones
- Multi-tenancy: Aislamiento total de datos

---

## 📜 Cumplimiento Normativo

| Normativa | Estado |
|-----------|--------|
| Ley 21.442 Copropiedad Inmobiliaria | ✅ Completo |
| DS 7/2025 Reglamento | ✅ Completo |
| Normativa SII (DTE, DJ) | ✅ Completo |
| Ley 19.628 Protección de Datos | ✅ Completo |

---

## 🗓️ Roadmap

### Q1 2026 (Actual)
- [x] 23 módulos al 100%
- [x] PAE Engines nativos
- [ ] Deploy producción
- [ ] 5 pilotos

### Q2 2026
- [ ] App móvil
- [ ] Integración SII producción
- [ ] 50 copropiedades

### Q3-Q4 2026
- [ ] Expansión Perú/Colombia
- [ ] ISO 27001
- [ ] Ronda Seed

---

## 📞 Contacto

**DATAPOLIS SpA**
- CEO: Daniel
- Email: daniel@datapolis.cl
- Web: https://datapolis.cl

---

*DATAPOLIS v3.0 - Transformando la administración de copropiedades en Chile*

© 2026 DATAPOLIS SpA. Todos los derechos reservados.
