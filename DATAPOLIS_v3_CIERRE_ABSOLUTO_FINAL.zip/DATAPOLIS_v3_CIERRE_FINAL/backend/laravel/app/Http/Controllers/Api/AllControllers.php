<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - CONTROLADORES API COMPLETOS
 * 23 Módulos - Controllers para producción
 * =========================================================================
 */

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\{Request, JsonResponse};
use Illuminate\Support\Facades\{DB, Cache, Log};
use App\Models\{
    Tenant, User, Role, Copropiedad, Unidad, Copropietario, EspacioComun,
    ContratoAntena, FacturaAntena, DistribucionIngresoAntena,
    PeriodoGasto, CategoriaGasto, GastoComun, CobroUnidad, Pago,
    Morosidad, GestionCobranza, ConvenioPago, Proveedor, ContratoServicio,
    PlanCuenta, PeriodoContable, LibroContable, AsientoContable, MovimientoContable, SaldoCuenta,
    CertificadoTributario, DeclaracionJurada, IntegracionSiiConfig,
    FondoReserva, MovimientoFondoReserva, Asamblea, ActaAsamblea,
    ComplianceEvaluacion, RequisitoNormativo, Avaluo,
    PrecessionAnalysis, PrecessionAlert, ContratoArriendo,
    OrdenTrabajo, PlanMantencion, Comunicado,
    ReporteConfigurado, ReporteGenerado, Documento, Configuracion, UfHistorico
};

// =============================================================================
// BASE CONTROLLER CON TENANT SCOPE
// =============================================================================
abstract class BaseApiController extends Controller
{
    protected function tenantId(): int
    {
        return auth()->user()->tenant_id;
    }

    protected function successResponse($data, string $message = 'Success', int $code = 200): JsonResponse
    {
        return response()->json([
            'success' => true,
            'message' => $message,
            'data' => $data
        ], $code);
    }

    protected function errorResponse(string $message, int $code = 400, $errors = null): JsonResponse
    {
        return response()->json([
            'success' => false,
            'message' => $message,
            'errors' => $errors
        ], $code);
    }

    protected function paginatedResponse($query, Request $request): JsonResponse
    {
        $perPage = min($request->input('per_page', 15), 100);
        $data = $query->paginate($perPage);
        return response()->json($data);
    }
}

// =============================================================================
// M01-M02: AUTH CONTROLLER
// =============================================================================
class AuthController extends BaseApiController
{
    public function login(Request $request): JsonResponse
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string'
        ]);

        if (!auth()->attempt($credentials)) {
            return $this->errorResponse('Credenciales inválidas', 401);
        }

        $user = auth()->user();
        $user->update(['last_login_at' => now(), 'last_login_ip' => $request->ip()]);
        $token = $user->createToken('api-token')->plainTextToken;

        return $this->successResponse([
            'user' => $user->load('roles', 'tenant'),
            'token' => $token
        ], 'Login exitoso');
    }

    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();
        return $this->successResponse(null, 'Logout exitoso');
    }

    public function me(Request $request): JsonResponse
    {
        return $this->successResponse($request->user()->load('roles', 'tenant'));
    }

    public function updateProfile(Request $request): JsonResponse
    {
        $user = $request->user();
        $data = $request->validate([
            'name' => 'sometimes|string|max:255',
            'telefono' => 'sometimes|string|max:20',
            'preferences' => 'sometimes|array'
        ]);
        $user->update($data);
        return $this->successResponse($user, 'Perfil actualizado');
    }
}

// =============================================================================
// M03: COPROPIEDADES CONTROLLER
// =============================================================================
class CopropiedadController extends BaseApiController
{
    public function index(Request $request): JsonResponse
    {
        $query = Copropiedad::where('tenant_id', $this->tenantId())
            ->with(['unidades' => fn($q) => $q->activas()->count()])
            ->when($request->activa, fn($q) => $q->activas())
            ->when($request->comuna, fn($q, $v) => $q->where('comuna', $v))
            ->when($request->search, fn($q, $v) => $q->where('nombre', 'like', "%{$v}%"));
        
        return $this->paginatedResponse($query->orderBy('nombre'), $request);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'nombre' => 'required|string|max:255',
            'rut' => 'required|string|max:20',
            'direccion' => 'required|string',
            'comuna' => 'required|string',
            'region' => 'required|string',
            'tipo' => 'required|in:edificio,condominio,mixto',
            'categoria' => 'required|in:residencial,comercial,industrial,mixto',
            'ano_construccion' => 'nullable|integer|min:1900|max:' . date('Y'),
            'pisos' => 'nullable|integer|min:1',
            'superficie_terreno' => 'nullable|numeric|min:0',
            'superficie_construida' => 'nullable|numeric|min:0',
            'rol_sii' => 'nullable|string|max:30',
            'administrador_nombre' => 'nullable|string',
            'administrador_email' => 'nullable|email',
            'administrador_telefono' => 'nullable|string',
        ]);

        $data['tenant_id'] = $this->tenantId();
        $data['uuid'] = \Str::uuid();
        
        $copropiedad = Copropiedad::create($data);
        
        // Crear fondo de reserva inicial (Ley 21.442)
        FondoReserva::create([
            'tenant_id' => $this->tenantId(),
            'copropiedad_id' => $copropiedad->id,
            'saldo_actual' => 0,
            'porcentaje_aporte_mensual' => 5, // Mínimo legal
            'ultima_actualizacion' => now()
        ]);

        return $this->successResponse($copropiedad, 'Copropiedad creada', 201);
    }

    public function show(int $id): JsonResponse
    {
        $copropiedad = Copropiedad::where('tenant_id', $this->tenantId())
            ->with(['unidades', 'espaciosComunes', 'fondoReserva', 'contratosAntenas' => fn($q) => $q->vigentes()])
            ->findOrFail($id);
        
        return $this->successResponse($copropiedad);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $copropiedad = Copropiedad::where('tenant_id', $this->tenantId())->findOrFail($id);
        $copropiedad->update($request->all());
        return $this->successResponse($copropiedad, 'Copropiedad actualizada');
    }

    public function destroy(int $id): JsonResponse
    {
        $copropiedad = Copropiedad::where('tenant_id', $this->tenantId())->findOrFail($id);
        $copropiedad->delete();
        return $this->successResponse(null, 'Copropiedad eliminada');
    }

    public function dashboard(int $id): JsonResponse
    {
        $copropiedad = Copropiedad::where('tenant_id', $this->tenantId())->findOrFail($id);
        
        $dashboard = [
            'copropiedad' => $copropiedad,
            'estadisticas' => [
                'total_unidades' => $copropiedad->unidades()->activas()->count(),
                'indice_ocupacion' => $copropiedad->getIndiceOcupacion(),
                'morosidad_porcentaje' => $this->calcularMorosidad($id),
                'ingresos_antenas_mensual' => $this->calcularIngresosAntenas($id),
            ],
            'fondo_reserva' => $copropiedad->fondoReserva,
            'alertas_activas' => PrecessionAlert::where('copropiedad_id', $id)
                ->where('status', 'active')
                ->orderByRaw("FIELD(severity, 'critical', 'high', 'warning', 'info')")
                ->limit(5)
                ->get(),
            'contratos_por_vencer' => ContratoAntena::where('copropiedad_id', $id)
                ->where('estado', 'vigente')
                ->where('fecha_termino', '<=', now()->addMonths(3))
                ->get(),
        ];

        return $this->successResponse($dashboard);
    }

    private function calcularMorosidad(int $copropiedadId): float
    {
        $total = Unidad::where('copropiedad_id', $copropiedadId)->activas()->count();
        if ($total === 0) return 0;
        $morosos = Morosidad::whereHas('unidad', fn($q) => $q->where('copropiedad_id', $copropiedadId))
            ->where('deuda_total', '>', 0)->count();
        return round(($morosos / $total) * 100, 2);
    }

    private function calcularIngresosAntenas(int $copropiedadId): float
    {
        return ContratoAntena::where('copropiedad_id', $copropiedadId)
            ->where('estado', 'vigente')
            ->sum('canon_mensual_clp');
    }
}

// =============================================================================
// M03: UNIDADES CONTROLLER
// =============================================================================
class UnidadController extends BaseApiController
{
    public function index(Request $request, int $copropiedadId): JsonResponse
    {
        $query = Unidad::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->with(['copropietarios' => fn($q) => $q->where('es_principal', true)])
            ->when($request->activa !== null, fn($q) => $q->where('activa', $request->activa))
            ->when($request->tipo, fn($q, $v) => $q->where('tipo', $v));

        return $this->paginatedResponse($query->orderBy('numero'), $request);
    }

    public function store(Request $request, int $copropiedadId): JsonResponse
    {
        $data = $request->validate([
            'numero' => 'required|string|max:20',
            'piso' => 'nullable|string',
            'tipo' => 'required|in:departamento,casa,local,oficina,bodega,estacionamiento,otro',
            'superficie_util' => 'nullable|numeric|min:0',
            'alicuota_prorrateo' => 'required|numeric|min:0|max:100',
            'dormitorios' => 'nullable|integer|min:0',
            'banos' => 'nullable|integer|min:0',
        ]);

        $data['tenant_id'] = $this->tenantId();
        $data['copropiedad_id'] = $copropiedadId;
        $data['uuid'] = \Str::uuid();
        $data['alicuota_prorrateo'] = $data['alicuota_prorrateo'] / 100;

        $unidad = Unidad::create($data);
        return $this->successResponse($unidad, 'Unidad creada', 201);
    }

    public function show(int $copropiedadId, int $id): JsonResponse
    {
        $unidad = Unidad::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->with(['copropietarios', 'cobrosUnidad', 'morosidad', 'avaluos'])
            ->findOrFail($id);

        return $this->successResponse($unidad);
    }

    public function update(Request $request, int $copropiedadId, int $id): JsonResponse
    {
        $unidad = Unidad::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->findOrFail($id);
        $unidad->update($request->all());
        return $this->successResponse($unidad, 'Unidad actualizada');
    }
}

// =============================================================================
// M04: ANTENAS CONTROLLER
// =============================================================================
class ContratoAntenaController extends BaseApiController
{
    public function index(Request $request, int $copropiedadId): JsonResponse
    {
        $query = ContratoAntena::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->with('espacioComun')
            ->when($request->estado, fn($q, $v) => $q->where('estado', $v));

        return $this->paginatedResponse($query->orderByDesc('fecha_inicio'), $request);
    }

    public function store(Request $request, int $copropiedadId): JsonResponse
    {
        $data = $request->validate([
            'empresa_operador' => 'required|string|max:255',
            'rut_operador' => 'required|string|max:20',
            'tipo_instalacion' => 'required|in:antena_celular,antena_radio,fibra_optica,repetidor,small_cell,satelital,otro',
            'ubicacion_instalacion' => 'required|string',
            'fecha_inicio' => 'required|date',
            'fecha_termino' => 'nullable|date|after:fecha_inicio',
            'canon_mensual_uf' => 'required|numeric|min:0',
            'afecto_iva' => 'required|boolean',
            'tasa_iva' => 'required_if:afecto_iva,true|numeric|min:0|max:100',
            'distribucion_tipo' => 'required|in:fondo_comun,propietarios,fondo_reserva,mixto',
            'porcentaje_fondo_comun' => 'required|numeric|min:0|max:100',
            'porcentaje_fondo_reserva' => 'required|numeric|min:0|max:100',
            'fecha_asamblea_aprobacion' => 'nullable|date',
            'acta_asamblea_numero' => 'nullable|string',
        ]);

        $data['tenant_id'] = $this->tenantId();
        $data['copropiedad_id'] = $copropiedadId;
        $data['uuid'] = \Str::uuid();
        $data['numero_contrato'] = $this->generarNumeroContrato();
        $data['estado'] = 'vigente';
        $data['canon_mensual_clp'] = $data['canon_mensual_uf'] * UfHistorico::getValor();

        $contrato = ContratoAntena::create($data);

        Log::info('Contrato antena creado', ['contrato_id' => $contrato->id, 'copropiedad_id' => $copropiedadId]);

        return $this->successResponse($contrato, 'Contrato de antena creado', 201);
    }

    public function show(int $copropiedadId, int $id): JsonResponse
    {
        $contrato = ContratoAntena::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->with(['facturas', 'espacioComun', 'copropiedad'])
            ->findOrFail($id);

        return $this->successResponse($contrato);
    }

    public function generarFactura(Request $request, int $copropiedadId, int $contratoId): JsonResponse
    {
        $contrato = ContratoAntena::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->findOrFail($contratoId);

        $periodo = $request->input('periodo', now()->format('Y-m'));
        $valorUf = UfHistorico::getValor();

        // Calcular montos
        $montoNetoUf = $contrato->canon_mensual_uf;
        $montoNetoCLP = $montoNetoUf * $valorUf;
        $montoIva = $contrato->afecto_iva ? $montoNetoCLP * ($contrato->tasa_iva / 100) : 0;
        $montoTotal = $montoNetoCLP + $montoIva;

        $factura = FacturaAntena::create([
            'uuid' => \Str::uuid(),
            'tenant_id' => $this->tenantId(),
            'contrato_antena_id' => $contratoId,
            'copropiedad_id' => $copropiedadId,
            'fecha_emision' => now(),
            'fecha_vencimiento' => now()->addDays(30),
            'periodo' => $periodo,
            'monto_neto_uf' => $montoNetoUf,
            'monto_neto_clp' => $montoNetoCLP,
            'monto_iva' => $montoIva,
            'monto_total_clp' => $montoTotal,
            'valor_uf_dia' => $valorUf,
            'iva_incluido' => $contrato->afecto_iva,
            'tasa_iva_aplicada' => $contrato->tasa_iva,
            'estado' => 'emitida',
        ]);

        // Generar distribución según configuración del contrato
        $this->generarDistribucion($factura, $contrato);

        return $this->successResponse($factura->load('distribuciones'), 'Factura generada');
    }

    private function generarDistribucion(FacturaAntena $factura, ContratoAntena $contrato): void
    {
        $montoDistribuir = $factura->monto_neto_clp;
        $valorUf = $factura->valor_uf_dia;

        // Fondo común
        if ($contrato->porcentaje_fondo_comun > 0) {
            $monto = $montoDistribuir * ($contrato->porcentaje_fondo_comun / 100);
            DistribucionIngresoAntena::create([
                'tenant_id' => $factura->tenant_id,
                'factura_antena_id' => $factura->id,
                'tipo_destino' => 'fondo_comun',
                'porcentaje' => $contrato->porcentaje_fondo_comun / 100,
                'monto_bruto_clp' => $monto,
                'monto_neto_clp' => $monto,
                'monto_uf' => $monto / $valorUf,
            ]);
        }

        // Fondo de reserva
        if ($contrato->porcentaje_fondo_reserva > 0) {
            $monto = $montoDistribuir * ($contrato->porcentaje_fondo_reserva / 100);
            DistribucionIngresoAntena::create([
                'tenant_id' => $factura->tenant_id,
                'factura_antena_id' => $factura->id,
                'tipo_destino' => 'fondo_reserva',
                'porcentaje' => $contrato->porcentaje_fondo_reserva / 100,
                'monto_bruto_clp' => $monto,
                'monto_neto_clp' => $monto,
                'monto_uf' => $monto / $valorUf,
            ]);

            // Actualizar fondo de reserva
            $fondo = FondoReserva::where('copropiedad_id', $contrato->copropiedad_id)->first();
            if ($fondo) {
                $fondo->increment('saldo_actual', $monto);
                MovimientoFondoReserva::create([
                    'tenant_id' => $factura->tenant_id,
                    'fondo_id' => $fondo->id,
                    'fecha' => now(),
                    'tipo' => 'ingreso_antena',
                    'monto' => $monto,
                    'saldo_posterior' => $fondo->saldo_actual,
                    'descripcion' => "Ingreso antena - {$contrato->empresa_operador} - {$factura->periodo}",
                    'periodo' => $factura->periodo,
                ]);
            }
        }

        // Distribución a propietarios
        if ($contrato->porcentaje_propietarios > 0) {
            $montoTotal = $montoDistribuir * ($contrato->porcentaje_propietarios / 100);
            $unidades = Unidad::where('copropiedad_id', $contrato->copropiedad_id)->activas()->get();
            
            foreach ($unidades as $unidad) {
                $montoPropietario = $montoTotal * $unidad->alicuota_prorrateo;
                $copropietario = $unidad->getPropietarioPrincipal();
                
                DistribucionIngresoAntena::create([
                    'tenant_id' => $factura->tenant_id,
                    'factura_antena_id' => $factura->id,
                    'unidad_id' => $unidad->id,
                    'copropietario_id' => $copropietario?->id,
                    'tipo_destino' => 'propietario',
                    'porcentaje' => $unidad->alicuota_prorrateo,
                    'monto_bruto_clp' => $montoPropietario,
                    'monto_neto_clp' => $montoPropietario,
                    'monto_uf' => $montoPropietario / $valorUf,
                ]);
            }
        }
    }

    private function generarNumeroContrato(): string
    {
        $year = date('Y');
        $count = ContratoAntena::where('tenant_id', $this->tenantId())
            ->whereYear('created_at', $year)->count() + 1;
        return "ANT-{$year}-" . str_pad($count, 4, '0', STR_PAD_LEFT);
    }
}

// =============================================================================
// M05: GASTOS COMUNES CONTROLLER
// =============================================================================
class GastoComunController extends BaseApiController
{
    public function index(Request $request, int $copropiedadId): JsonResponse
    {
        $query = GastoComun::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->with(['categoria', 'proveedor', 'periodo'])
            ->when($request->periodo_id, fn($q, $v) => $q->where('periodo_id', $v))
            ->when($request->categoria_id, fn($q, $v) => $q->where('categoria_id', $v));

        return $this->paginatedResponse($query->orderByDesc('fecha'), $request);
    }

    public function store(Request $request, int $copropiedadId): JsonResponse
    {
        $data = $request->validate([
            'periodo_id' => 'required|exists:periodos_gasto,id',
            'categoria_id' => 'required|exists:categorias_gasto,id',
            'proveedor_id' => 'nullable|exists:proveedores,id',
            'descripcion' => 'required|string',
            'fecha' => 'required|date',
            'monto_neto' => 'required|numeric|min:0',
            'afecto_iva' => 'required|boolean',
        ]);

        $data['tenant_id'] = $this->tenantId();
        $data['copropiedad_id'] = $copropiedadId;
        $data['uuid'] = \Str::uuid();
        $data['monto_iva'] = $data['afecto_iva'] ? $data['monto_neto'] * 0.19 : 0;
        $data['monto_total'] = $data['monto_neto'] + $data['monto_iva'];
        $data['estado'] = 'pendiente';

        $gasto = GastoComun::create($data);
        return $this->successResponse($gasto, 'Gasto registrado', 201);
    }

    public function prorratear(Request $request, int $copropiedadId, int $periodoId): JsonResponse
    {
        $periodo = PeriodoGasto::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->findOrFail($periodoId);

        $unidades = Unidad::where('copropiedad_id', $copropiedadId)->activas()->get();
        $gastos = GastoComun::where('periodo_id', $periodoId)->where('estado', 'aprobado')->get();

        $totalOrdinarios = $gastos->where('categoria.tipo', 'ordinario')->sum('monto_total');
        $totalExtraordinarios = $gastos->where('categoria.tipo', 'extraordinario')->sum('monto_total');
        
        $fondoReserva = FondoReserva::where('copropiedad_id', $copropiedadId)->first();
        $porcentajeFondo = $fondoReserva?->porcentaje_aporte_mensual ?? 5;

        foreach ($unidades as $unidad) {
            $gastoOrdinario = $totalOrdinarios * $unidad->alicuota_prorrateo;
            $gastoExtraordinario = $totalExtraordinarios * $unidad->alicuota_prorrateo;
            $fondoReservaAporte = $gastoOrdinario * ($porcentajeFondo / 100);

            CobroUnidad::updateOrCreate(
                ['unidad_id' => $unidad->id, 'periodo_id' => $periodoId],
                [
                    'tenant_id' => $this->tenantId(),
                    'gasto_ordinario' => $gastoOrdinario,
                    'gasto_extraordinario' => $gastoExtraordinario,
                    'fondo_reserva' => $fondoReservaAporte,
                    'total_cobrar' => $gastoOrdinario + $gastoExtraordinario + $fondoReservaAporte,
                    'saldo_pendiente' => $gastoOrdinario + $gastoExtraordinario + $fondoReservaAporte,
                    'fecha_vencimiento' => $periodo->fecha_vencimiento,
                    'estado' => 'pendiente',
                ]
            );
        }

        $periodo->update([
            'total_gastos_ordinarios' => $totalOrdinarios,
            'total_gastos_extraordinarios' => $totalExtraordinarios,
            'fondo_reserva_aporte' => $totalOrdinarios * ($porcentajeFondo / 100),
            'estado' => 'facturado',
        ]);

        return $this->successResponse(['cobros_generados' => $unidades->count()], 'Prorrateo completado');
    }
}

// =============================================================================
// M06: MOROSIDAD CONTROLLER
// =============================================================================
class MorosidadController extends BaseApiController
{
    public function index(Request $request, int $copropiedadId): JsonResponse
    {
        $query = Morosidad::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->with(['unidad', 'unidad.copropietarios' => fn($q) => $q->where('es_principal', true)])
            ->when($request->categoria_riesgo, fn($q, $v) => $q->where('categoria_riesgo', $v))
            ->when($request->estado_gestion, fn($q, $v) => $q->where('estado_gestion', $v))
            ->where('deuda_total', '>', 0);

        return $this->paginatedResponse($query->orderByDesc('deuda_total'), $request);
    }

    public function registrarGestion(Request $request, int $copropiedadId, int $morosidadId): JsonResponse
    {
        $morosidad = Morosidad::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->findOrFail($morosidadId);

        $data = $request->validate([
            'tipo' => 'required|in:llamada,email,carta,visita,whatsapp,carta_certificada,notificacion_judicial,otro',
            'descripcion' => 'required|string',
            'resultado' => 'required|in:contactado,no_contactado,compromiso_pago,rechazo,sin_respuesta',
            'fecha_compromiso' => 'nullable|date',
            'monto_compromiso' => 'nullable|numeric|min:0',
        ]);

        $gestion = GestionCobranza::create([
            'tenant_id' => $this->tenantId(),
            'morosidad_id' => $morosidadId,
            'usuario_id' => auth()->id(),
            'fecha' => now(),
            ...$data,
        ]);

        $morosidad->update([
            'ultima_gestion' => now(),
            'estado_gestion' => 'en_gestion',
            'proximo_contacto' => $data['fecha_compromiso'] ?? now()->addDays(7),
        ]);

        return $this->successResponse($gestion, 'Gestión registrada', 201);
    }

    public function crearConvenio(Request $request, int $copropiedadId, int $morosidadId): JsonResponse
    {
        $morosidad = Morosidad::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->findOrFail($morosidadId);

        $data = $request->validate([
            'pie_inicial' => 'required|numeric|min:0',
            'numero_cuotas' => 'required|integer|min:1|max:36',
            'tasa_interes_mensual' => 'nullable|numeric|min:0|max:5',
            'condiciones' => 'nullable|string',
        ]);

        $deudaRestante = $morosidad->deuda_total - $data['pie_inicial'];
        $montoCuota = $deudaRestante / $data['numero_cuotas'];

        $convenio = ConvenioPago::create([
            'uuid' => \Str::uuid(),
            'tenant_id' => $this->tenantId(),
            'morosidad_id' => $morosidadId,
            'unidad_id' => $morosidad->unidad_id,
            'numero_convenio' => 'CONV-' . date('Y') . '-' . str_pad(ConvenioPago::count() + 1, 5, '0', STR_PAD_LEFT),
            'fecha_convenio' => now(),
            'deuda_total' => $morosidad->deuda_total,
            'pie_inicial' => $data['pie_inicial'],
            'numero_cuotas' => $data['numero_cuotas'],
            'monto_cuota' => $montoCuota,
            'tasa_interes_mensual' => $data['tasa_interes_mensual'] ?? 0,
            'fecha_primera_cuota' => now()->addMonth()->startOfMonth(),
            'estado' => 'vigente',
            'condiciones' => $data['condiciones'],
        ]);

        $morosidad->update(['estado_gestion' => 'convenio']);

        return $this->successResponse($convenio, 'Convenio creado', 201);
    }
}

// =============================================================================
// M08: CONTABILIDAD CONTROLLER
// =============================================================================
class ContabilidadController extends BaseApiController
{
    public function planCuentas(int $copropiedadId): JsonResponse
    {
        $cuentas = PlanCuenta::where('tenant_id', $this->tenantId())
            ->where(function ($q) use ($copropiedadId) {
                $q->whereNull('copropiedad_id')->orWhere('copropiedad_id', $copropiedadId);
            })
            ->orderBy('codigo')
            ->get();

        return $this->successResponse($cuentas);
    }

    public function crearAsiento(Request $request, int $copropiedadId): JsonResponse
    {
        $data = $request->validate([
            'fecha' => 'required|date',
            'tipo' => 'required|in:ingreso,egreso,traspaso,ajuste',
            'glosa' => 'required|string|max:255',
            'movimientos' => 'required|array|min:2',
            'movimientos.*.cuenta_id' => 'required|exists:planes_cuenta,id',
            'movimientos.*.tipo_movimiento' => 'required|in:debe,haber',
            'movimientos.*.monto' => 'required|numeric|min:0.01',
        ]);

        // Validar balance
        $totalDebe = collect($data['movimientos'])->where('tipo_movimiento', 'debe')->sum('monto');
        $totalHaber = collect($data['movimientos'])->where('tipo_movimiento', 'haber')->sum('monto');

        if (abs($totalDebe - $totalHaber) > 0.01) {
            return $this->errorResponse('El asiento no está balanceado', 422);
        }

        // Obtener o crear período contable
        $fecha = \Carbon\Carbon::parse($data['fecha']);
        $periodo = PeriodoContable::firstOrCreate(
            ['copropiedad_id' => $copropiedadId, 'ano' => $fecha->year, 'mes' => $fecha->month],
            [
                'tenant_id' => $this->tenantId(),
                'fecha_inicio' => $fecha->startOfMonth(),
                'fecha_cierre' => $fecha->endOfMonth(),
                'estado' => 'abierto',
            ]
        );

        if ($periodo->estado === 'cerrado') {
            return $this->errorResponse('El período contable está cerrado', 422);
        }

        // Generar número de asiento
        $numeroAsiento = AsientoContable::where('copropiedad_id', $copropiedadId)
            ->where('periodo_contable_id', $periodo->id)->max('numero_asiento') + 1;

        DB::beginTransaction();
        try {
            $asiento = AsientoContable::create([
                'uuid' => \Str::uuid(),
                'tenant_id' => $this->tenantId(),
                'copropiedad_id' => $copropiedadId,
                'periodo_contable_id' => $periodo->id,
                'numero_asiento' => $numeroAsiento,
                'fecha' => $data['fecha'],
                'tipo' => $data['tipo'],
                'glosa' => $data['glosa'],
                'total_debe' => $totalDebe,
                'total_haber' => $totalHaber,
                'estado' => 'borrador',
                'creado_por' => auth()->id(),
            ]);

            foreach ($data['movimientos'] as $mov) {
                MovimientoContable::create([
                    'tenant_id' => $this->tenantId(),
                    'asiento_id' => $asiento->id,
                    'cuenta_id' => $mov['cuenta_id'],
                    'tipo_movimiento' => $mov['tipo_movimiento'],
                    'monto' => $mov['monto'],
                    'glosa_linea' => $mov['glosa_linea'] ?? null,
                ]);
            }

            DB::commit();
            return $this->successResponse($asiento->load('movimientos'), 'Asiento creado', 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->errorResponse('Error al crear asiento: ' . $e->getMessage(), 500);
        }
    }

    public function aprobarAsiento(int $copropiedadId, int $asientoId): JsonResponse
    {
        $asiento = AsientoContable::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->findOrFail($asientoId);

        if ($asiento->estado !== 'borrador') {
            return $this->errorResponse('Solo se pueden aprobar asientos en borrador', 422);
        }

        $asiento->update([
            'estado' => 'contabilizado',
            'aprobado_por' => auth()->id(),
            'fecha_aprobacion' => now(),
        ]);

        // Actualizar saldos de cuentas
        foreach ($asiento->movimientos as $mov) {
            $this->actualizarSaldoCuenta($mov);
        }

        return $this->successResponse($asiento, 'Asiento aprobado');
    }

    private function actualizarSaldoCuenta(MovimientoContable $movimiento): void
    {
        $asiento = $movimiento->asiento;
        
        $saldo = SaldoCuenta::firstOrCreate(
            [
                'cuenta_id' => $movimiento->cuenta_id,
                'periodo_contable_id' => $asiento->periodo_contable_id,
            ],
            [
                'tenant_id' => $asiento->tenant_id,
                'copropiedad_id' => $asiento->copropiedad_id,
                'saldo_inicial' => 0,
                'debitos' => 0,
                'creditos' => 0,
                'saldo_final' => 0,
            ]
        );

        if ($movimiento->tipo_movimiento === 'debe') {
            $saldo->increment('debitos', $movimiento->monto);
        } else {
            $saldo->increment('creditos', $movimiento->monto);
        }

        $cuenta = $movimiento->cuenta;
        if ($cuenta->naturaleza === 'deudora') {
            $saldo->saldo_final = $saldo->saldo_inicial + $saldo->debitos - $saldo->creditos;
        } else {
            $saldo->saldo_final = $saldo->saldo_inicial - $saldo->debitos + $saldo->creditos;
        }
        $saldo->save();
    }

    public function libroMayor(Request $request, int $copropiedadId): JsonResponse
    {
        $cuentaId = $request->input('cuenta_id');
        $ano = $request->input('ano', date('Y'));

        $movimientos = MovimientoContable::whereHas('asiento', function ($q) use ($copropiedadId, $ano) {
            $q->where('copropiedad_id', $copropiedadId)
              ->where('estado', 'contabilizado')
              ->whereYear('fecha', $ano);
        })
        ->when($cuentaId, fn($q) => $q->where('cuenta_id', $cuentaId))
        ->with(['asiento', 'cuenta'])
        ->orderBy('asiento_id')
        ->get();

        return $this->successResponse($movimientos);
    }

    public function balanceGeneral(int $copropiedadId, int $ano, int $mes): JsonResponse
    {
        $periodo = PeriodoContable::where('copropiedad_id', $copropiedadId)
            ->where('ano', $ano)
            ->where('mes', $mes)
            ->first();

        if (!$periodo) {
            return $this->errorResponse('Período no encontrado', 404);
        }

        $saldos = SaldoCuenta::where('periodo_contable_id', $periodo->id)
            ->with('cuenta')
            ->get()
            ->groupBy('cuenta.tipo');

        $balance = [
            'periodo' => "{$ano}-{$mes}",
            'activos' => $saldos->get('activo', collect())->sum('saldo_final'),
            'pasivos' => $saldos->get('pasivo', collect())->sum('saldo_final'),
            'patrimonio' => $saldos->get('patrimonio', collect())->sum('saldo_final'),
            'ingresos' => $saldos->get('ingreso', collect())->sum('saldo_final'),
            'gastos' => $saldos->get('gasto', collect())->sum('saldo_final'),
            'detalle' => $saldos,
        ];

        return $this->successResponse($balance);
    }

    public function exportarLibro(Request $request, int $copropiedadId): JsonResponse
    {
        $tipo = $request->input('tipo', 'diario');
        $ano = $request->input('ano', date('Y'));
        $mes = $request->input('mes');

        // Crear registro de libro
        $libro = LibroContable::create([
            'tenant_id' => $this->tenantId(),
            'copropiedad_id' => $copropiedadId,
            'tipo' => $tipo,
            'ano' => $ano,
            'mes' => $mes,
            'estado' => 'abierto',
            'fecha_generacion' => now(),
        ]);

        // TODO: Generar archivo PDF/Excel y guardar ruta
        
        return $this->successResponse($libro, 'Libro generado');
    }
}

// =============================================================================
// M09: CERTIFICADOS TRIBUTARIOS CONTROLLER
// =============================================================================
class CertificadoTributarioController extends BaseApiController
{
    public function index(Request $request, int $copropiedadId): JsonResponse
    {
        $query = CertificadoTributario::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->with(['copropietario', 'unidad'])
            ->when($request->tipo, fn($q, $v) => $q->where('tipo', $v))
            ->when($request->ano, fn($q, $v) => $q->where('ano_tributario', $v));

        return $this->paginatedResponse($query->orderByDesc('fecha_emision'), $request);
    }

    public function emitirCertificadoComunidad(Request $request, int $copropiedadId): JsonResponse
    {
        $ano = $request->input('ano_tributario', date('Y') - 1);
        
        $copropiedad = Copropiedad::where('tenant_id', $this->tenantId())->findOrFail($copropiedadId);

        // Calcular totales del año
        $ingresos = FacturaAntena::where('copropiedad_id', $copropiedadId)
            ->whereYear('fecha_emision', $ano)
            ->where('estado', 'pagada')
            ->sum('monto_neto_clp');

        $gastos = GastoComun::where('copropiedad_id', $copropiedadId)
            ->whereYear('fecha', $ano)
            ->where('estado', 'pagado')
            ->sum('monto_total');

        $certificado = CertificadoTributario::create([
            'uuid' => \Str::uuid(),
            'tenant_id' => $this->tenantId(),
            'copropiedad_id' => $copropiedadId,
            'tipo' => 'cumplimiento_comunidad',
            'ano_tributario' => $ano,
            'folio' => CertificadoTributario::generarFolio($this->tenantId(), $ano),
            'fecha_emision' => now(),
            'fecha_vigencia' => now()->addMonths(6),
            'monto_ingresos' => $ingresos,
            'monto_gastos' => $gastos,
            'detalle' => [
                'rut_comunidad' => $copropiedad->rut,
                'nombre_comunidad' => $copropiedad->nombre,
                'direccion' => $copropiedad->direccion,
                'comuna' => $copropiedad->comuna,
                'contratos_antenas' => ContratoAntena::where('copropiedad_id', $copropiedadId)->vigentes()->count(),
                'regimen_tributario' => $copropiedad->regimen_tributario,
            ],
            'estado' => 'emitido',
            'codigo_verificacion' => \Str::random(32),
            'emitido_por' => auth()->id(),
        ]);

        return $this->successResponse($certificado, 'Certificado emitido', 201);
    }

    public function emitirCertificadoCopropietario(Request $request, int $copropiedadId, int $copropietarioId): JsonResponse
    {
        $ano = $request->input('ano_tributario', date('Y') - 1);
        
        $copropietario = Copropietario::where('tenant_id', $this->tenantId())->findOrFail($copropietarioId);
        $unidad = $copropietario->unidad;

        // Calcular participación en ingresos de antenas
        $totalIngresosAntenas = DistribucionIngresoAntena::whereHas('facturaAntena', function ($q) use ($copropiedadId, $ano) {
            $q->where('copropiedad_id', $copropiedadId)->whereYear('fecha_emision', $ano);
        })->where('copropietario_id', $copropietarioId)->sum('monto_neto_clp');

        // Calcular gastos comunes pagados
        $totalGastosPagados = Pago::whereHas('cobroUnidad', function ($q) use ($unidad, $ano) {
            $q->where('unidad_id', $unidad->id)->whereYear('created_at', $ano);
        })->sum('monto');

        $certificado = CertificadoTributario::create([
            'uuid' => \Str::uuid(),
            'tenant_id' => $this->tenantId(),
            'copropiedad_id' => $copropiedadId,
            'copropietario_id' => $copropietarioId,
            'unidad_id' => $unidad->id,
            'tipo' => 'participacion_rentas',
            'ano_tributario' => $ano,
            'folio' => CertificadoTributario::generarFolio($this->tenantId(), $ano),
            'fecha_emision' => now(),
            'fecha_vigencia' => now()->addMonths(6),
            'monto_ingresos' => $totalIngresosAntenas,
            'monto_gastos' => $totalGastosPagados,
            'monto_participacion' => $totalIngresosAntenas,
            'porcentaje_participacion' => $unidad->alicuota_prorrateo,
            'detalle' => [
                'rut_copropietario' => $copropietario->rut,
                'nombre' => $copropietario->getNombreCompleto(),
                'unidad' => $unidad->numero,
                'alicuota' => $unidad->alicuota_prorrateo * 100 . '%',
            ],
            'estado' => 'emitido',
            'codigo_verificacion' => \Str::random(32),
            'emitido_por' => auth()->id(),
        ]);

        return $this->successResponse($certificado, 'Certificado emitido', 201);
    }

    public function verificar(string $codigo): JsonResponse
    {
        $certificado = CertificadoTributario::where('codigo_verificacion', $codigo)
            ->with(['copropiedad', 'copropietario', 'unidad'])
            ->first();

        if (!$certificado) {
            return $this->errorResponse('Certificado no encontrado', 404);
        }

        if ($certificado->estado === 'anulado') {
            return $this->errorResponse('Certificado anulado', 422);
        }

        if ($certificado->fecha_vigencia < now()) {
            return $this->errorResponse('Certificado vencido', 422);
        }

        return $this->successResponse($certificado, 'Certificado válido');
    }
}

// =============================================================================
// M15: PAE CONTROLLER
// =============================================================================
class PrecessionController extends BaseApiController
{
    public function analyze(Request $request, int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::where('tenant_id', $this->tenantId())->findOrFail($copropiedadId);

        $service = app(\App\Services\PrecessionService::class);
        
        $analysis = $service->analyzeCopropiedad($copropiedadId, [
            'horizon' => $request->input('horizon', 36),
            'max_depth' => $request->input('max_depth', 4),
            'include_ml' => $request->boolean('include_ml', true),
        ]);

        return $this->successResponse($analysis, 'Análisis completado');
    }

    public function alerts(Request $request, int $copropiedadId): JsonResponse
    {
        $alerts = PrecessionAlert::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->when($request->status, fn($q, $v) => $q->where('status', $v))
            ->when($request->severity, fn($q, $v) => $q->where('severity', $v))
            ->orderByRaw("FIELD(severity, 'critical', 'high', 'warning', 'info')")
            ->orderByDesc('created_at')
            ->paginate($request->input('per_page', 15));

        return response()->json($alerts);
    }

    public function acknowledgeAlert(int $copropiedadId, int $alertId): JsonResponse
    {
        $alert = PrecessionAlert::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->findOrFail($alertId);

        $alert->update([
            'status' => 'acknowledged',
            'acknowledged_at' => now(),
            'acknowledged_by' => auth()->id(),
        ]);

        return $this->successResponse($alert, 'Alerta reconocida');
    }

    public function resolveAlert(Request $request, int $copropiedadId, int $alertId): JsonResponse
    {
        $alert = PrecessionAlert::where('tenant_id', $this->tenantId())
            ->where('copropiedad_id', $copropiedadId)
            ->findOrFail($alertId);

        $alert->update([
            'status' => 'resolved',
            'resolved_at' => now(),
            'resolved_by' => auth()->id(),
            'resolution_notes' => $request->input('notes'),
        ]);

        return $this->successResponse($alert, 'Alerta resuelta');
    }

    public function dashboard(int $copropiedadId): JsonResponse
    {
        $cacheKey = "pae:dashboard:{$copropiedadId}";
        
        $dashboard = Cache::remember($cacheKey, 1800, function () use ($copropiedadId) {
            $latestAnalysis = PrecessionAnalysis::where('copropiedad_id', $copropiedadId)
                ->where('status', 'completed')
                ->orderByDesc('created_at')
                ->first();

            $activeAlerts = PrecessionAlert::where('copropiedad_id', $copropiedadId)
                ->where('status', 'active')
                ->get();

            return [
                'latest_analysis' => $latestAnalysis,
                'alerts_summary' => [
                    'total' => $activeAlerts->count(),
                    'critical' => $activeAlerts->where('severity', 'critical')->count(),
                    'high' => $activeAlerts->where('severity', 'high')->count(),
                    'warning' => $activeAlerts->where('severity', 'warning')->count(),
                ],
                'scores' => $latestAnalysis ? [
                    'precession' => $latestAnalysis->precession_score,
                    'risk' => $latestAnalysis->risk_score,
                    'opportunity' => $latestAnalysis->opportunity_score,
                ] : null,
            ];
        });

        return $this->successResponse($dashboard);
    }
}

// =============================================================================
// M13: COMPLIANCE CONTROLLER
// =============================================================================
class ComplianceController extends BaseApiController
{
    public function evaluar(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::where('tenant_id', $this->tenantId())
            ->with(['fondoReserva', 'contratosAntenas', 'asambleas'])
            ->findOrFail($copropiedadId);

        $scores = [];
        $brechas = [];

        // Evaluación Ley 21.442
        $scores['ley21442'] = $this->evaluarLey21442($copropiedad, $brechas);
        
        // Evaluación DS 7/2025
        $scores['ds7_2025'] = $this->evaluarDS7($copropiedad, $brechas);
        
        // Evaluación Tributaria
        $scores['tributario'] = $this->evaluarTributario($copropiedad, $brechas);
        
        // Evaluación Contable
        $scores['contable'] = $this->evaluarContable($copropiedad, $brechas);
        
        // Evaluación Transparencia
        $scores['transparencia'] = $this->evaluarTransparencia($copropiedad, $brechas);

        $scoreGlobal = collect($scores)->avg();

        $evaluacion = ComplianceEvaluacion::create([
            'uuid' => \Str::uuid(),
            'tenant_id' => $this->tenantId(),
            'copropiedad_id' => $copropiedadId,
            'fecha_evaluacion' => now(),
            'periodo_evaluado' => now()->format('Y-m'),
            'score_global' => $scoreGlobal,
            'score_ley21442' => $scores['ley21442'],
            'score_ds7_2025' => $scores['ds7_2025'],
            'score_tributario' => $scores['tributario'],
            'score_contable' => $scores['contable'],
            'score_transparencia' => $scores['transparencia'],
            'brechas' => $brechas,
            'recomendaciones' => $this->generarRecomendaciones($brechas),
            'estado' => 'publicado',
            'evaluador_id' => auth()->id(),
        ]);

        return $this->successResponse($evaluacion, 'Evaluación completada');
    }

    private function evaluarLey21442(Copropiedad $copropiedad, array &$brechas): float
    {
        $score = 100;
        
        // Fondo de reserva mínimo 5%
        $fondo = $copropiedad->fondoReserva;
        if (!$fondo || $fondo->porcentaje_aporte_mensual < 5) {
            $score -= 20;
            $brechas['ley21442'][] = 'Fondo de reserva bajo el mínimo legal (5%)';
        }

        // Contratos de antenas con acta de asamblea
        $contratossinActa = $copropiedad->contratosAntenas()
            ->whereNull('acta_asamblea_numero')
            ->count();
        if ($contratossinActa > 0) {
            $score -= 15;
            $brechas['ley21442'][] = "Hay {$contratossinActa} contratos sin acta de asamblea";
        }

        // Asamblea ordinaria anual
        $ultimaOrdinaria = $copropiedad->asambleas()
            ->where('tipo', 'ordinaria')
            ->where('estado', 'realizada')
            ->orderByDesc('fecha')
            ->first();
        if (!$ultimaOrdinaria || $ultimaOrdinaria->fecha < now()->subYear()) {
            $score -= 15;
            $brechas['ley21442'][] = 'No hay asamblea ordinaria en los últimos 12 meses';
        }

        return max(0, $score);
    }

    private function evaluarDS7(Copropiedad $copropiedad, array &$brechas): float
    {
        $score = 100;
        
        // Reglamento interno actualizado
        if (!$copropiedad->configuracion || !isset($copropiedad->configuracion['reglamento_actualizado'])) {
            $score -= 20;
            $brechas['ds7'][] = 'Reglamento interno no registrado o desactualizado';
        }

        return max(0, $score);
    }

    private function evaluarTributario(Copropiedad $copropiedad, array &$brechas): float
    {
        $score = 100;

        // Contratos afectos a IVA sin facturación
        $contratosAfectos = ContratoAntena::where('copropiedad_id', $copropiedad->id)
            ->where('afecto_iva', true)
            ->where('estado', 'vigente')
            ->get();

        foreach ($contratosAfectos as $contrato) {
            $ultimaFactura = $contrato->facturas()->orderByDesc('periodo')->first();
            if (!$ultimaFactura || $ultimaFactura->periodo < now()->subMonths(2)->format('Y-m')) {
                $score -= 10;
                $brechas['tributario'][] = "Contrato {$contrato->numero_contrato} sin facturación reciente";
            }
        }

        return max(0, $score);
    }

    private function evaluarContable(Copropiedad $copropiedad, array &$brechas): float
    {
        $score = 100;

        // Períodos contables cerrados
        $periodosPendientes = PeriodoContable::where('copropiedad_id', $copropiedad->id)
            ->where('estado', 'abierto')
            ->where('fecha_cierre', '<', now()->subMonth())
            ->count();

        if ($periodosPendientes > 0) {
            $score -= 15 * min($periodosPendientes, 3);
            $brechas['contable'][] = "{$periodosPendientes} períodos contables sin cerrar";
        }

        return max(0, $score);
    }

    private function evaluarTransparencia(Copropiedad $copropiedad, array &$brechas): float
    {
        $score = 100;

        // Comunicados recientes
        $comunicadosRecientes = Comunicado::where('copropiedad_id', $copropiedad->id)
            ->where('fecha_publicacion', '>=', now()->subMonths(3))
            ->count();

        if ($comunicadosRecientes < 1) {
            $score -= 10;
            $brechas['transparencia'][] = 'Sin comunicados en los últimos 3 meses';
        }

        return max(0, $score);
    }

    private function generarRecomendaciones(array $brechas): array
    {
        $recomendaciones = [];

        foreach ($brechas as $categoria => $items) {
            foreach ($items as $brecha) {
                $recomendaciones[] = [
                    'categoria' => $categoria,
                    'brecha' => $brecha,
                    'accion' => $this->sugerirAccion($brecha),
                    'prioridad' => $this->determinarPrioridad($categoria),
                ];
            }
        }

        return $recomendaciones;
    }

    private function sugerirAccion(string $brecha): string
    {
        $acciones = [
            'Fondo de reserva' => 'Ajustar el porcentaje de aporte mensual al mínimo legal de 5%',
            'contratos sin acta' => 'Convocar asamblea extraordinaria para ratificar contratos',
            'asamblea ordinaria' => 'Convocar asamblea ordinaria anual',
            'facturación' => 'Emitir facturas pendientes de contratos de antenas',
            'períodos contables' => 'Cerrar períodos contables pendientes',
        ];

        foreach ($acciones as $key => $accion) {
            if (stripos($brecha, $key) !== false) {
                return $accion;
            }
        }

        return 'Revisar y corregir la situación identificada';
    }

    private function determinarPrioridad(string $categoria): string
    {
        return match($categoria) {
            'ley21442', 'tributario' => 'alta',
            'contable', 'ds7' => 'media',
            default => 'baja',
        };
    }
}

// =============================================================================
// DASHBOARD GLOBAL CONTROLLER
// =============================================================================
class DashboardController extends BaseApiController
{
    public function index(): JsonResponse
    {
        $tenantId = $this->tenantId();

        $dashboard = Cache::remember("dashboard:tenant:{$tenantId}", 300, function () use ($tenantId) {
            $copropiedades = Copropiedad::where('tenant_id', $tenantId)->activas()->count();
            $unidades = Unidad::where('tenant_id', $tenantId)->activas()->count();
            
            $totalMorosidad = Morosidad::where('tenant_id', $tenantId)->sum('deuda_total');
            $contratosVigentes = ContratoAntena::where('tenant_id', $tenantId)->vigentes()->count();
            $ingresosAntenasMes = FacturaAntena::where('tenant_id', $tenantId)
                ->where('periodo', now()->format('Y-m'))
                ->sum('monto_total_clp');

            $alertasCriticas = PrecessionAlert::where('tenant_id', $tenantId)
                ->where('status', 'active')
                ->where('severity', 'critical')
                ->count();

            return [
                'resumen' => [
                    'copropiedades' => $copropiedades,
                    'unidades' => $unidades,
                    'contratos_antenas' => $contratosVigentes,
                ],
                'financiero' => [
                    'morosidad_total' => $totalMorosidad,
                    'ingresos_antenas_mes' => $ingresosAntenasMes,
                ],
                'alertas' => [
                    'criticas' => $alertasCriticas,
                ],
                'valor_uf' => UfHistorico::getValor(),
            ];
        });

        return $this->successResponse($dashboard);
    }
}
