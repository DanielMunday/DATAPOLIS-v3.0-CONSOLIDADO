<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - MODELOS COMPLETOS
 * 23 Módulos - Todos los modelos Eloquent para producción
 * =========================================================================
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\{HasMany, BelongsTo, BelongsToMany, HasOne, MorphMany};
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

// =============================================================================
// M01 - TENANT
// =============================================================================
class Tenant extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'uuid', 'name', 'slug', 'rut', 'razon_social', 'giro', 'direccion',
        'comuna', 'region', 'telefono', 'email', 'website', 'logo', 'plan',
        'settings', 'features', 'active', 'trial_ends_at', 'subscription_ends_at'
    ];

    protected $casts = [
        'settings' => 'array',
        'features' => 'array',
        'active' => 'boolean',
        'trial_ends_at' => 'datetime',
        'subscription_ends_at' => 'datetime',
    ];

    public function users(): HasMany { return $this->hasMany(User::class); }
    public function copropiedades(): HasMany { return $this->hasMany(Copropiedad::class); }
    public function roles(): HasMany { return $this->hasMany(Role::class); }
}

// =============================================================================
// M02 - USER
// =============================================================================
class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    protected $fillable = [
        'uuid', 'tenant_id', 'name', 'email', 'rut', 'telefono', 'cargo',
        'password', 'avatar', 'status', 'preferences', 'last_login_at', 'last_login_ip'
    ];

    protected $hidden = ['password', 'remember_token'];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'preferences' => 'array',
        'last_login_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function roles(): BelongsToMany { return $this->belongsToMany(Role::class); }
    
    public function hasPermission(string $permission): bool
    {
        return $this->roles->flatMap->permissions->contains('slug', $permission);
    }
}

class Role extends Model
{
    use HasFactory;

    protected $fillable = ['tenant_id', 'name', 'slug', 'description', 'is_system', 'permissions'];
    protected $casts = ['permissions' => 'array', 'is_system' => 'boolean'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function users(): BelongsToMany { return $this->belongsToMany(User::class); }
}

class Permission extends Model
{
    use HasFactory;
    protected $fillable = ['name', 'slug', 'module', 'description'];
}

class AuditLog extends Model
{
    protected $fillable = [
        'tenant_id', 'user_id', 'action', 'model_type', 'model_id',
        'old_values', 'new_values', 'ip_address', 'user_agent'
    ];
    protected $casts = ['old_values' => 'array', 'new_values' => 'array'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}

// =============================================================================
// M03 - COPROPIEDAD
// =============================================================================
class Copropiedad extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'copropiedades';

    protected $fillable = [
        'uuid', 'tenant_id', 'nombre', 'nombre_fantasia', 'rut', 'direccion',
        'numero', 'comuna', 'region', 'codigo_postal', 'latitud', 'longitud',
        'tipo', 'categoria', 'ano_construccion', 'pisos', 'subterraneos',
        'superficie_terreno', 'superficie_construida', 'rol_sii',
        'numero_resolucion_dom', 'fecha_recepcion_final', 'administrador_nombre',
        'administrador_email', 'administrador_telefono', 'representante_legal',
        'representante_rut', 'tiene_inicio_actividades', 'fecha_inicio_actividades',
        'giro_tributario', 'regimen_tributario', 'configuracion', 'activa'
    ];

    protected $casts = [
        'configuracion' => 'array',
        'activa' => 'boolean',
        'tiene_inicio_actividades' => 'boolean',
        'fecha_recepcion_final' => 'date',
        'fecha_inicio_actividades' => 'date',
        'latitud' => 'decimal:8',
        'longitud' => 'decimal:8',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function unidades(): HasMany { return $this->hasMany(Unidad::class); }
    public function espaciosComunes(): HasMany { return $this->hasMany(EspacioComun::class); }
    public function contratosAntenas(): HasMany { return $this->hasMany(ContratoAntena::class); }
    public function periodosGasto(): HasMany { return $this->hasMany(PeriodoGasto::class); }
    public function gastosComunes(): HasMany { return $this->hasMany(GastoComun::class); }
    public function planesCuenta(): HasMany { return $this->hasMany(PlanCuenta::class); }
    public function periodosContables(): HasMany { return $this->hasMany(PeriodoContable::class); }
    public function asientosContables(): HasMany { return $this->hasMany(AsientoContable::class); }
    public function certificadosTributarios(): HasMany { return $this->hasMany(CertificadoTributario::class); }
    public function declaracionesJuradas(): HasMany { return $this->hasMany(DeclaracionJurada::class); }
    public function fondoReserva(): HasOne { return $this->hasOne(FondoReserva::class); }
    public function asambleas(): HasMany { return $this->hasMany(Asamblea::class); }
    public function complianceEvaluaciones(): HasMany { return $this->hasMany(ComplianceEvaluacion::class); }
    public function avaluos(): HasMany { return $this->hasMany(Avaluo::class); }
    public function precessionAnalyses(): HasMany { return $this->hasMany(PrecessionAnalysis::class); }
    public function ordenesTrabajo(): HasMany { return $this->hasMany(OrdenTrabajo::class); }
    public function comunicados(): HasMany { return $this->hasMany(Comunicado::class); }
    public function documentos(): MorphMany { return $this->morphMany(Documento::class, 'documentable'); }

    // Scopes
    public function scopeActivas($query) { return $query->where('activa', true); }
    public function scopeDelTenant($query, $tenantId) { return $query->where('tenant_id', $tenantId); }

    // Helpers
    public function getTotalUnidades(): int { return $this->unidades()->activas()->count(); }
    public function getIndiceOcupacion(): float
    {
        $total = $this->unidades()->activas()->count();
        if ($total === 0) return 0;
        $ocupadas = $this->unidades()->activas()->whereIn('estado_ocupacion', ['propietario', 'arrendada'])->count();
        return round(($ocupadas / $total) * 100, 2);
    }
}

class Unidad extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'unidades';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'numero', 'piso', 'tipo',
        'superficie_util', 'superficie_terraza', 'superficie_total',
        'dormitorios', 'banos', 'alicuota_prorrateo', 'alicuota_gastos',
        'rol_sii', 'avaluo_fiscal', 'estado_ocupacion', 'activa', 'caracteristicas'
    ];

    protected $casts = [
        'caracteristicas' => 'array',
        'activa' => 'boolean',
        'alicuota_prorrateo' => 'decimal:6',
        'alicuota_gastos' => 'decimal:6',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function copropietarios(): HasMany { return $this->hasMany(Copropietario::class); }
    public function cobrosUnidad(): HasMany { return $this->hasMany(CobroUnidad::class); }
    public function morosidad(): HasOne { return $this->hasOne(Morosidad::class); }
    public function contratosArriendo(): HasMany { return $this->hasMany(ContratoArriendo::class); }
    public function avaluos(): HasMany { return $this->hasMany(Avaluo::class); }

    public function scopeActivas($query) { return $query->where('activa', true); }

    public function getPropietarioPrincipal(): ?Copropietario
    {
        return $this->copropietarios()->where('rol', 'propietario')->where('es_principal', true)->first();
    }
}

class Copropietario extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'copropietarios';

    protected $fillable = [
        'uuid', 'tenant_id', 'unidad_id', 'tipo_persona', 'rut', 'nombre',
        'apellido_paterno', 'apellido_materno', 'razon_social', 'email',
        'telefono', 'direccion_correspondencia', 'rol', 'porcentaje_propiedad',
        'fecha_adquisicion', 'escritura_numero', 'notaria', 'es_principal', 'activo'
    ];

    protected $casts = [
        'es_principal' => 'boolean',
        'activo' => 'boolean',
        'fecha_adquisicion' => 'date',
        'porcentaje_propiedad' => 'decimal:2',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
    public function certificadosTributarios(): HasMany { return $this->hasMany(CertificadoTributario::class); }
    public function distribucionesAntenas(): HasMany { return $this->hasMany(DistribucionIngresoAntena::class); }

    public function getNombreCompleto(): string
    {
        if ($this->tipo_persona === 'juridica') return $this->razon_social;
        return trim("{$this->nombre} {$this->apellido_paterno} {$this->apellido_materno}");
    }
}

class EspacioComun extends Model
{
    use HasFactory;

    protected $table = 'espacios_comunes';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'nombre', 'tipo', 'superficie',
        'capacidad_personas', 'reservable', 'costo_arriendo', 'descripcion',
        'horarios', 'reglas', 'activo'
    ];

    protected $casts = [
        'horarios' => 'array',
        'reglas' => 'array',
        'reservable' => 'boolean',
        'activo' => 'boolean',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function contratosAntenas(): HasMany { return $this->hasMany(ContratoAntena::class); }
}

// =============================================================================
// M04 - ANTENAS Y TELECOMUNICACIONES
// =============================================================================
class ContratoAntena extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'contratos_antenas';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'espacio_comun_id', 'numero_contrato',
        'empresa_operador', 'rut_operador', 'representante_operador', 'email_operador',
        'telefono_operador', 'tipo_instalacion', 'ubicacion_instalacion',
        'superficie_ocupada_m2', 'potencia_watts', 'fecha_inicio', 'fecha_termino',
        'duracion_meses', 'renovacion_automatica', 'preaviso_dias',
        'fecha_asamblea_aprobacion', 'acta_asamblea_numero', 'quorum_aprobacion',
        'canon_mensual_uf', 'canon_mensual_clp', 'moneda', 'periodicidad_pago',
        'dia_pago', 'reajuste_anual_porcentaje', 'tipo_reajuste',
        'afecto_iva', 'tasa_iva', 'regimen_tributario', 'retencion_iva', 'porcentaje_retencion',
        'distribucion_tipo', 'porcentaje_fondo_comun', 'porcentaje_propietarios', 'porcentaje_fondo_reserva',
        'garantia_monto_uf', 'garantia_tipo', 'garantia_vencimiento',
        'seguro_responsabilidad', 'poliza_seguro', 'cobertura_seguro',
        'estado', 'observaciones', 'documentos'
    ];

    protected $casts = [
        'documentos' => 'array',
        'renovacion_automatica' => 'boolean',
        'afecto_iva' => 'boolean',
        'retencion_iva' => 'boolean',
        'seguro_responsabilidad' => 'boolean',
        'fecha_inicio' => 'date',
        'fecha_termino' => 'date',
        'fecha_asamblea_aprobacion' => 'date',
        'garantia_vencimiento' => 'date',
        'canon_mensual_uf' => 'decimal:4',
        'tasa_iva' => 'decimal:2',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function espacioComun(): BelongsTo { return $this->belongsTo(EspacioComun::class); }
    public function facturas(): HasMany { return $this->hasMany(FacturaAntena::class, 'contrato_antena_id'); }
    public function movimientosContables(): HasMany { return $this->hasMany(MovimientoContable::class); }

    public function scopeVigentes($query) { return $query->where('estado', 'vigente'); }

    public function calcularMontoMensualConIva(): float
    {
        $neto = $this->canon_mensual_clp ?? ($this->canon_mensual_uf * $this->getValorUF());
        return $this->afecto_iva ? $neto * (1 + $this->tasa_iva / 100) : $neto;
    }

    public function getValorUF(): float
    {
        return UfHistorico::whereDate('fecha', '<=', now())->orderByDesc('fecha')->first()?->valor ?? 38000;
    }
}

class FacturaAntena extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'facturas_antenas';

    protected $fillable = [
        'uuid', 'tenant_id', 'contrato_antena_id', 'copropiedad_id',
        'numero_factura', 'folio_sii', 'fecha_emision', 'fecha_vencimiento', 'periodo',
        'monto_neto_uf', 'monto_neto_clp', 'monto_iva', 'monto_total_clp', 'valor_uf_dia',
        'iva_incluido', 'tasa_iva_aplicada', 'monto_retencion', 'iva_retenido',
        'estado', 'fecha_pago', 'medio_pago', 'comprobante_pago',
        'track_id_sii', 'fecha_envio_sii', 'respuesta_sii', 'observaciones'
    ];

    protected $casts = [
        'respuesta_sii' => 'array',
        'iva_incluido' => 'boolean',
        'iva_retenido' => 'boolean',
        'fecha_emision' => 'date',
        'fecha_vencimiento' => 'date',
        'fecha_pago' => 'date',
        'fecha_envio_sii' => 'datetime',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function contratoAntena(): BelongsTo { return $this->belongsTo(ContratoAntena::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function distribuciones(): HasMany { return $this->hasMany(DistribucionIngresoAntena::class); }
}

class DistribucionIngresoAntena extends Model
{
    protected $table = 'distribucion_ingresos_antenas';

    protected $fillable = [
        'tenant_id', 'factura_antena_id', 'unidad_id', 'copropietario_id',
        'tipo_destino', 'porcentaje', 'monto_bruto_clp', 'monto_neto_clp',
        'monto_uf', 'pagado', 'fecha_pago', 'comprobante'
    ];

    protected $casts = [
        'pagado' => 'boolean',
        'fecha_pago' => 'date',
        'porcentaje' => 'decimal:6',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function facturaAntena(): BelongsTo { return $this->belongsTo(FacturaAntena::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
    public function copropietario(): BelongsTo { return $this->belongsTo(Copropietario::class); }
}

// =============================================================================
// M05 - GASTOS COMUNES
// =============================================================================
class PeriodoGasto extends Model
{
    protected $table = 'periodos_gasto';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'periodo', 'fecha_inicio', 'fecha_cierre',
        'fecha_vencimiento', 'estado', 'total_gastos_ordinarios',
        'total_gastos_extraordinarios', 'total_ingresos', 'fondo_reserva_aporte',
        'saldo_periodo_anterior'
    ];

    protected $casts = [
        'fecha_inicio' => 'date',
        'fecha_cierre' => 'date',
        'fecha_vencimiento' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function gastosComunes(): HasMany { return $this->hasMany(GastoComun::class, 'periodo_id'); }
    public function cobrosUnidad(): HasMany { return $this->hasMany(CobroUnidad::class, 'periodo_id'); }
}

class CategoriaGasto extends Model
{
    protected $table = 'categorias_gasto';

    protected $fillable = [
        'tenant_id', 'codigo', 'nombre', 'tipo', 'prorrateable', 'metodo_prorrateo',
        'cuenta_contable', 'afecto_iva', 'activo', 'orden'
    ];

    protected $casts = [
        'prorrateable' => 'boolean',
        'afecto_iva' => 'boolean',
        'activo' => 'boolean',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function gastosComunes(): HasMany { return $this->hasMany(GastoComun::class, 'categoria_id'); }
}

class GastoComun extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'gastos_comunes';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'periodo_id', 'categoria_id',
        'proveedor_id', 'descripcion', 'fecha', 'numero_documento',
        'monto_neto', 'monto_iva', 'monto_total', 'afecto_iva',
        'estado', 'fecha_pago', 'comprobante_pago', 'observaciones', 'archivos'
    ];

    protected $casts = [
        'archivos' => 'array',
        'afecto_iva' => 'boolean',
        'fecha' => 'date',
        'fecha_pago' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function periodo(): BelongsTo { return $this->belongsTo(PeriodoGasto::class); }
    public function categoria(): BelongsTo { return $this->belongsTo(CategoriaGasto::class); }
    public function proveedor(): BelongsTo { return $this->belongsTo(Proveedor::class); }
}

class CobroUnidad extends Model
{
    protected $table = 'cobros_unidad';

    protected $fillable = [
        'tenant_id', 'unidad_id', 'periodo_id', 'gasto_ordinario',
        'gasto_extraordinario', 'fondo_reserva', 'multas', 'intereses_mora',
        'ajustes', 'total_cobrar', 'total_pagado', 'saldo_pendiente',
        'fecha_vencimiento', 'estado', 'dias_mora'
    ];

    protected $casts = ['fecha_vencimiento' => 'date'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
    public function periodo(): BelongsTo { return $this->belongsTo(PeriodoGasto::class); }
    public function pagos(): HasMany { return $this->hasMany(Pago::class); }
}

class Pago extends Model
{
    protected $table = 'pagos';

    protected $fillable = [
        'uuid', 'tenant_id', 'cobro_unidad_id', 'fecha_pago', 'monto',
        'medio_pago', 'numero_operacion', 'banco', 'comprobante',
        'observaciones', 'registrado_por'
    ];

    protected $casts = ['fecha_pago' => 'date'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function cobroUnidad(): BelongsTo { return $this->belongsTo(CobroUnidad::class); }
    public function registradoPor(): BelongsTo { return $this->belongsTo(User::class, 'registrado_por'); }
}

// =============================================================================
// M06 - MOROSIDAD Y COBRANZA
// =============================================================================
class Morosidad extends Model
{
    protected $table = 'morosidad';

    protected $fillable = [
        'tenant_id', 'unidad_id', 'copropiedad_id', 'deuda_total',
        'deuda_ordinaria', 'deuda_extraordinaria', 'intereses_acumulados',
        'multas_acumuladas', 'meses_mora', 'fecha_inicio_mora',
        'periodo_mas_antiguo', 'categoria_riesgo', 'estado_gestion',
        'ultima_gestion', 'proximo_contacto', 'observaciones'
    ];

    protected $casts = [
        'fecha_inicio_mora' => 'date',
        'ultima_gestion' => 'date',
        'proximo_contacto' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function gestiones(): HasMany { return $this->hasMany(GestionCobranza::class); }
    public function convenios(): HasMany { return $this->hasMany(ConvenioPago::class); }
}

class GestionCobranza extends Model
{
    protected $table = 'gestiones_cobranza';

    protected $fillable = [
        'tenant_id', 'morosidad_id', 'usuario_id', 'fecha', 'tipo',
        'descripcion', 'resultado', 'fecha_compromiso', 'monto_compromiso', 'archivos'
    ];

    protected $casts = [
        'archivos' => 'array',
        'fecha' => 'date',
        'fecha_compromiso' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function morosidad(): BelongsTo { return $this->belongsTo(Morosidad::class); }
    public function usuario(): BelongsTo { return $this->belongsTo(User::class); }
}

class ConvenioPago extends Model
{
    use SoftDeletes;

    protected $table = 'convenios_pago';

    protected $fillable = [
        'uuid', 'tenant_id', 'morosidad_id', 'unidad_id', 'numero_convenio',
        'fecha_convenio', 'deuda_total', 'pie_inicial', 'numero_cuotas',
        'monto_cuota', 'tasa_interes_mensual', 'fecha_primera_cuota',
        'estado', 'cuotas_pagadas', 'condiciones'
    ];

    protected $casts = [
        'fecha_convenio' => 'date',
        'fecha_primera_cuota' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function morosidad(): BelongsTo { return $this->belongsTo(Morosidad::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
}

// =============================================================================
// M07 - PROVEEDORES
// =============================================================================
class Proveedor extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'proveedores';

    protected $fillable = [
        'uuid', 'tenant_id', 'rut', 'razon_social', 'nombre_fantasia', 'giro',
        'direccion', 'comuna', 'region', 'telefono', 'email',
        'contacto_nombre', 'contacto_cargo', 'contacto_telefono', 'contacto_email',
        'banco', 'tipo_cuenta', 'numero_cuenta', 'categoria', 'activo',
        'calificacion', 'documentos'
    ];

    protected $casts = [
        'documentos' => 'array',
        'activo' => 'boolean',
        'calificacion' => 'decimal:2',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function contratosServicio(): HasMany { return $this->hasMany(ContratoServicio::class); }
    public function gastosComunes(): HasMany { return $this->hasMany(GastoComun::class); }
    public function ordenesTrabajo(): HasMany { return $this->hasMany(OrdenTrabajo::class); }
}

class ContratoServicio extends Model
{
    use SoftDeletes;

    protected $table = 'contratos_servicio';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'proveedor_id', 'numero_contrato',
        'descripcion', 'tipo', 'fecha_inicio', 'fecha_termino',
        'renovacion_automatica', 'monto_mensual', 'monto_total', 'moneda',
        'afecto_iva', 'estado', 'condiciones', 'documentos'
    ];

    protected $casts = [
        'documentos' => 'array',
        'renovacion_automatica' => 'boolean',
        'afecto_iva' => 'boolean',
        'fecha_inicio' => 'date',
        'fecha_termino' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function proveedor(): BelongsTo { return $this->belongsTo(Proveedor::class); }
}

// =============================================================================
// M08 - CONTABILIDAD
// =============================================================================
class PlanCuenta extends Model
{
    protected $table = 'planes_cuenta';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'codigo', 'nombre', 'tipo', 'naturaleza',
        'nivel', 'cuenta_padre', 'es_cuenta_movimiento', 'requiere_centro_costo',
        'activa', 'descripcion'
    ];

    protected $casts = [
        'es_cuenta_movimiento' => 'boolean',
        'requiere_centro_costo' => 'boolean',
        'activa' => 'boolean',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function movimientos(): HasMany { return $this->hasMany(MovimientoContable::class, 'cuenta_id'); }
    public function saldos(): HasMany { return $this->hasMany(SaldoCuenta::class, 'cuenta_id'); }
}

class PeriodoContable extends Model
{
    protected $table = 'periodos_contables';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'ano', 'mes', 'fecha_inicio',
        'fecha_cierre', 'estado', 'cerrado_por', 'fecha_cierre_real'
    ];

    protected $casts = [
        'fecha_inicio' => 'date',
        'fecha_cierre' => 'date',
        'fecha_cierre_real' => 'datetime',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function asientos(): HasMany { return $this->hasMany(AsientoContable::class); }
    public function saldos(): HasMany { return $this->hasMany(SaldoCuenta::class); }
    public function cerradoPor(): BelongsTo { return $this->belongsTo(User::class, 'cerrado_por'); }
}

class LibroContable extends Model
{
    protected $table = 'libros_contables';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'tipo', 'ano', 'mes',
        'folio_desde', 'folio_hasta', 'estado', 'archivo_respaldo', 'fecha_generacion'
    ];

    protected $casts = ['fecha_generacion' => 'datetime'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function asientos(): HasMany { return $this->hasMany(AsientoContable::class, 'libro_id'); }
}

class AsientoContable extends Model
{
    use SoftDeletes;

    protected $table = 'asientos_contables';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'periodo_contable_id', 'libro_id',
        'numero_asiento', 'fecha', 'tipo', 'glosa', 'referencia',
        'documento_tipo', 'documento_id', 'total_debe', 'total_haber',
        'estado', 'creado_por', 'aprobado_por', 'fecha_aprobacion'
    ];

    protected $casts = [
        'fecha' => 'date',
        'fecha_aprobacion' => 'datetime',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function periodoContable(): BelongsTo { return $this->belongsTo(PeriodoContable::class); }
    public function libro(): BelongsTo { return $this->belongsTo(LibroContable::class); }
    public function movimientos(): HasMany { return $this->hasMany(MovimientoContable::class, 'asiento_id'); }
    public function creadoPor(): BelongsTo { return $this->belongsTo(User::class, 'creado_por'); }
    public function aprobadoPor(): BelongsTo { return $this->belongsTo(User::class, 'aprobado_por'); }

    public function estaBalanceado(): bool
    {
        return abs($this->total_debe - $this->total_haber) < 0.01;
    }
}

class MovimientoContable extends Model
{
    protected $table = 'movimientos_contables';

    protected $fillable = [
        'tenant_id', 'asiento_id', 'cuenta_id', 'tipo_movimiento', 'monto',
        'glosa_linea', 'unidad_id', 'copropietario_id', 'proveedor_id', 'contrato_antena_id'
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function asiento(): BelongsTo { return $this->belongsTo(AsientoContable::class); }
    public function cuenta(): BelongsTo { return $this->belongsTo(PlanCuenta::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
    public function copropietario(): BelongsTo { return $this->belongsTo(Copropietario::class); }
    public function proveedor(): BelongsTo { return $this->belongsTo(Proveedor::class); }
    public function contratoAntena(): BelongsTo { return $this->belongsTo(ContratoAntena::class); }
}

class SaldoCuenta extends Model
{
    protected $table = 'saldos_cuenta';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'cuenta_id', 'periodo_contable_id',
        'saldo_inicial', 'debitos', 'creditos', 'saldo_final'
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function cuenta(): BelongsTo { return $this->belongsTo(PlanCuenta::class); }
    public function periodoContable(): BelongsTo { return $this->belongsTo(PeriodoContable::class); }
}

// =============================================================================
// M09 - CERTIFICADOS TRIBUTARIOS
// =============================================================================
class CertificadoTributario extends Model
{
    protected $table = 'certificados_tributarios';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'copropietario_id', 'unidad_id',
        'tipo', 'ano_tributario', 'folio', 'fecha_emision', 'fecha_vigencia',
        'monto_ingresos', 'monto_gastos', 'monto_participacion',
        'porcentaje_participacion', 'monto_deuda', 'detalle',
        'estado', 'codigo_verificacion', 'archivo_pdf', 'emitido_por', 'observaciones'
    ];

    protected $casts = [
        'detalle' => 'array',
        'fecha_emision' => 'date',
        'fecha_vigencia' => 'date',
        'porcentaje_participacion' => 'decimal:6',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function copropietario(): BelongsTo { return $this->belongsTo(Copropietario::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
    public function emitidoPor(): BelongsTo { return $this->belongsTo(User::class, 'emitido_por'); }

    public static function generarFolio(int $tenantId, int $ano): string
    {
        $ultimo = self::where('tenant_id', $tenantId)
            ->where('ano_tributario', $ano)
            ->orderByDesc('id')
            ->first();
        $numero = $ultimo ? intval(substr($ultimo->folio, -6)) + 1 : 1;
        return "CT-{$ano}-" . str_pad($numero, 6, '0', STR_PAD_LEFT);
    }
}

// =============================================================================
// M10 - DECLARACIONES JURADAS E INTEGRACIÓN SII
// =============================================================================
class DeclaracionJurada extends Model
{
    protected $table = 'declaraciones_juradas';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'tipo_dj', 'ano_tributario',
        'periodo', 'fecha_presentacion', 'folio_sii', 'estado', 'datos',
        'respuesta_sii', 'archivo_txt', 'archivo_pdf', 'generada_por',
        'fecha_envio', 'observaciones'
    ];

    protected $casts = [
        'datos' => 'array',
        'respuesta_sii' => 'array',
        'fecha_presentacion' => 'date',
        'fecha_envio' => 'datetime',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function generadaPor(): BelongsTo { return $this->belongsTo(User::class, 'generada_por'); }
}

class IntegracionSiiConfig extends Model
{
    protected $table = 'integracion_sii_config';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'rut_empresa', 'razon_social', 'giro',
        'direccion', 'comuna', 'ciudad', 'codigo_actividad_sii',
        'fecha_resolucion_sii', 'numero_resolucion_sii',
        'certificado_digital', 'certificado_password', 'certificado_vigencia',
        'ambiente', 'activo'
    ];

    protected $casts = [
        'fecha_resolucion_sii' => 'date',
        'certificado_vigencia' => 'date',
        'activo' => 'boolean',
    ];

    protected $hidden = ['certificado_digital', 'certificado_password'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
}

// =============================================================================
// M11 - FONDO DE RESERVA
// =============================================================================
class FondoReserva extends Model
{
    protected $table = 'fondos_reserva';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'saldo_actual', 'porcentaje_aporte_mensual',
        'meta_fondo', 'ultima_actualizacion', 'politica_uso'
    ];

    protected $casts = [
        'politica_uso' => 'array',
        'ultima_actualizacion' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function movimientos(): HasMany { return $this->hasMany(MovimientoFondoReserva::class, 'fondo_id'); }
}

class MovimientoFondoReserva extends Model
{
    protected $table = 'movimientos_fondo_reserva';

    protected $fillable = [
        'tenant_id', 'fondo_id', 'fecha', 'tipo', 'monto', 'saldo_posterior',
        'descripcion', 'periodo', 'acta_asamblea', 'asiento_id'
    ];

    protected $casts = ['fecha' => 'date'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function fondo(): BelongsTo { return $this->belongsTo(FondoReserva::class); }
    public function asiento(): BelongsTo { return $this->belongsTo(AsientoContable::class); }
}

// =============================================================================
// M12 - ASAMBLEAS
// =============================================================================
class Asamblea extends Model
{
    protected $table = 'asambleas';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'tipo', 'numero', 'fecha',
        'hora_primera_citacion', 'hora_segunda_citacion', 'lugar', 'modalidad',
        'orden_del_dia', 'quorum_requerido', 'quorum_asistencia',
        'unidades_presentes', 'unidades_representadas', 'estado'
    ];

    protected $casts = ['fecha' => 'date'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function acta(): HasOne { return $this->hasOne(ActaAsamblea::class); }
}

class ActaAsamblea extends Model
{
    protected $table = 'actas_asamblea';

    protected $fillable = [
        'uuid', 'tenant_id', 'asamblea_id', 'numero_acta', 'fecha_hora_inicio',
        'fecha_hora_termino', 'desarrollo', 'acuerdos', 'votaciones',
        'presidente_asamblea', 'secretario_acta', 'estado',
        'archivo_pdf', 'archivo_firmado'
    ];

    protected $casts = [
        'acuerdos' => 'array',
        'votaciones' => 'array',
        'fecha_hora_inicio' => 'datetime',
        'fecha_hora_termino' => 'datetime',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function asamblea(): BelongsTo { return $this->belongsTo(Asamblea::class); }
}

// =============================================================================
// M13 - COMPLIANCE
// =============================================================================
class ComplianceEvaluacion extends Model
{
    protected $table = 'compliance_evaluaciones';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'fecha_evaluacion', 'periodo_evaluado',
        'score_global', 'score_ley21442', 'score_ds7_2025', 'score_tributario',
        'score_contable', 'score_transparencia', 'brechas', 'recomendaciones',
        'plan_accion', 'estado', 'evaluador_id'
    ];

    protected $casts = [
        'brechas' => 'array',
        'recomendaciones' => 'array',
        'plan_accion' => 'array',
        'fecha_evaluacion' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function evaluador(): BelongsTo { return $this->belongsTo(User::class, 'evaluador_id'); }
}

class RequisitoNormativo extends Model
{
    protected $table = 'requisitos_normativos';

    protected $fillable = [
        'tenant_id', 'codigo', 'nombre', 'normativa', 'descripcion',
        'obligatoriedad', 'frecuencia_verificacion', 'criterios_cumplimiento', 'activo'
    ];

    protected $casts = [
        'criterios_cumplimiento' => 'array',
        'activo' => 'boolean',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
}

// =============================================================================
// M14 - VALORIZACIÓN
// =============================================================================
class Avaluo extends Model
{
    protected $table = 'avaluos';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'unidad_id', 'tipo',
        'fecha_avaluo', 'fecha_vigencia', 'valor_terreno', 'valor_construccion',
        'valor_total', 'valor_uf', 'valor_m2', 'fuente', 'tasador',
        'observaciones', 'datos_adicionales'
    ];

    protected $casts = [
        'datos_adicionales' => 'array',
        'fecha_avaluo' => 'date',
        'fecha_vigencia' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
}

// =============================================================================
// M15 - PAE (PRECESSION ANALYTICS) - Modelos ya existentes
// =============================================================================
class PrecessionAnalysis extends Model
{
    protected $table = 'precession_analyses';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id', 'tenant_id', 'copropiedad_id', 'analysis_type', 'status',
        'precession_score', 'risk_score', 'opportunity_score', 'confidence',
        'total_precession_value_uf', 'direct_value_uf', 'induced_value_uf',
        'precession_value_uf', 'systemic_value_uf', 'counter_value_uf',
        'effects_summary', 'effects_count', 'ml_predictions', 'parameters',
        'execution_time_ms', 'expires_at'
    ];

    protected $casts = [
        'effects_summary' => 'array',
        'ml_predictions' => 'array',
        'parameters' => 'array',
        'expires_at' => 'datetime',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function alerts(): HasMany { return $this->hasMany(PrecessionAlert::class, 'analysis_id'); }
}

class PrecessionAlert extends Model
{
    protected $table = 'precession_alerts';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'analysis_id', 'alert_type',
        'severity', 'precession_angle', 'status', 'title', 'description',
        'recommendation', 'probability', 'potential_impact_uf', 'expected_months',
        'data', 'acknowledged_at', 'acknowledged_by', 'resolved_at', 'resolved_by',
        'resolution_notes', 'expires_at', 'synced_to_agora', 'synced_at'
    ];

    protected $casts = [
        'data' => 'array',
        'synced_to_agora' => 'boolean',
        'acknowledged_at' => 'datetime',
        'resolved_at' => 'datetime',
        'expires_at' => 'datetime',
        'synced_at' => 'datetime',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function analysis(): BelongsTo { return $this->belongsTo(PrecessionAnalysis::class); }
    public function acknowledgedBy(): BelongsTo { return $this->belongsTo(User::class, 'acknowledged_by'); }
    public function resolvedBy(): BelongsTo { return $this->belongsTo(User::class, 'resolved_by'); }
}

// =============================================================================
// M16 - ARRIENDOS
// =============================================================================
class ContratoArriendo extends Model
{
    use SoftDeletes;

    protected $table = 'contratos_arriendo';

    protected $fillable = [
        'uuid', 'tenant_id', 'unidad_id', 'arrendador_id', 'arrendatario_rut',
        'arrendatario_nombre', 'arrendatario_email', 'arrendatario_telefono',
        'fecha_inicio', 'fecha_termino', 'renovacion_automatica',
        'canon_mensual', 'moneda', 'dia_pago', 'garantia', 'meses_garantia',
        'estado', 'observaciones', 'documentos'
    ];

    protected $casts = [
        'documentos' => 'array',
        'renovacion_automatica' => 'boolean',
        'fecha_inicio' => 'date',
        'fecha_termino' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
    public function arrendador(): BelongsTo { return $this->belongsTo(Copropietario::class, 'arrendador_id'); }
}

// =============================================================================
// M17 - MANTENCIONES
// =============================================================================
class OrdenTrabajo extends Model
{
    use SoftDeletes;

    protected $table = 'ordenes_trabajo';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'espacio_comun_id', 'unidad_id',
        'proveedor_id', 'numero', 'titulo', 'descripcion', 'tipo', 'prioridad',
        'estado', 'fecha_solicitud', 'fecha_programada', 'fecha_inicio_real',
        'fecha_termino_real', 'presupuesto_estimado', 'costo_real',
        'solicitado_por', 'aprobado_por', 'observaciones', 'fotos_antes', 'fotos_despues'
    ];

    protected $casts = [
        'fotos_antes' => 'array',
        'fotos_despues' => 'array',
        'fecha_solicitud' => 'date',
        'fecha_programada' => 'date',
        'fecha_inicio_real' => 'date',
        'fecha_termino_real' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function espacioComun(): BelongsTo { return $this->belongsTo(EspacioComun::class); }
    public function unidad(): BelongsTo { return $this->belongsTo(Unidad::class); }
    public function proveedor(): BelongsTo { return $this->belongsTo(Proveedor::class); }
    public function solicitadoPor(): BelongsTo { return $this->belongsTo(User::class, 'solicitado_por'); }
    public function aprobadoPor(): BelongsTo { return $this->belongsTo(User::class, 'aprobado_por'); }
}

class PlanMantencion extends Model
{
    protected $table = 'plan_mantencion';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'nombre', 'descripcion', 'equipo_sistema',
        'frecuencia', 'proxima_ejecucion', 'ultima_ejecucion', 'proveedor_id', 'activo'
    ];

    protected $casts = [
        'activo' => 'boolean',
        'proxima_ejecucion' => 'date',
        'ultima_ejecucion' => 'date',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function proveedor(): BelongsTo { return $this->belongsTo(Proveedor::class); }
}

// =============================================================================
// M18 - COMUNICACIONES
// =============================================================================
class Comunicado extends Model
{
    protected $table = 'comunicados';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'titulo', 'contenido', 'tipo',
        'canal', 'destinatarios', 'fecha_publicacion', 'fecha_expiracion',
        'requiere_confirmacion', 'confirmaciones_recibidas', 'estado',
        'creado_por', 'archivos_adjuntos'
    ];

    protected $casts = [
        'destinatarios' => 'array',
        'archivos_adjuntos' => 'array',
        'requiere_confirmacion' => 'boolean',
        'fecha_publicacion' => 'datetime',
        'fecha_expiracion' => 'datetime',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function creadoPor(): BelongsTo { return $this->belongsTo(User::class, 'creado_por'); }
}

// =============================================================================
// M19 - REPORTES
// =============================================================================
class ReporteConfigurado extends Model
{
    protected $table = 'reportes_configurados';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'nombre', 'codigo', 'tipo',
        'parametros', 'columnas', 'filtros', 'formato_salida',
        'programado', 'frecuencia_programada', 'destinatarios_email', 'activo'
    ];

    protected $casts = [
        'parametros' => 'array',
        'columnas' => 'array',
        'filtros' => 'array',
        'destinatarios_email' => 'array',
        'programado' => 'boolean',
        'activo' => 'boolean',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function reportesGenerados(): HasMany { return $this->hasMany(ReporteGenerado::class, 'reporte_config_id'); }
}

class ReporteGenerado extends Model
{
    protected $table = 'reportes_generados';

    protected $fillable = [
        'uuid', 'tenant_id', 'reporte_config_id', 'copropiedad_id', 'periodo',
        'fecha_generacion', 'archivo', 'formato', 'tamano_bytes',
        'generado_por', 'enviado_email'
    ];

    protected $casts = [
        'enviado_email' => 'boolean',
        'fecha_generacion' => 'datetime',
    ];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function reporteConfig(): BelongsTo { return $this->belongsTo(ReporteConfigurado::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function generadoPor(): BelongsTo { return $this->belongsTo(User::class, 'generado_por'); }
}

// =============================================================================
// M20 - DOCUMENTOS
// =============================================================================
class Documento extends Model
{
    use SoftDeletes;

    protected $table = 'documentos';

    protected $fillable = [
        'uuid', 'tenant_id', 'copropiedad_id', 'documentable_type', 'documentable_id',
        'nombre', 'nombre_original', 'ruta', 'mime_type', 'tamano_bytes',
        'categoria', 'descripcion', 'publico', 'subido_por'
    ];

    protected $casts = ['publico' => 'boolean'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }
    public function documentable() { return $this->morphTo(); }
    public function subidoPor(): BelongsTo { return $this->belongsTo(User::class, 'subido_por'); }
}

// =============================================================================
// M21 - CONFIGURACIONES
// =============================================================================
class Configuracion extends Model
{
    protected $table = 'configuraciones';

    protected $fillable = [
        'tenant_id', 'copropiedad_id', 'grupo', 'clave', 'valor',
        'tipo', 'descripcion', 'editable'
    ];

    protected $casts = ['editable' => 'boolean'];

    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function copropiedad(): BelongsTo { return $this->belongsTo(Copropiedad::class); }

    public static function get(string $grupo, string $clave, $default = null, ?int $tenantId = null, ?int $copropiedadId = null)
    {
        $query = self::where('grupo', $grupo)->where('clave', $clave);
        if ($tenantId) $query->where('tenant_id', $tenantId);
        if ($copropiedadId) $query->where('copropiedad_id', $copropiedadId);
        $config = $query->first();
        return $config ? $config->valor : $default;
    }
}

class UfHistorico extends Model
{
    protected $table = 'uf_historico';

    protected $fillable = ['fecha', 'valor'];
    protected $casts = ['fecha' => 'date', 'valor' => 'decimal:4'];

    public static function getValor(?string $fecha = null): float
    {
        $fecha = $fecha ?? now()->format('Y-m-d');
        $uf = self::where('fecha', '<=', $fecha)->orderByDesc('fecha')->first();
        return $uf?->valor ?? 38000;
    }
}
