<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - SERVICIOS DE NEGOCIO
 * Lógica de negocio para los 23 módulos
 * =========================================================================
 */

namespace App\Services;

use Illuminate\Support\Facades\{DB, Cache, Log};
use App\Models\{
    Copropiedad, Unidad, Copropietario, ContratoAntena, FacturaAntena,
    DistribucionIngresoAntena, PeriodoGasto, GastoComun, CobroUnidad,
    Morosidad, PlanCuenta, AsientoContable, MovimientoContable, SaldoCuenta,
    PeriodoContable, CertificadoTributario, FondoReserva, MovimientoFondoReserva,
    ComplianceEvaluacion, PrecessionAnalysis, PrecessionAlert, UfHistorico
};
use Carbon\Carbon;

// =============================================================================
// SERVICIO DE VALOR UF
// =============================================================================
class UfService
{
    public static function getValor(?string $fecha = null): float
    {
        $fecha = $fecha ?? now()->format('Y-m-d');
        
        return Cache::remember("uf:{$fecha}", 3600, function () use ($fecha) {
            $uf = UfHistorico::where('fecha', '<=', $fecha)
                ->orderByDesc('fecha')
                ->first();
            return $uf?->valor ?? 39950.56;
        });
    }

    public static function convertirClpToUf(float $monto, ?string $fecha = null): float
    {
        return round($monto / self::getValor($fecha), 4);
    }

    public static function convertirUfToClp(float $monto, ?string $fecha = null): float
    {
        return round($monto * self::getValor($fecha), 0);
    }
}

// =============================================================================
// SERVICIO DE ANTENAS Y TELECOMUNICACIONES
// =============================================================================
class AntenaService
{
    public function __construct(
        private ContabilidadService $contabilidad,
        private FondoReservaService $fondoReserva
    ) {}

    /**
     * Genera factura mensual para un contrato de antena
     */
    public function generarFactura(ContratoAntena $contrato, string $periodo): FacturaAntena
    {
        $valorUf = UfService::getValor();
        
        // Calcular montos
        $montoNetoUf = $contrato->canon_mensual_uf;
        $montoNetoClp = $montoNetoUf * $valorUf;
        $montoIva = $contrato->afecto_iva ? $montoNetoClp * ($contrato->tasa_iva / 100) : 0;
        $montoTotal = $montoNetoClp + $montoIva;

        // Crear factura
        $factura = FacturaAntena::create([
            'uuid' => \Str::uuid(),
            'tenant_id' => $contrato->tenant_id,
            'contrato_antena_id' => $contrato->id,
            'copropiedad_id' => $contrato->copropiedad_id,
            'fecha_emision' => now(),
            'fecha_vencimiento' => now()->addDays(30),
            'periodo' => $periodo,
            'monto_neto_uf' => $montoNetoUf,
            'monto_neto_clp' => $montoNetoClp,
            'monto_iva' => $montoIva,
            'monto_total_clp' => $montoTotal,
            'valor_uf_dia' => $valorUf,
            'iva_incluido' => $contrato->afecto_iva,
            'tasa_iva_aplicada' => $contrato->tasa_iva,
            'estado' => 'emitida',
        ]);

        // Generar distribución
        $this->generarDistribucion($factura, $contrato);

        // Generar asiento contable
        $this->contabilidad->registrarIngresoAntena($factura);

        Log::info('Factura antena generada', [
            'factura_id' => $factura->id,
            'contrato' => $contrato->numero_contrato,
            'monto' => $montoTotal,
        ]);

        return $factura;
    }

    /**
     * Distribuye los ingresos según configuración del contrato
     */
    private function generarDistribucion(FacturaAntena $factura, ContratoAntena $contrato): void
    {
        $montoDistribuir = $factura->monto_neto_clp;
        $valorUf = $factura->valor_uf_dia;

        // Fondo común
        if ($contrato->porcentaje_fondo_comun > 0) {
            $monto = $montoDistribuir * ($contrato->porcentaje_fondo_comun / 100);
            DistribucionIngresoAntena::create([
                'tenant_id' => $factura->tenant_id,
                'factura_antena_id' => $factura->id,
                'tipo_destino' => 'fondo_comun',
                'porcentaje' => $contrato->porcentaje_fondo_comun / 100,
                'monto_bruto_clp' => $monto,
                'monto_neto_clp' => $monto,
                'monto_uf' => $monto / $valorUf,
            ]);
        }

        // Fondo de reserva
        if ($contrato->porcentaje_fondo_reserva > 0) {
            $monto = $montoDistribuir * ($contrato->porcentaje_fondo_reserva / 100);
            
            DistribucionIngresoAntena::create([
                'tenant_id' => $factura->tenant_id,
                'factura_antena_id' => $factura->id,
                'tipo_destino' => 'fondo_reserva',
                'porcentaje' => $contrato->porcentaje_fondo_reserva / 100,
                'monto_bruto_clp' => $monto,
                'monto_neto_clp' => $monto,
                'monto_uf' => $monto / $valorUf,
            ]);

            // Actualizar fondo de reserva
            $this->fondoReserva->registrarIngreso(
                $contrato->copropiedad_id,
                $monto,
                'ingreso_antena',
                "Ingreso antena {$contrato->empresa_operador} - {$factura->periodo}"
            );
        }

        // Distribución a propietarios
        if ($contrato->porcentaje_propietarios > 0) {
            $montoTotal = $montoDistribuir * ($contrato->porcentaje_propietarios / 100);
            $unidades = Unidad::where('copropiedad_id', $contrato->copropiedad_id)
                ->where('activa', true)->get();

            foreach ($unidades as $unidad) {
                $montoPropietario = $montoTotal * $unidad->alicuota_prorrateo;
                $copropietario = $unidad->copropietarios()
                    ->where('rol', 'propietario')
                    ->where('es_principal', true)
                    ->first();

                DistribucionIngresoAntena::create([
                    'tenant_id' => $factura->tenant_id,
                    'factura_antena_id' => $factura->id,
                    'unidad_id' => $unidad->id,
                    'copropietario_id' => $copropietario?->id,
                    'tipo_destino' => 'propietario',
                    'porcentaje' => $unidad->alicuota_prorrateo,
                    'monto_bruto_clp' => $montoPropietario,
                    'monto_neto_clp' => $montoPropietario,
                    'monto_uf' => $montoPropietario / $valorUf,
                ]);
            }
        }
    }

    /**
     * Facturación masiva de todos los contratos vigentes
     */
    public function facturacionMasiva(int $tenantId, string $periodo): array
    {
        $contratos = ContratoAntena::where('tenant_id', $tenantId)
            ->where('estado', 'vigente')
            ->get();

        $resultados = ['exitosos' => 0, 'errores' => []];

        foreach ($contratos as $contrato) {
            try {
                // Verificar si ya existe factura para el período
                $existe = FacturaAntena::where('contrato_antena_id', $contrato->id)
                    ->where('periodo', $periodo)
                    ->exists();

                if (!$existe) {
                    $this->generarFactura($contrato, $periodo);
                    $resultados['exitosos']++;
                }
            } catch (\Exception $e) {
                $resultados['errores'][] = [
                    'contrato' => $contrato->numero_contrato,
                    'error' => $e->getMessage(),
                ];
            }
        }

        return $resultados;
    }
}

// =============================================================================
// SERVICIO DE CONTABILIDAD
// =============================================================================
class ContabilidadService
{
    /**
     * Registra asiento contable por ingreso de antena
     */
    public function registrarIngresoAntena(FacturaAntena $factura): AsientoContable
    {
        $periodo = $this->obtenerPeriodoContable($factura->copropiedad_id, $factura->fecha_emision);
        $numeroAsiento = $this->siguienteNumeroAsiento($factura->copropiedad_id, $periodo->id);

        DB::beginTransaction();
        try {
            $asiento = AsientoContable::create([
                'uuid' => \Str::uuid(),
                'tenant_id' => $factura->tenant_id,
                'copropiedad_id' => $factura->copropiedad_id,
                'periodo_contable_id' => $periodo->id,
                'numero_asiento' => $numeroAsiento,
                'fecha' => $factura->fecha_emision,
                'tipo' => 'ingreso',
                'glosa' => "Factura antena {$factura->periodo} - {$factura->contratoAntena->empresa_operador}",
                'documento_tipo' => 'factura_antena',
                'documento_id' => $factura->id,
                'total_debe' => $factura->monto_total_clp,
                'total_haber' => $factura->monto_total_clp,
                'estado' => 'contabilizado',
                'creado_por' => auth()->id() ?? 1,
                'aprobado_por' => auth()->id() ?? 1,
                'fecha_aprobacion' => now(),
            ]);

            // Debe: Deudores por Antenas
            $this->crearMovimiento($asiento, '1202', 'debe', $factura->monto_total_clp, 
                "Deudor {$factura->contratoAntena->empresa_operador}");

            // Haber: Ingresos por Antenas
            $this->crearMovimiento($asiento, '4201', 'haber', $factura->monto_neto_clp,
                "Ingreso antena período {$factura->periodo}");

            // Haber: IVA Débito (si aplica)
            if ($factura->monto_iva > 0) {
                $this->crearMovimiento($asiento, '2104', 'haber', $factura->monto_iva,
                    "IVA Débito factura antena");
            }

            DB::commit();
            return $asiento;
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Registra asiento por pago de gasto común
     */
    public function registrarPagoGasto(GastoComun $gasto): AsientoContable
    {
        $periodo = $this->obtenerPeriodoContable($gasto->copropiedad_id, $gasto->fecha_pago);
        $numeroAsiento = $this->siguienteNumeroAsiento($gasto->copropiedad_id, $periodo->id);

        DB::beginTransaction();
        try {
            $asiento = AsientoContable::create([
                'uuid' => \Str::uuid(),
                'tenant_id' => $gasto->tenant_id,
                'copropiedad_id' => $gasto->copropiedad_id,
                'periodo_contable_id' => $periodo->id,
                'numero_asiento' => $numeroAsiento,
                'fecha' => $gasto->fecha_pago,
                'tipo' => 'egreso',
                'glosa' => "Pago gasto: {$gasto->descripcion}",
                'documento_tipo' => 'gasto_comun',
                'documento_id' => $gasto->id,
                'total_debe' => $gasto->monto_total,
                'total_haber' => $gasto->monto_total,
                'estado' => 'contabilizado',
                'creado_por' => auth()->id() ?? 1,
            ]);

            // Debe: Cuenta de gasto
            $cuentaGasto = $gasto->categoria->cuenta_contable ?? '5199';
            $this->crearMovimiento($asiento, $cuentaGasto, 'debe', $gasto->monto_neto,
                $gasto->descripcion);

            // Debe: IVA Crédito (si aplica)
            if ($gasto->monto_iva > 0) {
                $this->crearMovimiento($asiento, '1301', 'debe', $gasto->monto_iva,
                    "IVA Crédito");
            }

            // Haber: Banco
            $this->crearMovimiento($asiento, '1102', 'haber', $gasto->monto_total,
                "Pago {$gasto->numero_documento}");

            DB::commit();
            return $asiento;
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Genera balance general
     */
    public function generarBalance(int $copropiedadId, int $ano, int $mes): array
    {
        $periodo = PeriodoContable::where('copropiedad_id', $copropiedadId)
            ->where('ano', $ano)
            ->where('mes', $mes)
            ->first();

        if (!$periodo) {
            return ['error' => 'Período no encontrado'];
        }

        $saldos = SaldoCuenta::where('periodo_contable_id', $periodo->id)
            ->with('cuenta')
            ->get();

        return [
            'periodo' => "{$ano}-{$mes}",
            'activos' => $saldos->where('cuenta.tipo', 'activo')->sum('saldo_final'),
            'pasivos' => $saldos->where('cuenta.tipo', 'pasivo')->sum('saldo_final'),
            'patrimonio' => $saldos->where('cuenta.tipo', 'patrimonio')->sum('saldo_final'),
            'ingresos' => $saldos->where('cuenta.tipo', 'ingreso')->sum('saldo_final'),
            'gastos' => $saldos->where('cuenta.tipo', 'gasto')->sum('saldo_final'),
            'resultado' => $saldos->where('cuenta.tipo', 'ingreso')->sum('saldo_final') 
                         - $saldos->where('cuenta.tipo', 'gasto')->sum('saldo_final'),
            'detalle' => $saldos->groupBy('cuenta.tipo'),
        ];
    }

    /**
     * Cierra período contable
     */
    public function cerrarPeriodo(int $copropiedadId, int $ano, int $mes): PeriodoContable
    {
        $periodo = PeriodoContable::where('copropiedad_id', $copropiedadId)
            ->where('ano', $ano)
            ->where('mes', $mes)
            ->firstOrFail();

        if ($periodo->estado === 'cerrado') {
            throw new \Exception('El período ya está cerrado');
        }

        // Recalcular saldos
        $this->recalcularSaldos($periodo);

        // Marcar como cerrado
        $periodo->update([
            'estado' => 'cerrado',
            'cerrado_por' => auth()->id(),
            'fecha_cierre_real' => now(),
        ]);

        return $periodo;
    }

    private function obtenerPeriodoContable(int $copropiedadId, $fecha): PeriodoContable
    {
        $fecha = Carbon::parse($fecha);
        
        return PeriodoContable::firstOrCreate(
            [
                'copropiedad_id' => $copropiedadId,
                'ano' => $fecha->year,
                'mes' => $fecha->month,
            ],
            [
                'tenant_id' => Copropiedad::find($copropiedadId)->tenant_id,
                'fecha_inicio' => $fecha->copy()->startOfMonth(),
                'fecha_cierre' => $fecha->copy()->endOfMonth(),
                'estado' => 'abierto',
            ]
        );
    }

    private function siguienteNumeroAsiento(int $copropiedadId, int $periodoId): int
    {
        return AsientoContable::where('copropiedad_id', $copropiedadId)
            ->where('periodo_contable_id', $periodoId)
            ->max('numero_asiento') + 1;
    }

    private function crearMovimiento(AsientoContable $asiento, string $codigoCuenta, 
        string $tipoMovimiento, float $monto, ?string $glosa = null): MovimientoContable
    {
        $cuenta = PlanCuenta::where('codigo', $codigoCuenta)
            ->where(function($q) use ($asiento) {
                $q->where('copropiedad_id', $asiento->copropiedad_id)
                  ->orWhereNull('copropiedad_id');
            })
            ->firstOrFail();

        $movimiento = MovimientoContable::create([
            'tenant_id' => $asiento->tenant_id,
            'asiento_id' => $asiento->id,
            'cuenta_id' => $cuenta->id,
            'tipo_movimiento' => $tipoMovimiento,
            'monto' => $monto,
            'glosa_linea' => $glosa,
        ]);

        // Actualizar saldo
        $this->actualizarSaldo($movimiento, $asiento);

        return $movimiento;
    }

    private function actualizarSaldo(MovimientoContable $movimiento, AsientoContable $asiento): void
    {
        $cuenta = $movimiento->cuenta;
        
        $saldo = SaldoCuenta::firstOrCreate(
            [
                'cuenta_id' => $movimiento->cuenta_id,
                'periodo_contable_id' => $asiento->periodo_contable_id,
            ],
            [
                'tenant_id' => $asiento->tenant_id,
                'copropiedad_id' => $asiento->copropiedad_id,
                'saldo_inicial' => 0,
                'debitos' => 0,
                'creditos' => 0,
                'saldo_final' => 0,
            ]
        );

        if ($movimiento->tipo_movimiento === 'debe') {
            $saldo->increment('debitos', $movimiento->monto);
        } else {
            $saldo->increment('creditos', $movimiento->monto);
        }

        // Recalcular saldo final
        if ($cuenta->naturaleza === 'deudora') {
            $saldo->saldo_final = $saldo->saldo_inicial + $saldo->debitos - $saldo->creditos;
        } else {
            $saldo->saldo_final = $saldo->saldo_inicial - $saldo->debitos + $saldo->creditos;
        }
        $saldo->save();
    }

    private function recalcularSaldos(PeriodoContable $periodo): void
    {
        $saldos = SaldoCuenta::where('periodo_contable_id', $periodo->id)->get();
        
        foreach ($saldos as $saldo) {
            $movimientos = MovimientoContable::whereHas('asiento', function($q) use ($periodo) {
                $q->where('periodo_contable_id', $periodo->id)
                  ->where('estado', 'contabilizado');
            })->where('cuenta_id', $saldo->cuenta_id)->get();

            $saldo->debitos = $movimientos->where('tipo_movimiento', 'debe')->sum('monto');
            $saldo->creditos = $movimientos->where('tipo_movimiento', 'haber')->sum('monto');

            $cuenta = $saldo->cuenta;
            if ($cuenta->naturaleza === 'deudora') {
                $saldo->saldo_final = $saldo->saldo_inicial + $saldo->debitos - $saldo->creditos;
            } else {
                $saldo->saldo_final = $saldo->saldo_inicial - $saldo->debitos + $saldo->creditos;
            }
            $saldo->save();
        }
    }
}

// =============================================================================
// SERVICIO DE FONDO DE RESERVA
// =============================================================================
class FondoReservaService
{
    public function registrarIngreso(int $copropiedadId, float $monto, string $tipo, string $descripcion): void
    {
        $fondo = FondoReserva::firstOrCreate(
            ['copropiedad_id' => $copropiedadId],
            [
                'tenant_id' => Copropiedad::find($copropiedadId)->tenant_id,
                'saldo_actual' => 0,
                'porcentaje_aporte_mensual' => 5,
                'ultima_actualizacion' => now(),
            ]
        );

        $fondo->increment('saldo_actual', $monto);
        $fondo->update(['ultima_actualizacion' => now()]);

        MovimientoFondoReserva::create([
            'tenant_id' => $fondo->tenant_id,
            'fondo_id' => $fondo->id,
            'fecha' => now(),
            'tipo' => $tipo,
            'monto' => $monto,
            'saldo_posterior' => $fondo->saldo_actual,
            'descripcion' => $descripcion,
        ]);
    }

    public function registrarUso(int $copropiedadId, float $monto, string $descripcion, string $actaAsamblea): void
    {
        $fondo = FondoReserva::where('copropiedad_id', $copropiedadId)->firstOrFail();

        if ($monto > $fondo->saldo_actual) {
            throw new \Exception('Saldo insuficiente en fondo de reserva');
        }

        $fondo->decrement('saldo_actual', $monto);
        $fondo->update(['ultima_actualizacion' => now()]);

        MovimientoFondoReserva::create([
            'tenant_id' => $fondo->tenant_id,
            'fondo_id' => $fondo->id,
            'fecha' => now(),
            'tipo' => 'uso_autorizado',
            'monto' => -$monto,
            'saldo_posterior' => $fondo->saldo_actual,
            'descripcion' => $descripcion,
            'acta_asamblea' => $actaAsamblea,
        ]);
    }
}

// =============================================================================
// SERVICIO DE CERTIFICADOS TRIBUTARIOS
// =============================================================================
class CertificadoService
{
    public function emitirCertificadoComunidad(int $copropiedadId, int $anoTributario): CertificadoTributario
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);

        // Calcular totales del año
        $ingresos = FacturaAntena::where('copropiedad_id', $copropiedadId)
            ->whereYear('fecha_emision', $anoTributario)
            ->where('estado', 'pagada')
            ->sum('monto_neto_clp');

        $gastos = GastoComun::where('copropiedad_id', $copropiedadId)
            ->whereYear('fecha', $anoTributario)
            ->where('estado', 'pagado')
            ->sum('monto_total');

        $contratos = ContratoAntena::where('copropiedad_id', $copropiedadId)
            ->where('estado', 'vigente')
            ->count();

        return CertificadoTributario::create([
            'uuid' => \Str::uuid(),
            'tenant_id' => $copropiedad->tenant_id,
            'copropiedad_id' => $copropiedadId,
            'tipo' => 'cumplimiento_comunidad',
            'ano_tributario' => $anoTributario,
            'folio' => $this->generarFolio($copropiedad->tenant_id, $anoTributario),
            'fecha_emision' => now(),
            'fecha_vigencia' => now()->addMonths(6),
            'monto_ingresos' => $ingresos,
            'monto_gastos' => $gastos,
            'detalle' => [
                'rut_comunidad' => $copropiedad->rut,
                'nombre' => $copropiedad->nombre,
                'direccion' => $copropiedad->direccion,
                'comuna' => $copropiedad->comuna,
                'contratos_antenas' => $contratos,
                'regimen_tributario' => $copropiedad->regimen_tributario,
                'tiene_inicio_actividades' => $copropiedad->tiene_inicio_actividades,
            ],
            'estado' => 'emitido',
            'codigo_verificacion' => \Str::random(32),
            'emitido_por' => auth()->id() ?? 1,
        ]);
    }

    public function emitirCertificadoParticipacion(int $copropietarioId, int $anoTributario): CertificadoTributario
    {
        $copropietario = Copropietario::with('unidad.copropiedad')->findOrFail($copropietarioId);
        $unidad = $copropietario->unidad;
        $copropiedad = $unidad->copropiedad;

        // Calcular participación en ingresos
        $participacion = DistribucionIngresoAntena::whereHas('facturaAntena', function($q) use ($copropiedad, $anoTributario) {
            $q->where('copropiedad_id', $copropiedad->id)
              ->whereYear('fecha_emision', $anoTributario);
        })
        ->where('copropietario_id', $copropietarioId)
        ->sum('monto_neto_clp');

        return CertificadoTributario::create([
            'uuid' => \Str::uuid(),
            'tenant_id' => $copropiedad->tenant_id,
            'copropiedad_id' => $copropiedad->id,
            'copropietario_id' => $copropietarioId,
            'unidad_id' => $unidad->id,
            'tipo' => 'participacion_rentas',
            'ano_tributario' => $anoTributario,
            'folio' => $this->generarFolio($copropiedad->tenant_id, $anoTributario),
            'fecha_emision' => now(),
            'fecha_vigencia' => now()->addMonths(6),
            'monto_participacion' => $participacion,
            'porcentaje_participacion' => $unidad->alicuota_prorrateo,
            'detalle' => [
                'rut_copropietario' => $copropietario->rut,
                'nombre' => $copropietario->getNombreCompleto(),
                'unidad' => $unidad->numero,
                'copropiedad' => $copropiedad->nombre,
                'alicuota' => ($unidad->alicuota_prorrateo * 100) . '%',
            ],
            'estado' => 'emitido',
            'codigo_verificacion' => \Str::random(32),
            'emitido_por' => auth()->id() ?? 1,
        ]);
    }

    private function generarFolio(int $tenantId, int $ano): string
    {
        $ultimo = CertificadoTributario::where('tenant_id', $tenantId)
            ->where('ano_tributario', $ano)
            ->orderByDesc('id')
            ->first();
        
        $numero = $ultimo ? intval(substr($ultimo->folio, -6)) + 1 : 1;
        return "CT-{$ano}-" . str_pad($numero, 6, '0', STR_PAD_LEFT);
    }
}

// =============================================================================
// SERVICIO DE COMPLIANCE
// =============================================================================
class ComplianceService
{
    public function evaluar(int $copropiedadId): ComplianceEvaluacion
    {
        $copropiedad = Copropiedad::with([
            'fondoReserva', 
            'contratosAntenas', 
            'asambleas'
        ])->findOrFail($copropiedadId);

        $brechas = [];
        $scores = [
            'ley21442' => $this->evaluarLey21442($copropiedad, $brechas),
            'ds7_2025' => $this->evaluarDS7($copropiedad, $brechas),
            'tributario' => $this->evaluarTributario($copropiedad, $brechas),
            'contable' => $this->evaluarContable($copropiedad, $brechas),
            'transparencia' => $this->evaluarTransparencia($copropiedad, $brechas),
        ];

        $scoreGlobal = collect($scores)->avg();

        return ComplianceEvaluacion::create([
            'uuid' => \Str::uuid(),
            'tenant_id' => $copropiedad->tenant_id,
            'copropiedad_id' => $copropiedadId,
            'fecha_evaluacion' => now(),
            'periodo_evaluado' => now()->format('Y-m'),
            'score_global' => $scoreGlobal,
            'score_ley21442' => $scores['ley21442'],
            'score_ds7_2025' => $scores['ds7_2025'],
            'score_tributario' => $scores['tributario'],
            'score_contable' => $scores['contable'],
            'score_transparencia' => $scores['transparencia'],
            'brechas' => $brechas,
            'recomendaciones' => $this->generarRecomendaciones($brechas),
            'estado' => 'publicado',
            'evaluador_id' => auth()->id() ?? 1,
        ]);
    }

    private function evaluarLey21442(Copropiedad $copropiedad, array &$brechas): float
    {
        $score = 100;

        // Fondo de reserva mínimo 5%
        $fondo = $copropiedad->fondoReserva;
        if (!$fondo || $fondo->porcentaje_aporte_mensual < 5) {
            $score -= 20;
            $brechas['ley21442'][] = [
                'codigo' => 'L21442-02',
                'descripcion' => 'Fondo de reserva bajo el mínimo legal (5%)',
                'criticidad' => 'alta',
            ];
        }

        // Contratos con acta de asamblea
        $contratosSinActa = $copropiedad->contratosAntenas()
            ->whereNull('acta_asamblea_numero')
            ->where('estado', 'vigente')
            ->count();
        if ($contratosSinActa > 0) {
            $score -= 15;
            $brechas['ley21442'][] = [
                'codigo' => 'L21442-04',
                'descripcion' => "{$contratosSinActa} contratos sin acta de asamblea",
                'criticidad' => 'alta',
            ];
        }

        // Asamblea ordinaria anual
        $ultimaOrdinaria = $copropiedad->asambleas()
            ->where('tipo', 'ordinaria')
            ->where('estado', 'realizada')
            ->orderByDesc('fecha')
            ->first();
        if (!$ultimaOrdinaria || $ultimaOrdinaria->fecha < now()->subYear()) {
            $score -= 15;
            $brechas['ley21442'][] = [
                'codigo' => 'L21442-03',
                'descripcion' => 'Sin asamblea ordinaria en los últimos 12 meses',
                'criticidad' => 'alta',
            ];
        }

        return max(0, $score);
    }

    private function evaluarDS7(Copropiedad $copropiedad, array &$brechas): float
    {
        // Simplificado para demo
        return 85;
    }

    private function evaluarTributario(Copropiedad $copropiedad, array &$brechas): float
    {
        $score = 100;

        // Contratos afectos sin facturación reciente
        $contratosAfectos = ContratoAntena::where('copropiedad_id', $copropiedad->id)
            ->where('afecto_iva', true)
            ->where('estado', 'vigente')
            ->get();

        foreach ($contratosAfectos as $contrato) {
            $ultimaFactura = $contrato->facturas()->orderByDesc('periodo')->first();
            if (!$ultimaFactura || $ultimaFactura->periodo < now()->subMonths(2)->format('Y-m')) {
                $score -= 10;
                $brechas['tributario'][] = [
                    'codigo' => 'SII-03',
                    'descripcion' => "Contrato {$contrato->numero_contrato} sin facturación reciente",
                    'criticidad' => 'alta',
                ];
            }
        }

        return max(0, $score);
    }

    private function evaluarContable(Copropiedad $copropiedad, array &$brechas): float
    {
        $score = 100;

        $periodosPendientes = PeriodoContable::where('copropiedad_id', $copropiedad->id)
            ->where('estado', 'abierto')
            ->where('fecha_cierre', '<', now()->subMonth())
            ->count();

        if ($periodosPendientes > 0) {
            $score -= min($periodosPendientes * 10, 40);
            $brechas['contable'][] = [
                'codigo' => 'CTB-01',
                'descripcion' => "{$periodosPendientes} períodos contables sin cerrar",
                'criticidad' => $periodosPendientes > 2 ? 'alta' : 'media',
            ];
        }

        return max(0, $score);
    }

    private function evaluarTransparencia(Copropiedad $copropiedad, array &$brechas): float
    {
        return 90; // Simplificado para demo
    }

    private function generarRecomendaciones(array $brechas): array
    {
        $recomendaciones = [];

        foreach ($brechas as $categoria => $items) {
            foreach ($items as $brecha) {
                $recomendaciones[] = [
                    'categoria' => $categoria,
                    'codigo' => $brecha['codigo'],
                    'brecha' => $brecha['descripcion'],
                    'accion' => $this->sugerirAccion($brecha['codigo']),
                    'prioridad' => $brecha['criticidad'],
                ];
            }
        }

        return $recomendaciones;
    }

    private function sugerirAccion(string $codigo): string
    {
        $acciones = [
            'L21442-02' => 'Ajustar porcentaje de aporte a fondo de reserva al mínimo legal de 5%',
            'L21442-03' => 'Convocar asamblea ordinaria anual',
            'L21442-04' => 'Convocar asamblea extraordinaria para ratificar contratos pendientes',
            'SII-03' => 'Emitir facturas pendientes de contratos de antenas',
            'CTB-01' => 'Cerrar períodos contables pendientes',
        ];

        return $acciones[$codigo] ?? 'Revisar y corregir la situación identificada';
    }
}

// =============================================================================
// SERVICIO PAE (PRECESSION ANALYTICS ENGINE)
// =============================================================================
class PrecessionService
{
    public function analyzeCopropiedad(int $copropiedadId, array $params = []): PrecessionAnalysis
    {
        $copropiedad = Copropiedad::with([
            'unidades', 'contratosAntenas', 'fondoReserva', 'morosidad'
        ])->findOrFail($copropiedadId);

        $horizon = $params['horizon'] ?? 36;
        $maxDepth = $params['max_depth'] ?? 4;
        $startTime = microtime(true);

        // Análisis de precesión
        $riskScore = $this->calcularRiesgo($copropiedad);
        $opportunityScore = $this->calcularOportunidad($copropiedad);
        $precessionScore = ($opportunityScore * 0.6) + ((100 - $riskScore) * 0.4);

        // Calcular valores
        $valores = $this->calcularValores($copropiedad, $horizon);

        $analysis = PrecessionAnalysis::create([
            'id' => \Str::uuid(),
            'tenant_id' => $copropiedad->tenant_id,
            'copropiedad_id' => $copropiedadId,
            'analysis_type' => 'full',
            'status' => 'completed',
            'precession_score' => $precessionScore,
            'risk_score' => $riskScore,
            'opportunity_score' => $opportunityScore,
            'confidence' => 0.85,
            'total_precession_value_uf' => $valores['total'],
            'direct_value_uf' => $valores['directo'],
            'induced_value_uf' => $valores['inducido'],
            'precession_value_uf' => $valores['precesion'],
            'systemic_value_uf' => $valores['sistemico'],
            'effects_summary' => $this->generarResumenEfectos($copropiedad),
            'effects_count' => 12,
            'parameters' => $params,
            'execution_time_ms' => (microtime(true) - $startTime) * 1000,
            'expires_at' => now()->addHours(1),
        ]);

        // Generar alertas
        $this->generarAlertas($analysis, $copropiedad);

        return $analysis;
    }

    private function calcularRiesgo(Copropiedad $copropiedad): float
    {
        $riesgo = 0;

        // Morosidad
        $totalUnidades = $copropiedad->unidades()->activas()->count();
        if ($totalUnidades > 0) {
            $morosos = Morosidad::whereHas('unidad', fn($q) => $q->where('copropiedad_id', $copropiedad->id))
                ->where('deuda_total', '>', 0)->count();
            $riesgo += ($morosos / $totalUnidades) * 30;
        }

        // Contratos por vencer
        $contratosPorVencer = $copropiedad->contratosAntenas()
            ->where('estado', 'vigente')
            ->where('fecha_termino', '<=', now()->addMonths(6))
            ->count();
        $riesgo += min($contratosPorVencer * 5, 20);

        // Fondo de reserva bajo
        $fondo = $copropiedad->fondoReserva;
        if ($fondo && $fondo->meta_fondo > 0) {
            $cumplimiento = ($fondo->saldo_actual / $fondo->meta_fondo) * 100;
            if ($cumplimiento < 50) {
                $riesgo += 15;
            }
        }

        return min($riesgo, 100);
    }

    private function calcularOportunidad(Copropiedad $copropiedad): float
    {
        $oportunidad = 50; // Base

        // Potencial de nuevas antenas
        $espaciosDisponibles = $copropiedad->espaciosComunes()
            ->whereNotIn('id', function($q) use ($copropiedad) {
                $q->select('espacio_comun_id')
                  ->from('contratos_antenas')
                  ->where('copropiedad_id', $copropiedad->id)
                  ->where('estado', 'vigente');
            })->count();
        $oportunidad += min($espaciosDisponibles * 10, 30);

        // Renovaciones próximas (oportunidad de renegociación)
        $renovaciones = $copropiedad->contratosAntenas()
            ->where('estado', 'vigente')
            ->where('renovacion_automatica', true)
            ->where('fecha_termino', '<=', now()->addYear())
            ->count();
        $oportunidad += min($renovaciones * 5, 20);

        return min($oportunidad, 100);
    }

    private function calcularValores(Copropiedad $copropiedad, int $horizon): array
    {
        $ingresosMensuales = $copropiedad->contratosAntenas()
            ->where('estado', 'vigente')
            ->sum('canon_mensual_uf');

        $directo = $ingresosMensuales * $horizon;
        $inducido = $directo * 0.15; // Efecto multiplicador
        $precesion = ($directo + $inducido) * 0.08; // Efectos de segundo orden
        $sistemico = $precesion * 0.5;

        return [
            'directo' => $directo,
            'inducido' => $inducido,
            'precesion' => $precesion,
            'sistemico' => $sistemico,
            'total' => $directo + $inducido + $precesion + $sistemico,
        ];
    }

    private function generarResumenEfectos(Copropiedad $copropiedad): array
    {
        return [
            'efectos_directos' => [
                'ingresos_antenas' => 'Flujo constante de ingresos por telecomunicaciones',
                'fondo_reserva' => 'Fortalecimiento del fondo de reserva',
            ],
            'efectos_inducidos' => [
                'reduccion_gastos' => 'Posible reducción de gastos comunes',
                'mejora_infraestructura' => 'Capacidad de inversión en mejoras',
            ],
            'efectos_precesion' => [
                'valorizacion' => 'Potencial aumento de valor de unidades',
                'satisfaccion' => 'Mayor satisfacción de copropietarios',
            ],
        ];
    }

    private function generarAlertas(PrecessionAnalysis $analysis, Copropiedad $copropiedad): void
    {
        // Alerta por contratos por vencer
        $contratosPorVencer = $copropiedad->contratosAntenas()
            ->where('estado', 'vigente')
            ->where('fecha_termino', '<=', now()->addMonths(3))
            ->get();

        foreach ($contratosPorVencer as $contrato) {
            PrecessionAlert::create([
                'uuid' => \Str::uuid(),
                'tenant_id' => $copropiedad->tenant_id,
                'copropiedad_id' => $copropiedad->id,
                'analysis_id' => $analysis->id,
                'alert_type' => 'contract_expiring',
                'severity' => 'warning',
                'status' => 'active',
                'title' => "Contrato por vencer: {$contrato->empresa_operador}",
                'description' => "El contrato {$contrato->numero_contrato} vence el {$contrato->fecha_termino->format('d/m/Y')}",
                'recommendation' => 'Iniciar negociaciones de renovación o buscar nuevos operadores',
                'potential_impact_uf' => $contrato->canon_mensual_uf * 12,
                'expected_months' => $contrato->fecha_termino->diffInMonths(now()),
                'expires_at' => $contrato->fecha_termino,
            ]);
        }

        // Alerta por morosidad alta
        if ($analysis->risk_score > 50) {
            PrecessionAlert::create([
                'uuid' => \Str::uuid(),
                'tenant_id' => $copropiedad->tenant_id,
                'copropiedad_id' => $copropiedad->id,
                'analysis_id' => $analysis->id,
                'alert_type' => 'high_risk',
                'severity' => 'high',
                'status' => 'active',
                'title' => 'Nivel de riesgo elevado',
                'description' => "El score de riesgo es {$analysis->risk_score}%",
                'recommendation' => 'Revisar morosidad y gestionar cobranza preventiva',
            ]);
        }
    }
}
