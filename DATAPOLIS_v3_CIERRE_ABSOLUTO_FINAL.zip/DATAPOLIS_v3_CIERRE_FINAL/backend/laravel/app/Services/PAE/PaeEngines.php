<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - PAE ENGINES NATIVOS
 * Precession Analytics Engine - Implementación PHP Pura
 * Sin dependencias externas de APIs
 * =========================================================================
 */

namespace App\Services\PAE;

use Illuminate\Support\Facades\{DB, Cache, Log};
use App\Models\{
    Copropiedad, Unidad, ContratoAntena, Morosidad, FondoReserva,
    ComplianceEvaluacion, PrecessionAnalysis, PrecessionAlert, UfHistorico
};
use Carbon\Carbon;

// =============================================================================
// PRECESSION GRAPH ENGINE - Ontología y Grafo de Efectos
// =============================================================================
class PrecessionGraphEngine
{
    private array $nodeTypes = [
        'copropiedad' => ['weight' => 1.0, 'category' => 'entity'],
        'unidad' => ['weight' => 0.8, 'category' => 'entity'],
        'contrato_antena' => ['weight' => 0.9, 'category' => 'financial'],
        'fondo_reserva' => ['weight' => 0.85, 'category' => 'financial'],
        'morosidad' => ['weight' => 0.7, 'category' => 'risk'],
        'compliance' => ['weight' => 0.75, 'category' => 'regulatory'],
        'asamblea' => ['weight' => 0.6, 'category' => 'governance'],
        'proveedor' => ['weight' => 0.5, 'category' => 'operational'],
        'mantencion' => ['weight' => 0.55, 'category' => 'operational'],
        'valuacion' => ['weight' => 0.65, 'category' => 'financial'],
        'ingreso' => ['weight' => 0.9, 'category' => 'financial'],
        'gasto' => ['weight' => 0.85, 'category' => 'financial'],
    ];

    private array $edgeTypes = [
        'genera_ingreso' => ['weight' => 0.9, 'direction' => 'positive'],
        'genera_gasto' => ['weight' => 0.8, 'direction' => 'negative'],
        'impacta_valor' => ['weight' => 0.85, 'direction' => 'variable'],
        'requiere_compliance' => ['weight' => 0.7, 'direction' => 'constraint'],
        'afecta_morosidad' => ['weight' => 0.75, 'direction' => 'risk'],
        'financia' => ['weight' => 0.8, 'direction' => 'positive'],
        'consume' => ['weight' => 0.7, 'direction' => 'negative'],
        'precede' => ['weight' => 0.6, 'direction' => 'temporal'],
        'depende_de' => ['weight' => 0.65, 'direction' => 'dependency'],
        'potencia' => ['weight' => 0.8, 'direction' => 'synergy'],
        'mitiga' => ['weight' => 0.7, 'direction' => 'hedge'],
        'amplifica' => ['weight' => 0.75, 'direction' => 'leverage'],
        'contrarresta' => ['weight' => 0.6, 'direction' => 'counter'],
        'induce' => ['weight' => 0.7, 'direction' => 'indirect'],
        'cataliza' => ['weight' => 0.85, 'direction' => 'accelerator'],
    ];

    /**
     * Construir grafo ontológico de la copropiedad
     */
    public function buildGraph(int $copropiedadId): array
    {
        $copropiedad = Copropiedad::with([
            'unidades',
            'contratosAntenas',
            'fondoReserva',
            'periodosGasto',
            'asambleas',
            'proveedores',
        ])->findOrFail($copropiedadId);

        $nodes = [];
        $edges = [];

        // Nodo central: Copropiedad
        $nodes['copropiedad_' . $copropiedadId] = [
            'id' => 'copropiedad_' . $copropiedadId,
            'type' => 'copropiedad',
            'data' => [
                'nombre' => $copropiedad->nombre,
                'total_unidades' => $copropiedad->unidades->count(),
                'tiene_inicio_actividades' => $copropiedad->tiene_inicio_actividades,
            ],
            'weight' => $this->nodeTypes['copropiedad']['weight'],
            'category' => $this->nodeTypes['copropiedad']['category'],
        ];

        // Nodos de unidades
        foreach ($copropiedad->unidades as $unidad) {
            $nodeId = 'unidad_' . $unidad->id;
            $nodes[$nodeId] = [
                'id' => $nodeId,
                'type' => 'unidad',
                'data' => [
                    'numero' => $unidad->numero,
                    'alicuota' => $unidad->alicuota_prorrateo,
                    'tipo' => $unidad->tipo,
                ],
                'weight' => $this->nodeTypes['unidad']['weight'] * $unidad->alicuota_prorrateo,
                'category' => $this->nodeTypes['unidad']['category'],
            ];

            $edges[] = [
                'source' => 'copropiedad_' . $copropiedadId,
                'target' => $nodeId,
                'type' => 'contiene',
                'weight' => $unidad->alicuota_prorrateo,
            ];

            // Morosidad de la unidad
            $morosidad = Morosidad::where('unidad_id', $unidad->id)->first();
            if ($morosidad && $morosidad->deuda_total > 0) {
                $morosidadNodeId = 'morosidad_' . $unidad->id;
                $nodes[$morosidadNodeId] = [
                    'id' => $morosidadNodeId,
                    'type' => 'morosidad',
                    'data' => [
                        'deuda' => $morosidad->deuda_total,
                        'meses' => $morosidad->meses_mora,
                        'categoria' => $morosidad->categoria_riesgo,
                    ],
                    'weight' => $this->calcularPesoMorosidad($morosidad),
                    'category' => 'risk',
                ];

                $edges[] = [
                    'source' => $nodeId,
                    'target' => $morosidadNodeId,
                    'type' => 'afecta_morosidad',
                    'weight' => $this->edgeTypes['afecta_morosidad']['weight'],
                ];
            }
        }

        // Nodos de contratos de antenas
        foreach ($copropiedad->contratosAntenas as $contrato) {
            if ($contrato->estado !== 'vigente') continue;

            $nodeId = 'contrato_' . $contrato->id;
            $valorUf = UfHistorico::getValor();
            $ingresoAnual = $contrato->canon_mensual_uf * 12 * $valorUf;

            $nodes[$nodeId] = [
                'id' => $nodeId,
                'type' => 'contrato_antena',
                'data' => [
                    'operador' => $contrato->empresa_operador,
                    'canon_uf' => $contrato->canon_mensual_uf,
                    'ingreso_anual_clp' => $ingresoAnual,
                    'afecto_iva' => $contrato->afecto_iva,
                    'vencimiento' => $contrato->fecha_termino,
                ],
                'weight' => min(1.0, $ingresoAnual / 50000000), // Normalizado
                'category' => 'financial',
            ];

            $edges[] = [
                'source' => $nodeId,
                'target' => 'copropiedad_' . $copropiedadId,
                'type' => 'genera_ingreso',
                'weight' => $this->edgeTypes['genera_ingreso']['weight'],
                'value' => $ingresoAnual,
            ];

            // Verificar si vence pronto (efecto precesional)
            if ($contrato->fecha_termino) {
                $diasParaVencer = Carbon::parse($contrato->fecha_termino)->diffInDays(now(), false);
                if ($diasParaVencer <= 180 && $diasParaVencer > 0) {
                    $edges[] = [
                        'source' => $nodeId,
                        'target' => 'copropiedad_' . $copropiedadId,
                        'type' => 'precede',
                        'weight' => 1 - ($diasParaVencer / 180),
                        'effect' => 'vencimiento_contrato',
                    ];
                }
            }
        }

        // Nodo de fondo de reserva
        if ($copropiedad->fondoReserva) {
            $fondo = $copropiedad->fondoReserva;
            $nodeId = 'fondo_' . $fondo->id;
            
            $nodes[$nodeId] = [
                'id' => $nodeId,
                'type' => 'fondo_reserva',
                'data' => [
                    'saldo' => $fondo->saldo_actual,
                    'porcentaje' => $fondo->porcentaje_aporte_mensual,
                    'cumple_minimo' => $fondo->porcentaje_aporte_mensual >= 5,
                ],
                'weight' => min(1.0, $fondo->saldo_actual / 100000000),
                'category' => 'financial',
            ];

            $edges[] = [
                'source' => 'copropiedad_' . $copropiedadId,
                'target' => $nodeId,
                'type' => 'financia',
                'weight' => $this->edgeTypes['financia']['weight'],
            ];

            // Efecto precesional: fondo bajo mínimo
            if ($fondo->porcentaje_aporte_mensual < 5) {
                $edges[] = [
                    'source' => $nodeId,
                    'target' => 'copropiedad_' . $copropiedadId,
                    'type' => 'requiere_compliance',
                    'weight' => 0.9,
                    'effect' => 'fondo_bajo_minimo',
                ];
            }
        }

        // Nodo de compliance
        $ultimoCompliance = ComplianceEvaluacion::where('copropiedad_id', $copropiedadId)
            ->orderByDesc('fecha_evaluacion')
            ->first();

        if ($ultimoCompliance) {
            $nodeId = 'compliance_' . $ultimoCompliance->id;
            $nodes[$nodeId] = [
                'id' => $nodeId,
                'type' => 'compliance',
                'data' => [
                    'score_global' => $ultimoCompliance->score_global,
                    'brechas_count' => count($ultimoCompliance->brechas ?? []),
                ],
                'weight' => $ultimoCompliance->score_global / 100,
                'category' => 'regulatory',
            ];

            $edges[] = [
                'source' => 'copropiedad_' . $copropiedadId,
                'target' => $nodeId,
                'type' => 'requiere_compliance',
                'weight' => $this->edgeTypes['requiere_compliance']['weight'],
            ];
        }

        return [
            'nodes' => $nodes,
            'edges' => $edges,
            'metadata' => [
                'copropiedad_id' => $copropiedadId,
                'total_nodes' => count($nodes),
                'total_edges' => count($edges),
                'built_at' => now()->toIso8601String(),
            ],
        ];
    }

    /**
     * Calcular efectos de precesión mediante BFS
     */
    public function calculatePrecessionEffects(array $graph, array $params = []): array
    {
        $maxDepth = $params['max_depth'] ?? 4;
        $horizon = $params['horizon'] ?? 36; // meses
        
        $effects = [];
        $visited = [];
        $queue = [];

        // Iniciar desde nodos financieros (generadores de valor)
        foreach ($graph['nodes'] as $nodeId => $node) {
            if ($node['category'] === 'financial') {
                $queue[] = ['node' => $nodeId, 'depth' => 0, 'path' => [$nodeId], 'accumulated_weight' => $node['weight']];
            }
        }

        while (!empty($queue)) {
            $current = array_shift($queue);
            $nodeId = $current['node'];
            $depth = $current['depth'];
            $path = $current['path'];
            $accWeight = $current['accumulated_weight'];

            if ($depth >= $maxDepth) continue;
            if (isset($visited[$nodeId . '_' . $depth])) continue;
            $visited[$nodeId . '_' . $depth] = true;

            // Buscar aristas salientes
            foreach ($graph['edges'] as $edge) {
                if ($edge['source'] === $nodeId) {
                    $targetNode = $graph['nodes'][$edge['target']] ?? null;
                    if (!$targetNode) continue;

                    $newWeight = $accWeight * $edge['weight'] * $targetNode['weight'];
                    
                    // Registrar efecto precesional
                    if ($depth > 0) { // No el primer nivel (directo)
                        $effectType = $this->classifyEffect($edge['type'], $depth);
                        $effects[] = [
                            'id' => uniqid('effect_'),
                            'source' => $path[0],
                            'target' => $edge['target'],
                            'path' => array_merge($path, [$edge['target']]),
                            'depth' => $depth + 1,
                            'type' => $effectType,
                            'edge_type' => $edge['type'],
                            'weight' => $newWeight,
                            'direction' => $this->edgeTypes[$edge['type']]['direction'] ?? 'neutral',
                            'value' => $edge['value'] ?? 0,
                        ];
                    }

                    // Agregar a la cola para continuar BFS
                    $queue[] = [
                        'node' => $edge['target'],
                        'depth' => $depth + 1,
                        'path' => array_merge($path, [$edge['target']]),
                        'accumulated_weight' => $newWeight,
                    ];
                }
            }
        }

        // Agrupar efectos por tipo
        $groupedEffects = [
            'direct' => [],
            'induced' => [],
            'precession' => [],
            'systemic' => [],
            'counter' => [],
        ];

        foreach ($effects as $effect) {
            $groupedEffects[$effect['type']][] = $effect;
        }

        return [
            'effects' => $effects,
            'grouped' => $groupedEffects,
            'summary' => [
                'total_effects' => count($effects),
                'by_type' => array_map('count', $groupedEffects),
                'max_depth_reached' => max(array_column($effects, 'depth') ?: [0]),
            ],
        ];
    }

    private function classifyEffect(string $edgeType, int $depth): string
    {
        if ($depth === 1) return 'direct';
        if ($depth === 2) return 'induced';
        if ($depth === 3) return 'precession';
        if ($depth >= 4) return 'systemic';
        
        if (in_array($edgeType, ['contrarresta', 'mitiga'])) {
            return 'counter';
        }
        
        return 'precession';
    }

    private function calcularPesoMorosidad(Morosidad $morosidad): float
    {
        $peso = match($morosidad->categoria_riesgo) {
            'critico' => 0.95,
            'alto' => 0.8,
            'medio' => 0.5,
            'bajo' => 0.2,
            default => 0.3,
        };
        
        return min(1.0, $peso + ($morosidad->meses_mora * 0.05));
    }
}

// =============================================================================
// PRECESSION SCORING ENGINE - Cálculo de Scores
// =============================================================================
class PrecessionScoringEngine
{
    /**
     * Calcular scores multi-dimensionales
     */
    public function calculateScores(int $copropiedadId, array $effects): array
    {
        $copropiedad = Copropiedad::with([
            'contratosAntenas',
            'fondoReserva',
            'unidades.morosidad',
        ])->findOrFail($copropiedadId);

        // Score de precesión (efectos secundarios positivos)
        $precessionScore = $this->calculatePrecessionScore($effects);
        
        // Score de riesgo
        $riskScore = $this->calculateRiskScore($copropiedad, $effects);
        
        // Score de oportunidad
        $opportunityScore = $this->calculateOpportunityScore($copropiedad, $effects);
        
        // Confianza del análisis
        $confidence = $this->calculateConfidence($effects);

        return [
            'precession_score' => round($precessionScore, 2),
            'risk_score' => round($riskScore, 4),
            'opportunity_score' => round($opportunityScore, 4),
            'confidence' => round($confidence, 4),
            'composite_score' => round(($precessionScore * 0.4 + (1 - $riskScore) * 0.3 + $opportunityScore * 0.3) * 100, 2),
        ];
    }

    private function calculatePrecessionScore(array $effects): float
    {
        if (empty($effects['effects'])) return 50.0;

        $positiveEffects = array_filter($effects['effects'], fn($e) => $e['direction'] === 'positive');
        $negativeEffects = array_filter($effects['effects'], fn($e) => $e['direction'] === 'negative');
        
        $positiveWeight = array_sum(array_column($positiveEffects, 'weight'));
        $negativeWeight = array_sum(array_column($negativeEffects, 'weight'));
        
        $totalWeight = $positiveWeight + $negativeWeight;
        if ($totalWeight === 0) return 50.0;
        
        $ratio = $positiveWeight / $totalWeight;
        
        // Escalar a 0-100
        return $ratio * 100;
    }

    private function calculateRiskScore(Copropiedad $copropiedad, array $effects): float
    {
        $riskFactors = 0;
        $maxFactors = 5;

        // Factor 1: Morosidad
        $morosidadCritica = $copropiedad->unidades->filter(function($u) {
            return $u->morosidad && $u->morosidad->categoria_riesgo === 'critico';
        })->count();
        
        if ($morosidadCritica > 0) {
            $riskFactors += min(1, $morosidadCritica / 10);
        }

        // Factor 2: Fondo de reserva bajo mínimo
        if (!$copropiedad->fondoReserva || $copropiedad->fondoReserva->porcentaje_aporte_mensual < 5) {
            $riskFactors += 0.8;
        }

        // Factor 3: Contratos por vencer sin renovación
        $contratosPorVencer = $copropiedad->contratosAntenas->filter(function($c) {
            return $c->fecha_termino && 
                   Carbon::parse($c->fecha_termino)->diffInDays(now()) < 90 &&
                   $c->estado === 'vigente';
        })->count();
        
        if ($contratosPorVencer > 0) {
            $riskFactors += min(1, $contratosPorVencer * 0.3);
        }

        // Factor 4: Efectos negativos sistémicos
        $negativeSystemic = count(array_filter($effects['grouped']['systemic'] ?? [], 
            fn($e) => $e['direction'] === 'negative'));
        if ($negativeSystemic > 0) {
            $riskFactors += min(1, $negativeSystemic * 0.2);
        }

        // Factor 5: Concentración de ingresos
        $contratosVigentes = $copropiedad->contratosAntenas->where('estado', 'vigente');
        if ($contratosVigentes->count() === 1) {
            $riskFactors += 0.5; // Riesgo de concentración
        }

        return min(1.0, $riskFactors / $maxFactors);
    }

    private function calculateOpportunityScore(Copropiedad $copropiedad, array $effects): float
    {
        $opportunities = 0;
        $maxOpportunities = 5;

        // Oportunidad 1: Espacios disponibles para más antenas
        $espaciosDisponibles = $copropiedad->espaciosComunes()
            ->whereDoesntHave('contratosAntenas', fn($q) => $q->where('estado', 'vigente'))
            ->count();
        if ($espaciosDisponibles > 0) {
            $opportunities += min(1, $espaciosDisponibles * 0.3);
        }

        // Oportunidad 2: Fondo de reserva saludable para inversiones
        if ($copropiedad->fondoReserva && $copropiedad->fondoReserva->saldo_actual > 10000000) {
            $opportunities += 0.6;
        }

        // Oportunidad 3: Baja morosidad
        $morosidadTotal = $copropiedad->unidades->filter(fn($u) => 
            $u->morosidad && $u->morosidad->deuda_total > 0
        )->count();
        $tasaMorosidad = $morosidadTotal / max(1, $copropiedad->unidades->count());
        if ($tasaMorosidad < 0.1) {
            $opportunities += 0.7;
        }

        // Oportunidad 4: Efectos positivos de precesión detectados
        $positivePrecessional = count(array_filter($effects['grouped']['precession'] ?? [],
            fn($e) => $e['direction'] === 'positive'));
        if ($positivePrecessional > 0) {
            $opportunities += min(1, $positivePrecessional * 0.15);
        }

        // Oportunidad 5: Contratos renovables con buenos términos
        $contratosRenovables = $copropiedad->contratosAntenas->filter(function($c) {
            return $c->renovacion_automatica && $c->estado === 'vigente';
        })->count();
        if ($contratosRenovables > 0) {
            $opportunities += min(1, $contratosRenovables * 0.25);
        }

        return min(1.0, $opportunities / $maxOpportunities);
    }

    private function calculateConfidence(array $effects): float
    {
        $baseConfidence = 0.7;
        
        // Más efectos = mayor confianza (hasta un punto)
        $effectCount = count($effects['effects'] ?? []);
        $effectBonus = min(0.2, $effectCount * 0.01);
        
        // Profundidad alcanzada aumenta confianza
        $maxDepth = $effects['summary']['max_depth_reached'] ?? 0;
        $depthBonus = min(0.1, $maxDepth * 0.025);
        
        return min(1.0, $baseConfidence + $effectBonus + $depthBonus);
    }

    /**
     * Calcular valoración en UF
     */
    public function calculateValuation(int $copropiedadId, array $effects): array
    {
        $copropiedad = Copropiedad::with(['contratosAntenas', 'fondoReserva'])->findOrFail($copropiedadId);
        $valorUf = UfHistorico::getValor();

        // Valor directo: Ingresos anuales de contratos vigentes
        $ingresoAnualCLP = $copropiedad->contratosAntenas
            ->where('estado', 'vigente')
            ->sum(fn($c) => $c->canon_mensual_uf * 12 * $valorUf);
        
        $directValue = $ingresoAnualCLP / $valorUf;

        // Valor inducido: Proyección de renovaciones y mejoras
        $inducedValue = $directValue * 0.15; // 15% por efectos inducidos

        // Valor precesional: Efectos de segundo y tercer orden
        $precessionEffectWeight = array_sum(array_column($effects['grouped']['precession'] ?? [], 'weight'));
        $precessionValue = $directValue * min(0.3, $precessionEffectWeight);

        // Valor sistémico: Efectos de largo plazo
        $systemicValue = $directValue * 0.1;

        // Valor de contra-efectos (pueden ser negativos)
        $counterEffects = $effects['grouped']['counter'] ?? [];
        $counterWeight = array_sum(array_column($counterEffects, 'weight'));
        $counterValue = -($directValue * min(0.2, $counterWeight));

        $total = $directValue + $inducedValue + $precessionValue + $systemicValue + $counterValue;

        return [
            'total' => round($total, 2),
            'direct' => round($directValue, 2),
            'induced' => round($inducedValue, 2),
            'precession' => round($precessionValue, 2),
            'systemic' => round($systemicValue, 2),
            'counter' => round($counterValue, 2),
            'currency' => 'UF',
            'calculated_at' => now()->toIso8601String(),
        ];
    }
}

// =============================================================================
// PRECESSION ALERT ENGINE - Generación de Alertas
// =============================================================================
class PrecessionAlertEngine
{
    /**
     * Generar alertas basadas en análisis
     */
    public function generateAlerts(int $copropiedadId, string $analysisId, array $effects, array $scores): array
    {
        $alerts = [];
        $copropiedad = Copropiedad::with([
            'contratosAntenas',
            'fondoReserva',
            'unidades.morosidad',
        ])->findOrFail($copropiedadId);

        // Alerta por contratos por vencer
        $alerts = array_merge($alerts, $this->checkContratoVencimientos($copropiedad, $analysisId));

        // Alerta por morosidad crítica
        $alerts = array_merge($alerts, $this->checkMorosidadCritica($copropiedad, $analysisId));

        // Alerta por fondo de reserva bajo mínimo
        $alerts = array_merge($alerts, $this->checkFondoReserva($copropiedad, $analysisId));

        // Alerta por score de riesgo alto
        if ($scores['risk_score'] > 0.7) {
            $alerts[] = $this->createAlert($copropiedadId, $analysisId, [
                'type' => 'high_risk_score',
                'severity' => 'high',
                'title' => 'Score de riesgo elevado',
                'description' => "El score de riesgo ({$scores['risk_score']}) supera el umbral recomendado.",
                'probability' => 0.8,
                'impact_uf' => 0,
            ]);
        }

        // Alerta por oportunidades detectadas
        if ($scores['opportunity_score'] > 0.6) {
            $alerts[] = $this->createAlert($copropiedadId, $analysisId, [
                'type' => 'opportunity_detected',
                'severity' => 'info',
                'title' => 'Oportunidades de mejora detectadas',
                'description' => 'El análisis ha identificado oportunidades significativas de optimización.',
                'probability' => 0.7,
                'impact_uf' => 100,
            ]);
        }

        // Alertas por efectos precesionales significativos
        foreach ($effects['grouped']['precession'] ?? [] as $effect) {
            if ($effect['weight'] > 0.7) {
                $alerts[] = $this->createAlert($copropiedadId, $analysisId, [
                    'type' => 'precession_effect',
                    'severity' => $effect['direction'] === 'negative' ? 'warning' : 'info',
                    'title' => 'Efecto precesional significativo',
                    'description' => "Detectado efecto de {$effect['edge_type']} con peso {$effect['weight']}",
                    'probability' => 0.6,
                    'impact_uf' => $effect['value'] ?? 0,
                ]);
            }
        }

        return $alerts;
    }

    private function checkContratoVencimientos(Copropiedad $copropiedad, string $analysisId): array
    {
        $alerts = [];
        
        foreach ($copropiedad->contratosAntenas as $contrato) {
            if ($contrato->estado !== 'vigente' || !$contrato->fecha_termino) continue;
            
            $diasParaVencer = Carbon::parse($contrato->fecha_termino)->diffInDays(now(), false);
            
            if ($diasParaVencer > 0 && $diasParaVencer <= 90) {
                $severity = $diasParaVencer <= 30 ? 'critical' : ($diasParaVencer <= 60 ? 'high' : 'warning');
                $valorUf = UfHistorico::getValor();
                $impactoAnual = $contrato->canon_mensual_uf * 12;
                
                $alerts[] = $this->createAlert($copropiedad->id, $analysisId, [
                    'type' => 'contract_expiring',
                    'severity' => $severity,
                    'title' => "Contrato {$contrato->numero_contrato} por vencer",
                    'description' => "El contrato con {$contrato->empresa_operador} vence en {$diasParaVencer} días. Impacto potencial: {$impactoAnual} UF/año.",
                    'probability' => 0.95,
                    'impact_uf' => $impactoAnual,
                    'metadata' => ['contrato_id' => $contrato->id, 'dias_restantes' => $diasParaVencer],
                ]);
            }
        }
        
        return $alerts;
    }

    private function checkMorosidadCritica(Copropiedad $copropiedad, string $analysisId): array
    {
        $alerts = [];
        $valorUf = UfHistorico::getValor();
        
        $unidadesCriticas = $copropiedad->unidades->filter(function($u) {
            return $u->morosidad && $u->morosidad->categoria_riesgo === 'critico';
        });
        
        if ($unidadesCriticas->count() > 0) {
            $deudaTotal = $unidadesCriticas->sum(fn($u) => $u->morosidad->deuda_total);
            
            $alerts[] = $this->createAlert($copropiedad->id, $analysisId, [
                'type' => 'critical_delinquency',
                'severity' => 'critical',
                'title' => 'Morosidad crítica detectada',
                'description' => "{$unidadesCriticas->count()} unidades con morosidad crítica. Deuda total: $" . number_format($deudaTotal, 0, ',', '.'),
                'probability' => 0.9,
                'impact_uf' => round($deudaTotal / $valorUf, 2),
                'metadata' => ['unidades_count' => $unidadesCriticas->count()],
            ]);
        }
        
        return $alerts;
    }

    private function checkFondoReserva(Copropiedad $copropiedad, string $analysisId): array
    {
        $alerts = [];
        
        if (!$copropiedad->fondoReserva || $copropiedad->fondoReserva->porcentaje_aporte_mensual < 5) {
            $porcentajeActual = $copropiedad->fondoReserva?->porcentaje_aporte_mensual ?? 0;
            
            $alerts[] = $this->createAlert($copropiedad->id, $analysisId, [
                'type' => 'reserve_fund_below_minimum',
                'severity' => 'high',
                'title' => 'Fondo de reserva bajo mínimo legal',
                'description' => "El aporte al fondo de reserva ({$porcentajeActual}%) está bajo el mínimo legal de 5% (Ley 21.442).",
                'probability' => 1.0,
                'impact_uf' => 0,
            ]);
        }
        
        return $alerts;
    }

    private function createAlert(int $copropiedadId, string $analysisId, array $data): PrecessionAlert
    {
        return PrecessionAlert::create([
            'id' => \Str::uuid(),
            'tenant_id' => auth()->user()->tenant_id ?? 1,
            'copropiedad_id' => $copropiedadId,
            'precession_analysis_id' => $analysisId,
            'alert_type' => $data['type'],
            'severity' => $data['severity'],
            'title' => $data['title'],
            'description' => $data['description'],
            'probability' => $data['probability'] ?? 0.5,
            'potential_impact_uf' => $data['impact_uf'] ?? 0,
            'expected_months' => $data['expected_months'] ?? 3,
            'recommended_actions' => $this->suggestActions($data['type']),
            'status' => 'active',
            'metadata' => $data['metadata'] ?? [],
        ]);
    }

    private function suggestActions(string $alertType): array
    {
        return match($alertType) {
            'contract_expiring' => [
                'Iniciar negociación de renovación con el operador',
                'Evaluar ofertas de otros operadores',
                'Preparar asamblea para aprobación si se requieren nuevos términos',
            ],
            'critical_delinquency' => [
                'Contactar a deudores para establecer convenios de pago',
                'Evaluar inicio de acciones judiciales',
                'Revisar políticas de cobranza',
            ],
            'reserve_fund_below_minimum' => [
                'Ajustar el porcentaje de aporte mensual al 5% mínimo',
                'Aprobar en asamblea el ajuste del fondo de reserva',
                'Documentar cumplimiento normativo',
            ],
            'high_risk_score' => [
                'Revisar factores de riesgo identificados',
                'Implementar plan de mitigación',
                'Monitorear indicadores mensualmente',
            ],
            'opportunity_detected' => [
                'Evaluar implementación de mejoras identificadas',
                'Presentar propuestas al comité de administración',
                'Estimar ROI de las oportunidades',
            ],
            default => ['Revisar situación y tomar medidas correctivas'],
        };
    }
}

// =============================================================================
// PRECESSION SYNC SERVICE - Sincronización con ÁGORA
// =============================================================================
class PrecessionSyncService
{
    private string $agoraEndpoint;
    private string $agoraApiKey;

    public function __construct()
    {
        $this->agoraEndpoint = config('pae.agora_endpoint', 'http://localhost:8001/api');
        $this->agoraApiKey = config('pae.agora_api_key', '');
    }

    /**
     * Sincronizar análisis con ÁGORA
     */
    public function syncAnalysis(PrecessionAnalysis $analysis): bool
    {
        if (empty($this->agoraApiKey)) {
            Log::warning('ÁGORA API key not configured, skipping sync');
            return false;
        }

        try {
            $payload = [
                'analysis_id' => $analysis->id,
                'copropiedad_id' => $analysis->copropiedad_id,
                'tenant_id' => $analysis->tenant_id,
                'scores' => [
                    'precession' => $analysis->precession_score,
                    'risk' => $analysis->risk_score,
                    'opportunity' => $analysis->opportunity_score,
                    'confidence' => $analysis->confidence,
                ],
                'valuation' => [
                    'total_uf' => $analysis->total_precession_value_uf,
                    'direct_uf' => $analysis->direct_value_uf,
                    'precession_uf' => $analysis->precession_value_uf,
                ],
                'analyzed_at' => $analysis->created_at->toIso8601String(),
            ];

            // En producción, enviar a ÁGORA
            // $response = Http::withHeaders([
            //     'Authorization' => 'Bearer ' . $this->agoraApiKey,
            //     'Content-Type' => 'application/json',
            // ])->post($this->agoraEndpoint . '/precession/sync', $payload);

            Log::info('PAE Analysis synced to ÁGORA', ['analysis_id' => $analysis->id]);
            
            $analysis->update(['synced_to_agora' => true]);
            
            return true;

        } catch (\Exception $e) {
            Log::error('Failed to sync with ÁGORA', ['error' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * Sincronizar alertas con ÁGORA
     */
    public function syncAlerts(array $alerts): int
    {
        $synced = 0;
        
        foreach ($alerts as $alert) {
            if ($alert->synced_to_agora) continue;
            
            try {
                // Lógica de sincronización
                $alert->update(['synced_to_agora' => true]);
                $synced++;
            } catch (\Exception $e) {
                Log::error('Failed to sync alert', ['alert_id' => $alert->id, 'error' => $e->getMessage()]);
            }
        }
        
        return $synced;
    }

    /**
     * Obtener datos territoriales de ÁGORA
     */
    public function fetchTerritorialData(int $copropiedadId): ?array
    {
        $copropiedad = Copropiedad::find($copropiedadId);
        if (!$copropiedad || !$copropiedad->latitud || !$copropiedad->longitud) {
            return null;
        }

        // En producción, consultar ÁGORA
        // $response = Http::get($this->agoraEndpoint . '/territorial/context', [
        //     'lat' => $copropiedad->latitud,
        //     'lng' => $copropiedad->longitud,
        //     'radius_km' => 2,
        // ]);

        // Datos simulados para desarrollo
        return [
            'comuna' => $copropiedad->comuna,
            'region' => $copropiedad->region,
            'densidad_copropiedades' => rand(10, 50),
            'indice_desarrollo_urbano' => rand(60, 95) / 100,
            'copropiedades_cercanas' => rand(5, 20),
            'valor_promedio_m2_uf' => rand(30, 80),
        ];
    }
}
