<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - MIGRACIÓN MAESTRA COMPLETA
 * 23 Módulos - Todas las tablas para producción
 * =========================================================================
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // =================================================================
        // M01 - TENANTS (Multi-tenancy)
        // =================================================================
        Schema::create('tenants', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('rut', 20)->unique();
            $table->string('razon_social');
            $table->string('giro')->nullable();
            $table->string('direccion')->nullable();
            $table->string('comuna')->nullable();
            $table->string('region')->nullable();
            $table->string('telefono', 20)->nullable();
            $table->string('email')->nullable();
            $table->string('website')->nullable();
            $table->string('logo')->nullable();
            $table->enum('plan', ['starter', 'professional', 'enterprise'])->default('starter');
            $table->json('settings')->nullable();
            $table->json('features')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamp('trial_ends_at')->nullable();
            $table->timestamp('subscription_ends_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // =================================================================
        // M02 - USUARIOS Y AUTENTICACIÓN
        // =================================================================
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('rut', 20)->nullable()->index();
            $table->string('telefono', 20)->nullable();
            $table->string('cargo')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('avatar')->nullable();
            $table->enum('status', ['active', 'inactive', 'suspended'])->default('active');
            $table->json('preferences')->nullable();
            $table->timestamp('last_login_at')->nullable();
            $table->string('last_login_ip')->nullable();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('slug');
            $table->text('description')->nullable();
            $table->boolean('is_system')->default(false);
            $table->json('permissions')->nullable();
            $table->timestamps();
            $table->unique(['tenant_id', 'slug']);
        });

        Schema::create('role_user', function (Blueprint $table) {
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('role_id')->constrained()->cascadeOnDelete();
            $table->primary(['user_id', 'role_id']);
        });

        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('module');
            $table->text('description')->nullable();
            $table->timestamps();
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('personal_access_tokens', function (Blueprint $table) {
            $table->id();
            $table->morphs('tokenable');
            $table->string('name');
            $table->string('token', 64)->unique();
            $table->text('abilities')->nullable();
            $table->timestamp('last_used_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
        });

        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('action');
            $table->string('model_type');
            $table->unsignedBigInteger('model_id')->nullable();
            $table->json('old_values')->nullable();
            $table->json('new_values')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->timestamps();
            $table->index(['tenant_id', 'model_type', 'model_id']);
        });

        // =================================================================
        // M03 - COPROPIEDADES (CORE)
        // =================================================================
        Schema::create('copropiedades', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->string('nombre');
            $table->string('nombre_fantasia')->nullable();
            $table->string('rut', 20)->index();
            $table->string('direccion');
            $table->string('numero')->nullable();
            $table->string('comuna');
            $table->string('region');
            $table->string('codigo_postal', 10)->nullable();
            $table->decimal('latitud', 10, 8)->nullable();
            $table->decimal('longitud', 11, 8)->nullable();
            $table->enum('tipo', ['edificio', 'condominio', 'mixto'])->default('edificio');
            $table->enum('categoria', ['residencial', 'comercial', 'industrial', 'mixto'])->default('residencial');
            $table->year('ano_construccion')->nullable();
            $table->integer('pisos')->nullable();
            $table->integer('subterraneos')->nullable();
            $table->decimal('superficie_terreno', 12, 2)->nullable();
            $table->decimal('superficie_construida', 12, 2)->nullable();
            $table->string('rol_sii', 30)->nullable()->index();
            $table->string('numero_resolucion_dom')->nullable();
            $table->date('fecha_recepcion_final')->nullable();
            $table->string('administrador_nombre')->nullable();
            $table->string('administrador_email')->nullable();
            $table->string('administrador_telefono', 20)->nullable();
            $table->string('representante_legal')->nullable();
            $table->string('representante_rut', 20)->nullable();
            // Datos tributarios
            $table->boolean('tiene_inicio_actividades')->default(false);
            $table->date('fecha_inicio_actividades')->nullable();
            $table->string('giro_tributario')->nullable();
            $table->enum('regimen_tributario', ['primera_categoria', 'renta_presunta', 'exento'])->nullable();
            $table->json('configuracion')->nullable();
            $table->boolean('activa')->default(true);
            $table->timestamps();
            $table->softDeletes();
            $table->index(['tenant_id', 'comuna']);
        });

        Schema::create('unidades', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('numero');
            $table->string('piso')->nullable();
            $table->enum('tipo', ['departamento', 'casa', 'local', 'oficina', 'bodega', 'estacionamiento', 'otro'])->default('departamento');
            $table->decimal('superficie_util', 10, 2)->nullable();
            $table->decimal('superficie_terraza', 10, 2)->nullable();
            $table->decimal('superficie_total', 10, 2)->nullable();
            $table->integer('dormitorios')->nullable();
            $table->integer('banos')->nullable();
            $table->decimal('alicuota_prorrateo', 8, 6);
            $table->decimal('alicuota_gastos', 8, 6)->nullable();
            $table->string('rol_sii', 30)->nullable();
            $table->decimal('avaluo_fiscal', 14, 2)->nullable();
            $table->enum('estado_ocupacion', ['propietario', 'arrendada', 'vacante', 'uso_comun'])->default('propietario');
            $table->boolean('activa')->default(true);
            $table->json('caracteristicas')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['copropiedad_id', 'numero']);
        });

        Schema::create('copropietarios', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained()->cascadeOnDelete();
            $table->enum('tipo_persona', ['natural', 'juridica'])->default('natural');
            $table->string('rut', 20)->index();
            $table->string('nombre');
            $table->string('apellido_paterno')->nullable();
            $table->string('apellido_materno')->nullable();
            $table->string('razon_social')->nullable();
            $table->string('email')->nullable();
            $table->string('telefono', 20)->nullable();
            $table->string('direccion_correspondencia')->nullable();
            $table->enum('rol', ['propietario', 'arrendatario', 'representante', 'residente'])->default('propietario');
            $table->decimal('porcentaje_propiedad', 5, 2)->default(100);
            $table->date('fecha_adquisicion')->nullable();
            $table->string('escritura_numero')->nullable();
            $table->string('notaria')->nullable();
            $table->boolean('es_principal')->default(true);
            $table->boolean('activo')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('espacios_comunes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('nombre');
            $table->enum('tipo', ['salon', 'piscina', 'quincho', 'gimnasio', 'terraza', 'jardin', 'estacionamiento_visita', 'bodega_comun', 'azotea', 'otro']);
            $table->decimal('superficie', 10, 2)->nullable();
            $table->integer('capacidad_personas')->nullable();
            $table->boolean('reservable')->default(false);
            $table->decimal('costo_arriendo', 10, 2)->nullable();
            $table->text('descripcion')->nullable();
            $table->json('horarios')->nullable();
            $table->json('reglas')->nullable();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        // =================================================================
        // M04 - ANTENAS Y TELECOMUNICACIONES (Ley 21.442 + IVA)
        // =================================================================
        Schema::create('contratos_antenas', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('espacio_comun_id')->nullable()->constrained('espacios_comunes')->nullOnDelete();
            $table->string('numero_contrato')->unique();
            $table->string('empresa_operador');
            $table->string('rut_operador', 20);
            $table->string('representante_operador')->nullable();
            $table->string('email_operador')->nullable();
            $table->string('telefono_operador')->nullable();
            $table->enum('tipo_instalacion', ['antena_celular', 'antena_radio', 'fibra_optica', 'repetidor', 'small_cell', 'satelital', 'otro'])->default('antena_celular');
            $table->string('ubicacion_instalacion');
            $table->decimal('superficie_ocupada_m2', 8, 2)->nullable();
            $table->decimal('potencia_watts', 10, 2)->nullable();
            $table->date('fecha_inicio');
            $table->date('fecha_termino')->nullable();
            $table->integer('duracion_meses')->nullable();
            $table->boolean('renovacion_automatica')->default(true);
            $table->integer('preaviso_dias')->default(90);
            // Acuerdo asamblea (Ley 21.442)
            $table->date('fecha_asamblea_aprobacion')->nullable();
            $table->string('acta_asamblea_numero')->nullable();
            $table->decimal('quorum_aprobacion', 5, 2)->nullable();
            // Valores del contrato
            $table->decimal('canon_mensual_uf', 12, 4);
            $table->decimal('canon_mensual_clp', 14, 2)->nullable();
            $table->enum('moneda', ['UF', 'CLP', 'USD'])->default('UF');
            $table->enum('periodicidad_pago', ['mensual', 'trimestral', 'semestral', 'anual'])->default('mensual');
            $table->integer('dia_pago')->default(5);
            $table->decimal('reajuste_anual_porcentaje', 5, 2)->nullable();
            $table->enum('tipo_reajuste', ['ipc', 'uf', 'fijo', 'ninguno'])->default('uf');
            // TRIBUTACIÓN IVA (Ley de Rentas Copropiedades)
            $table->boolean('afecto_iva')->default(true);
            $table->decimal('tasa_iva', 5, 2)->default(19.00);
            $table->enum('regimen_tributario', ['renta_presunta', 'renta_efectiva', 'exento'])->default('renta_efectiva');
            $table->boolean('retencion_iva')->default(false);
            $table->decimal('porcentaje_retencion', 5, 2)->nullable();
            // Distribución ingresos (Art. 14 Ley 21.442)
            $table->enum('distribucion_tipo', ['fondo_comun', 'propietarios', 'fondo_reserva', 'mixto'])->default('fondo_comun');
            $table->decimal('porcentaje_fondo_comun', 5, 2)->default(100);
            $table->decimal('porcentaje_propietarios', 5, 2)->default(0);
            $table->decimal('porcentaje_fondo_reserva', 5, 2)->default(0);
            // Garantías y seguros
            $table->decimal('garantia_monto_uf', 10, 4)->nullable();
            $table->string('garantia_tipo')->nullable();
            $table->date('garantia_vencimiento')->nullable();
            $table->boolean('seguro_responsabilidad')->default(false);
            $table->string('poliza_seguro')->nullable();
            $table->decimal('cobertura_seguro', 14, 2)->nullable();
            $table->enum('estado', ['vigente', 'por_vencer', 'vencido', 'terminado', 'en_negociacion'])->default('vigente');
            $table->text('observaciones')->nullable();
            $table->json('documentos')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['tenant_id', 'copropiedad_id', 'estado']);
        });

        Schema::create('facturas_antenas', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('contrato_antena_id')->constrained('contratos_antenas')->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('numero_factura')->nullable();
            $table->string('folio_sii')->nullable()->index();
            $table->date('fecha_emision');
            $table->date('fecha_vencimiento');
            $table->string('periodo', 7); // YYYY-MM
            // Montos
            $table->decimal('monto_neto_uf', 12, 4);
            $table->decimal('monto_neto_clp', 14, 2);
            $table->decimal('monto_iva', 14, 2);
            $table->decimal('monto_total_clp', 14, 2);
            $table->decimal('valor_uf_dia', 10, 4);
            // IVA y retenciones
            $table->boolean('iva_incluido')->default(true);
            $table->decimal('tasa_iva_aplicada', 5, 2)->default(19.00);
            $table->decimal('monto_retencion', 14, 2)->default(0);
            $table->boolean('iva_retenido')->default(false);
            // Estado SII
            $table->enum('estado', ['borrador', 'emitida', 'enviada_sii', 'aceptada_sii', 'rechazada_sii', 'pagada', 'anulada'])->default('borrador');
            $table->date('fecha_pago')->nullable();
            $table->string('medio_pago')->nullable();
            $table->string('comprobante_pago')->nullable();
            // Track SII
            $table->string('track_id_sii')->nullable();
            $table->timestamp('fecha_envio_sii')->nullable();
            $table->json('respuesta_sii')->nullable();
            $table->text('observaciones')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['tenant_id', 'periodo']);
        });

        Schema::create('distribucion_ingresos_antenas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('factura_antena_id')->constrained('facturas_antenas')->cascadeOnDelete();
            $table->foreignId('unidad_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('copropietario_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('tipo_destino', ['fondo_comun', 'propietario', 'fondo_reserva']);
            $table->decimal('porcentaje', 8, 6);
            $table->decimal('monto_bruto_clp', 14, 2);
            $table->decimal('monto_neto_clp', 14, 2);
            $table->decimal('monto_uf', 12, 4);
            $table->boolean('pagado')->default(false);
            $table->date('fecha_pago')->nullable();
            $table->string('comprobante')->nullable();
            $table->timestamps();
        });

        // =================================================================
        // M05 - GASTOS COMUNES
        // =================================================================
        Schema::create('periodos_gasto', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('periodo', 7); // YYYY-MM
            $table->date('fecha_inicio');
            $table->date('fecha_cierre');
            $table->date('fecha_vencimiento');
            $table->enum('estado', ['abierto', 'cerrado', 'facturado', 'cobrado'])->default('abierto');
            $table->decimal('total_gastos_ordinarios', 14, 2)->default(0);
            $table->decimal('total_gastos_extraordinarios', 14, 2)->default(0);
            $table->decimal('total_ingresos', 14, 2)->default(0);
            $table->decimal('fondo_reserva_aporte', 14, 2)->default(0);
            $table->decimal('saldo_periodo_anterior', 14, 2)->default(0);
            $table->timestamps();
            $table->unique(['copropiedad_id', 'periodo']);
        });

        Schema::create('categorias_gasto', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->string('codigo', 10);
            $table->string('nombre');
            $table->enum('tipo', ['ordinario', 'extraordinario', 'fondo_reserva', 'ingreso']);
            $table->boolean('prorrateable')->default(true);
            $table->enum('metodo_prorrateo', ['alicuota', 'partes_iguales', 'superficie', 'consumo', 'manual'])->default('alicuota');
            $table->string('cuenta_contable', 20)->nullable();
            $table->boolean('afecto_iva')->default(false);
            $table->boolean('activo')->default(true);
            $table->integer('orden')->default(0);
            $table->timestamps();
            $table->unique(['tenant_id', 'codigo']);
        });

        Schema::create('gastos_comunes', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('periodo_id')->constrained('periodos_gasto')->cascadeOnDelete();
            $table->foreignId('categoria_id')->constrained('categorias_gasto');
            $table->foreignId('proveedor_id')->nullable()->constrained('proveedores')->nullOnDelete();
            $table->string('descripcion');
            $table->date('fecha');
            $table->string('numero_documento')->nullable();
            $table->decimal('monto_neto', 14, 2);
            $table->decimal('monto_iva', 14, 2)->default(0);
            $table->decimal('monto_total', 14, 2);
            $table->boolean('afecto_iva')->default(false);
            $table->enum('estado', ['pendiente', 'aprobado', 'pagado', 'anulado'])->default('pendiente');
            $table->date('fecha_pago')->nullable();
            $table->string('comprobante_pago')->nullable();
            $table->text('observaciones')->nullable();
            $table->json('archivos')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['tenant_id', 'copropiedad_id', 'periodo_id']);
        });

        Schema::create('cobros_unidad', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('periodo_id')->constrained('periodos_gasto')->cascadeOnDelete();
            $table->decimal('gasto_ordinario', 14, 2)->default(0);
            $table->decimal('gasto_extraordinario', 14, 2)->default(0);
            $table->decimal('fondo_reserva', 14, 2)->default(0);
            $table->decimal('multas', 14, 2)->default(0);
            $table->decimal('intereses_mora', 14, 2)->default(0);
            $table->decimal('ajustes', 14, 2)->default(0);
            $table->decimal('total_cobrar', 14, 2);
            $table->decimal('total_pagado', 14, 2)->default(0);
            $table->decimal('saldo_pendiente', 14, 2);
            $table->date('fecha_vencimiento');
            $table->enum('estado', ['pendiente', 'parcial', 'pagado', 'mora', 'incobrable'])->default('pendiente');
            $table->integer('dias_mora')->default(0);
            $table->timestamps();
            $table->unique(['unidad_id', 'periodo_id']);
        });

        Schema::create('pagos', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('cobro_unidad_id')->constrained('cobros_unidad')->cascadeOnDelete();
            $table->date('fecha_pago');
            $table->decimal('monto', 14, 2);
            $table->enum('medio_pago', ['efectivo', 'transferencia', 'cheque', 'tarjeta', 'pago_automatico', 'otro'])->default('transferencia');
            $table->string('numero_operacion')->nullable();
            $table->string('banco')->nullable();
            $table->string('comprobante')->nullable();
            $table->text('observaciones')->nullable();
            $table->foreignId('registrado_por')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        // =================================================================
        // M06 - MOROSIDAD Y COBRANZA
        // =================================================================
        Schema::create('morosidad', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->decimal('deuda_total', 14, 2);
            $table->decimal('deuda_ordinaria', 14, 2)->default(0);
            $table->decimal('deuda_extraordinaria', 14, 2)->default(0);
            $table->decimal('intereses_acumulados', 14, 2)->default(0);
            $table->decimal('multas_acumuladas', 14, 2)->default(0);
            $table->integer('meses_mora')->default(0);
            $table->date('fecha_inicio_mora')->nullable();
            $table->string('periodo_mas_antiguo', 7)->nullable();
            $table->enum('categoria_riesgo', ['bajo', 'medio', 'alto', 'critico'])->default('bajo');
            $table->enum('estado_gestion', ['sin_gestion', 'en_gestion', 'convenio', 'judicial', 'incobrable'])->default('sin_gestion');
            $table->date('ultima_gestion')->nullable();
            $table->date('proximo_contacto')->nullable();
            $table->text('observaciones')->nullable();
            $table->timestamps();
            $table->unique(['unidad_id']);
        });

        Schema::create('gestiones_cobranza', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('morosidad_id')->constrained('morosidad')->cascadeOnDelete();
            $table->foreignId('usuario_id')->constrained('users');
            $table->date('fecha');
            $table->enum('tipo', ['llamada', 'email', 'carta', 'visita', 'whatsapp', 'carta_certificada', 'notificacion_judicial', 'otro']);
            $table->text('descripcion');
            $table->enum('resultado', ['contactado', 'no_contactado', 'compromiso_pago', 'rechazo', 'sin_respuesta']);
            $table->date('fecha_compromiso')->nullable();
            $table->decimal('monto_compromiso', 14, 2)->nullable();
            $table->json('archivos')->nullable();
            $table->timestamps();
        });

        Schema::create('convenios_pago', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('morosidad_id')->constrained('morosidad')->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained();
            $table->string('numero_convenio')->unique();
            $table->date('fecha_convenio');
            $table->decimal('deuda_total', 14, 2);
            $table->decimal('pie_inicial', 14, 2)->default(0);
            $table->integer('numero_cuotas');
            $table->decimal('monto_cuota', 14, 2);
            $table->decimal('tasa_interes_mensual', 5, 4)->default(0);
            $table->date('fecha_primera_cuota');
            $table->enum('estado', ['vigente', 'cumplido', 'incumplido', 'anulado'])->default('vigente');
            $table->integer('cuotas_pagadas')->default(0);
            $table->text('condiciones')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // =================================================================
        // M07 - PROVEEDORES Y CONTRATOS
        // =================================================================
        Schema::create('proveedores', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->string('rut', 20)->index();
            $table->string('razon_social');
            $table->string('nombre_fantasia')->nullable();
            $table->string('giro')->nullable();
            $table->string('direccion')->nullable();
            $table->string('comuna')->nullable();
            $table->string('region')->nullable();
            $table->string('telefono', 20)->nullable();
            $table->string('email')->nullable();
            $table->string('contacto_nombre')->nullable();
            $table->string('contacto_cargo')->nullable();
            $table->string('contacto_telefono')->nullable();
            $table->string('contacto_email')->nullable();
            $table->string('banco')->nullable();
            $table->string('tipo_cuenta')->nullable();
            $table->string('numero_cuenta')->nullable();
            $table->enum('categoria', ['mantención', 'servicios', 'suministros', 'profesionales', 'seguridad', 'aseo', 'otro'])->default('servicios');
            $table->boolean('activo')->default(true);
            $table->decimal('calificacion', 3, 2)->nullable();
            $table->json('documentos')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('contratos_servicio', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('proveedor_id')->constrained('proveedores');
            $table->string('numero_contrato');
            $table->string('descripcion');
            $table->enum('tipo', ['mantención', 'servicio_fijo', 'servicio_variable', 'obra', 'profesional', 'otro']);
            $table->date('fecha_inicio');
            $table->date('fecha_termino')->nullable();
            $table->boolean('renovacion_automatica')->default(false);
            $table->decimal('monto_mensual', 14, 2)->nullable();
            $table->decimal('monto_total', 14, 2)->nullable();
            $table->enum('moneda', ['CLP', 'UF', 'USD'])->default('CLP');
            $table->boolean('afecto_iva')->default(true);
            $table->enum('estado', ['vigente', 'por_vencer', 'vencido', 'terminado'])->default('vigente');
            $table->text('condiciones')->nullable();
            $table->json('documentos')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // =================================================================
        // M08 - CONTABILIDAD POR COPROPIEDAD
        // =================================================================
        Schema::create('planes_cuenta', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('codigo', 20);
            $table->string('nombre');
            $table->enum('tipo', ['activo', 'pasivo', 'patrimonio', 'ingreso', 'gasto', 'orden']);
            $table->enum('naturaleza', ['deudora', 'acreedora']);
            $table->integer('nivel')->default(1);
            $table->string('cuenta_padre', 20)->nullable();
            $table->boolean('es_cuenta_movimiento')->default(true);
            $table->boolean('requiere_centro_costo')->default(false);
            $table->boolean('activa')->default(true);
            $table->text('descripcion')->nullable();
            $table->timestamps();
            $table->unique(['tenant_id', 'copropiedad_id', 'codigo']);
        });

        Schema::create('periodos_contables', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->integer('ano');
            $table->integer('mes');
            $table->date('fecha_inicio');
            $table->date('fecha_cierre');
            $table->enum('estado', ['abierto', 'cerrado', 'ajuste'])->default('abierto');
            $table->foreignId('cerrado_por')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('fecha_cierre_real')->nullable();
            $table->timestamps();
            $table->unique(['copropiedad_id', 'ano', 'mes']);
        });

        Schema::create('libros_contables', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->enum('tipo', ['diario', 'mayor', 'balance', 'resultado', 'inventario', 'fondo_reserva', 'ingresos_adicionales', 'gastos_comunes']);
            $table->integer('ano');
            $table->integer('mes')->nullable();
            $table->integer('folio_desde')->default(1);
            $table->integer('folio_hasta')->nullable();
            $table->enum('estado', ['abierto', 'cerrado', 'timbrado'])->default('abierto');
            $table->string('archivo_respaldo')->nullable();
            $table->timestamp('fecha_generacion')->nullable();
            $table->timestamps();
        });

        Schema::create('asientos_contables', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('periodo_contable_id')->constrained('periodos_contables');
            $table->foreignId('libro_id')->nullable()->constrained('libros_contables')->nullOnDelete();
            $table->integer('numero_asiento');
            $table->date('fecha');
            $table->enum('tipo', ['ingreso', 'egreso', 'traspaso', 'ajuste', 'apertura', 'cierre']);
            $table->string('glosa');
            $table->string('referencia')->nullable();
            // Vinculación con documentos origen
            $table->string('documento_tipo')->nullable(); // factura_antena, gasto_comun, pago, etc.
            $table->unsignedBigInteger('documento_id')->nullable();
            $table->decimal('total_debe', 14, 2);
            $table->decimal('total_haber', 14, 2);
            $table->enum('estado', ['borrador', 'contabilizado', 'reversado', 'anulado'])->default('borrador');
            $table->foreignId('creado_por')->constrained('users');
            $table->foreignId('aprobado_por')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('fecha_aprobacion')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['copropiedad_id', 'periodo_contable_id', 'numero_asiento']);
        });

        Schema::create('movimientos_contables', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('asiento_id')->constrained('asientos_contables')->cascadeOnDelete();
            $table->foreignId('cuenta_id')->constrained('planes_cuenta');
            $table->enum('tipo_movimiento', ['debe', 'haber']);
            $table->decimal('monto', 14, 2);
            $table->string('glosa_linea')->nullable();
            // Vinculación auxiliar
            $table->foreignId('unidad_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('copropietario_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('proveedor_id')->nullable()->constrained('proveedores')->nullOnDelete();
            $table->foreignId('contrato_antena_id')->nullable()->constrained('contratos_antenas')->nullOnDelete();
            $table->timestamps();
            $table->index(['asiento_id', 'cuenta_id']);
        });

        Schema::create('saldos_cuenta', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('cuenta_id')->constrained('planes_cuenta');
            $table->foreignId('periodo_contable_id')->constrained('periodos_contables');
            $table->decimal('saldo_inicial', 14, 2)->default(0);
            $table->decimal('debitos', 14, 2)->default(0);
            $table->decimal('creditos', 14, 2)->default(0);
            $table->decimal('saldo_final', 14, 2)->default(0);
            $table->timestamps();
            $table->unique(['cuenta_id', 'periodo_contable_id']);
        });

        // =================================================================
        // M09 - CERTIFICADOS TRIBUTARIOS
        // =================================================================
        Schema::create('certificados_tributarios', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropietario_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('unidad_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('tipo', [
                'cumplimiento_comunidad',
                'cumplimiento_copropietario',
                'ingresos_adicionales',
                'participacion_rentas',
                'gastos_comunes',
                'deuda_pendiente',
                'no_deuda'
            ]);
            $table->integer('ano_tributario');
            $table->string('folio')->unique();
            $table->date('fecha_emision');
            $table->date('fecha_vigencia');
            // Datos del certificado
            $table->decimal('monto_ingresos', 14, 2)->nullable();
            $table->decimal('monto_gastos', 14, 2)->nullable();
            $table->decimal('monto_participacion', 14, 2)->nullable();
            $table->decimal('porcentaje_participacion', 8, 6)->nullable();
            $table->decimal('monto_deuda', 14, 2)->nullable();
            $table->json('detalle')->nullable();
            // Emisión y validación
            $table->enum('estado', ['emitido', 'anulado', 'vencido'])->default('emitido');
            $table->string('codigo_verificacion', 32)->unique();
            $table->string('archivo_pdf')->nullable();
            $table->foreignId('emitido_por')->constrained('users');
            $table->text('observaciones')->nullable();
            $table->timestamps();
            $table->index(['tenant_id', 'copropiedad_id', 'ano_tributario']);
        });

        // =================================================================
        // M10 - DECLARACIONES JURADAS E INTEGRACIÓN SII
        // =================================================================
        Schema::create('declaraciones_juradas', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('tipo_dj', 10); // DJ1887, DJ1835, etc.
            $table->integer('ano_tributario');
            $table->string('periodo', 7)->nullable(); // YYYY-MM para mensuales
            $table->date('fecha_presentacion')->nullable();
            $table->string('folio_sii')->nullable();
            $table->enum('estado', ['borrador', 'generada', 'enviada', 'aceptada', 'rechazada', 'rectificada'])->default('borrador');
            $table->json('datos')->nullable();
            $table->json('respuesta_sii')->nullable();
            $table->string('archivo_txt')->nullable();
            $table->string('archivo_pdf')->nullable();
            $table->foreignId('generada_por')->constrained('users');
            $table->timestamp('fecha_envio')->nullable();
            $table->text('observaciones')->nullable();
            $table->timestamps();
            $table->unique(['copropiedad_id', 'tipo_dj', 'ano_tributario', 'periodo']);
        });

        Schema::create('integracion_sii_config', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('rut_empresa', 20);
            $table->string('razon_social');
            $table->string('giro');
            $table->string('direccion');
            $table->string('comuna');
            $table->string('ciudad');
            $table->string('codigo_actividad_sii')->nullable();
            $table->date('fecha_resolucion_sii')->nullable();
            $table->string('numero_resolucion_sii')->nullable();
            // Certificados digitales
            $table->text('certificado_digital')->nullable();
            $table->string('certificado_password')->nullable();
            $table->date('certificado_vigencia')->nullable();
            // Ambiente
            $table->enum('ambiente', ['certificacion', 'produccion'])->default('certificacion');
            $table->boolean('activo')->default(true);
            $table->timestamps();
            $table->unique(['copropiedad_id']);
        });

        // =================================================================
        // M11 - FONDO DE RESERVA (Ley 21.442)
        // =================================================================
        Schema::create('fondos_reserva', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->decimal('saldo_actual', 14, 2)->default(0);
            $table->decimal('porcentaje_aporte_mensual', 5, 2)->default(5); // Mínimo 5% Ley 21.442
            $table->decimal('meta_fondo', 14, 2)->nullable();
            $table->date('ultima_actualizacion');
            $table->json('politica_uso')->nullable();
            $table->timestamps();
            $table->unique(['copropiedad_id']);
        });

        Schema::create('movimientos_fondo_reserva', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('fondo_id')->constrained('fondos_reserva')->cascadeOnDelete();
            $table->date('fecha');
            $table->enum('tipo', ['aporte_mensual', 'aporte_extraordinario', 'ingreso_antena', 'uso_autorizado', 'interes', 'ajuste']);
            $table->decimal('monto', 14, 2);
            $table->decimal('saldo_posterior', 14, 2);
            $table->string('descripcion');
            $table->string('periodo', 7)->nullable();
            $table->string('acta_asamblea')->nullable(); // Para usos autorizados
            $table->foreignId('asiento_id')->nullable()->constrained('asientos_contables')->nullOnDelete();
            $table->timestamps();
        });

        // =================================================================
        // M12 - ASAMBLEAS Y ACTAS (Ley 21.442)
        // =================================================================
        Schema::create('asambleas', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->enum('tipo', ['ordinaria', 'extraordinaria']);
            $table->integer('numero');
            $table->date('fecha');
            $table->time('hora_primera_citacion');
            $table->time('hora_segunda_citacion')->nullable();
            $table->string('lugar');
            $table->enum('modalidad', ['presencial', 'virtual', 'mixta'])->default('presencial');
            $table->text('orden_del_dia');
            $table->decimal('quorum_requerido', 5, 2);
            $table->decimal('quorum_asistencia', 5, 2)->nullable();
            $table->integer('unidades_presentes')->nullable();
            $table->integer('unidades_representadas')->nullable();
            $table->enum('estado', ['convocada', 'en_curso', 'realizada', 'suspendida', 'anulada'])->default('convocada');
            $table->timestamps();
        });

        Schema::create('actas_asamblea', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('asamblea_id')->constrained('asambleas')->cascadeOnDelete();
            $table->string('numero_acta');
            $table->datetime('fecha_hora_inicio');
            $table->datetime('fecha_hora_termino')->nullable();
            $table->text('desarrollo');
            $table->json('acuerdos')->nullable();
            $table->json('votaciones')->nullable();
            $table->string('presidente_asamblea')->nullable();
            $table->string('secretario_acta')->nullable();
            $table->enum('estado', ['borrador', 'aprobada', 'firmada', 'registrada'])->default('borrador');
            $table->string('archivo_pdf')->nullable();
            $table->string('archivo_firmado')->nullable();
            $table->timestamps();
        });

        // =================================================================
        // M13 - COMPLIANCE Y NORMATIVA
        // =================================================================
        Schema::create('compliance_evaluaciones', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->date('fecha_evaluacion');
            $table->string('periodo_evaluado', 7);
            $table->decimal('score_global', 5, 2);
            $table->decimal('score_ley21442', 5, 2)->nullable();
            $table->decimal('score_ds7_2025', 5, 2)->nullable();
            $table->decimal('score_tributario', 5, 2)->nullable();
            $table->decimal('score_contable', 5, 2)->nullable();
            $table->decimal('score_transparencia', 5, 2)->nullable();
            $table->json('brechas')->nullable();
            $table->json('recomendaciones')->nullable();
            $table->json('plan_accion')->nullable();
            $table->enum('estado', ['borrador', 'publicado', 'cerrado'])->default('borrador');
            $table->foreignId('evaluador_id')->constrained('users');
            $table->timestamps();
        });

        Schema::create('requisitos_normativos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->string('codigo', 20);
            $table->string('nombre');
            $table->enum('normativa', ['ley_21442', 'ds7_2025', 'sii', 'otro']);
            $table->text('descripcion');
            $table->enum('obligatoriedad', ['obligatorio', 'recomendado', 'opcional']);
            $table->string('frecuencia_verificacion')->nullable();
            $table->json('criterios_cumplimiento')->nullable();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        // =================================================================
        // M14 - VALORIZACIÓN Y AVALÚOS
        // =================================================================
        Schema::create('avaluos', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('unidad_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('tipo', ['fiscal', 'comercial', 'bancario', 'seguro']);
            $table->date('fecha_avaluo');
            $table->date('fecha_vigencia');
            $table->decimal('valor_terreno', 14, 2)->nullable();
            $table->decimal('valor_construccion', 14, 2)->nullable();
            $table->decimal('valor_total', 14, 2);
            $table->decimal('valor_uf', 12, 4);
            $table->decimal('valor_m2', 10, 2)->nullable();
            $table->string('fuente');
            $table->string('tasador')->nullable();
            $table->text('observaciones')->nullable();
            $table->json('datos_adicionales')->nullable();
            $table->timestamps();
        });

        // =================================================================
        // M15 - PAE PRECESSION ANALYTICS (ya desarrollado - tablas)
        // =================================================================
        Schema::create('precession_analyses', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('analysis_type')->default('full');
            $table->enum('status', ['pending', 'processing', 'completed', 'failed'])->default('pending');
            $table->decimal('precession_score', 5, 2)->nullable();
            $table->decimal('risk_score', 5, 4)->nullable();
            $table->decimal('opportunity_score', 5, 4)->nullable();
            $table->decimal('confidence', 5, 4)->nullable();
            $table->decimal('total_precession_value_uf', 14, 4)->nullable();
            $table->decimal('direct_value_uf', 14, 4)->nullable();
            $table->decimal('induced_value_uf', 14, 4)->nullable();
            $table->decimal('precession_value_uf', 14, 4)->nullable();
            $table->decimal('systemic_value_uf', 14, 4)->nullable();
            $table->decimal('counter_value_uf', 14, 4)->nullable();
            $table->json('effects_summary')->nullable();
            $table->integer('effects_count')->default(0);
            $table->json('ml_predictions')->nullable();
            $table->json('parameters')->nullable();
            $table->decimal('execution_time_ms', 10, 2)->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
            $table->index(['tenant_id', 'copropiedad_id', 'status']);
        });

        Schema::create('precession_alerts', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->nullable()->constrained()->nullOnDelete();
            $table->uuid('analysis_id')->nullable();
            $table->string('alert_type');
            $table->enum('severity', ['critical', 'high', 'warning', 'info']);
            $table->string('precession_angle')->nullable();
            $table->enum('status', ['active', 'acknowledged', 'resolved', 'expired'])->default('active');
            $table->string('title');
            $table->text('description');
            $table->text('recommendation')->nullable();
            $table->decimal('probability', 5, 4)->nullable();
            $table->decimal('potential_impact_uf', 14, 2)->nullable();
            $table->integer('expected_months')->nullable();
            $table->json('data')->nullable();
            $table->timestamp('acknowledged_at')->nullable();
            $table->foreignId('acknowledged_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('resolved_at')->nullable();
            $table->foreignId('resolved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->text('resolution_notes')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->boolean('synced_to_agora')->default(false);
            $table->timestamp('synced_at')->nullable();
            $table->timestamps();
            $table->index(['tenant_id', 'severity', 'status']);
        });

        // =================================================================
        // M16 - ARRIENDOS Y CONTRATOS UNIDADES
        // =================================================================
        Schema::create('contratos_arriendo', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('unidad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('arrendador_id')->constrained('copropietarios');
            $table->string('arrendatario_rut', 20);
            $table->string('arrendatario_nombre');
            $table->string('arrendatario_email')->nullable();
            $table->string('arrendatario_telefono')->nullable();
            $table->date('fecha_inicio');
            $table->date('fecha_termino');
            $table->boolean('renovacion_automatica')->default(false);
            $table->decimal('canon_mensual', 14, 2);
            $table->enum('moneda', ['CLP', 'UF'])->default('CLP');
            $table->integer('dia_pago')->default(5);
            $table->decimal('garantia', 14, 2)->nullable();
            $table->integer('meses_garantia')->nullable();
            $table->enum('estado', ['vigente', 'por_vencer', 'vencido', 'terminado'])->default('vigente');
            $table->text('observaciones')->nullable();
            $table->json('documentos')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // =================================================================
        // M17 - MANTENCIONES Y TRABAJOS
        // =================================================================
        Schema::create('ordenes_trabajo', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->foreignId('espacio_comun_id')->nullable()->constrained('espacios_comunes')->nullOnDelete();
            $table->foreignId('unidad_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('proveedor_id')->nullable()->constrained('proveedores')->nullOnDelete();
            $table->string('numero');
            $table->string('titulo');
            $table->text('descripcion');
            $table->enum('tipo', ['correctiva', 'preventiva', 'mejora', 'emergencia']);
            $table->enum('prioridad', ['baja', 'media', 'alta', 'urgente'])->default('media');
            $table->enum('estado', ['solicitada', 'aprobada', 'en_ejecucion', 'completada', 'cancelada'])->default('solicitada');
            $table->date('fecha_solicitud');
            $table->date('fecha_programada')->nullable();
            $table->date('fecha_inicio_real')->nullable();
            $table->date('fecha_termino_real')->nullable();
            $table->decimal('presupuesto_estimado', 14, 2)->nullable();
            $table->decimal('costo_real', 14, 2)->nullable();
            $table->foreignId('solicitado_por')->constrained('users');
            $table->foreignId('aprobado_por')->nullable()->constrained('users')->nullOnDelete();
            $table->text('observaciones')->nullable();
            $table->json('fotos_antes')->nullable();
            $table->json('fotos_despues')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('plan_mantencion', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('nombre');
            $table->text('descripcion');
            $table->string('equipo_sistema');
            $table->enum('frecuencia', ['diaria', 'semanal', 'quincenal', 'mensual', 'bimestral', 'trimestral', 'semestral', 'anual']);
            $table->date('proxima_ejecucion');
            $table->date('ultima_ejecucion')->nullable();
            $table->foreignId('proveedor_id')->nullable()->constrained('proveedores')->nullOnDelete();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        // =================================================================
        // M18 - COMUNICACIONES
        // =================================================================
        Schema::create('comunicados', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('titulo');
            $table->text('contenido');
            $table->enum('tipo', ['informativo', 'urgente', 'asamblea', 'cobranza', 'mantencion', 'otro']);
            $table->enum('canal', ['email', 'app', 'sms', 'todos'])->default('todos');
            $table->json('destinatarios')->nullable();
            $table->datetime('fecha_publicacion');
            $table->datetime('fecha_expiracion')->nullable();
            $table->boolean('requiere_confirmacion')->default(false);
            $table->integer('confirmaciones_recibidas')->default(0);
            $table->enum('estado', ['borrador', 'programado', 'enviado', 'expirado'])->default('borrador');
            $table->foreignId('creado_por')->constrained('users');
            $table->json('archivos_adjuntos')->nullable();
            $table->timestamps();
        });

        // =================================================================
        // M19 - REPORTES Y DASHBOARDS
        // =================================================================
        Schema::create('reportes_configurados', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->nullable()->constrained()->nullOnDelete();
            $table->string('nombre');
            $table->string('codigo')->unique();
            $table->enum('tipo', ['financiero', 'operacional', 'compliance', 'tributario', 'ejecutivo', 'personalizado']);
            $table->json('parametros')->nullable();
            $table->json('columnas')->nullable();
            $table->json('filtros')->nullable();
            $table->string('formato_salida')->default('pdf');
            $table->boolean('programado')->default(false);
            $table->string('frecuencia_programada')->nullable();
            $table->json('destinatarios_email')->nullable();
            $table->boolean('activo')->default(true);
            $table->timestamps();
        });

        Schema::create('reportes_generados', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('reporte_config_id')->constrained('reportes_configurados')->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->nullable()->constrained()->nullOnDelete();
            $table->string('periodo', 20)->nullable();
            $table->datetime('fecha_generacion');
            $table->string('archivo');
            $table->string('formato');
            $table->integer('tamano_bytes');
            $table->foreignId('generado_por')->nullable()->constrained('users')->nullOnDelete();
            $table->boolean('enviado_email')->default(false);
            $table->timestamps();
        });

        // =================================================================
        // M20 - DOCUMENTOS Y ARCHIVOS
        // =================================================================
        Schema::create('documentos', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->nullable()->constrained()->nullOnDelete();
            $table->string('documentable_type');
            $table->unsignedBigInteger('documentable_id');
            $table->string('nombre');
            $table->string('nombre_original');
            $table->string('ruta');
            $table->string('mime_type');
            $table->integer('tamano_bytes');
            $table->enum('categoria', ['contrato', 'factura', 'acta', 'legal', 'tecnico', 'foto', 'otro'])->default('otro');
            $table->text('descripcion')->nullable();
            $table->boolean('publico')->default(false);
            $table->foreignId('subido_por')->constrained('users');
            $table->timestamps();
            $table->softDeletes();
            $table->index(['documentable_type', 'documentable_id']);
        });

        // =================================================================
        // M21 - CONFIGURACIONES Y PARÁMETROS
        // =================================================================
        Schema::create('configuraciones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->nullable()->constrained()->cascadeOnDelete();
            $table->foreignId('copropiedad_id')->nullable()->constrained()->nullOnDelete();
            $table->string('grupo');
            $table->string('clave');
            $table->text('valor')->nullable();
            $table->string('tipo')->default('string');
            $table->text('descripcion')->nullable();
            $table->boolean('editable')->default(true);
            $table->timestamps();
            $table->unique(['tenant_id', 'copropiedad_id', 'grupo', 'clave']);
        });

        Schema::create('uf_historico', function (Blueprint $table) {
            $table->id();
            $table->date('fecha')->unique();
            $table->decimal('valor', 10, 4);
            $table->timestamps();
            $table->index('fecha');
        });

        // =================================================================
        // M22 - NOTIFICACIONES
        // =================================================================
        Schema::create('notifications', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('type');
            $table->morphs('notifiable');
            $table->text('data');
            $table->timestamp('read_at')->nullable();
            $table->timestamps();
        });

        // =================================================================
        // M23 - JOBS Y COLAS
        // =================================================================
        Schema::create('jobs', function (Blueprint $table) {
            $table->id();
            $table->string('queue')->index();
            $table->longText('payload');
            $table->unsignedTinyInteger('attempts');
            $table->unsignedInteger('reserved_at')->nullable();
            $table->unsignedInteger('available_at');
            $table->unsignedInteger('created_at');
        });

        Schema::create('failed_jobs', function (Blueprint $table) {
            $table->id();
            $table->string('uuid')->unique();
            $table->text('connection');
            $table->text('queue');
            $table->longText('payload');
            $table->longText('exception');
            $table->timestamp('failed_at')->useCurrent();
        });

        Schema::create('job_batches', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->string('name');
            $table->integer('total_jobs');
            $table->integer('pending_jobs');
            $table->integer('failed_jobs');
            $table->longText('failed_job_ids');
            $table->mediumText('options')->nullable();
            $table->integer('cancelled_at')->nullable();
            $table->integer('created_at');
            $table->integer('finished_at')->nullable();
        });

        Schema::create('cache', function (Blueprint $table) {
            $table->string('key')->primary();
            $table->mediumText('value');
            $table->integer('expiration');
        });

        Schema::create('cache_locks', function (Blueprint $table) {
            $table->string('key')->primary();
            $table->string('owner');
            $table->integer('expiration');
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    public function down(): void
    {
        // Drop en orden inverso por dependencias
        $tables = [
            'sessions', 'cache_locks', 'cache', 'job_batches', 'failed_jobs', 'jobs',
            'notifications', 'uf_historico', 'configuraciones', 'documentos',
            'reportes_generados', 'reportes_configurados', 'comunicados',
            'plan_mantencion', 'ordenes_trabajo', 'contratos_arriendo',
            'precession_alerts', 'precession_analyses', 'avaluos',
            'requisitos_normativos', 'compliance_evaluaciones',
            'actas_asamblea', 'asambleas', 'movimientos_fondo_reserva', 'fondos_reserva',
            'integracion_sii_config', 'declaraciones_juradas', 'certificados_tributarios',
            'saldos_cuenta', 'movimientos_contables', 'asientos_contables',
            'libros_contables', 'periodos_contables', 'planes_cuenta',
            'contratos_servicio', 'proveedores', 'convenios_pago',
            'gestiones_cobranza', 'morosidad', 'pagos', 'cobros_unidad',
            'gastos_comunes', 'categorias_gasto', 'periodos_gasto',
            'distribucion_ingresos_antenas', 'facturas_antenas', 'contratos_antenas',
            'espacios_comunes', 'copropietarios', 'unidades', 'copropiedades',
            'audit_logs', 'personal_access_tokens', 'password_reset_tokens',
            'permissions', 'role_user', 'roles', 'users', 'tenants'
        ];

        foreach ($tables as $table) {
            Schema::dropIfExists($table);
        }
    }
};
