<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - SEEDERS COMPLETOS
 * Datos iniciales para producción
 * =========================================================================
 */

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\{DB, Hash};
use App\Models\{
    Tenant, User, Role, Permission, CategoriaGasto, PlanCuenta,
    RequisitoNormativo, Configuracion, UfHistorico
};

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            PermissionSeeder::class,
            RoleSeeder::class,
            TenantSeeder::class,
            CategoriaGastoSeeder::class,
            PlanCuentaSeeder::class,
            RequisitoNormativoSeeder::class,
            ConfiguracionSeeder::class,
            UfHistoricoSeeder::class,
        ]);
    }
}

// =============================================================================
// PERMISSIONS SEEDER
// =============================================================================
class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            // Copropiedades
            ['name' => 'Ver Copropiedades', 'slug' => 'copropiedades.view', 'module' => 'copropiedades'],
            ['name' => 'Crear Copropiedades', 'slug' => 'copropiedades.create', 'module' => 'copropiedades'],
            ['name' => 'Editar Copropiedades', 'slug' => 'copropiedades.edit', 'module' => 'copropiedades'],
            ['name' => 'Eliminar Copropiedades', 'slug' => 'copropiedades.delete', 'module' => 'copropiedades'],
            
            // Unidades
            ['name' => 'Ver Unidades', 'slug' => 'unidades.view', 'module' => 'unidades'],
            ['name' => 'Crear Unidades', 'slug' => 'unidades.create', 'module' => 'unidades'],
            ['name' => 'Editar Unidades', 'slug' => 'unidades.edit', 'module' => 'unidades'],
            
            // Antenas
            ['name' => 'Ver Contratos Antenas', 'slug' => 'antenas.view', 'module' => 'antenas'],
            ['name' => 'Crear Contratos Antenas', 'slug' => 'antenas.create', 'module' => 'antenas'],
            ['name' => 'Facturar Antenas', 'slug' => 'antenas.facturar', 'module' => 'antenas'],
            
            // Gastos Comunes
            ['name' => 'Ver Gastos', 'slug' => 'gastos.view', 'module' => 'gastos'],
            ['name' => 'Crear Gastos', 'slug' => 'gastos.create', 'module' => 'gastos'],
            ['name' => 'Aprobar Gastos', 'slug' => 'gastos.aprobar', 'module' => 'gastos'],
            ['name' => 'Prorratear', 'slug' => 'gastos.prorratear', 'module' => 'gastos'],
            
            // Morosidad
            ['name' => 'Ver Morosidad', 'slug' => 'morosidad.view', 'module' => 'morosidad'],
            ['name' => 'Gestionar Cobranza', 'slug' => 'morosidad.gestionar', 'module' => 'morosidad'],
            ['name' => 'Crear Convenios', 'slug' => 'morosidad.convenios', 'module' => 'morosidad'],
            
            // Contabilidad
            ['name' => 'Ver Contabilidad', 'slug' => 'contabilidad.view', 'module' => 'contabilidad'],
            ['name' => 'Crear Asientos', 'slug' => 'contabilidad.asientos', 'module' => 'contabilidad'],
            ['name' => 'Aprobar Asientos', 'slug' => 'contabilidad.aprobar', 'module' => 'contabilidad'],
            ['name' => 'Cerrar Períodos', 'slug' => 'contabilidad.cerrar', 'module' => 'contabilidad'],
            
            // Certificados
            ['name' => 'Emitir Certificados', 'slug' => 'certificados.emitir', 'module' => 'certificados'],
            
            // PAE
            ['name' => 'Ver PAE', 'slug' => 'pae.view', 'module' => 'pae'],
            ['name' => 'Ejecutar Análisis PAE', 'slug' => 'pae.analyze', 'module' => 'pae'],
            
            // Compliance
            ['name' => 'Ver Compliance', 'slug' => 'compliance.view', 'module' => 'compliance'],
            ['name' => 'Evaluar Compliance', 'slug' => 'compliance.evaluar', 'module' => 'compliance'],
            
            // Administración
            ['name' => 'Administrar Usuarios', 'slug' => 'admin.users', 'module' => 'admin'],
            ['name' => 'Administrar Roles', 'slug' => 'admin.roles', 'module' => 'admin'],
            ['name' => 'Ver Auditoría', 'slug' => 'admin.audit', 'module' => 'admin'],
            ['name' => 'Configuración Sistema', 'slug' => 'admin.config', 'module' => 'admin'],
        ];

        foreach ($permissions as $permission) {
            Permission::updateOrCreate(['slug' => $permission['slug']], $permission);
        }
    }
}

// =============================================================================
// ROLES SEEDER
// =============================================================================
class RoleSeeder extends Seeder
{
    public function run(): void
    {
        $allPermissions = Permission::pluck('slug')->toArray();

        $roles = [
            [
                'name' => 'Super Administrador',
                'slug' => 'super-admin',
                'description' => 'Acceso total al sistema',
                'is_system' => true,
                'permissions' => $allPermissions,
            ],
            [
                'name' => 'Administrador',
                'slug' => 'admin',
                'description' => 'Administrador de tenant',
                'is_system' => true,
                'permissions' => array_filter($allPermissions, fn($p) => !str_starts_with($p, 'admin.')),
            ],
            [
                'name' => 'Contador',
                'slug' => 'contador',
                'description' => 'Acceso a módulos contables y tributarios',
                'is_system' => true,
                'permissions' => [
                    'copropiedades.view', 'unidades.view', 'gastos.view', 'gastos.create',
                    'gastos.aprobar', 'gastos.prorratear', 'contabilidad.view', 'contabilidad.asientos',
                    'contabilidad.aprobar', 'contabilidad.cerrar', 'certificados.emitir',
                    'antenas.view', 'antenas.facturar', 'morosidad.view',
                ],
            ],
            [
                'name' => 'Administrador de Edificio',
                'slug' => 'admin-edificio',
                'description' => 'Gestión operativa del edificio',
                'is_system' => true,
                'permissions' => [
                    'copropiedades.view', 'unidades.view', 'unidades.edit',
                    'gastos.view', 'gastos.create', 'morosidad.view', 'morosidad.gestionar',
                    'antenas.view', 'pae.view', 'compliance.view',
                ],
            ],
            [
                'name' => 'Copropietario',
                'slug' => 'copropietario',
                'description' => 'Acceso limitado a información propia',
                'is_system' => true,
                'permissions' => [
                    'copropiedades.view', 'unidades.view',
                ],
            ],
        ];

        foreach ($roles as $roleData) {
            Role::updateOrCreate(
                ['slug' => $roleData['slug'], 'tenant_id' => null],
                $roleData
            );
        }
    }
}

// =============================================================================
// TENANT SEEDER (Demo)
// =============================================================================
class TenantSeeder extends Seeder
{
    public function run(): void
    {
        // Crear tenant demo
        $tenant = Tenant::updateOrCreate(
            ['slug' => 'demo'],
            [
                'uuid' => \Str::uuid(),
                'name' => 'Demo DATAPOLIS',
                'rut' => '76.000.000-0',
                'razon_social' => 'Administradora Demo SpA',
                'giro' => 'Administración de Copropiedades',
                'direccion' => 'Av. Providencia 1234',
                'comuna' => 'Providencia',
                'region' => 'Metropolitana',
                'email' => 'demo@datapolis.cl',
                'plan' => 'enterprise',
                'active' => true,
                'settings' => [
                    'timezone' => 'America/Santiago',
                    'locale' => 'es',
                    'currency' => 'CLP',
                ],
                'features' => [
                    'pae' => true,
                    'compliance' => true,
                    'antenas' => true,
                    'contabilidad' => true,
                    'certificados' => true,
                ],
            ]
        );

        // Crear usuario admin
        $adminRole = Role::where('slug', 'super-admin')->first();
        
        $admin = User::updateOrCreate(
            ['email' => 'admin@datapolis.cl'],
            [
                'uuid' => \Str::uuid(),
                'tenant_id' => $tenant->id,
                'name' => 'Administrador Sistema',
                'rut' => '11.111.111-1',
                'password' => Hash::make('DataPolis2024!'),
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );

        $admin->roles()->sync([$adminRole->id]);
    }
}

// =============================================================================
// CATEGORÍAS DE GASTO SEEDER
// =============================================================================
class CategoriaGastoSeeder extends Seeder
{
    public function run(): void
    {
        $categorias = [
            // Gastos Ordinarios
            ['codigo' => 'GO-001', 'nombre' => 'Remuneraciones Personal', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5101'],
            ['codigo' => 'GO-002', 'nombre' => 'Consumo Eléctrico', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5102'],
            ['codigo' => 'GO-003', 'nombre' => 'Consumo Agua', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5103'],
            ['codigo' => 'GO-004', 'nombre' => 'Consumo Gas', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5104'],
            ['codigo' => 'GO-005', 'nombre' => 'Servicio Aseo', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5105'],
            ['codigo' => 'GO-006', 'nombre' => 'Servicio Seguridad', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5106'],
            ['codigo' => 'GO-007', 'nombre' => 'Mantención Ascensores', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5107'],
            ['codigo' => 'GO-008', 'nombre' => 'Mantención Jardines', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5108'],
            ['codigo' => 'GO-009', 'nombre' => 'Seguros', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5109'],
            ['codigo' => 'GO-010', 'nombre' => 'Administración', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5110'],
            ['codigo' => 'GO-011', 'nombre' => 'Gastos Bancarios', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5111'],
            ['codigo' => 'GO-012', 'nombre' => 'Otros Gastos Ordinarios', 'tipo' => 'ordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5199'],
            
            // Gastos Extraordinarios
            ['codigo' => 'GE-001', 'nombre' => 'Reparaciones Mayores', 'tipo' => 'extraordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5201'],
            ['codigo' => 'GE-002', 'nombre' => 'Mejoras Infraestructura', 'tipo' => 'extraordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5202'],
            ['codigo' => 'GE-003', 'nombre' => 'Proyectos Especiales', 'tipo' => 'extraordinario', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '5203'],
            
            // Ingresos
            ['codigo' => 'IN-001', 'nombre' => 'Ingresos Antenas', 'tipo' => 'ingreso', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '4101', 'afecto_iva' => true],
            ['codigo' => 'IN-002', 'nombre' => 'Arriendo Espacios Comunes', 'tipo' => 'ingreso', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '4102'],
            ['codigo' => 'IN-003', 'nombre' => 'Multas e Intereses', 'tipo' => 'ingreso', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '4103'],
            ['codigo' => 'IN-004', 'nombre' => 'Otros Ingresos', 'tipo' => 'ingreso', 'metodo_prorrateo' => 'alicuota', 'cuenta_contable' => '4199'],
        ];

        foreach ($categorias as $categoria) {
            CategoriaGasto::updateOrCreate(
                ['codigo' => $categoria['codigo'], 'tenant_id' => 1],
                array_merge($categoria, ['tenant_id' => 1, 'activo' => true])
            );
        }
    }
}

// =============================================================================
// PLAN DE CUENTAS SEEDER
// =============================================================================
class PlanCuentaSeeder extends Seeder
{
    public function run(): void
    {
        $cuentas = [
            // ACTIVOS
            ['codigo' => '1', 'nombre' => 'ACTIVOS', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 1, 'es_cuenta_movimiento' => false],
            ['codigo' => '11', 'nombre' => 'Activo Corriente', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 2, 'cuenta_padre' => '1', 'es_cuenta_movimiento' => false],
            ['codigo' => '1101', 'nombre' => 'Caja', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '11', 'es_cuenta_movimiento' => true],
            ['codigo' => '1102', 'nombre' => 'Banco Cuenta Corriente', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '11', 'es_cuenta_movimiento' => true],
            ['codigo' => '1103', 'nombre' => 'Fondos por Rendir', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '11', 'es_cuenta_movimiento' => true],
            ['codigo' => '1104', 'nombre' => 'Cuentas por Cobrar Copropietarios', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '11', 'es_cuenta_movimiento' => true],
            ['codigo' => '1105', 'nombre' => 'Cuentas por Cobrar Antenas', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '11', 'es_cuenta_movimiento' => true],
            ['codigo' => '1106', 'nombre' => 'IVA Crédito Fiscal', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '11', 'es_cuenta_movimiento' => true],
            ['codigo' => '1107', 'nombre' => 'Fondo de Reserva', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '11', 'es_cuenta_movimiento' => true],
            
            // PASIVOS
            ['codigo' => '2', 'nombre' => 'PASIVOS', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 1, 'es_cuenta_movimiento' => false],
            ['codigo' => '21', 'nombre' => 'Pasivo Corriente', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 2, 'cuenta_padre' => '2', 'es_cuenta_movimiento' => false],
            ['codigo' => '2101', 'nombre' => 'Cuentas por Pagar Proveedores', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '21', 'es_cuenta_movimiento' => true],
            ['codigo' => '2102', 'nombre' => 'Remuneraciones por Pagar', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '21', 'es_cuenta_movimiento' => true],
            ['codigo' => '2103', 'nombre' => 'IVA Débito Fiscal', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '21', 'es_cuenta_movimiento' => true],
            ['codigo' => '2104', 'nombre' => 'Retenciones por Pagar', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '21', 'es_cuenta_movimiento' => true],
            ['codigo' => '2105', 'nombre' => 'Provisiones', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '21', 'es_cuenta_movimiento' => true],
            
            // PATRIMONIO
            ['codigo' => '3', 'nombre' => 'PATRIMONIO', 'tipo' => 'patrimonio', 'naturaleza' => 'acreedora', 'nivel' => 1, 'es_cuenta_movimiento' => false],
            ['codigo' => '31', 'nombre' => 'Capital y Reservas', 'tipo' => 'patrimonio', 'naturaleza' => 'acreedora', 'nivel' => 2, 'cuenta_padre' => '3', 'es_cuenta_movimiento' => false],
            ['codigo' => '3101', 'nombre' => 'Fondo de Reserva Ley 21.442', 'tipo' => 'patrimonio', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '31', 'es_cuenta_movimiento' => true],
            ['codigo' => '3102', 'nombre' => 'Resultados Acumulados', 'tipo' => 'patrimonio', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '31', 'es_cuenta_movimiento' => true],
            ['codigo' => '3103', 'nombre' => 'Resultado del Ejercicio', 'tipo' => 'patrimonio', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '31', 'es_cuenta_movimiento' => true],
            
            // INGRESOS
            ['codigo' => '4', 'nombre' => 'INGRESOS', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 1, 'es_cuenta_movimiento' => false],
            ['codigo' => '41', 'nombre' => 'Ingresos Operacionales', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 2, 'cuenta_padre' => '4', 'es_cuenta_movimiento' => false],
            ['codigo' => '4101', 'nombre' => 'Ingresos por Antenas', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '41', 'es_cuenta_movimiento' => true],
            ['codigo' => '4102', 'nombre' => 'Arriendo Espacios Comunes', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '41', 'es_cuenta_movimiento' => true],
            ['codigo' => '4103', 'nombre' => 'Multas e Intereses', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '41', 'es_cuenta_movimiento' => true],
            ['codigo' => '4199', 'nombre' => 'Otros Ingresos', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'cuenta_padre' => '41', 'es_cuenta_movimiento' => true],
            
            // GASTOS
            ['codigo' => '5', 'nombre' => 'GASTOS', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 1, 'es_cuenta_movimiento' => false],
            ['codigo' => '51', 'nombre' => 'Gastos Ordinarios', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 2, 'cuenta_padre' => '5', 'es_cuenta_movimiento' => false],
            ['codigo' => '5101', 'nombre' => 'Remuneraciones', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5102', 'nombre' => 'Consumo Eléctrico', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5103', 'nombre' => 'Consumo Agua', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5104', 'nombre' => 'Consumo Gas', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5105', 'nombre' => 'Servicio Aseo', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5106', 'nombre' => 'Servicio Seguridad', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5107', 'nombre' => 'Mantención Ascensores', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5108', 'nombre' => 'Mantención Jardines', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5109', 'nombre' => 'Seguros', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5110', 'nombre' => 'Administración', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5111', 'nombre' => 'Gastos Bancarios', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '5199', 'nombre' => 'Otros Gastos Ordinarios', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '51', 'es_cuenta_movimiento' => true],
            ['codigo' => '52', 'nombre' => 'Gastos Extraordinarios', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 2, 'cuenta_padre' => '5', 'es_cuenta_movimiento' => false],
            ['codigo' => '5201', 'nombre' => 'Reparaciones Mayores', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '52', 'es_cuenta_movimiento' => true],
            ['codigo' => '5202', 'nombre' => 'Mejoras Infraestructura', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'cuenta_padre' => '52', 'es_cuenta_movimiento' => true],
        ];

        foreach ($cuentas as $cuenta) {
            PlanCuenta::updateOrCreate(
                ['codigo' => $cuenta['codigo'], 'tenant_id' => 1, 'copropiedad_id' => null],
                array_merge($cuenta, ['tenant_id' => 1, 'activa' => true])
            );
        }
    }
}

// =============================================================================
// REQUISITOS NORMATIVOS SEEDER
// =============================================================================
class RequisitoNormativoSeeder extends Seeder
{
    public function run(): void
    {
        $requisitos = [
            // Ley 21.442
            ['codigo' => 'L21442-01', 'nombre' => 'Fondo de Reserva mínimo 5%', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'mensual'],
            ['codigo' => 'L21442-02', 'nombre' => 'Asamblea Ordinaria Anual', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'anual'],
            ['codigo' => 'L21442-03', 'nombre' => 'Acta de Asamblea firmada', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'por_evento'],
            ['codigo' => 'L21442-04', 'nombre' => 'Quórum mínimo para contratos bienes comunes', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'por_evento'],
            ['codigo' => 'L21442-05', 'nombre' => 'Reglamento de Copropiedad actualizado', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'anual'],
            
            // DS 7/2025
            ['codigo' => 'DS7-01', 'nombre' => 'Libro de Actas actualizado', 'normativa' => 'ds7_2025', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'mensual'],
            ['codigo' => 'DS7-02', 'nombre' => 'Rendición de cuentas anual', 'normativa' => 'ds7_2025', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'anual'],
            
            // SII
            ['codigo' => 'SII-01', 'nombre' => 'Inicio de actividades vigente', 'normativa' => 'sii', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'anual'],
            ['codigo' => 'SII-02', 'nombre' => 'Facturación mensual contratos afectos', 'normativa' => 'sii', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'mensual'],
            ['codigo' => 'SII-03', 'nombre' => 'Declaración DJ anual ingresos', 'normativa' => 'sii', 'obligatoriedad' => 'obligatorio', 'frecuencia_verificacion' => 'anual'],
        ];

        foreach ($requisitos as $requisito) {
            RequisitoNormativo::updateOrCreate(
                ['codigo' => $requisito['codigo'], 'tenant_id' => 1],
                array_merge($requisito, [
                    'tenant_id' => 1,
                    'descripcion' => $requisito['nombre'],
                    'activo' => true,
                ])
            );
        }
    }
}

// =============================================================================
// CONFIGURACIÓN SEEDER
// =============================================================================
class ConfiguracionSeeder extends Seeder
{
    public function run(): void
    {
        $configs = [
            // Sistema
            ['grupo' => 'sistema', 'clave' => 'nombre_aplicacion', 'valor' => 'DATAPOLIS', 'tipo' => 'string'],
            ['grupo' => 'sistema', 'clave' => 'version', 'valor' => '3.0.0', 'tipo' => 'string'],
            ['grupo' => 'sistema', 'clave' => 'timezone', 'valor' => 'America/Santiago', 'tipo' => 'string'],
            ['grupo' => 'sistema', 'clave' => 'locale', 'valor' => 'es', 'tipo' => 'string'],
            
            // Tributario
            ['grupo' => 'tributario', 'clave' => 'tasa_iva', 'valor' => '19', 'tipo' => 'integer'],
            ['grupo' => 'tributario', 'clave' => 'tasa_interes_mora', 'valor' => '1.5', 'tipo' => 'float'],
            
            // Gastos Comunes
            ['grupo' => 'gastos', 'clave' => 'dia_vencimiento_default', 'valor' => '10', 'tipo' => 'integer'],
            ['grupo' => 'gastos', 'clave' => 'porcentaje_fondo_reserva_minimo', 'valor' => '5', 'tipo' => 'float'],
            
            // PAE
            ['grupo' => 'pae', 'clave' => 'horizonte_default', 'valor' => '36', 'tipo' => 'integer'],
            ['grupo' => 'pae', 'clave' => 'profundidad_default', 'valor' => '4', 'tipo' => 'integer'],
            
            // Notificaciones
            ['grupo' => 'notificaciones', 'clave' => 'email_remitente', 'valor' => 'notificaciones@datapolis.cl', 'tipo' => 'string'],
            ['grupo' => 'notificaciones', 'clave' => 'dias_aviso_vencimiento', 'valor' => '5', 'tipo' => 'integer'],
        ];

        foreach ($configs as $config) {
            Configuracion::updateOrCreate(
                ['grupo' => $config['grupo'], 'clave' => $config['clave'], 'tenant_id' => null, 'copropiedad_id' => null],
                array_merge($config, ['editable' => true])
            );
        }
    }
}

// =============================================================================
// UF HISTÓRICO SEEDER
// =============================================================================
class UfHistoricoSeeder extends Seeder
{
    public function run(): void
    {
        // Últimos valores UF (febrero 2026)
        $valores = [
            ['fecha' => '2026-02-01', 'valor' => 38521.45],
            ['fecha' => '2026-02-02', 'valor' => 38525.12],
            ['fecha' => '2026-02-03', 'valor' => 38528.79],
            ['fecha' => '2026-02-04', 'valor' => 38532.46],
            ['fecha' => '2026-02-05', 'valor' => 38536.13],
            ['fecha' => '2026-02-06', 'valor' => 38539.80],
        ];

        foreach ($valores as $uf) {
            UfHistorico::updateOrCreate(
                ['fecha' => $uf['fecha']],
                $uf
            );
        }
    }
}
