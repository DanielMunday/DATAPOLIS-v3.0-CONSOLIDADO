<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * =========================================================================
 * DATAPOLIS v3.0 - SEEDER MAESTRO
 * Datos iniciales completos para producción
 * =========================================================================
 */
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            RegionesSeeder::class,
            RolesPermisosSeeder::class,
            CategoriasGastoSeeder::class,
            PlanCuentasSeeder::class,
            RequisitosNormativosSeeder::class,
            ConfiguracionesSeeder::class,
            UFHistoricoSeeder::class,
            TenantDemoSeeder::class,
        ]);
    }
}

/**
 * Regiones y Comunas de Chile
 */
class RegionesSeeder extends Seeder
{
    public function run(): void
    {
        $regiones = [
            ['codigo' => 'XV', 'nombre' => 'Arica y Parinacota', 'comunas' => ['Arica', 'Camarones', 'Putre', 'General Lagos']],
            ['codigo' => 'I', 'nombre' => 'Tarapacá', 'comunas' => ['Iquique', 'Alto Hospicio', 'Pozo Almonte', 'Camiña', 'Colchane', 'Huara', 'Pica']],
            ['codigo' => 'II', 'nombre' => 'Antofagasta', 'comunas' => ['Antofagasta', 'Mejillones', 'Sierra Gorda', 'Taltal', 'Calama', 'Ollagüe', 'San Pedro de Atacama', 'Tocopilla', 'María Elena']],
            ['codigo' => 'III', 'nombre' => 'Atacama', 'comunas' => ['Copiapó', 'Caldera', 'Tierra Amarilla', 'Chañaral', 'Diego de Almagro', 'Vallenar', 'Alto del Carmen', 'Freirina', 'Huasco']],
            ['codigo' => 'IV', 'nombre' => 'Coquimbo', 'comunas' => ['La Serena', 'Coquimbo', 'Andacollo', 'La Higuera', 'Paihuano', 'Vicuña', 'Illapel', 'Canela', 'Los Vilos', 'Salamanca', 'Ovalle', 'Combarbalá', 'Monte Patria', 'Punitaqui', 'Río Hurtado']],
            ['codigo' => 'V', 'nombre' => 'Valparaíso', 'comunas' => ['Valparaíso', 'Viña del Mar', 'Concón', 'Quintero', 'Puchuncaví', 'Casablanca', 'Juan Fernández', 'Isla de Pascua', 'San Antonio', 'Algarrobo', 'Cartagena', 'El Quisco', 'El Tabo', 'Santo Domingo', 'Quillota', 'Calera', 'Hijuelas', 'La Cruz', 'Nogales', 'San Felipe', 'Catemu', 'Llaillay', 'Panquehue', 'Putaendo', 'Santa María', 'Los Andes', 'Calle Larga', 'Rinconada', 'San Esteban', 'Limache', 'Olmué', 'Villa Alemana', 'Quilpué']],
            ['codigo' => 'RM', 'nombre' => 'Metropolitana', 'comunas' => ['Santiago', 'Cerrillos', 'Cerro Navia', 'Conchalí', 'El Bosque', 'Estación Central', 'Huechuraba', 'Independencia', 'La Cisterna', 'La Florida', 'La Granja', 'La Pintana', 'La Reina', 'Las Condes', 'Lo Barnechea', 'Lo Espejo', 'Lo Prado', 'Macul', 'Maipú', 'Ñuñoa', 'Pedro Aguirre Cerda', 'Peñalolén', 'Providencia', 'Pudahuel', 'Quilicura', 'Quinta Normal', 'Recoleta', 'Renca', 'San Joaquín', 'San Miguel', 'San Ramón', 'Vitacura', 'Puente Alto', 'Pirque', 'San José de Maipo', 'Colina', 'Lampa', 'Tiltil', 'San Bernardo', 'Buin', 'Calera de Tango', 'Paine', 'Melipilla', 'Alhué', 'Curacaví', 'María Pinto', 'San Pedro', 'Talagante', 'El Monte', 'Isla de Maipo', 'Padre Hurtado', 'Peñaflor']],
            ['codigo' => 'VI', 'nombre' => "O'Higgins", 'comunas' => ['Rancagua', 'Codegua', 'Coinco', 'Coltauco', 'Doñihue', 'Graneros', 'Las Cabras', 'Machalí', 'Malloa', 'Mostazal', 'Olivar', 'Peumo', 'Pichidegua', 'Quinta de Tilcoco', 'Rengo', 'Requínoa', 'San Vicente', 'Pichilemu', 'La Estrella', 'Litueche', 'Marchihue', 'Navidad', 'Paredones', 'San Fernando', 'Chépica', 'Chimbarongo', 'Lolol', 'Nancagua', 'Palmilla', 'Peralillo', 'Placilla', 'Pumanque', 'Santa Cruz']],
            ['codigo' => 'VII', 'nombre' => 'Maule', 'comunas' => ['Talca', 'Constitución', 'Curepto', 'Empedrado', 'Maule', 'Pelarco', 'Pencahue', 'Río Claro', 'San Clemente', 'San Rafael', 'Cauquenes', 'Chanco', 'Pelluhue', 'Curicó', 'Hualañé', 'Licantén', 'Molina', 'Rauco', 'Romeral', 'Sagrada Familia', 'Teno', 'Vichuquén', 'Linares', 'Colbún', 'Longaví', 'Parral', 'Retiro', 'San Javier', 'Villa Alegre', 'Yerbas Buenas']],
            ['codigo' => 'XVI', 'nombre' => 'Ñuble', 'comunas' => ['Chillán', 'Bulnes', 'Chillán Viejo', 'El Carmen', 'Pemuco', 'Pinto', 'Quillón', 'San Ignacio', 'Yungay', 'Quirihue', 'Cobquecura', 'Coelemu', 'Ninhue', 'Portezuelo', 'Ránquil', 'Treguaco', 'San Carlos', 'Coihueco', 'Ñiquén', 'San Fabián', 'San Nicolás']],
            ['codigo' => 'VIII', 'nombre' => 'Biobío', 'comunas' => ['Concepción', 'Coronel', 'Chiguayante', 'Florida', 'Hualqui', 'Lota', 'Penco', 'San Pedro de la Paz', 'Santa Juana', 'Talcahuano', 'Tomé', 'Hualpén', 'Lebu', 'Arauco', 'Cañete', 'Contulmo', 'Curanilahue', 'Los Álamos', 'Tirúa', 'Los Ángeles', 'Antuco', 'Cabrero', 'Laja', 'Mulchén', 'Nacimiento', 'Negrete', 'Quilaco', 'Quilleco', 'San Rosendo', 'Santa Bárbara', 'Tucapel', 'Yumbel', 'Alto Biobío']],
            ['codigo' => 'IX', 'nombre' => 'La Araucanía', 'comunas' => ['Temuco', 'Carahue', 'Cunco', 'Curarrehue', 'Freire', 'Galvarino', 'Gorbea', 'Lautaro', 'Loncoche', 'Melipeuco', 'Nueva Imperial', 'Padre las Casas', 'Perquenco', 'Pitrufquén', 'Pucón', 'Saavedra', 'Teodoro Schmidt', 'Toltén', 'Vilcún', 'Villarrica', 'Cholchol', 'Angol', 'Collipulli', 'Curacautín', 'Ercilla', 'Lonquimay', 'Los Sauces', 'Lumaco', 'Purén', 'Renaico', 'Traiguén', 'Victoria']],
            ['codigo' => 'XIV', 'nombre' => 'Los Ríos', 'comunas' => ['Valdivia', 'Corral', 'Lanco', 'Los Lagos', 'Máfil', 'Mariquina', 'Paillaco', 'Panguipulli', 'La Unión', 'Futrono', 'Lago Ranco', 'Río Bueno']],
            ['codigo' => 'X', 'nombre' => 'Los Lagos', 'comunas' => ['Puerto Montt', 'Calbuco', 'Cochamó', 'Fresia', 'Frutillar', 'Los Muermos', 'Llanquihue', 'Maullín', 'Puerto Varas', 'Castro', 'Ancud', 'Chonchi', 'Curaco de Vélez', 'Dalcahue', 'Puqueldón', 'Queilén', 'Quellón', 'Quemchi', 'Quinchao', 'Osorno', 'Puerto Octay', 'Purranque', 'Puyehue', 'Río Negro', 'San Juan de la Costa', 'San Pablo', 'Chaitén', 'Futaleufú', 'Hualaihué', 'Palena']],
            ['codigo' => 'XI', 'nombre' => 'Aysén', 'comunas' => ['Coyhaique', 'Lago Verde', 'Aysén', 'Cisnes', 'Guaitecas', 'Cochrane', "O'Higgins", 'Tortel', 'Chile Chico', 'Río Ibáñez']],
            ['codigo' => 'XII', 'nombre' => 'Magallanes', 'comunas' => ['Punta Arenas', 'Laguna Blanca', 'Río Verde', 'San Gregorio', 'Cabo de Hornos', 'Antártica', 'Porvenir', 'Primavera', 'Timaukel', 'Natales', 'Torres del Paine']],
        ];

        DB::table('configuraciones')->insert([
            'tenant_id' => null,
            'copropiedad_id' => null,
            'grupo' => 'sistema',
            'clave' => 'regiones_comunas',
            'valor' => json_encode($regiones),
            'tipo' => 'json',
            'descripcion' => 'Regiones y comunas de Chile',
            'editable' => false,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}

/**
 * Roles y Permisos del Sistema
 */
class RolesPermisosSeeder extends Seeder
{
    public function run(): void
    {
        // Permisos por módulo
        $modulos = [
            'copropiedades' => ['ver', 'crear', 'editar', 'eliminar', 'exportar'],
            'unidades' => ['ver', 'crear', 'editar', 'eliminar'],
            'copropietarios' => ['ver', 'crear', 'editar', 'eliminar'],
            'antenas' => ['ver', 'crear', 'editar', 'eliminar', 'facturar'],
            'gastos' => ['ver', 'crear', 'editar', 'eliminar', 'aprobar', 'pagar'],
            'cobranza' => ['ver', 'gestionar', 'convenios', 'judicial'],
            'contabilidad' => ['ver', 'asientos', 'cerrar_periodo', 'reportes'],
            'certificados' => ['ver', 'emitir', 'anular'],
            'declaraciones' => ['ver', 'generar', 'enviar_sii'],
            'asambleas' => ['ver', 'crear', 'actas', 'firmar'],
            'compliance' => ['ver', 'evaluar', 'plan_accion'],
            'reportes' => ['ver', 'generar', 'programar'],
            'configuracion' => ['ver', 'editar'],
            'usuarios' => ['ver', 'crear', 'editar', 'eliminar', 'roles'],
            'pae' => ['ver', 'analizar', 'alertas', 'dashboard'],
        ];

        foreach ($modulos as $modulo => $acciones) {
            foreach ($acciones as $accion) {
                DB::table('permissions')->insert([
                    'name' => ucfirst($modulo) . ' - ' . ucfirst($accion),
                    'slug' => "{$modulo}.{$accion}",
                    'module' => $modulo,
                    'description' => "Permiso para {$accion} en módulo {$modulo}",
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }

        // Roles del sistema
        $roles = [
            [
                'name' => 'Super Administrador',
                'slug' => 'super_admin',
                'description' => 'Acceso total al sistema',
                'is_system' => true,
                'permissions' => json_encode(['*']),
            ],
            [
                'name' => 'Administrador Tenant',
                'slug' => 'admin_tenant',
                'description' => 'Administrador de la organización',
                'is_system' => true,
                'permissions' => json_encode(['copropiedades.*', 'unidades.*', 'copropietarios.*', 'antenas.*', 'gastos.*', 'cobranza.*', 'contabilidad.*', 'certificados.*', 'declaraciones.*', 'asambleas.*', 'compliance.*', 'reportes.*', 'configuracion.*', 'usuarios.*', 'pae.*']),
            ],
            [
                'name' => 'Administrador Edificio',
                'slug' => 'admin_edificio',
                'description' => 'Administrador de copropiedad',
                'is_system' => true,
                'permissions' => json_encode(['copropiedades.ver', 'unidades.*', 'copropietarios.*', 'antenas.ver', 'gastos.*', 'cobranza.ver', 'cobranza.gestionar', 'contabilidad.ver', 'contabilidad.asientos', 'certificados.*', 'asambleas.*', 'reportes.ver', 'reportes.generar', 'pae.ver', 'pae.dashboard']),
            ],
            [
                'name' => 'Contador',
                'slug' => 'contador',
                'description' => 'Acceso contable y tributario',
                'is_system' => true,
                'permissions' => json_encode(['copropiedades.ver', 'antenas.ver', 'antenas.facturar', 'gastos.ver', 'gastos.aprobar', 'contabilidad.*', 'certificados.*', 'declaraciones.*', 'reportes.*']),
            ],
            [
                'name' => 'Operador Cobranza',
                'slug' => 'operador_cobranza',
                'description' => 'Gestión de cobranza',
                'is_system' => true,
                'permissions' => json_encode(['copropiedades.ver', 'unidades.ver', 'copropietarios.ver', 'gastos.ver', 'cobranza.*']),
            ],
            [
                'name' => 'Copropietario',
                'slug' => 'copropietario',
                'description' => 'Acceso copropietario',
                'is_system' => true,
                'permissions' => json_encode(['copropiedades.ver', 'unidades.ver', 'gastos.ver', 'asambleas.ver']),
            ],
            [
                'name' => 'Solo Lectura',
                'slug' => 'solo_lectura',
                'description' => 'Acceso de solo lectura',
                'is_system' => true,
                'permissions' => json_encode(['*.ver']),
            ],
        ];

        foreach ($roles as $role) {
            DB::table('roles')->insert(array_merge($role, [
                'tenant_id' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ]));
        }
    }
}

/**
 * Categorías de Gasto Estándar
 */
class CategoriasGastoSeeder extends Seeder
{
    public function run(): void
    {
        $categorias = [
            // Ordinarios
            ['codigo' => 'ADM', 'nombre' => 'Administración', 'tipo' => 'ordinario', 'cuenta' => '5101'],
            ['codigo' => 'REM', 'nombre' => 'Remuneraciones', 'tipo' => 'ordinario', 'cuenta' => '5102'],
            ['codigo' => 'ASE', 'nombre' => 'Aseo y Limpieza', 'tipo' => 'ordinario', 'cuenta' => '5103'],
            ['codigo' => 'SEG', 'nombre' => 'Seguridad y Vigilancia', 'tipo' => 'ordinario', 'cuenta' => '5104'],
            ['codigo' => 'MAN', 'nombre' => 'Mantención General', 'tipo' => 'ordinario', 'cuenta' => '5105'],
            ['codigo' => 'ASC', 'nombre' => 'Mantención Ascensores', 'tipo' => 'ordinario', 'cuenta' => '5106'],
            ['codigo' => 'JAR', 'nombre' => 'Jardinería', 'tipo' => 'ordinario', 'cuenta' => '5107'],
            ['codigo' => 'ELE', 'nombre' => 'Electricidad Común', 'tipo' => 'ordinario', 'cuenta' => '5108'],
            ['codigo' => 'AGU', 'nombre' => 'Agua Común', 'tipo' => 'ordinario', 'cuenta' => '5109'],
            ['codigo' => 'GAS', 'nombre' => 'Gas Común', 'tipo' => 'ordinario', 'cuenta' => '5110'],
            ['codigo' => 'SRO', 'nombre' => 'Seguros', 'tipo' => 'ordinario', 'cuenta' => '5111'],
            ['codigo' => 'CTB', 'nombre' => 'Contabilidad', 'tipo' => 'ordinario', 'cuenta' => '5112'],
            ['codigo' => 'LEG', 'nombre' => 'Gastos Legales', 'tipo' => 'ordinario', 'cuenta' => '5113'],
            ['codigo' => 'BAN', 'nombre' => 'Gastos Bancarios', 'tipo' => 'ordinario', 'cuenta' => '5114'],
            ['codigo' => 'OTR', 'nombre' => 'Otros Gastos Ordinarios', 'tipo' => 'ordinario', 'cuenta' => '5199'],
            // Extraordinarios
            ['codigo' => 'REP', 'nombre' => 'Reparaciones Mayores', 'tipo' => 'extraordinario', 'cuenta' => '5201'],
            ['codigo' => 'MEJ', 'nombre' => 'Mejoras', 'tipo' => 'extraordinario', 'cuenta' => '5202'],
            ['codigo' => 'EME', 'nombre' => 'Emergencias', 'tipo' => 'extraordinario', 'cuenta' => '5203'],
            ['codigo' => 'OBR', 'nombre' => 'Obras Nuevas', 'tipo' => 'extraordinario', 'cuenta' => '5204'],
            // Fondo Reserva
            ['codigo' => 'FRE', 'nombre' => 'Aporte Fondo Reserva', 'tipo' => 'fondo_reserva', 'cuenta' => '2301'],
            // Ingresos
            ['codigo' => 'GCO', 'nombre' => 'Gastos Comunes Cobrados', 'tipo' => 'ingreso', 'cuenta' => '4101'],
            ['codigo' => 'ANT', 'nombre' => 'Ingresos por Antenas', 'tipo' => 'ingreso', 'cuenta' => '4201'],
            ['codigo' => 'ARR', 'nombre' => 'Arriendo Espacios Comunes', 'tipo' => 'ingreso', 'cuenta' => '4202'],
            ['codigo' => 'MUL', 'nombre' => 'Multas e Intereses', 'tipo' => 'ingreso', 'cuenta' => '4301'],
            ['codigo' => 'OIN', 'nombre' => 'Otros Ingresos', 'tipo' => 'ingreso', 'cuenta' => '4901'],
        ];

        foreach ($categorias as $i => $cat) {
            DB::table('categorias_gasto')->insert([
                'tenant_id' => 1, // Se actualizará por tenant
                'codigo' => $cat['codigo'],
                'nombre' => $cat['nombre'],
                'tipo' => $cat['tipo'],
                'prorrateable' => !in_array($cat['tipo'], ['fondo_reserva', 'ingreso']),
                'metodo_prorrateo' => 'alicuota',
                'cuenta_contable' => $cat['cuenta'],
                'afecto_iva' => false,
                'activo' => true,
                'orden' => $i + 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}

/**
 * Plan de Cuentas Estándar para Copropiedades
 */
class PlanCuentasSeeder extends Seeder
{
    public function run(): void
    {
        $cuentas = [
            // ACTIVOS
            ['codigo' => '1', 'nombre' => 'ACTIVOS', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 1, 'movimiento' => false],
            ['codigo' => '11', 'nombre' => 'ACTIVO CIRCULANTE', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 2, 'movimiento' => false, 'padre' => '1'],
            ['codigo' => '1101', 'nombre' => 'Caja', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '11'],
            ['codigo' => '1102', 'nombre' => 'Banco Cuenta Corriente', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '11'],
            ['codigo' => '1103', 'nombre' => 'Banco Cuenta Vista', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '11'],
            ['codigo' => '1104', 'nombre' => 'Inversiones Corto Plazo', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '11'],
            ['codigo' => '12', 'nombre' => 'DEUDORES', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 2, 'movimiento' => false, 'padre' => '1'],
            ['codigo' => '1201', 'nombre' => 'Gastos Comunes por Cobrar', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '12'],
            ['codigo' => '1202', 'nombre' => 'Deudores por Antenas', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '12'],
            ['codigo' => '1203', 'nombre' => 'Deudores Varios', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '12'],
            ['codigo' => '1204', 'nombre' => 'Provisión Incobrables', 'tipo' => 'activo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '12'],
            ['codigo' => '13', 'nombre' => 'IVA Y RETENCIONES', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 2, 'movimiento' => false, 'padre' => '1'],
            ['codigo' => '1301', 'nombre' => 'IVA Crédito Fiscal', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '13'],
            ['codigo' => '1302', 'nombre' => 'PPM por Recuperar', 'tipo' => 'activo', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '13'],
            // PASIVOS
            ['codigo' => '2', 'nombre' => 'PASIVOS', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 1, 'movimiento' => false],
            ['codigo' => '21', 'nombre' => 'PASIVO CIRCULANTE', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 2, 'movimiento' => false, 'padre' => '2'],
            ['codigo' => '2101', 'nombre' => 'Proveedores', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '21'],
            ['codigo' => '2102', 'nombre' => 'Remuneraciones por Pagar', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '21'],
            ['codigo' => '2103', 'nombre' => 'Retenciones por Pagar', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '21'],
            ['codigo' => '2104', 'nombre' => 'IVA Débito Fiscal', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '21'],
            ['codigo' => '2105', 'nombre' => 'PPM por Pagar', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '21'],
            ['codigo' => '2106', 'nombre' => 'Impuestos por Pagar', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '21'],
            ['codigo' => '23', 'nombre' => 'FONDOS', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 2, 'movimiento' => false, 'padre' => '2'],
            ['codigo' => '2301', 'nombre' => 'Fondo de Reserva', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '23'],
            ['codigo' => '2302', 'nombre' => 'Fondo de Contingencia', 'tipo' => 'pasivo', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '23'],
            // PATRIMONIO
            ['codigo' => '3', 'nombre' => 'PATRIMONIO', 'tipo' => 'patrimonio', 'naturaleza' => 'acreedora', 'nivel' => 1, 'movimiento' => false],
            ['codigo' => '31', 'nombre' => 'RESULTADOS', 'tipo' => 'patrimonio', 'naturaleza' => 'acreedora', 'nivel' => 2, 'movimiento' => false, 'padre' => '3'],
            ['codigo' => '3101', 'nombre' => 'Resultado Ejercicio Anterior', 'tipo' => 'patrimonio', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '31'],
            ['codigo' => '3102', 'nombre' => 'Resultado del Ejercicio', 'tipo' => 'patrimonio', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '31'],
            // INGRESOS
            ['codigo' => '4', 'nombre' => 'INGRESOS', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 1, 'movimiento' => false],
            ['codigo' => '41', 'nombre' => 'INGRESOS OPERACIONALES', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 2, 'movimiento' => false, 'padre' => '4'],
            ['codigo' => '4101', 'nombre' => 'Gastos Comunes Ordinarios', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '41'],
            ['codigo' => '4102', 'nombre' => 'Gastos Comunes Extraordinarios', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '41'],
            ['codigo' => '42', 'nombre' => 'INGRESOS ADICIONALES', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 2, 'movimiento' => false, 'padre' => '4'],
            ['codigo' => '4201', 'nombre' => 'Ingresos por Antenas Telecomunicaciones', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '42'],
            ['codigo' => '4202', 'nombre' => 'Arriendo Espacios Comunes', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '42'],
            ['codigo' => '4203', 'nombre' => 'Arriendo Estacionamientos', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '42'],
            ['codigo' => '4204', 'nombre' => 'Arriendo Bodegas', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '42'],
            ['codigo' => '43', 'nombre' => 'OTROS INGRESOS', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 2, 'movimiento' => false, 'padre' => '4'],
            ['codigo' => '4301', 'nombre' => 'Multas Copropietarios', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '43'],
            ['codigo' => '4302', 'nombre' => 'Intereses por Mora', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '43'],
            ['codigo' => '4303', 'nombre' => 'Intereses Ganados', 'tipo' => 'ingreso', 'naturaleza' => 'acreedora', 'nivel' => 3, 'movimiento' => true, 'padre' => '43'],
            // GASTOS
            ['codigo' => '5', 'nombre' => 'GASTOS', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 1, 'movimiento' => false],
            ['codigo' => '51', 'nombre' => 'GASTOS ORDINARIOS', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 2, 'movimiento' => false, 'padre' => '5'],
            ['codigo' => '5101', 'nombre' => 'Gastos de Administración', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5102', 'nombre' => 'Remuneraciones', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5103', 'nombre' => 'Aseo y Limpieza', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5104', 'nombre' => 'Seguridad y Vigilancia', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5105', 'nombre' => 'Mantención General', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5106', 'nombre' => 'Mantención Ascensores', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5107', 'nombre' => 'Jardinería', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5108', 'nombre' => 'Electricidad Común', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5109', 'nombre' => 'Agua Común', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5110', 'nombre' => 'Gas Común', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5111', 'nombre' => 'Seguros', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5112', 'nombre' => 'Contabilidad y Auditoría', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5113', 'nombre' => 'Gastos Legales', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '5114', 'nombre' => 'Gastos Bancarios', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '51'],
            ['codigo' => '52', 'nombre' => 'GASTOS EXTRAORDINARIOS', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 2, 'movimiento' => false, 'padre' => '5'],
            ['codigo' => '5201', 'nombre' => 'Reparaciones Mayores', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '52'],
            ['codigo' => '5202', 'nombre' => 'Mejoras y Ampliaciones', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '52'],
            ['codigo' => '53', 'nombre' => 'OTROS GASTOS', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 2, 'movimiento' => false, 'padre' => '5'],
            ['codigo' => '5301', 'nombre' => 'Castigo Incobrables', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '53'],
            ['codigo' => '5302', 'nombre' => 'Gastos Financieros', 'tipo' => 'gasto', 'naturaleza' => 'deudora', 'nivel' => 3, 'movimiento' => true, 'padre' => '53'],
        ];

        foreach ($cuentas as $cuenta) {
            DB::table('planes_cuenta')->insert([
                'tenant_id' => 1,
                'copropiedad_id' => null,
                'codigo' => $cuenta['codigo'],
                'nombre' => $cuenta['nombre'],
                'tipo' => $cuenta['tipo'],
                'naturaleza' => $cuenta['naturaleza'],
                'nivel' => $cuenta['nivel'],
                'cuenta_padre' => $cuenta['padre'] ?? null,
                'es_cuenta_movimiento' => $cuenta['movimiento'],
                'requiere_centro_costo' => false,
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}

/**
 * Requisitos Normativos (Ley 21.442, DS7, SII)
 */
class RequisitosNormativosSeeder extends Seeder
{
    public function run(): void
    {
        $requisitos = [
            // Ley 21.442
            ['codigo' => 'L21442-01', 'nombre' => 'Reglamento de Copropiedad Actualizado', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'L21442-02', 'nombre' => 'Fondo de Reserva Mínimo 5%', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'L21442-03', 'nombre' => 'Asamblea Ordinaria Anual', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'L21442-04', 'nombre' => 'Cuenta Bancaria Exclusiva', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'L21442-05', 'nombre' => 'Actas de Asamblea Firmadas', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'L21442-06', 'nombre' => 'Plan de Mantención Quinquenal', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'L21442-07', 'nombre' => 'Seguro de Incendio Vigente', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'L21442-08', 'nombre' => 'Registro de Copropietarios', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'L21442-09', 'nombre' => 'Quorum Asambleas Respetado', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'L21442-10', 'nombre' => 'Transparencia Financiera', 'normativa' => 'ley_21442', 'obligatoriedad' => 'obligatorio'],
            // DS7 2025
            ['codigo' => 'DS7-01', 'nombre' => 'Certificación Ascensores', 'normativa' => 'ds7_2025', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'DS7-02', 'nombre' => 'Mantención Preventiva Documentada', 'normativa' => 'ds7_2025', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'DS7-03', 'nombre' => 'Bitácora de Mantención', 'normativa' => 'ds7_2025', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'DS7-04', 'nombre' => 'Empresa Certificada SEC', 'normativa' => 'ds7_2025', 'obligatoriedad' => 'obligatorio'],
            // SII
            ['codigo' => 'SII-01', 'nombre' => 'RUT Comunidad Vigente', 'normativa' => 'sii', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'SII-02', 'nombre' => 'Inicio Actividades (si aplica)', 'normativa' => 'sii', 'obligatoriedad' => 'recomendado'],
            ['codigo' => 'SII-03', 'nombre' => 'Emisión DTE Ingresos Antenas', 'normativa' => 'sii', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'SII-04', 'nombre' => 'Declaración IVA Mensual', 'normativa' => 'sii', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'SII-05', 'nombre' => 'DJ1887 Participación Rentas', 'normativa' => 'sii', 'obligatoriedad' => 'obligatorio'],
            ['codigo' => 'SII-06', 'nombre' => 'Certificados Tributarios Anuales', 'normativa' => 'sii', 'obligatoriedad' => 'obligatorio'],
        ];

        foreach ($requisitos as $req) {
            DB::table('requisitos_normativos')->insert([
                'tenant_id' => 1,
                'codigo' => $req['codigo'],
                'nombre' => $req['nombre'],
                'normativa' => $req['normativa'],
                'descripcion' => 'Requisito normativo: ' . $req['nombre'],
                'obligatoriedad' => $req['obligatoriedad'],
                'activo' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}

/**
 * Configuraciones del Sistema
 */
class ConfiguracionesSeeder extends Seeder
{
    public function run(): void
    {
        $configs = [
            // Sistema
            ['grupo' => 'sistema', 'clave' => 'nombre', 'valor' => 'DATAPOLIS v3.0', 'tipo' => 'string'],
            ['grupo' => 'sistema', 'clave' => 'version', 'valor' => '3.0.0', 'tipo' => 'string'],
            ['grupo' => 'sistema', 'clave' => 'ambiente', 'valor' => 'production', 'tipo' => 'string'],
            ['grupo' => 'sistema', 'clave' => 'timezone', 'valor' => 'America/Santiago', 'tipo' => 'string'],
            ['grupo' => 'sistema', 'clave' => 'locale', 'valor' => 'es_CL', 'tipo' => 'string'],
            ['grupo' => 'sistema', 'clave' => 'moneda', 'valor' => 'CLP', 'tipo' => 'string'],
            // Tributario
            ['grupo' => 'tributario', 'clave' => 'tasa_iva', 'valor' => '19', 'tipo' => 'decimal'],
            ['grupo' => 'tributario', 'clave' => 'tasa_ppm', 'valor' => '0.25', 'tipo' => 'decimal'],
            ['grupo' => 'tributario', 'clave' => 'tasa_interes_mora', 'valor' => '1.5', 'tipo' => 'decimal'],
            // Gastos Comunes
            ['grupo' => 'gastos', 'clave' => 'porcentaje_fondo_reserva', 'valor' => '5', 'tipo' => 'decimal'],
            ['grupo' => 'gastos', 'clave' => 'dias_gracia_pago', 'valor' => '5', 'tipo' => 'integer'],
            ['grupo' => 'gastos', 'clave' => 'dias_mora_cobranza', 'valor' => '30', 'tipo' => 'integer'],
            // PAE
            ['grupo' => 'pae', 'clave' => 'horizonte_default', 'valor' => '36', 'tipo' => 'integer'],
            ['grupo' => 'pae', 'clave' => 'profundidad_default', 'valor' => '4', 'tipo' => 'integer'],
            ['grupo' => 'pae', 'clave' => 'cache_ttl_horas', 'valor' => '1', 'tipo' => 'integer'],
            // SII
            ['grupo' => 'sii', 'clave' => 'ambiente', 'valor' => 'certificacion', 'tipo' => 'string'],
            ['grupo' => 'sii', 'clave' => 'url_certificacion', 'valor' => 'https://maullin.sii.cl', 'tipo' => 'string'],
            ['grupo' => 'sii', 'clave' => 'url_produccion', 'valor' => 'https://palena.sii.cl', 'tipo' => 'string'],
        ];

        foreach ($configs as $config) {
            DB::table('configuraciones')->insert([
                'tenant_id' => null,
                'copropiedad_id' => null,
                'grupo' => $config['grupo'],
                'clave' => $config['clave'],
                'valor' => $config['valor'],
                'tipo' => $config['tipo'],
                'editable' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}

/**
 * UF Histórico (últimos 12 meses)
 */
class UFHistoricoSeeder extends Seeder
{
    public function run(): void
    {
        $uf_valores = [
            '2025-01-01' => 38177.07, '2025-01-15' => 38220.45, '2025-02-01' => 38305.12,
            '2025-02-15' => 38350.88, '2025-03-01' => 38420.33, '2025-03-15' => 38475.21,
            '2025-04-01' => 38520.67, '2025-04-15' => 38580.44, '2025-05-01' => 38645.89,
            '2025-05-15' => 38710.23, '2025-06-01' => 38780.56, '2025-06-15' => 38845.12,
            '2025-07-01' => 38912.34, '2025-07-15' => 38980.67, '2025-08-01' => 39050.89,
            '2025-08-15' => 39120.45, '2025-09-01' => 39195.23, '2025-09-15' => 39265.78,
            '2025-10-01' => 39340.12, '2025-10-15' => 39410.56, '2025-11-01' => 39485.34,
            '2025-11-15' => 39555.89, '2025-12-01' => 39630.45, '2025-12-15' => 39700.23,
            '2026-01-01' => 39775.67, '2026-01-15' => 39845.12, '2026-02-01' => 39920.34,
            '2026-02-06' => 39950.56,
        ];

        foreach ($uf_valores as $fecha => $valor) {
            DB::table('uf_historico')->insert([
                'fecha' => $fecha,
                'valor' => $valor,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}

/**
 * Tenant Demo con datos de ejemplo
 */
class TenantDemoSeeder extends Seeder
{
    public function run(): void
    {
        // Tenant Demo
        $tenantId = DB::table('tenants')->insertGetId([
            'uuid' => Str::uuid(),
            'name' => 'Demo DATAPOLIS',
            'slug' => 'demo',
            'rut' => '76.000.000-0',
            'razon_social' => 'Administradora Demo SpA',
            'giro' => 'Administración de Condominios',
            'direccion' => 'Av. Providencia 1234, Of. 501',
            'comuna' => 'Providencia',
            'region' => 'Metropolitana',
            'telefono' => '+56 2 2345 6789',
            'email' => 'contacto@demo.datapolis.cl',
            'plan' => 'enterprise',
            'active' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Usuario Admin
        $adminId = DB::table('users')->insertGetId([
            'uuid' => Str::uuid(),
            'tenant_id' => $tenantId,
            'name' => 'Administrador Demo',
            'email' => 'admin@demo.datapolis.cl',
            'rut' => '12.345.678-9',
            'password' => Hash::make('Demo2026!'),
            'status' => 'active',
            'email_verified_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Copropiedad Demo
        $copropiedadId = DB::table('copropiedades')->insertGetId([
            'uuid' => Str::uuid(),
            'tenant_id' => $tenantId,
            'nombre' => 'Edificio Torre Norte',
            'rut' => '65.123.456-7',
            'direccion' => 'Av. Apoquindo 4500',
            'numero' => '4500',
            'comuna' => 'Las Condes',
            'region' => 'Metropolitana',
            'tipo' => 'edificio',
            'categoria' => 'residencial',
            'ano_construccion' => 2018,
            'pisos' => 25,
            'subterraneos' => 4,
            'superficie_terreno' => 2500.00,
            'superficie_construida' => 35000.00,
            'rol_sii' => '12345-67',
            'administrador_nombre' => 'María González',
            'administrador_email' => 'admin@torrenorte.cl',
            'tiene_inicio_actividades' => true,
            'fecha_inicio_actividades' => '2019-03-15',
            'giro_tributario' => 'Administración de bienes raíces',
            'regimen_tributario' => 'primera_categoria',
            'activa' => true,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Unidades Demo (10 unidades)
        for ($i = 1; $i <= 10; $i++) {
            $piso = ceil($i / 2);
            $letra = $i % 2 == 0 ? 'B' : 'A';
            
            $unidadId = DB::table('unidades')->insertGetId([
                'uuid' => Str::uuid(),
                'tenant_id' => $tenantId,
                'copropiedad_id' => $copropiedadId,
                'numero' => "{$piso}{$letra}",
                'piso' => (string)$piso,
                'tipo' => 'departamento',
                'superficie_util' => 75 + ($i * 5),
                'superficie_total' => 85 + ($i * 5),
                'dormitorios' => 2 + ($i % 2),
                'banos' => 2,
                'alicuota_prorrateo' => 0.10,
                'estado_ocupacion' => $i <= 8 ? 'propietario' : 'arrendada',
                'activa' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            // Copropietario
            DB::table('copropietarios')->insert([
                'uuid' => Str::uuid(),
                'tenant_id' => $tenantId,
                'unidad_id' => $unidadId,
                'tipo_persona' => 'natural',
                'rut' => '10.' . str_pad($i * 111, 3, '0', STR_PAD_LEFT) . '.' . str_pad($i * 11, 3, '0', STR_PAD_LEFT) . '-' . ($i % 10),
                'nombre' => 'Propietario',
                'apellido_paterno' => 'Demo' . $i,
                'email' => "propietario{$i}@demo.cl",
                'rol' => 'propietario',
                'porcentaje_propiedad' => 100,
                'es_principal' => true,
                'activo' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        // Contrato Antena Demo
        DB::table('contratos_antenas')->insert([
            'uuid' => Str::uuid(),
            'tenant_id' => $tenantId,
            'copropiedad_id' => $copropiedadId,
            'numero_contrato' => 'ANT-2024-001',
            'empresa_operador' => 'Entel PCS Telecomunicaciones S.A.',
            'rut_operador' => '96.806.980-2',
            'tipo_instalacion' => 'antena_celular',
            'ubicacion_instalacion' => 'Azotea Torre Norte',
            'superficie_ocupada_m2' => 25.00,
            'fecha_inicio' => '2024-01-01',
            'fecha_termino' => '2028-12-31',
            'duracion_meses' => 60,
            'renovacion_automatica' => true,
            'fecha_asamblea_aprobacion' => '2023-11-15',
            'acta_asamblea_numero' => 'AE-2023-003',
            'quorum_aprobacion' => 75.50,
            'canon_mensual_uf' => 85.0000,
            'moneda' => 'UF',
            'periodicidad_pago' => 'mensual',
            'dia_pago' => 5,
            'tipo_reajuste' => 'uf',
            'afecto_iva' => true,
            'tasa_iva' => 19.00,
            'regimen_tributario' => 'renta_efectiva',
            'distribucion_tipo' => 'mixto',
            'porcentaje_fondo_comun' => 60.00,
            'porcentaje_fondo_reserva' => 40.00,
            'seguro_responsabilidad' => true,
            'estado' => 'vigente',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Fondo de Reserva
        DB::table('fondos_reserva')->insert([
            'tenant_id' => $tenantId,
            'copropiedad_id' => $copropiedadId,
            'saldo_actual' => 15000000,
            'porcentaje_aporte_mensual' => 5.00,
            'meta_fondo' => 50000000,
            'ultima_actualizacion' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
