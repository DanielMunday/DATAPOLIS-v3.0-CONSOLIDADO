# DATAPOLIS v3.0 - GUÍA DE INSTALACIÓN cPanel
## Instalación en Servidor de Producción

---

## 1. REQUISITOS DEL SERVIDOR

### 1.1 Requisitos Mínimos

| Componente | Mínimo | Recomendado |
|------------|--------|-------------|
| PHP | 8.2+ | 8.3 |
| MySQL | 8.0+ | 8.0+ |
| RAM | 2 GB | 4 GB |
| Disco | 10 GB | 50 GB SSD |
| CPU | 2 cores | 4 cores |

### 1.2 Extensiones PHP Requeridas

```
BCMath
Ctype
cURL
DOM
Fileinfo
GD
Iconv
Intl
JSON
Mbstring
OpenSSL
PCRE
PDO
PDO_MySQL
Redis (recomendado)
Session
Tokenizer
XML
Zip
```

### 1.3 Verificar Requisitos en cPanel

1. Acceder a **cPanel > Software > Select PHP Version**
2. Seleccionar PHP 8.2 o 8.3
3. Activar las extensiones listadas arriba
4. Guardar configuración

---

## 2. INSTALACIÓN PASO A PASO

### 2.1 Crear Base de Datos

```
1. cPanel > Databases > MySQL Databases
2. Create New Database: datapolis_prod
3. Create New User: datapolis_user
4. Add User to Database con ALL PRIVILEGES
5. Anotar: nombre BD, usuario, contraseña
```

### 2.2 Subir Archivos

**Opción A: File Manager (cPanel)**
```
1. cPanel > Files > File Manager
2. Navegar a public_html (o subdirectorio deseado)
3. Upload > Subir archivo datapolis-v3.zip
4. Click derecho > Extract
```

**Opción B: FTP/SFTP**
```
1. Conectar vía FileZilla o similar
2. Host: tudominio.com
3. Usuario: usuario_cpanel
4. Puerto: 21 (FTP) o 22 (SFTP)
5. Subir contenido a public_html
```

**Opción C: Terminal SSH**
```bash
cd ~/public_html
wget https://tu-repo/datapolis-v3.zip
unzip datapolis-v3.zip
```

### 2.3 Configurar Dominio

**Estructura recomendada:**
```
public_html/
├── datapolis/           # Raíz del proyecto
│   ├── app/
│   ├── bootstrap/
│   ├── config/
│   ├── database/
│   ├── public/         # Document Root del dominio
│   ├── resources/
│   ├── routes/
│   ├── storage/
│   └── vendor/
```

**Configurar Document Root:**
```
1. cPanel > Domains > Domains
2. Modificar dominio o crear subdominio
3. Document Root: /public_html/datapolis/public
4. Guardar
```

### 2.4 Configurar Variables de Entorno

**Crear archivo .env:**
```bash
# Copiar ejemplo
cp .env.example .env

# Editar con nano o File Manager
nano .env
```

**Contenido .env para producción:**
```env
APP_NAME=DATAPOLIS
APP_ENV=production
APP_KEY=
APP_DEBUG=false
APP_URL=https://tudominio.com

LOG_CHANNEL=daily
LOG_DEPRECATIONS_CHANNEL=null
LOG_LEVEL=error

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=datapolis_prod
DB_USERNAME=datapolis_user
DB_PASSWORD=tu_password_seguro

BROADCAST_DRIVER=log
CACHE_DRIVER=file
FILESYSTEM_DISK=local
QUEUE_CONNECTION=database
SESSION_DRIVER=database
SESSION_LIFETIME=120

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

MAIL_MAILER=smtp
MAIL_HOST=mail.tudominio.com
MAIL_PORT=587
MAIL_USERNAME=noreply@tudominio.com
MAIL_PASSWORD=tu_password_email
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@tudominio.com
MAIL_FROM_NAME="DATAPOLIS"

# Configuración Chile
APP_TIMEZONE=America/Santiago
APP_LOCALE=es

# PAE Configuration
PAE_DEFAULT_HORIZON=36
PAE_DEFAULT_DEPTH=4
PAE_CACHE_TTL=1800

# SII Integration (Ambiente)
SII_AMBIENTE=certificacion
# SII_AMBIENTE=produccion
```

### 2.5 Generar App Key

**Vía Terminal SSH:**
```bash
cd ~/public_html/datapolis
php artisan key:generate
```

**Si no hay SSH, usar script temporal:**
```php
<?php
// Crear archivo: generate_key.php en public/
require __DIR__.'/../vendor/autoload.php';
$app = require_once __DIR__.'/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->call('key:generate');
echo "Key generada exitosamente";
unlink(__FILE__); // Auto-eliminar
```

### 2.6 Ejecutar Migraciones

**Vía Terminal SSH:**
```bash
cd ~/public_html/datapolis
php artisan migrate --force
php artisan db:seed --force
```

**Si no hay SSH, usar script temporal:**
```php
<?php
// Crear archivo: run_migrations.php en public/
require __DIR__.'/../vendor/autoload.php';
$app = require_once __DIR__.'/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->call('migrate', ['--force' => true]);
$kernel->call('db:seed', ['--force' => true]);
echo "Migraciones ejecutadas";
unlink(__FILE__);
```

### 2.7 Configurar Permisos

```bash
# Permisos de carpetas
chmod -R 755 storage
chmod -R 755 bootstrap/cache

# Si es necesario (usuario web diferente)
chown -R www-data:www-data storage
chown -R www-data:www-data bootstrap/cache
```

### 2.8 Optimizar para Producción

```bash
# Cachear configuración
php artisan config:cache

# Cachear rutas
php artisan route:cache

# Cachear vistas
php artisan view:cache

# Optimizar autoload
composer install --optimize-autoloader --no-dev
```

---

## 3. CONFIGURAR CRON (SCHEDULER)

### 3.1 En cPanel

```
1. cPanel > Advanced > Cron Jobs
2. Common Settings: Once Per Minute (*****)
3. Command: cd /home/usuario/public_html/datapolis && php artisan schedule:run >> /dev/null 2>&1
4. Add New Cron Job
```

### 3.2 Jobs Programados

El scheduler ejecutará automáticamente:

| Job | Frecuencia | Descripción |
|-----|------------|-------------|
| FacturarAntenas | Día 1, 00:00 | Genera facturas mensuales |
| CalcularIntereses | Diario, 06:00 | Actualiza intereses mora |
| SincronizarUF | Diario, 08:00 | Obtiene valor UF del día |
| EvaluarCompliance | Semanal | Evaluación automática |
| LimpiarCache | Diario, 03:00 | Limpieza de cache |

---

## 4. CONFIGURAR SSL

### 4.1 Let's Encrypt (Gratuito)

```
1. cPanel > Security > SSL/TLS Status
2. Seleccionar dominio
3. Run AutoSSL
4. Esperar instalación (5-10 minutos)
```

### 4.2 Forzar HTTPS

**En .htaccess (public/):**
```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    
    # Forzar HTTPS
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
    
    # Forzar www (opcional)
    RewriteCond %{HTTP_HOST} !^www\. [NC]
    RewriteRule ^(.*)$ https://www.%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
    
    # Laravel routing
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [L]
</IfModule>
```

---

## 5. CONFIGURAR QUEUE WORKERS

### 5.1 Sin Supervisor (cPanel básico)

Usar cron cada minuto:
```bash
cd /home/usuario/public_html/datapolis && php artisan queue:work --stop-when-empty --max-time=55 >> /dev/null 2>&1
```

### 5.2 Con Supervisor (VPS/Dedicado)

**/etc/supervisor/conf.d/datapolis-worker.conf:**
```ini
[program:datapolis-worker]
process_name=%(program_name)s_%(process_num)02d
command=php /var/www/datapolis/artisan queue:work --sleep=3 --tries=3 --max-time=3600
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
user=www-data
numprocs=2
redirect_stderr=true
stdout_logfile=/var/www/datapolis/storage/logs/worker.log
stopwaitsecs=3600
```

---

## 6. CONFIGURAR MAIL

### 6.1 Usando cPanel Email

```env
MAIL_MAILER=smtp
MAIL_HOST=mail.tudominio.com
MAIL_PORT=587
MAIL_USERNAME=noreply@tudominio.com
MAIL_PASSWORD=password_email
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@tudominio.com
MAIL_FROM_NAME="DATAPOLIS"
```

### 6.2 Usando SendGrid/Mailgun

```env
# SendGrid
MAIL_MAILER=smtp
MAIL_HOST=smtp.sendgrid.net
MAIL_PORT=587
MAIL_USERNAME=apikey
MAIL_PASSWORD=SG.xxxxxxxxxxxx
MAIL_ENCRYPTION=tls
```

---

## 7. MONITOREO Y LOGS

### 7.1 Logs de Laravel

```
storage/logs/laravel.log
```

**Ver últimas líneas:**
```bash
tail -100 storage/logs/laravel.log
```

### 7.2 Configurar Log Rotation

Laravel ya usa `daily` por defecto. Configurar retención:

**config/logging.php:**
```php
'daily' => [
    'driver' => 'daily',
    'path' => storage_path('logs/laravel.log'),
    'level' => 'error',
    'days' => 14, // Retener 14 días
],
```

### 7.3 Monitoreo de Errores (Opcional)

Integrar Sentry, Bugsnag o similar:
```bash
composer require sentry/sentry-laravel
```

---

## 8. BACKUP

### 8.1 Backup Automático cPanel

```
1. cPanel > Files > Backup Wizard
2. Configurar backup completo semanal
3. Almacenar en ubicación remota (S3, Google Drive)
```

### 8.2 Backup de Base de Datos

**Cron diario:**
```bash
mysqldump -u datapolis_user -p'password' datapolis_prod > /home/usuario/backups/db_$(date +%Y%m%d).sql
```

### 8.3 Script de Backup Completo

```bash
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d)
BACKUP_DIR="/home/usuario/backups"

# Backup DB
mysqldump -u datapolis_user -p'password' datapolis_prod > $BACKUP_DIR/db_$DATE.sql

# Backup archivos
tar -czf $BACKUP_DIR/files_$DATE.tar.gz /home/usuario/public_html/datapolis/storage

# Eliminar backups > 7 días
find $BACKUP_DIR -type f -mtime +7 -delete

echo "Backup completado: $DATE"
```

---

## 9. TROUBLESHOOTING

### 9.1 Error 500

1. Verificar permisos de storage y bootstrap/cache
2. Revisar storage/logs/laravel.log
3. Verificar .env existe y tiene configuración correcta
4. Ejecutar `php artisan config:clear`

### 9.2 Error de Base de Datos

1. Verificar credenciales en .env
2. Verificar que el usuario tiene permisos en la BD
3. Verificar que las migraciones se ejecutaron

### 9.3 Composer Memory Limit

```bash
php -d memory_limit=-1 /usr/local/bin/composer install
```

### 9.4 Página en Blanco

1. Activar display_errors temporalmente
2. Verificar PHP version
3. Verificar extensiones PHP requeridas

---

## 10. CHECKLIST DE DEPLOYMENT

### Pre-Deploy
- [ ] Backup de la versión anterior (si existe)
- [ ] Base de datos creada
- [ ] Dominio configurado
- [ ] SSL activado

### Deploy
- [ ] Archivos subidos
- [ ] .env configurado
- [ ] App key generada
- [ ] Migraciones ejecutadas
- [ ] Seeders ejecutados
- [ ] Permisos configurados
- [ ] Cache generada

### Post-Deploy
- [ ] Login funcional
- [ ] API responde
- [ ] Cron configurado
- [ ] Email funcionando
- [ ] Backup automático activo

### Verificación Final
- [ ] Dashboard carga correctamente
- [ ] CRUD de copropiedades funciona
- [ ] Facturación de antenas funciona
- [ ] Prorrateo de gastos funciona
- [ ] Reportes se generan

---

## 11. DATOS DE ACCESO INICIAL

**Usuario Administrador:**
```
Email: admin@datapolis.cl
Password: DataPolis2024!
```

**IMPORTANTE:** Cambiar contraseña inmediatamente después del primer login.

---

## 12. SOPORTE

Para soporte técnico:
- Documentación: /docs/
- API Reference: /api/documentation
- Contacto: soporte@datapolis.cl

---

*DATAPOLIS v3.0 - Guía de Instalación cPanel*
*Versión 3.0.0*
*Febrero 2026*
