# MASTER PLAN GENERAL
## Ecosistema DATAPOLIS v3.0 - ÁGORA - Sistema Multi-Agente

---

## 1. ARQUITECTURA DE CAPAS

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           CAPA DE PRESENTACIÓN                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐ │
│  │  Web App    │  │  Mobile     │  │  Dashboard  │  │  Landing ÁGORA      │ │
│  │  (Next.js)  │  │  (React     │  │  Ejecutivo  │  │  (Marketing)        │ │
│  │             │  │   Native)   │  │             │  │                     │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              CAPA API                                        │
│  ┌─────────────────────────────────────────────────────────────────────────┐│
│  │                         API REST (Laravel 11)                            ││
│  │  /api/v1/auth  /api/v1/copropiedades  /api/v1/antenas  /api/v1/pae      ││
│  │  /api/v1/gastos  /api/v1/contabilidad  /api/v1/compliance  ...          ││
│  └─────────────────────────────────────────────────────────────────────────┘│
│  ┌─────────────────────────────────────────────────────────────────────────┐│
│  │                         API GraphQL (Futuro)                             ││
│  └─────────────────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         CAPA DE LÓGICA DE NEGOCIO                           │
│  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌─────────────────┐  │
│  │ Contabilidad  │ │   Antenas     │ │  Gastos       │ │  Morosidad      │  │
│  │   Service     │ │   Service     │ │  Service      │ │  Service        │  │
│  └───────────────┘ └───────────────┘ └───────────────┘ └─────────────────┘  │
│  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌─────────────────┐  │
│  │ Compliance    │ │ Certificados  │ │  PAE          │ │  Reportes       │  │
│  │   Service     │ │   Service     │ │  Service      │ │  Service        │  │
│  └───────────────┘ └───────────────┘ └───────────────┘ └─────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CAPA PAE (PRECESSION ANALYTICS)                       │
│  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌─────────────────┐  │
│  │ Precession    │ │ Precession    │ │ Precession    │ │ Precession      │  │
│  │ Graph Engine  │ │ Scoring       │ │ ML Connector  │ │ Alert Engine    │  │
│  │ (996 líneas)  │ │ Engine (733)  │ │ (616 líneas)  │ │ (721 líneas)    │  │
│  └───────────────┘ └───────────────┘ └───────────────┘ └─────────────────┘  │
│                            │                                                 │
│                            ▼                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐│
│  │                    Precession Sync Service (688 líneas)                  ││
│  │                    Event Bus ←→ ÁGORA Integration                        ││
│  └─────────────────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      CAPA SISTEMA MULTI-AGENTE v2.0                          │
│  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌─────────────────┐  │
│  │ Agente        │ │ Agente        │ │ Agente        │ │ Agente          │  │
│  │ Compliance    │ │ Financiero    │ │ Territorial   │ │ Predictivo      │  │
│  └───────────────┘ └───────────────┘ └───────────────┘ └─────────────────┘  │
│  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌─────────────────┐  │
│  │ Agente        │ │ Agente        │ │ Agente        │ │ RLM Engine      │  │
│  │ Cobranza      │ │ Operaciones   │ │ Comunicación  │ │ (Ollama+Chroma) │  │
│  └───────────────┘ └───────────────┘ └───────────────┘ └─────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                             CAPA ÁGORA v4.0                                  │
│  ┌─────────────────────────────────────────────────────────────────────────┐│
│  │                    Inteligencia Territorial                              ││
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐    ││
│  │  │ Geo Engine  │ │ Analytics   │ │ Predicción  │ │ Visualización   │    ││
│  │  │             │ │ Territorial │ │ Urbana      │ │ Mapas           │    ││
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────────┘    ││
│  └─────────────────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            CAPA DE DATOS                                     │
│  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌─────────────────┐  │
│  │ MySQL/        │ │ Redis         │ │ ChromaDB      │ │ Elasticsearch   │  │
│  │ PostgreSQL    │ │ (Cache)       │ │ (Vectores)    │ │ (Búsqueda)      │  │
│  │ (60+ tablas)  │ │               │ │               │ │                 │  │
│  └───────────────┘ └───────────────┘ └───────────────┘ └─────────────────┘  │
│  ┌─────────────────────────────────────────────────────────────────────────┐│
│  │                         File Storage (S3/Local)                          ││
│  │                         Documentos, PDFs, Imágenes                       ││
│  └─────────────────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      CAPA DE INTEGRACIONES EXTERNAS                          │
│  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌─────────────────┐  │
│  │ SII           │ │ Bancos        │ │ Operadores    │ │ APIs            │  │
│  │ (DTE, DJ)     │ │ (Pagos)       │ │ Telecom       │ │ Geográficas     │  │
│  └───────────────┘ └───────────────┘ └───────────────┘ └─────────────────┘  │
│  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌─────────────────┐  │
│  │ Email         │ │ SMS           │ │ ChileCompra   │ │ UF/Indicadores  │  │
│  │ (SMTP)        │ │ (Twilio)      │ │               │ │ (CMF/SII)       │  │
│  └───────────────┘ └───────────────┘ └───────────────┘ └─────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. FLUJOS CLAVE ENTRE MÓDULOS

### 2.1 Flujo de Ingreso por Antena (End-to-End)

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ FLUJO: INGRESO POR ANTENA - DESDE CONTRATO HASTA DECLARACIÓN JURADA         │
└──────────────────────────────────────────────────────────────────────────────┘

[1] CONTRATO ANTENA
    │
    │ Job: FacturarAntenasMensual (día 1 cada mes)
    ▼
[2] FACTURA MENSUAL
    │
    ├──────────────────────────────────────────────────────┐
    │                                                      │
    ▼                                                      ▼
[3] CONTABILIZACIÓN                              [4] DISTRIBUCIÓN INGRESOS
    │                                                      │
    │ Asiento automático:                                  ├──► Fondo Común
    │ D: Banco 1102                                        │
    │ H: Ingreso 4101                                      ├──► Fondo Reserva
    │ H: IVA Débito 2103                                   │    (movimiento + saldo)
    │                                                      │
    ▼                                                      └──► Propietarios
[5] LIBRO MAYOR                                                 (por alícuota)
    │                                                           │
    ▼                                                           ▼
[6] BALANCE/EERR                                    [7] CERTIFICADO PARTICIPACIÓN
    │                                                           │
    ▼                                                           ▼
[8] SII - ENVÍO DTE ◄────────────────────────────────── [9] DJ ANUAL
    │
    ▼
[10] TRACK ESTADO → ACEPTADA/RECHAZADA
```

### 2.2 Flujo de Gastos Comunes (End-to-End)

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ FLUJO: GASTOS COMUNES - DESDE REGISTRO HASTA COBRO                           │
└──────────────────────────────────────────────────────────────────────────────┘

[1] REGISTRO GASTO
    │
    │ (Factura proveedor, consumo, etc.)
    ▼
[2] CATEGORIZACIÓN
    │
    │ (Ordinario/Extraordinario + Cuenta Contable)
    ▼
[3] APROBACIÓN
    │
    │ (Workflow según monto/tipo)
    ▼
[4] PRORRATEO MENSUAL
    │
    │ Total Gastos × Alícuota = Cuota Unidad
    │ + Fondo Reserva (≥5%)
    │ + Intereses Mora (si aplica)
    │
    ▼
[5] COBRO POR UNIDAD
    │
    ├──► Notificación a copropietario
    │
    ▼
[6] PAGO
    │
    ├──► Contabilización automática
    │    D: Banco
    │    H: CxC Copropietarios
    │
    └──► Actualización morosidad
         │
         ▼
[7] SI MORA > 0 ────────────────────────────┐
                                            │
                                            ▼
                                   [8] GESTIÓN COBRANZA
                                            │
                                            ├──► Llamada/Email/Carta
                                            │
                                            └──► Convenio de Pago
```

### 2.3 Flujo PAE (Análisis Precesional)

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ FLUJO: ANÁLISIS PAE - DESDE DATOS HASTA ALERTAS                              │
└──────────────────────────────────────────────────────────────────────────────┘

[1] DATOS DE COPROPIEDAD
    │
    │ (Unidades, Contratos, Morosidad, Compliance, Avalúos)
    ▼
[2] PRECESSION GRAPH ENGINE
    │
    │ Construye grafo de entidades y relaciones
    │ 12+ nodos, 15+ aristas
    ▼
[3] ANÁLISIS BFS
    │
    │ Recorrido de efectos precesionales
    │ Profundidad: 4 niveles
    │ Horizonte: 36 meses
    ▼
[4] PRECESSION SCORING ENGINE
    │
    │ Calcula:
    │ - Score Precesión (0-100)
    │ - Score Riesgo (0-1)
    │ - Score Oportunidad (0-1)
    │ - Confianza (0-1)
    │ - Valor Precesional UF
    ▼
[5] PRECESSION ML CONNECTOR
    │
    │ (Opcional) Predicciones ML
    │ Fallback: Scoring heurístico
    ▼
[6] PRECESSION ALERT ENGINE
    │
    │ Genera alertas por:
    │ - Contratos por vencer
    │ - Morosidad crítica
    │ - Incumplimiento normativo
    │ - Oportunidades detectadas
    ▼
[7] PRECESSION SYNC SERVICE
    │
    │ Event Bus → ÁGORA
    │ JSON-RPC para sincronización
    ▼
[8] DASHBOARD PAE
    │
    │ Visualización de scores y alertas
    │ Recomendaciones accionables
    ▼
[9] AGENTES MULTI-AGENTE
    │
    │ Toman decisiones basadas en análisis
    │ Ejecutan acciones automatizadas
```

---

## 3. CASO DE USO EXTREMO A EXTREMO

### Municipio de Pudahuel + Copropiedades del Sector

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ CASO: MUNICIPIO PUDAHUEL + 50 COPROPIEDADES                                  │
└──────────────────────────────────────────────────────────────────────────────┘

ACTORES:
- Municipio de Pudahuel (DOM, Rentas, Planificación)
- 50 Copropiedades del sector
- 3 Operadores de Telecomunicaciones
- 5,000 Copropietarios

ESCENARIO:

[1] MUNICIPIO - ÁGORA
    │
    │ Visualiza dashboard territorial:
    │ - Mapa de copropiedades
    │ - Índices de cumplimiento normativo
    │ - Concentración de antenas
    │ - Morosidad por sector
    │
    ▼
[2] FISCALIZACIÓN AUTOMÁTICA
    │
    │ ÁGORA detecta:
    │ - 5 copropiedades sin asamblea anual
    │ - 3 contratos de antenas sin acta
    │ - 2 edificios con fondo reserva < 5%
    │
    │ Genera alertas automáticas
    ▼
[3] NOTIFICACIÓN A COPROPIEDADES
    │
    │ Vía DATAPOLIS, cada copropiedad recibe:
    │ - Alerta de incumplimiento
    │ - Plazo de regularización
    │ - Guía de acciones correctivas
    │
    ▼
[4] REGULARIZACIÓN - COPROPIEDAD "ALTOS DE PUDAHUEL"
    │
    │ a) Convocan asamblea extraordinaria
    │ b) Aprueban contrato de antena con Entel
    │ c) Registran acta en sistema
    │ d) Ajustan fondo reserva a 6%
    │
    ▼
[5] FACTURACIÓN ANTENA
    │
    │ - Genera factura mensual UF 25
    │ - Envía a SII (aceptada)
    │ - Contabiliza automáticamente
    │ - Distribuye: 70% fondo común, 20% fondo reserva, 10% propietarios
    │
    ▼
[6] CIERRE CONTABLE MENSUAL
    │
    │ - Balance generado automáticamente
    │ - Estado de resultados
    │ - Libro mayor exportable
    │
    ▼
[7] EVALUACIÓN COMPLIANCE
    │
    │ - Score sube de 45 a 92
    │ - Sale de lista de incumplimiento municipal
    │ - Certificado de cumplimiento disponible
    │
    ▼
[8] PAE - ANÁLISIS PRECESIONAL
    │
    │ Detecta oportunidades:
    │ - Potencial para 2 antenas adicionales
    │ - Ahorro posible por renegociación servicios
    │ - Riesgo de morosidad en torre B
    │
    ▼
[9] AGENTE MULTI-AGENTE ACTÚA
    │
    │ - Envía propuesta a WOM para segunda antena
    │ - Programa campaña de cobranza preventiva torre B
    │ - Notifica al comité sobre oportunidades
    │
    ▼
[10] MUNICIPIO - CONSOLIDACIÓN
     │
     │ Informe trimestral:
     │ - Cumplimiento normativo sector: 89%
     │ - Ingresos fiscales proyectados por antenas
     │ - Índice de desarrollo urbano
     │
     └──► Planificación urbana informada
```

---

## 4. ESCALABILIDAD

### 4.1 Escalamiento Horizontal

```
┌─────────────────────────────────────────────────────────────────┐
│                    ARQUITECTURA ESCALABLE                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Load Balancer (Nginx/HAProxy)                                  │
│         │                                                        │
│         ├──► App Server 1 (Laravel)                             │
│         ├──► App Server 2 (Laravel)                             │
│         └──► App Server N (Laravel)                             │
│                    │                                             │
│                    ▼                                             │
│         Redis Cluster (Sessions + Cache)                        │
│                    │                                             │
│                    ▼                                             │
│         MySQL/PostgreSQL (Read Replicas)                        │
│         ├──► Primary (Write)                                    │
│         ├──► Replica 1 (Read)                                   │
│         └──► Replica 2 (Read)                                   │
│                                                                  │
│  Queue Workers (Horizon)                                        │
│         ├──► Worker 1 (Facturación)                             │
│         ├──► Worker 2 (Notificaciones)                          │
│         └──► Worker 3 (PAE Analysis)                            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 Métricas de Capacidad

| Escenario | Tenants | Copropiedades | Unidades | RPS | Infra Requerida |
|-----------|---------|---------------|----------|-----|-----------------|
| MVP | 5 | 50 | 5,000 | 10 | 1 VPS |
| Growth | 50 | 500 | 50,000 | 100 | 2 App + 1 DB |
| Scale | 200 | 2,000 | 200,000 | 500 | 4 App + DB Cluster |
| Enterprise | 500 | 10,000 | 1,000,000 | 2,000 | K8s + DB Cluster |

---

## 5. GOBIERNO DE DATOS

### 5.1 Clasificación de Datos

| Nivel | Tipo | Ejemplos | Retención | Acceso |
|-------|------|----------|-----------|--------|
| Crítico | PII | RUT, Direcciones | 7 años | Encriptado |
| Sensible | Financiero | Saldos, Deudas | 7 años | Roles específicos |
| Operacional | Transacciones | Pagos, Facturas | 7 años | Usuarios autorizados |
| Analítico | Métricas | Scores, KPIs | 2 años | Reportes |
| Temporal | Cache | Sesiones | 24 horas | Sistema |

### 5.2 Flujo de Datos

```
Ingreso → Validación → Clasificación → Almacenamiento → Acceso → Auditoría
                                              │
                                              ▼
                                    Encriptación at-rest (AES-256)
                                    Encriptación in-transit (TLS 1.3)
```

### 5.3 Cumplimiento

- **Ley 19.628**: Protección de Datos Personales Chile
- **GDPR-like**: Preparación para expansión Latam
- **SOX/PCAOB**: Auditoría financiera
- **ISO 27001**: Seguridad de información (roadmap)

---

## 6. SEGURIDAD

### 6.1 Capas de Seguridad

```
[1] PERÍMETRO
    ├── WAF (Web Application Firewall)
    ├── DDoS Protection
    └── Rate Limiting

[2] RED
    ├── VPC / Subnets privadas
    ├── Security Groups
    └── TLS 1.3

[3] APLICACIÓN
    ├── Autenticación (Sanctum)
    ├── Autorización (RBAC)
    ├── CSRF Protection
    ├── XSS Prevention
    └── SQL Injection Prevention

[4] DATOS
    ├── Encriptación AES-256
    ├── Hashing bcrypt (passwords)
    └── Backup encriptado

[5] AUDITORÍA
    ├── Logs centralizados
    ├── Monitoreo de accesos
    └── Alertas de seguridad
```

### 6.2 Checklist de Seguridad

- [x] HTTPS obligatorio
- [x] Tokens con expiración
- [x] Validación de inputs
- [x] Prepared statements
- [x] CORS configurado
- [x] Headers de seguridad
- [x] Auditoría de acciones
- [ ] MFA (roadmap)
- [ ] Pentesting (pre-producción)

---

## 7. ROADMAP TÉCNICO

### Q1 2026 (Actual)
- [x] Desarrollo 23 módulos
- [x] Arquitectura PAE nativa
- [x] Migraciones y seeders
- [ ] Deploy producción cPanel
- [ ] 5 pilotos iniciales

### Q2 2026
- [ ] App móvil React Native
- [ ] Integración SII producción
- [ ] MFA para usuarios
- [ ] 50 copropiedades

### Q3 2026
- [ ] API GraphQL
- [ ] Dashboard BI avanzado
- [ ] Integración bancaria
- [ ] 150 copropiedades

### Q4 2026
- [ ] Expansión Perú
- [ ] ISO 27001 inicio
- [ ] 300 copropiedades
- [ ] Ronda Seed/Pre-A

---

*Master Plan DATAPOLIS v3.0 - ÁGORA*
*Versión 3.0.0 Final*
*Febrero 2026*
