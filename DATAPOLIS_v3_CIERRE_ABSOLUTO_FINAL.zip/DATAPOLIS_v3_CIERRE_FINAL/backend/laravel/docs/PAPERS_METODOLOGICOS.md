# DATAPOLIS v3.0 - PAPERS METODOLÓGICOS
## 22 Módulos del Ecosistema DATAPOLIS-ÁGORA

---

# PAPER M02: USUARIOS Y AUTENTICACIÓN

## 1. Objetivo y Alcance
Gestionar identidad, acceso y permisos de usuarios en un entorno multi-tenant, garantizando seguridad, trazabilidad y cumplimiento normativo PCAOB/SOX para auditoría.

## 2. Marco Conceptual
- **Autenticación**: Verificación de identidad mediante credenciales + tokens
- **Autorización**: Control granular basado en roles y permisos (RBAC)
- **Multi-tenancy**: Aislamiento de datos por organización

## 3. Hipótesis y Riesgos
| Riesgo | Probabilidad | Impacto | Mitigación |
|--------|--------------|---------|------------|
| Acceso no autorizado | Media | Crítico | MFA, tokens con expiración, auditoría |
| Escalamiento de privilegios | Baja | Crítico | Validación server-side, least privilege |
| Token comprometido | Media | Alto | Revocación inmediata, refresh tokens |

## 4. Soluciones y KPIs
- **Sanctum**: Tokens seguros con expiración configurable
- **Roles predefinidos**: 5 roles base, extensibles por tenant
- **Auditoría completa**: Registro de todas las acciones

**KPIs:**
- Tiempo de autenticación < 200ms
- Intentos fallidos antes de bloqueo: 5
- Retención de logs: 2 años

## 5. Diagrama de Flujo
```
Usuario → Login → Validación → Token → Request con Bearer → Middleware Auth → Verificación Permisos → Respuesta
                                                                    ↓
                                                              Audit Log
```

## 6. Referencias
- Laravel Sanctum Documentation
- OWASP Authentication Guidelines
- SOX Section 404

---

# PAPER M03: COPROPIEDADES (CORE)

## 1. Objetivo y Alcance
Modelar la estructura jerárquica de copropiedades (edificios/condominios), sus unidades (departamentos, locales, estacionamientos), copropietarios y espacios comunes según la Ley 21.442 de Copropiedad Inmobiliaria.

## 2. Marco Conceptual
- **Copropiedad**: Entidad jurídica que agrupa bienes comunes y privativos
- **Unidad**: Bien privativo con alícuota de prorrateo
- **Alícuota**: Porcentaje de participación en gastos y decisiones
- **Espacios Comunes**: Bienes de dominio común (Art. 5 Ley 21.442)

## 3. Hipótesis
- Las alícuotas suman 100% por copropiedad
- Cada unidad tiene al menos un copropietario
- Los espacios comunes pueden generar ingresos (arriendos, antenas)

## 4. Riesgos
| Riesgo | Mitigación |
|--------|------------|
| Alícuotas no cuadran | Validación al crear/editar unidades |
| Datos incompletos | Campos obligatorios con validación |
| Duplicidad de RUT | Índice único por tenant |

## 5. KPIs
- Tiempo de carga dashboard < 1s
- Precisión alícuotas: 6 decimales
- Cobertura de datos: >95%

## 6. Flujo de Datos
```
Tenant → Copropiedad → Unidades → Copropietarios
                    ↓
              Espacios Comunes → Contratos Antenas
                              → Reservas
```

---

# PAPER M04: ANTENAS Y TELECOMUNICACIONES

## 1. Objetivo y Alcance
Gestionar contratos de uso de bienes comunes para instalación de antenas de telecomunicaciones, incluyendo tratamiento tributario (IVA, Ley de Rentas), distribución de ingresos según Ley 21.442, y generación automática de facturación.

## 2. Marco Conceptual
- **Contrato de antena**: Acuerdo entre copropiedad y operador de telecomunicaciones
- **Canon**: Pago periódico por uso de espacio común
- **IVA afecto**: Aplicación de 19% sobre servicios gravados
- **Distribución**: Asignación de ingresos a fondo común, fondo reserva o copropietarios

## 3. Marco Legal
- **Ley 21.442 Art. 17**: Quórum para contratos sobre bienes comunes
- **DL 825**: Impuesto al Valor Agregado
- **Ley de Impuesto a la Renta**: Tributación de rentas de copropiedades
- **Circular SII**: Tratamiento de ingresos de comunidades

## 4. Hipótesis
- Todo contrato requiere acta de asamblea con quórum calificado
- Los contratos afectos a IVA requieren inicio de actividades
- La distribución se realiza proporcionalmente a las alícuotas

## 5. Riesgos y Mitigación
| Riesgo | Probabilidad | Impacto | Mitigación |
|--------|--------------|---------|------------|
| Contrato sin acta válida | Media | Alto | Validación obligatoria de acta |
| Facturación sin IVA cuando corresponde | Baja | Crítico | Configuración por contrato + alertas |
| Incumplimiento tributario | Media | Crítico | Integración SII automática |
| Distribución incorrecta | Baja | Alto | Validación de suma = 100% |

## 6. Soluciones
- **Facturación automática**: Generación mensual basada en configuración
- **Cálculo UF**: Valor del día para conversión precisa
- **Track SII**: Seguimiento de estado de DTEs
- **Contabilización automática**: Asiento al emitir factura

## 7. KPIs
- Tiempo de facturación: < 5 segundos
- Tasa de aceptación SII: > 99%
- Precisión de cálculos: 100%
- Distribución a fondo reserva: ≥ 5% (legal)

## 8. Flujo
```
Contrato Vigente → Período Mensual → Generar Factura → Calcular Montos
                                           ↓
                    ┌──────────────────────┼──────────────────────┐
                    ↓                      ↓                      ↓
            Contabilizar             Enviar SII            Distribuir Ingresos
                    ↓                      ↓                      ↓
            Asiento Contable      Track + Respuesta      Fondo Común/Reserva/Propietarios
```

---

# PAPER M05: GASTOS COMUNES

## 1. Objetivo y Alcance
Gestionar el ciclo completo de gastos comunes: registro, categorización, aprobación, prorrateo por alícuotas, generación de cobros por unidad y control de vencimientos.

## 2. Marco Conceptual
- **Gasto ordinario**: Recurrente para operación normal
- **Gasto extraordinario**: Eventual, requiere aprobación especial
- **Prorrateo**: Distribución proporcional según alícuotas
- **Fondo de reserva**: Mínimo 5% del gasto común (Art. 8 Ley 21.442)

## 3. Flujo de Prorrateo
```
Gastos del Período (aprobados) → Sumar por Tipo → Calcular por Unidad
                                                        ↓
                                            Alícuota × Total = Cuota Base
                                                        ↓
                                            + Fondo Reserva (5%+)
                                            + Intereses Mora (si aplica)
                                                        ↓
                                            Cobro por Unidad
```

## 4. Riesgos
| Riesgo | Mitigación |
|--------|------------|
| Prorrateo incorrecto | Validación alícuotas = 100% |
| Gastos no aprobados incluidos | Flujo de aprobación obligatorio |
| Fondo reserva bajo mínimo | Alerta automática < 5% |

## 5. KPIs
- Error de cuadre: $0
- Tiempo de prorrateo: < 10 segundos/100 unidades
- Cumplimiento fondo reserva: 100%

---

# PAPER M06: MOROSIDAD Y COBRANZA

## 1. Objetivo y Alcance
Calcular y gestionar deudas de copropietarios, categorizar riesgo, registrar gestiones de cobranza, generar convenios de pago y calcular intereses de mora.

## 2. Marco Conceptual
- **Mora**: Atraso en pago respecto a fecha de vencimiento
- **Interés de mora**: Recargo por atraso (configurable, ej. 1.5% mensual)
- **Categoría de riesgo**: Clasificación según meses de atraso
- **Convenio**: Acuerdo de pago fraccionado

## 3. Categorización de Riesgo
| Meses Mora | Categoría | Acciones |
|------------|-----------|----------|
| 0 | Bajo | Normal |
| 1-2 | Medio | Aviso + llamada |
| 3-5 | Alto | Carta certificada + gestión intensiva |
| 6+ | Crítico | Cobranza judicial |

## 4. Riesgos
| Riesgo | Mitigación |
|--------|------------|
| Cálculo incorrecto de intereses | Fórmula estandarizada + auditoría |
| Convenios incumplidos | Seguimiento automático + reversión |
| Datos desactualizados | Recálculo diario de morosidad |

## 5. KPIs
- Días promedio de cobro (DSO)
- % morosidad > 90 días
- Tasa de recuperación de convenios
- Efectividad de gestiones

---

# PAPER M07: PROVEEDORES Y CONTRATOS

## 1. Objetivo y Alcance
Gestionar base de proveedores, contratos de servicio, evaluación de desempeño y control de vencimientos.

## 2. Funcionalidades
- Registro de proveedores con datos bancarios
- Contratos con renovación automática
- Calificación de proveedores
- Alertas de vencimiento

## 3. Riesgos
| Riesgo | Mitigación |
|--------|------------|
| Proveedor sin documentación | Campos obligatorios |
| Contrato vencido operando | Alertas automáticas |
| Pagos a proveedor incorrecto | Validación de datos bancarios |

## 4. KPIs
- Contratos vigentes vs vencidos
- Calificación promedio proveedores
- Tiempo de renovación

---

# PAPER M08: CONTABILIDAD POR COPROPIEDAD

## 1. Objetivo y Alcance
Implementar contabilidad completa independiente por cada copropiedad, con plan de cuentas configurable, asientos automáticos desde documentos fuente, libros contables y estados financieros según normativa chilena.

## 2. Marco Conceptual
- **Plan de cuentas**: Estructura jerárquica de cuentas contables
- **Asiento contable**: Registro de operación con debe = haber
- **Libro diario**: Registro cronológico de asientos
- **Libro mayor**: Saldo por cuenta
- **Balance**: Ecuación patrimonial (A = P + PN)
- **Estado de resultados**: Ingresos - Gastos = Resultado

## 3. Estructura del Plan de Cuentas
```
1. ACTIVOS (deudora)
   11. Activo Corriente
       1101. Caja
       1102. Banco Cuenta Corriente
       1104. CxC Copropietarios
       1105. CxC Antenas
       1106. IVA Crédito Fiscal
       1107. Fondo de Reserva

2. PASIVOS (acreedora)
   21. Pasivo Corriente
       2101. CxP Proveedores
       2103. IVA Débito Fiscal

3. PATRIMONIO (acreedora)
   31. Capital y Reservas
       3101. Fondo de Reserva Ley 21.442
       3102. Resultados Acumulados

4. INGRESOS (acreedora)
   41. Ingresos Operacionales
       4101. Ingresos por Antenas
       4102. Arriendo Espacios Comunes

5. GASTOS (deudora)
   51. Gastos Ordinarios
       5101. Remuneraciones
       5102. Consumo Eléctrico
       ...
```

## 4. Contabilización Automática

| Documento Fuente | Asiento Generado |
|------------------|------------------|
| Factura Antena | D: Banco / H: Ingreso Antenas + IVA Débito |
| Pago Gasto Común | D: Banco / H: CxC Copropietarios |
| Factura Proveedor | D: Gasto + IVA Crédito / H: CxP Proveedores |
| Pago Proveedor | D: CxP Proveedores / H: Banco |

## 5. Riesgos
| Riesgo | Mitigación |
|--------|------------|
| Asiento desbalanceado | Validación debe = haber |
| Período cerrado modificado | Control de estado de período |
| Cuenta incorrecta | Configuración por categoría |

## 6. KPIs
- Error de cuadre: $0
- Días de cierre mensual
- Cobertura de contabilización automática

---

# PAPER M09: CERTIFICADOS TRIBUTARIOS

## 1. Objetivo y Alcance
Emitir certificados tributarios verificables para comunidades y copropietarios, cumpliendo requisitos del SII para declaraciones juradas y comprobación de cumplimiento.

## 2. Tipos de Certificados
1. **Cumplimiento Comunidad**: Estado tributario de la copropiedad
2. **Participación en Rentas**: Para DJ de copropietarios (ingresos por antenas)
3. **Gastos Comunes**: Comprobante de pagos realizados
4. **No Deuda**: Certificación de estar al día

## 3. Elementos del Certificado
- Folio único secuencial
- Código de verificación (32 caracteres)
- QR con enlace de verificación
- Fecha de emisión y vigencia
- Datos del emisor y destinatario
- Montos certificados
- Firma digital (preparado)

## 4. Verificación
```
Código → API Pública → Validar Existencia → Validar Vigencia → Validar Estado → Respuesta
```

## 5. KPIs
- Tiempo de emisión: < 3 segundos
- Tasa de verificación exitosa
- Certificados emitidos/mes

---

# PAPER M10: DECLARACIONES JURADAS SII

## 1. Objetivo y Alcance
Generar y gestionar declaraciones juradas requeridas por el SII para copropiedades con actividades tributarias, incluyendo DJ1887 (información de rentas) y otras aplicables.

## 2. Declaraciones Aplicables
| DJ | Descripción | Plazo | Datos Requeridos |
|----|-------------|-------|------------------|
| DJ1887 | Rentas de copropiedades | Marzo | Ingresos, participaciones |
| DJ1835 | Retenciones honorarios | Marzo | Pagos a terceros |

## 3. Flujo de Generación
```
Datos Contables → Validar Completitud → Generar Archivo TXT → Validar Formato SII → Enviar → Tracking
```

## 4. Riesgos
| Riesgo | Mitigación |
|--------|------------|
| Datos incompletos | Validación previa + alertas |
| Formato incorrecto | Parser según especificación SII |
| Rechazo SII | Manejo de errores + corrección |

---

# PAPER M11: FONDO DE RESERVA

## 1. Objetivo y Alcance
Gestionar el fondo de reserva según Art. 8 de la Ley 21.442, garantizando el aporte mínimo del 5%, registrando movimientos y controlando usos autorizados.

## 2. Marco Legal
> "El fondo común de reserva estará constituido por un porcentaje de recargo sobre los gastos comunes, que no será inferior al cinco por ciento..." - Art. 8 Ley 21.442

## 3. Tipos de Movimientos
| Tipo | Origen | Requiere Acta |
|------|--------|---------------|
| Aporte mensual | Prorrateo gastos | No |
| Aporte extraordinario | Asamblea | Sí |
| Ingreso antena | Distribución | No |
| Uso autorizado | Asamblea | Sí |
| Intereses | Rendimiento | No |

## 4. Riesgos
| Riesgo | Mitigación |
|--------|------------|
| Aporte < 5% | Validación en configuración |
| Uso sin autorización | Requiere acta obligatoria |
| Saldo negativo | Alerta y bloqueo |

## 5. KPIs
- Cumplimiento mínimo legal: 100%
- Saldo promedio vs meta
- Usos autorizados vs ejecutados

---

# PAPER M12: ASAMBLEAS Y ACTAS

## 1. Objetivo y Alcance
Gestionar el ciclo de asambleas de copropietarios según Ley 21.442: convocatoria, quórum, desarrollo, votaciones y registro de actas.

## 2. Tipos de Asamblea
| Tipo | Frecuencia | Quórum Mínimo | Materias |
|------|------------|---------------|----------|
| Ordinaria | Anual | Mayoría simple | Presupuesto, cuentas, comité |
| Extraordinaria | Cuando se requiera | Según materia | Contratos, modificaciones |

## 3. Quórum por Materia (Ley 21.442)
| Materia | Quórum Requerido |
|---------|------------------|
| Modificación reglamento | 75% |
| Contratos bienes comunes | 66% |
| Uso fondo reserva | 66% |
| Materias ordinarias | Mayoría simple |

## 4. Flujo
```
Convocatoria → Primera Citación → Segunda Citación (si no hay quórum) → Asamblea → Votaciones → Acta → Aprobación → Registro
```

---

# PAPER M13: COMPLIANCE Y NORMATIVA

## 1. Objetivo y Alcance
Evaluar automáticamente el cumplimiento normativo de copropiedades respecto a Ley 21.442, DS 7/2025, normativa SII y buenas prácticas, generando scores, brechas y planes de acción.

## 2. Dimensiones de Evaluación
1. **Ley 21.442**: Fondo reserva, asambleas, actas, quórum
2. **DS 7/2025**: Reglamento, libros, transparencia
3. **Tributario**: Inicio actividades, facturación, declaraciones
4. **Contable**: Períodos, asientos, estados financieros
5. **Transparencia**: Comunicación, acceso a información

## 3. Metodología de Scoring
```
Score Dimensión = 100 - Σ(Penalidad por Brecha)

Score Global = Promedio Ponderado de Dimensiones
```

## 4. Severidad de Brechas
| Severidad | Penalidad | Plazo Corrección |
|-----------|-----------|------------------|
| Crítica | 20-30 pts | 7 días |
| Alta | 10-20 pts | 15 días |
| Media | 5-10 pts | 30 días |
| Baja | 1-5 pts | 60 días |

## 5. KPIs
- Score promedio del tenant
- % copropiedades en cumplimiento (>80)
- Brechas críticas abiertas
- Tiempo promedio de corrección

---

# PAPER M14: VALORIZACIÓN Y AVALÚOS

## 1. Objetivo y Alcance
Registrar y gestionar avalúos de copropiedades y unidades para análisis financiero, garantías bancarias y seguros.

## 2. Tipos de Avalúo
| Tipo | Uso | Fuente |
|------|-----|--------|
| Fiscal | Contribuciones | SII |
| Comercial | Compraventa | Tasador |
| Bancario | Créditos | Banco |
| Seguro | Pólizas | Aseguradora |

## 3. KPIs
- Cobertura de avalúos actualizados
- Variación de valor año a año
- Valor por m² promedio

---

# PAPER M15: PAE - PRECESSION ANALYTICS ENGINE

## 1. Objetivo y Alcance
Proporcionar análisis predictivo y prescriptivo sobre copropiedades utilizando el concepto de "precesión" de Buckminster Fuller, identificando efectos secundarios y oportunidades no evidentes.

## 2. Marco Conceptual
- **Precesión**: Efectos perpendiculares al movimiento directo
- **Grafo de efectos**: Red de relaciones causa-efecto
- **Score precesional**: Medida de impacto sistémico
- **Alerta precesional**: Notificación de efecto detectado

## 3. Engines Nativos
1. **PrecessionGraphEngine**: Ontología y grafo de 12+ nodos, 15+ aristas
2. **PrecessionScoringEngine**: Cálculo multi-dimensional de scores
3. **PrecessionMLConnector**: Integración con modelos ML (fallback funcional)
4. **PrecessionAlertEngine**: Generación y gestión de alertas
5. **PrecessionSyncService**: Sincronización con ÁGORA

## 4. Tipos de Análisis
| Análisis | Descripción | Horizonte |
|----------|-------------|-----------|
| Riesgo | Probabilidad de eventos adversos | 12-36 meses |
| Oportunidad | Potencial de mejora | 12-36 meses |
| Inversión | Score para decisiones de capital | Inmediato |
| Comparativo | Benchmark entre copropiedades | N/A |

## 5. KPIs
- Precisión de predicciones
- Tiempo de análisis < 2 segundos
- Alertas accionadas vs ignoradas

---

# PAPER M16: ARRIENDOS Y CONTRATOS

## 1. Objetivo y Alcance
Gestionar contratos de arriendo de unidades dentro de copropiedades, manteniendo actualizado el estado de ocupación.

## 2. Datos del Contrato
- Arrendador (copropietario)
- Arrendatario (datos completos)
- Canon mensual (CLP o UF)
- Fechas de inicio y término
- Garantía
- Condiciones especiales

## 3. KPIs
- Tasa de ocupación
- Canon promedio por tipo de unidad
- Contratos por vencer

---

# PAPER M17: MANTENCIONES Y ÓRDENES DE TRABAJO

## 1. Objetivo y Alcance
Gestionar mantenciones preventivas y correctivas de la copropiedad mediante órdenes de trabajo con seguimiento completo.

## 2. Tipos de Mantenimiento
| Tipo | Descripción | Prioridad Default |
|------|-------------|-------------------|
| Preventiva | Programada | Media |
| Correctiva | Reparación de falla | Alta |
| Mejora | Upgrade | Baja |
| Emergencia | Urgente | Urgente |

## 3. Flujo de OT
```
Solicitud → Evaluación → Aprobación → Asignación → Ejecución → Cierre → Evaluación
```

## 4. KPIs
- Tiempo promedio de resolución
- OT cerradas vs abiertas
- Cumplimiento plan preventivo

---

# PAPER M18: COMUNICACIONES

## 1. Objetivo y Alcance
Gestionar comunicaciones a copropietarios mediante múltiples canales, con seguimiento de entrega y confirmación.

## 2. Tipos y Canales
| Tipo | Canales Sugeridos |
|------|-------------------|
| Informativo | Email, App |
| Urgente | Email, SMS, App |
| Asamblea | Email, Carta |
| Cobranza | Email, SMS |

## 3. KPIs
- Tasa de apertura
- Tasa de confirmación
- Tiempo de lectura promedio

---

# PAPER M19: REPORTES Y DASHBOARDS

## 1. Objetivo y Alcance
Generar reportes configurables y dashboards interactivos para toma de decisiones en todos los niveles.

## 2. Tipos de Reportes
1. **Financiero**: Balance, Estado de Resultados, Flujo de Caja
2. **Operacional**: Morosidad, Mantenciones, Ocupación
3. **Compliance**: Evaluación normativa, Brechas
4. **Tributario**: DJ, Certificados emitidos
5. **Ejecutivo**: Resumen gerencial

## 3. KPIs
- Reportes generados/mes
- Tiempo de generación
- Uso de dashboards

---

# PAPER M20: DOCUMENTOS Y ARCHIVOS

## 1. Objetivo y Alcance
Gestionar almacenamiento, categorización y acceso a documentos digitales asociados a todas las entidades del sistema.

## 2. Categorías
- Contratos
- Facturas
- Actas
- Legal
- Técnico
- Fotos

## 3. Políticas
- Retención: 5 años mínimo
- Backup: Diario
- Acceso: Según permisos de entidad padre

---

# PAPER M21: CONFIGURACIONES

## 1. Objetivo y Alcance
Gestionar parámetros configurables del sistema a nivel global, por tenant y por copropiedad.

## 2. Jerarquía
```
Global → Tenant → Copropiedad
```

## 3. Grupos Principales
- Sistema: Timezone, locale
- Tributario: Tasa IVA, interés mora
- Gastos: Día vencimiento, % fondo reserva
- PAE: Horizonte, profundidad
- Notificaciones: Email remitente, días aviso

---

# PAPER M22: NOTIFICACIONES

## 1. Objetivo y Alcance
Gestionar notificaciones en tiempo real y diferidas a usuarios del sistema.

## 2. Canales
- Database (in-app)
- Email
- Push (preparado)
- SMS (integración futura)

## 3. Triggers
- Vencimientos
- Alertas PAE
- Cambios de estado
- Comunicados

---

# PAPER M23: JOBS Y AUTOMATIZACIONES

## 1. Objetivo y Alcance
Ejecutar procesos automáticos programados y en background para operaciones masivas y periódicas.

## 2. Jobs Principales
| Job | Frecuencia | Descripción |
|-----|------------|-------------|
| FacturarAntenas | Mensual (día 1) | Genera facturas de contratos vigentes |
| CalcularIntereses | Diario | Actualiza intereses de mora |
| SincronizarUF | Diario | Obtiene valor UF del día |
| SincronizarAgora | Cada 6 horas | Envía datos a ÁGORA |
| GenerarReportes | Según config | Reportes programados |
| EvaluarCompliance | Mensual | Evaluación automática |

## 3. KPIs
- Jobs exitosos vs fallidos
- Tiempo promedio de ejecución
- Cola de pendientes

---

# REFERENCIAS GENERALES

1. Ley N° 21.442 de Copropiedad Inmobiliaria (2022)
2. DS N° 7/2025 Reglamento de Copropiedad
3. DL 825 Impuesto al Valor Agregado
4. Ley de Impuesto a la Renta
5. Circulares SII sobre Copropiedades
6. Laravel 11 Documentation
7. OWASP Security Guidelines
8. Buckminster Fuller - "Critical Path" (concepto de precesión)

---

*Documentos generados para DATAPOLIS v3.0*
*Fecha: 6 de febrero de 2026*
