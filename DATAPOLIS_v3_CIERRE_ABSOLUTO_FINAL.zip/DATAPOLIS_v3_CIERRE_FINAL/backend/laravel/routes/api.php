<?php
/**
 * =========================================================================
 * DATAPOLIS v3.0 - RUTAS API COMPLETAS
 * 23 Módulos - Todos los endpoints para producción
 * =========================================================================
 */

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\{
    AuthController,
    CopropiedadController,
    UnidadController,
    ContratoAntenaController,
    GastoComunController,
    MorosidadController,
    ContabilidadController,
    CertificadoTributarioController,
    PrecessionController,
    ComplianceController,
    DashboardController
};

// =============================================================================
// RUTAS PÚBLICAS
// =============================================================================
Route::prefix('v1')->group(function () {
    
    // Auth
    Route::post('auth/login', [AuthController::class, 'login']);
    Route::post('auth/register', [AuthController::class, 'register']);
    Route::post('auth/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('auth/reset-password', [AuthController::class, 'resetPassword']);

    // Verificación de certificados (público)
    Route::get('certificados/verificar/{codigo}', [CertificadoTributarioController::class, 'verificar']);

    // UF del día (público)
    Route::get('uf/hoy', fn() => response()->json(['valor' => \App\Models\UfHistorico::getValor()]));
});

// =============================================================================
// RUTAS PROTEGIDAS
// =============================================================================
Route::prefix('v1')->middleware(['auth:sanctum'])->group(function () {

    // -------------------------------------------------------------------------
    // AUTH
    // -------------------------------------------------------------------------
    Route::prefix('auth')->group(function () {
        Route::post('logout', [AuthController::class, 'logout']);
        Route::get('me', [AuthController::class, 'me']);
        Route::put('profile', [AuthController::class, 'updateProfile']);
        Route::put('password', [AuthController::class, 'updatePassword']);
    });

    // -------------------------------------------------------------------------
    // DASHBOARD GLOBAL
    // -------------------------------------------------------------------------
    Route::get('dashboard', [DashboardController::class, 'index']);

    // -------------------------------------------------------------------------
    // M03: COPROPIEDADES
    // -------------------------------------------------------------------------
    Route::prefix('copropiedades')->group(function () {
        Route::get('/', [CopropiedadController::class, 'index']);
        Route::post('/', [CopropiedadController::class, 'store']);
        Route::get('{id}', [CopropiedadController::class, 'show']);
        Route::put('{id}', [CopropiedadController::class, 'update']);
        Route::delete('{id}', [CopropiedadController::class, 'destroy']);
        Route::get('{id}/dashboard', [CopropiedadController::class, 'dashboard']);

        // -------------------------------------------------------------------------
        // M03: UNIDADES (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/unidades')->group(function () {
            Route::get('/', [UnidadController::class, 'index']);
            Route::post('/', [UnidadController::class, 'store']);
            Route::get('{id}', [UnidadController::class, 'show']);
            Route::put('{id}', [UnidadController::class, 'update']);
            Route::delete('{id}', [UnidadController::class, 'destroy']);

            // Copropietarios
            Route::get('{unidadId}/copropietarios', 'CopropietarioController@index');
            Route::post('{unidadId}/copropietarios', 'CopropietarioController@store');
            Route::put('{unidadId}/copropietarios/{id}', 'CopropietarioController@update');
        });

        // -------------------------------------------------------------------------
        // M04: ANTENAS (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/antenas')->group(function () {
            Route::get('/', [ContratoAntenaController::class, 'index']);
            Route::post('/', [ContratoAntenaController::class, 'store']);
            Route::get('{id}', [ContratoAntenaController::class, 'show']);
            Route::put('{id}', [ContratoAntenaController::class, 'update']);
            Route::delete('{id}', [ContratoAntenaController::class, 'destroy']);
            Route::post('{id}/facturar', [ContratoAntenaController::class, 'generarFactura']);
            Route::get('{id}/facturas', [ContratoAntenaController::class, 'facturas']);
            Route::post('{id}/renovar', [ContratoAntenaController::class, 'renovar']);
        });

        // -------------------------------------------------------------------------
        // M05: GASTOS COMUNES (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/gastos')->group(function () {
            Route::get('/', [GastoComunController::class, 'index']);
            Route::post('/', [GastoComunController::class, 'store']);
            Route::get('{id}', [GastoComunController::class, 'show']);
            Route::put('{id}', [GastoComunController::class, 'update']);
            Route::delete('{id}', [GastoComunController::class, 'destroy']);
            Route::put('{id}/aprobar', [GastoComunController::class, 'aprobar']);
            Route::put('{id}/pagar', [GastoComunController::class, 'registrarPago']);
        });

        Route::prefix('{copropiedadId}/periodos')->group(function () {
            Route::get('/', 'PeriodoGastoController@index');
            Route::post('/', 'PeriodoGastoController@store');
            Route::get('{id}', 'PeriodoGastoController@show');
            Route::post('{id}/prorratear', [GastoComunController::class, 'prorratear']);
            Route::post('{id}/cerrar', 'PeriodoGastoController@cerrar');
        });

        // -------------------------------------------------------------------------
        // M06: MOROSIDAD (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/morosidad')->group(function () {
            Route::get('/', [MorosidadController::class, 'index']);
            Route::get('resumen', [MorosidadController::class, 'resumen']);
            Route::get('{id}', [MorosidadController::class, 'show']);
            Route::post('{id}/gestion', [MorosidadController::class, 'registrarGestion']);
            Route::post('{id}/convenio', [MorosidadController::class, 'crearConvenio']);
            Route::get('{id}/historial', [MorosidadController::class, 'historial']);
        });

        // -------------------------------------------------------------------------
        // M08: CONTABILIDAD (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/contabilidad')->group(function () {
            Route::get('plan-cuentas', [ContabilidadController::class, 'planCuentas']);
            Route::post('plan-cuentas', [ContabilidadController::class, 'crearCuenta']);
            
            Route::get('asientos', [ContabilidadController::class, 'asientos']);
            Route::post('asientos', [ContabilidadController::class, 'crearAsiento']);
            Route::get('asientos/{id}', [ContabilidadController::class, 'showAsiento']);
            Route::put('asientos/{id}/aprobar', [ContabilidadController::class, 'aprobarAsiento']);
            Route::put('asientos/{id}/reversar', [ContabilidadController::class, 'reversarAsiento']);

            Route::get('libro-mayor', [ContabilidadController::class, 'libroMayor']);
            Route::get('libro-diario', [ContabilidadController::class, 'libroDiario']);
            Route::get('balance/{ano}/{mes}', [ContabilidadController::class, 'balanceGeneral']);
            Route::get('estado-resultados/{ano}/{mes}', [ContabilidadController::class, 'estadoResultados']);

            Route::post('exportar-libro', [ContabilidadController::class, 'exportarLibro']);
            Route::get('libros', [ContabilidadController::class, 'libros']);
        });

        // -------------------------------------------------------------------------
        // M09: CERTIFICADOS TRIBUTARIOS (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/certificados')->group(function () {
            Route::get('/', [CertificadoTributarioController::class, 'index']);
            Route::post('comunidad', [CertificadoTributarioController::class, 'emitirCertificadoComunidad']);
            Route::post('copropietario/{copropietarioId}', [CertificadoTributarioController::class, 'emitirCertificadoCopropietario']);
            Route::get('{id}', [CertificadoTributarioController::class, 'show']);
            Route::get('{id}/pdf', [CertificadoTributarioController::class, 'descargarPdf']);
            Route::put('{id}/anular', [CertificadoTributarioController::class, 'anular']);
        });

        // -------------------------------------------------------------------------
        // M10: DECLARACIONES JURADAS (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/declaraciones')->group(function () {
            Route::get('/', 'DeclaracionJuradaController@index');
            Route::post('generar', 'DeclaracionJuradaController@generar');
            Route::get('{id}', 'DeclaracionJuradaController@show');
            Route::post('{id}/enviar-sii', 'DeclaracionJuradaController@enviarSii');
            Route::get('{id}/estado-sii', 'DeclaracionJuradaController@consultarEstadoSii');
        });

        // -------------------------------------------------------------------------
        // M11: FONDO DE RESERVA (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/fondo-reserva')->group(function () {
            Route::get('/', 'FondoReservaController@show');
            Route::put('/', 'FondoReservaController@update');
            Route::get('movimientos', 'FondoReservaController@movimientos');
            Route::post('uso', 'FondoReservaController@registrarUso');
        });

        // -------------------------------------------------------------------------
        // M12: ASAMBLEAS (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/asambleas')->group(function () {
            Route::get('/', 'AsambleaController@index');
            Route::post('/', 'AsambleaController@store');
            Route::get('{id}', 'AsambleaController@show');
            Route::put('{id}', 'AsambleaController@update');
            Route::post('{id}/acta', 'AsambleaController@registrarActa');
            Route::get('{id}/acta', 'AsambleaController@showActa');
            Route::put('{id}/acta/aprobar', 'AsambleaController@aprobarActa');
        });

        // -------------------------------------------------------------------------
        // M13: COMPLIANCE (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/compliance')->group(function () {
            Route::get('/', [ComplianceController::class, 'evaluaciones']);
            Route::post('evaluar', [ComplianceController::class, 'evaluar']);
            Route::get('{id}', [ComplianceController::class, 'showEvaluacion']);
            Route::get('requisitos', [ComplianceController::class, 'requisitos']);
        });

        // -------------------------------------------------------------------------
        // M14: AVALÚOS (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/avaluos')->group(function () {
            Route::get('/', 'AvaluoController@index');
            Route::post('/', 'AvaluoController@store');
            Route::get('{id}', 'AvaluoController@show');
            Route::put('{id}', 'AvaluoController@update');
        });

        // -------------------------------------------------------------------------
        // M15: PAE - PRECESSION ANALYTICS (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/pae')->group(function () {
            Route::get('dashboard', [PrecessionController::class, 'dashboard']);
            Route::post('analyze', [PrecessionController::class, 'analyze']);
            Route::get('analyses', [PrecessionController::class, 'analyses']);
            Route::get('analyses/{id}', [PrecessionController::class, 'showAnalysis']);
            
            Route::get('alerts', [PrecessionController::class, 'alerts']);
            Route::put('alerts/{id}/acknowledge', [PrecessionController::class, 'acknowledgeAlert']);
            Route::put('alerts/{id}/resolve', [PrecessionController::class, 'resolveAlert']);

            Route::post('investment-score', [PrecessionController::class, 'investmentScore']);
            Route::post('compare', [PrecessionController::class, 'compare']);
        });

        // -------------------------------------------------------------------------
        // M16: ARRIENDOS (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/arriendos')->group(function () {
            Route::get('/', 'ContratoArriendoController@index');
            Route::post('/', 'ContratoArriendoController@store');
            Route::get('{id}', 'ContratoArriendoController@show');
            Route::put('{id}', 'ContratoArriendoController@update');
            Route::put('{id}/terminar', 'ContratoArriendoController@terminar');
        });

        // -------------------------------------------------------------------------
        // M17: MANTENCIONES (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/ordenes-trabajo')->group(function () {
            Route::get('/', 'OrdenTrabajoController@index');
            Route::post('/', 'OrdenTrabajoController@store');
            Route::get('{id}', 'OrdenTrabajoController@show');
            Route::put('{id}', 'OrdenTrabajoController@update');
            Route::put('{id}/aprobar', 'OrdenTrabajoController@aprobar');
            Route::put('{id}/completar', 'OrdenTrabajoController@completar');
        });

        Route::prefix('{copropiedadId}/plan-mantencion')->group(function () {
            Route::get('/', 'PlanMantencionController@index');
            Route::post('/', 'PlanMantencionController@store');
            Route::put('{id}', 'PlanMantencionController@update');
            Route::delete('{id}', 'PlanMantencionController@destroy');
        });

        // -------------------------------------------------------------------------
        // M18: COMUNICACIONES (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/comunicados')->group(function () {
            Route::get('/', 'ComunicadoController@index');
            Route::post('/', 'ComunicadoController@store');
            Route::get('{id}', 'ComunicadoController@show');
            Route::put('{id}', 'ComunicadoController@update');
            Route::post('{id}/enviar', 'ComunicadoController@enviar');
        });

        // -------------------------------------------------------------------------
        // M19: REPORTES (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/reportes')->group(function () {
            Route::get('/', 'ReporteController@index');
            Route::get('configurados', 'ReporteController@configurados');
            Route::post('generar', 'ReporteController@generar');
            Route::get('{id}/descargar', 'ReporteController@descargar');
        });

        // -------------------------------------------------------------------------
        // M20: DOCUMENTOS (nested)
        // -------------------------------------------------------------------------
        Route::prefix('{copropiedadId}/documentos')->group(function () {
            Route::get('/', 'DocumentoController@index');
            Route::post('/', 'DocumentoController@store');
            Route::get('{id}', 'DocumentoController@show');
            Route::get('{id}/descargar', 'DocumentoController@descargar');
            Route::delete('{id}', 'DocumentoController@destroy');
        });
    });

    // -------------------------------------------------------------------------
    // M07: PROVEEDORES (global por tenant)
    // -------------------------------------------------------------------------
    Route::prefix('proveedores')->group(function () {
        Route::get('/', 'ProveedorController@index');
        Route::post('/', 'ProveedorController@store');
        Route::get('{id}', 'ProveedorController@show');
        Route::put('{id}', 'ProveedorController@update');
        Route::delete('{id}', 'ProveedorController@destroy');
        Route::get('{id}/contratos', 'ProveedorController@contratos');
    });

    // -------------------------------------------------------------------------
    // CATEGORÍAS DE GASTO (global por tenant)
    // -------------------------------------------------------------------------
    Route::prefix('categorias-gasto')->group(function () {
        Route::get('/', 'CategoriaGastoController@index');
        Route::post('/', 'CategoriaGastoController@store');
        Route::put('{id}', 'CategoriaGastoController@update');
        Route::delete('{id}', 'CategoriaGastoController@destroy');
    });

    // -------------------------------------------------------------------------
    // M21: CONFIGURACIONES
    // -------------------------------------------------------------------------
    Route::prefix('configuraciones')->group(function () {
        Route::get('/', 'ConfiguracionController@index');
        Route::get('{grupo}/{clave}', 'ConfiguracionController@show');
        Route::put('{grupo}/{clave}', 'ConfiguracionController@update');
    });

    // -------------------------------------------------------------------------
    // UF HISTÓRICO
    // -------------------------------------------------------------------------
    Route::prefix('uf')->group(function () {
        Route::get('historico', 'UfController@historico');
        Route::post('sincronizar', 'UfController@sincronizar');
    });

    // -------------------------------------------------------------------------
    // ADMINISTRACIÓN (solo admin)
    // -------------------------------------------------------------------------
    Route::prefix('admin')->middleware(['role:admin'])->group(function () {
        Route::get('tenants', 'AdminController@tenants');
        Route::get('tenants/{id}', 'AdminController@showTenant');
        Route::put('tenants/{id}', 'AdminController@updateTenant');
        
        Route::get('users', 'AdminController@users');
        Route::post('users', 'AdminController@createUser');
        Route::put('users/{id}', 'AdminController@updateUser');
        Route::delete('users/{id}', 'AdminController@deleteUser');

        Route::get('roles', 'AdminController@roles');
        Route::post('roles', 'AdminController@createRole');
        Route::put('roles/{id}', 'AdminController@updateRole');

        Route::get('audit-logs', 'AdminController@auditLogs');
    });
});
