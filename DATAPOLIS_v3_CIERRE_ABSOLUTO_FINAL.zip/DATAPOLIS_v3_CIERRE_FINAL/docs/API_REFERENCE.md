# DATAPOLIS v3.0 - Referencia de API

## Índice
1. [Información General](#información-general)
2. [Autenticación](#autenticación)
3. [Endpoints por Módulo](#endpoints-por-módulo)
4. [Códigos de Estado](#códigos-de-estado)
5. [Ejemplos de Uso](#ejemplos-de-uso)

---

## Información General

### Base URLs

| Ambiente | URL |
|----------|-----|
| Producción | `https://api.datapolis.cl/v1` |
| Staging | `https://staging-api.datapolis.cl/v1` |
| Local | `http://localhost:8000/api/v1` |

### Headers Requeridos

```http
Content-Type: application/json
Accept: application/json
Authorization: Bearer {token}
X-Tenant-ID: {tenant_id}  # Solo multi-tenant
```

### Paginación

Todos los endpoints de listado soportan paginación:

```
?page=1&per_page=15
```

Respuesta paginada:
```json
{
  "data": [...],
  "meta": {
    "current_page": 1,
    "last_page": 10,
    "per_page": 15,
    "total": 150
  }
}
```

---

## Autenticación

### Login

```http
POST /auth/login
```

**Request:**
```json
{
  "email": "usuario@example.com",
  "password": "contraseña"
}
```

**Response 200:**
```json
{
  "access_token": "1|abc123...",
  "token_type": "Bearer",
  "expires_in": 3600,
  "user": {
    "id": 1,
    "name": "Usuario",
    "email": "usuario@example.com",
    "roles": ["admin"]
  }
}
```

### Logout

```http
POST /auth/logout
Authorization: Bearer {token}
```

### Usuario Actual

```http
GET /auth/me
Authorization: Bearer {token}
```

---

## Endpoints por Módulo

### M00 - Expediente (15 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/expedientes` | Listar expedientes |
| POST | `/expedientes` | Crear expediente |
| GET | `/expedientes/{id}` | Obtener expediente |
| PUT | `/expedientes/{id}` | Actualizar expediente |
| DELETE | `/expedientes/{id}` | Eliminar expediente |
| GET | `/expedientes/{id}/timeline` | Timeline del expediente |
| POST | `/expedientes/{id}/documentos` | Agregar documento |
| GET | `/expedientes/{id}/documentos` | Listar documentos |
| POST | `/expedientes/{id}/notas` | Agregar nota |
| GET | `/expedientes/{id}/participantes` | Listar participantes |
| POST | `/expedientes/{id}/participantes` | Agregar participante |
| PUT | `/expedientes/{id}/estado` | Cambiar estado |
| GET | `/expedientes/{id}/historial` | Historial de cambios |
| POST | `/expedientes/{id}/vincular` | Vincular a propiedad |
| GET | `/expedientes/estadisticas` | Estadísticas globales |

---

### M01 - Ficha Propiedad (18 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/propiedades` | Listar propiedades |
| POST | `/propiedades` | Crear propiedad |
| GET | `/propiedades/{id}` | Obtener propiedad |
| PUT | `/propiedades/{id}` | Actualizar propiedad |
| DELETE | `/propiedades/{id}` | Eliminar propiedad |
| GET | `/propiedades/{id}/ficha-completa` | Ficha completa |
| GET | `/propiedades/{id}/avaluo` | Avalúo actual |
| POST | `/propiedades/{id}/avaluo` | Solicitar avalúo |
| GET | `/propiedades/{id}/documentos` | Documentos propiedad |
| POST | `/propiedades/{id}/documentos` | Subir documento |
| GET | `/propiedades/{id}/historial-precios` | Historial de precios |
| GET | `/propiedades/{id}/comparables` | Propiedades comparables |
| GET | `/propiedades/{id}/riesgos` | Análisis de riesgos |
| POST | `/propiedades/{id}/certificado` | Generar certificado |
| GET | `/propiedades/buscar` | Búsqueda avanzada |
| GET | `/propiedades/mapa` | Propiedades en mapa |
| POST | `/propiedades/importar` | Importar masivo |
| GET | `/propiedades/exportar` | Exportar datos |

---

### M02 - Copropiedad (25 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/copropiedades` | Listar copropiedades |
| POST | `/copropiedades` | Crear copropiedad |
| GET | `/copropiedades/{id}` | Obtener copropiedad |
| PUT | `/copropiedades/{id}` | Actualizar |
| DELETE | `/copropiedades/{id}` | Eliminar |
| GET | `/copropiedades/{id}/dashboard` | Dashboard |
| GET | `/copropiedades/{id}/unidades` | Listar unidades |
| POST | `/copropiedades/{id}/unidades` | Crear unidad |
| GET | `/copropiedades/{id}/unidades/{uid}` | Obtener unidad |
| PUT | `/copropiedades/{id}/unidades/{uid}` | Actualizar unidad |
| DELETE | `/copropiedades/{id}/unidades/{uid}` | Eliminar unidad |
| GET | `/copropiedades/{id}/antenas` | Listar antenas |
| POST | `/copropiedades/{id}/antenas` | Crear contrato antena |
| GET | `/copropiedades/{id}/antenas/{aid}` | Obtener antena |
| PUT | `/copropiedades/{id}/antenas/{aid}` | Actualizar antena |
| POST | `/copropiedades/{id}/antenas/{aid}/facturar` | Generar factura |
| GET | `/copropiedades/{id}/gastos` | Períodos de gasto |
| POST | `/copropiedades/{id}/gastos` | Crear período |
| GET | `/copropiedades/{id}/morosidad` | Reporte morosidad |
| POST | `/copropiedades/{id}/cobranza` | Iniciar cobranza |
| GET | `/copropiedades/{id}/fondo-reserva` | Estado fondo |
| POST | `/copropiedades/{id}/fondo-reserva/movimiento` | Registrar movimiento |
| GET | `/copropiedades/{id}/estadisticas` | Estadísticas |
| POST | `/copropiedades/{id}/importar-unidades` | Importar unidades |
| GET | `/copropiedades/{id}/reporte-anual` | Reporte anual |

---

### M03 - Credit Scoring (12 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/creditscore/calculate` | Calcular score |
| GET | `/creditscore/entity/{type}/{id}` | Score por entidad |
| GET | `/creditscore/pd/{entityId}` | Probability of Default |
| GET | `/creditscore/lgd/{entityId}` | Loss Given Default |
| GET | `/creditscore/ead/{entityId}` | Exposure at Default |
| GET | `/creditscore/rwa/{entityId}` | Risk Weighted Assets |
| GET | `/creditscore/history/{entityId}` | Historial de scores |
| POST | `/creditscore/batch` | Cálculo batch |
| GET | `/creditscore/factors/{entityId}` | Factores del score |
| POST | `/creditscore/simulate` | Simular escenario |
| GET | `/creditscore/models` | Modelos disponibles |
| GET | `/creditscore/thresholds` | Umbrales configurados |

---

### M04 - Valorización (10 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/valorizacion/avaluo` | Generar avalúo ML |
| GET | `/valorizacion/avaluo/{id}` | Obtener avalúo |
| POST | `/valorizacion/comparables` | Buscar comparables |
| GET | `/valorizacion/historial/{propiedadId}` | Historial valores |
| POST | `/valorizacion/hedonic` | Modelo hedónico |
| POST | `/valorizacion/cost-approach` | Método de costo |
| POST | `/valorizacion/income-approach` | Método de ingresos |
| GET | `/valorizacion/indices` | Índices de mercado |
| POST | `/valorizacion/batch` | Valorización masiva |
| GET | `/valorizacion/reporte/{id}` | Reporte PDF |

---

### M11 - PAE (36 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/copropiedades/{id}/pae/analyze` | Análisis completo |
| GET | `/copropiedades/{id}/pae/quick` | Análisis rápido |
| GET | `/copropiedades/{id}/pae/score` | Score actual |
| GET | `/copropiedades/{id}/pae/scores/history` | Historial scores |
| GET | `/copropiedades/{id}/pae/alerts` | Alertas activas |
| PUT | `/copropiedades/{id}/pae/alerts/{aid}` | Actualizar alerta |
| POST | `/copropiedades/{id}/pae/alerts/{aid}/acknowledge` | Reconocer alerta |
| POST | `/copropiedades/{id}/pae/alerts/{aid}/resolve` | Resolver alerta |
| GET | `/copropiedades/{id}/pae/effects` | Efectos propagados |
| GET | `/copropiedades/{id}/pae/graph` | Grafo ontológico |
| POST | `/copropiedades/{id}/pae/simulate` | Simular escenario |
| GET | `/copropiedades/{id}/pae/projections` | Proyecciones |
| GET | `/copropiedades/{id}/pae/recommendations` | Recomendaciones |
| GET | `/copropiedades/{id}/pae/trends` | Tendencias |
| GET | `/copropiedades/{id}/pae/benchmarks` | Comparativas |
| POST | `/copropiedades/{id}/pae/refresh` | Recalcular |
| GET | `/pae/ontology/nodes` | Nodos ontología |
| GET | `/pae/ontology/edges` | Aristas ontología |
| GET | `/pae/ontology/relationships` | Relaciones |
| POST | `/pae/ontology/nodes` | Crear nodo |
| PUT | `/pae/ontology/nodes/{nid}` | Actualizar nodo |
| DELETE | `/pae/ontology/nodes/{nid}` | Eliminar nodo |
| POST | `/pae/ontology/edges` | Crear arista |
| GET | `/pae/models` | Modelos PAE |
| GET | `/pae/models/{mid}` | Detalle modelo |
| POST | `/pae/models/{mid}/train` | Entrenar modelo |
| GET | `/pae/metrics` | Métricas globales |
| GET | `/pae/reports/summary` | Reporte resumen |
| GET | `/pae/reports/detailed/{copId}` | Reporte detallado |
| POST | `/pae/reports/generate` | Generar reporte PDF |
| GET | `/pae/config` | Configuración |
| PUT | `/pae/config` | Actualizar config |
| GET | `/pae/logs` | Logs de ejecución |
| POST | `/pae/batch` | Análisis batch |
| GET | `/pae/queue/status` | Estado de cola |
| POST | `/pae/webhooks` | Configurar webhook |

---

### M01-OF - Open Finance NCG514 (23 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/openfinance/consent` | Crear consentimiento |
| GET | `/openfinance/consent/{id}` | Estado consentimiento |
| DELETE | `/openfinance/consent/{id}` | Revocar consentimiento |
| GET | `/openfinance/consents` | Listar consentimientos |
| GET | `/openfinance/accounts` | Listar cuentas |
| GET | `/openfinance/accounts/{id}` | Detalle cuenta |
| GET | `/openfinance/accounts/{id}/balances` | Saldos |
| GET | `/openfinance/accounts/{id}/transactions` | Transacciones |
| POST | `/openfinance/payments` | Iniciar pago |
| GET | `/openfinance/payments/{id}` | Estado pago |
| POST | `/openfinance/payments/{id}/authorize` | Autorizar pago |
| GET | `/openfinance/institutions` | Instituciones |
| GET | `/openfinance/institutions/{id}` | Detalle institución |
| POST | `/openfinance/token` | Obtener token |
| POST | `/openfinance/token/refresh` | Refrescar token |
| POST | `/openfinance/token/revoke` | Revocar token |
| GET | `/openfinance/directorio` | Directorio participantes |
| POST | `/openfinance/mensajes/iso20022` | Enviar mensaje ISO |
| GET | `/openfinance/mensajes/{id}` | Estado mensaje |
| GET | `/openfinance/audit` | Log de auditoría |
| GET | `/openfinance/metrics` | Métricas uso |
| POST | `/openfinance/webhook` | Registrar webhook |
| GET | `/openfinance/status` | Estado servicio |

---

### M17 - GIRES (18 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/gires/riesgos/{ubicacionId}` | Riesgos por ubicación |
| POST | `/gires/analisis` | Análisis de riesgos |
| GET | `/gires/analisis/{id}` | Detalle análisis |
| GET | `/gires/alertas` | Alertas activas |
| GET | `/gires/alertas/{id}` | Detalle alerta |
| POST | `/gires/alertas/{id}/notificar` | Notificar |
| GET | `/gires/zonas` | Zonas de riesgo |
| GET | `/gires/zonas/{id}` | Detalle zona |
| GET | `/gires/mapas/sismico` | Mapa sísmico |
| GET | `/gires/mapas/tsunami` | Mapa tsunami |
| GET | `/gires/mapas/inundacion` | Mapa inundación |
| GET | `/gires/mapas/incendio` | Mapa incendio |
| GET | `/gires/mapas/remocion` | Mapa remoción masa |
| POST | `/gires/consulta-masiva` | Consulta masiva |
| GET | `/gires/estadisticas` | Estadísticas |
| GET | `/gires/historial/{ubicacionId}` | Historial eventos |
| POST | `/gires/reporte` | Generar reporte |
| GET | `/gires/fuentes` | Fuentes de datos |

---

### M22 - ÁGORA GeoViewer (20 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/agora/capas` | Listar capas |
| GET | `/agora/capas/{id}` | Detalle capa |
| POST | `/agora/capas` | Crear capa |
| PUT | `/agora/capas/{id}` | Actualizar capa |
| DELETE | `/agora/capas/{id}` | Eliminar capa |
| GET | `/agora/tiles/{z}/{x}/{y}` | Obtener tile |
| GET | `/agora/features` | Features en bbox |
| GET | `/agora/features/{id}` | Detalle feature |
| POST | `/agora/query` | Query espacial |
| POST | `/agora/intersect` | Intersección |
| POST | `/agora/buffer` | Buffer análisis |
| GET | `/agora/prc/{comuna}` | Plan Regulador |
| GET | `/agora/zonificacion/{coords}` | Zonificación |
| GET | `/agora/normativa/{zona}` | Normativa urbana |
| POST | `/agora/analisis-territorial` | Análisis territorial |
| GET | `/agora/indicadores/{territorio}` | Indicadores |
| POST | `/agora/reporte-territorial` | Reporte PDF |
| GET | `/agora/proyectos` | Proyectos urbanos |
| POST | `/agora/geocodificar` | Geocodificar |
| POST | `/agora/reverse-geocode` | Reverse geocode |

---

### GT-PV - Plusvalías (25 endpoints)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/plusvalias/calcular` | Calcular plusvalía |
| GET | `/plusvalias/{id}` | Detalle cálculo |
| GET | `/plusvalias/propiedad/{propId}` | Por propiedad |
| POST | `/plusvalias/simular` | Simular escenario |
| GET | `/plusvalias/historial/{propId}` | Historial |
| POST | `/plusvalias/declaracion` | Generar declaración |
| GET | `/plusvalias/declaracion/{id}` | Estado declaración |
| POST | `/plusvalias/pago` | Registrar pago |
| GET | `/plusvalias/deuda/{propId}` | Deuda pendiente |
| POST | `/plusvalias/convenio` | Crear convenio pago |
| GET | `/plusvalias/convenio/{id}` | Estado convenio |
| GET | `/plusvalias/tasas` | Tasas vigentes |
| GET | `/plusvalias/exenciones` | Exenciones aplicables |
| POST | `/plusvalias/solicitar-exencion` | Solicitar exención |
| GET | `/plusvalias/obras-publicas` | Obras públicas |
| GET | `/plusvalias/zonas-afectas` | Zonas afectas |
| GET | `/plusvalias/estadisticas` | Estadísticas |
| POST | `/plusvalias/masivo` | Cálculo masivo |
| GET | `/plusvalias/reporte/{id}` | Reporte PDF |
| POST | `/plusvalias/notificar` | Notificar contribuyente |
| GET | `/plusvalias/calendario` | Calendario fiscal |
| POST | `/plusvalias/recurso` | Presentar recurso |
| GET | `/plusvalias/recurso/{id}` | Estado recurso |
| GET | `/plusvalias/jurisprudencia` | Jurisprudencia |
| GET | `/plusvalias/normativa` | Normativa vigente |

---

## Códigos de Estado

| Código | Significado | Uso |
|--------|-------------|-----|
| 200 | OK | Solicitud exitosa |
| 201 | Created | Recurso creado |
| 204 | No Content | Eliminación exitosa |
| 400 | Bad Request | Error de validación |
| 401 | Unauthorized | Token inválido/ausente |
| 403 | Forbidden | Sin permisos |
| 404 | Not Found | Recurso no existe |
| 422 | Unprocessable | Error de datos |
| 429 | Too Many Requests | Rate limit excedido |
| 500 | Server Error | Error interno |

### Formato de Error

```json
{
  "message": "Error de validación",
  "errors": {
    "email": ["El email es requerido"],
    "password": ["La contraseña debe tener al menos 8 caracteres"]
  }
}
```

---

## Ejemplos de Uso

### Crear Copropiedad

```bash
curl -X POST https://api.datapolis.cl/v1/copropiedades \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Edificio Los Álamos",
    "rut": "76.123.456-7",
    "direccion": "Av. Providencia 1234",
    "comuna": "Providencia",
    "region": "Metropolitana",
    "total_unidades": 50,
    "prorrateo_type": "metros"
  }'
```

### Ejecutar Análisis PAE

```bash
curl -X POST https://api.datapolis.cl/v1/copropiedades/1/pae/analyze \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{
    "include_projections": true,
    "horizon_months": 12
  }'
```

### Calcular Credit Score

```bash
curl -X POST https://api.datapolis.cl/v1/creditscore/calculate \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{
    "entity_type": "copropiedad",
    "entity_id": 1,
    "include_history": true
  }'
```

### Generar Avalúo ML

```bash
curl -X POST https://api.datapolis.cl/v1/valorizacion/avaluo \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{
    "propiedad_id": 123,
    "metodo": "ml_ensemble"
  }'
```

---

**DATAPOLIS v3.0** | Referencia de API | 450+ Endpoints
