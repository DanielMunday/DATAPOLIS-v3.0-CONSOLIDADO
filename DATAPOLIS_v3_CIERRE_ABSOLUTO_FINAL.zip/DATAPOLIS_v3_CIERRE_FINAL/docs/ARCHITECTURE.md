# DATAPOLIS v3.0 - Documentación de Arquitectura

## Índice
1. [Visión General](#visión-general)
2. [Dominios de Negocio](#dominios-de-negocio)
3. [Arquitectura del Sistema](#arquitectura-del-sistema)
4. [Componentes Principales](#componentes-principales)
5. [Módulos del Sistema](#módulos-del-sistema)
6. [Flujos de Datos](#flujos-de-datos)
7. [Seguridad](#seguridad)
8. [Integraciones Externas](#integraciones-externas)

---

## Visión General

DATAPOLIS v3.0 es una plataforma integral PropTech/FinTech/RegTech/GovTech diseñada para el mercado inmobiliario chileno. Combina gestión de copropiedades, análisis financiero avanzado, cumplimiento regulatorio y análisis territorial.

### Métricas del Sistema

| Métrica | Valor |
|---------|-------|
| Líneas de código total | ~151,585 |
| Backend FastAPI (Python) | ~140,000 |
| Backend Laravel (PHP) | ~11,585 |
| Endpoints API | 450+ |
| Módulos funcionales | 23 |
| Tablas de base de datos | 64 |

### Stack Tecnológico

```
┌─────────────────────────────────────────────────────────────┐
│                      FRONTEND                                │
│  Vue.js 3 / Nuxt 3 / TailwindCSS / Chart.js / Leaflet       │
├─────────────────────────────────────────────────────────────┤
│                      API GATEWAY                             │
│  Kong / Nginx / Rate Limiting / mTLS / JWT                  │
├─────────────────────────────────────────────────────────────┤
│                      BACKEND                                 │
│  ┌─────────────────────┐  ┌─────────────────────┐          │
│  │   Laravel 11        │  │   FastAPI 0.100+    │          │
│  │   PHP 8.2           │  │   Python 3.11       │          │
│  │   Sanctum Auth      │  │   Pydantic v2       │          │
│  │   Eloquent ORM      │  │   SQLAlchemy        │          │
│  └─────────────────────┘  └─────────────────────┘          │
├─────────────────────────────────────────────────────────────┤
│                      DATA LAYER                              │
│  PostgreSQL 15 + PostGIS 3.3 │ Redis 7 │ MinIO (S3)        │
├─────────────────────────────────────────────────────────────┤
│                      ML/AI LAYER                             │
│  XGBoost │ LightGBM │ LSTM │ Scikit-learn │ Transformers   │
└─────────────────────────────────────────────────────────────┘
```

---

## Dominios de Negocio

### Diagrama de Dominios

```
                           DATAPOLIS v3.0
                                 │
        ┌────────────────────────┼────────────────────────┐
        │                        │                        │
   ┌────┴────┐             ┌─────┴─────┐            ┌────┴────┐
   │ PROPTECH │             │  FINTECH  │            │ REGTECH │
   └────┬────┘             └─────┬─────┘            └────┬────┘
        │                        │                        │
   ┌────┴────┐             ┌─────┴─────┐            ┌────┴────┐
   │• M00-M02│             │• M01-OF   │            │• M10    │
   │• M05-M06│             │• M03-M04  │            │• M11    │
   │• M09    │             │• M07-M08  │            │• M14-M16│
   │• MS     │             │• M13      │            │         │
   └─────────┘             └───────────┘            └─────────┘
        │                        │                        │
        └────────────────────────┼────────────────────────┘
                                 │
                     ┌───────────┴───────────┐
                     │       GOVTECH         │
                     │  • M17 GIRES          │
                     │  • M22 ÁGORA          │
                     │  • GT-PV Plusvalías   │
                     └───────────────────────┘
```

### PropTech (Gestión Inmobiliaria)
- Expedientes y fichas de propiedad
- Gestión de copropiedades Ley 21.442
- Arriendos y Supply Chain Finance
- Mantenciones y contratos de antenas
- Mercado de suelo

### FinTech (Servicios Financieros)
- Open Finance NCG514/FAPI 2.0
- Credit Scoring Basel IV (PD, LGD, EAD)
- Valorización inmobiliaria ML
- Análisis de inversión
- Contabilidad y reportería

### RegTech (Cumplimiento Regulatorio)
- Compliance Ley 21.442, 21.713, 21.719
- Certificados tributarios automatizados
- Basel IV regulatory engine
- PAE (Precession Analysis Engine)

### GovTech (Integración Gubernamental)
- GIRES - Gestión de riesgos naturales
- ÁGORA - Inteligencia territorial
- Plusvalías urbanas (GT-PV)
- Integración SII, CMF, BCCH, MINVU

---

## Arquitectura del Sistema

### Diagrama de Arquitectura General

```
                                    ┌─────────────────┐
                                    │   CDN/WAF       │
                                    │   Cloudflare    │
                                    └────────┬────────┘
                                             │
                                    ┌────────┴────────┐
                                    │   Load Balancer │
                                    │     Nginx       │
                                    └────────┬────────┘
                                             │
                    ┌────────────────────────┼────────────────────────┐
                    │                        │                        │
           ┌────────┴────────┐      ┌────────┴────────┐      ┌────────┴────────┐
           │    Frontend     │      │   API Gateway   │      │   WebSocket     │
           │    Vue.js 3     │      │      Kong       │      │    Server       │
           │    Port 3000    │      │   Port 8443     │      │   Port 8080     │
           └─────────────────┘      └────────┬────────┘      └─────────────────┘
                                             │
                              ┌──────────────┴──────────────┐
                              │                             │
                     ┌────────┴────────┐           ┌────────┴────────┐
                     │  Laravel API    │           │  FastAPI ML     │
                     │  PHP 8.2        │           │  Python 3.11    │
                     │  Port 8000      │           │  Port 8001      │
                     └────────┬────────┘           └────────┬────────┘
                              │                             │
                              └──────────────┬──────────────┘
                                             │
              ┌──────────────────────────────┼──────────────────────────────┐
              │                              │                              │
     ┌────────┴────────┐           ┌────────┴────────┐           ┌────────┴────────┐
     │   PostgreSQL    │           │     Redis       │           │     MinIO       │
     │   + PostGIS     │           │   Cache/Queue   │           │   Object Store  │
     │   Port 5432     │           │   Port 6379     │           │   Port 9000     │
     └─────────────────┘           └─────────────────┘           └─────────────────┘
```

### Patrón de Arquitectura

DATAPOLIS implementa una **arquitectura hexagonal (ports & adapters)** con los siguientes principios:

1. **Domain-Driven Design (DDD)**: Cada módulo representa un bounded context
2. **CQRS**: Separación de comandos y queries en módulos críticos
3. **Event Sourcing**: Para auditoría y PAE
4. **Microservicios híbridos**: Laravel (CRUD) + FastAPI (ML/Analytics)

---

## Componentes Principales

### Backend Laravel (API Principal)

```
backend/laravel/
├── app/
│   ├── Http/
│   │   └── Controllers/Api/
│   │       ├── AuthController.php
│   │       ├── CopropiedadController.php
│   │       ├── UnidadController.php
│   │       ├── ContratoAntenaController.php
│   │       ├── GastoComunController.php
│   │       ├── MorosidadController.php
│   │       ├── ContabilidadController.php
│   │       ├── CertificadoTributarioController.php
│   │       ├── PrecessionController.php
│   │       ├── ComplianceController.php
│   │       └── DashboardController.php
│   ├── Models/
│   │   ├── Tenant.php
│   │   ├── Copropiedad.php
│   │   ├── Unidad.php
│   │   ├── ContratoAntena.php
│   │   ├── GastoComun.php
│   │   └── ... (48 modelos)
│   └── Services/
│       ├── UfService.php
│       ├── AntenaService.php
│       ├── ContabilidadService.php
│       └── PAE/
│           ├── PrecessionGraphEngine.php
│           ├── PrecessionScoringEngine.php
│           ├── PrecessionAlertEngine.php
│           └── PrecessionSyncService.php
├── database/
│   ├── migrations/
│   └── seeders/
└── routes/
    └── api.php (186 rutas)
```

### Backend FastAPI (ML/Analytics)

```
backend/fastapi/
├── main.py
├── config.py
├── database.py
├── routers/
│   ├── analisis_inversion.py
│   ├── credit_score.py
│   ├── due_diligence.py
│   ├── gires.py
│   ├── open_finance.py
│   ├── plusvalia.py
│   ├── valorizacion.py
│   └── ... (29 routers)
├── services/
│   ├── m00_expediente.py
│   ├── m03_credit_score.py
│   ├── m04_valorizacion.py
│   ├── m17_gires.py
│   └── ... (19 servicios)
├── schemas/
│   ├── base.py
│   ├── credit_score.py
│   └── valorizacion.py
├── models/
│   └── ml/
│       ├── xgboost_credit.pkl
│       ├── lstm_timeseries.h5
│       └── ensemble_valuation.pkl
└── fintech_ncg514/
    ├── open_finance_core.py
    ├── ncg514_fapi_security.py
    ├── ncg514_iso20022_messaging.py
    └── ncg514_sistema_integrado.py
```

### PAE (Precession Analysis Engine)

El PAE es el motor de análisis predictivo que evalúa la "salud" de una copropiedad mediante análisis de efectos propagados:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    PAE - PRECESSION ANALYSIS ENGINE                  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐ │
│  │  Graph Engine   │───▶│ Scoring Engine  │───▶│  Alert Engine   │ │
│  │                 │    │                 │    │                 │ │
│  │ • Ontology      │    │ • Financial     │    │ • Critical      │ │
│  │ • Relationships │    │ • Compliance    │    │ • High          │ │
│  │ • Propagation   │    │ • Operational   │    │ • Medium        │ │
│  │ • Effects       │    │ • Risk          │    │ • Low           │ │
│  └─────────────────┘    └─────────────────┘    └─────────────────┘ │
│           │                      │                      │          │
│           └──────────────────────┼──────────────────────┘          │
│                                  ▼                                  │
│                     ┌─────────────────────┐                        │
│                     │    Sync Service     │                        │
│                     │ • Real-time updates │                        │
│                     │ • Event processing  │                        │
│                     │ • History tracking  │                        │
│                     └─────────────────────┘                        │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Módulos del Sistema

### Matriz de Módulos

| Código | Módulo | Dominio | Backend | Endpoints | Descripción |
|--------|--------|---------|---------|-----------|-------------|
| M00 | Expediente | PropTech | Both | 15 | Gestión de casos inmobiliarios |
| M01 | Ficha Propiedad | PropTech | Both | 18 | Registro de propiedades |
| M01-OF | Open Finance | FinTech | FastAPI | 23 | NCG514/FAPI 2.0 |
| M02 | Copropiedad | PropTech | Laravel | 25 | Gestión Ley 21.442 |
| M03 | Credit Scoring | FinTech | FastAPI | 12 | Basel IV PD/LGD/EAD |
| M04 | Valorización | FinTech | FastAPI | 10 | ML hedonic pricing |
| M05 | Arriendos/SCF | FinTech | Laravel | 18 | Supply Chain Finance |
| M06 | Mantenciones | PropTech | Laravel | 15 | Gestión de mantenciones |
| M07 | Inversión | FinTech | FastAPI | 20 | Análisis de inversión |
| M08 | Contabilidad | FinTech | Laravel | 22 | Plan de cuentas IFRS |
| M09 | Cambio Suelo | PropTech | FastAPI | 8 | Análisis de zonificación |
| M10 | Compliance | RegTech | Laravel | 10 | Evaluaciones regulatorias |
| M11 | PAE | RegTech | Laravel | 36 | Precession Analysis Engine |
| M12 | Due Diligence | FinTech | FastAPI | 15 | DD360 automatizado |
| M13 | Garantías | FinTech | Both | 12 | Registro de colaterales |
| M14 | Reavalúo SII | RegTech | FastAPI | 8 | Integración SII |
| M15 | Indicadores | DataTech | FastAPI | 6 | UF, UTM, IPC, etc. |
| M16 | Basel IV | RegTech | FastAPI | 15 | Motor regulatorio |
| M17 | GIRES | GovTech | FastAPI | 18 | Riesgos naturales |
| MS | Mercado Suelo | PropTech | FastAPI | 12 | Análisis de mercado |
| RR | Rentabilidad | FinTech | FastAPI | 10 | Análisis de retorno |
| M22 | ÁGORA | GovTech | Both | 20 | Inteligencia territorial |
| GT-PV | Plusvalías | GovTech | FastAPI | 25 | Ley 21.713 |

### Diagrama de Relaciones entre Módulos

```
                              ┌─────────┐
                              │   M00   │
                              │Expediente│
                              └────┬────┘
                                   │
                              ┌────┴────┐
                              │   M01   │
                              │  Ficha  │
                              └────┬────┘
                                   │
        ┌──────────────────────────┼──────────────────────────┐
        │                          │                          │
   ┌────┴────┐                ┌────┴────┐                ┌────┴────┐
   │   M02   │                │   M04   │                │   M12   │
   │Copropied│                │Valoriza.│                │   DD    │
   └────┬────┘                └────┬────┘                └────┬────┘
        │                          │                          │
   ┌────┴────┐                ┌────┴────┐                     │
   │   M11   │                │   M03   │                     │
   │   PAE   │                │ Credit  │◄────────────────────┘
   └────┬────┘                └────┬────┘
        │                          │
        │                     ┌────┴────┐
        │                     │   M13   │
        │                     │Garantías│
        │                     └────┬────┘
        │                          │
        └──────────────────────────┼──────────────────────────┐
                                   │                          │
                              ┌────┴────┐                ┌────┴────┐
                              │   M16   │                │   M08   │
                              │Basel IV │                │Contabil.│
                              └─────────┘                └─────────┘
```

---

## Flujos de Datos

### Flujo Principal: Expediente → Basel IV

```
┌─────────────────────────────────────────────────────────────────────┐
│                    FLUJO PRINCIPAL DE NEGOCIO                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  1. CREAR         2. REGISTRAR       3. VALORIZAR                   │
│  EXPEDIENTE       PROPIEDAD          ACTIVO                         │
│  ┌─────────┐      ┌─────────┐        ┌─────────┐                    │
│  │   M00   │─────▶│   M01   │───────▶│   M04   │                    │
│  │         │      │         │        │   ML    │                    │
│  └─────────┘      └─────────┘        └────┬────┘                    │
│                                           │                          │
│  4. EVALUAR       5. REGISTRAR       6. VALIDAR                     │
│  RIESGO           GARANTÍA           REGULACIÓN                     │
│  ┌─────────┐      ┌─────────┐        ┌─────────┐                    │
│  │   M03   │◀─────│   M13   │◀───────│   M16   │                    │
│  │ Credit  │      │         │        │Basel IV │                    │
│  └────┬────┘      └─────────┘        └─────────┘                    │
│       │                                                              │
│       ▼                                                              │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    OUTPUTS                                    │   │
│  │  • Credit Score (300-850)                                    │   │
│  │  • Risk Grade (AAA - D)                                      │   │
│  │  • PD, LGD, EAD                                              │   │
│  │  • RWA (Risk Weighted Assets)                                │   │
│  │  • Compliance Status                                         │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

### Flujo PAE (Precession Analysis)

```
┌─────────────────────────────────────────────────────────────────────┐
│                    FLUJO PAE ANALYSIS                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  INPUT DATA                   PROCESSING                  OUTPUT    │
│  ──────────                   ──────────                  ──────    │
│                                                                      │
│  ┌──────────┐                ┌───────────┐              ┌────────┐ │
│  │Morosidad │───┐            │   GRAPH   │              │ Score  │ │
│  └──────────┘   │            │  ENGINE   │              │ Total  │ │
│                 │            │           │              │ 0-100  │ │
│  ┌──────────┐   │  ┌─────┐   │ • Build   │  ┌─────┐    └────────┘ │
│  │ Gastos   │───┼─▶│Nodes│──▶│   graph   │─▶│Score│─┐             │
│  └──────────┘   │  └─────┘   │ • Calc    │  └─────┘ │  ┌────────┐ │
│                 │            │   effects │           ├─▶│ Alerts │ │
│  ┌──────────┐   │  ┌─────┐   │ • Prop.   │  ┌─────┐ │  │Critical│ │
│  │ Antenas  │───┼─▶│Edges│──▶│   paths   │─▶│Trend│─┤  │ High   │ │
│  └──────────┘   │  └─────┘   │           │  └─────┘ │  │ Medium │ │
│                 │            └───────────┘           │  └────────┘ │
│  ┌──────────┐   │                                    │             │
│  │Compliance│───┘                                    │  ┌────────┐ │
│  └──────────┘                                        └─▶│Report  │ │
│                                                         │ PDF    │ │
│                                                         └────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Seguridad

### Capas de Seguridad

```
┌─────────────────────────────────────────────────────────────────┐
│                     SECURITY LAYERS                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Layer 1: NETWORK                                               │
│  ├── WAF (Cloudflare/AWS WAF)                                   │
│  ├── DDoS Protection                                            │
│  └── IP Whitelist (APIs sensibles)                              │
│                                                                  │
│  Layer 2: TRANSPORT                                             │
│  ├── TLS 1.3 obligatorio                                        │
│  ├── mTLS para Open Finance                                     │
│  └── Certificate Pinning (mobile)                               │
│                                                                  │
│  Layer 3: API GATEWAY                                           │
│  ├── Rate Limiting (100 req/min user, 1000 req/min service)    │
│  ├── Request Validation                                         │
│  └── API Versioning                                             │
│                                                                  │
│  Layer 4: APPLICATION                                           │
│  ├── JWT + Refresh Tokens (Sanctum)                            │
│  ├── OAuth2 FAPI 2.0 (Open Finance)                            │
│  ├── RBAC (6 roles predefinidos)                               │
│  └── Input Sanitization                                         │
│                                                                  │
│  Layer 5: DATA                                                  │
│  ├── Encryption at Rest (AES-256)                              │
│  ├── Encryption in Transit (TLS)                               │
│  ├── Field-level Encryption (PII)                              │
│  └── Audit Logging                                              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Roles y Permisos

| Rol | Descripción | Permisos |
|-----|-------------|----------|
| `super_admin` | Administrador sistema | Todos |
| `admin` | Administrador tenant | CRUD completo |
| `manager` | Gerente copropiedad | Gestión operativa |
| `accountant` | Contador | Contabilidad, reportes |
| `operator` | Operador | Lectura, operaciones básicas |
| `viewer` | Visualizador | Solo lectura |

---

## Integraciones Externas

### APIs Gubernamentales Chile

| Sistema | Propósito | Módulos |
|---------|-----------|---------|
| **SII** | Información tributaria, avalúos fiscales | M14, M08 |
| **CMF** | Regulación financiera, NCG514 | M01-OF, M16 |
| **BCCH** | Indicadores económicos (UF, UTM, IPC) | M15, M04 |
| **MINVU** | Normativa urbanística, DOM | M22, GT-PV |
| **SHOA** | Datos tsunami, mareas | M17 |
| **SERNAGEOMIN** | Riesgos geológicos | M17 |
| **CONAF** | Riesgo de incendios | M17 |

### Diagrama de Integraciones

```
                              DATAPOLIS
                                  │
        ┌─────────────────────────┼─────────────────────────┐
        │                         │                         │
   ┌────┴────┐              ┌─────┴─────┐             ┌────┴────┐
   │   SII   │              │    CMF    │             │  BCCH   │
   │         │              │           │             │         │
   │• Avalúos│              │• NCG514   │             │• UF     │
   │• F29/F22│              │• Entidades│             │• UTM    │
   │• RUT    │              │• FAPI 2.0 │             │• IPC    │
   └─────────┘              └───────────┘             └─────────┘
        │                         │                         │
        │    ┌────────────────────┴────────────────────┐   │
        │    │                                         │   │
        ▼    ▼                                         ▼   ▼
   ┌─────────────────────────────────────────────────────────┐
   │                    DATA AGGREGATION                      │
   │                                                          │
   │  • Normalización de datos                               │
   │  • Validación cruzada                                   │
   │  • Cache inteligente                                    │
   │  • Fallback handling                                    │
   └─────────────────────────────────────────────────────────┘
```

---

## Apéndices

### A. Modelo de Datos Simplificado

```
Tenant (Multi-tenancy)
├── Copropiedad
│   ├── Unidad
│   │   ├── Copropietario
│   │   └── ContratoArriendo
│   ├── ContratoAntena
│   │   └── FacturaAntena
│   ├── PeriodoGasto
│   │   ├── GastoComun
│   │   └── Pago
│   ├── PrecessionAnalysis
│   │   └── PrecessionAlert
│   └── CertificadoTributario
└── User
    ├── Role
    └── Permission
```

### B. Convenciones de Código

- **PHP**: PSR-12
- **Python**: PEP 8 + Black
- **JavaScript**: ESLint + Prettier
- **SQL**: snake_case para tablas y columnas
- **API**: RESTful, versionado `/api/v1/`

### C. Patrones de Diseño Utilizados

1. **Repository Pattern** - Abstracción de persistencia
2. **Service Layer** - Lógica de negocio centralizada
3. **Factory Pattern** - Creación de objetos complejos
4. **Observer Pattern** - Eventos y notificaciones
5. **Strategy Pattern** - Algoritmos intercambiables (scoring, valorización)

---

**DATAPOLIS v3.0** | Documentación de Arquitectura | Versión 3.0.0
