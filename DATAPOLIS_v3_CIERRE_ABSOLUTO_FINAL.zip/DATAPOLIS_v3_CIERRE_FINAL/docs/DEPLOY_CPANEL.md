# DATAPOLIS v3.0 - Guía de Despliegue en cPanel

## Índice
1. [Requisitos Previos](#requisitos-previos)
2. [Preparación del Hosting](#preparación-del-hosting)
3. [Subir Archivos](#subir-archivos)
4. [Configurar Base de Datos](#configurar-base-de-datos)
5. [Configurar PHP](#configurar-php)
6. [Configurar Laravel](#configurar-laravel)
7. [Configurar FastAPI (Python)](#configurar-fastapi-python)
8. [Configurar Dominio y SSL](#configurar-dominio-y-ssl)
9. [Verificación Final](#verificación-final)
10. [Mantenimiento](#mantenimiento)

---

## Requisitos Previos

### Requisitos del Hosting cPanel

| Característica | Mínimo | Recomendado |
|----------------|--------|-------------|
| PHP | 8.1 | 8.2+ |
| Python | 3.9 | 3.11+ |
| PostgreSQL | 14 | 15+ |
| Espacio | 5 GB | 20+ GB |
| RAM | 2 GB | 4+ GB |
| SSL | Requerido | Let's Encrypt |

### Extensiones PHP Requeridas
- pdo_pgsql
- redis (opcional pero recomendado)
- mbstring
- xml
- curl
- zip
- bcmath
- gd
- intl

### Verificar Compatibilidad

Antes de comenzar, verifique que su hosting soporte:
1. ✅ PHP 8.1+ con acceso CLI
2. ✅ PostgreSQL (no solo MySQL)
3. ✅ Python con pip y virtualenv
4. ✅ Acceso SSH
5. ✅ Cron jobs
6. ✅ Subdominios o dominios adicionales

---

## Preparación del Hosting

### Paso 1: Acceder a cPanel

1. Ingrese a su cPanel: `https://sudominio.com:2083`
2. Use sus credenciales de hosting

### Paso 2: Crear Subdominios (Recomendado)

Navegue a **Dominios** → **Subdominios**

Crear los siguientes subdominios:

| Subdominio | Document Root |
|------------|---------------|
| `app.sudominio.com` | `/home/usuario/app.sudominio.com` |
| `api.sudominio.com` | `/home/usuario/api.sudominio.com` |

---

## Subir Archivos

### Opción A: File Manager (Archivos pequeños)

1. Ir a **Archivos** → **Administrador de archivos**
2. Navegar a `/home/usuario/`
3. Subir `DATAPOLIS_v3_Full.zip`
4. Click derecho → **Extraer**

### Opción B: FTP (Recomendado)

```bash
# Usando FileZilla o similar
Host: ftp.sudominio.com
Usuario: su_usuario_cpanel
Puerto: 21

# Subir archivos a:
/home/usuario/datapolis/
```

### Opción C: SSH + Git (Avanzado)

```bash
# Conectar via SSH
ssh usuario@sudominio.com

# Clonar o subir
cd ~
unzip DATAPOLIS_v3_Full.zip
mv DATAPOLIS_v3_Full datapolis
```

### Estructura de Archivos Final

```
/home/usuario/
├── datapolis/
│   ├── backend/
│   │   ├── fastapi/
│   │   └── laravel/
│   ├── frontend/
│   │   └── vue/dist/
│   └── docs/
├── api.sudominio.com/          # Symlink a laravel/public
└── app.sudominio.com/          # Symlink a vue/dist
```

---

## Configurar Base de Datos

### Paso 1: Crear Base de Datos PostgreSQL

1. Ir a **Bases de datos** → **PostgreSQL Databases**
2. Crear nueva base de datos:
   - Nombre: `usuario_datapolis`
3. Crear usuario:
   - Usuario: `usuario_datapolis`
   - Contraseña: (generar contraseña segura)
4. Agregar usuario a la base de datos con **TODOS los privilegios**

### Paso 2: Habilitar Extensiones PostGIS (SSH)

```bash
# Conectar via SSH
ssh usuario@sudominio.com

# Acceder a PostgreSQL
psql -U usuario_datapolis -d usuario_datapolis -h localhost

# Ejecutar (si tiene permisos):
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

# Si no tiene permisos, contacte a soporte técnico del hosting
```

### Paso 3: Importar Esquema

```bash
# Via SSH
cd ~/datapolis/backend/laravel
php artisan migrate --force

# O importar SQL directamente
psql -U usuario_datapolis -d usuario_datapolis -h localhost < database/schema.sql
```

---

## Configurar PHP

### Paso 1: Seleccionar Versión PHP

1. Ir a **Software** → **MultiPHP Manager**
2. Seleccionar dominio `api.sudominio.com`
3. Cambiar a **PHP 8.2**

### Paso 2: Configurar Extensiones PHP

1. Ir a **Software** → **Select PHP Version**
2. Seleccionar PHP 8.2
3. Habilitar extensiones:
   - ✅ pdo_pgsql
   - ✅ pgsql
   - ✅ mbstring
   - ✅ xml
   - ✅ curl
   - ✅ zip
   - ✅ bcmath
   - ✅ gd
   - ✅ intl
   - ✅ redis (si disponible)

### Paso 3: Configurar php.ini

1. Ir a **Software** → **MultiPHP INI Editor**
2. Seleccionar dominio
3. Configurar:

```ini
memory_limit = 512M
max_execution_time = 300
upload_max_filesize = 50M
post_max_size = 50M
max_input_vars = 5000
```

---

## Configurar Laravel

### Paso 1: Configurar .env

```bash
# Via SSH
cd ~/datapolis/backend/laravel

# Copiar template
cp .env.example .env

# Editar
nano .env
```

Contenido del `.env`:

```ini
APP_NAME=DATAPOLIS
APP_ENV=production
APP_KEY=
APP_DEBUG=false
APP_URL=https://api.sudominio.com

LOG_CHANNEL=daily
LOG_LEVEL=error

DB_CONNECTION=pgsql
DB_HOST=localhost
DB_PORT=5432
DB_DATABASE=usuario_datapolis
DB_USERNAME=usuario_datapolis
DB_PASSWORD=su_password_seguro

CACHE_DRIVER=file
QUEUE_CONNECTION=database
SESSION_DRIVER=file

# Si tiene Redis disponible:
# CACHE_DRIVER=redis
# REDIS_HOST=127.0.0.1
# REDIS_PASSWORD=null
# REDIS_PORT=6379
```

### Paso 2: Instalar Dependencias

```bash
cd ~/datapolis/backend/laravel

# Instalar Composer (si no está)
curl -sS https://getcomposer.org/installer | php

# Instalar dependencias
php composer.phar install --optimize-autoloader --no-dev

# Generar clave
php artisan key:generate

# Migraciones
php artisan migrate --force

# Seeders
php artisan db:seed --force

# Optimizar
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Permisos
chmod -R 755 storage bootstrap/cache
```

### Paso 3: Configurar Document Root

1. Ir a **Dominios** → **Subdominios**
2. Editar `api.sudominio.com`
3. Cambiar Document Root a:
   ```
   /home/usuario/datapolis/backend/laravel/public
   ```

### Paso 4: Crear .htaccess

Crear/verificar `/home/usuario/datapolis/backend/laravel/public/.htaccess`:

```apache
<IfModule mod_rewrite.c>
    <IfModule mod_negotiation.c>
        Options -MultiViews -Indexes
    </IfModule>

    RewriteEngine On

    # Handle Authorization Header
    RewriteCond %{HTTP:Authorization} .
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]

    # Redirect Trailing Slashes If Not A Folder...
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_URI} (.+)/$
    RewriteRule ^ %1 [L,R=301]

    # Send Requests To Front Controller...
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [L]

    # CORS Headers
    Header always set Access-Control-Allow-Origin "*"
    Header always set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
    Header always set Access-Control-Allow-Headers "Content-Type, Authorization, X-Requested-With"
</IfModule>

# PHP Settings
<IfModule mod_php.c>
    php_value upload_max_filesize 50M
    php_value post_max_size 50M
    php_value memory_limit 512M
    php_value max_execution_time 300
</IfModule>
```

---

## Configurar FastAPI (Python)

### Opción A: Usando Python App en cPanel (Si disponible)

1. Ir a **Software** → **Setup Python App**
2. Click **CREATE APPLICATION**
3. Configurar:
   - Python version: 3.11
   - Application root: `/home/usuario/datapolis/backend/fastapi`
   - Application URL: `api.sudominio.com/ml` o subdominio dedicado
   - Application startup file: `main.py`
   - Application Entry point: `app`

4. Click **CREATE**

5. Instalar dependencias:
   ```bash
   # En el terminal de la app Python
   pip install -r requirements.txt
   ```

### Opción B: Passenger WSGI (Alternativa)

Crear `/home/usuario/datapolis/backend/fastapi/passenger_wsgi.py`:

```python
import sys
import os

# Agregar el directorio al path
sys.path.insert(0, os.path.dirname(__file__))

# Activar virtualenv si existe
venv_path = os.path.join(os.path.dirname(__file__), 'venv')
if os.path.exists(venv_path):
    activate_this = os.path.join(venv_path, 'bin', 'activate_this.py')
    with open(activate_this) as f:
        exec(f.read(), {'__file__': activate_this})

# Importar la aplicación FastAPI
from main import app

# Passenger espera una variable 'application'
application = app
```

### Opción C: CGI Wrapper (Hosting básico)

Si el hosting no soporta WSGI/Passenger, crear wrapper CGI:

```bash
# Crear script CGI
nano ~/datapolis/backend/fastapi/api.cgi
```

```python
#!/usr/bin/env python3
import sys
sys.path.insert(0, '/home/usuario/datapolis/backend/fastapi')

from wsgiref.handlers import CGIHandler
from main import app

CGIHandler().run(app)
```

```bash
chmod +x ~/datapolis/backend/fastapi/api.cgi
```

### Configurar .env FastAPI

```bash
cd ~/datapolis/backend/fastapi
cp .env.example .env
nano .env
```

```ini
APP_NAME=DATAPOLIS_API
DEBUG=false
DATABASE_URL=postgresql://usuario_datapolis:password@localhost/usuario_datapolis
REDIS_URL=redis://localhost:6379/0
JWT_SECRET_KEY=su_clave_secreta_muy_larga_32_chars
```

---

## Configurar Dominio y SSL

### Paso 1: SSL con Let's Encrypt

1. Ir a **Seguridad** → **SSL/TLS Status**
2. Seleccionar todos los dominios
3. Click **Run AutoSSL**

### Paso 2: Forzar HTTPS

Agregar al `.htaccess` principal:

```apache
# Forzar HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### Paso 3: Configurar Frontend

1. Ir a **Dominios** → **Subdominios**
2. Editar `app.sudominio.com`
3. Document Root: `/home/usuario/datapolis/frontend/vue/dist`

Crear `.htaccess` en `/home/usuario/datapolis/frontend/vue/dist/`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteRule ^index\.html$ - [L]
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.html [L]
</IfModule>

# Cache static assets
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>

# Gzip compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json
</IfModule>
```

---

## Verificación Final

### Checklist de Verificación

| # | Verificación | Comando/URL | Esperado |
|---|--------------|-------------|----------|
| 1 | Laravel API | `https://api.sudominio.com/api/v1/health` | `{"status":"healthy"}` |
| 2 | Frontend | `https://app.sudominio.com` | Página de login |
| 3 | Base de datos | `php artisan migrate:status` | Todas migradas |
| 4 | SSL | Navegador | Candado verde |
| 5 | Login | POST `/auth/login` | Token JWT |

### Probar Endpoints

```bash
# Health check
curl https://api.sudominio.com/api/v1/health

# Login
curl -X POST https://api.sudominio.com/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@datapolis.cl","password":"admin123"}'

# Listar copropiedades (con token)
curl https://api.sudominio.com/api/v1/copropiedades \
  -H "Authorization: Bearer {su_token}"
```

---

## Mantenimiento

### Cron Jobs

1. Ir a **Avanzado** → **Cron Jobs**
2. Agregar las siguientes tareas:

| Frecuencia | Comando |
|------------|---------|
| Cada minuto | `cd ~/datapolis/backend/laravel && php artisan schedule:run >> /dev/null 2>&1` |
| Diario 2am | `cd ~/datapolis/backend/laravel && php artisan backup:run >> /dev/null 2>&1` |
| Diario 3am | `cd ~/datapolis/backend/laravel && php artisan queue:restart >> /dev/null 2>&1` |

### Actualizar Código

```bash
# Via SSH
cd ~/datapolis

# Backup actual
tar -czf backup_$(date +%Y%m%d).tar.gz backend frontend

# Subir nuevo código
unzip DATAPOLIS_v3_new.zip

# Actualizar Laravel
cd backend/laravel
php composer.phar install --optimize-autoloader --no-dev
php artisan migrate --force
php artisan config:cache
php artisan route:cache

# Limpiar caché
php artisan cache:clear
```

### Logs

```bash
# Ver logs Laravel
tail -f ~/datapolis/backend/laravel/storage/logs/laravel.log

# Ver logs de acceso
tail -f ~/access-logs/api.sudominio.com
```

---

## Troubleshooting cPanel

### Error 500 en Laravel

```bash
# Verificar permisos
chmod -R 755 ~/datapolis/backend/laravel/storage
chmod -R 755 ~/datapolis/backend/laravel/bootstrap/cache

# Verificar .env
cat ~/datapolis/backend/laravel/.env | grep APP_KEY
# Debe tener valor

# Regenerar clave si está vacía
php artisan key:generate

# Limpiar caché
php artisan config:clear
php artisan cache:clear
```

### Error de Base de Datos

```bash
# Verificar conexión
php artisan tinker
>>> DB::connection()->getPdo();

# Si falla, verificar credenciales en .env
```

### Python App No Inicia

1. Verificar que Python 3.9+ esté disponible
2. Verificar que `passenger_wsgi.py` existe
3. Revisar logs en **Métricas** → **Errors**

### CORS Errors

Verificar que el `.htaccess` tenga los headers CORS correctos y que `APP_URL` en `.env` sea correcto.

---

## Limitaciones de cPanel

| Limitación | Solución |
|------------|----------|
| Sin Redis | Usar `CACHE_DRIVER=file` |
| Sin PostGIS | Contactar soporte o usar hosting VPS |
| Python limitado | Usar CGI wrapper o VPS |
| Sin acceso root | Usar alternativas en userspace |

---

**DATAPOLIS v3.0** | Guía de Despliegue cPanel
