# DATAPOLIS v3.0 - Guía de Despliegue Local

## Índice
1. [Requisitos del Sistema](#requisitos-del-sistema)
2. [Instalación Rápida](#instalación-rápida)
3. [Instalación Manual](#instalación-manual)
4. [Configuración](#configuración)
5. [Verificación](#verificación)
6. [Troubleshooting](#troubleshooting)

---

## Requisitos del Sistema

### Hardware Mínimo
- CPU: 2 cores
- RAM: 4 GB
- Disco: 20 GB SSD

### Hardware Recomendado
- CPU: 4+ cores
- RAM: 8+ GB
- Disco: 50+ GB SSD

### Software Requerido

| Componente | Versión Mínima | Recomendada |
|------------|----------------|-------------|
| Ubuntu | 22.04 LTS | 24.04 LTS |
| PHP | 8.1 | 8.2+ |
| Python | 3.10 | 3.11+ |
| PostgreSQL | 14 | 15+ |
| PostGIS | 3.2 | 3.3+ |
| Redis | 6.0 | 7.0+ |
| Node.js | 18 | 20 LTS |
| Nginx | 1.18 | 1.24+ |

---

## Instalación Rápida

### Opción A: Docker Compose (Recomendado)

```bash
# Clonar o descomprimir el paquete
unzip DATAPOLIS_v3_Full.zip
cd DATAPOLIS_v3_Full

# Copiar configuración
cp .env.example .env

# Editar variables de entorno
nano .env

# Iniciar todos los servicios
docker-compose up -d

# Verificar estado
docker-compose ps

# Ver logs
docker-compose logs -f
```

El sistema estará disponible en:
- **Frontend**: http://localhost:3000
- **API Laravel**: http://localhost:8000
- **API FastAPI**: http://localhost:8001
- **API Docs**: http://localhost:8001/docs

### Opción B: Script de Instalación Automática

```bash
# Dar permisos de ejecución
chmod +x scripts/install_local.sh

# Ejecutar instalador
sudo ./scripts/install_local.sh

# Seguir las instrucciones en pantalla
```

---

## Instalación Manual

### Paso 1: Instalar Dependencias del Sistema

```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar dependencias base
sudo apt install -y \
    git curl wget unzip \
    software-properties-common \
    apt-transport-https ca-certificates

# Agregar repositorio PHP
sudo add-apt-repository ppa:ondrej/php -y

# Instalar PHP 8.2 y extensiones
sudo apt install -y \
    php8.2 php8.2-fpm php8.2-cli \
    php8.2-pgsql php8.2-redis php8.2-curl \
    php8.2-xml php8.2-mbstring php8.2-zip \
    php8.2-bcmath php8.2-gd php8.2-intl

# Instalar Composer
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer

# Instalar Python 3.11
sudo apt install -y python3.11 python3.11-venv python3-pip

# Instalar Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Instalar PostgreSQL 15 con PostGIS
sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
sudo apt update
sudo apt install -y postgresql-15 postgresql-15-postgis-3

# Instalar Redis
sudo apt install -y redis-server

# Instalar Nginx
sudo apt install -y nginx
```

### Paso 2: Configurar PostgreSQL

```bash
# Acceder a PostgreSQL
sudo -u postgres psql

# Crear usuario y base de datos
CREATE USER datapolis WITH PASSWORD 'su_password_seguro';
CREATE DATABASE datapolis_db OWNER datapolis;
GRANT ALL PRIVILEGES ON DATABASE datapolis_db TO datapolis;

# Habilitar PostGIS
\c datapolis_db
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;

# Salir
\q
```

### Paso 3: Configurar Redis

```bash
# Editar configuración
sudo nano /etc/redis/redis.conf

# Configurar (buscar y modificar):
# maxmemory 256mb
# maxmemory-policy allkeys-lru

# Reiniciar Redis
sudo systemctl restart redis-server
sudo systemctl enable redis-server
```

### Paso 4: Instalar Backend Laravel

```bash
# Ir al directorio
cd DATAPOLIS_v3_Full/backend/laravel

# Instalar dependencias
composer install --optimize-autoloader

# Copiar configuración
cp .env.example .env

# Configurar .env
nano .env
```

Contenido del `.env` Laravel:
```ini
APP_NAME=DATAPOLIS
APP_ENV=local
APP_KEY=
APP_DEBUG=true
APP_URL=http://localhost:8000

DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=datapolis_db
DB_USERNAME=datapolis
DB_PASSWORD=su_password_seguro

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

CACHE_DRIVER=redis
QUEUE_CONNECTION=redis
SESSION_DRIVER=redis

# Configuración UF
UF_API_URL=https://mindicador.cl/api
```

Continuar configuración:
```bash
# Generar clave de aplicación
php artisan key:generate

# Ejecutar migraciones
php artisan migrate

# Ejecutar seeders
php artisan db:seed

# Crear enlace simbólico para storage
php artisan storage:link

# Optimizar para producción
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### Paso 5: Instalar Backend FastAPI

```bash
# Ir al directorio
cd DATAPOLIS_v3_Full/backend/fastapi

# Crear entorno virtual
python3.11 -m venv venv
source venv/bin/activate

# Instalar dependencias
pip install --upgrade pip
pip install -r requirements.txt

# Copiar configuración
cp .env.example .env

# Configurar .env
nano .env
```

Contenido del `.env` FastAPI:
```ini
APP_NAME=DATAPOLIS_API
APP_VERSION=3.0.0
DEBUG=false
LOG_LEVEL=INFO

DATABASE_URL=postgresql://datapolis:su_password_seguro@localhost:5432/datapolis_db
REDIS_URL=redis://localhost:6379/0

JWT_SECRET_KEY=su_jwt_secret_muy_seguro_de_32_caracteres
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# ML Models Path
ML_MODELS_PATH=/var/www/datapolis/ml_models

# External APIs
SII_API_URL=https://api.sii.cl
CMF_API_URL=https://api.cmfchile.cl
BCCH_API_URL=https://si3.bcentral.cl
```

### Paso 6: Instalar Frontend

```bash
# Ir al directorio
cd DATAPOLIS_v3_Full/frontend/vue

# Instalar dependencias
npm ci

# Configurar
cp .env.example .env.local
nano .env.local
```

Contenido del `.env.local`:
```ini
VITE_API_URL=http://localhost:8000/api/v1
VITE_FASTAPI_URL=http://localhost:8001/api/v1
VITE_APP_NAME=DATAPOLIS
```

Build para producción:
```bash
npm run build
```

### Paso 7: Configurar Nginx

```bash
# Crear configuración
sudo nano /etc/nginx/sites-available/datapolis
```

Contenido del archivo Nginx:
```nginx
# Frontend Vue.js
server {
    listen 80;
    server_name datapolis.local;
    root /var/www/datapolis/frontend/vue/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /api/v1/ml {
        proxy_pass http://127.0.0.1:8001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}

# API Laravel
server {
    listen 8000;
    server_name localhost;
    root /var/www/datapolis/backend/laravel/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
```

Activar configuración:
```bash
# Crear enlace simbólico
sudo ln -s /etc/nginx/sites-available/datapolis /etc/nginx/sites-enabled/

# Verificar configuración
sudo nginx -t

# Reiniciar Nginx
sudo systemctl restart nginx
```

### Paso 8: Configurar Servicios Systemd

#### Servicio FastAPI

```bash
sudo nano /etc/systemd/system/datapolis-fastapi.service
```

```ini
[Unit]
Description=DATAPOLIS FastAPI Backend
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/var/www/datapolis/backend/fastapi
Environment="PATH=/var/www/datapolis/backend/fastapi/venv/bin"
ExecStart=/var/www/datapolis/backend/fastapi/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8001 --workers 4
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

#### Servicio Queue Worker (Laravel)

```bash
sudo nano /etc/systemd/system/datapolis-queue.service
```

```ini
[Unit]
Description=DATAPOLIS Laravel Queue Worker
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/var/www/datapolis/backend/laravel
ExecStart=/usr/bin/php artisan queue:work redis --sleep=3 --tries=3 --max-time=3600
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Activar servicios:
```bash
sudo systemctl daemon-reload
sudo systemctl enable datapolis-fastapi datapolis-queue
sudo systemctl start datapolis-fastapi datapolis-queue
```

---

## Configuración

### Variables de Entorno Críticas

| Variable | Descripción | Ejemplo |
|----------|-------------|---------|
| `DB_PASSWORD` | Contraseña PostgreSQL | `SecurePass123!` |
| `JWT_SECRET_KEY` | Clave JWT (min 32 chars) | `abc123...` |
| `APP_KEY` | Clave Laravel (auto-generada) | `base64:...` |

### Configuración de Seguridad

```bash
# Permisos de archivos
sudo chown -R www-data:www-data /var/www/datapolis
sudo chmod -R 755 /var/www/datapolis
sudo chmod -R 775 /var/www/datapolis/backend/laravel/storage
sudo chmod -R 775 /var/www/datapolis/backend/laravel/bootstrap/cache
```

---

## Verificación

### Checklist de Verificación

```bash
# 1. Verificar PostgreSQL
sudo systemctl status postgresql
psql -U datapolis -d datapolis_db -c "SELECT PostGIS_Version();"

# 2. Verificar Redis
redis-cli ping  # Debe responder: PONG

# 3. Verificar PHP-FPM
sudo systemctl status php8.2-fpm

# 4. Verificar Nginx
sudo systemctl status nginx
curl -I http://localhost

# 5. Verificar FastAPI
curl http://localhost:8001/health

# 6. Verificar Laravel
curl http://localhost:8000/api/v1/health

# 7. Verificar Frontend
curl http://localhost:3000
```

### Test de Endpoints Principales

```bash
# Login
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@datapolis.cl","password":"admin123"}'

# Listar copropiedades
curl http://localhost:8000/api/v1/copropiedades \
  -H "Authorization: Bearer {token}"

# PAE Analysis
curl -X POST http://localhost:8000/api/v1/copropiedades/1/pae/analyze \
  -H "Authorization: Bearer {token}"
```

---

## Troubleshooting

### Error: PostgreSQL Connection Refused
```bash
# Verificar que PostgreSQL esté corriendo
sudo systemctl status postgresql

# Verificar configuración de conexión
sudo nano /etc/postgresql/15/main/pg_hba.conf
# Agregar: local all datapolis md5

sudo systemctl restart postgresql
```

### Error: Redis Connection Failed
```bash
# Verificar Redis
redis-cli ping

# Si no responde, reiniciar
sudo systemctl restart redis-server
```

### Error: Permission Denied (Laravel)
```bash
sudo chown -R www-data:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
php artisan cache:clear
```

### Error: FastAPI Import Error
```bash
cd /var/www/datapolis/backend/fastapi
source venv/bin/activate
pip install -r requirements.txt --force-reinstall
```

---

## Comandos Útiles

```bash
# Reiniciar todos los servicios
sudo systemctl restart nginx php8.2-fpm datapolis-fastapi datapolis-queue

# Ver logs Laravel
tail -f /var/www/datapolis/backend/laravel/storage/logs/laravel.log

# Ver logs FastAPI
journalctl -u datapolis-fastapi -f

# Limpiar caché Laravel
php artisan cache:clear && php artisan config:clear

# Ejecutar migraciones
php artisan migrate --force
```

---

**DATAPOLIS v3.0** | Documentación de Despliegue Local
