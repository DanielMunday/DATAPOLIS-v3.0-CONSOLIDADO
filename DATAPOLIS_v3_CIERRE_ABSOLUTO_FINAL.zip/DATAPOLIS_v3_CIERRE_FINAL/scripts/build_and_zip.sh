#!/bin/bash
# ==============================================================================
# DATAPOLIS v3.0 - Script de Empaquetado para Producción
# ==============================================================================

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables
VERSION="3.0.0"
DATE=$(date +%Y%m%d_%H%M%S)
OUTPUT_DIR="DATAPOLIS_v3_Full"
ZIP_NAME="DATAPOLIS_v3_Full.zip"

echo -e "${BLUE}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║       DATAPOLIS v3.0 - Build & Package Script                 ║${NC}"
echo -e "${BLUE}║       Version: $VERSION                                          ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# ==============================================================================
# PASO 1: Verificar prerrequisitos
# ==============================================================================
echo -e "${YELLOW}[1/8] Verificando prerrequisitos...${NC}"

check_command() {
    if ! command -v $1 &> /dev/null; then
        echo -e "${RED}Error: $1 no está instalado${NC}"
        exit 1
    fi
    echo -e "  ✓ $1 encontrado"
}

check_command php
check_command composer
check_command python3
check_command pip
check_command node
check_command npm
check_command zip

echo -e "${GREEN}  Prerrequisitos verificados ✓${NC}"
echo ""

# ==============================================================================
# PASO 2: Limpiar directorio de salida
# ==============================================================================
echo -e "${YELLOW}[2/8] Preparando directorio de salida...${NC}"

rm -rf "$OUTPUT_DIR" 2>/dev/null || true
rm -f "$ZIP_NAME" 2>/dev/null || true
mkdir -p "$OUTPUT_DIR"/{backend/{fastapi,laravel},frontend/vue,docs,tests,ci,scripts}

echo -e "${GREEN}  Directorio preparado ✓${NC}"
echo ""

# ==============================================================================
# PASO 3: Instalar dependencias Laravel
# ==============================================================================
echo -e "${YELLOW}[3/8] Instalando dependencias Laravel...${NC}"

if [ -d "backend/laravel" ]; then
    cd backend/laravel
    
    # Instalar sin dependencias de desarrollo
    composer install --no-dev --optimize-autoloader --no-interaction
    
    # Optimizar para producción
    php artisan config:clear
    php artisan route:clear
    php artisan view:clear
    
    cd ../..
    
    # Copiar al directorio de salida
    cp -r backend/laravel/* "$OUTPUT_DIR/backend/laravel/"
    
    # Excluir archivos innecesarios
    rm -rf "$OUTPUT_DIR/backend/laravel/vendor/bin"
    rm -rf "$OUTPUT_DIR/backend/laravel/tests"
    rm -rf "$OUTPUT_DIR/backend/laravel/.git"
    rm -f "$OUTPUT_DIR/backend/laravel/.env"
    
    echo -e "${GREEN}  Laravel empaquetado ✓${NC}"
else
    echo -e "${YELLOW}  Directorio Laravel no encontrado, saltando...${NC}"
fi
echo ""

# ==============================================================================
# PASO 4: Instalar dependencias FastAPI
# ==============================================================================
echo -e "${YELLOW}[4/8] Instalando dependencias FastAPI...${NC}"

if [ -d "backend/fastapi" ]; then
    cd backend/fastapi
    
    # Crear entorno virtual temporal
    python3 -m venv .venv_build
    source .venv_build/bin/activate
    
    # Instalar dependencias
    pip install --upgrade pip
    pip install -r requirements.txt
    
    deactivate
    rm -rf .venv_build
    
    cd ../..
    
    # Copiar al directorio de salida
    cp -r backend/fastapi/* "$OUTPUT_DIR/backend/fastapi/"
    
    # Excluir archivos innecesarios
    rm -rf "$OUTPUT_DIR/backend/fastapi/__pycache__"
    rm -rf "$OUTPUT_DIR/backend/fastapi/.pytest_cache"
    rm -rf "$OUTPUT_DIR/backend/fastapi/.venv"
    rm -f "$OUTPUT_DIR/backend/fastapi/.env"
    
    echo -e "${GREEN}  FastAPI empaquetado ✓${NC}"
else
    echo -e "${YELLOW}  Directorio FastAPI no encontrado, saltando...${NC}"
fi
echo ""

# ==============================================================================
# PASO 5: Construir Frontend
# ==============================================================================
echo -e "${YELLOW}[5/8] Construyendo frontend Vue.js...${NC}"

if [ -d "frontend/vue" ]; then
    cd frontend/vue
    
    # Instalar dependencias
    npm ci --production=false
    
    # Build para producción
    npm run build
    
    cd ../..
    
    # Copiar solo el build
    cp -r frontend/vue/dist "$OUTPUT_DIR/frontend/vue/dist"
    cp frontend/vue/package.json "$OUTPUT_DIR/frontend/vue/"
    
    echo -e "${GREEN}  Frontend construido ✓${NC}"
else
    echo -e "${YELLOW}  Directorio frontend no encontrado, saltando...${NC}"
fi
echo ""

# ==============================================================================
# PASO 6: Ejecutar tests
# ==============================================================================
echo -e "${YELLOW}[6/8] Ejecutando tests...${NC}"

TESTS_PASSED=true

# Tests Laravel
if [ -d "backend/laravel" ] && [ -f "backend/laravel/phpunit.xml" ]; then
    cd backend/laravel
    if php vendor/bin/phpunit --no-coverage --stop-on-failure; then
        echo -e "  ${GREEN}Tests Laravel: PASSED ✓${NC}"
    else
        echo -e "  ${RED}Tests Laravel: FAILED ✗${NC}"
        TESTS_PASSED=false
    fi
    cd ../..
fi

# Tests FastAPI
if [ -d "backend/fastapi" ] && [ -d "backend/fastapi/tests" ]; then
    cd backend/fastapi
    if python3 -m pytest tests/ -v --tb=short; then
        echo -e "  ${GREEN}Tests FastAPI: PASSED ✓${NC}"
    else
        echo -e "  ${RED}Tests FastAPI: FAILED ✗${NC}"
        TESTS_PASSED=false
    fi
    cd ../..
fi

if [ "$TESTS_PASSED" = false ]; then
    echo -e "${RED}Algunos tests fallaron. ¿Continuar de todos modos? (y/N)${NC}"
    read -r response
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        echo "Build cancelado."
        exit 1
    fi
fi
echo ""

# ==============================================================================
# PASO 7: Copiar documentación y configuración
# ==============================================================================
echo -e "${YELLOW}[7/8] Copiando documentación y configuración...${NC}"

# Documentación
cp -r docs/* "$OUTPUT_DIR/docs/" 2>/dev/null || true
cp README.md "$OUTPUT_DIR/" 2>/dev/null || true

# CI/CD
cp -r ci/.github "$OUTPUT_DIR/ci/" 2>/dev/null || mkdir -p "$OUTPUT_DIR/ci/.github/workflows"

# Scripts
cp scripts/*.sh "$OUTPUT_DIR/scripts/" 2>/dev/null || true

# Archivos de configuración raíz
cp .gitignore "$OUTPUT_DIR/" 2>/dev/null || true
cp docker-compose.yml "$OUTPUT_DIR/" 2>/dev/null || true

# OpenAPI
cp backend/openapi.yaml "$OUTPUT_DIR/backend/" 2>/dev/null || true

# Crear archivo de versión
cat > "$OUTPUT_DIR/VERSION" << EOF
DATAPOLIS v$VERSION
Build Date: $DATE
Git Commit: $(git rev-parse HEAD 2>/dev/null || echo "N/A")
EOF

echo -e "${GREEN}  Documentación copiada ✓${NC}"
echo ""

# ==============================================================================
# PASO 8: Crear archivo ZIP
# ==============================================================================
echo -e "${YELLOW}[8/8] Creando archivo ZIP...${NC}"

# Calcular tamaño antes de comprimir
SIZE_BEFORE=$(du -sh "$OUTPUT_DIR" | cut -f1)

# Crear ZIP
zip -r "$ZIP_NAME" "$OUTPUT_DIR" -x "*.DS_Store" -x "*__pycache__*" -x "*.pyc"

# Calcular tamaño del ZIP
SIZE_AFTER=$(du -sh "$ZIP_NAME" | cut -f1)

echo -e "${GREEN}  ZIP creado ✓${NC}"
echo ""

# ==============================================================================
# RESUMEN FINAL
# ==============================================================================
echo -e "${BLUE}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                    BUILD COMPLETADO                           ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${GREEN}✓${NC} Versión: $VERSION"
echo -e "  ${GREEN}✓${NC} Archivo: $ZIP_NAME"
echo -e "  ${GREEN}✓${NC} Tamaño original: $SIZE_BEFORE"
echo -e "  ${GREEN}✓${NC} Tamaño comprimido: $SIZE_AFTER"
echo ""
echo -e "${GREEN}El paquete está listo para despliegue.${NC}"
echo ""

# Verificación de contenido
echo -e "${YELLOW}Contenido del paquete:${NC}"
unzip -l "$ZIP_NAME" | tail -20

echo ""
echo -e "${BLUE}Para desplegar:${NC}"
echo "  1. Local:  Ver docs/DEPLOY_LOCAL.md"
echo "  2. cPanel: Ver docs/DEPLOY_CPANEL.md"
echo ""
