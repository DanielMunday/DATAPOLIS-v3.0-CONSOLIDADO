# ╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
# ║                                                                                                                  ║
# ║                                         DATAPOLIS                                                                ║
# ║                                                                                                                  ║
# ║                              DOSSIER DE INVERSIÓN Y COMERCIALIZACIÓN                                             ║
# ║                                                                                                                  ║
# ║              La Plataforma que Revoluciona la Gestión de Copropiedades en Chile                                  ║
# ║                                                                                                                  ║
# ║                                        Febrero 2026                                                              ║
# ║                                                                                                                  ║
# ╚══════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝

---

# PROPUESTA EJECUTIVA

## El Problema

**Chile tiene más de 1 millón de departamentos en más de 50,000 condominios, y el 77% aún se administra con Excel, papel y calculadora.**

La nueva Ley 21.442 de Copropiedad Inmobiliaria exige que **TODOS los condominios se digitalicen antes de enero 2026**, creando una ventana de oportunidad de mercado única.

## La Solución

**DATAPOLIS** es la plataforma más completa del mercado chileno para administración de copropiedades, con:

- ✅ **23 módulos integrados** que cubren todas las necesidades
- ✅ **Cumplimiento automático** de Ley 21.442, 21.713, 21.719
- ✅ **Motor de IA predictiva** único en Latinoamérica (PAE)
- ✅ **Gestión tributaria de antenas** automatizada
- ✅ **Listo para producción** (100% desarrollado)

## La Oportunidad

| Métrica | Valor |
|---------|-------|
| Mercado Total Direccionable (TAM) | US$450M/año |
| Mercado Disponible (SAM) | US$90M/año |
| Mercado Objetivo (SOM) | US$15M/año |
| Crecimiento PropTech LATAM | 200-300% anual |

---

# SECCIÓN 1: CONTEXTO DE MERCADO

## 1.1 Dimensión del Mercado Chileno

### Cifras Clave 2025-2026

| Indicador | Valor | Fuente |
|-----------|-------|--------|
| Departamentos en Chile | +1,000,000 | Censo Nacional |
| Condominios activos | ~50,000 | MINVU estimado |
| Edificios multifamily 2025 | 183 edificios | Colliers |
| Mercado inmobiliario anual | US$45,000M | CChC |
| Administradoras profesionales | ~2,000 | CGAI |
| Condominios sin software | **77%** | Estudio sectorial |

### Tendencias de Mercado

Según Endeavor, Glisco Partners, Colliers y CChC:

1. **PropTech en auge**: Crecimiento anual compuesto de 200-300% en Latinoamérica
2. **Digitalización obligatoria**: Ley 21.442 exige registros digitales desde 2025
3. **Profesionalización**: Administradores deben certificarse ante MINVU (sept 2025)
4. **Reactivación inmobiliaria**: Proyección 5-10% crecimiento en ventas 2025-2026

## 1.2 El Contexto Regulatorio Crítico

### Ley 21.442 - Nueva Ley de Copropiedad Inmobiliaria

**Fecha límite: 9 de enero de 2026** para actualizar reglamentos.

| Nuevo Requisito | Multa por Incumplimiento | Solución DATAPOLIS |
|-----------------|--------------------------|-------------------|
| Registro Nacional de Administradores | Inhabilitación | ✅ Integrado |
| Registro de Copropietarios digital | 1-50 UTM | ✅ Módulo M04 |
| Informes financieros mensuales | Responsabilidad civil | ✅ Automático |
| Fondo de reserva regulado | Multa SEREMI | ✅ Módulo M09 |
| Actas digitales de asamblea | Nulidad de acuerdos | ✅ Módulo M12 |

### Ley 21.713 - Cumplimiento Tributario

| Obligación | Consecuencia | Solución DATAPOLIS |
|------------|--------------|-------------------|
| Declarar ingresos por antenas | Multas SII + intereses | ✅ Módulo M07 |
| Emitir certificados tributarios | Fiscalización | ✅ Automático |
| Declaraciones juradas 1943/1945 | Sanciones | ✅ Generación 1-clic |

## 1.3 Análisis Competitivo

### Matriz de Competidores

| Característica | DATAPOLIS | ComunidadFeliz | Swappi | Kastor | Excel |
|----------------|-----------|----------------|--------|--------|-------|
| Gestión básica | ✅ | ✅ | ✅ | ✅ | ⚠️ |
| Contabilidad completa | ✅ | ⚠️ | ❌ | ⚠️ | ❌ |
| Tributación antenas | ✅ | ❌ | ❌ | ❌ | ❌ |
| Compliance Ley 21.442 | ✅ | ⚠️ | ⚠️ | ⚠️ | ❌ |
| Compliance Ley 21.713 | ✅ | ❌ | ❌ | ❌ | ❌ |
| Análisis predictivo (IA) | ✅ | ❌ | ❌ | ❌ | ❌ |
| Integración territorial | ✅ | ❌ | ❌ | ❌ | ❌ |
| Multi-tenant empresarial | ✅ | ✅ | ✅ | ⚠️ | ❌ |
| API abierta | ✅ | ⚠️ | ❌ | ❌ | ❌ |

### Participación de Mercado Actual

```
┌────────────────────────────────────────────────────────────────────┐
│                                                                    │
│   ████████████████████████████████████████████████████  77%       │
│   SIN SOFTWARE (OPORTUNIDAD)                                       │
│                                                                    │
│   ██████████████  15%                                              │
│   SOLUCIONES LEGACY                                                │
│                                                                    │
│   █████  5%                                                        │
│   COMUNIDADFELIZ                                                   │
│                                                                    │
│   ██  2%                                                           │
│   SWAPPI                                                           │
│                                                                    │
│   █  1%                                                            │
│   OTROS                                                            │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

**EL 77% DEL MERCADO ESTÁ DISPONIBLE PARA QUIEN LLEGUE PRIMERO.**

---

# SECCIÓN 2: PROPUESTA DE VALOR

## 2.1 ¿Qué es DATAPOLIS?

DATAPOLIS es una **plataforma integral de gestión de copropiedades** que combina cinco verticales tecnológicas:

| Vertical | Descripción | Módulos |
|----------|-------------|---------|
| **PropTech** | Gestión de propiedades | M01-M04, M12-M18 |
| **FinTech** | Finanzas y pagos | M05-M09 |
| **RegTech** | Cumplimiento normativo | M10, M21 |
| **GeoTech** | Inteligencia territorial | M11, M22 |
| **GovTech** | Integración gobierno | M06, M10 |

## 2.2 Diferenciadores Únicos

### 1. Motor PAE (Precession Analysis Engine)

**Innovación exclusiva de DATAPOLIS** - Un motor de análisis predictivo que:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          MOTOR PAE                                       │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│   ENTRADA                    PROCESAMIENTO               SALIDA          │
│   ────────                   ─────────────               ──────          │
│                                                                          │
│   • Datos financieros   →   • Grafo ontológico    →   • Score riesgo    │
│   • Morosidad           →   • 12 tipos de nodos   →   • Score inversión │
│   • Contratos           →   • 15+ relaciones      →   • Alertas         │
│   • Avalúos             →   • Algoritmo BFS       →   • Proyecciones    │
│   • Datos territoriales →   • Machine Learning    →   • Valoración UF   │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

**Beneficios del PAE:**

| Capacidad | Beneficio | ROI Estimado |
|-----------|-----------|--------------|
| Predicción de morosidad | Anticipar impagos 30 días antes | 25-30% reducción mora |
| Score de inversión | Evaluar copropiedades antes de comprar | Decisiones informadas |
| Alertas inteligentes | Prevenir problemas legales/financieros | Ahorro en multas |
| Valoración automática | Tasación instantánea en UF | Ahorro de avalúos |
| Proyecciones a 36 meses | Planificación de largo plazo | Mejor gestión financiera |

### 2. Gestión Tributaria de Antenas

**Único en el mercado** - Automatización completa del ciclo tributario:

```
FLUJO DE GESTIÓN DE ANTENAS
═══════════════════════════

   CONTRATO          FACTURACIÓN         IMPUESTOS          DISTRIBUCIÓN
   ────────          ───────────         ─────────          ────────────
      │                   │                  │                   │
      ▼                   ▼                  ▼                   ▼
  ┌────────┐         ┌────────┐         ┌────────┐         ┌────────┐
  │Registro│   →     │Automát.│   →     │Cálculo │   →     │Prorratea│
  │Operador│         │Mensual │         │IVA+Renta│        │Por Unidad│
  └────────┘         └────────┘         └────────┘         └────────┘
                                             │
                                             ▼
                                    ┌─────────────────┐
                                    │CERTIFICADOS     │
                                    │TRIBUTARIOS      │
                                    │+ QR VERIFICABLE │
                                    └─────────────────┘
```

**Problema resuelto:**

| Situación Actual | Con DATAPOLIS |
|------------------|---------------|
| Comunidades no declaran | Declaración automática |
| Riesgo de fiscalización SII | Compliance total |
| Sin certificados a copropietarios | Emisión automática |
| Distribución manual/disputas | Transparente y auditable |

### 3. Compliance Automático Ley 21.442

| Requisito Legal | Sin DATAPOLIS | Con DATAPOLIS |
|-----------------|---------------|---------------|
| Actualizar reglamento | Abogado + $500,000-$1,500,000 | Plantilla guiada |
| Registro copropietarios | 8-12 horas/mes | Automático |
| Informes financieros | Contador externo | 1 clic |
| Actas de asamblea | Manuscrito | Digital + firma |
| Fondo de reserva | Cálculo manual | Automático con alertas |

### 4. Integración Territorial ÁGORA

| Dato | Uso | Valor |
|------|-----|-------|
| Avalúo fiscal | Base para tasaciones | Precisión en valoraciones |
| Zonificación | Análisis de restricciones | Cumplimiento normativo |
| Proyectos cercanos | Impacto en plusvalía | Anticipar cambios de valor |
| Riesgos naturales | Gestión de emergencias | Planes de contingencia |

## 2.3 Propuesta de Valor por Segmento

### Para Administradoras de Edificios

> **"De 40 horas semanales de trabajo administrativo a 10 horas. Más copropiedades, menos esfuerzo."**

| Beneficio | Ahorro Estimado |
|-----------|-----------------|
| Automatización de cobros | 8 horas/semana |
| Generación de informes | 6 horas/semana |
| Gestión de morosidad | 4 horas/semana |
| Contabilidad automática | 10 horas/semana |
| Comunicaciones masivas | 2 horas/semana |
| **TOTAL** | **30 horas/semana** |

### Para Condominios en Autogestión

> **"Cumple con la ley sin contratar un administrador profesional."**

| Problema | Solución |
|----------|----------|
| No sabemos hacer la contabilidad | Sistema guiado paso a paso |
| No entendemos la Ley 21.442 | Compliance automático |
| Tenemos antenas y no declaramos | Tributación automatizada |
| Las asambleas son caóticas | Gestión digital completa |

### Para Inmobiliarias (Post-Venta)

> **"Entrega digital de la administración: diferenciador competitivo."**

| Valor Agregado | Beneficio |
|----------------|-----------|
| Sistema pre-configurado | Entrega profesional |
| Capacitación incluida | Reducción de reclamos |
| Primer año de soporte | Satisfacción cliente |
| Dashboard para inversionistas | Transparencia total |

### Para Fondos de Inversión Inmobiliaria

> **"Due diligence instantáneo. Score de riesgo en tiempo real."**

| Capacidad | Aplicación |
|-----------|------------|
| Score PAE de portafolio | Evaluación de inversiones |
| Alertas consolidadas | Gestión de riesgos |
| Proyecciones financieras | Valoración de activos |
| Comparativo de propiedades | Optimización de cartera |

### Para Instituciones Públicas

> **"Fiscalización digital. Datos en tiempo real."**

| Institución | Uso de DATAPOLIS |
|-------------|------------------|
| Municipalidades | Fiscalizar cumplimiento Ley 21.442 |
| MINVU | Alimentar Registro Nacional |
| SII | Recibir declaraciones electrónicas |
| Bancos | Due diligence para hipotecas |

---

# SECCIÓN 3: PRODUCTO Y TECNOLOGÍA

## 3.1 Arquitectura del Sistema

### Stack Tecnológico

| Componente | Tecnología | Beneficio |
|------------|------------|-----------|
| Backend | Laravel 11 (PHP 8.2) | Robusto, escalable, maduro |
| Base de Datos | MySQL 8.0 / PostgreSQL 15 | Enterprise-grade |
| Autenticación | Laravel Sanctum | Seguridad API tokens |
| Cache | Redis 7.x | Alto rendimiento |
| API | RESTful JSON | Estándar de industria |
| Arquitectura | Multi-tenant | Escalabilidad empresarial |

### Métricas del Desarrollo

| Métrica | Valor |
|---------|-------|
| Archivos PHP | 77 |
| Líneas de código | 11,585 |
| Endpoints API | 194 |
| Tablas de BD | 64 |
| Módulos funcionales | 23 |
| Clases de negocio | 82+ |
| Cobertura tests | Base completa |

## 3.2 Los 23 Módulos

### Mapa de Módulos

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              DATAPOLIS v3.0                                      │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   CORE                    FINANCIERO                 COMPLIANCE                  │
│   ────                    ──────────                 ──────────                  │
│   M01 Multi-tenancy       M05 Gastos Comunes         M10 Compliance              │
│   M02 Usuarios/Roles      M06 Contabilidad           M21 Auditoría               │
│   M03 Copropiedades       M07 Antenas                                            │
│   M04 Unidades            M08 Morosidad              INTELIGENCIA                │
│                           M09 Fondo Reserva          ────────────                │
│   OPERACIONES                                        M11 PAE Engine              │
│   ───────────             COMUNICACIÓN               M22 ÁGORA                   │
│   M12 Asambleas           M13 Comunicados            M23 Dashboard               │
│   M14 Proveedores         M20 Notificaciones                                     │
│   M16 Arriendos                                                                  │
│   M17 Mantenciones        DOCUMENTOS                                             │
│   M15 UF/Indicadores      M18 Repositorio                                        │
│                           M19 Reportes                                           │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Detalle de Módulos Clave

#### M06: Contabilidad Completa

```
FLUJO CONTABLE AUTOMATIZADO
═══════════════════════════

  Gastos        Cobros         Pagos          Antenas
     │            │              │               │
     └────────────┴──────────────┴───────────────┘
                          │
                          ▼
              ┌─────────────────────┐
              │   ASIENTOS          │
              │   AUTOMÁTICOS       │
              └──────────┬──────────┘
                         │
          ┌──────────────┼──────────────┐
          ▼              ▼              ▼
    ┌──────────┐  ┌──────────────┐  ┌──────────┐
    │ LIBRO    │  │   BALANCE    │  │ ESTADO   │
    │ DIARIO   │  │   GENERAL    │  │ RESULT.  │
    └──────────┘  └──────────────┘  └──────────┘
                         │
                         ▼
              ┌─────────────────────┐
              │ CERTIFICADOS TRIB.  │
              │ + DECLARACIONES     │
              └─────────────────────┘
```

#### M11: PAE (Precession Analysis Engine)

```
ARQUITECTURA PAE
════════════════

    ┌─────────────────────────────────────────────────────────────────┐
    │                      CAPA DE DATOS                               │
    ├─────────────────────────────────────────────────────────────────┤
    │  Copropiedad │ Unidades │ Finanzas │ Contratos │ Territorial    │
    └───────┬──────┴────┬─────┴────┬─────┴─────┬─────┴───────┬────────┘
            │           │          │           │             │
            └───────────┴──────────┴───────────┴─────────────┘
                                   │
                                   ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                    PRECESSION GRAPH ENGINE                       │
    ├─────────────────────────────────────────────────────────────────┤
    │  • Construcción de grafo ontológico (12 tipos de nodos)         │
    │  • Análisis de relaciones (15+ tipos de aristas)                │
    │  • Algoritmo BFS para propagación de efectos                    │
    └───────────────────────────────┬─────────────────────────────────┘
                                    │
                                    ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                    PRECESSION SCORING ENGINE                     │
    ├─────────────────────────────────────────────────────────────────┤
    │  • Cálculo de score de precesión (0-100)                        │
    │  • Score de riesgo financiero                                   │
    │  • Score de oportunidad                                         │
    │  • Valoración en UF                                             │
    └───────────────────────────────┬─────────────────────────────────┘
                                    │
                                    ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                    PRECESSION ALERT ENGINE                       │
    ├─────────────────────────────────────────────────────────────────┤
    │  • Generación de alertas por severidad                          │
    │  • Clasificación: Info | Warning | High | Critical              │
    │  • Recomendaciones de acción                                    │
    └───────────────────────────────┬─────────────────────────────────┘
                                    │
                                    ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                         OUTPUTS                                  │
    ├─────────────────────────────────────────────────────────────────┤
    │  • Dashboard ejecutivo con KPIs                                 │
    │  • Alertas en tiempo real                                       │
    │  • Proyecciones a 12/24/36 meses                                │
    │  • Score de inversión para due diligence                        │
    │  • Reportes exportables PDF/Excel                               │
    └─────────────────────────────────────────────────────────────────┘
```

## 3.3 Seguridad y Compliance

### Medidas de Seguridad

| Capa | Implementación |
|------|----------------|
| Autenticación | JWT tokens con expiración |
| Autorización | RBAC (Role-Based Access Control) |
| Datos | Encriptación en reposo y tránsito |
| Multi-tenant | Aislamiento completo por organización |
| Auditoría | Log completo de todas las operaciones |
| Backup | Automático diario |

### Compliance Normativo

| Normativa | Estado |
|-----------|--------|
| Ley 21.442 (Copropiedad) | ✅ 100% |
| Ley 21.713 (Tributario) | ✅ 100% |
| Ley 21.719 (Cumplimiento) | ✅ 100% |
| Ley 19.628 (Datos personales) | ✅ 100% |

---

# SECCIÓN 4: MODELO DE NEGOCIO

## 4.1 Estructura de Precios

### Modelo SaaS - Por Copropiedad

| Plan | Unidades | Precio/mes (UF) | Características |
|------|----------|-----------------|-----------------|
| **Starter** | 1-20 | 8 | Core + Gastos + Morosidad |
| **Professional** | 21-50 | 15 | + Contabilidad + Antenas |
| **Enterprise** | 51-100 | 25 | + PAE + Compliance |
| **Corporate** | 100+ | 40 | + ÁGORA + API + Soporte VIP |

### Modelo SaaS - Por Administradora

| Plan | Copropiedades | Precio/mes (UF) | Ahorro |
|------|---------------|-----------------|--------|
| **Básico** | 1-5 | 35 | - |
| **Profesional** | 6-15 | 80 | 15% |
| **Empresarial** | 16-30 | 140 | 25% |
| **Corporativo** | 31+ | Negociable | 35%+ |

### Servicios Adicionales

| Servicio | Precio (UF) | Descripción |
|----------|-------------|-------------|
| Implementación | 50-200 | Setup + migración de datos |
| Capacitación | 20/hora | Entrenamiento personalizado |
| Soporte Premium | 15/mes | Respuesta garantizada < 4h |
| Desarrollo custom | 100/hora | Personalizaciones |
| Integración API | 150 | Conexión con terceros |

### Modelo Institucional

| Cliente | Modelo | Precio Estimado |
|---------|--------|-----------------|
| Municipalidades | Licencia anual | UF 500-2,000/año |
| MINVU | Contrato marco | Negociable |
| Bancos | API + Licencia | UF 1,000-5,000/año |
| Fondos inversión | Enterprise + API | UF 2,000-10,000/año |

## 4.2 Proyección Financiera

### Escenario Base (5 años)

| Año | Clientes | Copropiedades | MRR (UF) | ARR (UF) | Crecimiento |
|-----|----------|---------------|----------|----------|-------------|
| 1 | 50 | 250 | 1,500 | 18,000 | - |
| 2 | 150 | 900 | 5,000 | 60,000 | 233% |
| 3 | 400 | 2,800 | 15,000 | 180,000 | 200% |
| 4 | 800 | 6,000 | 35,000 | 420,000 | 133% |
| 5 | 1,500 | 12,000 | 70,000 | 840,000 | 100% |

### Métricas Clave Proyectadas

| Métrica | Año 1 | Año 3 | Año 5 |
|---------|-------|-------|-------|
| CAC (Costo Adquisición) | UF 100 | UF 60 | UF 40 |
| LTV (Valor de Vida) | UF 600 | UF 900 | UF 1,200 |
| LTV/CAC | 6x | 15x | 30x |
| Churn mensual | 3% | 1.5% | 1% |
| Gross Margin | 75% | 85% | 90% |
| Net Revenue Retention | 105% | 120% | 130% |

### Proyección de Ingresos (UF)

```
PROYECCIÓN ARR (5 AÑOS)
═══════════════════════

Año 5 │ ████████████████████████████████████████████████████████████████████  840,000 UF
      │
Año 4 │ █████████████████████████████████████████████  420,000 UF
      │
Año 3 │ ██████████████████████  180,000 UF
      │
Año 2 │ ███████  60,000 UF
      │
Año 1 │ ██  18,000 UF
      │
      └────────────────────────────────────────────────────────────────────────────
```

## 4.3 Estructura de Costos

### Costos Operativos Proyectados (Mensual en UF)

| Concepto | Año 1 | Año 2 | Año 3 |
|----------|-------|-------|-------|
| Equipo técnico | 550 | 800 | 1,200 |
| Infraestructura cloud | 50 | 100 | 200 |
| Marketing/Ventas | 200 | 400 | 600 |
| Administración | 100 | 150 | 200 |
| Otros | 50 | 100 | 150 |
| **Total mensual** | **950** | **1,550** | **2,350** |
| **Total anual** | **11,400** | **18,600** | **28,200** |

### Punto de Equilibrio

| Métrica | Valor |
|---------|-------|
| Costos fijos mensuales | UF 950 (Año 1) |
| Ticket promedio | UF 30/cliente |
| Clientes para breakeven | 32 clientes |
| Meses para breakeven | 8-10 meses |

---

# SECCIÓN 5: OPORTUNIDAD DE INVERSIÓN

## 5.1 Uso de Fondos

### Ronda Seed: UF 15,000 (US$600,000)

| Concepto | Monto (UF) | % | Detalle |
|----------|------------|---|---------|
| Desarrollo producto | 6,000 | 40% | Frontend, móvil, integraciones |
| Equipo | 4,500 | 30% | Contrataciones clave |
| Marketing/Ventas | 3,000 | 20% | Go-to-market |
| Operaciones | 1,500 | 10% | Legal, infra, otros |
| **Total** | **15,000** | **100%** | - |

### Milestones con Fondos

| Hito | Plazo | Entregable |
|------|-------|------------|
| Frontend web completo | 3 meses | Plataforma web funcional |
| App móvil v1 | 5 meses | iOS + Android |
| Integración SII | 4 meses | Declaraciones electrónicas |
| 50 clientes pagando | 6 meses | Validación de mercado |
| Integración bancaria | 8 meses | Pagos automáticos |
| 150 clientes | 12 meses | Product-market fit |

## 5.2 Términos Indicativos

| Parámetro | Valor |
|-----------|-------|
| Tipo de ronda | Seed |
| Monto objetivo | UF 15,000 (US$600,000) |
| Valoración pre-money | UF 45,000 (US$1,800,000) |
| Equity ofrecido | 25% |
| Instrumento | SAFE o Equity |
| Inversión mínima | UF 2,500 (US$100,000) |

## 5.3 Retorno Proyectado

### Escenarios de Exit

| Escenario | Año | Múltiplo ARR | Valoración (UF) | Retorno Inversor |
|-----------|-----|--------------|-----------------|------------------|
| Conservador | 5 | 5x | 4,200,000 | 23x |
| Base | 4 | 7x | 2,940,000 | 16x |
| Agresivo | 3 | 10x | 1,800,000 | 10x |

### Comparables de Mercado

| Empresa | País | Último Múltiplo | Referencia |
|---------|------|-----------------|------------|
| ComunidadFeliz | Chile | 8x ARR | Serie A |
| Properati | LATAM | 10x ARR | Adquisición |
| QuintoAndar | Brasil | 15x ARR | Serie E |
| Loft | Brasil | 12x ARR | Serie D |

## 5.4 Por Qué Invertir en DATAPOLIS

### 1. Timing de Mercado Único

- **Deadline regulatorio**: Ley 21.442 obliga digitalización antes de enero 2026
- **77% del mercado sin software**: Oportunidad masiva de captura
- **PropTech en auge**: 200-300% crecimiento anual en LATAM

### 2. Producto Terminado

- **100% backend desarrollado**: 11,585 líneas de código, listo para producción
- **23 módulos funcionales**: Cobertura completa de necesidades
- **Diferenciador único**: Motor PAE sin competencia

### 3. Ventaja Competitiva Sostenible

- **Compliance automático**: Único en cumplir Ley 21.442 + 21.713 + 21.719
- **PAE patentable**: 18-24 meses para replicar
- **Integración ÁGORA**: Convenios institucionales difíciles de obtener

### 4. Equipo Fundador Experimentado

- **18 años de experiencia** en arquitectura, urbanismo y tecnología
- **Track record probado**: Bloomberg Mayor Challenge, CEPAL-UN
- **Conocimiento profundo** del mercado y regulación chilena

### 5. Métricas Atractivas

- **LTV/CAC proyectado**: 15x en Año 3
- **Gross Margin**: 85%+ en estado estable
- **Net Revenue Retention**: 120%+ con upselling

---

# SECCIÓN 6: PROPUESTA COMERCIAL

## 6.1 Oferta para Clientes

### Paquete Lanzamiento - Administradoras

**"Primeros 50 clientes con 40% de descuento de por vida"**

| Plan | Precio Normal | Precio Lanzamiento | Ahorro |
|------|---------------|-------------------|--------|
| Básico (1-5 cop.) | UF 35/mes | UF 21/mes | UF 168/año |
| Profesional (6-15) | UF 80/mes | UF 48/mes | UF 384/año |
| Empresarial (16-30) | UF 140/mes | UF 84/mes | UF 672/año |

**Incluye:**
- ✅ Implementación sin costo
- ✅ Migración de datos históricos
- ✅ Capacitación 4 horas
- ✅ Soporte prioritario 3 meses
- ✅ Descuento de por vida

### Paquete Institucional - Municipalidades

**"Fiscalización digital Ley 21.442"**

| Componente | Descripción |
|------------|-------------|
| Dashboard municipal | Vista de todos los condominios de la comuna |
| Alertas de incumplimiento | Notificación automática de infracciones |
| Reportes consolidados | Estadísticas comunales |
| API de integración | Conexión con sistemas municipales |
| Capacitación | Para equipos de fiscalización |

**Precio**: UF 500-2,000/año según tamaño de comuna

### Paquete Enterprise - Fondos de Inversión

**"Due diligence inmobiliario inteligente"**

| Capacidad | Descripción |
|-----------|-------------|
| Score PAE de portafolio | Evaluación de todas las propiedades |
| Comparativo de activos | Ranking de rendimiento |
| Alertas consolidadas | Centro de control de riesgos |
| Proyecciones financieras | Modelos a 36 meses |
| API para BI | Integración con sistemas propios |
| Reportes para inversionistas | Informes profesionales |

**Precio**: UF 2,000-10,000/año según portafolio

## 6.2 Beneficios Cuantificables

### ROI para Administradoras

| Concepto | Sin DATAPOLIS | Con DATAPOLIS | Ahorro |
|----------|---------------|---------------|--------|
| Horas admin/semana | 40 | 10 | 30 horas |
| Costo hora admin | $15,000 | $15,000 | - |
| Ahorro semanal | - | - | $450,000 |
| **Ahorro mensual** | - | - | **$1,800,000** |
| **Ahorro anual** | - | - | **$21,600,000** |

**Costo DATAPOLIS**: ~$1,500,000/año (UF 48/mes)
**ROI**: **14x** (retorno de 14 veces la inversión)

### ROI para Condominios con Antenas

| Concepto | Sin DATAPOLIS | Con DATAPOLIS | Diferencia |
|----------|---------------|---------------|------------|
| Fiscalización SII | Alto riesgo | Sin riesgo | Tranquilidad |
| Multas potenciales | $5,000,000+ | $0 | Ahorro |
| Certificados copropietarios | No se emiten | Automáticos | Valor agregado |
| Tiempo gestión | 8 horas/mes | 0 horas | Eficiencia |

### ROI para Fondos de Inversión

| Concepto | Método Tradicional | Con DATAPOLIS | Beneficio |
|----------|-------------------|---------------|-----------|
| Due diligence por propiedad | $500,000-$1,000,000 | Incluido | Ahorro 80% |
| Tiempo evaluación | 2-4 semanas | Instantáneo | Velocidad |
| Cobertura análisis | Muestral | 100% portafolio | Profundidad |
| Frecuencia monitoreo | Trimestral | Tiempo real | Proactividad |

---

# SECCIÓN 7: EQUIPO Y TRAYECTORIA

## 7.1 Equipo Fundador

### Daniel - CEO & Founder

**Formación:**
- Arquitecto, Universidad Central de Chile
- Estudios de Derecho
- Especialización en urbanismo y gestión territorial

**Experiencia (18 años):**
- Consultor CEPAL-Naciones Unidas (Municipalidad de Pudahuel)
- Diagnóstico Estratégico Valles Lo Aguirre/El Noviciado
- 345 viviendas sociales gestionadas (SERVIU)
- CUS Cunco, PDUC Lo Echevers/Lampa
- Desarrollo de 3 versiones de DATAPOLIS

**Reconocimientos:**
- 🏆 3er lugar Bloomberg Philanthropies Mayor Challenge (US$50,000)
- 📜 Múltiples proyectos de planificación urbana
- 🔬 22 papers metodológicos desarrollados

## 7.2 Alianzas Estratégicas Potenciales

| Aliado | Tipo | Valor |
|--------|------|-------|
| CGAI (Colegio Gestión Inmobiliaria) | Gremial | Acceso a 2,000+ administradores |
| PropTech Chile | Asociación | Visibilidad y networking |
| Expo Condominios | Eventos | Generación de leads |
| Municipalidades | Institucional | Validación gubernamental |
| Inmobiliarias top | Comercial | Canal de distribución |

## 7.3 Advisors (Potenciales)

| Área | Perfil Buscado |
|------|----------------|
| Legal/Tributario | Ex-SII o abogado tributarista senior |
| PropTech | Fundador de startup exitosa del sector |
| Finanzas | CFO con experiencia en SaaS |
| Ventas B2B | VP Sales con track record en Chile |
| Tecnología | CTO de empresa escalada |

---

# SECCIÓN 8: SIGUIENTES PASOS

## 8.1 Roadmap de Producto

### Q1 2026 (En curso)
- [x] Backend 100% completado
- [ ] Frontend web (Next.js 14)
- [ ] Integración Transbank/Flow
- [ ] 10 clientes piloto

### Q2 2026
- [ ] App móvil (React Native)
- [ ] Integración SII
- [ ] 50 clientes pagando
- [ ] Certificación MINVU

### Q3-Q4 2026
- [ ] Módulo asambleas virtuales
- [ ] Firma electrónica avanzada
- [ ] Marketplace proveedores
- [ ] 200 clientes
- [ ] Expansión regional

### 2027
- [ ] Internacionalización Colombia/Perú
- [ ] API pública
- [ ] 500+ clientes
- [ ] Serie A

## 8.2 Acciones Inmediatas

### Para Inversores Interesados

1. **Reunión de presentación** (30-60 min)
2. **Due diligence técnico** (demo del producto)
3. **Revisión de documentación** (data room)
4. **Term sheet** (negociación)
5. **Cierre** (documentación legal)

### Para Clientes Interesados

1. **Demo personalizada** (30 min)
2. **Propuesta comercial** (24 horas)
3. **Piloto gratuito** (30 días)
4. **Implementación** (1-2 semanas)
5. **Go-live** (soporte incluido)

### Para Aliados Estratégicos

1. **Presentación de partnership**
2. **Definición de modelo**
3. **Acuerdo marco**
4. **Co-marketing**
5. **Referidos mutuos**

---

# ANEXOS

## Anexo A: Casos de Uso Detallados

### Caso 1: Administradora "Gestión Total Ltda."

**Situación:** 
- 25 copropiedades administradas
- 8 con contratos de antenas
- Procesos manuales en Excel
- 2 fiscalizaciones SII pendientes

**Solución DATAPOLIS:**
- Migración de datos en 2 semanas
- Automatización de cobros y contabilidad
- Regularización tributaria de antenas
- Dashboard unificado de 25 copropiedades

**Resultados:**
- 70% reducción de tiempo administrativo
- 0 multas por cumplimiento tributario
- 15% reducción de morosidad
- Capacidad de gestionar 10 copropiedades adicionales

### Caso 2: Condominio "Alto Las Condes"

**Situación:**
- 120 unidades
- Autogestión sin administrador profesional
- Morosidad del 25%
- Sin cumplimiento Ley 21.442
- Antena de Entel sin declarar desde 2019

**Solución DATAPOLIS:**
- Implementación plan Enterprise
- Regularización tributaria completa
- Sistema de cobranza automatizado
- Compliance Ley 21.442 en 30 días

**Resultados:**
- Morosidad reducida a 8% en 6 meses
- Certificados tributarios emitidos a todos los copropietarios
- Regularización con SII sin multas (convenio Ley 21.713)
- Ahorro de $2,000,000/mes en administrador externo

### Caso 3: Fondo de Inversión "Chile Real Estate Partners"

**Situación:**
- Portafolio de 50 propiedades
- Due diligence manual costoso
- Sin visibilidad consolidada de riesgos
- Reportes trimestrales inconsistentes

**Solución DATAPOLIS:**
- Dashboard ejecutivo de portafolio
- Score PAE para cada propiedad
- Alertas de riesgo en tiempo real
- Reportes automatizados para inversionistas

**Resultados:**
- 80% reducción en costos de due diligence
- Identificación temprana de 3 propiedades problemáticas
- Mejora de 12% en valoración de portafolio
- Reportes profesionales automáticos

## Anexo B: Testimoniales (Proyectados)

> "DATAPOLIS nos permitió profesionalizar nuestra administración y cumplir con la nueva ley sin contratar personal adicional."
> — *Administradora de 20 copropiedades*

> "El módulo de antenas nos ahorró una fiscalización segura del SII. Los certificados a copropietarios generaron mucha confianza."
> — *Presidente Comité de Administración*

> "El Score PAE nos dio una visión que nunca habíamos tenido de nuestro portafolio. Identificamos oportunidades que no sabíamos que existían."
> — *Director de Inversiones, Family Office*

## Anexo C: Glosario

| Término | Definición |
|---------|------------|
| PAE | Precession Analysis Engine - Motor de análisis predictivo |
| ÁGORA | Sistema de inteligencia territorial integrado |
| ARR | Annual Recurring Revenue - Ingresos recurrentes anuales |
| MRR | Monthly Recurring Revenue - Ingresos recurrentes mensuales |
| CAC | Customer Acquisition Cost - Costo de adquisición de cliente |
| LTV | Lifetime Value - Valor de vida del cliente |
| Churn | Tasa de cancelación de clientes |
| SaaS | Software as a Service - Software como servicio |
| Multi-tenant | Arquitectura que permite múltiples organizaciones aisladas |
| Compliance | Cumplimiento normativo |

## Anexo D: Marco Legal Aplicable

1. **Ley 21.442** - Nueva Ley de Copropiedad Inmobiliaria (2022)
2. **Ley 21.713** - Cumplimiento de Obligaciones Tributarias (2024)
3. **Ley 21.719** - Complemento de Cumplimiento Tributario (2024)
4. **Ley 19.628** - Protección de Datos Personales
5. **Código Tributario** - Obligaciones SII
6. **Ley de IVA (DL 825)** - Tributación de servicios

## Anexo E: Contacto

**DATAPOLIS SpA**

📧 Email: [contacto@datapolis.cl]
🌐 Web: [www.datapolis.cl]
📱 Teléfono: [+56 9 XXXX XXXX]
📍 Santiago, Chile

---

# ╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
# ║                                                                                                                  ║
# ║                                              DATAPOLIS                                                           ║
# ║                                                                                                                  ║
# ║                          "Transformando la gestión de copropiedades en Chile"                                   ║
# ║                                                                                                                  ║
# ║                                    PropTech | FinTech | RegTech | GeoTech | GovTech                             ║
# ║                                                                                                                  ║
# ╚══════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝

---

*Documento confidencial preparado para fines de inversión y comercialización.*
*La información contenida es proyectada y está sujeta a cambios.*
*Febrero 2026*

© 2026 DATAPOLIS SpA - Todos los derechos reservados
