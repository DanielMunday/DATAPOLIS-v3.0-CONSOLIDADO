# ══════════════════════════════════════════════════════════════════════════════
#                              DATAPOLIS v3.0
#                           EXECUTIVE SUMMARY
#                              One-Pager
# ══════════════════════════════════════════════════════════════════════════════

## LA OPORTUNIDAD

**Chile tiene +1 millón de departamentos en +50,000 condominios.**
**El 77% aún se administra con Excel y papel.**
**La Ley 21.442 obliga a digitalizarse antes de enero 2026.**

---

## LA SOLUCIÓN

**DATAPOLIS** es la plataforma más completa para gestión de copropiedades:

| Característica | Valor |
|----------------|-------|
| 23 módulos integrados | Cobertura total de necesidades |
| Motor PAE (IA predictiva) | Único en el mercado |
| Compliance automático | Ley 21.442 + 21.713 + 21.719 |
| Tributación de antenas | Automatización completa |
| 100% desarrollado | Listo para producción |

---

## MÉTRICAS CLAVE

| Desarrollo | Mercado | Proyección |
|------------|---------|------------|
| 11,585 líneas código | US$450M TAM | 233% crecimiento Año 2 |
| 194 endpoints API | 77% sin software | UF 180,000 ARR Año 3 |
| 64 tablas BD | 200-300% crecimiento PropTech | 15x LTV/CAC |

---

## MODELO DE NEGOCIO

**SaaS por suscripción mensual**

| Segmento | Ticket Promedio | Mercado |
|----------|-----------------|---------|
| Administradoras | UF 80/mes | 2,000 empresas |
| Condominios | UF 25/mes | 50,000 comunidades |
| Instituciones | UF 2,000/año | Municipios, bancos, fondos |

---

## DIFERENCIADORES ÚNICOS

1. **Motor PAE**: Análisis predictivo con ontología de 12 nodos - 18 meses para replicar
2. **Compliance total**: Único con Ley 21.442 + 21.713 automatizado
3. **Gestión de antenas**: Único que automatiza tributación completa
4. **Integración ÁGORA**: Inteligencia territorial exclusiva

---

## EQUIPO

**Daniel - CEO & Founder**
- 18 años experiencia arquitectura/urbanismo/tecnología
- Consultor CEPAL-UN
- 3er lugar Bloomberg Mayor Challenge (US$50,000)
- 345 viviendas sociales gestionadas

---

## INVERSIÓN BUSCADA

| Parámetro | Valor |
|-----------|-------|
| Ronda | Seed |
| Monto | UF 15,000 (US$600,000) |
| Valoración pre-money | UF 45,000 (US$1.8M) |
| Uso | Producto (40%), Equipo (30%), GTM (20%), Ops (10%) |

---

## PROYECCIÓN DE RETORNO

| Escenario | Año | Valoración | Retorno |
|-----------|-----|------------|---------|
| Conservador | 5 | UF 4.2M | 23x |
| Base | 4 | UF 2.9M | 16x |
| Agresivo | 3 | UF 1.8M | 10x |

---

## ¿POR QUÉ AHORA?

✅ **Timing regulatorio**: Deadline Ley 21.442 en enero 2026
✅ **Producto listo**: Backend 100% completado
✅ **Mercado masivo**: 77% sin digitalizar
✅ **Ventaja competitiva**: PAE + Compliance únicos
✅ **Equipo probado**: Track record de ejecución

---

## CONTACTO

📧 contacto@datapolis.cl
🌐 www.datapolis.cl
📍 Santiago, Chile

---

**DATAPOLIS - Transformando la gestión de copropiedades**
*PropTech | FinTech | RegTech | GeoTech | GovTech*

© 2026 DATAPOLIS SpA
