# ══════════════════════════════════════════════════════════════════════════════
#                              DATAPOLIS v3.0
#                              PITCH DECK
#                     Estructura para Presentación
# ══════════════════════════════════════════════════════════════════════════════

# SLIDE 1: PORTADA
═══════════════════════════════════════════════════════════════════════════════

                              DATAPOLIS
                                  
            La Plataforma que Revoluciona la Gestión 
                    de Copropiedades en Chile
                                  
                 PropTech | FinTech | RegTech | GeoTech | GovTech
                                  
                           Ronda Seed 2026


# SLIDE 2: EL PROBLEMA
═══════════════════════════════════════════════════════════════════════════════

    ┌─────────────────────────────────────────────────────────────────────┐
    │                                                                     │
    │     +1,000,000 departamentos en Chile                              │
    │                                                                     │
    │     +50,000 condominios activos                                    │
    │                                                                     │
    │     77% SIN SOFTWARE de gestión                                    │
    │                                                                     │
    │     Ley 21.442: OBLIGACIÓN de digitalizar antes de enero 2026      │
    │                                                                     │
    └─────────────────────────────────────────────────────────────────────┘

    PROBLEMAS ESPECÍFICOS:
    
    ❌ Administración manual con Excel y papel
    ❌ Incumplimiento de obligaciones tributarias (antenas)
    ❌ Morosidad sin control efectivo
    ❌ Asambleas caóticas sin registro digital
    ❌ Fiscalizaciones SII inminentes
    ❌ Nueva ley sin herramientas para cumplir


# SLIDE 3: LA SOLUCIÓN
═══════════════════════════════════════════════════════════════════════════════

                              DATAPOLIS
                                  
           Plataforma integral de gestión de copropiedades
                    con inteligencia artificial

    ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
    │    PropTech     │  │    FinTech      │  │    RegTech      │
    │   Propiedades   │  │    Finanzas     │  │   Compliance    │
    └─────────────────┘  └─────────────────┘  └─────────────────┘
    
    ┌─────────────────┐  ┌─────────────────┐
    │    GeoTech      │  │    GovTech      │
    │   Territorial   │  │   Gobierno      │
    └─────────────────┘  └─────────────────┘

    ✅ 23 módulos integrados
    ✅ 194 endpoints API
    ✅ 100% desarrollado y listo


# SLIDE 4: DIFERENCIADORES ÚNICOS
═══════════════════════════════════════════════════════════════════════════════

    1. MOTOR PAE (Precession Analysis Engine)
       ─────────────────────────────────────
       • Análisis predictivo con IA
       • Ontología de 12 tipos de nodos
       • Score de riesgo en tiempo real
       • Proyecciones a 36 meses
       • ÚNICO EN EL MERCADO - 18 meses para replicar

    2. COMPLIANCE AUTOMÁTICO
       ─────────────────────────────────────
       • Ley 21.442 (Copropiedad) ✓
       • Ley 21.713 (Tributario) ✓
       • Ley 21.719 (Cumplimiento) ✓
       • ÚNICO CON LAS 3 LEYES INTEGRADAS

    3. GESTIÓN DE ANTENAS
       ─────────────────────────────────────
       • Facturación automática
       • Cálculo de impuestos (IVA + Renta)
       • Certificados tributarios con QR
       • ÚNICO QUE AUTOMATIZA TRIBUTACIÓN

    4. INTEGRACIÓN ÁGORA
       ─────────────────────────────────────
       • Inteligencia territorial
       • Avalúos fiscales
       • Análisis de plusvalía
       • DATOS EXCLUSIVOS


# SLIDE 5: PRODUCTO - DEMO VISUAL
═══════════════════════════════════════════════════════════════════════════════

    ┌─────────────────────────────────────────────────────────────────────┐
    │                       DASHBOARD EJECUTIVO                           │
    ├─────────────────────────────────────────────────────────────────────┤
    │                                                                     │
    │  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐       │
    │  │ MOROSIDAD │  │ INGRESOS  │  │ COMPLIANCE│  │ SCORE PAE │       │
    │  │   8.5%    │  │ UF 1,250  │  │    95%    │  │    78     │       │
    │  │    ↓2%    │  │    ↑12%   │  │    ↑5%    │  │   MEDIO   │       │
    │  └───────────┘  └───────────┘  └───────────┘  └───────────┘       │
    │                                                                     │
    │  ┌─────────────────────────────────────────────────────────────┐   │
    │  │                    ALERTAS ACTIVAS                          │   │
    │  │  ⚠️ 3 unidades con mora >90 días                           │   │
    │  │  ⚠️ Contrato antena Entel vence en 45 días                 │   │
    │  │  ✓ Declaración DJ1943 lista para envío                     │   │
    │  └─────────────────────────────────────────────────────────────┘   │
    │                                                                     │
    └─────────────────────────────────────────────────────────────────────┘

    [Screenshots del producto en presentación real]


# SLIDE 6: MODELO DE NEGOCIO
═══════════════════════════════════════════════════════════════════════════════

    MODELO: SaaS - Suscripción Mensual
    
    ┌──────────────────────────────────────────────────────────────────┐
    │  SEGMENTO              │  TICKET        │  MERCADO              │
    ├──────────────────────────────────────────────────────────────────┤
    │  Administradoras       │  UF 80/mes     │  2,000 empresas       │
    │  Condominios           │  UF 25/mes     │  50,000 comunidades   │
    │  Instituciones         │  UF 2,000/año  │  Municipios, bancos   │
    └──────────────────────────────────────────────────────────────────┘

    PLANES POR COPROPIEDAD:
    
    Starter      │ 1-20 unidades   │ UF 8/mes   │ Core + Gastos
    Professional │ 21-50 unidades  │ UF 15/mes  │ + Contabilidad + Antenas
    Enterprise   │ 51-100 unidades │ UF 25/mes  │ + PAE + Compliance
    Corporate    │ 100+ unidades   │ UF 40/mes  │ + ÁGORA + API + VIP


# SLIDE 7: TRACCIÓN Y MÉTRICAS
═══════════════════════════════════════════════════════════════════════════════

    DESARROLLO COMPLETADO:
    
    ████████████████████████████████████████  100%

    ┌────────────────────────────────────────────────────────────────┐
    │  MÉTRICA                        │  VALOR                       │
    ├────────────────────────────────────────────────────────────────┤
    │  Líneas de código               │  11,585                      │
    │  Módulos funcionales            │  23                          │
    │  Endpoints API                  │  194                         │
    │  Tablas de base de datos        │  64                          │
    │  Documentos técnicos            │  22 papers metodológicos     │
    │  Estado del producto            │  100% backend listo          │
    └────────────────────────────────────────────────────────────────┘

    PRÓXIMOS HITOS:
    
    Q1 2026  │ Frontend web completo
    Q2 2026  │ App móvil + 50 clientes
    Q3 2026  │ Integración SII + 150 clientes
    Q4 2026  │ 300 clientes + expansión regional


# SLIDE 8: TAMAÑO DE MERCADO
═══════════════════════════════════════════════════════════════════════════════

    ┌─────────────────────────────────────────────────────────────────────┐
    │                                                                     │
    │                    TAM: US$450M                                     │
    │              ┌─────────────────────────┐                           │
    │              │                         │                           │
    │              │      SAM: US$90M        │                           │
    │              │    ┌───────────────┐    │                           │
    │              │    │               │    │                           │
    │              │    │  SOM: US$15M  │    │                           │
    │              │    │               │    │                           │
    │              │    └───────────────┘    │                           │
    │              │                         │                           │
    │              └─────────────────────────┘                           │
    │                                                                     │
    └─────────────────────────────────────────────────────────────────────┘

    TAM │ Mercado total LATAM PropTech gestión
    SAM │ Chile + condominios que pueden pagar
    SOM │ Objetivo realista a 5 años

    CRECIMIENTO PROPTECH LATAM: 200-300% anual
    (Fuente: Endeavor, Glisco Partners)


# SLIDE 9: COMPETENCIA
═══════════════════════════════════════════════════════════════════════════════

    ┌────────────────────────────────────────────────────────────────────────┐
    │                    │ DATAPOLIS │ ComunidadFeliz │ Swappi │ Excel      │
    ├────────────────────────────────────────────────────────────────────────┤
    │ Gestión básica     │    ✅     │      ✅        │   ✅   │    ⚠️      │
    │ Contabilidad       │    ✅     │      ⚠️        │   ❌   │    ❌      │
    │ Tributación antenas│    ✅     │      ❌        │   ❌   │    ❌      │
    │ Compliance 21.442  │    ✅     │      ⚠️        │   ⚠️   │    ❌      │
    │ Compliance 21.713  │    ✅     │      ❌        │   ❌   │    ❌      │
    │ IA Predictiva      │    ✅     │      ❌        │   ❌   │    ❌      │
    │ Intel. Territorial │    ✅     │      ❌        │   ❌   │    ❌      │
    └────────────────────────────────────────────────────────────────────────┘

    PARTICIPACIÓN ACTUAL DEL MERCADO:
    
    █████████████████████████████████████████████████  77% SIN SOFTWARE
    ████████████  15% Soluciones legacy
    ████  5% ComunidadFeliz
    ██  2% Swappi
    █  1% Otros


# SLIDE 10: PROYECCIÓN FINANCIERA
═══════════════════════════════════════════════════════════════════════════════

    ARR PROYECTADO (5 AÑOS)
    
    Año 5 │ ████████████████████████████████████████████  840,000 UF
    Año 4 │ ██████████████████████████  420,000 UF
    Año 3 │ █████████████  180,000 UF
    Año 2 │ ██████  60,000 UF
    Año 1 │ ██  18,000 UF
          └────────────────────────────────────────────────────────────

    MÉTRICAS CLAVE:
    
    ┌─────────────────────────────────────────────────────────────────┐
    │                    │  Año 1   │  Año 3   │  Año 5              │
    ├─────────────────────────────────────────────────────────────────┤
    │  Clientes          │    50    │   400    │  1,500              │
    │  ARR (UF)          │  18,000  │ 180,000  │ 840,000             │
    │  Gross Margin      │   75%    │   85%    │   90%               │
    │  LTV/CAC           │   6x     │   15x    │   30x               │
    │  Churn mensual     │   3%     │  1.5%    │   1%                │
    └─────────────────────────────────────────────────────────────────┘


# SLIDE 11: EQUIPO
═══════════════════════════════════════════════════════════════════════════════

    ┌─────────────────────────────────────────────────────────────────────┐
    │                                                                     │
    │                    DANIEL - CEO & FOUNDER                           │
    │                                                                     │
    │    📚 Arquitecto, Universidad Central                              │
    │    📚 Estudios de Derecho                                          │
    │                                                                     │
    │    💼 18 años de experiencia en:                                   │
    │       • Arquitectura y urbanismo                                   │
    │       • Gestión territorial                                        │
    │       • Desarrollo tecnológico                                     │
    │                                                                     │
    │    🏆 Logros destacados:                                           │
    │       • 3er lugar Bloomberg Mayor Challenge (US$50,000)            │
    │       • Consultor CEPAL-Naciones Unidas                            │
    │       • 345 viviendas sociales gestionadas (SERVIU)                │
    │       • 22 papers metodológicos desarrollados                      │
    │                                                                     │
    └─────────────────────────────────────────────────────────────────────┘

    EQUIPO A CONSTRUIR (con inversión):
    
    • CTO - Liderazgo técnico
    • Full-stack Senior (x2) - Desarrollo
    • Frontend Developer - UI/UX
    • Mobile Developer - Apps
    • Sales Lead - Comercial


# SLIDE 12: USO DE FONDOS
═══════════════════════════════════════════════════════════════════════════════

    RONDA SEED: UF 15,000 (US$600,000)

    ┌────────────────────────────────────────────────────────────────┐
    │                                                                │
    │  ████████████████████████████████████████  40%  PRODUCTO      │
    │  Frontend web, móvil, integraciones                           │
    │                                                                │
    │  ██████████████████████████████  30%  EQUIPO                  │
    │  Contrataciones clave                                         │
    │                                                                │
    │  ████████████████████  20%  GO-TO-MARKET                      │
    │  Marketing, ventas, partnerships                              │
    │                                                                │
    │  ██████████  10%  OPERACIONES                                 │
    │  Legal, infraestructura, otros                                │
    │                                                                │
    └────────────────────────────────────────────────────────────────┘

    MILESTONES:
    
    3 meses  │ Frontend web completo
    5 meses  │ App móvil v1
    6 meses  │ 50 clientes pagando
    8 meses  │ Integración bancaria
    12 meses │ 150 clientes - Product-market fit


# SLIDE 13: TÉRMINOS DE INVERSIÓN
═══════════════════════════════════════════════════════════════════════════════

    ┌─────────────────────────────────────────────────────────────────────┐
    │                                                                     │
    │    RONDA                     Seed                                   │
    │                                                                     │
    │    MONTO OBJETIVO            UF 15,000 (US$600,000)                │
    │                                                                     │
    │    VALORACIÓN PRE-MONEY      UF 45,000 (US$1,800,000)              │
    │                                                                     │
    │    EQUITY OFRECIDO           25%                                    │
    │                                                                     │
    │    INSTRUMENTO               SAFE o Equity                          │
    │                                                                     │
    │    INVERSIÓN MÍNIMA          UF 2,500 (US$100,000)                 │
    │                                                                     │
    └─────────────────────────────────────────────────────────────────────┘

    ESCENARIOS DE RETORNO:
    
    ┌─────────────────────────────────────────────────────────────────┐
    │  Escenario     │  Año  │  Múltiplo  │  Valoración  │  Retorno  │
    ├─────────────────────────────────────────────────────────────────┤
    │  Conservador   │   5   │    5x ARR  │  UF 4.2M     │    23x    │
    │  Base          │   4   │    7x ARR  │  UF 2.9M     │    16x    │
    │  Agresivo      │   3   │   10x ARR  │  UF 1.8M     │    10x    │
    └─────────────────────────────────────────────────────────────────┘


# SLIDE 14: ¿POR QUÉ INVERTIR?
═══════════════════════════════════════════════════════════════════════════════

    1. TIMING PERFECTO
       ────────────────
       Ley 21.442 obliga digitalización → Deadline enero 2026
       77% del mercado sin software → Oportunidad masiva

    2. PRODUCTO LISTO
       ────────────────
       100% backend desarrollado → Menor riesgo de ejecución
       11,585 líneas de código probadas → Time-to-market rápido

    3. VENTAJA COMPETITIVA SOSTENIBLE
       ────────────────
       Motor PAE único → 18 meses para replicar
       Compliance automatizado → Diferenciador regulatorio

    4. EQUIPO CON TRACK RECORD
       ────────────────
       18 años de experiencia → Conocimiento profundo
       Bloomberg Mayor Challenge → Capacidad de ejecución

    5. MÉTRICAS ATRACTIVAS
       ────────────────
       LTV/CAC 15x → Unit economics sólidos
       85% Gross Margin → Escalabilidad probada


# SLIDE 15: LLAMADO A LA ACCIÓN
═══════════════════════════════════════════════════════════════════════════════

    ┌─────────────────────────────────────────────────────────────────────┐
    │                                                                     │
    │                         ÚNASE A NOSOTROS                            │
    │                                                                     │
    │        Transformemos juntos la gestión de copropiedades            │
    │                        en Chile y LATAM                             │
    │                                                                     │
    │   ─────────────────────────────────────────────────────────────    │
    │                                                                     │
    │                      PRÓXIMOS PASOS:                                │
    │                                                                     │
    │          1. Demo del producto (30 min)                              │
    │          2. Due diligence técnico                                   │
    │          3. Revisión data room                                      │
    │          4. Term sheet                                              │
    │                                                                     │
    │   ─────────────────────────────────────────────────────────────    │
    │                                                                     │
    │                         CONTACTO:                                   │
    │                                                                     │
    │                  📧 contacto@datapolis.cl                          │
    │                  🌐 www.datapolis.cl                               │
    │                  📍 Santiago, Chile                                 │
    │                                                                     │
    └─────────────────────────────────────────────────────────────────────┘


                              ¡GRACIAS!

                              DATAPOLIS
                 PropTech | FinTech | RegTech | GeoTech | GovTech

                    © 2026 DATAPOLIS SpA - Confidencial


# ══════════════════════════════════════════════════════════════════════════════
#                           FIN DEL PITCH DECK
# ══════════════════════════════════════════════════════════════════════════════
