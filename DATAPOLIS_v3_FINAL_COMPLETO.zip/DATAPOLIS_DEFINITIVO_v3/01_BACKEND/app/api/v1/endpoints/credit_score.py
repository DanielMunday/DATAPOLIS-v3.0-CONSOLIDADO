# -*- coding: utf-8 -*-
"""
DATAPOLIS v3.0 - Router API: Credit Score Inmobiliario (M03)
=============================================================
Endpoints REST para scoring crediticio de propiedades.

Sistema de evaluación 5 dimensiones:
- Ubicación (20%)
- Legal (25%)
- Financiero (25%)
- Técnico (15%)
- Mercado (15%)

Autor: DATAPOLIS SpA
Versión: 3.0.0
"""

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from fastapi.responses import JSONResponse, StreamingResponse
from typing import Optional, List, Dict, Any
from datetime import date, datetime
from enum import Enum
import logging
import io

from ....schemas.credit_score import (
    CreditScoreRequest,
    CreditScoreResponse,
    CreditScoreDetalladoResponse,
    ComparativoScoreResponse,
    HistorialScoreResponse,
    SimulacionScoreRequest,
    SimulacionScoreResponse,
    RiesgoIdentificadoSchema,
    ComponenteScoreSchema
)
from ....schemas.base import (
    PaginatedResponse,
    ErrorResponse,
    SuccessResponse
)
from ....services.m03_credit_score import ServicioCreditScore
from ....config import settings
from ..dependencies import (
    get_current_user,
    get_db_session,
    verify_api_key,
    rate_limiter,
    verify_permission
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/credit-score",
    tags=["Credit Score Inmobiliario"],
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        429: {"model": ErrorResponse},
        500: {"model": ErrorResponse}
    }
)

# Instancia global del servicio
_servicio_credit_score: Optional[ServicioCreditScore] = None


class CategoriaScore(str, Enum):
    """Categorías de credit score"""
    AAA = "AAA"
    AA = "AA"
    A = "A"
    BBB = "BBB"
    BB = "BB"
    B = "B"
    CCC = "CCC"
    CC = "CC"
    C = "C"
    D = "D"


class TipoRiesgo(str, Enum):
    """Tipos de riesgo identificables"""
    TITULO = "titulo"
    GRAVAMEN = "gravamen"
    LITIGIO = "litigio"
    URBANISTICO = "urbanistico"
    AMBIENTAL = "ambiental"
    ESTRUCTURAL = "estructural"
    MERCADO = "mercado"
    LIQUIDEZ = "liquidez"
    REGULATORIO = "regulatorio"
    SISMICO = "sismico"


async def get_servicio_credit_score() -> ServicioCreditScore:
    """Dependency injection para servicio de credit score"""
    global _servicio_credit_score
    if _servicio_credit_score is None:
        _servicio_credit_score = ServicioCreditScore()
    return _servicio_credit_score


# ============================================================================
# ENDPOINTS PRINCIPALES
# ============================================================================

@router.post(
    "/evaluar",
    response_model=CreditScoreResponse,
    summary="Evaluar credit score de propiedad",
    description="""
    Calcula el credit score inmobiliario de una propiedad evaluando 5 dimensiones.
    
    **Dimensiones evaluadas:**
    
    | Dimensión | Peso | Componentes |
    |-----------|------|-------------|
    | Ubicación | 20% | Zona, accesibilidad, servicios, plusvalía, seguridad |
    | Legal | 25% | Títulos, gravámenes, litigios, permisos |
    | Financiero | 25% | Valor, rentabilidad, liquidez, deuda |
    | Técnico | 15% | Estado, antigüedad, calidad, eficiencia |
    | Mercado | 15% | Oferta/demanda, tendencias, competencia |
    
    **Escala de score:** 0-1000
    
    **Categorías:**
    - AAA (900-1000): Excelente - Riesgo mínimo
    - AA (800-899): Muy bueno - Bajo riesgo
    - A (700-799): Bueno - Riesgo moderado-bajo
    - BBB (600-699): Aceptable - Riesgo moderado
    - BB (500-599): Regular - Riesgo medio
    - B (400-499): Bajo - Riesgo medio-alto
    - CCC-D (<400): Débil a Default - Alto riesgo
    
    **Machine Learning:**
    - Modelo XGBoost entrenado con datos chilenos
    - Explicabilidad SHAP
    """,
    responses={
        200: {
            "description": "Evaluación exitosa",
            "content": {
                "application/json": {
                    "example": {
                        "id_evaluacion": "CS-2026-000456",
                        "score_total": 785,
                        "categoria": "A",
                        "descripcion_categoria": "Bueno - Riesgo moderado-bajo",
                        "confianza": 0.89,
                        "componentes": {
                            "ubicacion": {"score": 820, "peso": 0.20},
                            "legal": {"score": 750, "peso": 0.25},
                            "financiero": {"score": 790, "peso": 0.25},
                            "tecnico": {"score": 760, "peso": 0.15},
                            "mercado": {"score": 800, "peso": 0.15}
                        },
                        "riesgos_identificados": 2,
                        "fecha_evaluacion": "2026-02-01"
                    }
                }
            }
        }
    }
)
async def evaluar_credit_score(
    request: CreditScoreRequest,
    background_tasks: BackgroundTasks,
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    current_user: dict = Depends(get_current_user)
):
    """Evaluar credit score de una propiedad"""
    try:
        resultado = await servicio.evaluar(
            datos_propiedad=request.propiedad,
            datos_legales=request.datos_legales,
            datos_financieros=request.datos_financieros,
            datos_tecnicos=request.datos_tecnicos,
            datos_mercado=request.datos_mercado,
            incluir_shap=request.incluir_explicabilidad
        )
        
        # Log asíncrono
        background_tasks.add_task(
            _log_evaluacion,
            user_id=current_user.get("id"),
            id_evaluacion=resultado["id"],
            score=resultado["score_total"]
        )
        
        return CreditScoreResponse(
            id_evaluacion=resultado["id"],
            estado="completada",
            score_total=resultado["score_total"],
            categoria=resultado["categoria"],
            descripcion_categoria=_get_descripcion_categoria(resultado["categoria"]),
            confianza=resultado["confianza"],
            completitud_datos=resultado["completitud"],
            
            componentes={
                dim: ComponenteScoreSchema(
                    dimension=dim,
                    score=comp["score"],
                    peso=comp["peso"],
                    contribucion=comp["contribucion"],
                    factores_positivos=comp.get("positivos", []),
                    factores_negativos=comp.get("negativos", [])
                )
                for dim, comp in resultado["componentes"].items()
            },
            
            riesgos_identificados=[
                RiesgoIdentificadoSchema(
                    tipo=r["tipo"],
                    severidad=r["severidad"],
                    descripcion=r["descripcion"],
                    impacto_score=r["impacto"],
                    mitigacion_sugerida=r.get("mitigacion")
                )
                for r in resultado.get("riesgos", [])
            ],
            
            recomendaciones=resultado.get("recomendaciones", []),
            fecha_evaluacion=resultado["fecha"],
            tiempo_procesamiento_ms=resultado["tiempo_ms"]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error evaluando credit score: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/evaluar/detallado",
    response_model=CreditScoreDetalladoResponse,
    summary="Evaluación detallada con explicabilidad completa",
    description="""
    Versión extendida con análisis completo por cada subdimensión
    y explicaciones SHAP del modelo ML.
    """
)
async def evaluar_credit_score_detallado(
    request: CreditScoreRequest,
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    current_user: dict = Depends(get_current_user)
):
    """Evaluación detallada con explicabilidad"""
    try:
        resultado = await servicio.evaluar_detallado(
            datos_propiedad=request.propiedad,
            datos_legales=request.datos_legales,
            datos_financieros=request.datos_financieros,
            datos_tecnicos=request.datos_tecnicos,
            datos_mercado=request.datos_mercado
        )
        
        return CreditScoreDetalladoResponse(
            id_evaluacion=resultado["id"],
            score_total=resultado["score_total"],
            categoria=resultado["categoria"],
            
            # Desglose por dimensión
            dimension_ubicacion={
                "score": resultado["ubicacion"]["score"],
                "factor_zona": resultado["ubicacion"]["factor_zona"],
                "comuna": resultado["ubicacion"]["comuna"],
                "distancia_metro_km": resultado["ubicacion"].get("dist_metro"),
                "indice_servicios": resultado["ubicacion"].get("servicios"),
                "plusvalia_anual": resultado["ubicacion"].get("plusvalia"),
                "indice_seguridad": resultado["ubicacion"].get("seguridad"),
                "zona_sismica": resultado["ubicacion"].get("zona_sismica")
            },
            
            dimension_legal={
                "score": resultado["legal"]["score"],
                "titulo_status": resultado["legal"]["titulo"],
                "n_gravamenes": resultado["legal"].get("n_gravamenes", 0),
                "hipoteca_ltv": resultado["legal"].get("ltv"),
                "prohibiciones": resultado["legal"].get("prohibiciones", []),
                "embargos": resultado["legal"].get("embargos", []),
                "litigios_activos": resultado["legal"].get("n_litigios", 0),
                "permisos_vigentes": resultado["legal"].get("permisos_ok"),
                "cumplimiento_urbanistico": resultado["legal"].get("urbanistico_ok")
            },
            
            dimension_financiero={
                "score": resultado["financiero"]["score"],
                "valor_vs_mercado": resultado["financiero"]["vs_mercado"],
                "cap_rate": resultado["financiero"].get("cap_rate"),
                "dias_promedio_mercado": resultado["financiero"].get("dias_mercado"),
                "morosidad": resultado["financiero"].get("morosidad"),
                "gastos_sobre_ingreso": resultado["financiero"].get("expense_ratio"),
                "contribuciones_al_dia": resultado["financiero"].get("contrib_ok"),
                "razon_deuda": resultado["financiero"].get("deuda_ratio")
            },
            
            dimension_tecnico={
                "score": resultado["tecnico"]["score"],
                "estado_conservacion": resultado["tecnico"]["estado"],
                "antiguedad_anos": resultado["tecnico"]["antiguedad"],
                "vida_util_remanente": resultado["tecnico"].get("vida_util"),
                "calidad_construccion": resultado["tecnico"].get("calidad"),
                "certificacion_energetica": resultado["tecnico"].get("energia"),
                "estado_instalaciones": resultado["tecnico"].get("instalaciones")
            },
            
            dimension_mercado={
                "score": resultado["mercado"]["score"],
                "indice_demanda": resultado["mercado"]["demanda"],
                "tendencia_precios_12m": resultado["mercado"].get("tendencia"),
                "meses_inventario": resultado["mercado"].get("inventario"),
                "competencia_zona": resultado["mercado"].get("competencia"),
                "tasa_hipotecaria_actual": resultado["mercado"].get("tasa_hip"),
                "proyectos_nuevos_zona": resultado["mercado"].get("proyectos")
            },
            
            # ML y SHAP
            modelo_ml={
                "score_predicho": resultado.get("ml_score"),
                "features_utilizadas": resultado.get("features"),
                "importancia_variables": resultado.get("importancia")
            },
            
            shap_explicaciones={
                "top_positivos": resultado.get("shap_positivos", []),
                "top_negativos": resultado.get("shap_negativos", []),
                "base_value": resultado.get("shap_base"),
                "valores_shap": resultado.get("shap_values")
            },
            
            # Riesgos detallados
            riesgos=resultado.get("riesgos", []),
            
            # Benchmark
            benchmark={
                "percentil_comuna": resultado.get("percentil_comuna"),
                "percentil_tipo": resultado.get("percentil_tipo"),
                "promedio_comuna": resultado.get("avg_comuna"),
                "promedio_tipo": resultado.get("avg_tipo")
            },
            
            recomendaciones=resultado.get("recomendaciones", []),
            plan_mejora=resultado.get("plan_mejora"),
            
            fecha_evaluacion=resultado["fecha"],
            hash_verificacion=resultado.get("hash")
        )
        
    except Exception as e:
        logger.error(f"Error en evaluación detallada: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/evaluacion/{id_evaluacion}",
    response_model=CreditScoreResponse,
    summary="Obtener evaluación por ID"
)
async def obtener_evaluacion(
    id_evaluacion: str,
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    current_user: dict = Depends(get_current_user)
):
    """Obtener evaluación existente"""
    try:
        resultado = await servicio.obtener_evaluacion(id_evaluacion)
        
        if resultado is None:
            raise HTTPException(
                status_code=404,
                detail=f"Evaluación {id_evaluacion} no encontrada"
            )
        
        return CreditScoreResponse(**resultado)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error obteniendo evaluación: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# SIMULACIÓN Y ESCENARIOS
# ============================================================================

@router.post(
    "/simular",
    response_model=SimulacionScoreResponse,
    summary="Simular cambios en credit score",
    description="""
    Simula el impacto de cambios hipotéticos en el credit score.
    
    **Escenarios simulables:**
    - Regularización de títulos
    - Pago de deudas/gravámenes
    - Mejoras físicas
    - Cambios de mercado
    - Obtención de permisos
    """
)
async def simular_score(
    request: SimulacionScoreRequest,
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    _: dict = Depends(verify_api_key)
):
    """Simular cambios en credit score"""
    try:
        resultado = await servicio.simular_escenarios(
            id_evaluacion_base=request.id_evaluacion_base,
            escenarios=request.escenarios
        )
        
        return SimulacionScoreResponse(
            id_evaluacion_base=request.id_evaluacion_base,
            score_actual=resultado["score_actual"],
            categoria_actual=resultado["categoria_actual"],
            
            simulaciones=[
                {
                    "escenario": sim["nombre"],
                    "descripcion": sim["descripcion"],
                    "score_proyectado": sim["score_nuevo"],
                    "categoria_proyectada": sim["categoria_nueva"],
                    "delta_score": sim["delta"],
                    "cambios_aplicados": sim["cambios"],
                    "costo_estimado": sim.get("costo"),
                    "tiempo_estimado_meses": sim.get("tiempo"),
                    "roi_estimado": sim.get("roi")
                }
                for sim in resultado["simulaciones"]
            ],
            
            mejor_escenario=resultado["mejor_escenario"],
            recomendacion_optima=resultado.get("recomendacion")
        )
        
    except Exception as e:
        logger.error(f"Error en simulación: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/escenarios-mejora/{id_evaluacion}",
    summary="Escenarios de mejora sugeridos",
    description="Genera automáticamente escenarios de mejora para una evaluación"
)
async def escenarios_mejora(
    id_evaluacion: str,
    presupuesto_max_uf: Optional[float] = Query(default=None),
    horizonte_meses: int = Query(default=12, ge=1, le=36),
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    _: dict = Depends(verify_api_key)
):
    """Generar escenarios de mejora"""
    try:
        resultado = await servicio.generar_escenarios_mejora(
            id_evaluacion=id_evaluacion,
            presupuesto_max=presupuesto_max_uf,
            horizonte=horizonte_meses
        )
        
        return {
            "id_evaluacion": id_evaluacion,
            "score_actual": resultado["score_actual"],
            "score_potencial_maximo": resultado["score_potencial"],
            "gap": resultado["gap"],
            
            "escenarios": resultado["escenarios"],
            
            "quick_wins": [
                e for e in resultado["escenarios"]
                if e.get("roi", 0) > 2 and e.get("tiempo", 99) <= 3
            ],
            
            "plan_optimo": resultado.get("plan_optimo"),
            "inversion_total_uf": resultado.get("inversion_total"),
            "score_final_proyectado": resultado.get("score_final")
        }
        
    except Exception as e:
        logger.error(f"Error generando escenarios: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# COMPARATIVOS Y BENCHMARK
# ============================================================================

@router.get(
    "/comparativo",
    response_model=ComparativoScoreResponse,
    summary="Comparativo de scores",
    description="Compara el score de una propiedad con benchmark de mercado"
)
async def comparativo_score(
    id_evaluacion: str = Query(...),
    comparar_con: str = Query(
        default="comuna",
        regex="^(comuna|tipo|region|nacional)$"
    ),
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    _: dict = Depends(verify_api_key)
):
    """Comparativo de score con benchmark"""
    try:
        resultado = await servicio.comparativo(
            id_evaluacion=id_evaluacion,
            nivel=comparar_con
        )
        
        return ComparativoScoreResponse(
            id_evaluacion=id_evaluacion,
            score_propiedad=resultado["score"],
            categoria_propiedad=resultado["categoria"],
            
            benchmark={
                "nivel": comparar_con,
                "nombre": resultado["benchmark_nombre"],
                "score_promedio": resultado["promedio"],
                "score_mediana": resultado["mediana"],
                "score_p25": resultado["p25"],
                "score_p75": resultado["p75"],
                "n_propiedades": resultado["n_muestra"]
            },
            
            posicion={
                "percentil": resultado["percentil"],
                "ranking": resultado.get("ranking"),
                "total": resultado.get("total")
            },
            
            vs_benchmark={
                "diferencia": resultado["diferencia"],
                "porcentaje": resultado["pct_diferencia"],
                "interpretacion": resultado["interpretacion"]
            },
            
            distribucion=resultado.get("distribucion")
        )
        
    except Exception as e:
        logger.error(f"Error en comparativo: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/historial",
    response_model=HistorialScoreResponse,
    summary="Historial de scores de una propiedad"
)
async def historial_scores(
    rol_propiedad: str = Query(..., description="ROL SII de la propiedad"),
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    _: dict = Depends(verify_api_key)
):
    """Obtener historial de scores"""
    try:
        resultado = await servicio.historial_scores(rol_propiedad)
        
        return HistorialScoreResponse(
            rol_propiedad=rol_propiedad,
            evaluaciones=resultado["evaluaciones"],
            tendencia=resultado["tendencia"],
            score_actual=resultado["score_actual"],
            score_hace_12m=resultado.get("score_12m"),
            variacion_12m=resultado.get("variacion_12m"),
            mejor_score=resultado.get("mejor"),
            peor_score=resultado.get("peor"),
            volatilidad=resultado.get("volatilidad")
        )
        
    except Exception as e:
        logger.error(f"Error obteniendo historial: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ANÁLISIS DE RIESGO
# ============================================================================

@router.get(
    "/riesgos/{id_evaluacion}",
    summary="Detalle de riesgos identificados"
)
async def detalle_riesgos(
    id_evaluacion: str,
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    _: dict = Depends(verify_api_key)
):
    """Obtener detalle de riesgos identificados"""
    try:
        resultado = await servicio.detalle_riesgos(id_evaluacion)
        
        return {
            "id_evaluacion": id_evaluacion,
            "total_riesgos": resultado["total"],
            "por_severidad": resultado["por_severidad"],
            "por_tipo": resultado["por_tipo"],
            
            "riesgos": [
                {
                    "tipo": r["tipo"],
                    "severidad": r["severidad"],
                    "descripcion": r["descripcion"],
                    "impacto_score": r["impacto"],
                    "dimension_afectada": r["dimension"],
                    "fuente_deteccion": r.get("fuente"),
                    "mitigacion": {
                        "accion": r.get("mitigacion"),
                        "costo_estimado_uf": r.get("costo_mitigacion"),
                        "tiempo_estimado_dias": r.get("tiempo_mitigacion"),
                        "impacto_esperado": r.get("impacto_mitigacion")
                    },
                    "referencias_legales": r.get("referencias", [])
                }
                for r in resultado["riesgos"]
            ],
            
            "riesgo_agregado": resultado["riesgo_agregado"],
            "perfil_riesgo": resultado["perfil"]
        }
        
    except Exception as e:
        logger.error(f"Error obteniendo riesgos: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/alertas-activas",
    summary="Alertas activas de propiedades evaluadas"
)
async def alertas_activas(
    severidad_minima: str = Query(default="media", regex="^(baja|media|alta|critica)$"),
    tipo_riesgo: Optional[TipoRiesgo] = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    current_user: dict = Depends(get_current_user)
):
    """Obtener alertas activas"""
    try:
        resultado = await servicio.obtener_alertas(
            user_id=current_user.get("id"),
            severidad_minima=severidad_minima,
            tipo_riesgo=tipo_riesgo.value if tipo_riesgo else None,
            limit=limit
        )
        
        return {
            "total_alertas": resultado["total"],
            "filtros_aplicados": {
                "severidad_minima": severidad_minima,
                "tipo_riesgo": tipo_riesgo
            },
            "alertas": resultado["alertas"],
            "resumen_por_severidad": resultado["por_severidad"],
            "propiedades_afectadas": resultado["n_propiedades"]
        }
        
    except Exception as e:
        logger.error(f"Error obteniendo alertas: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# INFORMES
# ============================================================================

@router.get(
    "/informe/{id_evaluacion}",
    summary="Generar informe de credit score (PDF)"
)
async def generar_informe_score(
    id_evaluacion: str,
    formato: str = Query(default="pdf", regex="^(pdf|docx|html)$"),
    incluir_shap: bool = Query(default=True),
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    current_user: dict = Depends(get_current_user)
):
    """Generar informe de credit score"""
    try:
        resultado = await servicio.generar_informe(
            id_evaluacion=id_evaluacion,
            formato=formato,
            incluir_shap=incluir_shap,
            usuario=current_user.get("nombre")
        )
        
        if resultado is None:
            raise HTTPException(
                status_code=404,
                detail=f"Evaluación {id_evaluacion} no encontrada"
            )
        
        media_types = {
            "pdf": "application/pdf",
            "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "html": "text/html"
        }
        
        return StreamingResponse(
            io.BytesIO(resultado["contenido"]),
            media_type=media_types[formato],
            headers={
                "Content-Disposition": f"attachment; filename=CreditScore_{id_evaluacion}.{formato}"
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generando informe: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ESTADÍSTICAS Y ANALYTICS
# ============================================================================

@router.get(
    "/estadisticas/mercado",
    summary="Estadísticas de scores del mercado"
)
async def estadisticas_mercado(
    region: str = Query(default="RM"),
    tipo_propiedad: Optional[str] = Query(default=None),
    periodo_meses: int = Query(default=12, ge=1, le=36),
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score),
    _: dict = Depends(verify_api_key)
):
    """Estadísticas de scores del mercado"""
    try:
        resultado = await servicio.estadisticas_mercado(
            region=region,
            tipo_propiedad=tipo_propiedad,
            meses=periodo_meses
        )
        
        return {
            "region": region,
            "tipo_propiedad": tipo_propiedad or "Todos",
            "periodo_meses": periodo_meses,
            
            "distribucion_categorias": resultado["distribucion"],
            
            "estadisticas": {
                "score_promedio": resultado["promedio"],
                "score_mediana": resultado["mediana"],
                "desviacion_estandar": resultado["desviacion"],
                "percentiles": resultado["percentiles"]
            },
            
            "tendencia": {
                "variacion_vs_periodo_anterior": resultado["variacion"],
                "direccion": resultado["direccion"]
            },
            
            "riesgos_mas_comunes": resultado["riesgos_comunes"],
            "n_evaluaciones": resultado["n_total"]
        }
        
    except Exception as e:
        logger.error(f"Error obteniendo estadísticas: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# FUNCIONES AUXILIARES
# ============================================================================

def _get_descripcion_categoria(categoria: str) -> str:
    """Obtener descripción de categoría de score"""
    descripciones = {
        "AAA": "Excelente - Riesgo mínimo, propiedad premium",
        "AA": "Muy bueno - Bajo riesgo, altamente recomendable",
        "A": "Bueno - Riesgo moderado-bajo, recomendable con precauciones menores",
        "BBB": "Aceptable - Riesgo moderado, requiere análisis adicional",
        "BB": "Regular - Riesgo medio, precaución recomendada",
        "B": "Bajo - Riesgo medio-alto, due diligence exhaustivo requerido",
        "CCC": "Débil - Alto riesgo, múltiples problemas identificados",
        "CC": "Muy débil - Riesgo muy alto, problemas severos",
        "C": "Crítico - Riesgo extremo, no recomendable",
        "D": "Default - Problemas legales/estructurales graves, evitar"
    }
    return descripciones.get(categoria, "Categoría no definida")


async def _log_evaluacion(user_id: str, id_evaluacion: str, score: int):
    """Log asíncrono de evaluaciones"""
    logger.info(f"Credit Score evaluado: user={user_id}, id={id_evaluacion}, score={score}")


# ============================================================================
# HEALTH CHECK
# ============================================================================

@router.get(
    "/health",
    summary="Health check del servicio",
    include_in_schema=False
)
async def health_check(
    servicio: ServicioCreditScore = Depends(get_servicio_credit_score)
):
    """Health check"""
    try:
        status = await servicio.verificar_estado()
        
        return {
            "servicio": "m03_credit_score",
            "status": "healthy" if status["ok"] else "degraded",
            "modelo_ml_cargado": status.get("modelo_ok"),
            "shap_disponible": status.get("shap_ok"),
            "evaluaciones_hoy": status.get("evaluaciones_hoy"),
            "timestamp": datetime.utcnow()
        }
        
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "servicio": "m03_credit_score",
                "status": "unhealthy",
                "error": str(e)
            }
        )
