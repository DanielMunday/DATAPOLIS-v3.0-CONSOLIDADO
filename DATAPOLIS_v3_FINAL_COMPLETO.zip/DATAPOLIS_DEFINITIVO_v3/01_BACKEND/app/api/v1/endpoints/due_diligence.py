# -*- coding: utf-8 -*-
"""
DATAPOLIS v3.0 - Router API: Due Diligence Inmobiliario (M12)
==============================================================
Endpoints REST para due diligence automatizado de propiedades.

Sistema de 150+ checks en 6 áreas:
- Legal (40 checks)
- Financiero (30 checks)
- Técnico (25 checks)
- Ambiental (20 checks)
- Urbanístico (20 checks)
- Comercial (15 checks)

Autor: DATAPOLIS SpA
Versión: 3.0.0
"""

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks, UploadFile, File
from fastapi.responses import JSONResponse, StreamingResponse
from typing import Optional, List, Dict, Any
from datetime import date, datetime
from enum import Enum
import logging
import io

from ....schemas.due_diligence import (
    DueDiligenceRequest,
    DueDiligenceResponse,
    DueDiligenceDetalladoResponse,
    CheckResultSchema,
    AreaResultSchema,
    ValidacionHumanaRequest,
    ValidacionHumanaResponse,
    ResumenEjecutivoResponse,
    ChecklistPersonalizadoRequest
)
from ....schemas.base import (
    PaginatedResponse,
    ErrorResponse,
    SuccessResponse
)
from ....services.m12_due_diligence import ServicioDueDiligence
from ....config import settings
from ..dependencies import (
    get_current_user,
    get_db_session,
    verify_api_key,
    rate_limiter,
    verify_permission
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/due-diligence",
    tags=["Due Diligence Inmobiliario"],
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        429: {"model": ErrorResponse},
        500: {"model": ErrorResponse}
    }
)

# Instancia global del servicio
_servicio_dd: Optional[ServicioDueDiligence] = None


class AreaDueDiligence(str, Enum):
    """Áreas de due diligence"""
    LEGAL = "legal"
    FINANCIERO = "financiero"
    TECNICO = "tecnico"
    AMBIENTAL = "ambiental"
    URBANISTICO = "urbanistico"
    COMERCIAL = "comercial"


class NivelProfundidad(str, Enum):
    """Niveles de profundidad del análisis"""
    BASICO = "basico"      # Solo checks críticos y altos
    ESTANDAR = "estandar"  # + checks medios
    COMPLETO = "completo"  # Todos los checks


class EstadoCheck(str, Enum):
    """Estados posibles de un check"""
    APROBADO = "aprobado"
    RECHAZADO = "rechazado"
    OBSERVADO = "observado"
    PENDIENTE = "pendiente"
    NO_APLICA = "no_aplica"
    ERROR = "error"


async def get_servicio_dd() -> ServicioDueDiligence:
    """Dependency injection para servicio de due diligence"""
    global _servicio_dd
    if _servicio_dd is None:
        _servicio_dd = ServicioDueDiligence()
    return _servicio_dd


# ============================================================================
# ENDPOINTS PRINCIPALES
# ============================================================================

@router.post(
    "/ejecutar",
    response_model=DueDiligenceResponse,
    summary="Ejecutar due diligence de propiedad",
    description="""
    Ejecuta due diligence automatizado de una propiedad con 150+ checks.
    
    **Áreas evaluadas:**
    
    | Área | Checks | Peso | Ejemplos |
    |------|--------|------|----------|
    | Legal | 40 | 25% | Títulos CBR, gravámenes, hipotecas, litigios |
    | Financiero | 30 | 20% | Contribuciones, avalúo, comparables |
    | Técnico | 25 | 15% | Estructura, instalaciones, eficiencia |
    | Ambiental | 20 | 15% | Contaminación, riesgos naturales, permisos |
    | Urbanístico | 20 | 15% | Permisos DOM, recepción final, uso suelo |
    | Comercial | 15 | 10% | Mercado, liquidez, competencia |
    
    **Niveles de profundidad:**
    - `basico`: Solo checks críticos y altos (~40 checks)
    - `estandar`: + checks medios (~100 checks)
    - `completo`: Todos los checks (~150 checks)
    
    **Deal Breakers:**
    Checks críticos rechazados que bloquean la transacción:
    - Prohibición de enajenar
    - Embargo activo
    - Uso de suelo incompatible
    - Alto riesgo tsunami/inundación
    
    **HITL (Human-in-the-Loop):**
    Algunos checks requieren validación humana:
    - Abogado inmobiliario
    - Ingeniero estructural
    - Consultor ambiental
    - Certificador SEC
    """,
    responses={
        200: {
            "description": "Due diligence completado",
            "content": {
                "application/json": {
                    "example": {
                        "id_due_diligence": "DD-2026-000789",
                        "estado": "completado_con_observaciones",
                        "score_global": 78.5,
                        "categoria": "B",
                        "checks_ejecutados": 95,
                        "checks_aprobados": 82,
                        "checks_rechazados": 3,
                        "checks_observados": 10,
                        "deal_breakers": [],
                        "requiere_validacion_humana": True
                    }
                }
            }
        }
    }
)
async def ejecutar_due_diligence(
    request: DueDiligenceRequest,
    background_tasks: BackgroundTasks,
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    current_user: dict = Depends(get_current_user)
):
    """Ejecutar due diligence de propiedad"""
    try:
        resultado = await servicio.ejecutar(
            datos_propiedad=request.propiedad,
            areas=request.areas or [a.value for a in AreaDueDiligence],
            nivel_profundidad=request.nivel_profundidad or "estandar",
            datos_adicionales=request.datos_adicionales,
            timeout_check_ms=request.timeout_check_ms or 30000
        )
        
        # Log asíncrono
        background_tasks.add_task(
            _log_due_diligence,
            user_id=current_user.get("id"),
            id_dd=resultado["id"],
            score=resultado["score_global"]
        )
        
        return DueDiligenceResponse(
            id_due_diligence=resultado["id"],
            estado=resultado["estado"],
            score_global=resultado["score_global"],
            categoria=resultado["categoria"],
            
            resumen_areas={
                area: {
                    "score": data["score"],
                    "checks_total": data["total"],
                    "aprobados": data["aprobados"],
                    "rechazados": data["rechazados"],
                    "observados": data["observados"],
                    "completitud": data["completitud"]
                }
                for area, data in resultado["areas"].items()
            },
            
            checks_ejecutados=resultado["checks_ejecutados"],
            checks_aprobados=resultado["checks_aprobados"],
            checks_rechazados=resultado["checks_rechazados"],
            checks_observados=resultado["checks_observados"],
            checks_pendientes=resultado.get("checks_pendientes", 0),
            
            deal_breakers=resultado.get("deal_breakers", []),
            riesgos_criticos=resultado.get("riesgos_criticos", []),
            riesgos_altos=resultado.get("riesgos_altos", []),
            
            requiere_validacion_humana=resultado.get("requiere_hitl", False),
            validadores_requeridos=resultado.get("validadores", []),
            
            recomendaciones=resultado.get("recomendaciones", []),
            condiciones_cierre=resultado.get("condiciones", []),
            
            tiempo_procesamiento_ms=resultado["tiempo_ms"],
            fecha_ejecucion=resultado["fecha"],
            hash_verificacion=resultado.get("hash")
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error ejecutando due diligence: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/ejecutar/detallado",
    response_model=DueDiligenceDetalladoResponse,
    summary="Due diligence con detalle completo de todos los checks"
)
async def ejecutar_due_diligence_detallado(
    request: DueDiligenceRequest,
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    current_user: dict = Depends(get_current_user)
):
    """Due diligence con detalle completo"""
    try:
        resultado = await servicio.ejecutar_detallado(
            datos_propiedad=request.propiedad,
            areas=request.areas or [a.value for a in AreaDueDiligence],
            nivel_profundidad=request.nivel_profundidad or "completo",
            datos_adicionales=request.datos_adicionales
        )
        
        return DueDiligenceDetalladoResponse(
            id_due_diligence=resultado["id"],
            estado=resultado["estado"],
            score_global=resultado["score_global"],
            categoria=resultado["categoria"],
            
            # Detalle por área
            areas={
                area: AreaResultSchema(
                    nombre=area,
                    score=data["score"],
                    peso=data["peso"],
                    checks=[
                        CheckResultSchema(
                            codigo=c["codigo"],
                            nombre=c["nombre"],
                            area=area,
                            criticidad=c["criticidad"],
                            estado=c["estado"],
                            score=c["score"],
                            hallazgos=c.get("hallazgos", []),
                            observaciones=c.get("observaciones"),
                            fuente_datos=c.get("fuente"),
                            requiere_validacion_humana=c.get("requiere_hitl", False),
                            validado_por_humano=c.get("validado", False),
                            fecha_check=c.get("fecha")
                        )
                        for c in data["checks"]
                    ],
                    completitud=data["completitud"]
                )
                for area, data in resultado["areas"].items()
            },
            
            # Métricas
            metricas={
                "total_checks": resultado["checks_ejecutados"],
                "por_estado": resultado["por_estado"],
                "por_criticidad": resultado["por_criticidad"],
                "tiempo_promedio_check_ms": resultado.get("tiempo_promedio")
            },
            
            # Deal breakers
            deal_breakers=[
                {
                    "check": db["codigo"],
                    "descripcion": db["descripcion"],
                    "area": db["area"],
                    "impacto": db["impacto"],
                    "remediacion_posible": db.get("remediacion")
                }
                for db in resultado.get("deal_breakers", [])
            ],
            
            # HITL
            checks_pendientes_validacion=[
                {
                    "check": c["codigo"],
                    "nombre": c["nombre"],
                    "validador_requerido": c["validador"],
                    "prioridad": c["prioridad"]
                }
                for c in resultado.get("pendientes_hitl", [])
            ],
            
            # Documentos
            documentos_revisados=resultado.get("documentos", []),
            documentos_faltantes=resultado.get("docs_faltantes", []),
            
            # Conclusiones
            conclusion_general=resultado.get("conclusion"),
            recomendacion_final=resultado.get("recomendacion_final"),
            condiciones_precedentes=resultado.get("condiciones", []),
            
            fecha_ejecucion=resultado["fecha"],
            hash_verificacion=resultado.get("hash")
        )
        
    except Exception as e:
        logger.error(f"Error en due diligence detallado: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/{id_due_diligence}",
    response_model=DueDiligenceResponse,
    summary="Obtener due diligence por ID"
)
async def obtener_due_diligence(
    id_due_diligence: str,
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    current_user: dict = Depends(get_current_user)
):
    """Obtener due diligence existente"""
    try:
        resultado = await servicio.obtener(id_due_diligence)
        
        if resultado is None:
            raise HTTPException(
                status_code=404,
                detail=f"Due diligence {id_due_diligence} no encontrado"
            )
        
        return DueDiligenceResponse(**resultado)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error obteniendo due diligence: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# VALIDACIÓN HUMANA (HITL)
# ============================================================================

@router.post(
    "/{id_due_diligence}/validar",
    response_model=ValidacionHumanaResponse,
    summary="Registrar validación humana de check",
    description="""
    Permite a validadores autorizados registrar la validación manual de checks
    que requieren verificación humana.
    
    **Validadores requeridos por área:**
    - Legal: Abogado inmobiliario
    - Técnico: Ingeniero estructural
    - Ambiental: Consultor ambiental certificado
    - Urbanístico: Arquitecto o ingeniero civil
    """
)
async def validar_check_humano(
    id_due_diligence: str,
    request: ValidacionHumanaRequest,
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    current_user: dict = Depends(get_current_user)
):
    """Registrar validación humana"""
    try:
        # Verificar permisos de validador
        if not _es_validador_autorizado(current_user, request.area):
            raise HTTPException(
                status_code=403,
                detail=f"Usuario no autorizado como validador para área {request.area}"
            )
        
        resultado = await servicio.registrar_validacion_humana(
            id_due_diligence=id_due_diligence,
            codigo_check=request.codigo_check,
            estado_validado=request.estado,
            observaciones=request.observaciones,
            documentos_soporte=request.documentos_soporte,
            validador_id=current_user.get("id"),
            validador_nombre=current_user.get("nombre"),
            validador_rol=current_user.get("rol_validador")
        )
        
        return ValidacionHumanaResponse(
            id_due_diligence=id_due_diligence,
            codigo_check=request.codigo_check,
            estado_anterior=resultado["estado_anterior"],
            estado_nuevo=request.estado,
            validador=current_user.get("nombre"),
            rol_validador=current_user.get("rol_validador"),
            fecha_validacion=datetime.utcnow(),
            
            # Impacto en score
            score_anterior=resultado["score_anterior"],
            score_nuevo=resultado["score_nuevo"],
            delta_score=resultado["delta"],
            
            # Estado actualizado del DD
            checks_pendientes_validacion=resultado["pendientes"],
            dd_completado=resultado["completado"]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error en validación humana: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/{id_due_diligence}/pendientes-validacion",
    summary="Checks pendientes de validación humana"
)
async def checks_pendientes_validacion(
    id_due_diligence: str,
    area: Optional[AreaDueDiligence] = Query(default=None),
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    current_user: dict = Depends(get_current_user)
):
    """Obtener checks pendientes de validación"""
    try:
        resultado = await servicio.obtener_pendientes_validacion(
            id_due_diligence=id_due_diligence,
            area=area.value if area else None
        )
        
        return {
            "id_due_diligence": id_due_diligence,
            "total_pendientes": resultado["total"],
            "por_area": resultado["por_area"],
            "por_validador": resultado["por_validador"],
            "checks": resultado["checks"],
            "prioridad_sugerida": resultado["prioridad"]
        }
        
    except Exception as e:
        logger.error(f"Error obteniendo pendientes: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# CHECKS INDIVIDUALES
# ============================================================================

@router.get(
    "/checks/catalogo",
    summary="Catálogo completo de checks disponibles",
    description="Lista todos los checks disponibles con su descripción y criticidad"
)
async def catalogo_checks(
    area: Optional[AreaDueDiligence] = Query(default=None),
    criticidad: Optional[str] = Query(default=None, regex="^(critico|alto|medio|bajo|informativo)$"),
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    _: dict = Depends(verify_api_key)
):
    """Obtener catálogo de checks"""
    try:
        resultado = await servicio.obtener_catalogo_checks(
            area=area.value if area else None,
            criticidad=criticidad
        )
        
        return {
            "total_checks": resultado["total"],
            "por_area": resultado["por_area"],
            "por_criticidad": resultado["por_criticidad"],
            "checks": resultado["checks"]
        }
        
    except Exception as e:
        logger.error(f"Error obteniendo catálogo: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/{id_due_diligence}/check/{codigo_check}",
    summary="Detalle de un check específico"
)
async def detalle_check(
    id_due_diligence: str,
    codigo_check: str,
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    _: dict = Depends(verify_api_key)
):
    """Obtener detalle de un check"""
    try:
        resultado = await servicio.obtener_detalle_check(
            id_due_diligence=id_due_diligence,
            codigo_check=codigo_check
        )
        
        if resultado is None:
            raise HTTPException(
                status_code=404,
                detail=f"Check {codigo_check} no encontrado"
            )
        
        return {
            "codigo": codigo_check,
            "nombre": resultado["nombre"],
            "descripcion": resultado["descripcion"],
            "area": resultado["area"],
            "criticidad": resultado["criticidad"],
            "tipo_validacion": resultado["tipo_validacion"],
            
            "resultado": {
                "estado": resultado["estado"],
                "score": resultado["score"],
                "hallazgos": resultado["hallazgos"],
                "observaciones": resultado["observaciones"],
                "fuente_datos": resultado["fuente"],
                "fecha_ejecucion": resultado["fecha"]
            },
            
            "validacion_humana": {
                "requerida": resultado.get("requiere_hitl", False),
                "completada": resultado.get("validado", False),
                "validador": resultado.get("validador"),
                "fecha_validacion": resultado.get("fecha_validacion")
            },
            
            "referencias": resultado.get("referencias", []),
            "normativa_aplicable": resultado.get("normativa", [])
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error obteniendo check: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/{id_due_diligence}/re-ejecutar/{codigo_check}",
    summary="Re-ejecutar un check específico"
)
async def re_ejecutar_check(
    id_due_diligence: str,
    codigo_check: str,
    datos_actualizados: Optional[Dict[str, Any]] = None,
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    current_user: dict = Depends(get_current_user)
):
    """Re-ejecutar un check con datos actualizados"""
    try:
        resultado = await servicio.re_ejecutar_check(
            id_due_diligence=id_due_diligence,
            codigo_check=codigo_check,
            datos_actualizados=datos_actualizados
        )
        
        return {
            "codigo": codigo_check,
            "estado_anterior": resultado["estado_anterior"],
            "estado_nuevo": resultado["estado_nuevo"],
            "score_anterior": resultado["score_anterior"],
            "score_nuevo": resultado["score_nuevo"],
            "hallazgos": resultado["hallazgos"],
            "fecha_re_ejecucion": datetime.utcnow(),
            
            # Impacto en DD global
            "score_dd_anterior": resultado["score_dd_anterior"],
            "score_dd_nuevo": resultado["score_dd_nuevo"]
        }
        
    except Exception as e:
        logger.error(f"Error re-ejecutando check: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# CHECKLIST PERSONALIZADO
# ============================================================================

@router.post(
    "/checklist-personalizado",
    summary="Crear checklist personalizado",
    description="Crea un checklist personalizado con checks específicos"
)
async def crear_checklist_personalizado(
    request: ChecklistPersonalizadoRequest,
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    current_user: dict = Depends(get_current_user)
):
    """Crear checklist personalizado"""
    try:
        resultado = await servicio.crear_checklist_personalizado(
            nombre=request.nombre,
            descripcion=request.descripcion,
            checks=request.checks,
            user_id=current_user.get("id")
        )
        
        return {
            "id_checklist": resultado["id"],
            "nombre": request.nombre,
            "checks_incluidos": len(request.checks),
            "creado_por": current_user.get("nombre"),
            "fecha_creacion": datetime.utcnow()
        }
        
    except Exception as e:
        logger.error(f"Error creando checklist: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# INFORMES Y REPORTES
# ============================================================================

@router.get(
    "/{id_due_diligence}/resumen-ejecutivo",
    response_model=ResumenEjecutivoResponse,
    summary="Resumen ejecutivo del due diligence"
)
async def resumen_ejecutivo(
    id_due_diligence: str,
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    _: dict = Depends(verify_api_key)
):
    """Obtener resumen ejecutivo"""
    try:
        resultado = await servicio.generar_resumen_ejecutivo(id_due_diligence)
        
        return ResumenEjecutivoResponse(
            id_due_diligence=id_due_diligence,
            titulo=f"Resumen Ejecutivo Due Diligence - {resultado['propiedad']}",
            
            conclusion=resultado["conclusion"],
            recomendacion=resultado["recomendacion"],
            
            semaforo={
                "legal": resultado["semaforos"]["legal"],
                "financiero": resultado["semaforos"]["financiero"],
                "tecnico": resultado["semaforos"]["tecnico"],
                "ambiental": resultado["semaforos"]["ambiental"],
                "urbanistico": resultado["semaforos"]["urbanistico"],
                "comercial": resultado["semaforos"]["comercial"]
            },
            
            score_global=resultado["score"],
            categoria=resultado["categoria"],
            
            hallazgos_criticos=resultado["criticos"],
            hallazgos_relevantes=resultado["relevantes"],
            
            deal_breakers=resultado.get("deal_breakers", []),
            condiciones_precedentes=resultado.get("condiciones", []),
            
            siguiente_pasos=resultado.get("siguientes_pasos", []),
            
            fecha_emision=datetime.utcnow()
        )
        
    except Exception as e:
        logger.error(f"Error generando resumen: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/{id_due_diligence}/informe",
    summary="Generar informe completo (PDF/DOCX)"
)
async def generar_informe_dd(
    id_due_diligence: str,
    formato: str = Query(default="pdf", regex="^(pdf|docx|html)$"),
    incluir_anexos: bool = Query(default=True),
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    current_user: dict = Depends(get_current_user)
):
    """Generar informe de due diligence"""
    try:
        resultado = await servicio.generar_informe(
            id_due_diligence=id_due_diligence,
            formato=formato,
            incluir_anexos=incluir_anexos,
            usuario=current_user.get("nombre")
        )
        
        if resultado is None:
            raise HTTPException(
                status_code=404,
                detail=f"Due diligence {id_due_diligence} no encontrado"
            )
        
        media_types = {
            "pdf": "application/pdf",
            "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "html": "text/html"
        }
        
        return StreamingResponse(
            io.BytesIO(resultado["contenido"]),
            media_type=media_types[formato],
            headers={
                "Content-Disposition": f"attachment; filename=DueDiligence_{id_due_diligence}.{formato}"
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generando informe: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/{id_due_diligence}/matriz-riesgos",
    summary="Matriz de riesgos del due diligence"
)
async def matriz_riesgos(
    id_due_diligence: str,
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    _: dict = Depends(verify_api_key)
):
    """Obtener matriz de riesgos"""
    try:
        resultado = await servicio.generar_matriz_riesgos(id_due_diligence)
        
        return {
            "id_due_diligence": id_due_diligence,
            "matriz": resultado["matriz"],
            "riesgos_por_cuadrante": {
                "critico_alto": resultado["critico_alto"],
                "critico_bajo": resultado["critico_bajo"],
                "menor_alto": resultado["menor_alto"],
                "menor_bajo": resultado["menor_bajo"]
            },
            "riesgo_agregado": resultado["riesgo_agregado"],
            "distribucion_probabilidad_impacto": resultado["distribucion"],
            "top_5_riesgos": resultado["top_5"]
        }
        
    except Exception as e:
        logger.error(f"Error generando matriz: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# COMPARATIVOS Y BENCHMARK
# ============================================================================

@router.get(
    "/comparativo",
    summary="Comparar múltiples due diligence"
)
async def comparar_due_diligence(
    ids: List[str] = Query(..., min_items=2, max_items=5),
    servicio: ServicioDueDiligence = Depends(get_servicio_dd),
    _: dict = Depends(verify_api_key)
):
    """Comparar múltiples due diligence"""
    try:
        resultado = await servicio.comparar(ids)
        
        return {
            "propiedades_comparadas": len(ids),
            "comparativo": resultado["comparativo"],
            "ranking_por_score": resultado["ranking"],
            "mejor_opcion": resultado["mejor"],
            "areas_destacadas": resultado["areas_destacadas"],
            "riesgos_comunes": resultado["riesgos_comunes"]
        }
        
    except Exception as e:
        logger.error(f"Error en comparativo: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# FUNCIONES AUXILIARES
# ============================================================================

def _es_validador_autorizado(user: dict, area: str) -> bool:
    """Verificar si usuario es validador autorizado para área"""
    validadores_por_area = {
        "legal": ["abogado_inmobiliario", "notario"],
        "tecnico": ["ingeniero_estructural", "arquitecto"],
        "ambiental": ["consultor_ambiental", "ingeniero_ambiental"],
        "urbanistico": ["arquitecto", "ingeniero_civil"],
        "financiero": ["contador", "auditor", "analista_financiero"],
        "comercial": ["corredor_propiedades", "analista_mercado"]
    }
    
    rol = user.get("rol_validador", "")
    return rol in validadores_por_area.get(area, [])


async def _log_due_diligence(user_id: str, id_dd: str, score: float):
    """Log asíncrono"""
    logger.info(f"Due Diligence completado: user={user_id}, id={id_dd}, score={score:.1f}")


# ============================================================================
# HEALTH CHECK
# ============================================================================

@router.get(
    "/health",
    summary="Health check del servicio",
    include_in_schema=False
)
async def health_check(
    servicio: ServicioDueDiligence = Depends(get_servicio_dd)
):
    """Health check"""
    try:
        status = await servicio.verificar_estado()
        
        return {
            "servicio": "m12_due_diligence",
            "status": "healthy" if status["ok"] else "degraded",
            "checks_disponibles": status.get("n_checks"),
            "integraciones_activas": status.get("integraciones"),
            "dd_ejecutados_hoy": status.get("dd_hoy"),
            "timestamp": datetime.utcnow()
        }
        
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "servicio": "m12_due_diligence",
                "status": "unhealthy",
                "error": str(e)
            }
        )
