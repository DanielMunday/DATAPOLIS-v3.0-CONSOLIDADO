# -*- coding: utf-8 -*-
"""
DATAPOLIS v3.0 - Router API: Indicadores Económicos
====================================================
Endpoints REST para el servicio IE de indicadores macroeconómicos chilenos.

Fuentes oficiales:
- Banco Central de Chile (BCCh)
- Instituto Nacional de Estadísticas (INE)
- Superintendencia de Bancos (SBIF/CMF)

Autor: DATAPOLIS SpA
Versión: 3.0.0
Licencia: Propietaria
"""

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from fastapi.responses import JSONResponse
from typing import Optional, List
from datetime import date, datetime
from enum import Enum
import logging

from ....schemas.indicadores import (
    IndicadorResponse,
    IndicadorHistoricoRequest,
    IndicadorHistoricoResponse,
    ProyeccionRequest,
    ProyeccionResponse,
    IndicadoresResumenResponse,
    SerieTemporalResponse,
    ComparativoRegionalResponse,
    AlertaIndicadorResponse
)
from ....schemas.base import (
    PaginatedResponse,
    ErrorResponse,
    SuccessResponse
)
from ....services.ie_indicadores import ServicioIndicadoresEconomicos
from ....config import settings
from ..dependencies import (
    get_current_user,
    get_db_session,
    verify_api_key,
    rate_limiter
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/indicadores",
    tags=["Indicadores Económicos"],
    responses={
        401: {"model": ErrorResponse, "description": "No autorizado"},
        403: {"model": ErrorResponse, "description": "Prohibido"},
        429: {"model": ErrorResponse, "description": "Rate limit excedido"},
        500: {"model": ErrorResponse, "description": "Error interno"}
    }
)

# Instancia global del servicio
_servicio_indicadores: Optional[ServicioIndicadoresEconomicos] = None


class TipoIndicador(str, Enum):
    """Tipos de indicadores disponibles"""
    UF = "uf"
    UTM = "utm"
    IPC = "ipc"
    DOLAR = "dolar"
    EURO = "euro"
    TASA_POLITICA = "tasa_politica"
    IMACEC = "imacec"
    DESEMPLEO = "desempleo"
    PIB = "pib"
    TASA_HIPOTECARIA = "tasa_hipotecaria"


class PeriodoProyeccion(str, Enum):
    """Períodos de proyección"""
    MENSUAL = "mensual"
    TRIMESTRAL = "trimestral"
    SEMESTRAL = "semestral"
    ANUAL = "anual"


async def get_servicio_indicadores() -> ServicioIndicadoresEconomicos:
    """Dependency injection para servicio de indicadores"""
    global _servicio_indicadores
    if _servicio_indicadores is None:
        _servicio_indicadores = ServicioIndicadoresEconomicos()
    return _servicio_indicadores


# ============================================================================
# ENDPOINTS PRINCIPALES
# ============================================================================

@router.get(
    "/actual/{tipo}",
    response_model=IndicadorResponse,
    summary="Obtener valor actual de indicador",
    description="""
    Retorna el valor más reciente de un indicador económico específico.
    
    **Indicadores disponibles:**
    - `uf`: Unidad de Fomento
    - `utm`: Unidad Tributaria Mensual
    - `ipc`: Índice de Precios al Consumidor
    - `dolar`: Tipo de cambio USD/CLP
    - `euro`: Tipo de cambio EUR/CLP
    - `tasa_politica`: Tasa de Política Monetaria BCCh
    - `imacec`: Índice Mensual de Actividad Económica
    - `desempleo`: Tasa de desempleo INE
    - `tasa_hipotecaria`: Tasa hipotecaria promedio
    
    **Fuente:** Banco Central de Chile (API SI3)
    """,
    responses={
        200: {
            "description": "Valor actual del indicador",
            "content": {
                "application/json": {
                    "example": {
                        "tipo": "uf",
                        "valor": 37845.32,
                        "fecha": "2026-02-01",
                        "variacion_diaria": 0.02,
                        "variacion_mensual": 0.45,
                        "fuente": "Banco Central de Chile",
                        "actualizado_en": "2026-02-01T08:00:00Z"
                    }
                }
            }
        },
        404: {"description": "Indicador no encontrado"}
    }
)
async def obtener_indicador_actual(
    tipo: TipoIndicador,
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    _: dict = Depends(verify_api_key)
):
    """Obtener valor actual de un indicador económico"""
    try:
        resultado = await servicio.obtener_indicador_actual(tipo.value)
        
        if resultado is None:
            raise HTTPException(
                status_code=404,
                detail=f"Indicador '{tipo.value}' no disponible"
            )
        
        return IndicadorResponse(
            tipo=tipo.value,
            valor=resultado["valor"],
            fecha=resultado["fecha"],
            variacion_diaria=resultado.get("variacion_diaria"),
            variacion_mensual=resultado.get("variacion_mensual"),
            variacion_anual=resultado.get("variacion_anual"),
            fuente=resultado.get("fuente", "Banco Central de Chile"),
            actualizado_en=datetime.utcnow()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error obteniendo indicador {tipo}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/resumen",
    response_model=IndicadoresResumenResponse,
    summary="Resumen de todos los indicadores",
    description="""
    Retorna un resumen con los valores actuales de todos los indicadores
    económicos principales de Chile.
    
    Incluye variaciones diarias, mensuales y anuales cuando están disponibles.
    """
)
async def obtener_resumen_indicadores(
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    _: dict = Depends(verify_api_key)
):
    """Obtener resumen de todos los indicadores económicos"""
    try:
        indicadores = await servicio.obtener_todos_indicadores()
        
        return IndicadoresResumenResponse(
            fecha=date.today(),
            indicadores=indicadores,
            total=len(indicadores),
            fuentes=["BCCh", "INE", "CMF"],
            actualizado_en=datetime.utcnow()
        )
        
    except Exception as e:
        logger.error(f"Error obteniendo resumen indicadores: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/historico/{tipo}",
    response_model=IndicadorHistoricoResponse,
    summary="Serie histórica de indicador",
    description="""
    Retorna la serie histórica de un indicador económico para un rango de fechas.
    
    **Límites:**
    - Máximo 365 días por consulta
    - Datos disponibles desde 2010
    
    **Formato de fechas:** YYYY-MM-DD
    """
)
async def obtener_historico_indicador(
    tipo: TipoIndicador,
    fecha_inicio: date = Query(..., description="Fecha inicio (YYYY-MM-DD)"),
    fecha_fin: date = Query(default=None, description="Fecha fin (YYYY-MM-DD), default: hoy"),
    frecuencia: str = Query(default="diaria", regex="^(diaria|semanal|mensual)$"),
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    _: dict = Depends(verify_api_key)
):
    """Obtener serie histórica de un indicador"""
    try:
        if fecha_fin is None:
            fecha_fin = date.today()
        
        # Validar rango máximo
        dias_diferencia = (fecha_fin - fecha_inicio).days
        if dias_diferencia > 365:
            raise HTTPException(
                status_code=400,
                detail="Rango máximo permitido: 365 días"
            )
        
        if fecha_inicio > fecha_fin:
            raise HTTPException(
                status_code=400,
                detail="fecha_inicio debe ser anterior a fecha_fin"
            )
        
        resultado = await servicio.obtener_serie_historica(
            tipo=tipo.value,
            fecha_inicio=fecha_inicio,
            fecha_fin=fecha_fin,
            frecuencia=frecuencia
        )
        
        return IndicadorHistoricoResponse(
            tipo=tipo.value,
            fecha_inicio=fecha_inicio,
            fecha_fin=fecha_fin,
            frecuencia=frecuencia,
            datos=resultado["datos"],
            estadisticas={
                "minimo": resultado["min"],
                "maximo": resultado["max"],
                "promedio": resultado["promedio"],
                "desviacion": resultado["desviacion"],
                "tendencia": resultado["tendencia"]
            },
            total_registros=len(resultado["datos"]),
            fuente=resultado.get("fuente", "BCCh")
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error obteniendo histórico {tipo}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/proyeccion",
    response_model=ProyeccionResponse,
    summary="Proyección de indicador (ARIMA/Prophet)",
    description="""
    Genera proyecciones de indicadores económicos usando modelos de series temporales.
    
    **Modelos disponibles:**
    - `arima`: Auto-ARIMA con detección automática de parámetros
    - `prophet`: Facebook Prophet con estacionalidad
    - `ensemble`: Combinación ponderada de modelos
    
    **Horizontes de proyección:**
    - Mensual: hasta 12 meses
    - Trimestral: hasta 4 trimestres
    - Anual: hasta 3 años
    
    **Intervalos de confianza:** 80% y 95%
    """
)
async def generar_proyeccion(
    request: ProyeccionRequest,
    background_tasks: BackgroundTasks,
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    current_user: dict = Depends(get_current_user)
):
    """Generar proyección de indicador económico"""
    try:
        # Validar horizonte según período
        max_horizonte = {
            "mensual": 12,
            "trimestral": 4,
            "anual": 3
        }
        
        if request.horizonte > max_horizonte.get(request.periodo, 12):
            raise HTTPException(
                status_code=400,
                detail=f"Horizonte máximo para período {request.periodo}: {max_horizonte[request.periodo]}"
            )
        
        resultado = await servicio.generar_proyeccion(
            tipo=request.tipo,
            horizonte=request.horizonte,
            periodo=request.periodo,
            modelo=request.modelo,
            incluir_intervalos=request.incluir_intervalos
        )
        
        # Log asíncrono para auditoría
        background_tasks.add_task(
            _log_proyeccion,
            user_id=current_user.get("id"),
            tipo=request.tipo,
            horizonte=request.horizonte
        )
        
        return ProyeccionResponse(
            tipo=request.tipo,
            modelo_usado=resultado["modelo"],
            horizonte=request.horizonte,
            periodo=request.periodo,
            proyecciones=resultado["proyecciones"],
            intervalos_confianza=resultado.get("intervalos"),
            metricas_modelo={
                "mape": resultado.get("mape"),
                "rmse": resultado.get("rmse"),
                "aic": resultado.get("aic"),
                "r2": resultado.get("r2")
            },
            fecha_base=resultado["fecha_base"],
            generado_en=datetime.utcnow(),
            advertencias=resultado.get("advertencias", [])
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generando proyección: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/series/{tipo}",
    response_model=SerieTemporalResponse,
    summary="Serie temporal con análisis",
    description="""
    Retorna una serie temporal con análisis estadístico completo.
    
    **Incluye:**
    - Descomposición estacional (tendencia, estacionalidad, residuos)
    - Test de estacionariedad (ADF)
    - Autocorrelación (ACF/PACF)
    - Detección de cambios estructurales
    """
)
async def obtener_serie_temporal(
    tipo: TipoIndicador,
    años: int = Query(default=5, ge=1, le=15, description="Años de historia"),
    incluir_descomposicion: bool = Query(default=True),
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    _: dict = Depends(verify_api_key)
):
    """Obtener serie temporal con análisis estadístico"""
    try:
        resultado = await servicio.analizar_serie_temporal(
            tipo=tipo.value,
            años=años,
            incluir_descomposicion=incluir_descomposicion
        )
        
        return SerieTemporalResponse(
            tipo=tipo.value,
            periodo_analisis=f"{años} años",
            datos=resultado["datos"],
            descomposicion=resultado.get("descomposicion"),
            tests_estadisticos={
                "adf_statistic": resultado.get("adf_stat"),
                "adf_pvalue": resultado.get("adf_pvalue"),
                "es_estacionaria": resultado.get("es_estacionaria"),
                "kpss_statistic": resultado.get("kpss_stat")
            },
            cambios_estructurales=resultado.get("breakpoints", []),
            correlaciones=resultado.get("correlaciones"),
            total_observaciones=len(resultado["datos"])
        )
        
    except Exception as e:
        logger.error(f"Error analizando serie temporal: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/comparativo-regional",
    response_model=ComparativoRegionalResponse,
    summary="Comparativo regional de indicadores",
    description="""
    Compara indicadores económicos entre regiones de Chile.
    
    **Indicadores regionales disponibles:**
    - PIB regional
    - Desempleo regional
    - IPC regional (cuando disponible)
    - Salarios promedio
    
    **Regiones:** Todas las 16 regiones de Chile
    """
)
async def obtener_comparativo_regional(
    indicador: str = Query(..., description="Indicador a comparar"),
    regiones: Optional[List[str]] = Query(default=None, description="Lista de regiones (código o nombre)"),
    año: int = Query(default=None, description="Año de comparación"),
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    _: dict = Depends(verify_api_key)
):
    """Obtener comparativo regional de indicadores"""
    try:
        resultado = await servicio.comparativo_regional(
            indicador=indicador,
            regiones=regiones,
            año=año or date.today().year
        )
        
        return ComparativoRegionalResponse(
            indicador=indicador,
            año=año or date.today().year,
            datos_regionales=resultado["datos"],
            ranking=resultado["ranking"],
            estadisticas_nacionales={
                "promedio": resultado["promedio_nacional"],
                "mediana": resultado["mediana_nacional"],
                "desviacion": resultado["desviacion"]
            },
            fuente=resultado.get("fuente", "INE/BCCh")
        )
        
    except Exception as e:
        logger.error(f"Error en comparativo regional: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ENDPOINTS DE CONVERSIÓN Y CÁLCULO
# ============================================================================

@router.get(
    "/convertir/uf",
    summary="Convertir monto a/desde UF",
    description="Convierte montos entre CLP y UF usando el valor del día"
)
async def convertir_uf(
    monto: float = Query(..., description="Monto a convertir"),
    direccion: str = Query(..., regex="^(clp_a_uf|uf_a_clp)$"),
    fecha: Optional[date] = Query(default=None, description="Fecha para conversión histórica"),
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    _: dict = Depends(verify_api_key)
):
    """Convertir entre CLP y UF"""
    try:
        resultado = await servicio.convertir_uf(
            monto=monto,
            direccion=direccion,
            fecha=fecha
        )
        
        return {
            "monto_original": monto,
            "moneda_origen": "CLP" if direccion == "clp_a_uf" else "UF",
            "monto_convertido": resultado["monto_convertido"],
            "moneda_destino": "UF" if direccion == "clp_a_uf" else "CLP",
            "uf_usada": resultado["uf_valor"],
            "fecha_uf": resultado["fecha"],
            "fuente": "BCCh"
        }
        
    except Exception as e:
        logger.error(f"Error en conversión UF: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/ajuste-inflacion",
    summary="Ajustar monto por inflación",
    description="Ajusta un monto histórico a valor presente usando IPC"
)
async def ajustar_inflacion(
    monto: float = Query(..., description="Monto histórico"),
    fecha_origen: date = Query(..., description="Fecha del monto original"),
    fecha_destino: Optional[date] = Query(default=None, description="Fecha destino (default: hoy)"),
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    _: dict = Depends(verify_api_key)
):
    """Ajustar monto por inflación"""
    try:
        resultado = await servicio.ajustar_por_inflacion(
            monto=monto,
            fecha_origen=fecha_origen,
            fecha_destino=fecha_destino or date.today()
        )
        
        return {
            "monto_original": monto,
            "fecha_origen": fecha_origen,
            "monto_ajustado": resultado["monto_ajustado"],
            "fecha_destino": fecha_destino or date.today(),
            "inflacion_acumulada": resultado["inflacion_acumulada"],
            "factor_ajuste": resultado["factor"],
            "ipc_origen": resultado["ipc_origen"],
            "ipc_destino": resultado["ipc_destino"],
            "fuente": "INE"
        }
        
    except Exception as e:
        logger.error(f"Error en ajuste inflación: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ENDPOINTS DE ALERTAS Y MONITOREO
# ============================================================================

@router.get(
    "/alertas",
    response_model=List[AlertaIndicadorResponse],
    summary="Alertas de indicadores",
    description="""
    Retorna alertas activas sobre movimientos significativos en indicadores.
    
    **Tipos de alertas:**
    - Variación diaria superior a umbral
    - Cambio de tendencia
    - Máximo/mínimo histórico
    - Divergencia respecto a proyección
    """
)
async def obtener_alertas_indicadores(
    tipos: Optional[List[TipoIndicador]] = Query(default=None),
    severidad_minima: str = Query(default="media", regex="^(baja|media|alta|critica)$"),
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    current_user: dict = Depends(get_current_user)
):
    """Obtener alertas activas de indicadores"""
    try:
        alertas = await servicio.obtener_alertas(
            tipos=[t.value for t in tipos] if tipos else None,
            severidad_minima=severidad_minima
        )
        
        return [
            AlertaIndicadorResponse(
                id=a["id"],
                tipo_indicador=a["tipo"],
                tipo_alerta=a["tipo_alerta"],
                severidad=a["severidad"],
                mensaje=a["mensaje"],
                valor_actual=a["valor_actual"],
                valor_referencia=a.get("valor_referencia"),
                variacion=a.get("variacion"),
                creada_en=a["creada_en"],
                activa=a["activa"]
            )
            for a in alertas
        ]
        
    except Exception as e:
        logger.error(f"Error obteniendo alertas: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/alertas/configurar",
    summary="Configurar alerta personalizada",
    description="Configura una alerta personalizada para un indicador"
)
async def configurar_alerta(
    tipo: TipoIndicador,
    umbral_superior: Optional[float] = None,
    umbral_inferior: Optional[float] = None,
    variacion_porcentual: Optional[float] = None,
    notificar_email: bool = True,
    current_user: dict = Depends(get_current_user)
):
    """Configurar alerta personalizada"""
    try:
        # Validar que al menos un umbral esté definido
        if all(v is None for v in [umbral_superior, umbral_inferior, variacion_porcentual]):
            raise HTTPException(
                status_code=400,
                detail="Debe especificar al menos un umbral o variación"
            )
        
        # Aquí se guardaría la configuración en BD
        return SuccessResponse(
            success=True,
            message=f"Alerta configurada para {tipo.value}",
            data={
                "tipo": tipo.value,
                "umbral_superior": umbral_superior,
                "umbral_inferior": umbral_inferior,
                "variacion_porcentual": variacion_porcentual,
                "notificar_email": notificar_email,
                "user_id": current_user.get("id")
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error configurando alerta: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ENDPOINTS DE CORRELACIÓN Y ANÁLISIS
# ============================================================================

@router.get(
    "/correlacion",
    summary="Matriz de correlación entre indicadores",
    description="Calcula la correlación entre múltiples indicadores económicos"
)
async def calcular_correlacion(
    indicadores: List[TipoIndicador] = Query(..., min_items=2, max_items=10),
    periodo_meses: int = Query(default=24, ge=6, le=120),
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    _: dict = Depends(verify_api_key)
):
    """Calcular correlación entre indicadores"""
    try:
        resultado = await servicio.calcular_correlacion(
            indicadores=[i.value for i in indicadores],
            meses=periodo_meses
        )
        
        return {
            "indicadores": [i.value for i in indicadores],
            "periodo_meses": periodo_meses,
            "matriz_correlacion": resultado["matriz"],
            "correlaciones_significativas": resultado["significativas"],
            "p_values": resultado["p_values"],
            "observaciones": resultado["n_obs"],
            "interpretacion": resultado.get("interpretacion")
        }
        
    except Exception as e:
        logger.error(f"Error calculando correlación: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/impacto-inmobiliario",
    summary="Análisis de impacto en sector inmobiliario",
    description="""
    Analiza el impacto de indicadores macroeconómicos en el sector inmobiliario.
    
    **Variables analizadas:**
    - Tasa de política monetaria vs ventas inmobiliarias
    - IPC vs precios de vivienda
    - Desempleo vs demanda
    - Tasas hipotecarias vs accesibilidad
    """
)
async def analizar_impacto_inmobiliario(
    region: Optional[str] = Query(default=None, description="Región específica"),
    segmento: str = Query(default="residencial", regex="^(residencial|comercial|industrial)$"),
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores),
    _: dict = Depends(verify_api_key)
):
    """Analizar impacto de indicadores en sector inmobiliario"""
    try:
        resultado = await servicio.analizar_impacto_inmobiliario(
            region=region,
            segmento=segmento
        )
        
        return {
            "region": region or "Nacional",
            "segmento": segmento,
            "fecha_analisis": date.today(),
            "indicadores_clave": resultado["indicadores"],
            "impactos": resultado["impactos"],
            "indice_accesibilidad": resultado["indice_accesibilidad"],
            "tendencia_mercado": resultado["tendencia"],
            "riesgos_identificados": resultado["riesgos"],
            "oportunidades": resultado["oportunidades"],
            "recomendaciones": resultado["recomendaciones"]
        }
        
    except Exception as e:
        logger.error(f"Error en análisis impacto inmobiliario: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# FUNCIONES AUXILIARES
# ============================================================================

async def _log_proyeccion(user_id: str, tipo: str, horizonte: int):
    """Log asíncrono de proyecciones para auditoría"""
    logger.info(f"Proyección generada: user={user_id}, tipo={tipo}, horizonte={horizonte}")


# ============================================================================
# HEALTH CHECK ESPECÍFICO
# ============================================================================

@router.get(
    "/health",
    summary="Health check del servicio de indicadores",
    include_in_schema=False
)
async def health_check_indicadores(
    servicio: ServicioIndicadoresEconomicos = Depends(get_servicio_indicadores)
):
    """Health check del servicio"""
    try:
        # Verificar conexión a fuentes
        status = await servicio.verificar_conexiones()
        
        return {
            "servicio": "ie_indicadores",
            "status": "healthy" if status["ok"] else "degraded",
            "fuentes": status["fuentes"],
            "cache_status": status.get("cache"),
            "ultima_actualizacion": status.get("ultima_actualizacion"),
            "timestamp": datetime.utcnow()
        }
        
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "servicio": "ie_indicadores",
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )
