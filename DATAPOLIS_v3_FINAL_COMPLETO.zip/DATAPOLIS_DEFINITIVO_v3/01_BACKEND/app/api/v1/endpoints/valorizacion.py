# -*- coding: utf-8 -*-
"""
DATAPOLIS v3.0 - Router API: Valorización Inmobiliaria (M04)
=============================================================
Endpoints REST para tasación automatizada conforme IVS 2022.

Metodologías:
- Comparación de mercado (Sales Comparison)
- Capitalización de rentas (Income Approach)
- Costo de reposición (Cost Approach)
- Machine Learning (XGBoost ensemble)

Autor: DATAPOLIS SpA
Versión: 3.0.0
"""

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks, UploadFile, File
from fastapi.responses import JSONResponse, StreamingResponse
from typing import Optional, List, Dict, Any
from datetime import date, datetime
from enum import Enum
from decimal import Decimal
import logging
import io

from ....schemas.valorizacion import (
    TasacionRequest,
    TasacionResponse,
    TasacionDetalladaResponse,
    ComparablesRequest,
    ComparablesResponse,
    ValorizacionMasivaRequest,
    ValorizacionMasivaResponse,
    AnalisisSensibilidadResponse,
    InformeValorizacionResponse,
    HistorialValorizacionResponse
)
from ....schemas.base import (
    PaginatedResponse,
    ErrorResponse,
    SuccessResponse,
    GeoJSONFeature
)
from ....services.m04_valorizacion import ServicioValorizacion
from ....config import settings
from ..dependencies import (
    get_current_user,
    get_db_session,
    verify_api_key,
    rate_limiter,
    verify_permission
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/valorizacion",
    tags=["Valorización Inmobiliaria"],
    responses={
        401: {"model": ErrorResponse, "description": "No autorizado"},
        403: {"model": ErrorResponse, "description": "Prohibido"},
        429: {"model": ErrorResponse, "description": "Rate limit excedido"},
        500: {"model": ErrorResponse, "description": "Error interno"}
    }
)

# Instancia global del servicio
_servicio_valorizacion: Optional[ServicioValorizacion] = None


class MetodoValorizacion(str, Enum):
    """Métodos de valorización disponibles"""
    COMPARACION = "comparacion"
    CAPITALIZACION = "capitalizacion"
    COSTO = "costo"
    ML = "ml"
    ENSEMBLE = "ensemble"  # Combinación ponderada


class TipoPropiedad(str, Enum):
    """Tipos de propiedad"""
    CASA = "casa"
    DEPARTAMENTO = "departamento"
    TERRENO = "terreno"
    OFICINA = "oficina"
    LOCAL_COMERCIAL = "local_comercial"
    BODEGA = "bodega"
    ESTACIONAMIENTO = "estacionamiento"


class PropositoTasacion(str, Enum):
    """Propósitos de tasación según IVS 2022"""
    COMPRAVENTA = "compraventa"
    HIPOTECARIO = "hipotecario"
    TRIBUTARIO = "tributario"
    CONTABLE = "contable"
    JUDICIAL = "judicial"
    SEGURO = "seguro"
    INVERSION = "inversion"


async def get_servicio_valorizacion() -> ServicioValorizacion:
    """Dependency injection para servicio de valorización"""
    global _servicio_valorizacion
    if _servicio_valorizacion is None:
        _servicio_valorizacion = ServicioValorizacion()
    return _servicio_valorizacion


# ============================================================================
# ENDPOINTS DE TASACIÓN
# ============================================================================

@router.post(
    "/tasar",
    response_model=TasacionResponse,
    summary="Tasación automatizada de propiedad",
    description="""
    Realiza una tasación automatizada de una propiedad utilizando múltiples metodologías
    conforme a los estándares IVS 2022 (International Valuation Standards).
    
    **Metodologías disponibles:**
    - `comparacion`: Sales Comparison Approach - basado en transacciones comparables
    - `capitalizacion`: Income Approach - basado en flujos de renta proyectados
    - `costo`: Cost Approach - costo de reposición depreciado
    - `ml`: Machine Learning - modelo XGBoost entrenado con mercado chileno
    - `ensemble`: Combinación ponderada de todos los métodos
    
    **Propósitos soportados:**
    - Compraventa, hipotecario, tributario, contable, judicial, seguro, inversión
    
    **Outputs:**
    - Valor estimado con intervalos de confianza
    - Comparables utilizados con ajustes
    - Explicabilidad del modelo ML (SHAP)
    - Alertas y riesgos identificados
    """,
    responses={
        200: {
            "description": "Tasación exitosa",
            "content": {
                "application/json": {
                    "example": {
                        "id_tasacion": "TAS-2026-000123",
                        "valor_estimado": 185000000,
                        "valor_uf": 4890.5,
                        "moneda": "CLP",
                        "intervalo_confianza": {
                            "minimo": 175000000,
                            "maximo": 195000000,
                            "nivel": 0.95
                        },
                        "metodo_principal": "ensemble",
                        "confianza": 0.87,
                        "fecha_valoracion": "2026-02-01"
                    }
                }
            }
        }
    }
)
async def tasar_propiedad(
    request: TasacionRequest,
    background_tasks: BackgroundTasks,
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    current_user: dict = Depends(get_current_user)
):
    """Realizar tasación automatizada de propiedad"""
    try:
        # Ejecutar tasación
        resultado = await servicio.tasar(
            propiedad=request.propiedad,
            metodo=request.metodo or "ensemble",
            proposito=request.proposito or "compraventa",
            fecha_valoracion=request.fecha_valoracion or date.today(),
            incluir_comparables=request.incluir_comparables,
            radio_busqueda_km=request.radio_busqueda_km or 2.0,
            max_comparables=request.max_comparables or 10,
            ajustes_personalizados=request.ajustes_personalizados
        )
        
        # Log asíncrono
        background_tasks.add_task(
            _log_tasacion,
            user_id=current_user.get("id"),
            id_tasacion=resultado["id"],
            valor=resultado["valor_estimado"]
        )
        
        return TasacionResponse(
            id_tasacion=resultado["id"],
            estado="completada",
            valor_estimado=resultado["valor_estimado"],
            valor_uf=resultado["valor_uf"],
            valor_utm=resultado.get("valor_utm"),
            moneda="CLP",
            intervalo_confianza={
                "minimo": resultado["intervalo_min"],
                "maximo": resultado["intervalo_max"],
                "nivel": 0.95
            },
            metodo_principal=resultado["metodo_usado"],
            metodos_aplicados=resultado["metodos_detalle"],
            confianza=resultado["confianza"],
            comparables_usados=resultado.get("n_comparables", 0),
            fecha_valoracion=resultado["fecha_valoracion"],
            fecha_emision=datetime.utcnow(),
            proposito=request.proposito or "compraventa",
            alertas=resultado.get("alertas", []),
            disclaimer=_get_disclaimer_tasacion(request.proposito)
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error en tasación: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/tasar/detallada",
    response_model=TasacionDetalladaResponse,
    summary="Tasación detallada con explicabilidad completa",
    description="""
    Versión extendida de la tasación con análisis completo:
    
    - Detalle de cada metodología aplicada
    - Lista completa de comparables con ajustes individuales
    - Análisis de sensibilidad
    - Explicaciones SHAP del modelo ML
    - Factores de riesgo identificados
    - Recomendaciones
    """
)
async def tasar_propiedad_detallada(
    request: TasacionRequest,
    background_tasks: BackgroundTasks,
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    current_user: dict = Depends(get_current_user)
):
    """Tasación detallada con explicabilidad completa"""
    try:
        resultado = await servicio.tasar_detallado(
            propiedad=request.propiedad,
            metodo=request.metodo or "ensemble",
            proposito=request.proposito or "compraventa",
            fecha_valoracion=request.fecha_valoracion or date.today(),
            radio_busqueda_km=request.radio_busqueda_km or 3.0,
            max_comparables=request.max_comparables or 20
        )
        
        return TasacionDetalladaResponse(
            id_tasacion=resultado["id"],
            estado="completada",
            
            # Valores principales
            valor_estimado=resultado["valor_estimado"],
            valor_uf=resultado["valor_uf"],
            valor_por_m2=resultado["valor_m2"],
            intervalo_confianza=resultado["intervalo"],
            
            # Metodologías
            metodologias={
                "comparacion": resultado.get("comparacion"),
                "capitalizacion": resultado.get("capitalizacion"),
                "costo": resultado.get("costo"),
                "ml": resultado.get("ml")
            },
            pesos_metodologias=resultado["pesos"],
            
            # Comparables
            comparables=resultado["comparables"],
            ajustes_aplicados=resultado["ajustes"],
            
            # ML y explicabilidad
            features_modelo=resultado.get("features_ml"),
            shap_explicaciones=resultado.get("shap"),
            importancia_variables=resultado.get("importancia"),
            
            # Análisis
            analisis_mercado=resultado.get("analisis_mercado"),
            factores_riesgo=resultado.get("riesgos"),
            oportunidades=resultado.get("oportunidades"),
            
            # Sensibilidad
            sensibilidad={
                "superficie": resultado.get("sens_superficie"),
                "ubicacion": resultado.get("sens_ubicacion"),
                "antiguedad": resultado.get("sens_antiguedad"),
                "calidad": resultado.get("sens_calidad")
            },
            
            # Metadatos
            metricas_calidad={
                "r2_modelo": resultado.get("r2"),
                "mape": resultado.get("mape"),
                "n_comparables": resultado.get("n_comparables"),
                "coeficiente_variacion": resultado.get("cv")
            },
            
            fecha_valoracion=resultado["fecha_valoracion"],
            fecha_emision=datetime.utcnow(),
            tasador_responsable=resultado.get("tasador", "Sistema Automatizado"),
            
            recomendaciones=resultado.get("recomendaciones", []),
            disclaimer=_get_disclaimer_tasacion(request.proposito),
            hash_verificacion=resultado.get("hash")
        )
        
    except Exception as e:
        logger.error(f"Error en tasación detallada: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/tasacion/{id_tasacion}",
    response_model=TasacionResponse,
    summary="Obtener tasación por ID"
)
async def obtener_tasacion(
    id_tasacion: str,
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    current_user: dict = Depends(get_current_user)
):
    """Obtener una tasación existente por su ID"""
    try:
        resultado = await servicio.obtener_tasacion(id_tasacion)
        
        if resultado is None:
            raise HTTPException(
                status_code=404,
                detail=f"Tasación {id_tasacion} no encontrada"
            )
        
        return TasacionResponse(**resultado)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error obteniendo tasación: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ENDPOINTS DE COMPARABLES
# ============================================================================

@router.post(
    "/comparables/buscar",
    response_model=ComparablesResponse,
    summary="Buscar propiedades comparables",
    description="""
    Busca propiedades comparables para una propiedad objetivo.
    
    **Criterios de búsqueda:**
    - Radio geográfico (PostGIS)
    - Tipo de propiedad
    - Rango de superficie (±20%)
    - Antigüedad similar
    - Transacciones recientes (últimos 12 meses)
    
    **Ajustes automáticos:**
    - Ubicación (microzona)
    - Superficie
    - Antigüedad y estado
    - Características adicionales
    - Tiempo de transacción
    """
)
async def buscar_comparables(
    request: ComparablesRequest,
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    _: dict = Depends(verify_api_key)
):
    """Buscar propiedades comparables"""
    try:
        resultado = await servicio.buscar_comparables(
            latitud=request.latitud,
            longitud=request.longitud,
            tipo_propiedad=request.tipo_propiedad,
            superficie_m2=request.superficie_m2,
            antiguedad_anos=request.antiguedad_anos,
            radio_km=request.radio_km or 2.0,
            max_resultados=request.max_resultados or 15,
            meses_atras=request.meses_atras or 12,
            solo_transacciones=request.solo_transacciones
        )
        
        return ComparablesResponse(
            propiedad_objetivo={
                "latitud": request.latitud,
                "longitud": request.longitud,
                "tipo": request.tipo_propiedad,
                "superficie_m2": request.superficie_m2
            },
            comparables=resultado["comparables"],
            total_encontrados=resultado["total"],
            radio_efectivo_km=resultado["radio_usado"],
            criterios_busqueda={
                "radio_km": request.radio_km or 2.0,
                "meses_atras": request.meses_atras or 12,
                "tipo_propiedad": request.tipo_propiedad
            },
            estadisticas={
                "precio_m2_promedio": resultado["precio_m2_promedio"],
                "precio_m2_mediana": resultado["precio_m2_mediana"],
                "precio_m2_min": resultado["precio_m2_min"],
                "precio_m2_max": resultado["precio_m2_max"],
                "desviacion_estandar": resultado["desviacion"]
            },
            fecha_consulta=datetime.utcnow()
        )
        
    except Exception as e:
        logger.error(f"Error buscando comparables: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/comparables/mapa",
    summary="Mapa de comparables (GeoJSON)",
    description="Retorna comparables en formato GeoJSON para visualización en mapa"
)
async def mapa_comparables(
    latitud: float = Query(..., ge=-56, le=-17),
    longitud: float = Query(..., ge=-76, le=-66),
    tipo_propiedad: TipoPropiedad = Query(...),
    radio_km: float = Query(default=2.0, ge=0.5, le=10),
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    _: dict = Depends(verify_api_key)
):
    """Obtener comparables en formato GeoJSON"""
    try:
        resultado = await servicio.comparables_geojson(
            latitud=latitud,
            longitud=longitud,
            tipo_propiedad=tipo_propiedad.value,
            radio_km=radio_km
        )
        
        return {
            "type": "FeatureCollection",
            "features": resultado["features"],
            "properties": {
                "centro": [longitud, latitud],
                "radio_km": radio_km,
                "total_features": len(resultado["features"]),
                "bbox": resultado.get("bbox")
            }
        }
        
    except Exception as e:
        logger.error(f"Error generando mapa comparables: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# VALORIZACIÓN MASIVA
# ============================================================================

@router.post(
    "/masiva",
    response_model=ValorizacionMasivaResponse,
    summary="Valorización masiva de propiedades",
    description="""
    Realiza valorización de múltiples propiedades en batch.
    
    **Límites:**
    - Máximo 100 propiedades por request
    - Timeout: 5 minutos
    
    **Ideal para:**
    - Carteras inmobiliarias
    - Portafolios de inversión
    - Avalúos tributarios masivos
    """
)
async def valorizar_masivo(
    request: ValorizacionMasivaRequest,
    background_tasks: BackgroundTasks,
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    current_user: dict = Depends(get_current_user)
):
    """Valorización masiva de propiedades"""
    try:
        if len(request.propiedades) > 100:
            raise HTTPException(
                status_code=400,
                detail="Máximo 100 propiedades por request"
            )
        
        resultado = await servicio.valorizar_masivo(
            propiedades=request.propiedades,
            metodo=request.metodo or "ensemble",
            proposito=request.proposito or "compraventa"
        )
        
        return ValorizacionMasivaResponse(
            id_lote=resultado["id_lote"],
            estado="completado",
            total_propiedades=len(request.propiedades),
            exitosas=resultado["exitosas"],
            fallidas=resultado["fallidas"],
            resultados=resultado["resultados"],
            resumen={
                "valor_total": resultado["valor_total"],
                "valor_total_uf": resultado["valor_total_uf"],
                "valor_promedio": resultado["valor_promedio"],
                "valor_m2_promedio": resultado["valor_m2_promedio"]
            },
            tiempo_procesamiento_ms=resultado["tiempo_ms"],
            fecha_proceso=datetime.utcnow()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error en valorización masiva: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/masiva/archivo",
    summary="Valorización masiva desde archivo",
    description="Procesa archivo Excel/CSV con propiedades para valorización masiva"
)
async def valorizar_desde_archivo(
    archivo: UploadFile = File(..., description="Archivo Excel o CSV"),
    metodo: MetodoValorizacion = Query(default=MetodoValorizacion.ENSEMBLE),
    proposito: PropositoTasacion = Query(default=PropositoTasacion.COMPRAVENTA),
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    current_user: dict = Depends(get_current_user)
):
    """Valorización masiva desde archivo"""
    try:
        # Validar tipo archivo
        if not archivo.filename.endswith(('.xlsx', '.csv')):
            raise HTTPException(
                status_code=400,
                detail="Formato no soportado. Use Excel (.xlsx) o CSV (.csv)"
            )
        
        # Leer archivo
        contenido = await archivo.read()
        
        resultado = await servicio.valorizar_desde_archivo(
            contenido=contenido,
            nombre_archivo=archivo.filename,
            metodo=metodo.value,
            proposito=proposito.value
        )
        
        return {
            "id_lote": resultado["id_lote"],
            "archivo_original": archivo.filename,
            "propiedades_procesadas": resultado["procesadas"],
            "exitosas": resultado["exitosas"],
            "fallidas": resultado["fallidas"],
            "errores": resultado.get("errores", []),
            "url_resultado": f"/api/v1/valorizacion/masiva/{resultado['id_lote']}/resultado"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error procesando archivo: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ANÁLISIS Y REPORTES
# ============================================================================

@router.get(
    "/analisis/sensibilidad/{id_tasacion}",
    response_model=AnalisisSensibilidadResponse,
    summary="Análisis de sensibilidad de tasación",
    description="""
    Analiza cómo varía el valor estimado ante cambios en variables clave.
    
    **Variables analizadas:**
    - Superficie (±10%, ±20%)
    - Antigüedad (±5 años)
    - Estado de conservación
    - Ubicación (microzona)
    - Condiciones de mercado
    """
)
async def analisis_sensibilidad(
    id_tasacion: str,
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    _: dict = Depends(verify_api_key)
):
    """Análisis de sensibilidad de una tasación"""
    try:
        resultado = await servicio.analisis_sensibilidad(id_tasacion)
        
        if resultado is None:
            raise HTTPException(
                status_code=404,
                detail=f"Tasación {id_tasacion} no encontrada"
            )
        
        return AnalisisSensibilidadResponse(
            id_tasacion=id_tasacion,
            valor_base=resultado["valor_base"],
            escenarios=resultado["escenarios"],
            variables_sensibles=[
                {
                    "variable": v["nombre"],
                    "elasticidad": v["elasticidad"],
                    "impacto_maximo": v["impacto_max"],
                    "direccion": v["direccion"]
                }
                for v in resultado["variables"]
            ],
            matriz_sensibilidad=resultado.get("matriz"),
            tornado_chart_data=resultado.get("tornado"),
            recomendaciones=resultado.get("recomendaciones", [])
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error en análisis sensibilidad: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/informe/{id_tasacion}",
    summary="Generar informe de tasación (PDF)",
    description="Genera informe profesional de tasación en formato PDF"
)
async def generar_informe_tasacion(
    id_tasacion: str,
    formato: str = Query(default="pdf", regex="^(pdf|docx|html)$"),
    incluir_comparables: bool = Query(default=True),
    incluir_fotos: bool = Query(default=True),
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    current_user: dict = Depends(get_current_user)
):
    """Generar informe de tasación"""
    try:
        resultado = await servicio.generar_informe(
            id_tasacion=id_tasacion,
            formato=formato,
            incluir_comparables=incluir_comparables,
            incluir_fotos=incluir_fotos,
            usuario=current_user.get("nombre", "Usuario")
        )
        
        if resultado is None:
            raise HTTPException(
                status_code=404,
                detail=f"Tasación {id_tasacion} no encontrada"
            )
        
        # Retornar archivo
        media_types = {
            "pdf": "application/pdf",
            "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "html": "text/html"
        }
        
        return StreamingResponse(
            io.BytesIO(resultado["contenido"]),
            media_type=media_types[formato],
            headers={
                "Content-Disposition": f"attachment; filename=Tasacion_{id_tasacion}.{formato}"
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generando informe: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/historial",
    response_model=HistorialValorizacionResponse,
    summary="Historial de valorizaciones de una propiedad",
    description="Obtiene el historial de todas las valorizaciones de una propiedad"
)
async def historial_valorizacion(
    rol_propiedad: Optional[str] = Query(default=None, description="ROL SII"),
    latitud: Optional[float] = Query(default=None),
    longitud: Optional[float] = Query(default=None),
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    _: dict = Depends(verify_api_key)
):
    """Obtener historial de valorizaciones"""
    try:
        if not rol_propiedad and not (latitud and longitud):
            raise HTTPException(
                status_code=400,
                detail="Debe proporcionar rol_propiedad o coordenadas"
            )
        
        resultado = await servicio.historial_valorizaciones(
            rol_propiedad=rol_propiedad,
            latitud=latitud,
            longitud=longitud
        )
        
        return HistorialValorizacionResponse(
            propiedad=resultado["propiedad"],
            valorizaciones=resultado["valorizaciones"],
            tendencia=resultado["tendencia"],
            variacion_total=resultado["variacion_total"],
            tasa_crecimiento_anual=resultado.get("cagr"),
            proyeccion_12m=resultado.get("proyeccion")
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error obteniendo historial: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ENDPOINTS DE MERCADO
# ============================================================================

@router.get(
    "/mercado/precios",
    summary="Precios de mercado por zona",
    description="Obtiene estadísticas de precios por zona geográfica"
)
async def precios_mercado_zona(
    comuna: str = Query(..., description="Nombre de comuna"),
    tipo_propiedad: TipoPropiedad = Query(...),
    periodo_meses: int = Query(default=12, ge=3, le=36),
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    _: dict = Depends(verify_api_key)
):
    """Obtener precios de mercado por zona"""
    try:
        resultado = await servicio.precios_por_zona(
            comuna=comuna,
            tipo_propiedad=tipo_propiedad.value,
            meses=periodo_meses
        )
        
        return {
            "comuna": comuna,
            "tipo_propiedad": tipo_propiedad.value,
            "periodo_meses": periodo_meses,
            "estadisticas": {
                "precio_m2_promedio": resultado["promedio"],
                "precio_m2_mediana": resultado["mediana"],
                "precio_m2_p25": resultado["p25"],
                "precio_m2_p75": resultado["p75"],
                "precio_m2_min": resultado["minimo"],
                "precio_m2_max": resultado["maximo"],
                "n_transacciones": resultado["n_transacciones"]
            },
            "tendencia": {
                "variacion_mensual": resultado["var_mensual"],
                "variacion_trimestral": resultado["var_trimestral"],
                "variacion_anual": resultado["var_anual"],
                "direccion": resultado["direccion"]
            },
            "comparativo_rm": resultado.get("vs_rm"),
            "fuentes": ["CBR", "Portal Inmobiliario", "SII"]
        }
        
    except Exception as e:
        logger.error(f"Error obteniendo precios mercado: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/mercado/heatmap",
    summary="Mapa de calor de precios",
    description="Genera datos para mapa de calor de precios por zona"
)
async def heatmap_precios(
    region: str = Query(default="RM", description="Código región"),
    tipo_propiedad: TipoPropiedad = Query(...),
    resolucion: str = Query(default="comuna", regex="^(comuna|distrito|manzana)$"),
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion),
    _: dict = Depends(verify_api_key)
):
    """Generar datos para heatmap de precios"""
    try:
        resultado = await servicio.heatmap_precios(
            region=region,
            tipo_propiedad=tipo_propiedad.value,
            resolucion=resolucion
        )
        
        return {
            "type": "FeatureCollection",
            "features": resultado["features"],
            "metadata": {
                "region": region,
                "tipo_propiedad": tipo_propiedad.value,
                "resolucion": resolucion,
                "precio_m2_min": resultado["min"],
                "precio_m2_max": resultado["max"],
                "escala_colores": resultado["escala"]
            }
        }
        
    except Exception as e:
        logger.error(f"Error generando heatmap: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# FUNCIONES AUXILIARES
# ============================================================================

def _get_disclaimer_tasacion(proposito: str) -> str:
    """Genera disclaimer según propósito de tasación"""
    disclaimers = {
        "compraventa": (
            "Esta tasación es una estimación automatizada basada en datos de mercado "
            "y modelos estadísticos. No constituye una tasación oficial y se recomienda "
            "complementar con una evaluación presencial por un tasador certificado."
        ),
        "hipotecario": (
            "Tasación automatizada para fines referenciales. Las instituciones financieras "
            "pueden requerir tasación presencial por tasador inscrito en la CMF."
        ),
        "tributario": (
            "Valor estimado para referencia. El avalúo fiscal oficial es determinado "
            "exclusivamente por el SII conforme a la Ley 17.235."
        ),
        "judicial": (
            "Estimación referencial. Para efectos judiciales se requiere tasación "
            "por perito tasador inscrito en el Poder Judicial."
        )
    }
    return disclaimers.get(proposito, disclaimers["compraventa"])


async def _log_tasacion(user_id: str, id_tasacion: str, valor: float):
    """Log asíncrono de tasaciones"""
    logger.info(f"Tasación completada: user={user_id}, id={id_tasacion}, valor={valor:,.0f}")


# ============================================================================
# HEALTH CHECK
# ============================================================================

@router.get(
    "/health",
    summary="Health check del servicio de valorización",
    include_in_schema=False
)
async def health_check(
    servicio: ServicioValorizacion = Depends(get_servicio_valorizacion)
):
    """Health check del servicio"""
    try:
        status = await servicio.verificar_estado()
        
        return {
            "servicio": "m04_valorizacion",
            "status": "healthy" if status["ok"] else "degraded",
            "modelo_ml": status.get("modelo_cargado"),
            "comparables_disponibles": status.get("n_comparables"),
            "ultima_actualizacion_datos": status.get("ultima_actualizacion"),
            "timestamp": datetime.utcnow()
        }
        
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "servicio": "m04_valorizacion",
                "status": "unhealthy",
                "error": str(e)
            }
        )
