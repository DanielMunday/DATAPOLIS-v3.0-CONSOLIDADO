# DATAPOLIS v3.0 - MANUAL DE IMPLEMENTACIÓN
## Servidor Local + cPanel

**Versión**: 3.0.0  
**Fecha**: Febrero 2026  
**Autor**: DATAPOLIS SpA  
**Normativa Principal**: NCG 514 CMF (Deadline Abril 2026)

---

## 📋 ÍNDICE

1. [Requisitos del Sistema](#1-requisitos-del-sistema)
2. [Instalación en Servidor Local](#2-instalación-en-servidor-local)
3. [Despliegue en cPanel](#3-despliegue-en-cpanel)
4. [Configuración de Base de Datos](#4-configuración-de-base-de-datos)
5. [Variables de Entorno](#5-variables-de-entorno)
6. [Configuración de Certificados](#6-configuración-de-certificados)
7. [Integración NCG 514](#7-integración-ncg-514)
8. [Monitoreo y Mantenimiento](#8-monitoreo-y-mantenimiento)
9. [Solución de Problemas](#9-solución-de-problemas)

---

## 1. REQUISITOS DEL SISTEMA

### 1.1 Hardware Mínimo
```
CPU: 4 cores (8 recomendado)
RAM: 8 GB (16 GB recomendado)
Disco: 50 GB SSD (100 GB para producción)
```

### 1.2 Software Requerido
```
Sistema Operativo: Ubuntu 22.04 LTS / 24.04 LTS
Python: 3.11+
PostgreSQL: 15+
Redis: 7+
Nginx: 1.24+
Node.js: 20 LTS (para frontend)
```

### 1.3 Dependencias Python
```bash
# Archivo requirements.txt incluido
fastapi==0.109.0
uvicorn[standard]==0.27.0
sqlalchemy[asyncio]==2.0.25
asyncpg==0.29.0
redis==5.0.1
pydantic==2.5.3
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
httpx==0.26.0
pandas==2.1.4
numpy==1.26.3
scikit-learn==1.4.0
```

---

## 2. INSTALACIÓN EN SERVIDOR LOCAL

### 2.1 Preparación del Servidor
```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar dependencias base
sudo apt install -y python3.11 python3.11-venv python3-pip \
    postgresql postgresql-contrib redis-server nginx \
    build-essential libpq-dev git curl

# Instalar Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

### 2.2 Configurar PostgreSQL
```bash
# Crear usuario y base de datos
sudo -u postgres psql

CREATE USER datapolis_user WITH PASSWORD 'tu_password_seguro';
CREATE DATABASE datapolis_db OWNER datapolis_user;
GRANT ALL PRIVILEGES ON DATABASE datapolis_db TO datapolis_user;

# Habilitar extensiones requeridas
\c datapolis_db
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gin";
\q
```

### 2.3 Configurar Redis
```bash
# Editar configuración
sudo nano /etc/redis/redis.conf

# Cambiar:
# bind 127.0.0.1
# maxmemory 512mb
# maxmemory-policy allkeys-lru

sudo systemctl restart redis
sudo systemctl enable redis
```

### 2.4 Clonar y Configurar Proyecto
```bash
# Crear directorio
sudo mkdir -p /var/www/datapolis
sudo chown $USER:$USER /var/www/datapolis
cd /var/www/datapolis

# Clonar repositorio (o copiar archivos)
# git clone https://github.com/datapolis/datapolis-v3.git .

# Crear entorno virtual
python3.11 -m venv venv
source venv/bin/activate

# Instalar dependencias
pip install --upgrade pip
pip install -r requirements.txt
```

### 2.5 Configurar Variables de Entorno
```bash
# Crear archivo .env
nano /var/www/datapolis/.env

# Contenido (ver sección 5 para detalles completos)
APP_NAME=DATAPOLIS
APP_ENV=production
APP_VERSION=3.0.0
DEBUG=false
SECRET_KEY=tu_clave_secreta_muy_larga_min_64_caracteres
DATABASE_URL=postgresql+asyncpg://datapolis_user:password@localhost:5432/datapolis_db
REDIS_URL=redis://localhost:6379/0
```

### 2.6 Ejecutar Migraciones
```bash
cd /var/www/datapolis
source venv/bin/activate

# Crear tablas
python -c "from app.database import init_db; import asyncio; asyncio.run(init_db())"

# O usar Alembic si está configurado
# alembic upgrade head
```

### 2.7 Configurar Nginx
```bash
sudo nano /etc/nginx/sites-available/datapolis

# Contenido:
server {
    listen 80;
    server_name api.datapolis.cl;
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
    }
}

# Habilitar sitio
sudo ln -s /etc/nginx/sites-available/datapolis /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 2.8 Configurar SSL con Let's Encrypt
```bash
# Instalar Certbot
sudo apt install certbot python3-certbot-nginx

# Obtener certificado
sudo certbot --nginx -d api.datapolis.cl

# Renovación automática ya configurada
```

### 2.9 Crear Servicio Systemd
```bash
sudo nano /etc/systemd/system/datapolis.service

# Contenido:
[Unit]
Description=DATAPOLIS v3.0 API
After=network.target postgresql.service redis.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/datapolis
Environment="PATH=/var/www/datapolis/venv/bin"
EnvironmentFile=/var/www/datapolis/.env
ExecStart=/var/www/datapolis/venv/bin/uvicorn app.main:app \
    --host 127.0.0.1 \
    --port 8000 \
    --workers 4 \
    --loop uvloop \
    --http httptools
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target

# Habilitar e iniciar
sudo systemctl daemon-reload
sudo systemctl enable datapolis
sudo systemctl start datapolis
```

### 2.10 Verificar Instalación
```bash
# Verificar servicio
sudo systemctl status datapolis

# Verificar endpoints
curl http://localhost:8000/health
curl http://localhost:8000/api/docs
```

---

## 3. DESPLIEGUE EN cPANEL

### 3.1 Requisitos cPanel
```
- cPanel con soporte para Python 3.11+
- Acceso SSH habilitado
- PostgreSQL o MySQL disponible
- Al menos 1 GB RAM
- Certificado SSL instalado
```

### 3.2 Configuración Inicial
```bash
# Acceder por SSH
ssh usuario@tudominio.cl

# Navegar a directorio de aplicación
cd ~/public_html
mkdir datapolis
cd datapolis
```

### 3.3 Subir Archivos
```bash
# Opción 1: Git
git clone https://github.com/datapolis/datapolis-v3.git .

# Opción 2: FTP/SFTP
# Subir archivos a ~/public_html/datapolis/

# Opción 3: cPanel File Manager
# Subir archivo .zip y extraer
```

### 3.4 Configurar Python en cPanel
```bash
# Acceder a cPanel > Setup Python App
# Seleccionar:
#   - Python version: 3.11
#   - Application root: datapolis
#   - Application URL: api.tudominio.cl
#   - Application startup file: app.py (ver paso siguiente)
#   - Application Entry point: app

# Crear archivo de entrada para Passenger
nano ~/public_html/datapolis/passenger_wsgi.py
```

```python
# passenger_wsgi.py
import sys
import os

# Agregar directorio de aplicación al path
sys.path.insert(0, os.path.dirname(__file__))

# Cargar variables de entorno
from dotenv import load_dotenv
load_dotenv()

# Importar aplicación FastAPI
from app.main import app as application

# Para compatibilidad con ASGI
from asgiref.wsgi import WsgiToAsgi
application = WsgiToAsgi(application)
```

### 3.5 Instalar Dependencias en cPanel
```bash
# En terminal SSH
cd ~/public_html/datapolis
source /home/usuario/virtualenv/datapolis/3.11/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
pip install python-dotenv asgiref
```

### 3.6 Configurar Base de Datos en cPanel
```bash
# En cPanel > MySQL/PostgreSQL Databases:
# 1. Crear base de datos: usuario_datapolis
# 2. Crear usuario: usuario_datapolis_user
# 3. Asignar permisos completos

# Actualizar .env con credenciales de cPanel
DATABASE_URL=postgresql+asyncpg://usuario_datapolis_user:password@localhost/usuario_datapolis
```

### 3.7 Configurar Subdominio en cPanel
```bash
# En cPanel > Subdomains:
# 1. Crear subdominio: api.tudominio.cl
# 2. Document Root: /home/usuario/public_html/datapolis/public

# En cPanel > SSL/TLS:
# Instalar certificado SSL para api.tudominio.cl
```

### 3.8 Configurar .htaccess
```apache
# ~/public_html/datapolis/public/.htaccess
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^(.*)$ /datapolis/app.py [QSA,L]

# Headers de seguridad
Header set X-Content-Type-Options "nosniff"
Header set X-Frame-Options "DENY"
Header set X-XSS-Protection "1; mode=block"
Header set Strict-Transport-Security "max-age=31536000; includeSubDomains"
```

### 3.9 Reiniciar Aplicación
```bash
# En cPanel > Setup Python App:
# Click en "Restart" para la aplicación

# O por SSH:
touch ~/public_html/datapolis/tmp/restart.txt
```

### 3.10 Configurar Cron Jobs
```bash
# En cPanel > Cron Jobs:

# Actualizar indicadores económicos (diario 6 AM)
0 6 * * * cd ~/public_html/datapolis && source ~/virtualenv/datapolis/3.11/bin/activate && python -c "from app.services.ie_indicadores import actualizar_indicadores; import asyncio; asyncio.run(actualizar_indicadores())"

# Backup base de datos (diario 3 AM)
0 3 * * * mysqldump -u usuario_datapolis_user -p'password' usuario_datapolis > ~/backups/datapolis_$(date +\%Y\%m\%d).sql

# Limpiar logs antiguos (semanal)
0 4 * * 0 find ~/logs -name "*.log" -mtime +30 -delete
```

---

## 4. CONFIGURACIÓN DE BASE DE DATOS

### 4.1 Esquema Principal
```sql
-- Tablas principales DATAPOLIS v3.0
-- Ver archivos en /migrations para DDL completo

-- Propiedades
CREATE TABLE propiedades (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rol_sii VARCHAR(20) UNIQUE NOT NULL,
    direccion TEXT NOT NULL,
    comuna_id INTEGER REFERENCES comunas(id),
    tipo_propiedad VARCHAR(50),
    superficie_terreno DECIMAL(12,2),
    superficie_construida DECIMAL(12,2),
    avaluo_fiscal DECIMAL(15,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Condominios (Ley 21.442)
CREATE TABLE condominios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre VARCHAR(200) NOT NULL,
    rut_administrador VARCHAR(12),
    tipo_condominio VARCHAR(20) CHECK (tipo_condominio IN ('A', 'B')),
    total_unidades INTEGER,
    fondo_reserva DECIMAL(15,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Open Finance - Consentimientos (NCG 514)
CREATE TABLE consentimientos_openfinance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id UUID REFERENCES usuarios(id),
    tpp_id VARCHAR(50) NOT NULL,
    estado VARCHAR(20) DEFAULT 'pendiente',
    alcances JSONB NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_expiracion TIMESTAMP NOT NULL,
    fecha_revocacion TIMESTAMP,
    CONSTRAINT check_expiracion CHECK (fecha_expiracion <= fecha_creacion + INTERVAL '365 days')
);

-- Índices optimizados
CREATE INDEX idx_propiedades_comuna ON propiedades(comuna_id);
CREATE INDEX idx_propiedades_rol ON propiedades(rol_sii);
CREATE INDEX idx_consentimientos_usuario ON consentimientos_openfinance(usuario_id);
CREATE INDEX idx_consentimientos_estado ON consentimientos_openfinance(estado);
```

### 4.2 Configuración de Conexión
```python
# app/database.py - Configuración de conexión optimizada

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool

DATABASE_URL = os.getenv("DATABASE_URL")

engine = create_async_engine(
    DATABASE_URL,
    poolclass=NullPool,  # Para cPanel
    echo=False,
    future=True
)

async_session = sessionmaker(
    engine, 
    class_=AsyncSession, 
    expire_on_commit=False
)
```

---

## 5. VARIABLES DE ENTORNO

### 5.1 Archivo .env Completo
```bash
# =====================================================
# DATAPOLIS v3.0 - CONFIGURACIÓN DE ENTORNO
# =====================================================

# --- Aplicación ---
APP_NAME=DATAPOLIS
APP_ENV=production  # development | staging | production
APP_VERSION=3.0.0
DEBUG=false
LOG_LEVEL=INFO

# --- Seguridad ---
SECRET_KEY=tu_clave_secreta_muy_larga_minimo_64_caracteres_aleatorios
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24
REFRESH_TOKEN_DAYS=30

# --- Base de Datos ---
DATABASE_URL=postgresql+asyncpg://usuario:password@localhost:5432/datapolis_db
DATABASE_POOL_SIZE=10
DATABASE_MAX_OVERFLOW=20

# --- Redis ---
REDIS_URL=redis://localhost:6379/0
REDIS_PASSWORD=

# --- API ---
API_HOST=0.0.0.0
API_PORT=8000
CORS_ORIGINS=["https://app.datapolis.cl","https://api.datapolis.cl"]
RATE_LIMIT_PER_MINUTE=100

# --- Servicios Externos ---
# BCCh (Indicadores económicos)
BCCH_API_URL=https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx
BCCH_USER=usuario_bcch
BCCH_PASSWORD=password_bcch

# SII (Avalúos fiscales)
SII_API_URL=https://zeus.sii.cl
SII_RUT_EMPRESA=77.xxx.xxx-x
SII_CERT_PATH=/etc/ssl/datapolis/sii_cert.p12
SII_CERT_PASSWORD=cert_password

# --- Open Finance NCG 514 ---
OPENFINANCE_ENABLED=true
OPENFINANCE_ENVIRONMENT=sandbox  # sandbox | production
CMF_DIRECTORY_URL=https://api.cmfchile.cl/openfinance/v1/directory
QWAC_CERT_PATH=/etc/ssl/datapolis/qwac.pem
QSEAL_CERT_PATH=/etc/ssl/datapolis/qseal.pem
MTLS_KEY_PATH=/etc/ssl/datapolis/mtls.key

# --- Integraciones GIS ---
ESRI_CLIENT_ID=
ESRI_CLIENT_SECRET=
ARCGIS_PORTAL_URL=https://www.arcgis.com

# --- Email ---
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=notificaciones@datapolis.cl
SMTP_PASSWORD=app_password
SMTP_FROM=DATAPOLIS <notificaciones@datapolis.cl>

# --- Almacenamiento ---
STORAGE_TYPE=s3  # local | s3
S3_BUCKET=datapolis-files
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=

# --- Monitoreo ---
SENTRY_DSN=https://xxx@sentry.io/xxx
PROMETHEUS_ENABLED=true
```

### 5.2 Generar SECRET_KEY Seguro
```python
import secrets
print(secrets.token_urlsafe(64))
```

---

## 6. CONFIGURACIÓN DE CERTIFICADOS

### 6.1 Certificados NCG 514 (QWAC/QSEAL)
```bash
# Los certificados QWAC y QSEAL deben ser emitidos por
# una CA acreditada (ej: CertCentral, GlobalSign, Entrust)

# Estructura de directorios
sudo mkdir -p /etc/ssl/datapolis
sudo chmod 700 /etc/ssl/datapolis

# Copiar certificados
sudo cp qwac.pem /etc/ssl/datapolis/
sudo cp qseal.pem /etc/ssl/datapolis/
sudo cp mtls.key /etc/ssl/datapolis/

# Permisos
sudo chown root:www-data /etc/ssl/datapolis/*
sudo chmod 640 /etc/ssl/datapolis/*
```

### 6.2 Configurar mTLS en Nginx
```nginx
# /etc/nginx/sites-available/datapolis-openfinance

server {
    listen 443 ssl;
    server_name openfinance.datapolis.cl;

    # Certificado del servidor
    ssl_certificate /etc/ssl/datapolis/server.crt;
    ssl_certificate_key /etc/ssl/datapolis/server.key;

    # mTLS - Verificación de cliente
    ssl_client_certificate /etc/ssl/datapolis/ca-bundle.crt;
    ssl_verify_client on;
    ssl_verify_depth 2;

    # Pasar información del certificado al backend
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header X-SSL-Client-Cert $ssl_client_cert;
        proxy_set_header X-SSL-Client-Verify $ssl_client_verify;
        proxy_set_header X-SSL-Client-DN $ssl_client_s_dn;
    }
}
```

---

## 7. INTEGRACIÓN NCG 514

### 7.1 Registro en Directorio CMF
```bash
# 1. Solicitar registro como TPP en CMF
# https://www.cmfchile.cl/openfinance

# 2. Obtener certificados QWAC y QSEAL

# 3. Configurar endpoints en directorio
# POST /api/v1/open-finance/directorio/registro
```

### 7.2 Configurar Endpoints AIS/PIS
```python
# Endpoints requeridos NCG 514

# AIS (Account Information Services)
GET  /api/v1/open-finance/cuentas
GET  /api/v1/open-finance/cuentas/{id}/saldos
GET  /api/v1/open-finance/cuentas/{id}/transacciones

# PIS (Payment Initiation Services)
POST /api/v1/open-finance/pagos
GET  /api/v1/open-finance/pagos/{id}
POST /api/v1/open-finance/pagos/{id}/confirmar

# Consentimientos
POST   /api/v1/open-finance/consentimientos
GET    /api/v1/open-finance/consentimientos/{id}
DELETE /api/v1/open-finance/consentimientos/{id}
```

### 7.3 Implementar Strong Customer Authentication (SCA)
```python
# Métodos SCA soportados
SCA_METHODS = [
    "clave_unica",      # Clave Única Chile
    "biometric",        # Huella/Face ID
    "otp_sms",          # SMS one-time password
    "otp_app",          # App authenticator
    "fido2"             # WebAuthn/FIDO2
]
```

---

## 8. MONITOREO Y MANTENIMIENTO

### 8.1 Logs
```bash
# Ubicación de logs
/var/log/datapolis/app.log        # Aplicación
/var/log/datapolis/access.log     # Accesos
/var/log/datapolis/error.log      # Errores
/var/log/nginx/datapolis.log      # Nginx

# Ver logs en tiempo real
tail -f /var/log/datapolis/app.log

# Rotación de logs (logrotate)
sudo nano /etc/logrotate.d/datapolis
```

### 8.2 Métricas Prometheus
```bash
# Endpoint de métricas
curl http://localhost:8000/metrics

# Métricas disponibles:
# - datapolis_requests_total
# - datapolis_request_latency_seconds
# - datapolis_active_connections
# - datapolis_database_queries_total
```

### 8.3 Health Checks
```bash
# Health check básico
curl http://localhost:8000/health

# Health check detallado
curl http://localhost:8000/health?detailed=true

# Monitoreo con uptimerobot o similar
# URL: https://api.datapolis.cl/health
# Intervalo: 5 minutos
```

### 8.4 Backups Automáticos
```bash
# Script de backup
#!/bin/bash
# /opt/scripts/backup_datapolis.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR=/var/backups/datapolis

# Backup base de datos
pg_dump -U datapolis_user datapolis_db | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# Backup archivos
tar -czf $BACKUP_DIR/files_$DATE.tar.gz /var/www/datapolis/uploads

# Retener últimos 30 días
find $BACKUP_DIR -mtime +30 -delete

# Cron: 0 2 * * * /opt/scripts/backup_datapolis.sh
```

---

## 9. SOLUCIÓN DE PROBLEMAS

### 9.1 Error: Conexión a Base de Datos
```bash
# Verificar PostgreSQL
sudo systemctl status postgresql
sudo -u postgres psql -c "SELECT 1"

# Verificar conexión desde app
python -c "from app.database import engine; print(engine.url)"
```

### 9.2 Error: Redis No Disponible
```bash
# Verificar Redis
sudo systemctl status redis
redis-cli ping

# Reiniciar Redis
sudo systemctl restart redis
```

### 9.3 Error: 502 Bad Gateway
```bash
# Verificar que uvicorn esté corriendo
sudo systemctl status datapolis

# Verificar logs de Nginx
sudo tail -f /var/log/nginx/error.log

# Verificar que el puerto esté escuchando
sudo netstat -tlnp | grep 8000
```

### 9.4 Error: Certificados SSL
```bash
# Verificar certificado
openssl x509 -in /etc/ssl/datapolis/qwac.pem -text -noout

# Verificar cadena de confianza
openssl verify -CAfile ca-bundle.crt qwac.pem
```

### 9.5 Error: Memoria Insuficiente
```bash
# Ver uso de memoria
free -h
htop

# Reducir workers de uvicorn
# En /etc/systemd/system/datapolis.service
# --workers 2 (en lugar de 4)

# Aumentar swap si es necesario
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

---

## 📞 SOPORTE

**DATAPOLIS SpA**
- Web: https://datapolis.cl
- Email: soporte@datapolis.cl
- Documentación: https://docs.datapolis.cl

**Horario de Soporte**
- Lunes a Viernes: 9:00 - 18:00 (Chile)
- Emergencias 24/7 para clientes enterprise

---

**Versión del Manual**: 3.0.0  
**Última Actualización**: Febrero 2026  
**Próxima Revisión**: Mayo 2026 (post-implementación NCG 514)
