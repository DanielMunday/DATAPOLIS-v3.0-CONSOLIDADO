<?php

namespace App\Console\Commands\PAE;

use App\Models\PropTech\Copropiedad;
use App\Models\PAE\PrecessionAnalysis;
use App\Models\PAE\PrecessionAlert;
use App\Services\PrecessionService;
use App\Services\PAE\PrecessionContextBuilder;
use App\Jobs\PAE\TriggerPrecessionAnalysis;
use App\Jobs\PAE\BatchRecalculatePrecession;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/**
 * =========================================================
 * COMANDOS ARTISAN PAE M11
 * =========================================================
 */

// =========================================================
// COMANDO: Analizar Copropiedad
// =========================================================

/**
 * AnalyzeCopropiedadCommand
 * 
 * Ejecuta análisis precesional para una o más copropiedades.
 * 
 * Uso:
 *   php artisan pae:analyze {copropiedad_id}
 *   php artisan pae:analyze --all --tenant=1
 *   php artisan pae:analyze --comuna="Santiago"
 */
class AnalyzeCopropiedadCommand extends Command
{
    protected $signature = 'pae:analyze 
                            {copropiedad_id? : ID de la copropiedad a analizar}
                            {--all : Analizar todas las copropiedades}
                            {--tenant= : Filtrar por tenant ID}
                            {--comuna= : Filtrar por comuna}
                            {--force : Forzar re-análisis ignorando cache}
                            {--horizon=36 : Horizonte temporal en meses}
                            {--sync : Ejecutar sincrónicamente (no usar queue)}';

    protected $description = 'Ejecuta análisis precesional PAE para copropiedades';

    public function handle(PrecessionService $service): int
    {
        $this->info('🔮 PAE - Precession Analytics Engine');
        $this->line('');

        if ($copropiedadId = $this->argument('copropiedad_id')) {
            return $this->analyzeSingle($service, (int) $copropiedadId);
        }

        if ($this->option('all')) {
            return $this->analyzeMultiple();
        }

        $this->error('Especifique un ID de copropiedad o use --all');
        return Command::FAILURE;
    }

    protected function analyzeSingle(PrecessionService $service, int $copropiedadId): int
    {
        $copropiedad = Copropiedad::find($copropiedadId);
        
        if (!$copropiedad) {
            $this->error("Copropiedad {$copropiedadId} no encontrada");
            return Command::FAILURE;
        }

        $this->info("Analizando: {$copropiedad->nombre}");
        $this->line("Comuna: {$copropiedad->comuna}");
        $this->line("Ubicación: {$copropiedad->latitud}, {$copropiedad->longitud}");
        $this->line('');

        $this->output->write('Ejecutando análisis precesional... ');

        try {
            $startTime = microtime(true);
            
            $result = $service->analyzeCopropiedad($copropiedadId, [
                'horizon' => (int) $this->option('horizon'),
                'force_refresh' => $this->option('force'),
                'include_ml' => true,
            ]);

            $executionTime = round(microtime(true) - $startTime, 2);

            $this->info('✅ Completado');
            $this->line('');
            
            $this->table(
                ['Métrica', 'Valor'],
                [
                    ['Precession Score', number_format($result['precession_score'] ?? 0, 1)],
                    ['Risk Score', number_format(($result['risk_score'] ?? 0) * 100, 1) . '%'],
                    ['Opportunity Score', number_format(($result['opportunity_score'] ?? 0) * 100, 1) . '%'],
                    ['Confidence', number_format(($result['confidence'] ?? 0) * 100, 1) . '%'],
                    ['Total Value (UF)', number_format($result['total_precession_value_uf'] ?? 0, 0)],
                    ['Tiempo ejecución', "{$executionTime}s"],
                ]
            );

            if (!empty($result['ml_predictions'])) {
                $this->line('');
                $this->info('📊 Predicciones ML:');
                foreach ($result['ml_predictions'] as $horizon => $prediction) {
                    $sign = $prediction >= 0 ? '+' : '';
                    $this->line("  {$horizon}: {$sign}" . number_format($prediction * 100, 1) . '%');
                }
            }

            return Command::SUCCESS;

        } catch (\Exception $e) {
            $this->error('❌ Error: ' . $e->getMessage());
            return Command::FAILURE;
        }
    }

    protected function analyzeMultiple(): int
    {
        $query = Copropiedad::query()->where('activa', true);

        if ($tenantId = $this->option('tenant')) {
            $query->where('tenant_id', $tenantId);
        }

        if ($comuna = $this->option('comuna')) {
            $query->where('comuna', $comuna);
        }

        $copropiedades = $query->get();

        if ($copropiedades->isEmpty()) {
            $this->warn('No se encontraron copropiedades con los filtros especificados');
            return Command::SUCCESS;
        }

        $this->info("Encontradas {$copropiedades->count()} copropiedades");

        if (!$this->confirm('¿Desea continuar con el análisis?')) {
            return Command::SUCCESS;
        }

        $bar = $this->output->createProgressBar($copropiedades->count());
        $bar->start();

        $dispatched = 0;
        foreach ($copropiedades as $copropiedad) {
            if ($this->option('sync')) {
                // Ejecutar sincrónicamente
                try {
                    app(PrecessionService::class)->analyzeCopropiedad($copropiedad->id, [
                        'force_refresh' => $this->option('force'),
                    ]);
                } catch (\Exception $e) {
                    $this->newLine();
                    $this->warn("Error en {$copropiedad->nombre}: {$e->getMessage()}");
                }
            } else {
                // Despachar a cola
                TriggerPrecessionAnalysis::dispatch($copropiedad->id, [
                    'reason' => 'artisan_command',
                    'force_refresh' => $this->option('force'),
                ])->delay(now()->addSeconds($dispatched * 10));
            }
            
            $dispatched++;
            $bar->advance();
        }

        $bar->finish();
        $this->newLine(2);

        if ($this->option('sync')) {
            $this->info("✅ {$dispatched} análisis completados");
        } else {
            $this->info("✅ {$dispatched} análisis despachados a la cola");
        }

        return Command::SUCCESS;
    }
}

// =========================================================
// COMANDO: Estadísticas PAE
// =========================================================

/**
 * PAEStatsCommand
 * 
 * Muestra estadísticas del sistema PAE.
 */
class PAEStatsCommand extends Command
{
    protected $signature = 'pae:stats 
                            {--days=7 : Número de días a mostrar}
                            {--tenant= : Filtrar por tenant}';

    protected $description = 'Muestra estadísticas del Precession Analytics Engine';

    public function handle(): int
    {
        $this->info('📊 PAE - Estadísticas del Sistema');
        $this->line('');

        $days = (int) $this->option('days');

        // Estadísticas generales
        $this->showGeneralStats($days);
        
        // Estadísticas por día
        $this->showDailyStats($days);

        // Top copropiedades por riesgo
        $this->showTopRisks();

        // Top oportunidades
        $this->showTopOpportunities();

        // Alertas activas
        $this->showActiveAlerts();

        return Command::SUCCESS;
    }

    protected function showGeneralStats(int $days): void
    {
        $since = now()->subDays($days);

        $analyses = PrecessionAnalysis::where('created_at', '>=', $since)->count();
        $completed = PrecessionAnalysis::where('created_at', '>=', $since)
            ->where('status', 'completed')->count();
        $failed = PrecessionAnalysis::where('created_at', '>=', $since)
            ->where('status', 'failed')->count();
        
        $alerts = PrecessionAlert::where('created_at', '>=', $since)->count();
        $criticalAlerts = PrecessionAlert::where('created_at', '>=', $since)
            ->where('severity', 'critical')->count();
        $resolvedAlerts = PrecessionAlert::where('created_at', '>=', $since)
            ->where('status', 'resolved')->count();

        $avgScore = PrecessionAnalysis::where('created_at', '>=', $since)
            ->where('status', 'completed')
            ->avg('precession_score');

        $this->info("📈 Últimos {$days} días:");
        $this->table(
            ['Métrica', 'Valor'],
            [
                ['Análisis ejecutados', $analyses],
                ['Análisis completados', $completed],
                ['Análisis fallidos', $failed],
                ['Tasa de éxito', $analyses > 0 ? round($completed / $analyses * 100, 1) . '%' : 'N/A'],
                ['Alertas generadas', $alerts],
                ['Alertas críticas', $criticalAlerts],
                ['Alertas resueltas', $resolvedAlerts],
                ['Score promedio', $avgScore ? round($avgScore, 1) : 'N/A'],
            ]
        );
        $this->line('');
    }

    protected function showDailyStats(int $days): void
    {
        $stats = DB::table('pae_statistics')
            ->where('date', '>=', now()->subDays($days)->toDateString())
            ->orderByDesc('date')
            ->get();

        if ($stats->isEmpty()) {
            $this->warn('No hay estadísticas diarias disponibles');
            return;
        }

        $this->info('📅 Estadísticas diarias:');
        $this->table(
            ['Fecha', 'Análisis', 'Alertas', 'Críticas', 'Avg Score', 'Avg Risk'],
            $stats->map(fn($s) => [
                $s->date,
                $s->analyses_completed ?? 0,
                $s->alerts_triggered ?? 0,
                $s->critical_alerts ?? 0,
                $s->avg_precession_score ? round($s->avg_precession_score, 1) : '-',
                $s->avg_risk_score ? round($s->avg_risk_score * 100, 1) . '%' : '-',
            ])->toArray()
        );
        $this->line('');
    }

    protected function showTopRisks(): void
    {
        $risks = DB::table('copropiedad_metrics')
            ->join('copropiedades', 'copropiedades.id', '=', 'copropiedad_metrics.copropiedad_id')
            ->whereNotNull('pae_risk_score')
            ->orderByDesc('pae_risk_score')
            ->limit(5)
            ->select(
                'copropiedades.nombre',
                'copropiedades.comuna',
                'copropiedad_metrics.pae_risk_score',
                'copropiedad_metrics.pae_precession_score'
            )
            ->get();

        if ($risks->isEmpty()) {
            return;
        }

        $this->info('🔴 Top 5 Copropiedades por Riesgo:');
        $this->table(
            ['Copropiedad', 'Comuna', 'Risk Score', 'Precession Score'],
            $risks->map(fn($r) => [
                $r->nombre,
                $r->comuna,
                round($r->pae_risk_score * 100, 1) . '%',
                round($r->pae_precession_score, 1),
            ])->toArray()
        );
        $this->line('');
    }

    protected function showTopOpportunities(): void
    {
        $opportunities = DB::table('precession_valuations')
            ->join('copropiedades', 'copropiedades.id', '=', 'precession_valuations.copropiedad_id')
            ->where('appreciation_60m_pct', '>', 0)
            ->orderByDesc('appreciation_60m_pct')
            ->limit(5)
            ->select(
                'copropiedades.nombre',
                'copropiedades.comuna',
                'precession_valuations.appreciation_60m_pct',
                'precession_valuations.confidence'
            )
            ->get();

        if ($opportunities->isEmpty()) {
            return;
        }

        $this->info('🟢 Top 5 Oportunidades de Inversión:');
        $this->table(
            ['Copropiedad', 'Comuna', 'Apreciación 60m', 'Confianza'],
            $opportunities->map(fn($o) => [
                $o->nombre,
                $o->comuna,
                '+' . round($o->appreciation_60m_pct, 1) . '%',
                round($o->confidence * 100, 0) . '%',
            ])->toArray()
        );
        $this->line('');
    }

    protected function showActiveAlerts(): void
    {
        $alerts = PrecessionAlert::where('status', 'active')
            ->with('copropiedad:id,nombre')
            ->orderByDesc('severity')
            ->limit(10)
            ->get();

        if ($alerts->isEmpty()) {
            $this->info('✅ No hay alertas activas');
            return;
        }

        $this->info('⚠️ Alertas Activas:');
        $this->table(
            ['Severidad', 'Tipo', 'Copropiedad', 'Título'],
            $alerts->map(fn($a) => [
                strtoupper($a->severity),
                $a->alert_type,
                $a->copropiedad?->nombre ?? 'N/A',
                \Str::limit($a->title, 40),
            ])->toArray()
        );
    }
}

// =========================================================
// COMANDO: Gestionar Alertas
// =========================================================

/**
 * ManageAlertsCommand
 * 
 * Gestiona alertas del sistema PAE.
 */
class ManageAlertsCommand extends Command
{
    protected $signature = 'pae:alerts 
                            {action=list : Acción (list, resolve, acknowledge, cleanup)}
                            {--id= : ID de la alerta}
                            {--severity= : Filtrar por severidad}
                            {--type= : Filtrar por tipo}
                            {--status=active : Filtrar por estado}';

    protected $description = 'Gestiona alertas del Precession Analytics Engine';

    public function handle(): int
    {
        $action = $this->argument('action');

        return match($action) {
            'list' => $this->listAlerts(),
            'resolve' => $this->resolveAlert(),
            'acknowledge' => $this->acknowledgeAlert(),
            'cleanup' => $this->cleanupAlerts(),
            default => $this->error("Acción desconocida: {$action}") ?? Command::FAILURE,
        };
    }

    protected function listAlerts(): int
    {
        $query = PrecessionAlert::query()
            ->with('copropiedad:id,nombre');

        if ($severity = $this->option('severity')) {
            $query->where('severity', $severity);
        }

        if ($type = $this->option('type')) {
            $query->where('alert_type', $type);
        }

        if ($status = $this->option('status')) {
            $query->where('status', $status);
        }

        $alerts = $query->orderByDesc('created_at')->limit(20)->get();

        if ($alerts->isEmpty()) {
            $this->info('No hay alertas que coincidan con los filtros');
            return Command::SUCCESS;
        }

        $this->table(
            ['ID', 'Severidad', 'Tipo', 'Copropiedad', 'Estado', 'Creada'],
            $alerts->map(fn($a) => [
                $a->id,
                strtoupper($a->severity),
                $a->alert_type,
                $a->copropiedad?->nombre ?? 'N/A',
                $a->status,
                $a->created_at->diffForHumans(),
            ])->toArray()
        );

        return Command::SUCCESS;
    }

    protected function resolveAlert(): int
    {
        $id = $this->option('id');
        
        if (!$id) {
            $this->error('Especifique el ID de la alerta con --id=');
            return Command::FAILURE;
        }

        $alert = PrecessionAlert::find($id);
        
        if (!$alert) {
            $this->error("Alerta {$id} no encontrada");
            return Command::FAILURE;
        }

        $alert->update([
            'status' => 'resolved',
            'resolved_at' => now(),
            'resolution_notes' => 'Resuelta via CLI',
        ]);

        $this->info("✅ Alerta {$id} resuelta");
        return Command::SUCCESS;
    }

    protected function acknowledgeAlert(): int
    {
        $id = $this->option('id');
        
        if (!$id) {
            $this->error('Especifique el ID de la alerta con --id=');
            return Command::FAILURE;
        }

        $alert = PrecessionAlert::find($id);
        
        if (!$alert) {
            $this->error("Alerta {$id} no encontrada");
            return Command::FAILURE;
        }

        $alert->update([
            'status' => 'acknowledged',
            'acknowledged_at' => now(),
        ]);

        $this->info("✅ Alerta {$id} reconocida");
        return Command::SUCCESS;
    }

    protected function cleanupAlerts(): int
    {
        $deleted = PrecessionAlert::where('status', 'resolved')
            ->where('resolved_at', '<', now()->subDays(90))
            ->delete();

        $this->info("✅ {$deleted} alertas antiguas eliminadas");
        return Command::SUCCESS;
    }
}

// =========================================================
// COMANDO: Reconstruir Ontología
// =========================================================

/**
 * RebuildOntologyCommand
 * 
 * Reconstruye la ontología territorial del PAE.
 */
class RebuildOntologyCommand extends Command
{
    protected $signature = 'pae:rebuild-ontology 
                            {--fresh : Eliminar ontología existente antes de reconstruir}';

    protected $description = 'Reconstruye la ontología territorial del PAE';

    public function handle(): int
    {
        $this->info('🔧 PAE - Reconstruyendo Ontología Territorial');
        $this->line('');

        if ($this->option('fresh')) {
            if ($this->confirm('¿Está seguro de eliminar la ontología existente?')) {
                DB::table('precession_graph_edges')->where('is_system', true)->delete();
                DB::table('precession_graph_nodes')->where('is_system', true)->delete();
                $this->info('Ontología existente eliminada');
            }
        }

        $this->output->write('Ejecutando seeder de ontología... ');
        
        try {
            \Artisan::call('db:seed', [
                '--class' => 'PrecessionOntologySeeder',
                '--force' => true,
            ]);
            
            $this->info('✅ Completado');

            $nodes = DB::table('precession_graph_nodes')->count();
            $edges = DB::table('precession_graph_edges')->count();

            $this->line('');
            $this->info("📊 Ontología cargada:");
            $this->line("  - Nodos: {$nodes}");
            $this->line("  - Relaciones: {$edges}");

            return Command::SUCCESS;

        } catch (\Exception $e) {
            $this->error('❌ Error: ' . $e->getMessage());
            return Command::FAILURE;
        }
    }
}

// =========================================================
// COMANDO: Exportar Análisis
// =========================================================

/**
 * ExportAnalysisCommand
 * 
 * Exporta análisis precesionales a CSV/JSON.
 */
class ExportAnalysisCommand extends Command
{
    protected $signature = 'pae:export 
                            {--format=csv : Formato de exportación (csv, json)}
                            {--output= : Archivo de salida}
                            {--days=30 : Días de antigüedad máxima}
                            {--tenant= : Filtrar por tenant}';

    protected $description = 'Exporta análisis precesionales a archivo';

    public function handle(): int
    {
        $format = $this->option('format');
        $days = (int) $this->option('days');
        
        $query = PrecessionAnalysis::with('copropiedad:id,nombre,comuna')
            ->where('status', 'completed')
            ->where('created_at', '>=', now()->subDays($days));

        if ($tenantId = $this->option('tenant')) {
            $query->where('tenant_id', $tenantId);
        }

        $analyses = $query->get();

        if ($analyses->isEmpty()) {
            $this->warn('No hay análisis para exportar');
            return Command::SUCCESS;
        }

        $output = $this->option('output') ?? storage_path("exports/pae_export_" . now()->format('Y-m-d_His') . ".{$format}");

        // Asegurar directorio
        $dir = dirname($output);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        if ($format === 'json') {
            file_put_contents($output, $analyses->toJson(JSON_PRETTY_PRINT));
        } else {
            $this->exportToCsv($analyses, $output);
        }

        $this->info("✅ Exportados {$analyses->count()} análisis a: {$output}");
        return Command::SUCCESS;
    }

    protected function exportToCsv($analyses, string $output): void
    {
        $handle = fopen($output, 'w');
        
        // Header
        fputcsv($handle, [
            'ID', 'Copropiedad', 'Comuna', 'Fecha',
            'Precession Score', 'Risk Score', 'Opportunity Score',
            'Confidence', 'Total Value UF', 'Status'
        ]);

        // Data
        foreach ($analyses as $a) {
            fputcsv($handle, [
                $a->id,
                $a->copropiedad?->nombre ?? 'N/A',
                $a->copropiedad?->comuna ?? 'N/A',
                $a->created_at->format('Y-m-d H:i'),
                $a->precession_score,
                $a->risk_score,
                $a->opportunity_score,
                $a->confidence,
                $a->total_precession_value_uf,
                $a->status,
            ]);
        }

        fclose($handle);
    }
}
