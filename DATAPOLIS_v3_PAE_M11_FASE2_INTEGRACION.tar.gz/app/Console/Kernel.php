<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

/**
 * Console Kernel
 * 
 * Define los comandos Artisan y el schedule de tareas programadas.
 * Incluye jobs del PAE M11 para análisis precesional automatizado.
 */
class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        // =========================================================
        // PAE M11 - ANÁLISIS PRECESIONAL PROGRAMADO
        // =========================================================

        /**
         * Análisis precesional diario
         * 
         * Ejecuta análisis para copropiedades activas que no han sido
         * analizadas en las últimas 24 horas.
         * 
         * Horario: 02:00 AM (baja carga del sistema)
         */
        $schedule->job(new \App\Jobs\PAE\ScheduledPrecessionAnalysis(
            tenantId: null,
            filters: ['batch_size' => 50]
        ))
            ->dailyAt('02:00')
            ->name('pae:daily-analysis')
            ->withoutOverlapping()
            ->onOneServer()
            ->runInBackground()
            ->appendOutputTo(storage_path('logs/pae-scheduled.log'));

        /**
         * Limpieza de análisis expirados
         * 
         * Elimina análisis con más de 30 días y alertas resueltas
         * con más de 90 días.
         * 
         * Horario: Domingos 04:00 AM
         */
        $schedule->job(new \App\Jobs\PAE\CleanupExpiredAnalyses())
            ->weeklyOn(0, '04:00')
            ->name('pae:cleanup')
            ->withoutOverlapping()
            ->onOneServer();

        /**
         * Resumen diario PAE
         * 
         * Envía notificación con resumen de actividad PAE a administradores.
         * 
         * Horario: 08:00 AM
         */
        $schedule->call(function () {
            $this->sendDailyPAESummary();
        })
            ->dailyAt('08:00')
            ->name('pae:daily-summary')
            ->onOneServer();

        /**
         * Verificación de alertas expirando
         * 
         * Notifica sobre alertas que expirarán en las próximas 24 horas.
         * 
         * Horario: Cada 6 horas
         */
        $schedule->call(function () {
            $this->checkExpiringAlerts();
        })
            ->everySixHours()
            ->name('pae:check-expiring-alerts')
            ->onOneServer();

        /**
         * Actualización de métricas consolidadas
         * 
         * Recalcula métricas agregadas en copropiedad_metrics.
         * 
         * Horario: Cada hora
         */
        $schedule->call(function () {
            $this->updateConsolidatedMetrics();
        })
            ->hourly()
            ->name('pae:update-metrics')
            ->withoutOverlapping()
            ->onOneServer();

        // =========================================================
        // OTROS JOBS DEL SISTEMA
        // =========================================================

        // Limpiar cache expirado
        $schedule->command('cache:prune-stale-tags')
            ->hourly()
            ->onOneServer();

        // Limpiar logs antiguos
        $schedule->command('log:clear')
            ->weekly()
            ->onOneServer();

        // Backup de base de datos (si está configurado)
        if (config('backup.enabled', false)) {
            $schedule->command('backup:run --only-db')
                ->dailyAt('03:00')
                ->onOneServer();
        }
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }

    /**
     * Envía resumen diario de actividad PAE
     */
    protected function sendDailyPAESummary(): void
    {
        $yesterday = now()->subDay();

        // Obtener estadísticas
        $stats = \DB::table('pae_statistics')
            ->whereDate('date', $yesterday->toDateString())
            ->first();

        // Obtener top riesgos
        $topRisks = \DB::table('copropiedad_metrics')
            ->join('copropiedades', 'copropiedades.id', '=', 'copropiedad_metrics.copropiedad_id')
            ->orderByDesc('pae_risk_score')
            ->limit(3)
            ->select('copropiedades.nombre', 'copropiedad_metrics.pae_risk_score as risk_score')
            ->get()
            ->toArray();

        // Obtener top oportunidades
        $topOpportunities = \DB::table('precession_valuations')
            ->join('copropiedades', 'copropiedades.id', '=', 'precession_valuations.copropiedad_id')
            ->where('appreciation_60m_pct', '>', 10)
            ->orderByDesc('appreciation_60m_pct')
            ->limit(3)
            ->select('copropiedades.nombre', 'precession_valuations.appreciation_60m_pct as appreciation')
            ->get()
            ->toArray();

        $summary = [
            'date' => $yesterday->toDateString(),
            'analyses_completed' => $stats->analyses_completed ?? 0,
            'alerts_triggered' => $stats->alerts_triggered ?? 0,
            'critical_alerts' => $stats->critical_alerts ?? 0,
            'alerts_resolved' => $stats->alerts_resolved ?? 0,
            'top_risks' => $topRisks,
            'top_opportunities' => $topOpportunities,
        ];

        // Enviar a administradores
        $admins = \App\Models\Core\User::whereIn('role', ['admin', 'superadmin'])
            ->where('receive_pae_summary', true)
            ->get();

        if ($admins->isNotEmpty()) {
            \Illuminate\Support\Facades\Notification::send(
                $admins,
                new \App\Notifications\PAE\DailyPAESummaryNotification($summary)
            );
        }

        \Log::info('PAE: Resumen diario enviado', ['recipients' => $admins->count()]);
    }

    /**
     * Verifica alertas próximas a expirar
     */
    protected function checkExpiringAlerts(): void
    {
        $expiringAlerts = \App\Models\PAE\PrecessionAlert::where('status', 'active')
            ->where('expires_at', '<=', now()->addHours(24))
            ->where('expires_at', '>', now())
            ->with('copropiedad')
            ->get();

        foreach ($expiringAlerts as $alert) {
            // Notificar sobre alerta que expira pronto
            $admins = \App\Models\Core\User::where('tenant_id', $alert->tenant_id)
                ->whereIn('role', ['admin', 'superadmin'])
                ->get();

            if ($admins->isNotEmpty()) {
                \Illuminate\Support\Facades\Notification::send(
                    $admins,
                    new \App\Notifications\PAE\HighPriorityAlertNotification($alert)
                );
            }
        }

        \Log::info('PAE: Verificadas alertas expirando', ['count' => $expiringAlerts->count()]);
    }

    /**
     * Actualiza métricas consolidadas
     */
    protected function updateConsolidatedMetrics(): void
    {
        // Obtener copropiedades con análisis recientes
        $recentAnalyses = \App\Models\PAE\PrecessionAnalysis::where('status', 'completed')
            ->where('created_at', '>=', now()->subHour())
            ->get();

        foreach ($recentAnalyses as $analysis) {
            \DB::table('copropiedad_metrics')
                ->updateOrInsert(
                    ['copropiedad_id' => $analysis->copropiedad_id],
                    [
                        'pae_precession_score' => $analysis->precession_score,
                        'pae_risk_score' => $analysis->risk_score,
                        'pae_opportunity_score' => $analysis->opportunity_score,
                        'pae_last_analysis' => $analysis->created_at,
                        'updated_at' => now(),
                    ]
                );
        }

        // Actualizar estadísticas diarias
        \DB::table('pae_statistics')
            ->updateOrInsert(
                ['date' => now()->toDateString()],
                [
                    'avg_precession_score' => \App\Models\PAE\PrecessionAnalysis::whereDate('created_at', now())
                        ->where('status', 'completed')
                        ->avg('precession_score'),
                    'avg_risk_score' => \App\Models\PAE\PrecessionAnalysis::whereDate('created_at', now())
                        ->where('status', 'completed')
                        ->avg('risk_score'),
                    'avg_opportunity_score' => \App\Models\PAE\PrecessionAnalysis::whereDate('created_at', now())
                        ->where('status', 'completed')
                        ->avg('opportunity_score'),
                    'updated_at' => now(),
                ]
            );

        \Log::debug('PAE: Métricas consolidadas actualizadas', ['analyses' => $recentAnalyses->count()]);
    }
}
