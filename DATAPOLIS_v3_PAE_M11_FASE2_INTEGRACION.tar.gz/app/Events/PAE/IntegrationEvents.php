<?php

namespace App\Events\PAE;

use App\Models\PropTech\Copropiedad;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * =========================================================
 * EVENTOS DE INTEGRACIÓN PAE M11 CON MÓDULOS DATAPOLIS
 * =========================================================
 * 
 * Eventos que comunican cambios precesionales a otros módulos
 * y permiten reaccionar a actualizaciones de datos externos.
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx Sección 4.2
 */

// =========================================================
// M04 TRIBUTARIO - Evento de riesgo tributario actualizado
// =========================================================

/**
 * PrecessionTaxRiskUpdated
 * 
 * Se dispara cuando el PAE detecta cambios en el riesgo tributario
 * de una copropiedad basado en análisis precesional de DJ, PPM, F29.
 */
class PrecessionTaxRiskUpdated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public Copropiedad $copropiedad,
        public array $taxContext,
        public float $riskScore,
        public array $projectedLoad,
        public array $recommendations
    ) {}

    public function broadcastOn(): array
    {
        return [
            new PrivateChannel("tenant.{$this->copropiedad->tenant_id}"),
            new PrivateChannel("copropiedad.{$this->copropiedad->id}"),
        ];
    }

    public function broadcastAs(): string
    {
        return 'precession.tax_risk_updated';
    }

    public function broadcastWith(): array
    {
        return [
            'copropiedad_id' => $this->copropiedad->id,
            'risk_score' => $this->riskScore,
            'projected_load_12m' => $this->projectedLoad['12m'] ?? 0,
            'projected_load_36m' => $this->projectedLoad['36m'] ?? 0,
            'compliance_rate' => $this->taxContext['metrics']['cumplimiento_global'] ?? 100,
            'recommendations_count' => count($this->recommendations),
            'timestamp' => now()->toIso8601String(),
        ];
    }
}

// =========================================================
// M05 GASTOS COMUNES - Evento de pronóstico de gastos
// =========================================================

/**
 * PrecessionExpenseForecast
 * 
 * Se dispara cuando el PAE genera nuevas proyecciones de gastos
 * comunes basadas en análisis de tendencia y estacionalidad.
 */
class PrecessionExpenseForecast implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public Copropiedad $copropiedad,
        public array $expenseContext,
        public array $forecast12m,
        public array $forecast36m,
        public array $seasonalityIndices
    ) {}

    public function broadcastOn(): array
    {
        return [
            new PrivateChannel("tenant.{$this->copropiedad->tenant_id}"),
            new PrivateChannel("copropiedad.{$this->copropiedad->id}"),
        ];
    }

    public function broadcastAs(): string
    {
        return 'precession.expense_forecast';
    }

    public function broadcastWith(): array
    {
        return [
            'copropiedad_id' => $this->copropiedad->id,
            'current_average' => $this->expenseContext['historico']['promedio_mensual'] ?? 0,
            'forecast_12m' => $this->forecast12m,
            'forecast_36m' => $this->forecast36m,
            'trend_direction' => $this->expenseContext['tendencia']['direccion'] ?? 'estable',
            'trend_percentage' => $this->expenseContext['tendencia']['porcentaje_anual'] ?? 0,
            'volatility_level' => $this->expenseContext['volatilidad']['nivel'] ?? 'bajo',
            'timestamp' => now()->toIso8601String(),
        ];
    }
}

// =========================================================
// M06 COMPLIANCE DS7-2025 - Alerta de compliance
// =========================================================

/**
 * PrecessionComplianceAlert
 * 
 * Se dispara cuando el PAE detecta brechas de cumplimiento
 * normativo o cambios regulatorios inminentes.
 */
class PrecessionComplianceAlert implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public Copropiedad $copropiedad,
        public array $complianceContext,
        public float $globalScore,
        public array $gaps,
        public array $regulatoryChangeProbability
    ) {}

    public function broadcastOn(): array
    {
        return [
            new PrivateChannel("tenant.{$this->copropiedad->tenant_id}"),
            new PrivateChannel("copropiedad.{$this->copropiedad->id}"),
        ];
    }

    public function broadcastAs(): string
    {
        return 'precession.compliance_alert';
    }

    public function broadcastWith(): array
    {
        $criticalGaps = array_filter($this->gaps, fn($g) => ($g['severidad'] ?? '') === 'critica');
        
        return [
            'copropiedad_id' => $this->copropiedad->id,
            'global_score' => $this->globalScore,
            'ds7_score' => $this->complianceContext['ds7_2025']['score'] ?? 0,
            'ley21442_status' => $this->complianceContext['ley_21442']['estado'] ?? 'pendiente',
            'gaps_count' => count($this->gaps),
            'critical_gaps_count' => count($criticalGaps),
            'regulatory_change_probability' => $this->regulatoryChangeProbability['prob_12m'] ?? 0,
            'severity' => count($criticalGaps) > 0 ? 'critical' : (count($this->gaps) > 3 ? 'high' : 'medium'),
            'timestamp' => now()->toIso8601String(),
        ];
    }
}

// =========================================================
// M07 ALÍCUOTAS LEY 21.442 - Proyección de alícuotas
// =========================================================

/**
 * PrecessionAliquotProjection
 * 
 * Se dispara cuando el PAE genera proyecciones de revalúo SII
 * y su impacto sobre la distribución de alícuotas.
 */
class PrecessionAliquotProjection implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public Copropiedad $copropiedad,
        public array $aliquotContext,
        public array $revaluationProjection,
        public array $affectedUnits
    ) {}

    public function broadcastOn(): array
    {
        return [
            new PrivateChannel("tenant.{$this->copropiedad->tenant_id}"),
            new PrivateChannel("copropiedad.{$this->copropiedad->id}"),
        ];
    }

    public function broadcastAs(): string
    {
        return 'precession.aliquot_projection';
    }

    public function broadcastWith(): array
    {
        return [
            'copropiedad_id' => $this->copropiedad->id,
            'current_gini' => $this->aliquotContext['distribucion_actual']['gini'] ?? 0,
            'total_avaluo_sii' => $this->aliquotContext['avaluos_sii']['total_copropiedad'] ?? 0,
            'revaluation_date' => $this->revaluationProjection['fecha'] ?? null,
            'revaluation_variation' => $this->revaluationProjection['variacion'] ?? 0,
            'affected_units_percentage' => $this->revaluationProjection['afectadas'] ?? 0,
            'impact_level' => $this->revaluationProjection['impacto'] ?? 'bajo',
            'timestamp' => now()->toIso8601String(),
        ];
    }
}

// =========================================================
// M08 VALORIZACIÓN - Valorización precesional actualizada
// =========================================================

/**
 * PrecessionValuationUpdated
 * 
 * Se dispara cuando el PAE actualiza la valorización precesional
 * a +90° en horizontes de 12-60 meses.
 */
class PrecessionValuationUpdated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public Copropiedad $copropiedad,
        public array $valuationContext,
        public array $precessionValuation,
        public float $confidence
    ) {}

    public function broadcastOn(): array
    {
        return [
            new PrivateChannel("tenant.{$this->copropiedad->tenant_id}"),
            new PrivateChannel("copropiedad.{$this->copropiedad->id}"),
        ];
    }

    public function broadcastAs(): string
    {
        return 'precession.valuation_updated';
    }

    public function broadcastWith(): array
    {
        $currentValue = $this->valuationContext['avaluo_fiscal']['valor_uf'] ?? 0;
        $value12m = $this->precessionValuation['horizonte_12m'] ?? 0;
        $value60m = $this->precessionValuation['horizonte_60m'] ?? 0;
        
        return [
            'copropiedad_id' => $this->copropiedad->id,
            'current_value_uf' => $currentValue,
            'valuation_12m' => $value12m,
            'valuation_24m' => $this->precessionValuation['horizonte_24m'] ?? 0,
            'valuation_36m' => $this->precessionValuation['horizonte_36m'] ?? 0,
            'valuation_60m' => $value60m,
            'appreciation_12m_percent' => $currentValue > 0 ? (($value12m - $currentValue) / $currentValue) * 100 : 0,
            'appreciation_60m_percent' => $currentValue > 0 ? (($value60m - $currentValue) / $currentValue) * 100 : 0,
            'main_factors' => $this->precessionValuation['factores_principales'] ?? [],
            'confidence' => $this->confidence,
            'timestamp' => now()->toIso8601String(),
        ];
    }
}

// =========================================================
// M16 ARRIENDOS - Pronóstico de arriendos
// =========================================================

/**
 * PrecessionRentalForecast
 * 
 * Se dispara cuando el PAE genera proyecciones de arriendo
 * ajustadas por factores precesionales.
 */
class PrecessionRentalForecast implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public Copropiedad $copropiedad,
        public array $rentalContext,
        public array $rentalProjection,
        public array $investmentMetrics
    ) {}

    public function broadcastOn(): array
    {
        return [
            new PrivateChannel("tenant.{$this->copropiedad->tenant_id}"),
            new PrivateChannel("copropiedad.{$this->copropiedad->id}"),
        ];
    }

    public function broadcastAs(): string
    {
        return 'precession.rental_forecast';
    }

    public function broadcastWith(): array
    {
        return [
            'copropiedad_id' => $this->copropiedad->id,
            'current_rental_avg' => $this->rentalContext['arriendos_activos']['arriendo_promedio'] ?? 0,
            'current_price_m2' => $this->rentalContext['precio_m2']['promedio'] ?? 0,
            'vacancy_rate' => $this->rentalContext['vacancia']['tasa_actual'] ?? 0,
            'rental_forecast_12m' => $this->rentalProjection['arriendo_12m'] ?? 0,
            'rental_forecast_24m' => $this->rentalProjection['arriendo_24m'] ?? 0,
            'rental_forecast_36m' => $this->rentalProjection['arriendo_36m'] ?? 0,
            'precession_adjustment' => $this->rentalProjection['factores_ajuste']['ajuste_precesional'] ?? 0,
            'gross_yield' => $this->investmentMetrics['gross_yield'] ?? 0,
            'net_yield' => $this->investmentMetrics['net_yield'] ?? 0,
            'payback_years' => $this->investmentMetrics['payback_anos'] ?? 0,
            'timestamp' => now()->toIso8601String(),
        ];
    }
}

// =========================================================
// EVENTO INTERNO - Datos de módulo actualizados
// =========================================================

/**
 * ModuleDataUpdated
 * 
 * Evento interno que señala que datos de un módulo han cambiado
 * y se requiere re-cálculo precesional.
 */
class ModuleDataUpdated
{
    use Dispatchable, SerializesModels;

    public function __construct(
        public string $moduleName,
        public string $entityType,
        public int $entityId,
        public ?int $copropiedadId,
        public string $changeType, // created, updated, deleted
        public array $changedAttributes = []
    ) {}

    /**
     * Determina si el cambio es significativo para trigger PAE
     */
    public function isSignificantChange(): bool
    {
        // Definir atributos significativos por módulo
        $significantAttributes = [
            'tributario' => ['monto', 'estado', 'cumplimiento'],
            'gastos_comunes' => ['monto_total', 'fecha'],
            'compliance' => ['score', 'estado', 'brecha'],
            'alicuotas' => ['prorrateo', 'avaluo'],
            'valorizacion' => ['valor', 'transaccion'],
            'arriendos' => ['monto_mensual', 'estado', 'vacancia'],
        ];

        $moduleAttrs = $significantAttributes[$this->moduleName] ?? [];
        
        if (empty($moduleAttrs)) {
            return true; // Por defecto, cualquier cambio es significativo
        }

        foreach ($this->changedAttributes as $attr) {
            if (in_array($attr, $moduleAttrs)) {
                return true;
            }
        }

        return false;
    }
}

// =========================================================
// EVENTO - Análisis precesional programado completado
// =========================================================

/**
 * ScheduledAnalysisCompleted
 * 
 * Se dispara cuando un análisis precesional programado
 * (via Job) se completa exitosamente.
 */
class ScheduledAnalysisCompleted
{
    use Dispatchable, SerializesModels;

    public function __construct(
        public int $copropiedadId,
        public string $analysisId,
        public array $results,
        public float $executionTimeSeconds,
        public bool $triggeredAlerts
    ) {}
}
