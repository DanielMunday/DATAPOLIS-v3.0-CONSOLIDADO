<?php

namespace App\Http\Controllers\Api\V1\PAE;

use App\Http\Controllers\Controller;
use App\Models\PropTech\Copropiedad;
use App\Models\PAE\PrecessionAnalysis;
use App\Models\PAE\PrecessionAlert;
use App\Services\PAE\PrecessionContextBuilder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

/**
 * IntegrationMetricsController
 * 
 * Endpoints para métricas integradas del PAE M11.
 * Expone datos consolidados de todos los módulos.
 */
class IntegrationMetricsController extends Controller
{
    public function __construct(
        protected PrecessionContextBuilder $contextBuilder
    ) {}

    // =========================================================
    // MÉTRICAS CONSOLIDADAS
    // =========================================================

    /**
     * GET /api/v1/pae/metrics/{copropiedadId}
     * 
     * Obtiene métricas consolidadas de todos los módulos.
     */
    public function getConsolidatedMetrics(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);
        
        $cacheKey = "pae:consolidated_metrics:{$copropiedadId}";
        
        $metrics = Cache::remember($cacheKey, 900, function () use ($copropiedad) {
            return DB::table('copropiedad_metrics')
                ->where('copropiedad_id', $copropiedad->id)
                ->first();
        });

        if (!$metrics) {
            return response()->json([
                'data' => null,
                'message' => 'No hay métricas disponibles. Ejecute un análisis primero.',
            ], 404);
        }

        return response()->json([
            'data' => [
                'copropiedad_id' => $copropiedad->id,
                'tax' => [
                    'risk_score' => $metrics->tax_risk_score,
                    'projected_load_12m' => $metrics->tax_projected_load_12m,
                    'compliance_rate' => $metrics->tax_compliance_rate,
                ],
                'expenses' => [
                    'avg_monthly' => $metrics->expense_avg_monthly,
                    'trend_direction' => $metrics->expense_trend_direction,
                    'trend_percentage' => $metrics->expense_trend_percentage,
                    'volatility_level' => $metrics->expense_volatility_level,
                ],
                'compliance' => [
                    'score_global' => $metrics->compliance_score_global,
                    'ds7_score' => $metrics->compliance_ds7_score,
                    'ley21442_status' => $metrics->compliance_ley21442_status,
                    'gaps_count' => $metrics->compliance_gaps_count,
                    'critical_gaps' => $metrics->compliance_critical_gaps,
                ],
                'aliquots' => [
                    'gini' => $metrics->aliquot_gini,
                    'revaluation_pct' => $metrics->aliquot_revaluation_pct,
                    'revaluation_date' => $metrics->aliquot_revaluation_date,
                ],
                'valuation' => [
                    'current_uf' => $metrics->valuation_current_uf,
                    'valuation_12m' => $metrics->valuation_12m_uf,
                    'valuation_60m' => $metrics->valuation_60m_uf,
                    'appreciation_60m' => $metrics->valuation_appreciation_60m,
                    'confidence' => $metrics->valuation_confidence,
                ],
                'rental' => [
                    'active_count' => $metrics->rental_active_count,
                    'avg_monthly' => $metrics->rental_avg_monthly,
                    'price_m2' => $metrics->rental_price_m2,
                    'vacancy_rate' => $metrics->rental_vacancy_rate,
                    'gross_yield' => $metrics->rental_gross_yield,
                    'net_yield' => $metrics->rental_net_yield,
                ],
                'pae' => [
                    'precession_score' => $metrics->pae_precession_score,
                    'risk_score' => $metrics->pae_risk_score,
                    'opportunity_score' => $metrics->pae_opportunity_score,
                    'last_analysis' => $metrics->pae_last_analysis,
                ],
                'updated_at' => $metrics->updated_at,
            ],
        ]);
    }

    /**
     * GET /api/v1/pae/metrics/{copropiedadId}/tax
     * 
     * Obtiene contexto tributario detallado.
     */
    public function getTaxContext(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);
        $context = $this->contextBuilder->buildTaxContext($copropiedad);

        return response()->json(['data' => $context]);
    }

    /**
     * GET /api/v1/pae/metrics/{copropiedadId}/expenses
     * 
     * Obtiene contexto de gastos comunes detallado.
     */
    public function getExpenseContext(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);
        $context = $this->contextBuilder->buildExpenseContext($copropiedad);

        return response()->json(['data' => $context]);
    }

    /**
     * GET /api/v1/pae/metrics/{copropiedadId}/compliance
     * 
     * Obtiene contexto de compliance detallado.
     */
    public function getComplianceContext(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);
        $context = $this->contextBuilder->buildComplianceContext($copropiedad);

        return response()->json(['data' => $context]);
    }

    /**
     * GET /api/v1/pae/metrics/{copropiedadId}/aliquots
     * 
     * Obtiene contexto de alícuotas detallado.
     */
    public function getAliquotContext(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);
        $context = $this->contextBuilder->buildAliquotContext($copropiedad);

        return response()->json(['data' => $context]);
    }

    /**
     * GET /api/v1/pae/metrics/{copropiedadId}/valuation
     * 
     * Obtiene contexto de valorización detallado.
     */
    public function getValuationContext(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);
        $context = $this->contextBuilder->buildValuationContext($copropiedad);

        return response()->json(['data' => $context]);
    }

    /**
     * GET /api/v1/pae/metrics/{copropiedadId}/rental
     * 
     * Obtiene contexto de arriendos detallado.
     */
    public function getRentalContext(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);
        $context = $this->contextBuilder->buildRentalContext($copropiedad);

        return response()->json(['data' => $context]);
    }

    /**
     * GET /api/v1/pae/metrics/{copropiedadId}/full
     * 
     * Obtiene contexto completo de todos los módulos.
     */
    public function getFullContext(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);
        $context = $this->contextBuilder->buildFullContext($copropiedad);

        return response()->json(['data' => $context]);
    }

    // =========================================================
    // PROYECCIONES
    // =========================================================

    /**
     * GET /api/v1/pae/projections/{copropiedadId}
     * 
     * Obtiene todas las proyecciones precesionales.
     */
    public function getProjections(int $copropiedadId): JsonResponse
    {
        $copropiedad = Copropiedad::findOrFail($copropiedadId);

        $expenseForecasts = DB::table('expense_forecasts')
            ->where('copropiedad_id', $copropiedadId)
            ->first();

        $aliquotProjections = DB::table('aliquot_projections')
            ->where('copropiedad_id', $copropiedadId)
            ->first();

        $valuations = DB::table('precession_valuations')
            ->where('copropiedad_id', $copropiedadId)
            ->first();

        $rentalMetrics = DB::table('rental_metrics')
            ->where('copropiedad_id', $copropiedadId)
            ->first();

        return response()->json([
            'data' => [
                'copropiedad_id' => $copropiedadId,
                'expenses' => $expenseForecasts ? [
                    'forecast_12m' => json_decode($expenseForecasts->forecast_12m, true),
                    'forecast_36m' => json_decode($expenseForecasts->forecast_36m, true),
                    'seasonality' => json_decode($expenseForecasts->seasonality_indices, true),
                    'trend' => [
                        'direction' => $expenseForecasts->trend_direction,
                        'percentage' => $expenseForecasts->trend_percentage,
                    ],
                ] : null,
                'aliquots' => $aliquotProjections ? [
                    'current_gini' => $aliquotProjections->current_gini,
                    'revaluation_date' => $aliquotProjections->revaluation_date,
                    'revaluation_variation' => $aliquotProjections->revaluation_variation,
                    'affected_units_pct' => $aliquotProjections->affected_units_pct,
                ] : null,
                'valuation' => $valuations ? [
                    'current_uf' => $valuations->current_value_uf,
                    'horizons' => [
                        '12m' => $valuations->valuation_12m,
                        '24m' => $valuations->valuation_24m,
                        '36m' => $valuations->valuation_36m,
                        '60m' => $valuations->valuation_60m,
                    ],
                    'appreciation_60m_pct' => $valuations->appreciation_60m_pct,
                    'confidence' => $valuations->confidence,
                    'main_factors' => json_decode($valuations->main_factors, true),
                ] : null,
                'rental' => $rentalMetrics ? [
                    'current_avg' => $rentalMetrics->average_rental,
                    'forecast_12m' => $rentalMetrics->forecast_12m,
                    'forecast_36m' => $rentalMetrics->forecast_36m,
                    'yields' => [
                        'gross' => $rentalMetrics->gross_yield,
                        'net' => $rentalMetrics->net_yield,
                    ],
                    'payback_years' => $rentalMetrics->payback_years,
                ] : null,
            ],
        ]);
    }

    // =========================================================
    // ESTADÍSTICAS DEL SISTEMA
    // =========================================================

    /**
     * GET /api/v1/pae/stats
     * 
     * Obtiene estadísticas del sistema PAE.
     */
    public function getSystemStats(Request $request): JsonResponse
    {
        $days = $request->input('days', 7);
        $tenantId = $request->user()->tenant_id ?? null;

        $query = DB::table('pae_statistics')
            ->where('date', '>=', now()->subDays($days)->toDateString());

        if ($tenantId) {
            $query->where(function ($q) use ($tenantId) {
                $q->where('tenant_id', $tenantId)
                  ->orWhereNull('tenant_id');
            });
        }

        $dailyStats = $query->orderBy('date')->get();

        // Agregados
        $totals = [
            'analyses_completed' => $dailyStats->sum('analyses_completed'),
            'analyses_failed' => $dailyStats->sum('analyses_failed'),
            'alerts_triggered' => $dailyStats->sum('alerts_triggered'),
            'critical_alerts' => $dailyStats->sum('critical_alerts'),
            'alerts_resolved' => $dailyStats->sum('alerts_resolved'),
        ];

        $averages = [
            'avg_precession_score' => $dailyStats->avg('avg_precession_score'),
            'avg_risk_score' => $dailyStats->avg('avg_risk_score'),
            'avg_opportunity_score' => $dailyStats->avg('avg_opportunity_score'),
            'avg_execution_time' => $dailyStats->avg('avg_execution_time'),
        ];

        // Alertas activas actuales
        $activeAlerts = PrecessionAlert::where('status', 'active')
            ->when($tenantId, fn($q) => $q->where('tenant_id', $tenantId))
            ->selectRaw('severity, COUNT(*) as count')
            ->groupBy('severity')
            ->pluck('count', 'severity');

        return response()->json([
            'data' => [
                'period_days' => $days,
                'totals' => $totals,
                'averages' => $averages,
                'daily' => $dailyStats,
                'active_alerts' => $activeAlerts,
                'success_rate' => $totals['analyses_completed'] > 0
                    ? round($totals['analyses_completed'] / ($totals['analyses_completed'] + $totals['analyses_failed']) * 100, 1)
                    : 0,
            ],
        ]);
    }

    /**
     * GET /api/v1/pae/stats/top-risks
     * 
     * Obtiene copropiedades con mayor riesgo.
     */
    public function getTopRisks(Request $request): JsonResponse
    {
        $limit = min($request->input('limit', 10), 50);
        $tenantId = $request->user()->tenant_id ?? null;

        $risks = DB::table('copropiedad_metrics')
            ->join('copropiedades', 'copropiedades.id', '=', 'copropiedad_metrics.copropiedad_id')
            ->whereNotNull('pae_risk_score')
            ->when($tenantId, fn($q) => $q->where('copropiedades.tenant_id', $tenantId))
            ->orderByDesc('pae_risk_score')
            ->limit($limit)
            ->select(
                'copropiedades.id',
                'copropiedades.nombre',
                'copropiedades.comuna',
                'copropiedad_metrics.pae_risk_score',
                'copropiedad_metrics.pae_precession_score',
                'copropiedad_metrics.tax_risk_score',
                'copropiedad_metrics.compliance_score_global',
                'copropiedad_metrics.pae_last_analysis'
            )
            ->get();

        return response()->json(['data' => $risks]);
    }

    /**
     * GET /api/v1/pae/stats/top-opportunities
     * 
     * Obtiene copropiedades con mejores oportunidades.
     */
    public function getTopOpportunities(Request $request): JsonResponse
    {
        $limit = min($request->input('limit', 10), 50);
        $tenantId = $request->user()->tenant_id ?? null;

        $opportunities = DB::table('precession_valuations')
            ->join('copropiedades', 'copropiedades.id', '=', 'precession_valuations.copropiedad_id')
            ->where('appreciation_60m_pct', '>', 0)
            ->when($tenantId, fn($q) => $q->where('copropiedades.tenant_id', $tenantId))
            ->orderByDesc('appreciation_60m_pct')
            ->limit($limit)
            ->select(
                'copropiedades.id',
                'copropiedades.nombre',
                'copropiedades.comuna',
                'precession_valuations.current_value_uf',
                'precession_valuations.valuation_60m',
                'precession_valuations.appreciation_60m_pct',
                'precession_valuations.confidence',
                'precession_valuations.main_factors'
            )
            ->get()
            ->map(function ($item) {
                $item->main_factors = json_decode($item->main_factors, true);
                return $item;
            });

        return response()->json(['data' => $opportunities]);
    }

    /**
     * GET /api/v1/pae/stats/module-changes
     * 
     * Obtiene historial de cambios en módulos.
     */
    public function getModuleChanges(Request $request): JsonResponse
    {
        $days = min($request->input('days', 7), 30);
        $module = $request->input('module');

        $query = DB::table('pae_module_changes')
            ->where('created_at', '>=', now()->subDays($days));

        if ($module) {
            $query->where('module_name', $module);
        }

        $changes = $query
            ->selectRaw('
                module_name,
                change_type,
                DATE(created_at) as date,
                COUNT(*) as count
            ')
            ->groupBy('module_name', 'change_type', DB::raw('DATE(created_at)'))
            ->orderByDesc('date')
            ->get();

        $summary = $query
            ->selectRaw('module_name, COUNT(*) as total')
            ->groupBy('module_name')
            ->pluck('total', 'module_name');

        return response()->json([
            'data' => [
                'period_days' => $days,
                'by_module' => $summary,
                'daily' => $changes,
            ],
        ]);
    }

    // =========================================================
    // RANKINGS Y COMPARATIVAS
    // =========================================================

    /**
     * GET /api/v1/pae/rankings
     * 
     * Obtiene rankings por diferentes métricas.
     */
    public function getRankings(Request $request): JsonResponse
    {
        $metric = $request->input('metric', 'precession_score');
        $order = $request->input('order', 'desc');
        $limit = min($request->input('limit', 20), 100);
        $tenantId = $request->user()->tenant_id ?? null;

        $validMetrics = [
            'precession_score' => 'pae_precession_score',
            'risk_score' => 'pae_risk_score',
            'opportunity_score' => 'pae_opportunity_score',
            'compliance' => 'compliance_score_global',
            'tax_risk' => 'tax_risk_score',
            'yield' => 'rental_gross_yield',
            'appreciation' => 'valuation_appreciation_60m',
        ];

        if (!isset($validMetrics[$metric])) {
            return response()->json([
                'error' => 'Invalid metric',
                'valid_metrics' => array_keys($validMetrics),
            ], 400);
        }

        $column = $validMetrics[$metric];

        $rankings = DB::table('copropiedad_metrics')
            ->join('copropiedades', 'copropiedades.id', '=', 'copropiedad_metrics.copropiedad_id')
            ->whereNotNull($column)
            ->when($tenantId, fn($q) => $q->where('copropiedades.tenant_id', $tenantId))
            ->orderBy($column, $order)
            ->limit($limit)
            ->select(
                'copropiedades.id',
                'copropiedades.nombre',
                'copropiedades.comuna',
                DB::raw("{$column} as value"),
                'copropiedad_metrics.updated_at'
            )
            ->get()
            ->map(function ($item, $index) {
                $item->rank = $index + 1;
                return $item;
            });

        return response()->json([
            'data' => [
                'metric' => $metric,
                'order' => $order,
                'rankings' => $rankings,
            ],
        ]);
    }

    /**
     * POST /api/v1/pae/compare-metrics
     * 
     * Compara métricas entre copropiedades.
     */
    public function compareMetrics(Request $request): JsonResponse
    {
        $request->validate([
            'copropiedad_ids' => 'required|array|min:2|max:10',
            'copropiedad_ids.*' => 'integer|exists:copropiedades,id',
        ]);

        $ids = $request->input('copropiedad_ids');

        $metrics = DB::table('copropiedad_metrics')
            ->join('copropiedades', 'copropiedades.id', '=', 'copropiedad_metrics.copropiedad_id')
            ->whereIn('copropiedad_metrics.copropiedad_id', $ids)
            ->select(
                'copropiedades.id',
                'copropiedades.nombre',
                'copropiedades.comuna',
                'copropiedad_metrics.*'
            )
            ->get()
            ->keyBy('id');

        // Calcular promedios para comparación
        $averages = [
            'pae_precession_score' => $metrics->avg('pae_precession_score'),
            'pae_risk_score' => $metrics->avg('pae_risk_score'),
            'pae_opportunity_score' => $metrics->avg('pae_opportunity_score'),
            'compliance_score_global' => $metrics->avg('compliance_score_global'),
            'rental_gross_yield' => $metrics->avg('rental_gross_yield'),
            'valuation_appreciation_60m' => $metrics->avg('valuation_appreciation_60m'),
        ];

        // Identificar mejor/peor por métrica
        $rankings = [];
        foreach ($averages as $key => $avg) {
            $sorted = $metrics->sortByDesc($key);
            $rankings[$key] = [
                'best' => $sorted->first()?->id,
                'worst' => $sorted->last()?->id,
                'average' => $avg,
            ];
        }

        return response()->json([
            'data' => [
                'copropiedades' => $metrics,
                'averages' => $averages,
                'rankings' => $rankings,
            ],
        ]);
    }
}
