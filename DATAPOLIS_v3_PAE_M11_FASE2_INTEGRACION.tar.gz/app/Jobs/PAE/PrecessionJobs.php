<?php

namespace App\Jobs\PAE;

use App\Models\PropTech\Copropiedad;
use App\Models\PAE\PrecessionAnalysis;
use App\Services\PrecessionService;
use App\Services\PAE\PrecessionContextBuilder;
use App\Events\PAE\ScheduledAnalysisCompleted;
use App\Events\PAE\PrecessionTaxRiskUpdated;
use App\Events\PAE\PrecessionExpenseForecast;
use App\Events\PAE\PrecessionComplianceAlert;
use App\Events\PAE\PrecessionAliquotProjection;
use App\Events\PAE\PrecessionValuationUpdated;
use App\Events\PAE\PrecessionRentalForecast;
use App\Notifications\PAE\PrecessionAnalysisNotification;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Notification;
use Carbon\Carbon;
use Throwable;

/**
 * TriggerPrecessionAnalysis
 * 
 * Job que ejecuta análisis precesional para una copropiedad.
 * Puede ser disparado por:
 * - Observer (cambios en modelos)
 * - Scheduler (análisis diario)
 * - API (solicitud manual)
 */
class TriggerPrecessionAnalysis implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Número de intentos
     */
    public int $tries = 3;

    /**
     * Timeout en segundos
     */
    public int $timeout = 120;

    /**
     * Backoff en segundos para reintentos
     */
    public array $backoff = [30, 60, 120];

    public function __construct(
        public int $copropiedadId,
        public array $options = []
    ) {}

    /**
     * ID único para prevenir duplicados
     */
    public function uniqueId(): string
    {
        return "pae_analysis_{$this->copropiedadId}";
    }

    /**
     * Tiempo de unicidad (segundos)
     */
    public function uniqueFor(): int
    {
        return 300; // 5 minutos
    }

    /**
     * Ejecutar el job
     */
    public function handle(
        PrecessionService $precessionService,
        PrecessionContextBuilder $contextBuilder
    ): void {
        $startTime = microtime(true);
        $triggeredAlerts = false;

        try {
            $copropiedad = Copropiedad::findOrFail($this->copropiedadId);
            
            Log::info("PAE Job: Iniciando análisis para copropiedad {$this->copropiedadId}", [
                'reason' => $this->options['reason'] ?? 'scheduled',
                'priority' => $this->options['priority'] ?? 'normal',
            ]);

            // Limpiar flag de análisis pendiente
            Cache::forget("pae:pending_analysis:{$this->copropiedadId}");

            // Ejecutar análisis principal
            $analysisResult = $precessionService->analyzeCopropiedad($this->copropiedadId, [
                'horizon' => $this->options['horizon'] ?? 36,
                'radius' => $this->options['radius'] ?? 1000,
                'max_depth' => $this->options['max_depth'] ?? 4,
                'include_ml' => $this->options['include_ml'] ?? true,
                'force_refresh' => $this->options['force_refresh'] ?? true,
            ]);

            if (!$analysisResult || isset($analysisResult['error'])) {
                throw new \Exception($analysisResult['error'] ?? 'Análisis falló sin mensaje de error');
            }

            // Construir contextos enriquecidos
            $contexts = $this->buildEnrichedContexts($contextBuilder, $copropiedad);

            // Disparar eventos de integración según resultados
            $triggeredAlerts = $this->dispatchIntegrationEvents($copropiedad, $analysisResult, $contexts);

            $executionTime = microtime(true) - $startTime;

            // Evento de análisis completado
            event(new ScheduledAnalysisCompleted(
                copropiedadId: $this->copropiedadId,
                analysisId: $analysisResult['analysis_id'] ?? '',
                results: $analysisResult,
                executionTimeSeconds: $executionTime,
                triggeredAlerts: $triggeredAlerts
            ));

            Log::info("PAE Job: Análisis completado para copropiedad {$this->copropiedadId}", [
                'execution_time' => round($executionTime, 2) . 's',
                'triggered_alerts' => $triggeredAlerts,
                'precession_score' => $analysisResult['precession_score'] ?? null,
            ]);

        } catch (Throwable $e) {
            Log::error("PAE Job: Error en análisis copropiedad {$this->copropiedadId}", [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            
            throw $e;
        }
    }

    /**
     * Construye contextos enriquecidos de todos los módulos
     */
    protected function buildEnrichedContexts(
        PrecessionContextBuilder $contextBuilder, 
        Copropiedad $copropiedad
    ): array {
        return [
            'tax' => $contextBuilder->buildTaxContext($copropiedad),
            'expenses' => $contextBuilder->buildExpenseContext($copropiedad),
            'compliance' => $contextBuilder->buildComplianceContext($copropiedad),
            'aliquots' => $contextBuilder->buildAliquotContext($copropiedad),
            'valuation' => $contextBuilder->buildValuationContext($copropiedad),
            'rental' => $contextBuilder->buildRentalContext($copropiedad),
        ];
    }

    /**
     * Dispara eventos de integración basados en umbrales
     */
    protected function dispatchIntegrationEvents(
        Copropiedad $copropiedad, 
        array $analysisResult, 
        array $contexts
    ): bool {
        $triggeredAlerts = false;

        // M04 Tributario - si riesgo tributario > 0.5
        if (($contexts['tax']['risk_score'] ?? 0) > 0.5) {
            event(new PrecessionTaxRiskUpdated(
                copropiedad: $copropiedad,
                taxContext: $contexts['tax'],
                riskScore: $contexts['tax']['risk_score'],
                projectedLoad: [
                    '12m' => $contexts['tax']['projected_load_12m'] ?? 0,
                    '36m' => $contexts['tax']['projected_load_36m'] ?? 0,
                ],
                recommendations: $this->generateTaxRecommendations($contexts['tax'])
            ));
            $triggeredAlerts = true;
        }

        // M05 Gastos - si tendencia > 10% anual
        if (abs($contexts['expenses']['tendencia']['porcentaje_anual'] ?? 0) > 10) {
            event(new PrecessionExpenseForecast(
                copropiedad: $copropiedad,
                expenseContext: $contexts['expenses'],
                forecast12m: $contexts['expenses']['proyecciones']['12_meses'] ?? [],
                forecast36m: $contexts['expenses']['proyecciones']['36_meses'] ?? [],
                seasonalityIndices: $contexts['expenses']['estacionalidad']['indices_mensuales'] ?? []
            ));
            $triggeredAlerts = true;
        }

        // M06 Compliance - si score < 70 o hay brechas críticas
        $complianceScore = $contexts['compliance']['score_global'] ?? 100;
        $criticalGaps = $contexts['compliance']['brechas']['criticas'] ?? [];
        if ($complianceScore < 70 || count($criticalGaps) > 0) {
            event(new PrecessionComplianceAlert(
                copropiedad: $copropiedad,
                complianceContext: $contexts['compliance'],
                globalScore: $complianceScore,
                gaps: $contexts['compliance']['brechas']['detalle'] ?? [],
                regulatoryChangeProbability: $contexts['compliance']['cambio_normativo'] ?? []
            ));
            $triggeredAlerts = true;
        }

        // M07 Alícuotas - si revalúo proyectado > 5%
        $revaluationVariation = $contexts['aliquots']['proyeccion_revaluo']['variacion_estimada'] ?? 0;
        if ($revaluationVariation > 5) {
            event(new PrecessionAliquotProjection(
                copropiedad: $copropiedad,
                aliquotContext: $contexts['aliquots'],
                revaluationProjection: $contexts['aliquots']['proyeccion_revaluo'] ?? [],
                affectedUnits: $this->getAffectedUnits($copropiedad, $contexts['aliquots'])
            ));
            $triggeredAlerts = true;
        }

        // M08 Valorización - siempre actualizar (core del PAE)
        $valuationPrecession = $contexts['valuation']['valorizacion_precesional'] ?? [];
        if (!empty($valuationPrecession)) {
            event(new PrecessionValuationUpdated(
                copropiedad: $copropiedad,
                valuationContext: $contexts['valuation'],
                precessionValuation: $valuationPrecession,
                confidence: $valuationPrecession['confianza'] ?? 0.7
            ));
        }

        // M16 Arriendos - si hay arriendos activos
        $arriendosActivos = $contexts['rental']['arriendos_activos']['cantidad'] ?? 0;
        if ($arriendosActivos > 0) {
            event(new PrecessionRentalForecast(
                copropiedad: $copropiedad,
                rentalContext: $contexts['rental'],
                rentalProjection: $contexts['rental']['proyeccion_precesional'] ?? [],
                investmentMetrics: $contexts['rental']['metricas_inversion'] ?? []
            ));
        }

        return $triggeredAlerts;
    }

    protected function generateTaxRecommendations(array $taxContext): array
    {
        $recommendations = [];
        
        if (($taxContext['dj_1879']['cumplimiento'] ?? '') === 'pendiente') {
            $recommendations[] = [
                'priority' => 'high',
                'action' => 'Presentar DJ 1879 antes del 31 de marzo',
                'deadline' => Carbon::now()->year . '-03-31',
            ];
        }
        
        if (($taxContext['f29']['cumplimiento_12m'] ?? 100) < 90) {
            $recommendations[] = [
                'priority' => 'medium',
                'action' => 'Regularizar presentación de F29',
                'deadline' => null,
            ];
        }

        return $recommendations;
    }

    protected function getAffectedUnits(Copropiedad $copropiedad, array $aliquotContext): array
    {
        // Retornar unidades que serían afectadas por revalúo
        return [];
    }

    /**
     * Handle job failure
     */
    public function failed(Throwable $exception): void
    {
        Log::error("PAE Job: Falló análisis copropiedad {$this->copropiedadId}", [
            'error' => $exception->getMessage(),
            'attempts' => $this->attempts(),
        ]);

        // Marcar análisis como fallido si existe
        PrecessionAnalysis::where('copropiedad_id', $this->copropiedadId)
            ->where('status', 'processing')
            ->update([
                'status' => 'failed',
                'error_message' => $exception->getMessage(),
            ]);
    }
}

// =========================================================
// JOB PROGRAMADO DIARIO
// =========================================================

/**
 * ScheduledPrecessionAnalysis
 * 
 * Job programado que ejecuta análisis precesional para todas
 * las copropiedades activas. Diseñado para ejecutarse diariamente.
 * 
 * Uso en Console/Kernel.php:
 * $schedule->job(new ScheduledPrecessionAnalysis)->dailyAt('02:00');
 */
class ScheduledPrecessionAnalysis implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 1;
    public int $timeout = 3600; // 1 hora máximo

    public function __construct(
        public ?int $tenantId = null,
        public array $filters = []
    ) {}

    public function handle(): void
    {
        $startTime = microtime(true);
        
        Log::info("PAE Scheduled: Iniciando análisis programado diario", [
            'tenant_id' => $this->tenantId,
            'filters' => $this->filters,
        ]);

        // Construir query de copropiedades
        $query = Copropiedad::query()
            ->where('activa', true)
            ->whereNotNull('latitud')
            ->whereNotNull('longitud');

        // Filtrar por tenant si se especifica
        if ($this->tenantId) {
            $query->where('tenant_id', $this->tenantId);
        }

        // Filtrar por comuna si se especifica
        if (!empty($this->filters['comuna'])) {
            $query->where('comuna', $this->filters['comuna']);
        }

        // Priorizar copropiedades sin análisis reciente
        $query->where(function ($q) {
            $q->whereDoesntHave('precessionAnalyses')
              ->orWhereHas('precessionAnalyses', function ($sq) {
                  $sq->where('created_at', '<', now()->subDays(7))
                     ->orWhere('status', 'failed');
              });
        });

        // Limitar a batch manejable
        $batchSize = $this->filters['batch_size'] ?? 50;
        $copropiedades = $query->limit($batchSize)->get();

        $dispatched = 0;
        $skipped = 0;

        foreach ($copropiedades as $index => $copropiedad) {
            // Verificar si ya hay análisis reciente válido
            $recentAnalysis = $copropiedad->precessionAnalyses()
                ->where('status', 'completed')
                ->where('created_at', '>=', now()->subHours(12))
                ->exists();

            if ($recentAnalysis) {
                $skipped++;
                continue;
            }

            // Despachar con delay escalonado para no sobrecargar
            $delay = $index * 30; // 30 segundos entre cada uno
            
            TriggerPrecessionAnalysis::dispatch($copropiedad->id, [
                'reason' => 'scheduled_daily',
                'priority' => 'low',
            ])->delay(now()->addSeconds($delay));

            $dispatched++;
        }

        $executionTime = microtime(true) - $startTime;

        Log::info("PAE Scheduled: Análisis diario completado", [
            'total_copropiedades' => $copropiedades->count(),
            'dispatched' => $dispatched,
            'skipped' => $skipped,
            'execution_time' => round($executionTime, 2) . 's',
        ]);
    }
}

// =========================================================
// JOB DE LIMPIEZA
// =========================================================

/**
 * CleanupExpiredAnalyses
 * 
 * Limpia análisis expirados y datos de cache obsoletos.
 * Ejecutar semanalmente.
 */
class CleanupExpiredAnalyses implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(): void
    {
        Log::info("PAE Cleanup: Iniciando limpieza de análisis expirados");

        // Eliminar análisis expirados (> 30 días)
        $deleted = PrecessionAnalysis::where('expires_at', '<', now()->subDays(30))
            ->delete();

        // Limpiar alertas resueltas antiguas
        $alertsDeleted = \App\Models\PAE\PrecessionAlert::where('status', 'resolved')
            ->where('resolved_at', '<', now()->subDays(90))
            ->delete();

        Log::info("PAE Cleanup: Limpieza completada", [
            'analyses_deleted' => $deleted,
            'alerts_deleted' => $alertsDeleted,
        ]);
    }
}

// =========================================================
// JOB DE RECÁLCULO MASIVO
// =========================================================

/**
 * BatchRecalculatePrecession
 * 
 * Recalcula análisis precesional para un conjunto de copropiedades.
 * Útil después de cambios masivos o actualizaciones de ontología.
 */
class BatchRecalculatePrecession implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 7200; // 2 horas

    public function __construct(
        public array $copropiedadIds,
        public string $reason = 'batch_recalculate'
    ) {}

    public function handle(): void
    {
        Log::info("PAE Batch: Iniciando recálculo masivo", [
            'count' => count($this->copropiedadIds),
            'reason' => $this->reason,
        ]);

        foreach ($this->copropiedadIds as $index => $id) {
            TriggerPrecessionAnalysis::dispatch($id, [
                'reason' => $this->reason,
                'priority' => 'medium',
                'force_refresh' => true,
            ])->delay(now()->addSeconds($index * 20));
        }

        Log::info("PAE Batch: {$index} análisis despachados");
    }
}
