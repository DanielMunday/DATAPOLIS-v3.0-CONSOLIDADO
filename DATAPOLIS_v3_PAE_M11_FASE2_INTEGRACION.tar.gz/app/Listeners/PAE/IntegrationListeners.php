<?php

namespace App\Listeners\PAE;

use App\Events\PAE\PrecessionTaxRiskUpdated;
use App\Events\PAE\PrecessionExpenseForecast;
use App\Events\PAE\PrecessionComplianceAlert;
use App\Events\PAE\PrecessionAliquotProjection;
use App\Events\PAE\PrecessionValuationUpdated;
use App\Events\PAE\PrecessionRentalForecast;
use App\Events\PAE\ModuleDataUpdated;
use App\Events\PAE\ScheduledAnalysisCompleted;
use App\Models\PAE\PrecessionAlert;
use App\Models\Core\User;
use App\Notifications\PAE\TaxRiskNotification;
use App\Notifications\PAE\ComplianceAlertNotification;
use App\Notifications\PAE\ValuationUpdateNotification;
use App\Notifications\PAE\HighPriorityAlertNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\DB;

/**
 * =========================================================
 * LISTENERS DE INTEGRACIÓN PAE M11
 * =========================================================
 */

// =========================================================
// LISTENER: Riesgo Tributario Actualizado
// =========================================================

/**
 * HandleTaxRiskUpdated
 * 
 * Procesa actualizaciones de riesgo tributario y genera
 * alertas/notificaciones según umbrales.
 */
class HandleTaxRiskUpdated implements ShouldQueue
{
    use InteractsWithQueue;

    public function handle(PrecessionTaxRiskUpdated $event): void
    {
        Log::info("PAE Listener: Procesando actualización riesgo tributario", [
            'copropiedad_id' => $event->copropiedad->id,
            'risk_score' => $event->riskScore,
        ]);

        // Crear alerta si riesgo es alto
        if ($event->riskScore >= 0.7) {
            $alert = PrecessionAlert::create([
                'tenant_id' => $event->copropiedad->tenant_id,
                'copropiedad_id' => $event->copropiedad->id,
                'alert_type' => 'risk_threshold',
                'severity' => $event->riskScore >= 0.85 ? 'critical' : 'high',
                'precession_angle' => 'direct_0',
                'title' => 'Riesgo tributario elevado detectado',
                'description' => sprintf(
                    'El análisis precesional detectó un riesgo tributario del %.1f%%. ' .
                    'Carga proyectada 12 meses: %.2f UF. Cumplimiento: %.1f%%.',
                    $event->riskScore * 100,
                    $event->projectedLoad['12m'] ?? 0,
                    $event->taxContext['metrics']['cumplimiento_global'] ?? 0
                ),
                'recommendation' => $this->generateTaxRecommendation($event),
                'probability' => $event->riskScore,
                'potential_impact_uf' => $event->projectedLoad['12m'] ?? 0,
                'expected_months' => 12,
                'status' => 'active',
                'expires_at' => now()->addDays(30),
            ]);

            // Notificar administradores
            $this->notifyAdministrators($event, $alert);
        }

        // Actualizar métricas en tabla de resumen
        $this->updateTaxMetrics($event);
    }

    protected function generateTaxRecommendation(PrecessionTaxRiskUpdated $event): string
    {
        $recommendations = [];
        
        if (($event->taxContext['dj_1879']['cumplimiento'] ?? '') === 'pendiente') {
            $recommendations[] = 'Regularizar DJ 1879';
        }
        if (($event->taxContext['f29']['cumplimiento_12m'] ?? 100) < 90) {
            $recommendations[] = 'Mejorar cumplimiento F29';
        }
        if (($event->projectedLoad['36m'] ?? 0) > ($event->projectedLoad['12m'] ?? 0) * 3.5) {
            $recommendations[] = 'Evaluar planificación tributaria preventiva';
        }

        return implode('. ', $recommendations) ?: 'Revisar situación tributaria con asesor especializado';
    }

    protected function notifyAdministrators(PrecessionTaxRiskUpdated $event, PrecessionAlert $alert): void
    {
        $admins = User::where('tenant_id', $event->copropiedad->tenant_id)
            ->whereIn('role', ['admin', 'superadmin'])
            ->get();

        if ($admins->isNotEmpty()) {
            Notification::send($admins, new TaxRiskNotification($alert, $event));
        }
    }

    protected function updateTaxMetrics(PrecessionTaxRiskUpdated $event): void
    {
        DB::table('copropiedad_metrics')
            ->updateOrInsert(
                ['copropiedad_id' => $event->copropiedad->id],
                [
                    'tax_risk_score' => $event->riskScore,
                    'tax_projected_load_12m' => $event->projectedLoad['12m'] ?? 0,
                    'tax_compliance_rate' => $event->taxContext['metrics']['cumplimiento_global'] ?? 100,
                    'updated_at' => now(),
                ]
            );
    }
}

// =========================================================
// LISTENER: Pronóstico de Gastos
// =========================================================

/**
 * HandleExpenseForecast
 * 
 * Procesa pronósticos de gastos comunes y actualiza proyecciones.
 */
class HandleExpenseForecast implements ShouldQueue
{
    use InteractsWithQueue;

    public function handle(PrecessionExpenseForecast $event): void
    {
        Log::info("PAE Listener: Procesando pronóstico gastos", [
            'copropiedad_id' => $event->copropiedad->id,
            'trend' => $event->expenseContext['tendencia']['direccion'] ?? 'unknown',
        ]);

        // Crear alerta si tendencia es muy alta (> 15% anual)
        $trendPercent = $event->expenseContext['tendencia']['porcentaje_anual'] ?? 0;
        
        if ($trendPercent > 15) {
            PrecessionAlert::create([
                'tenant_id' => $event->copropiedad->tenant_id,
                'copropiedad_id' => $event->copropiedad->id,
                'alert_type' => 'trend_change',
                'severity' => $trendPercent > 25 ? 'high' : 'medium',
                'precession_angle' => 'induced_45',
                'title' => 'Tendencia creciente en gastos comunes',
                'description' => sprintf(
                    'Los gastos comunes muestran una tendencia creciente del %.1f%% anual. ' .
                    'Proyección 12 meses: $%s. Promedio actual: $%s.',
                    $trendPercent,
                    number_format($event->forecast12m['promedio_mensual'] ?? 0, 0, ',', '.'),
                    number_format($event->expenseContext['historico']['promedio_mensual'] ?? 0, 0, ',', '.')
                ),
                'recommendation' => 'Revisar estructura de gastos y evaluar medidas de eficiencia',
                'probability' => min(0.9, 0.5 + ($trendPercent / 100)),
                'potential_impact_uf' => ($event->forecast12m['total'] ?? 0) * 0.03, // Estimación en UF
                'expected_months' => 12,
                'status' => 'active',
                'expires_at' => now()->addDays(60),
            ]);
        }

        // Guardar pronósticos para dashboard
        DB::table('expense_forecasts')
            ->updateOrInsert(
                ['copropiedad_id' => $event->copropiedad->id],
                [
                    'forecast_12m' => json_encode($event->forecast12m),
                    'forecast_36m' => json_encode($event->forecast36m),
                    'seasonality_indices' => json_encode($event->seasonalityIndices),
                    'trend_direction' => $event->expenseContext['tendencia']['direccion'] ?? 'estable',
                    'trend_percentage' => $trendPercent,
                    'updated_at' => now(),
                ]
            );
    }
}

// =========================================================
// LISTENER: Alerta de Compliance
// =========================================================

/**
 * HandleComplianceAlert
 * 
 * Procesa alertas de compliance y genera notificaciones urgentes.
 */
class HandleComplianceAlert implements ShouldQueue
{
    use InteractsWithQueue;

    public function handle(PrecessionComplianceAlert $event): void
    {
        Log::info("PAE Listener: Procesando alerta compliance", [
            'copropiedad_id' => $event->copropiedad->id,
            'score' => $event->globalScore,
            'gaps' => count($event->gaps),
        ]);

        // Siempre crear alerta para compliance bajo
        $criticalGaps = array_filter($event->gaps, fn($g) => ($g['severidad'] ?? '') === 'critica');
        
        $severity = match(true) {
            count($criticalGaps) >= 2 => 'critical',
            count($criticalGaps) >= 1 || $event->globalScore < 50 => 'high',
            $event->globalScore < 70 => 'medium',
            default => 'low',
        };

        $alert = PrecessionAlert::create([
            'tenant_id' => $event->copropiedad->tenant_id,
            'copropiedad_id' => $event->copropiedad->id,
            'alert_type' => 'regulatory_impact',
            'severity' => $severity,
            'precession_angle' => 'precession_90',
            'title' => 'Brechas de cumplimiento normativo detectadas',
            'description' => $this->buildComplianceDescription($event),
            'recommendation' => $this->buildComplianceRecommendation($event),
            'probability' => 0.95, // Alta certeza en brechas de compliance
            'potential_impact_uf' => $this->estimateComplianceImpact($event),
            'expected_months' => 3,
            'status' => 'active',
            'expires_at' => now()->addDays(30),
        ]);

        // Notificación inmediata si es crítico
        if ($severity === 'critical') {
            $this->sendUrgentNotification($event, $alert);
        }
    }

    protected function buildComplianceDescription(PrecessionComplianceAlert $event): string
    {
        $parts = [
            sprintf('Score de cumplimiento: %.1f/100.', $event->globalScore),
            sprintf('DS7-2025: %s.', $event->complianceContext['ds7_2025']['nivel'] ?? 'pendiente'),
            sprintf('Ley 21.442: %s.', $event->complianceContext['ley_21442']['estado'] ?? 'pendiente'),
        ];

        if (count($event->gaps) > 0) {
            $parts[] = sprintf('%d brechas detectadas que requieren atención.', count($event->gaps));
        }

        return implode(' ', $parts);
    }

    protected function buildComplianceRecommendation(PrecessionComplianceAlert $event): string
    {
        $recommendations = $event->complianceContext['recomendaciones'] ?? [];
        
        if (empty($recommendations)) {
            return 'Agendar revisión de cumplimiento normativo con asesor legal';
        }

        $topRecommendations = array_slice($recommendations, 0, 3);
        return implode('. ', array_map(fn($r) => $r['accion'] ?? '', $topRecommendations));
    }

    protected function estimateComplianceImpact(PrecessionComplianceAlert $event): float
    {
        $multaPotencial = $event->complianceContext['ley_21442']['multa_potencial'] ?? 0;
        $utm = 65000; // Valor UTM aproximado en CLP
        $uf = 37000;  // Valor UF aproximado en CLP
        
        return ($multaPotencial * $utm) / $uf;
    }

    protected function sendUrgentNotification(PrecessionComplianceAlert $event, PrecessionAlert $alert): void
    {
        $admins = User::where('tenant_id', $event->copropiedad->tenant_id)
            ->whereIn('role', ['admin', 'superadmin', 'compliance_officer'])
            ->get();

        if ($admins->isNotEmpty()) {
            Notification::send($admins, new ComplianceAlertNotification($alert, $event));
        }
    }
}

// =========================================================
// LISTENER: Proyección de Alícuotas
// =========================================================

/**
 * HandleAliquotProjection
 * 
 * Procesa proyecciones de revalúo y su impacto en alícuotas.
 */
class HandleAliquotProjection implements ShouldQueue
{
    use InteractsWithQueue;

    public function handle(PrecessionAliquotProjection $event): void
    {
        Log::info("PAE Listener: Procesando proyección alícuotas", [
            'copropiedad_id' => $event->copropiedad->id,
            'revaluation_variation' => $event->revaluationProjection['variacion'] ?? 0,
        ]);

        $variation = $event->revaluationProjection['variacion'] ?? 0;

        // Crear alerta si variación proyectada es significativa
        if ($variation > 10) {
            PrecessionAlert::create([
                'tenant_id' => $event->copropiedad->tenant_id,
                'copropiedad_id' => $event->copropiedad->id,
                'alert_type' => 'market_shift',
                'severity' => $variation > 20 ? 'high' : 'medium',
                'precession_angle' => 'systemic_135',
                'title' => 'Revalúo SII proyectado con impacto en alícuotas',
                'description' => sprintf(
                    'Se proyecta un revalúo SII con variación de %.1f%% para %s. ' .
                    'Aproximadamente %s%% de las unidades podrían ver modificadas sus alícuotas.',
                    $variation,
                    $event->revaluationProjection['fecha'] ?? 'próximo período',
                    $event->revaluationProjection['afectadas'] ?? 0
                ),
                'recommendation' => 'Preparar comunicación a copropietarios sobre posible ajuste de alícuotas',
                'probability' => 0.7,
                'potential_impact_uf' => 0, // No hay impacto directo en UF
                'expected_months' => 24,
                'status' => 'active',
                'expires_at' => now()->addMonths(6),
            ]);
        }

        // Actualizar proyecciones
        DB::table('aliquot_projections')
            ->updateOrInsert(
                ['copropiedad_id' => $event->copropiedad->id],
                [
                    'current_gini' => $event->aliquotContext['distribucion_actual']['gini'] ?? 0,
                    'revaluation_date' => $event->revaluationProjection['fecha'] ?? null,
                    'revaluation_variation' => $variation,
                    'affected_units_pct' => $event->revaluationProjection['afectadas'] ?? 0,
                    'updated_at' => now(),
                ]
            );
    }
}

// =========================================================
// LISTENER: Valorización Precesional
// =========================================================

/**
 * HandleValuationUpdated
 * 
 * Procesa actualizaciones de valorización precesional.
 */
class HandleValuationUpdated implements ShouldQueue
{
    use InteractsWithQueue;

    public function handle(PrecessionValuationUpdated $event): void
    {
        Log::info("PAE Listener: Procesando actualización valorización", [
            'copropiedad_id' => $event->copropiedad->id,
            'confidence' => $event->confidence,
        ]);

        $currentValue = $event->valuationContext['avaluo_fiscal']['valor_uf'] ?? 0;
        $value60m = $event->precessionValuation['horizonte_60m'] ?? 0;
        
        // Calcular apreciación proyectada
        $appreciation = $currentValue > 0 
            ? (($value60m - $currentValue) / $currentValue) * 100 
            : 0;

        // Alerta si apreciación negativa o muy alta
        if ($appreciation < -5 || $appreciation > 50) {
            $severity = $appreciation < -10 ? 'high' : 'medium';
            $type = $appreciation < 0 ? 'risk_threshold' : 'opportunity_detected';

            PrecessionAlert::create([
                'tenant_id' => $event->copropiedad->tenant_id,
                'copropiedad_id' => $event->copropiedad->id,
                'alert_type' => $type,
                'severity' => $severity,
                'precession_angle' => 'precession_90',
                'title' => $appreciation < 0 
                    ? 'Depreciación precesional proyectada' 
                    : 'Oportunidad de apreciación precesional detectada',
                'description' => sprintf(
                    'Valorización actual: %.0f UF. Proyección 60 meses: %.0f UF (%.1f%%). ' .
                    'Factores principales: %s. Confianza: %.0f%%.',
                    $currentValue,
                    $value60m,
                    $appreciation,
                    implode(', ', $event->precessionValuation['factores_principales'] ?? []),
                    $event->confidence * 100
                ),
                'recommendation' => $appreciation < 0 
                    ? 'Evaluar factores de riesgo y considerar estrategias de mitigación'
                    : 'Oportunidad de inversión identificada - evaluar con análisis detallado',
                'probability' => $event->confidence,
                'potential_impact_uf' => abs($value60m - $currentValue),
                'expected_months' => 60,
                'status' => 'active',
                'expires_at' => now()->addMonths(6),
            ]);

            // Notificar si es oportunidad significativa
            if ($appreciation > 30 && $event->confidence > 0.75) {
                $this->notifyInvestmentOpportunity($event, $appreciation);
            }
        }

        // Guardar valorización precesional
        DB::table('precession_valuations')
            ->updateOrInsert(
                ['copropiedad_id' => $event->copropiedad->id],
                [
                    'current_value_uf' => $currentValue,
                    'valuation_12m' => $event->precessionValuation['horizonte_12m'] ?? 0,
                    'valuation_24m' => $event->precessionValuation['horizonte_24m'] ?? 0,
                    'valuation_36m' => $event->precessionValuation['horizonte_36m'] ?? 0,
                    'valuation_60m' => $value60m,
                    'appreciation_60m_pct' => $appreciation,
                    'confidence' => $event->confidence,
                    'main_factors' => json_encode($event->precessionValuation['factores_principales'] ?? []),
                    'updated_at' => now(),
                ]
            );
    }

    protected function notifyInvestmentOpportunity(PrecessionValuationUpdated $event, float $appreciation): void
    {
        $users = User::where('tenant_id', $event->copropiedad->tenant_id)
            ->whereIn('role', ['admin', 'investor', 'asset_manager'])
            ->get();

        if ($users->isNotEmpty()) {
            Notification::send($users, new ValuationUpdateNotification($event, $appreciation));
        }
    }
}

// =========================================================
// LISTENER: Pronóstico de Arriendos
// =========================================================

/**
 * HandleRentalForecast
 * 
 * Procesa pronósticos de arriendo y métricas de inversión.
 */
class HandleRentalForecast implements ShouldQueue
{
    use InteractsWithQueue;

    public function handle(PrecessionRentalForecast $event): void
    {
        Log::info("PAE Listener: Procesando pronóstico arriendos", [
            'copropiedad_id' => $event->copropiedad->id,
            'active_rentals' => $event->rentalContext['arriendos_activos']['cantidad'] ?? 0,
        ]);

        $vacancyRate = $event->rentalContext['vacancia']['tasa_actual'] ?? 0;
        $grossYield = $event->investmentMetrics['gross_yield'] ?? 0;

        // Alerta si vacancia alta o yield bajo
        if ($vacancyRate > 15 || $grossYield < 4) {
            $issues = [];
            if ($vacancyRate > 15) $issues[] = sprintf('vacancia %.1f%%', $vacancyRate);
            if ($grossYield < 4) $issues[] = sprintf('yield %.1f%%', $grossYield);

            PrecessionAlert::create([
                'tenant_id' => $event->copropiedad->tenant_id,
                'copropiedad_id' => $event->copropiedad->id,
                'alert_type' => 'risk_threshold',
                'severity' => ($vacancyRate > 25 || $grossYield < 3) ? 'high' : 'medium',
                'precession_angle' => 'counter_180',
                'title' => 'Métricas de arriendo requieren atención',
                'description' => sprintf(
                    'Se detectaron indicadores que requieren revisión: %s. ' .
                    'Arriendo promedio: $%s. Proyección 12m: $%s.',
                    implode(', ', $issues),
                    number_format($event->rentalContext['arriendos_activos']['arriendo_promedio'] ?? 0, 0, ',', '.'),
                    number_format($event->rentalProjection['arriendo_12m'] ?? 0, 0, ',', '.')
                ),
                'recommendation' => $vacancyRate > 15 
                    ? 'Evaluar estrategia de comercialización y precios de arriendo'
                    : 'Revisar estructura de gastos para mejorar rentabilidad neta',
                'probability' => 0.85,
                'potential_impact_uf' => $this->estimateRentalImpact($event),
                'expected_months' => 12,
                'status' => 'active',
                'expires_at' => now()->addDays(45),
            ]);
        }

        // Guardar métricas de arriendo
        DB::table('rental_metrics')
            ->updateOrInsert(
                ['copropiedad_id' => $event->copropiedad->id],
                [
                    'active_rentals' => $event->rentalContext['arriendos_activos']['cantidad'] ?? 0,
                    'average_rental' => $event->rentalContext['arriendos_activos']['arriendo_promedio'] ?? 0,
                    'price_per_m2' => $event->rentalContext['precio_m2']['promedio'] ?? 0,
                    'vacancy_rate' => $vacancyRate,
                    'forecast_12m' => $event->rentalProjection['arriendo_12m'] ?? 0,
                    'forecast_36m' => $event->rentalProjection['arriendo_36m'] ?? 0,
                    'gross_yield' => $grossYield,
                    'net_yield' => $event->investmentMetrics['net_yield'] ?? 0,
                    'payback_years' => $event->investmentMetrics['payback_anos'] ?? 0,
                    'updated_at' => now(),
                ]
            );
    }

    protected function estimateRentalImpact(PrecessionRentalForecast $event): float
    {
        $monthlyLoss = ($event->rentalContext['vacancia']['tasa_actual'] ?? 0) / 100 
            * ($event->rentalContext['arriendos_activos']['arriendo_promedio'] ?? 0)
            * ($event->rentalContext['arriendos_activos']['cantidad'] ?? 0);
        
        $annualLoss = $monthlyLoss * 12;
        $ufValue = 37000;
        
        return $annualLoss / $ufValue;
    }
}

// =========================================================
// LISTENER: Análisis Programado Completado
// =========================================================

/**
 * HandleScheduledAnalysisCompleted
 * 
 * Procesa finalización de análisis programados y actualiza estadísticas.
 */
class HandleScheduledAnalysisCompleted
{
    public function handle(ScheduledAnalysisCompleted $event): void
    {
        Log::info("PAE Listener: Análisis programado completado", [
            'copropiedad_id' => $event->copropiedadId,
            'analysis_id' => $event->analysisId,
            'execution_time' => $event->executionTimeSeconds,
            'triggered_alerts' => $event->triggeredAlerts,
        ]);

        // Actualizar estadísticas
        DB::table('pae_statistics')->updateOrInsert(
            ['date' => now()->toDateString()],
            [
                DB::raw('analyses_completed = COALESCE(analyses_completed, 0) + 1'),
                DB::raw('alerts_triggered = COALESCE(alerts_triggered, 0) + ' . ($event->triggeredAlerts ? 1 : 0)),
                DB::raw('total_execution_time = COALESCE(total_execution_time, 0) + ' . $event->executionTimeSeconds),
                'updated_at' => now(),
            ]
        );
    }
}

// =========================================================
// LISTENER: Datos de Módulo Actualizados
// =========================================================

/**
 * HandleModuleDataUpdated
 * 
 * Procesa actualizaciones de datos de módulos y determina
 * si requieren re-análisis precesional.
 */
class HandleModuleDataUpdated
{
    public function handle(ModuleDataUpdated $event): void
    {
        if (!$event->isSignificantChange()) {
            return;
        }

        Log::debug("PAE Listener: Cambio significativo en módulo", [
            'module' => $event->moduleName,
            'entity' => $event->entityType,
            'change' => $event->changeType,
            'copropiedad_id' => $event->copropiedadId,
        ]);

        // Los cambios significativos ya disparan re-análisis via Observer
        // Este listener es para logging y estadísticas adicionales
        
        DB::table('pae_module_changes')->insert([
            'module_name' => $event->moduleName,
            'entity_type' => $event->entityType,
            'entity_id' => $event->entityId,
            'copropiedad_id' => $event->copropiedadId,
            'change_type' => $event->changeType,
            'changed_attributes' => json_encode($event->changedAttributes),
            'created_at' => now(),
        ]);
    }
}
