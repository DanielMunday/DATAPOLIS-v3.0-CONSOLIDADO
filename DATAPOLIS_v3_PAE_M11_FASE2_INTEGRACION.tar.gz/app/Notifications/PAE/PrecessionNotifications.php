<?php

namespace App\Notifications\PAE;

use App\Models\PAE\PrecessionAlert;
use App\Events\PAE\PrecessionTaxRiskUpdated;
use App\Events\PAE\PrecessionComplianceAlert;
use App\Events\PAE\PrecessionValuationUpdated;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\SlackMessage;
use Illuminate\Notifications\Notification;

/**
 * =========================================================
 * NOTIFICACIONES PAE M11
 * =========================================================
 * 
 * Notificaciones para alertas precesionales vía email, database y Slack.
 */

// =========================================================
// NOTIFICACIÓN: Riesgo Tributario
// =========================================================

/**
 * TaxRiskNotification
 * 
 * Notifica sobre riesgos tributarios detectados por el PAE.
 */
class TaxRiskNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(
        public PrecessionAlert $alert,
        public PrecessionTaxRiskUpdated $event
    ) {}

    public function via(object $notifiable): array
    {
        $channels = ['database'];
        
        // Email para severidad alta o crítica
        if (in_array($this->alert->severity, ['high', 'critical'])) {
            $channels[] = 'mail';
        }
        
        // Slack para críticos
        if ($this->alert->severity === 'critical' && config('services.slack.notifications_webhook')) {
            $channels[] = 'slack';
        }

        return $channels;
    }

    public function toMail(object $notifiable): MailMessage
    {
        $copropiedad = $this->event->copropiedad;
        
        return (new MailMessage)
            ->subject("⚠️ Alerta PAE: Riesgo Tributario - {$copropiedad->nombre}")
            ->greeting("Alerta de Riesgo Tributario")
            ->line("Se ha detectado un riesgo tributario elevado en la copropiedad **{$copropiedad->nombre}**.")
            ->line("**Detalles del análisis:**")
            ->line("- Score de riesgo: " . number_format($this->event->riskScore * 100, 1) . "%")
            ->line("- Carga proyectada 12 meses: " . number_format($this->event->projectedLoad['12m'] ?? 0, 0, ',', '.') . " UF")
            ->line("- Cumplimiento tributario: " . number_format($this->event->taxContext['metrics']['cumplimiento_global'] ?? 0, 1) . "%")
            ->line("**Recomendación:**")
            ->line($this->alert->recommendation)
            ->action('Ver Dashboard PAE', url("/pae/dashboard/{$copropiedad->id}"))
            ->line("Esta alerta fue generada por el Precession Analytics Engine (PAE M11).")
            ->salutation("DATAPOLIS - Sistema de Inteligencia Precesional");
    }

    public function toSlack(object $notifiable): SlackMessage
    {
        $copropiedad = $this->event->copropiedad;
        
        return (new SlackMessage)
            ->error()
            ->content("🚨 Alerta PAE: Riesgo Tributario Elevado")
            ->attachment(function ($attachment) use ($copropiedad) {
                $attachment
                    ->title("Copropiedad: {$copropiedad->nombre}")
                    ->fields([
                        'Score Riesgo' => number_format($this->event->riskScore * 100, 1) . '%',
                        'Carga 12m' => number_format($this->event->projectedLoad['12m'] ?? 0, 0) . ' UF',
                        'Cumplimiento' => number_format($this->event->taxContext['metrics']['cumplimiento_global'] ?? 0, 1) . '%',
                        'Severidad' => strtoupper($this->alert->severity),
                    ])
                    ->action('Ver Dashboard', url("/pae/dashboard/{$copropiedad->id}"));
            });
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'pae_tax_risk',
            'alert_id' => $this->alert->id,
            'copropiedad_id' => $this->event->copropiedad->id,
            'copropiedad_nombre' => $this->event->copropiedad->nombre,
            'severity' => $this->alert->severity,
            'risk_score' => $this->event->riskScore,
            'projected_load_12m' => $this->event->projectedLoad['12m'] ?? 0,
            'title' => $this->alert->title,
            'recommendation' => $this->alert->recommendation,
            'created_at' => now()->toIso8601String(),
        ];
    }
}

// =========================================================
// NOTIFICACIÓN: Alerta de Compliance
// =========================================================

/**
 * ComplianceAlertNotification
 * 
 * Notifica sobre brechas de cumplimiento normativo.
 */
class ComplianceAlertNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(
        public PrecessionAlert $alert,
        public PrecessionComplianceAlert $event
    ) {}

    public function via(object $notifiable): array
    {
        $channels = ['database', 'mail'];
        
        if ($this->alert->severity === 'critical' && config('services.slack.notifications_webhook')) {
            $channels[] = 'slack';
        }

        return $channels;
    }

    public function toMail(object $notifiable): MailMessage
    {
        $copropiedad = $this->event->copropiedad;
        $criticalGaps = count($this->event->complianceContext['brechas']['criticas'] ?? []);
        
        $mail = (new MailMessage)
            ->subject("🔴 Alerta PAE: Cumplimiento Normativo - {$copropiedad->nombre}")
            ->greeting("Alerta de Cumplimiento Normativo")
            ->line("Se han detectado brechas de cumplimiento en la copropiedad **{$copropiedad->nombre}**.");

        // Detalles según severidad
        $mail->line("**Estado de cumplimiento:**")
            ->line("- Score global: " . number_format($this->event->globalScore, 1) . "/100")
            ->line("- DS7-2025: " . ($this->event->complianceContext['ds7_2025']['nivel'] ?? 'pendiente'))
            ->line("- Ley 21.442: " . ($this->event->complianceContext['ley_21442']['estado'] ?? 'pendiente'))
            ->line("- Brechas detectadas: " . count($this->event->gaps) . " ({$criticalGaps} críticas)");

        // Listar brechas críticas
        if ($criticalGaps > 0) {
            $mail->line("")->line("**Brechas críticas:**");
            foreach ($this->event->complianceContext['brechas']['criticas'] as $brecha) {
                $mail->line("- " . ($brecha['accion_requerida'] ?? $brecha['requisito'] ?? 'Sin detalle'));
            }
        }

        $mail->line("")
            ->line("**Recomendación:**")
            ->line($this->alert->recommendation)
            ->action('Ver Detalles Compliance', url("/regtech/compliance/{$copropiedad->id}"))
            ->line("Atención: El incumplimiento normativo puede generar multas de hasta " . 
                   ($this->event->complianceContext['ley_21442']['multa_potencial'] ?? 50) . " UTM.");

        return $mail;
    }

    public function toSlack(object $notifiable): SlackMessage
    {
        $copropiedad = $this->event->copropiedad;
        
        return (new SlackMessage)
            ->error()
            ->content("🔴 Alerta PAE: Brechas de Cumplimiento Críticas")
            ->attachment(function ($attachment) use ($copropiedad) {
                $attachment
                    ->title("Copropiedad: {$copropiedad->nombre}")
                    ->fields([
                        'Score' => number_format($this->event->globalScore, 1) . '/100',
                        'DS7' => $this->event->complianceContext['ds7_2025']['nivel'] ?? 'N/A',
                        'Ley 21.442' => $this->event->complianceContext['ley_21442']['estado'] ?? 'N/A',
                        'Brechas' => count($this->event->gaps),
                    ])
                    ->color('danger')
                    ->action('Ver Compliance', url("/regtech/compliance/{$copropiedad->id}"));
            });
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'pae_compliance_alert',
            'alert_id' => $this->alert->id,
            'copropiedad_id' => $this->event->copropiedad->id,
            'copropiedad_nombre' => $this->event->copropiedad->nombre,
            'severity' => $this->alert->severity,
            'global_score' => $this->event->globalScore,
            'gaps_count' => count($this->event->gaps),
            'critical_gaps' => count($this->event->complianceContext['brechas']['criticas'] ?? []),
            'title' => $this->alert->title,
            'recommendation' => $this->alert->recommendation,
            'created_at' => now()->toIso8601String(),
        ];
    }
}

// =========================================================
// NOTIFICACIÓN: Actualización de Valorización
// =========================================================

/**
 * ValuationUpdateNotification
 * 
 * Notifica sobre oportunidades de inversión por valorización.
 */
class ValuationUpdateNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(
        public PrecessionValuationUpdated $event,
        public float $appreciation
    ) {}

    public function via(object $notifiable): array
    {
        return ['database', 'mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $copropiedad = $this->event->copropiedad;
        $currentValue = $this->event->valuationContext['avaluo_fiscal']['valor_uf'] ?? 0;
        $value60m = $this->event->precessionValuation['horizonte_60m'] ?? 0;
        
        return (new MailMessage)
            ->subject("📈 PAE: Oportunidad de Inversión - {$copropiedad->nombre}")
            ->greeting("Oportunidad de Inversión Detectada")
            ->line("El análisis precesional ha identificado una oportunidad significativa de apreciación.")
            ->line("")
            ->line("**Copropiedad:** {$copropiedad->nombre}")
            ->line("**Ubicación:** {$copropiedad->direccion}, {$copropiedad->comuna}")
            ->line("")
            ->line("**Análisis de Valorización:**")
            ->line("- Valor actual: " . number_format($currentValue, 0, ',', '.') . " UF")
            ->line("- Proyección 12 meses: " . number_format($this->event->precessionValuation['horizonte_12m'] ?? 0, 0, ',', '.') . " UF")
            ->line("- Proyección 60 meses: " . number_format($value60m, 0, ',', '.') . " UF")
            ->line("- **Apreciación esperada: " . number_format($this->appreciation, 1) . "%**")
            ->line("")
            ->line("**Factores precesionales identificados:**")
            ->line(implode(', ', $this->event->precessionValuation['factores_principales'] ?? []))
            ->line("")
            ->line("**Nivel de confianza:** " . number_format($this->event->confidence * 100, 0) . "%")
            ->action('Analizar Oportunidad', url("/pae/dashboard/{$copropiedad->id}"))
            ->line("Este análisis fue generado por el motor PAE basado en la teoría de precesión de Fuller.");
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'pae_investment_opportunity',
            'copropiedad_id' => $this->event->copropiedad->id,
            'copropiedad_nombre' => $this->event->copropiedad->nombre,
            'current_value_uf' => $this->event->valuationContext['avaluo_fiscal']['valor_uf'] ?? 0,
            'projected_value_60m' => $this->event->precessionValuation['horizonte_60m'] ?? 0,
            'appreciation_percent' => $this->appreciation,
            'confidence' => $this->event->confidence,
            'factors' => $this->event->precessionValuation['factores_principales'] ?? [],
            'created_at' => now()->toIso8601String(),
        ];
    }
}

// =========================================================
// NOTIFICACIÓN: Alerta de Alta Prioridad Genérica
// =========================================================

/**
 * HighPriorityAlertNotification
 * 
 * Notificación genérica para alertas de alta prioridad.
 */
class HighPriorityAlertNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(
        public PrecessionAlert $alert
    ) {}

    public function via(object $notifiable): array
    {
        $channels = ['database'];
        
        if (in_array($this->alert->severity, ['high', 'critical'])) {
            $channels[] = 'mail';
        }

        return $channels;
    }

    public function toMail(object $notifiable): MailMessage
    {
        $severityEmoji = match($this->alert->severity) {
            'critical' => '🚨',
            'high' => '⚠️',
            'medium' => '📊',
            default => 'ℹ️',
        };

        $mail = (new MailMessage)
            ->subject("{$severityEmoji} Alerta PAE: {$this->alert->title}")
            ->greeting("Alerta del Precession Analytics Engine")
            ->line($this->alert->description)
            ->line("")
            ->line("**Detalles:**")
            ->line("- Tipo: " . $this->getAlertTypeName())
            ->line("- Severidad: " . ucfirst($this->alert->severity))
            ->line("- Ángulo precesional: " . $this->getAngleName())
            ->line("- Probabilidad: " . number_format(($this->alert->probability ?? 0) * 100, 0) . "%");

        if ($this->alert->potential_impact_uf > 0) {
            $mail->line("- Impacto potencial: " . number_format($this->alert->potential_impact_uf, 0, ',', '.') . " UF");
        }

        if ($this->alert->expected_months) {
            $mail->line("- Horizonte: " . $this->alert->expected_months . " meses");
        }

        $mail->line("")
            ->line("**Recomendación:**")
            ->line($this->alert->recommendation ?? 'Revisar situación con equipo especializado');

        if ($this->alert->copropiedad_id) {
            $mail->action('Ver Dashboard', url("/pae/dashboard/{$this->alert->copropiedad_id}"));
        }

        return $mail;
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'pae_alert',
            'alert_id' => $this->alert->id,
            'alert_type' => $this->alert->alert_type,
            'severity' => $this->alert->severity,
            'title' => $this->alert->title,
            'description' => $this->alert->description,
            'recommendation' => $this->alert->recommendation,
            'copropiedad_id' => $this->alert->copropiedad_id,
            'potential_impact_uf' => $this->alert->potential_impact_uf,
            'probability' => $this->alert->probability,
            'precession_angle' => $this->alert->precession_angle,
            'created_at' => now()->toIso8601String(),
        ];
    }

    protected function getAlertTypeName(): string
    {
        return match($this->alert->alert_type) {
            'risk_threshold' => 'Umbral de Riesgo',
            'opportunity_detected' => 'Oportunidad Detectada',
            'trend_change' => 'Cambio de Tendencia',
            'anomaly_detected' => 'Anomalía Detectada',
            'deadline_approaching' => 'Plazo Próximo',
            'regulatory_impact' => 'Impacto Regulatorio',
            'market_shift' => 'Cambio de Mercado',
            default => $this->alert->alert_type,
        };
    }

    protected function getAngleName(): string
    {
        return match($this->alert->precession_angle) {
            'direct_0' => 'Directo (0°)',
            'induced_45' => 'Inducido (45°)',
            'precession_90' => 'Precesional (90°)',
            'systemic_135' => 'Sistémico (135°)',
            'counter_180' => 'Contra-Precesión (180°)',
            default => $this->alert->precession_angle ?? 'N/A',
        };
    }
}

// =========================================================
// NOTIFICACIÓN: Resumen Diario PAE
// =========================================================

/**
 * DailyPAESummaryNotification
 * 
 * Resumen diario de actividad del PAE.
 */
class DailyPAESummaryNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(
        public array $summary
    ) {}

    public function via(object $notifiable): array
    {
        return ['mail', 'database'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("📊 Resumen Diario PAE - " . now()->format('d/m/Y'))
            ->greeting("Resumen Diario del Precession Analytics Engine")
            ->line("**Actividad de las últimas 24 horas:**")
            ->line("")
            ->line("📈 **Análisis ejecutados:** " . ($this->summary['analyses_completed'] ?? 0))
            ->line("⚠️ **Alertas generadas:** " . ($this->summary['alerts_triggered'] ?? 0))
            ->line("🚨 **Alertas críticas:** " . ($this->summary['critical_alerts'] ?? 0))
            ->line("✅ **Alertas resueltas:** " . ($this->summary['alerts_resolved'] ?? 0))
            ->line("")
            ->line("**Top 3 Copropiedades por Riesgo:**")
            ->line($this->formatTopRisks())
            ->line("")
            ->line("**Top 3 Oportunidades Detectadas:**")
            ->line($this->formatTopOpportunities())
            ->action('Ver Dashboard PAE', url('/pae/dashboard'))
            ->line("Este resumen es generado automáticamente por DATAPOLIS PAE M11.");
    }

    protected function formatTopRisks(): string
    {
        $risks = $this->summary['top_risks'] ?? [];
        if (empty($risks)) return "Sin riesgos significativos detectados.";
        
        return collect($risks)
            ->map(fn($r, $i) => ($i + 1) . ". {$r['nombre']} - Score: {$r['risk_score']}")
            ->implode("\n");
    }

    protected function formatTopOpportunities(): string
    {
        $opportunities = $this->summary['top_opportunities'] ?? [];
        if (empty($opportunities)) return "Sin oportunidades destacadas.";
        
        return collect($opportunities)
            ->map(fn($o, $i) => ($i + 1) . ". {$o['nombre']} - Apreciación: {$o['appreciation']}%")
            ->implode("\n");
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'pae_daily_summary',
            'date' => now()->toDateString(),
            'summary' => $this->summary,
            'created_at' => now()->toIso8601String(),
        ];
    }
}
