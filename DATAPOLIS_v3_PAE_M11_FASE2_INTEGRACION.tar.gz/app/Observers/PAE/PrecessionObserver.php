<?php

namespace App\Observers\PAE;

use App\Models\PropTech\Copropiedad;
use App\Models\PropTech\Unidad;
use App\Models\PropTech\Arriendo;
use App\Models\FinTech\GastoComun;
use App\Models\FinTech\DeclaracionJurada;
use App\Models\FinTech\PagoPPM;
use App\Models\FinTech\Formulario29;
use App\Models\RegTech\ComplianceRecord;
use App\Models\RegTech\Alicuota;
use App\Models\GeoTech\Avaluo;
use App\Models\GeoTech\TransaccionCBR;
use App\Events\PAE\ModuleDataUpdated;
use App\Jobs\PAE\TriggerPrecessionAnalysis;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Model;

/**
 * PrecessionObserver
 * 
 * Observa cambios en modelos de módulos DATAPOLIS (M04-M16)
 * y dispara re-cálculo precesional cuando los cambios son significativos.
 * 
 * Módulos observados:
 * - M04 Tributario: DeclaracionJurada, PagoPPM, Formulario29
 * - M05 Gastos Comunes: GastoComun
 * - M06 Compliance: ComplianceRecord
 * - M07 Alícuotas: Alicuota, Unidad (prorrateo)
 * - M08 Valorización: Avaluo, TransaccionCBR
 * - M16 Arriendos: Arriendo
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx Sección 4.2
 */
class PrecessionObserver
{
    /**
     * Umbral mínimo de tiempo entre re-análisis (segundos)
     */
    protected const DEBOUNCE_SECONDS = 300; // 5 minutos

    /**
     * Cantidad mínima de cambios para trigger batch
     */
    protected const BATCH_THRESHOLD = 5;

    // =========================================================
    // COPROPIEDAD - Observador principal
    // =========================================================

    /**
     * Handle Copropiedad "created" event
     */
    public function copropiedadCreated(Copropiedad $copropiedad): void
    {
        $this->dispatchModuleUpdate('copropiedad', $copropiedad, 'created');
        
        // Programar análisis inicial después de 1 hora (dar tiempo a cargar datos)
        TriggerPrecessionAnalysis::dispatch($copropiedad->id, [
            'reason' => 'new_copropiedad',
            'priority' => 'low',
        ])->delay(now()->addHour());
        
        Log::info("PAE Observer: Nueva copropiedad {$copropiedad->id}, análisis programado");
    }

    /**
     * Handle Copropiedad "updated" event
     */
    public function copropiedadUpdated(Copropiedad $copropiedad): void
    {
        $significantFields = [
            'latitud', 'longitud', 'comuna', 'tipo',
            'superficie_total', 'unidades_count',
            'administracion_id', 'reglamento_inscrito',
        ];

        $changedAttributes = array_keys($copropiedad->getDirty());
        $hasSignificantChange = !empty(array_intersect($significantFields, $changedAttributes));

        if ($hasSignificantChange) {
            $this->dispatchModuleUpdate('copropiedad', $copropiedad, 'updated', $changedAttributes);
            $this->schedulePrecessionAnalysis($copropiedad);
        }
    }

    // =========================================================
    // M04 TRIBUTARIO
    // =========================================================

    /**
     * Handle DeclaracionJurada events
     */
    public function declaracionJuradaCreated($declaracion): void
    {
        $this->handleTributarioChange($declaracion, 'created', 'declaracion_jurada');
    }

    public function declaracionJuradaUpdated($declaracion): void
    {
        $significantFields = ['monto_informado', 'estado', 'fecha_presentacion'];
        $changedAttributes = array_keys($declaracion->getDirty());
        
        if (!empty(array_intersect($significantFields, $changedAttributes))) {
            $this->handleTributarioChange($declaracion, 'updated', 'declaracion_jurada', $changedAttributes);
        }
    }

    /**
     * Handle PagoPPM events
     */
    public function pagoPPMCreated($pago): void
    {
        $this->handleTributarioChange($pago, 'created', 'pago_ppm');
    }

    public function pagoPPMUpdated($pago): void
    {
        $significantFields = ['monto', 'estado', 'periodo'];
        $changedAttributes = array_keys($pago->getDirty());
        
        if (!empty(array_intersect($significantFields, $changedAttributes))) {
            $this->handleTributarioChange($pago, 'updated', 'pago_ppm', $changedAttributes);
        }
    }

    /**
     * Handle Formulario29 events
     */
    public function formulario29Created($f29): void
    {
        $this->handleTributarioChange($f29, 'created', 'formulario_29');
    }

    public function formulario29Updated($f29): void
    {
        $significantFields = ['debito_fiscal', 'credito_fiscal', 'saldo_a_pagar', 'estado'];
        $changedAttributes = array_keys($f29->getDirty());
        
        if (!empty(array_intersect($significantFields, $changedAttributes))) {
            $this->handleTributarioChange($f29, 'updated', 'formulario_29', $changedAttributes);
        }
    }

    protected function handleTributarioChange(Model $model, string $changeType, string $subType, array $changedAttributes = []): void
    {
        $copropiedadId = $model->copropiedad_id ?? $this->resolveCopropiedadId($model);
        
        if (!$copropiedadId) {
            return;
        }

        $this->dispatchModuleUpdate('tributario', $model, $changeType, $changedAttributes);
        
        $copropiedad = Copropiedad::find($copropiedadId);
        if ($copropiedad) {
            $this->schedulePrecessionAnalysis($copropiedad, [
                'reason' => "tributario_{$subType}_{$changeType}",
                'priority' => $changeType === 'created' ? 'medium' : 'low',
            ]);
        }

        Log::info("PAE Observer: Cambio tributario ({$subType}) en copropiedad {$copropiedadId}");
    }

    // =========================================================
    // M05 GASTOS COMUNES
    // =========================================================

    /**
     * Handle GastoComun events
     */
    public function gastoComunCreated($gasto): void
    {
        $this->handleGastoComunChange($gasto, 'created');
    }

    public function gastoComunUpdated($gasto): void
    {
        $significantFields = ['monto_total', 'estado', 'fecha'];
        $changedAttributes = array_keys($gasto->getDirty());
        
        if (!empty(array_intersect($significantFields, $changedAttributes))) {
            $this->handleGastoComunChange($gasto, 'updated', $changedAttributes);
        }
    }

    public function gastoComunDeleted($gasto): void
    {
        $this->handleGastoComunChange($gasto, 'deleted');
    }

    protected function handleGastoComunChange(Model $gasto, string $changeType, array $changedAttributes = []): void
    {
        $copropiedadId = $gasto->copropiedad_id;
        
        if (!$copropiedadId) {
            return;
        }

        $this->dispatchModuleUpdate('gastos_comunes', $gasto, $changeType, $changedAttributes);

        // Solo re-analizar si es un gasto significativo (> 10% del promedio)
        if ($changeType === 'created' && $this->isSignificantExpenseChange($gasto)) {
            $copropiedad = Copropiedad::find($copropiedadId);
            if ($copropiedad) {
                $this->schedulePrecessionAnalysis($copropiedad, [
                    'reason' => "gasto_comun_{$changeType}",
                    'priority' => 'low',
                ]);
            }
        }

        Log::info("PAE Observer: Cambio gasto común en copropiedad {$copropiedadId}");
    }

    protected function isSignificantExpenseChange($gasto): bool
    {
        // Obtener promedio histórico
        $promedio = \DB::table('gastos_comunes')
            ->where('copropiedad_id', $gasto->copropiedad_id)
            ->where('id', '!=', $gasto->id)
            ->avg('monto_total');

        if (!$promedio) {
            return true; // Primer gasto, siempre significativo
        }

        $variacion = abs($gasto->monto_total - $promedio) / $promedio;
        
        return $variacion > 0.1; // Más del 10% de variación
    }

    // =========================================================
    // M06 COMPLIANCE DS7-2025
    // =========================================================

    /**
     * Handle ComplianceRecord events
     */
    public function complianceRecordCreated($record): void
    {
        $this->handleComplianceChange($record, 'created');
    }

    public function complianceRecordUpdated($record): void
    {
        $significantFields = ['score', 'estado', 'brechas', 'nivel'];
        $changedAttributes = array_keys($record->getDirty());
        
        if (!empty(array_intersect($significantFields, $changedAttributes))) {
            $this->handleComplianceChange($record, 'updated', $changedAttributes);
        }
    }

    protected function handleComplianceChange(Model $record, string $changeType, array $changedAttributes = []): void
    {
        $copropiedadId = $record->copropiedad_id;
        
        if (!$copropiedadId) {
            return;
        }

        $this->dispatchModuleUpdate('compliance', $record, $changeType, $changedAttributes);

        // Compliance siempre dispara análisis (alto impacto)
        $copropiedad = Copropiedad::find($copropiedadId);
        if ($copropiedad) {
            $this->schedulePrecessionAnalysis($copropiedad, [
                'reason' => "compliance_{$changeType}",
                'priority' => 'high',
            ]);
        }

        Log::info("PAE Observer: Cambio compliance en copropiedad {$copropiedadId}");
    }

    // =========================================================
    // M07 ALÍCUOTAS
    // =========================================================

    /**
     * Handle Alicuota events
     */
    public function alicuotaUpdated($alicuota): void
    {
        $significantFields = ['prorrateo', 'ponderador', 'avaluo'];
        $changedAttributes = array_keys($alicuota->getDirty());
        
        if (!empty(array_intersect($significantFields, $changedAttributes))) {
            $this->handleAlicuotaChange($alicuota, 'updated', $changedAttributes);
        }
    }

    /**
     * Handle Unidad prorrateo changes
     */
    public function unidadUpdated(Unidad $unidad): void
    {
        $significantFields = ['prorrateo', 'superficie', 'avaluo_fiscal'];
        $changedAttributes = array_keys($unidad->getDirty());
        
        if (!empty(array_intersect($significantFields, $changedAttributes))) {
            $this->handleAlicuotaChange($unidad, 'updated', $changedAttributes);
        }
    }

    protected function handleAlicuotaChange(Model $model, string $changeType, array $changedAttributes = []): void
    {
        $copropiedadId = $model->copropiedad_id ?? $model->copropiedad?->id;
        
        if (!$copropiedadId) {
            return;
        }

        $this->dispatchModuleUpdate('alicuotas', $model, $changeType, $changedAttributes);

        $copropiedad = Copropiedad::find($copropiedadId);
        if ($copropiedad) {
            $this->schedulePrecessionAnalysis($copropiedad, [
                'reason' => 'alicuota_change',
                'priority' => 'medium',
            ]);
        }

        Log::info("PAE Observer: Cambio alícuota en copropiedad {$copropiedadId}");
    }

    // =========================================================
    // M08 VALORIZACIÓN
    // =========================================================

    /**
     * Handle Avaluo events
     */
    public function avaluoCreated($avaluo): void
    {
        $this->handleValorizacionChange($avaluo, 'created', 'avaluo');
    }

    public function avaluoUpdated($avaluo): void
    {
        $significantFields = ['valor', 'valor_m2', 'fecha'];
        $changedAttributes = array_keys($avaluo->getDirty());
        
        if (!empty(array_intersect($significantFields, $changedAttributes))) {
            $this->handleValorizacionChange($avaluo, 'updated', 'avaluo', $changedAttributes);
        }
    }

    /**
     * Handle TransaccionCBR events (transacciones en zona)
     */
    public function transaccionCBRCreated($transaccion): void
    {
        $this->handleValorizacionChange($transaccion, 'created', 'transaccion_cbr');
    }

    protected function handleValorizacionChange(Model $model, string $changeType, string $subType, array $changedAttributes = []): void
    {
        $copropiedadId = $model->copropiedad_id ?? $this->resolveCopropiedadFromLocation($model);
        
        if (!$copropiedadId) {
            // Para transacciones CBR, buscar copropiedades afectadas por ubicación
            if ($subType === 'transaccion_cbr') {
                $this->triggerZoneAnalysis($model);
            }
            return;
        }

        $this->dispatchModuleUpdate('valorizacion', $model, $changeType, $changedAttributes);

        $copropiedad = Copropiedad::find($copropiedadId);
        if ($copropiedad) {
            $this->schedulePrecessionAnalysis($copropiedad, [
                'reason' => "valorizacion_{$subType}_{$changeType}",
                'priority' => $subType === 'avaluo' ? 'high' : 'medium',
            ]);
        }

        Log::info("PAE Observer: Cambio valorización ({$subType}) en copropiedad {$copropiedadId}");
    }

    /**
     * Dispara análisis para todas las copropiedades en zona afectada
     */
    protected function triggerZoneAnalysis(Model $transaccion): void
    {
        if (!isset($transaccion->latitud) || !isset($transaccion->longitud)) {
            return;
        }

        // Buscar copropiedades en radio de 1km
        $copropiedades = Copropiedad::whereRaw("
            ST_DWithin(
                ST_SetSRID(ST_MakePoint(longitud, latitud), 4326)::geography,
                ST_SetSRID(ST_MakePoint(?, ?), 4326)::geography,
                1000
            )
        ", [$transaccion->longitud, $transaccion->latitud])
        ->limit(10)
        ->get();

        foreach ($copropiedades as $copropiedad) {
            TriggerPrecessionAnalysis::dispatch($copropiedad->id, [
                'reason' => 'zone_transaction_cbr',
                'priority' => 'low',
                'transaction_id' => $transaccion->id,
            ])->delay(now()->addMinutes(30));
        }

        Log::info("PAE Observer: Transacción CBR disparó análisis en {$copropiedades->count()} copropiedades");
    }

    // =========================================================
    // M16 ARRIENDOS
    // =========================================================

    /**
     * Handle Arriendo events
     */
    public function arriendoCreated(Arriendo $arriendo): void
    {
        $this->handleArriendoChange($arriendo, 'created');
    }

    public function arriendoUpdated(Arriendo $arriendo): void
    {
        $significantFields = ['monto_mensual', 'estado', 'fecha_inicio', 'fecha_termino'];
        $changedAttributes = array_keys($arriendo->getDirty());
        
        if (!empty(array_intersect($significantFields, $changedAttributes))) {
            $this->handleArriendoChange($arriendo, 'updated', $changedAttributes);
        }
    }

    public function arriendoDeleted(Arriendo $arriendo): void
    {
        $this->handleArriendoChange($arriendo, 'deleted');
    }

    protected function handleArriendoChange(Arriendo $arriendo, string $changeType, array $changedAttributes = []): void
    {
        $copropiedadId = $arriendo->unidad?->copropiedad_id;
        
        if (!$copropiedadId) {
            return;
        }

        $this->dispatchModuleUpdate('arriendos', $arriendo, $changeType, $changedAttributes);

        // Arriendos con cambio de monto o estado siempre disparan análisis
        if (in_array($changeType, ['created', 'deleted']) || 
            in_array('monto_mensual', $changedAttributes) || 
            in_array('estado', $changedAttributes)) {
            
            $copropiedad = Copropiedad::find($copropiedadId);
            if ($copropiedad) {
                $this->schedulePrecessionAnalysis($copropiedad, [
                    'reason' => "arriendo_{$changeType}",
                    'priority' => 'medium',
                ]);
            }
        }

        Log::info("PAE Observer: Cambio arriendo en copropiedad {$copropiedadId}");
    }

    // =========================================================
    // HELPERS
    // =========================================================

    /**
     * Despacha evento de actualización de módulo
     */
    protected function dispatchModuleUpdate(
        string $moduleName, 
        Model $model, 
        string $changeType, 
        array $changedAttributes = []
    ): void {
        $copropiedadId = $this->resolveCopropiedadId($model);

        event(new ModuleDataUpdated(
            moduleName: $moduleName,
            entityType: class_basename($model),
            entityId: $model->getKey(),
            copropiedadId: $copropiedadId,
            changeType: $changeType,
            changedAttributes: $changedAttributes
        ));
    }

    /**
     * Programa análisis precesional con debounce
     */
    protected function schedulePrecessionAnalysis(Copropiedad $copropiedad, array $options = []): void
    {
        $cacheKey = "pae:pending_analysis:{$copropiedad->id}";
        $pendingAnalysis = \Cache::get($cacheKey);

        if ($pendingAnalysis) {
            // Ya hay análisis pendiente, incrementar contador
            $pendingAnalysis['changes_count']++;
            $pendingAnalysis['reasons'][] = $options['reason'] ?? 'unknown';
            
            // Si supera threshold, priorizar
            if ($pendingAnalysis['changes_count'] >= self::BATCH_THRESHOLD) {
                $options['priority'] = 'high';
            }
            
            \Cache::put($cacheKey, $pendingAnalysis, self::DEBOUNCE_SECONDS);
            return;
        }

        // Nuevo análisis pendiente
        \Cache::put($cacheKey, [
            'copropiedad_id' => $copropiedad->id,
            'scheduled_at' => now()->toIso8601String(),
            'changes_count' => 1,
            'reasons' => [$options['reason'] ?? 'unknown'],
        ], self::DEBOUNCE_SECONDS);

        // Despachar job con delay (debounce)
        $delay = match($options['priority'] ?? 'low') {
            'high' => 60,      // 1 minuto
            'medium' => 300,   // 5 minutos
            'low' => 900,      // 15 minutos
            default => 600,
        };

        TriggerPrecessionAnalysis::dispatch($copropiedad->id, $options)
            ->delay(now()->addSeconds($delay));

        Log::info("PAE Observer: Análisis programado para copropiedad {$copropiedad->id} en {$delay}s");
    }

    /**
     * Resuelve ID de copropiedad desde modelo relacionado
     */
    protected function resolveCopropiedadId(Model $model): ?int
    {
        // Directo
        if (isset($model->copropiedad_id)) {
            return $model->copropiedad_id;
        }

        // Via unidad
        if (method_exists($model, 'unidad') && $model->unidad) {
            return $model->unidad->copropiedad_id;
        }

        // Via relación copropiedad
        if (method_exists($model, 'copropiedad') && $model->copropiedad) {
            return $model->copropiedad->id;
        }

        return null;
    }

    /**
     * Resuelve copropiedad desde ubicación geográfica
     */
    protected function resolveCopropiedadFromLocation(Model $model): ?int
    {
        if (!isset($model->latitud) || !isset($model->longitud)) {
            return null;
        }

        $copropiedad = Copropiedad::whereRaw("
            ST_DWithin(
                ST_SetSRID(ST_MakePoint(longitud, latitud), 4326)::geography,
                ST_SetSRID(ST_MakePoint(?, ?), 4326)::geography,
                100
            )
        ", [$model->longitud, $model->latitud])
        ->first();

        return $copropiedad?->id;
    }
}
