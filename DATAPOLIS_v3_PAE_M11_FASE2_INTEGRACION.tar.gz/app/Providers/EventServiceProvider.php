<?php

namespace App\Providers;

use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

/**
 * EventServiceProvider
 * 
 * Registra eventos y listeners del sistema DATAPOLIS.
 * Incluye eventos PAE M11 para integración con módulos.
 */
class EventServiceProvider extends ServiceProvider
{
    /**
     * The event to listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        // =========================================================
        // AUTH EVENTS
        // =========================================================
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],

        // =========================================================
        // PAE M11 - EVENTOS CORE
        // =========================================================
        \App\Events\PrecessionAnalysisCompleted::class => [
            \App\Listeners\PrecessionAnalysisCompletedListener::class,
        ],

        \App\Events\PrecessionAlertTriggered::class => [
            \App\Listeners\PrecessionAlertTriggeredListener::class,
        ],

        // =========================================================
        // PAE M11 - EVENTOS DE INTEGRACIÓN
        // =========================================================
        
        // M04 Tributario
        \App\Events\PAE\PrecessionTaxRiskUpdated::class => [
            \App\Listeners\PAE\HandleTaxRiskUpdated::class,
        ],

        // M05 Gastos Comunes
        \App\Events\PAE\PrecessionExpenseForecast::class => [
            \App\Listeners\PAE\HandleExpenseForecast::class,
        ],

        // M06 Compliance
        \App\Events\PAE\PrecessionComplianceAlert::class => [
            \App\Listeners\PAE\HandleComplianceAlert::class,
        ],

        // M07 Alícuotas
        \App\Events\PAE\PrecessionAliquotProjection::class => [
            \App\Listeners\PAE\HandleAliquotProjection::class,
        ],

        // M08 Valorización
        \App\Events\PAE\PrecessionValuationUpdated::class => [
            \App\Listeners\PAE\HandleValuationUpdated::class,
        ],

        // M16 Arriendos
        \App\Events\PAE\PrecessionRentalForecast::class => [
            \App\Listeners\PAE\HandleRentalForecast::class,
        ],

        // Eventos internos
        \App\Events\PAE\ModuleDataUpdated::class => [
            \App\Listeners\PAE\HandleModuleDataUpdated::class,
        ],

        \App\Events\PAE\ScheduledAnalysisCompleted::class => [
            \App\Listeners\PAE\HandleScheduledAnalysisCompleted::class,
        ],
    ];

    /**
     * The model observers for your application.
     *
     * @var array<string, string|array<int, string>>
     */
    protected $observers = [
        // PAE Observers para modelos de módulos integrados
        // Se registran en boot() para control más fino
    ];

    /**
     * Register any events for your application.
     */
    public function boot(): void
    {
        // =========================================================
        // REGISTRAR OBSERVERS PAE
        // =========================================================
        $this->registerPAEObservers();
    }

    /**
     * Registra observers del PAE para modelos de módulos integrados
     */
    protected function registerPAEObservers(): void
    {
        $observer = \App\Observers\PAE\PrecessionObserver::class;

        // M01 PropTech Core
        if (class_exists(\App\Models\PropTech\Copropiedad::class)) {
            \App\Models\PropTech\Copropiedad::observe($observer);
        }

        if (class_exists(\App\Models\PropTech\Unidad::class)) {
            \App\Models\PropTech\Unidad::observe($observer);
        }

        // M04 Tributario
        if (class_exists(\App\Models\FinTech\DeclaracionJurada::class)) {
            \App\Models\FinTech\DeclaracionJurada::observe($observer);
        }

        if (class_exists(\App\Models\FinTech\PagoPPM::class)) {
            \App\Models\FinTech\PagoPPM::observe($observer);
        }

        if (class_exists(\App\Models\FinTech\Formulario29::class)) {
            \App\Models\FinTech\Formulario29::observe($observer);
        }

        // M05 Gastos Comunes
        if (class_exists(\App\Models\FinTech\GastoComun::class)) {
            \App\Models\FinTech\GastoComun::observe($observer);
        }

        // M06 Compliance
        if (class_exists(\App\Models\RegTech\ComplianceRecord::class)) {
            \App\Models\RegTech\ComplianceRecord::observe($observer);
        }

        // M07 Alícuotas
        if (class_exists(\App\Models\RegTech\Alicuota::class)) {
            \App\Models\RegTech\Alicuota::observe($observer);
        }

        // M08 Valorización
        if (class_exists(\App\Models\GeoTech\Avaluo::class)) {
            \App\Models\GeoTech\Avaluo::observe($observer);
        }

        if (class_exists(\App\Models\GeoTech\TransaccionCBR::class)) {
            \App\Models\GeoTech\TransaccionCBR::observe($observer);
        }

        // M16 Arriendos
        if (class_exists(\App\Models\PropTech\Arriendo::class)) {
            \App\Models\PropTech\Arriendo::observe($observer);
        }
    }

    /**
     * Determine if events and listeners should be automatically discovered.
     */
    public function shouldDiscoverEvents(): bool
    {
        return false;
    }
}
