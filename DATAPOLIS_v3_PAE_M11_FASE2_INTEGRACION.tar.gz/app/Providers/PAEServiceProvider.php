<?php

namespace App\Providers;

use App\Services\PrecessionService;
use App\Services\PAE\PrecessionContextBuilder;
use App\Observers\PAE\PrecessionObserver;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;
use Illuminate\Console\Scheduling\Schedule;

/**
 * PAEServiceProvider
 * 
 * Registra servicios, bindings y configuraciones del módulo
 * Precession Analytics Engine (PAE) M11.
 */
class PAEServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        // Registrar PrecessionService como singleton
        $this->app->singleton(PrecessionService::class, function ($app) {
            return new PrecessionService();
        });

        // Registrar PrecessionContextBuilder como singleton
        $this->app->singleton(PrecessionContextBuilder::class, function ($app) {
            return new PrecessionContextBuilder();
        });

        // Alias para facilitar inyección
        $this->app->alias(PrecessionService::class, 'pae');
        $this->app->alias(PrecessionContextBuilder::class, 'pae.context');

        // Merge configuración
        $this->mergeConfigFrom(
            __DIR__ . '/../../config/pae.php',
            'pae'
        );
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        // Publicar configuración
        $this->publishes([
            __DIR__ . '/../../config/pae.php' => config_path('pae.php'),
        ], 'pae-config');

        // Publicar migraciones
        $this->publishes([
            __DIR__ . '/../../database/migrations/2024_01_01_000060_create_pae_precession_tables.php' 
                => database_path('migrations/2024_01_01_000060_create_pae_precession_tables.php'),
            __DIR__ . '/../../database/migrations/2024_01_01_000061_create_pae_integration_tables.php' 
                => database_path('migrations/2024_01_01_000061_create_pae_integration_tables.php'),
        ], 'pae-migrations');

        // Cargar rutas
        $this->loadRoutesFrom(__DIR__ . '/../../routes/pae.php');

        // Registrar comandos
        if ($this->app->runningInConsole()) {
            $this->commands([
                \App\Console\Commands\PAE\AnalyzeCopropiedadCommand::class,
                \App\Console\Commands\PAE\PAEStatsCommand::class,
                \App\Console\Commands\PAE\ManageAlertsCommand::class,
                \App\Console\Commands\PAE\RebuildOntologyCommand::class,
                \App\Console\Commands\PAE\ExportAnalysisCommand::class,
            ]);
        }

        // Registrar observers si los modelos existen
        $this->registerObservers();

        // Registrar macros útiles
        $this->registerMacros();
    }

    /**
     * Registra observers del PAE
     */
    protected function registerObservers(): void
    {
        $observer = PrecessionObserver::class;
        $models = [
            \App\Models\PropTech\Copropiedad::class,
            \App\Models\PropTech\Unidad::class,
            \App\Models\PropTech\Arriendo::class,
        ];

        foreach ($models as $model) {
            if (class_exists($model)) {
                $model::observe($observer);
            }
        }
    }

    /**
     * Registra macros útiles para el PAE
     */
    protected function registerMacros(): void
    {
        // Macro para Collection: calcular Gini
        \Illuminate\Support\Collection::macro('gini', function () {
            $values = $this->sort()->values();
            $n = $values->count();
            
            if ($n === 0) return 0;
            
            $sum = $values->sum();
            if ($sum === 0) return 0;
            
            $gini = 0;
            foreach ($values as $i => $value) {
                $gini += (2 * ($i + 1) - $n - 1) * $value;
            }
            
            return abs($gini / ($n * $sum));
        });

        // Macro para Collection: calcular tendencia lineal
        \Illuminate\Support\Collection::macro('trend', function () {
            $values = $this->values();
            $n = $values->count();
            
            if ($n < 2) {
                return ['slope' => 0, 'direction' => 'stable'];
            }
            
            $x = range(1, $n);
            $sumX = array_sum($x);
            $sumY = $values->sum();
            $sumXY = 0;
            $sumX2 = 0;
            
            for ($i = 0; $i < $n; $i++) {
                $sumXY += $x[$i] * $values[$i];
                $sumX2 += $x[$i] * $x[$i];
            }
            
            $slope = ($n * $sumXY - $sumX * $sumY) / ($n * $sumX2 - $sumX * $sumX);
            
            $direction = match(true) {
                $slope > 0.01 => 'increasing',
                $slope < -0.01 => 'decreasing',
                default => 'stable',
            };
            
            return ['slope' => $slope, 'direction' => $direction];
        });
    }

    /**
     * Get the services provided by the provider.
     */
    public function provides(): array
    {
        return [
            PrecessionService::class,
            PrecessionContextBuilder::class,
            'pae',
            'pae.context',
        ];
    }
}
