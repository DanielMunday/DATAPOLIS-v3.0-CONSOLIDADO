<?php

namespace App\Services\PAE;

use App\Models\PropTech\Copropiedad;
use App\Models\PropTech\Unidad;
use App\Models\PropTech\Arriendo;
use App\Models\PAE\PrecessionAnalysis;
use App\Models\PAE\PrecessionAlert;
use App\Events\PrecessionTaxRiskUpdated;
use App\Events\PrecessionExpenseForecast;
use App\Events\PrecessionComplianceAlert;
use App\Events\PrecessionAliquotProjection;
use App\Events\PrecessionValuationUpdated;
use App\Events\PrecessionRentalForecast;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Collection;
use Carbon\Carbon;

/**
 * PrecessionContextBuilder - Construcción de contextos precesionales
 * 
 * Integra datos de módulos DATAPOLIS existentes (M04-M16) para
 * alimentar el motor PAE con contexto enriquecido.
 * 
 * Módulos integrados:
 * - M04 Tributario: DJ 1879, DJ 1907, PPM, IVA, F29
 * - M05 Gastos Comunes: histórico, tendencia, estacionalidad
 * - M06 Compliance DS7-2025: score, Ley 21.442, brechas
 * - M07 Alícuotas: distribución, ponderadores, avalúos
 * - M08 Valorización: avalúo fiscal, CBR, arriendos
 * - M16 Arriendos: precio/m², vacancia, tendencia
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx Sección 4.2
 */
class PrecessionContextBuilder
{
    /**
     * Cache TTL para contextos calculados (minutos)
     */
    protected const CONTEXT_CACHE_TTL = 30;

    // =========================================================
    // M04 TRIBUTARIO: DJ 1879, DJ 1907, PPM, IVA, F29
    // =========================================================

    /**
     * Construye contexto tributario para análisis precesional
     * 
     * Extrae datos de declaraciones juradas, PPM, IVA y F29
     * para evaluar riesgo tributario y proyectar carga futura.
     * 
     * @param Copropiedad $copropiedad
     * @return array Contexto tributario normalizado
     */
    public function buildTaxContext(Copropiedad $copropiedad): array
    {
        $cacheKey = "pae:tax_context:{$copropiedad->id}";
        
        return Cache::remember($cacheKey, self::CONTEXT_CACHE_TTL, function () use ($copropiedad) {
            // Obtener declaraciones juradas históricas
            $dj1879 = $this->getDJ1879History($copropiedad);
            $dj1907 = $this->getDJ1907History($copropiedad);
            
            // Obtener PPM e IVA si aplica (arriendos con antenas, etc.)
            $ppm = $this->getPPMHistory($copropiedad);
            $f29 = $this->getF29History($copropiedad);
            
            // Calcular métricas tributarias
            $taxMetrics = $this->calculateTaxMetrics($copropiedad, $dj1879, $dj1907, $ppm);
            
            return [
                'dj_1879' => [
                    'ultimo_periodo' => $dj1879['ultimo_periodo'] ?? null,
                    'monto_informado' => $dj1879['monto_total'] ?? 0,
                    'cantidad_informantes' => $dj1879['count'] ?? 0,
                    'cumplimiento' => $dj1879['cumplimiento'] ?? 'pendiente',
                    'historico_3_anos' => $dj1879['historico'] ?? [],
                ],
                'dj_1907' => [
                    'ultimo_periodo' => $dj1907['ultimo_periodo'] ?? null,
                    'rentas_informadas' => $dj1907['rentas'] ?? 0,
                    'retenciones' => $dj1907['retenciones'] ?? 0,
                    'cumplimiento' => $dj1907['cumplimiento'] ?? 'pendiente',
                ],
                'ppm' => [
                    'tasa_vigente' => $ppm['tasa'] ?? 0,
                    'base_imponible_mensual' => $ppm['base_mensual'] ?? 0,
                    'pagos_acumulados_ano' => $ppm['acumulado_ano'] ?? 0,
                    'tendencia_12m' => $ppm['tendencia'] ?? 0,
                ],
                'iva' => [
                    'aplica' => $f29['aplica_iva'] ?? false,
                    'debito_fiscal_mensual' => $f29['debito_mensual'] ?? 0,
                    'credito_fiscal_mensual' => $f29['credito_mensual'] ?? 0,
                    'saldo_promedio' => $f29['saldo_promedio'] ?? 0,
                ],
                'f29' => [
                    'ultimo_periodo' => $f29['ultimo_periodo'] ?? null,
                    'cumplimiento_12m' => $f29['cumplimiento_rate'] ?? 100,
                    'mora_historica' => $f29['mora_count'] ?? 0,
                ],
                'metrics' => $taxMetrics,
                'risk_score' => $this->calculateTaxRiskScore($taxMetrics),
                'projected_load_12m' => $this->projectTaxLoad($copropiedad, 12),
                'projected_load_36m' => $this->projectTaxLoad($copropiedad, 36),
            ];
        });
    }

    /**
     * Obtiene historial de DJ 1879 (arriendos informados)
     */
    protected function getDJ1879History(Copropiedad $copropiedad): array
    {
        $arriendos = $copropiedad->unidades()
            ->with(['arriendos' => fn($q) => $q->where('estado', 'activo')])
            ->get()
            ->flatMap(fn($u) => $u->arriendos);

        if ($arriendos->isEmpty()) {
            return ['cumplimiento' => 'no_aplica'];
        }

        // Simular consulta a tabla de declaraciones
        $declaraciones = DB::table('declaraciones_juradas')
            ->where('copropiedad_id', $copropiedad->id)
            ->where('tipo', 'DJ1879')
            ->orderByDesc('periodo')
            ->limit(3)
            ->get();

        $ultimaDeclaracion = $declaraciones->first();

        return [
            'ultimo_periodo' => $ultimaDeclaracion?->periodo,
            'monto_total' => $arriendos->sum('monto_mensual') * 12,
            'count' => $arriendos->count(),
            'cumplimiento' => $ultimaDeclaracion ? 'presentada' : 'pendiente',
            'historico' => $declaraciones->map(fn($d) => [
                'periodo' => $d->periodo,
                'monto' => $d->monto_informado,
                'fecha_presentacion' => $d->fecha_presentacion,
            ])->toArray(),
        ];
    }

    /**
     * Obtiene historial de DJ 1907 (retenciones)
     */
    protected function getDJ1907History(Copropiedad $copropiedad): array
    {
        $declaraciones = DB::table('declaraciones_juradas')
            ->where('copropiedad_id', $copropiedad->id)
            ->where('tipo', 'DJ1907')
            ->orderByDesc('periodo')
            ->limit(3)
            ->get();

        $ultima = $declaraciones->first();

        return [
            'ultimo_periodo' => $ultima?->periodo,
            'rentas' => $ultima?->monto_rentas ?? 0,
            'retenciones' => $ultima?->monto_retenciones ?? 0,
            'cumplimiento' => $ultima ? 'presentada' : 'pendiente',
        ];
    }

    /**
     * Obtiene historial de PPM
     */
    protected function getPPMHistory(Copropiedad $copropiedad): array
    {
        // Verificar si tiene ingresos gravados (ej: antenas telecomunicaciones)
        $ingresosGravados = DB::table('ingresos_copropiedad')
            ->where('copropiedad_id', $copropiedad->id)
            ->where('gravado_renta', true)
            ->sum('monto_mensual');

        if ($ingresosGravados == 0) {
            return ['tasa' => 0, 'aplica' => false];
        }

        $pagos = DB::table('pagos_ppm')
            ->where('copropiedad_id', $copropiedad->id)
            ->whereYear('periodo', now()->year)
            ->get();

        $tendencia = DB::table('pagos_ppm')
            ->where('copropiedad_id', $copropiedad->id)
            ->where('periodo', '>=', now()->subMonths(12))
            ->selectRaw('AVG(monto) as promedio, 
                         (MAX(monto) - MIN(monto)) / NULLIF(AVG(monto), 0) * 100 as variacion')
            ->first();

        return [
            'tasa' => 0.03, // 3% tasa PPM estándar
            'base_mensual' => $ingresosGravados,
            'acumulado_ano' => $pagos->sum('monto'),
            'tendencia' => $tendencia->variacion ?? 0,
            'aplica' => true,
        ];
    }

    /**
     * Obtiene historial de F29
     */
    protected function getF29History(Copropiedad $copropiedad): array
    {
        $f29 = DB::table('formularios_29')
            ->where('copropiedad_id', $copropiedad->id)
            ->orderByDesc('periodo')
            ->limit(12)
            ->get();

        if ($f29->isEmpty()) {
            return ['aplica_iva' => false];
        }

        $enMora = $f29->filter(fn($f) => $f->estado === 'mora')->count();
        $ultimo = $f29->first();

        return [
            'aplica_iva' => true,
            'ultimo_periodo' => $ultimo->periodo,
            'debito_mensual' => $ultimo->debito_fiscal ?? 0,
            'credito_mensual' => $ultimo->credito_fiscal ?? 0,
            'saldo_promedio' => $f29->avg('saldo_a_pagar'),
            'cumplimiento_rate' => (12 - $enMora) / 12 * 100,
            'mora_count' => $enMora,
        ];
    }

    /**
     * Calcula métricas tributarias agregadas
     */
    protected function calculateTaxMetrics(Copropiedad $copropiedad, array $dj1879, array $dj1907, array $ppm): array
    {
        return [
            'carga_anual_estimada' => ($ppm['base_mensual'] ?? 0) * 12 * ($ppm['tasa'] ?? 0.03),
            'cumplimiento_global' => $this->calculateGlobalCompliance($dj1879, $dj1907, $ppm),
            'riesgo_fiscalizacion' => $this->estimateFiscalizationRisk($copropiedad),
            'ahorro_potencial' => $this->calculatePotentialSavings($copropiedad),
        ];
    }

    /**
     * Calcula score de riesgo tributario (0-1)
     */
    protected function calculateTaxRiskScore(array $metrics): float
    {
        $score = 0.5; // Base

        // Penalizar por bajo cumplimiento
        $cumplimiento = $metrics['cumplimiento_global'] ?? 100;
        if ($cumplimiento < 80) $score += 0.2;
        elseif ($cumplimiento < 95) $score += 0.1;

        // Penalizar por riesgo de fiscalización
        $score += ($metrics['riesgo_fiscalizacion'] ?? 0) * 0.3;

        return min(1, max(0, $score));
    }

    /**
     * Proyecta carga tributaria futura
     */
    protected function projectTaxLoad(Copropiedad $copropiedad, int $months): float
    {
        $baseAnual = $this->getAnnualTaxBase($copropiedad);
        
        // Aplicar factor de crecimiento estimado (3% anual inflación + 2% crecimiento real)
        $growthFactor = pow(1.05, $months / 12);
        
        return $baseAnual * $growthFactor * ($months / 12);
    }

    protected function calculateGlobalCompliance(array $dj1879, array $dj1907, array $ppm): float
    {
        $scores = [];
        
        if (($dj1879['cumplimiento'] ?? 'no_aplica') !== 'no_aplica') {
            $scores[] = $dj1879['cumplimiento'] === 'presentada' ? 100 : 0;
        }
        if (($dj1907['cumplimiento'] ?? 'no_aplica') !== 'no_aplica') {
            $scores[] = $dj1907['cumplimiento'] === 'presentada' ? 100 : 0;
        }
        
        return empty($scores) ? 100 : array_sum($scores) / count($scores);
    }

    protected function estimateFiscalizationRisk(Copropiedad $copropiedad): float
    {
        // Factores de riesgo de fiscalización SII
        $risk = 0;
        
        // Ingresos altos aumentan probabilidad de revisión
        $ingresos = $copropiedad->unidades()->count() * 50000; // Estimado
        if ($ingresos > 100000000) $risk += 0.2;
        
        // Sectores específicos (antenas, arriendos comerciales)
        // $risk += 0.1 si aplica
        
        return min(1, $risk);
    }

    protected function calculatePotentialSavings(Copropiedad $copropiedad): float
    {
        // Calcular potencial ahorro por optimización tributaria
        return 0;
    }

    protected function getAnnualTaxBase(Copropiedad $copropiedad): float
    {
        return DB::table('ingresos_copropiedad')
            ->where('copropiedad_id', $copropiedad->id)
            ->where('gravado_renta', true)
            ->sum('monto_mensual') * 12;
    }

    // =========================================================
    // M05 GASTOS COMUNES: Histórico, tendencia, estacionalidad
    // =========================================================

    /**
     * Construye contexto de gastos comunes para análisis precesional
     * 
     * Analiza histórico de gastos, identifica patrones estacionales
     * y calcula tendencias para proyección precesional.
     * 
     * @param Copropiedad $copropiedad
     * @return array Contexto de gastos normalizado
     */
    public function buildExpenseContext(Copropiedad $copropiedad): array
    {
        $cacheKey = "pae:expense_context:{$copropiedad->id}";
        
        return Cache::remember($cacheKey, self::CONTEXT_CACHE_TTL, function () use ($copropiedad) {
            // Obtener histórico de gastos comunes (últimos 36 meses)
            $gastos = DB::table('gastos_comunes')
                ->where('copropiedad_id', $copropiedad->id)
                ->where('fecha', '>=', now()->subMonths(36))
                ->orderBy('fecha')
                ->get();

            if ($gastos->isEmpty()) {
                return $this->getDefaultExpenseContext();
            }

            // Calcular métricas
            $promedioMensual = $gastos->avg('monto_total');
            $tendencia = $this->calculateExpenseTrend($gastos);
            $estacionalidad = $this->calculateSeasonality($gastos);
            $volatilidad = $this->calculateVolatility($gastos);

            // Desglose por categoría
            $porCategoria = $this->getExpensesByCategory($copropiedad);

            // Proyecciones
            $proyeccion12m = $this->projectExpenses($gastos, 12);
            $proyeccion36m = $this->projectExpenses($gastos, 36);

            return [
                'historico' => [
                    'meses_disponibles' => $gastos->count(),
                    'promedio_mensual' => round($promedioMensual),
                    'minimo' => $gastos->min('monto_total'),
                    'maximo' => $gastos->max('monto_total'),
                    'ultimo_gasto' => $gastos->last()?->monto_total,
                    'fecha_ultimo' => $gastos->last()?->fecha,
                ],
                'tendencia' => [
                    'direccion' => $tendencia['direccion'],
                    'porcentaje_anual' => round($tendencia['porcentaje'], 2),
                    'pendiente' => $tendencia['pendiente'],
                    'r_squared' => $tendencia['r_squared'],
                ],
                'estacionalidad' => [
                    'detectada' => $estacionalidad['detectada'],
                    'meses_altos' => $estacionalidad['meses_altos'],
                    'meses_bajos' => $estacionalidad['meses_bajos'],
                    'amplitud' => $estacionalidad['amplitud'],
                    'indices_mensuales' => $estacionalidad['indices'],
                ],
                'volatilidad' => [
                    'coeficiente_variacion' => round($volatilidad['cv'], 4),
                    'desviacion_estandar' => round($volatilidad['std']),
                    'nivel' => $volatilidad['nivel'],
                ],
                'por_categoria' => $porCategoria,
                'proyecciones' => [
                    '12_meses' => [
                        'total' => round($proyeccion12m['total']),
                        'promedio_mensual' => round($proyeccion12m['promedio']),
                        'intervalo_confianza' => $proyeccion12m['intervalo'],
                    ],
                    '36_meses' => [
                        'total' => round($proyeccion36m['total']),
                        'promedio_mensual' => round($proyeccion36m['promedio']),
                        'intervalo_confianza' => $proyeccion36m['intervalo'],
                    ],
                ],
                'alertas' => $this->detectExpenseAnomalies($gastos, $promedioMensual),
            ];
        });
    }

    /**
     * Calcula tendencia de gastos usando regresión lineal
     */
    protected function calculateExpenseTrend(Collection $gastos): array
    {
        if ($gastos->count() < 3) {
            return ['direccion' => 'estable', 'porcentaje' => 0, 'pendiente' => 0, 'r_squared' => 0];
        }

        $n = $gastos->count();
        $x = range(1, $n);
        $y = $gastos->pluck('monto_total')->toArray();

        $sumX = array_sum($x);
        $sumY = array_sum($y);
        $sumXY = 0;
        $sumX2 = 0;
        $sumY2 = 0;

        for ($i = 0; $i < $n; $i++) {
            $sumXY += $x[$i] * $y[$i];
            $sumX2 += $x[$i] * $x[$i];
            $sumY2 += $y[$i] * $y[$i];
        }

        $pendiente = ($n * $sumXY - $sumX * $sumY) / ($n * $sumX2 - $sumX * $sumX);
        $intercepto = ($sumY - $pendiente * $sumX) / $n;

        // R-squared
        $yMean = $sumY / $n;
        $ssTot = array_sum(array_map(fn($yi) => pow($yi - $yMean, 2), $y));
        $ssRes = 0;
        for ($i = 0; $i < $n; $i++) {
            $yPred = $pendiente * $x[$i] + $intercepto;
            $ssRes += pow($y[$i] - $yPred, 2);
        }
        $rSquared = $ssTot > 0 ? 1 - ($ssRes / $ssTot) : 0;

        // Porcentaje anual
        $primerValor = $y[0] ?: 1;
        $porcentajeAnual = ($pendiente * 12) / $primerValor * 100;

        return [
            'direccion' => $pendiente > 0 ? 'creciente' : ($pendiente < 0 ? 'decreciente' : 'estable'),
            'porcentaje' => $porcentajeAnual,
            'pendiente' => $pendiente,
            'r_squared' => $rSquared,
        ];
    }

    /**
     * Calcula índices de estacionalidad mensual
     */
    protected function calculateSeasonality(Collection $gastos): array
    {
        $porMes = [];
        foreach ($gastos as $gasto) {
            $mes = Carbon::parse($gasto->fecha)->month;
            $porMes[$mes][] = $gasto->monto_total;
        }

        $promedioGeneral = $gastos->avg('monto_total');
        $indices = [];
        
        for ($m = 1; $m <= 12; $m++) {
            if (isset($porMes[$m]) && count($porMes[$m]) > 0) {
                $promedioMes = array_sum($porMes[$m]) / count($porMes[$m]);
                $indices[$m] = $promedioGeneral > 0 ? $promedioMes / $promedioGeneral : 1;
            } else {
                $indices[$m] = 1;
            }
        }

        // Detectar meses altos y bajos
        $mesesAltos = array_keys(array_filter($indices, fn($i) => $i > 1.1));
        $mesesBajos = array_keys(array_filter($indices, fn($i) => $i < 0.9));
        
        $amplitud = max($indices) - min($indices);
        $detectada = $amplitud > 0.2;

        return [
            'detectada' => $detectada,
            'meses_altos' => $mesesAltos,
            'meses_bajos' => $mesesBajos,
            'amplitud' => round($amplitud, 3),
            'indices' => $indices,
        ];
    }

    /**
     * Calcula volatilidad de gastos
     */
    protected function calculateVolatility(Collection $gastos): array
    {
        $valores = $gastos->pluck('monto_total');
        $promedio = $valores->avg();
        
        if ($promedio == 0) {
            return ['cv' => 0, 'std' => 0, 'nivel' => 'bajo'];
        }

        $varianza = $valores->map(fn($v) => pow($v - $promedio, 2))->avg();
        $std = sqrt($varianza);
        $cv = $std / $promedio;

        $nivel = match(true) {
            $cv > 0.3 => 'alto',
            $cv > 0.15 => 'medio',
            default => 'bajo',
        };

        return ['cv' => $cv, 'std' => $std, 'nivel' => $nivel];
    }

    /**
     * Obtiene desglose de gastos por categoría
     */
    protected function getExpensesByCategory(Copropiedad $copropiedad): array
    {
        $gastos = DB::table('gastos_comunes_detalle')
            ->join('gastos_comunes', 'gastos_comunes.id', '=', 'gastos_comunes_detalle.gasto_comun_id')
            ->where('gastos_comunes.copropiedad_id', $copropiedad->id)
            ->where('gastos_comunes.fecha', '>=', now()->subMonths(12))
            ->selectRaw('categoria, SUM(monto) as total, AVG(monto) as promedio')
            ->groupBy('categoria')
            ->get();

        $total = $gastos->sum('total');

        return $gastos->map(fn($g) => [
            'categoria' => $g->categoria,
            'total_12m' => $g->total,
            'promedio_mensual' => $g->promedio,
            'porcentaje' => $total > 0 ? round($g->total / $total * 100, 1) : 0,
        ])->toArray();
    }

    /**
     * Proyecta gastos futuros
     */
    protected function projectExpenses(Collection $gastos, int $months): array
    {
        $tendencia = $this->calculateExpenseTrend($gastos);
        $ultimoGasto = $gastos->last()?->monto_total ?? 0;
        
        $proyeccionMensual = $ultimoGasto * (1 + $tendencia['porcentaje'] / 100 / 12);
        $total = 0;
        
        for ($m = 1; $m <= $months; $m++) {
            $total += $proyeccionMensual * pow(1 + $tendencia['porcentaje'] / 100 / 12, $m);
        }

        $volatilidad = $this->calculateVolatility($gastos);
        $intervalo = $volatilidad['std'] * 1.96; // 95% confianza

        return [
            'total' => $total,
            'promedio' => $total / $months,
            'intervalo' => [
                'inferior' => ($total / $months) - $intervalo,
                'superior' => ($total / $months) + $intervalo,
            ],
        ];
    }

    /**
     * Detecta anomalías en gastos
     */
    protected function detectExpenseAnomalies(Collection $gastos, float $promedio): array
    {
        $alertas = [];
        $umbralAlto = $promedio * 1.5;
        $umbralBajo = $promedio * 0.5;

        $ultimo = $gastos->last();
        if ($ultimo && $ultimo->monto_total > $umbralAlto) {
            $alertas[] = [
                'tipo' => 'gasto_alto',
                'mensaje' => 'Último gasto significativamente superior al promedio',
                'valor' => $ultimo->monto_total,
                'umbral' => $umbralAlto,
            ];
        }

        return $alertas;
    }

    protected function getDefaultExpenseContext(): array
    {
        return [
            'historico' => ['meses_disponibles' => 0],
            'tendencia' => ['direccion' => 'sin_datos'],
            'estacionalidad' => ['detectada' => false],
            'volatilidad' => ['nivel' => 'desconocido'],
            'por_categoria' => [],
            'proyecciones' => [],
            'alertas' => [],
        ];
    }

    // =========================================================
    // M06 COMPLIANCE DS7-2025: Score, Ley 21.442, brechas
    // =========================================================

    /**
     * Construye contexto de compliance para análisis precesional
     * 
     * Evalúa cumplimiento DS7-2025, Ley 21.442, y detecta
     * brechas normativas que impactan valorización precesional.
     * 
     * @param Copropiedad $copropiedad
     * @return array Contexto compliance normalizado
     */
    public function buildComplianceContext(Copropiedad $copropiedad): array
    {
        $cacheKey = "pae:compliance_context:{$copropiedad->id}";
        
        return Cache::remember($cacheKey, self::CONTEXT_CACHE_TTL, function () use ($copropiedad) {
            // Evaluar DS7-2025
            $ds7 = $this->evaluateDS7Compliance($copropiedad);
            
            // Evaluar Ley 21.442
            $ley21442 = $this->evaluateLey21442Compliance($copropiedad);
            
            // Detectar brechas
            $brechas = $this->detectComplianceGaps($copropiedad, $ds7, $ley21442);
            
            // Calcular probabilidad de cambio normativo
            $cambioNormativo = $this->estimateRegulatoryChange();

            return [
                'ds7_2025' => [
                    'score' => $ds7['score'],
                    'nivel' => $ds7['nivel'],
                    'requisitos_cumplidos' => $ds7['cumplidos'],
                    'requisitos_totales' => $ds7['totales'],
                    'detalle' => $ds7['detalle'],
                ],
                'ley_21442' => [
                    'estado' => $ley21442['estado'],
                    'fecha_limite' => $ley21442['fecha_limite'],
                    'dias_restantes' => $ley21442['dias_restantes'],
                    'requisitos' => $ley21442['requisitos'],
                    'multa_potencial' => $ley21442['multa_potencial'],
                ],
                'brechas' => [
                    'cantidad' => count($brechas),
                    'criticas' => array_filter($brechas, fn($b) => $b['severidad'] === 'critica'),
                    'altas' => array_filter($brechas, fn($b) => $b['severidad'] === 'alta'),
                    'detalle' => $brechas,
                ],
                'cambio_normativo' => [
                    'probabilidad_12m' => $cambioNormativo['prob_12m'],
                    'impacto_estimado' => $cambioNormativo['impacto'],
                    'normativas_en_tramite' => $cambioNormativo['en_tramite'],
                ],
                'score_global' => $this->calculateGlobalComplianceScore($ds7, $ley21442, $brechas),
                'recomendaciones' => $this->generateComplianceRecommendations($brechas),
            ];
        });
    }

    /**
     * Evalúa cumplimiento DS7-2025
     */
    protected function evaluateDS7Compliance(Copropiedad $copropiedad): array
    {
        $requisitos = [
            'reglamento_inscrito' => [
                'cumple' => !empty($copropiedad->reglamento_inscrito),
                'peso' => 20,
            ],
            'administrador_vigente' => [
                'cumple' => !empty($copropiedad->nombre_administracion),
                'peso' => 15,
            ],
            'cuenta_bancaria_exclusiva' => [
                'cumple' => !empty($copropiedad->cuenta_bancaria),
                'peso' => 15,
            ],
            'fondo_reserva_minimo' => [
                'cumple' => ($copropiedad->fondo_reserva ?? 0) >= ($copropiedad->gasto_comun_mensual ?? 1) * 3,
                'peso' => 10,
            ],
            'libro_actas_digital' => [
                'cumple' => $copropiedad->libro_actas_digital ?? false,
                'peso' => 10,
            ],
            'plan_mantenimiento' => [
                'cumple' => $copropiedad->plan_mantenimiento ?? false,
                'peso' => 15,
            ],
            'seguro_incendio_vigente' => [
                'cumple' => $copropiedad->seguro_vigente ?? false,
                'peso' => 15,
            ],
        ];

        $scorePonderado = 0;
        $pesoTotal = 0;
        $cumplidos = 0;
        $detalle = [];

        foreach ($requisitos as $req => $data) {
            $pesoTotal += $data['peso'];
            if ($data['cumple']) {
                $scorePonderado += $data['peso'];
                $cumplidos++;
            }
            $detalle[$req] = $data['cumple'];
        }

        $score = $pesoTotal > 0 ? ($scorePonderado / $pesoTotal) * 100 : 0;

        return [
            'score' => round($score, 1),
            'nivel' => $this->getComplianceLevel($score),
            'cumplidos' => $cumplidos,
            'totales' => count($requisitos),
            'detalle' => $detalle,
        ];
    }

    /**
     * Evalúa cumplimiento Ley 21.442
     */
    protected function evaluateLey21442Compliance(Copropiedad $copropiedad): array
    {
        // Fecha límite: 1 año desde publicación (Abril 2022)
        $fechaLimite = Carbon::parse('2024-04-13');
        $diasRestantes = max(0, now()->diffInDays($fechaLimite, false));

        $requisitos = [
            'adecuacion_reglamento' => $copropiedad->reglamento_adecuado_21442 ?? false,
            'asamblea_adecuacion' => $copropiedad->asamblea_adecuacion ?? false,
            'inscripcion_cbr' => $copropiedad->inscripcion_cbr_21442 ?? false,
            'comite_administracion' => $copropiedad->comite_constituido ?? false,
        ];

        $cumplidos = count(array_filter($requisitos));
        $estado = match($cumplidos) {
            4 => 'cumple',
            3, 2 => 'parcial',
            default => 'incumple',
        };

        // Multa potencial por incumplimiento
        $multaPotencial = $estado === 'incumple' ? 50 : ($estado === 'parcial' ? 20 : 0); // UTM

        return [
            'estado' => $estado,
            'fecha_limite' => $fechaLimite->toDateString(),
            'dias_restantes' => $diasRestantes,
            'requisitos' => $requisitos,
            'multa_potencial' => $multaPotencial,
        ];
    }

    /**
     * Detecta brechas de cumplimiento
     */
    protected function detectComplianceGaps(Copropiedad $copropiedad, array $ds7, array $ley21442): array
    {
        $brechas = [];

        // Brechas DS7
        foreach ($ds7['detalle'] as $req => $cumple) {
            if (!$cumple) {
                $brechas[] = [
                    'tipo' => 'ds7',
                    'requisito' => $req,
                    'severidad' => in_array($req, ['reglamento_inscrito', 'administrador_vigente']) ? 'critica' : 'alta',
                    'accion_requerida' => $this->getRequiredAction($req),
                    'plazo_sugerido' => 30,
                ];
            }
        }

        // Brechas Ley 21.442
        foreach ($ley21442['requisitos'] as $req => $cumple) {
            if (!$cumple) {
                $brechas[] = [
                    'tipo' => 'ley_21442',
                    'requisito' => $req,
                    'severidad' => $ley21442['dias_restantes'] < 30 ? 'critica' : 'alta',
                    'accion_requerida' => $this->getRequiredAction($req),
                    'plazo_sugerido' => min(30, $ley21442['dias_restantes']),
                ];
            }
        }

        return $brechas;
    }

    protected function getComplianceLevel(float $score): string
    {
        return match(true) {
            $score >= 90 => 'excelente',
            $score >= 70 => 'bueno',
            $score >= 50 => 'regular',
            default => 'deficiente',
        };
    }

    protected function getRequiredAction(string $requisito): string
    {
        return match($requisito) {
            'reglamento_inscrito' => 'Inscribir reglamento de copropiedad en CBR',
            'administrador_vigente' => 'Designar administrador en asamblea',
            'cuenta_bancaria_exclusiva' => 'Abrir cuenta corriente exclusiva',
            'fondo_reserva_minimo' => 'Constituir fondo de reserva mínimo',
            'adecuacion_reglamento' => 'Adecuar reglamento a Ley 21.442',
            default => 'Verificar requisito y subsanar',
        };
    }

    protected function estimateRegulatoryChange(): array
    {
        // Monitorear proyectos de ley en trámite
        return [
            'prob_12m' => 0.15, // 15% probabilidad de cambio normativo
            'impacto' => 'medio',
            'en_tramite' => [
                'Modificación DS7 sobre administración profesional',
            ],
        ];
    }

    protected function calculateGlobalComplianceScore(array $ds7, array $ley21442, array $brechas): float
    {
        $scoreBase = $ds7['score'];
        
        // Penalizar por brechas críticas
        $criticas = count(array_filter($brechas, fn($b) => $b['severidad'] === 'critica'));
        $scoreBase -= $criticas * 10;
        
        // Penalizar por incumplimiento Ley 21.442
        if ($ley21442['estado'] === 'incumple') {
            $scoreBase -= 20;
        }

        return max(0, min(100, $scoreBase));
    }

    protected function generateComplianceRecommendations(array $brechas): array
    {
        return array_map(fn($b) => [
            'prioridad' => $b['severidad'] === 'critica' ? 1 : 2,
            'accion' => $b['accion_requerida'],
            'plazo' => $b['plazo_sugerido'] . ' días',
        ], array_slice($brechas, 0, 5));
    }

    // =========================================================
    // M07 ALÍCUOTAS LEY 21.442
    // =========================================================

    /**
     * Construye contexto de alícuotas para análisis precesional
     * 
     * @param Copropiedad $copropiedad
     * @return array Contexto alícuotas normalizado
     */
    public function buildAliquotContext(Copropiedad $copropiedad): array
    {
        $cacheKey = "pae:aliquot_context:{$copropiedad->id}";
        
        return Cache::remember($cacheKey, self::CONTEXT_CACHE_TTL, function () use ($copropiedad) {
            $unidades = $copropiedad->unidades()->with('avaluosFiscales')->get();
            
            // Distribución actual de alícuotas
            $distribucion = $this->calculateAliquotDistribution($unidades);
            
            // Avalúos SII
            $avaluos = $this->getAvaluosSII($unidades);
            
            // Proyección de revalúo
            $proyeccionRevaluo = $this->projectRevaluation($avaluos);

            return [
                'distribucion_actual' => [
                    'metodo' => $copropiedad->metodo_prorrateo ?? 'superficie',
                    'total_unidades' => $unidades->count(),
                    'suma_alicuotas' => round($distribucion['suma'], 4),
                    'max_alicuota' => $distribucion['max'],
                    'min_alicuota' => $distribucion['min'],
                    'desviacion' => $distribucion['std'],
                    'gini' => $distribucion['gini'],
                ],
                'ponderadores' => [
                    'superficie' => $copropiedad->ponderador_superficie ?? 1.0,
                    'avaluo' => $copropiedad->ponderador_avaluo ?? 0.0,
                    'uso' => $copropiedad->ponderador_uso ?? 0.0,
                ],
                'avaluos_sii' => [
                    'total_copropiedad' => $avaluos['total'],
                    'promedio_unidad' => $avaluos['promedio'],
                    'fecha_ultimo_revaluo' => $avaluos['ultimo_revaluo'],
                    'variacion_ultimo_ano' => $avaluos['variacion_anual'],
                ],
                'proyeccion_revaluo' => [
                    'fecha_probable' => $proyeccionRevaluo['fecha'],
                    'variacion_estimada' => $proyeccionRevaluo['variacion'],
                    'impacto_alicuotas' => $proyeccionRevaluo['impacto'],
                    'unidades_afectadas' => $proyeccionRevaluo['afectadas'],
                ],
                'alertas' => $this->detectAliquotAnomalies($distribucion),
            ];
        });
    }

    protected function calculateAliquotDistribution(Collection $unidades): array
    {
        $alicuotas = $unidades->pluck('prorrateo')->filter()->values();
        
        if ($alicuotas->isEmpty()) {
            return ['suma' => 0, 'max' => 0, 'min' => 0, 'std' => 0, 'gini' => 0];
        }

        $n = $alicuotas->count();
        $suma = $alicuotas->sum();
        $promedio = $alicuotas->avg();
        $varianza = $alicuotas->map(fn($a) => pow($a - $promedio, 2))->avg();
        
        // Coeficiente de Gini
        $sorted = $alicuotas->sort()->values();
        $gini = 0;
        for ($i = 0; $i < $n; $i++) {
            $gini += (2 * ($i + 1) - $n - 1) * $sorted[$i];
        }
        $gini = $suma > 0 ? $gini / ($n * $suma) : 0;

        return [
            'suma' => $suma,
            'max' => $alicuotas->max(),
            'min' => $alicuotas->min(),
            'std' => sqrt($varianza),
            'gini' => abs($gini),
        ];
    }

    protected function getAvaluosSII(Collection $unidades): array
    {
        $avaluos = $unidades->map(fn($u) => $u->avaluo_fiscal ?? 0);
        
        return [
            'total' => $avaluos->sum(),
            'promedio' => $avaluos->avg(),
            'ultimo_revaluo' => '2024-01-01', // Ejemplo
            'variacion_anual' => 5.2, // Ejemplo %
        ];
    }

    protected function projectRevaluation(array $avaluos): array
    {
        // SII realiza revalúos cada 4-5 años aproximadamente
        return [
            'fecha' => Carbon::now()->addYears(2)->format('Y'),
            'variacion' => 8.5, // Estimación %
            'impacto' => 'medio',
            'afectadas' => 15, // % unidades con cambio significativo
        ];
    }

    protected function detectAliquotAnomalies(array $distribucion): array
    {
        $alertas = [];
        
        if (abs($distribucion['suma'] - 100) > 0.01) {
            $alertas[] = [
                'tipo' => 'suma_incorrecta',
                'mensaje' => 'La suma de alícuotas no es 100%',
                'valor' => $distribucion['suma'],
            ];
        }
        
        if ($distribucion['gini'] > 0.5) {
            $alertas[] = [
                'tipo' => 'alta_desigualdad',
                'mensaje' => 'Alta concentración de alícuotas',
                'gini' => $distribucion['gini'],
            ];
        }

        return $alertas;
    }

    // =========================================================
    // M08 VALORIZACIÓN
    // =========================================================

    /**
     * Construye contexto de valorización para análisis precesional
     * 
     * @param Copropiedad $copropiedad
     * @return array Contexto valorización normalizado
     */
    public function buildValuationContext(Copropiedad $copropiedad): array
    {
        $cacheKey = "pae:valuation_context:{$copropiedad->id}";
        
        return Cache::remember($cacheKey, self::CONTEXT_CACHE_TTL, function () use ($copropiedad) {
            // Avalúo fiscal SII
            $avaluoFiscal = $this->getAvaluoFiscal($copropiedad);
            
            // Transacciones CBR en la zona
            $transaccionesCBR = $this->getTransaccionesCBR($copropiedad);
            
            // Arriendos comparables
            $arriendosZona = $this->getArriendosZona($copropiedad);
            
            // Valorización precesional
            $valorizacionPrecesional = $this->calculatePrecessionValuation(
                $avaluoFiscal, $transaccionesCBR, $arriendosZona
            );

            return [
                'avaluo_fiscal' => [
                    'valor_uf' => $avaluoFiscal['valor'],
                    'fecha' => $avaluoFiscal['fecha'],
                    'destino' => $avaluoFiscal['destino'],
                    'superficie_m2' => $avaluoFiscal['superficie'],
                    'valor_m2_uf' => $avaluoFiscal['valor_m2'],
                ],
                'mercado_cbr' => [
                    'transacciones_12m' => $transaccionesCBR['count'],
                    'valor_m2_promedio' => $transaccionesCBR['valor_m2_avg'],
                    'tendencia' => $transaccionesCBR['tendencia'],
                    'cap_rate_implicito' => $transaccionesCBR['cap_rate'],
                ],
                'arriendos_zona' => [
                    'arriendo_m2_promedio' => $arriendosZona['valor_m2'],
                    'vacancia' => $arriendosZona['vacancia'],
                    'tendencia_12m' => $arriendosZona['tendencia'],
                    'comparables' => $arriendosZona['count'],
                ],
                'valorizacion_precesional' => [
                    'horizonte_12m' => $valorizacionPrecesional['12m'],
                    'horizonte_24m' => $valorizacionPrecesional['24m'],
                    'horizonte_36m' => $valorizacionPrecesional['36m'],
                    'horizonte_60m' => $valorizacionPrecesional['60m'],
                    'factores_principales' => $valorizacionPrecesional['factores'],
                    'confianza' => $valorizacionPrecesional['confianza'],
                ],
                'indicadores' => [
                    'ratio_avaluo_mercado' => $avaluoFiscal['valor'] > 0 
                        ? $transaccionesCBR['valor_m2_avg'] / $avaluoFiscal['valor_m2'] 
                        : null,
                    'gross_yield' => $arriendosZona['valor_m2'] * 12 / ($transaccionesCBR['valor_m2_avg'] ?: 1) * 100,
                ],
            ];
        });
    }

    protected function getAvaluoFiscal(Copropiedad $copropiedad): array
    {
        return [
            'valor' => $copropiedad->avaluo_fiscal ?? 0,
            'fecha' => $copropiedad->fecha_avaluo ?? now()->format('Y-m-d'),
            'destino' => $copropiedad->destino ?? 'habitacional',
            'superficie' => $copropiedad->superficie_total ?? 0,
            'valor_m2' => $copropiedad->superficie_total > 0 
                ? ($copropiedad->avaluo_fiscal ?? 0) / $copropiedad->superficie_total 
                : 0,
        ];
    }

    protected function getTransaccionesCBR(Copropiedad $copropiedad): array
    {
        // Consultar transacciones CBR en radio de 1km
        $transacciones = DB::table('transacciones_cbr')
            ->whereRaw("ST_DWithin(
                ST_SetSRID(ST_MakePoint(longitud, latitud), 4326)::geography,
                ST_SetSRID(ST_MakePoint(?, ?), 4326)::geography,
                1000
            )", [$copropiedad->longitud, $copropiedad->latitud])
            ->where('fecha', '>=', now()->subMonths(12))
            ->get();

        if ($transacciones->isEmpty()) {
            return ['count' => 0, 'valor_m2_avg' => 0, 'tendencia' => 'sin_datos', 'cap_rate' => 0];
        }

        return [
            'count' => $transacciones->count(),
            'valor_m2_avg' => $transacciones->avg('valor_m2'),
            'tendencia' => $this->calculateTransactionTrend($transacciones),
            'cap_rate' => 5.5, // Estimado
        ];
    }

    protected function getArriendosZona(Copropiedad $copropiedad): array
    {
        $arriendos = DB::table('arriendos_mercado')
            ->where('comuna', $copropiedad->comuna)
            ->where('tipo', $copropiedad->tipo)
            ->where('fecha_publicacion', '>=', now()->subMonths(6))
            ->get();

        return [
            'valor_m2' => $arriendos->avg('precio_m2') ?? 0,
            'vacancia' => 5.2, // Estimado %
            'tendencia' => 'estable',
            'count' => $arriendos->count(),
        ];
    }

    protected function calculatePrecessionValuation(array $avaluo, array $cbr, array $arriendos): array
    {
        $valorBase = $cbr['valor_m2_avg'] * ($avaluo['superficie'] ?? 100);
        $tendenciaMensual = match($cbr['tendencia']) {
            'creciente' => 0.005,
            'decreciente' => -0.003,
            default => 0.002,
        };

        return [
            '12m' => round($valorBase * pow(1 + $tendenciaMensual, 12)),
            '24m' => round($valorBase * pow(1 + $tendenciaMensual, 24)),
            '36m' => round($valorBase * pow(1 + $tendenciaMensual, 36)),
            '60m' => round($valorBase * pow(1 + $tendenciaMensual, 60)),
            'factores' => ['ubicacion', 'transporte', 'equipamiento'],
            'confianza' => 0.75,
        ];
    }

    protected function calculateTransactionTrend(Collection $transacciones): string
    {
        if ($transacciones->count() < 3) return 'sin_datos';
        
        $primeros = $transacciones->take(intval($transacciones->count() / 2))->avg('valor_m2');
        $ultimos = $transacciones->skip(intval($transacciones->count() / 2))->avg('valor_m2');
        
        $variacion = $primeros > 0 ? ($ultimos - $primeros) / $primeros : 0;
        
        return match(true) {
            $variacion > 0.05 => 'creciente',
            $variacion < -0.05 => 'decreciente',
            default => 'estable',
        };
    }

    // =========================================================
    // M16 ARRIENDOS
    // =========================================================

    /**
     * Construye contexto de arriendos para análisis precesional
     * 
     * @param Copropiedad $copropiedad
     * @return array Contexto arriendos normalizado
     */
    public function buildRentalContext(Copropiedad $copropiedad): array
    {
        $cacheKey = "pae:rental_context:{$copropiedad->id}";
        
        return Cache::remember($cacheKey, self::CONTEXT_CACHE_TTL, function () use ($copropiedad) {
            // Arriendos activos en la copropiedad
            $arriendosActivos = $this->getActiveRentals($copropiedad);
            
            // Precio por m² y tendencia
            $precioM2 = $this->calculateRentalPricePerM2($arriendosActivos);
            
            // Vacancia
            $vacancia = $this->calculateVacancy($copropiedad);
            
            // Proyección ajustada por precesión
            $proyeccion = $this->projectRentalWithPrecession($arriendosActivos, $copropiedad);

            return [
                'arriendos_activos' => [
                    'cantidad' => $arriendosActivos->count(),
                    'ingreso_mensual_total' => $arriendosActivos->sum('monto_mensual'),
                    'arriendo_promedio' => $arriendosActivos->avg('monto_mensual'),
                    'duracion_promedio_meses' => $arriendosActivos->avg('duracion_meses'),
                ],
                'precio_m2' => [
                    'promedio' => $precioM2['promedio'],
                    'minimo' => $precioM2['min'],
                    'maximo' => $precioM2['max'],
                    'tendencia_12m' => $precioM2['tendencia'],
                    'variacion_ipc' => $precioM2['vs_ipc'],
                ],
                'vacancia' => [
                    'tasa_actual' => $vacancia['tasa'],
                    'unidades_disponibles' => $vacancia['disponibles'],
                    'dias_promedio_vacante' => $vacancia['dias_promedio'],
                    'tendencia' => $vacancia['tendencia'],
                ],
                'proyeccion_precesional' => [
                    'arriendo_12m' => $proyeccion['12m'],
                    'arriendo_24m' => $proyeccion['24m'],
                    'arriendo_36m' => $proyeccion['36m'],
                    'factores_ajuste' => $proyeccion['factores'],
                    'intervalo_confianza' => $proyeccion['intervalo'],
                ],
                'metricas_inversion' => [
                    'gross_yield' => $this->calculateGrossYield($arriendosActivos, $copropiedad),
                    'net_yield' => $this->calculateNetYield($arriendosActivos, $copropiedad),
                    'payback_anos' => $this->calculatePayback($arriendosActivos, $copropiedad),
                ],
            ];
        });
    }

    protected function getActiveRentals(Copropiedad $copropiedad): Collection
    {
        return Arriendo::whereHas('unidad', fn($q) => $q->where('copropiedad_id', $copropiedad->id))
            ->where('estado', 'activo')
            ->get();
    }

    protected function calculateRentalPricePerM2(Collection $arriendos): array
    {
        if ($arriendos->isEmpty()) {
            return ['promedio' => 0, 'min' => 0, 'max' => 0, 'tendencia' => 0, 'vs_ipc' => 0];
        }

        $preciosM2 = $arriendos->map(function ($arriendo) {
            $superficie = $arriendo->unidad->superficie ?? 50;
            return $superficie > 0 ? $arriendo->monto_mensual / $superficie : 0;
        })->filter();

        return [
            'promedio' => round($preciosM2->avg(), 2),
            'min' => round($preciosM2->min(), 2),
            'max' => round($preciosM2->max(), 2),
            'tendencia' => 3.5, // % anual estimado
            'vs_ipc' => 1.2, // Diferencia vs IPC
        ];
    }

    protected function calculateVacancy(Copropiedad $copropiedad): array
    {
        $totalUnidades = $copropiedad->unidades()->count();
        $arrendadas = $copropiedad->unidades()
            ->whereHas('arriendos', fn($q) => $q->where('estado', 'activo'))
            ->count();

        $disponibles = $totalUnidades - $arrendadas;
        $tasa = $totalUnidades > 0 ? ($disponibles / $totalUnidades) * 100 : 0;

        return [
            'tasa' => round($tasa, 1),
            'disponibles' => $disponibles,
            'dias_promedio' => 45, // Estimado
            'tendencia' => 'estable',
        ];
    }

    protected function projectRentalWithPrecession(Collection $arriendos, Copropiedad $copropiedad): array
    {
        $arriendoActual = $arriendos->avg('monto_mensual') ?? 0;
        
        // Factores precesionales que afectan arriendos
        $factorMetro = 1.0; // Si hay proyecto metro cercano: 1.05-1.15
        $factorEquipamiento = 1.02;
        $factorSeguridad = 1.0;
        
        $factorTotal = $factorMetro * $factorEquipamiento * $factorSeguridad;
        $crecimientoAnual = 0.04; // 4% real + IPC

        return [
            '12m' => round($arriendoActual * pow(1 + $crecimientoAnual, 1) * $factorTotal),
            '24m' => round($arriendoActual * pow(1 + $crecimientoAnual, 2) * $factorTotal),
            '36m' => round($arriendoActual * pow(1 + $crecimientoAnual, 3) * $factorTotal),
            'factores' => [
                'crecimiento_base' => $crecimientoAnual * 100,
                'ajuste_precesional' => ($factorTotal - 1) * 100,
            ],
            'intervalo' => [
                'inferior' => round($arriendoActual * 0.95),
                'superior' => round($arriendoActual * 1.15),
            ],
        ];
    }

    protected function calculateGrossYield(Collection $arriendos, Copropiedad $copropiedad): float
    {
        $ingresoAnual = $arriendos->sum('monto_mensual') * 12;
        $valorPropiedad = $copropiedad->valor_comercial ?? $copropiedad->avaluo_fiscal ?? 1;
        
        return round(($ingresoAnual / $valorPropiedad) * 100, 2);
    }

    protected function calculateNetYield(Collection $arriendos, Copropiedad $copropiedad): float
    {
        $ingresoAnual = $arriendos->sum('monto_mensual') * 12;
        $gastosAnuales = ($copropiedad->gasto_comun_mensual ?? 0) * 12 * 0.3; // Estimado 30%
        $noi = $ingresoAnual - $gastosAnuales;
        $valorPropiedad = $copropiedad->valor_comercial ?? $copropiedad->avaluo_fiscal ?? 1;
        
        return round(($noi / $valorPropiedad) * 100, 2);
    }

    protected function calculatePayback(Collection $arriendos, Copropiedad $copropiedad): float
    {
        $ingresoAnual = $arriendos->sum('monto_mensual') * 12;
        $valorPropiedad = $copropiedad->valor_comercial ?? $copropiedad->avaluo_fiscal ?? 0;
        
        return $ingresoAnual > 0 ? round($valorPropiedad / $ingresoAnual, 1) : 0;
    }

    // =========================================================
    // CONTEXTO COMPLETO INTEGRADO
    // =========================================================

    /**
     * Construye contexto completo integrando todos los módulos
     * 
     * @param Copropiedad $copropiedad
     * @return array Contexto completo para PAE
     */
    public function buildFullContext(Copropiedad $copropiedad): array
    {
        return [
            'copropiedad_id' => $copropiedad->id,
            'timestamp' => now()->toIso8601String(),
            'location' => [
                'lat' => $copropiedad->latitud,
                'lng' => $copropiedad->longitud,
                'comuna' => $copropiedad->comuna,
                'region' => $copropiedad->region ?? 'Metropolitana',
            ],
            'tax' => $this->buildTaxContext($copropiedad),
            'expenses' => $this->buildExpenseContext($copropiedad),
            'compliance' => $this->buildComplianceContext($copropiedad),
            'aliquots' => $this->buildAliquotContext($copropiedad),
            'valuation' => $this->buildValuationContext($copropiedad),
            'rental' => $this->buildRentalContext($copropiedad),
        ];
    }
}
