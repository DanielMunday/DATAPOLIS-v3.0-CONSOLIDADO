<?php

/**
 * =========================================================
 * PAE M11 - Precession Analytics Engine Configuration
 * =========================================================
 * 
 * Configuración del módulo de análisis precesional basado
 * en la teoría de R. Buckminster Fuller.
 */

return [

    /*
    |--------------------------------------------------------------------------
    | PAE Core API
    |--------------------------------------------------------------------------
    |
    | Configuración de conexión al servicio PAE Core (FastAPI/Python).
    |
    */

    'api' => [
        'url' => env('PAE_API_URL', 'http://localhost:8000/api/v1/pae'),
        'key' => env('PAE_API_KEY', ''),
        'timeout' => env('PAE_HTTP_TIMEOUT', 30),
        'retry_times' => 3,
        'retry_delay' => 1000, // milliseconds
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Configuration
    |--------------------------------------------------------------------------
    |
    | TTL para diferentes tipos de cache del PAE.
    |
    */

    'cache' => [
        'driver' => env('PAE_CACHE_DRIVER', 'redis'),
        'prefix' => 'pae:',
        
        'ttl' => [
            'analysis' => env('PAE_CACHE_TTL_ANALYSIS', 3600),      // 1 hora
            'scoring' => env('PAE_CACHE_TTL_SCORING', 86400),       // 24 horas
            'context' => env('PAE_CACHE_TTL_CONTEXT', 1800),        // 30 minutos
            'heatmap' => env('PAE_CACHE_TTL_HEATMAP', 7200),        // 2 horas
            'dashboard' => env('PAE_CACHE_TTL_DASHBOARD', 900),     // 15 minutos
        ],
        
        'expiration_hours' => env('PAE_CACHE_EXPIRATION_HOURS', 24),
    ],

    /*
    |--------------------------------------------------------------------------
    | Fallback Configuration
    |--------------------------------------------------------------------------
    |
    | Configuración del análisis fallback cuando PAE Core no está disponible.
    |
    */

    'fallback' => [
        'enabled' => env('PAE_FALLBACK_ENABLED', true),
        'max_confidence' => 0.5, // Confianza máxima para análisis fallback
        'simplified' => true,    // Usar modelo simplificado
    ],

    /*
    |--------------------------------------------------------------------------
    | Default Analysis Parameters
    |--------------------------------------------------------------------------
    |
    | Parámetros por defecto para análisis precesional.
    |
    */

    'defaults' => [
        'radius_meters' => 1000,
        'time_horizon_months' => 36,
        'max_depth' => 4,
        'include_ml' => true,
        'generate_heatmap' => false,
    ],

    /*
    |--------------------------------------------------------------------------
    | Alert Thresholds
    |--------------------------------------------------------------------------
    |
    | Umbrales para generación de alertas.
    |
    */

    'thresholds' => [
        'risk' => [
            'critical' => 0.85,
            'high' => 0.70,
            'medium' => 0.50,
            'low' => 0.30,
        ],
        'opportunity' => [
            'exceptional' => 0.85,
            'high' => 0.70,
            'medium' => 0.50,
        ],
        'compliance' => [
            'critical' => 50,
            'warning' => 70,
        ],
        'expense_trend' => [
            'alert' => 15, // % anual
            'warning' => 10,
        ],
        'valuation' => [
            'depreciation_alert' => -5, // %
            'appreciation_opportunity' => 30, // %
        ],
        'vacancy' => [
            'high' => 15, // %
            'critical' => 25,
        ],
        'yield' => [
            'low' => 4, // %
            'critical' => 3,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Observer Configuration
    |--------------------------------------------------------------------------
    |
    | Configuración del PrecessionObserver.
    |
    */

    'observer' => [
        'enabled' => env('PAE_OBSERVER_ENABLED', true),
        'debounce_seconds' => 300, // 5 minutos
        'batch_threshold' => 5,    // Cambios para trigger batch
        
        'significant_fields' => [
            'copropiedad' => [
                'latitud', 'longitud', 'comuna', 'tipo',
                'superficie_total', 'unidades_count',
                'administracion_id', 'reglamento_inscrito',
            ],
            'tributario' => [
                'monto', 'monto_informado', 'estado', 'cumplimiento',
            ],
            'gastos_comunes' => [
                'monto_total', 'fecha', 'estado',
            ],
            'compliance' => [
                'score', 'estado', 'brechas', 'nivel',
            ],
            'alicuotas' => [
                'prorrateo', 'ponderador', 'avaluo',
            ],
            'valorizacion' => [
                'valor', 'valor_m2', 'transaccion',
            ],
            'arriendos' => [
                'monto_mensual', 'estado', 'fecha_inicio', 'fecha_termino',
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Precession Angles
    |--------------------------------------------------------------------------
    |
    | Configuración de los 5 ángulos precesionales de Fuller.
    |
    */

    'angles' => [
        'direct_0' => [
            'name' => 'Directo',
            'degrees' => 0,
            'description' => 'Efecto lineal causa-efecto inmediato',
            'temporal_lag_months' => [0, 6],
            'weight' => 1.0,
        ],
        'induced_45' => [
            'name' => 'Inducido',
            'degrees' => 45,
            'description' => 'Efectos secundarios correlacionados',
            'temporal_lag_months' => [3, 18],
            'weight' => 0.8,
        ],
        'precession_90' => [
            'name' => 'Precesión',
            'degrees' => 90,
            'description' => 'Efecto perpendicular - concepto core de Fuller',
            'temporal_lag_months' => [12, 36],
            'weight' => 0.6,
        ],
        'systemic_135' => [
            'name' => 'Sistémico',
            'degrees' => 135,
            'description' => 'Efectos de segundo orden en el sistema',
            'temporal_lag_months' => [24, 60],
            'weight' => 0.4,
        ],
        'counter_180' => [
            'name' => 'Contra-Precesión',
            'degrees' => 180,
            'description' => 'Efectos inversos y de retroalimentación',
            'temporal_lag_months' => [36, 120],
            'weight' => 0.2,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Scheduled Jobs
    |--------------------------------------------------------------------------
    |
    | Configuración de jobs programados.
    |
    */

    'schedule' => [
        'daily_analysis' => [
            'enabled' => true,
            'time' => '02:00',
            'batch_size' => 50,
            'priority' => 'low',
        ],
        'cleanup' => [
            'enabled' => true,
            'day' => 'sunday',
            'time' => '04:00',
            'retention_days' => 30,
            'alert_retention_days' => 90,
        ],
        'daily_summary' => [
            'enabled' => true,
            'time' => '08:00',
        ],
        'expiring_alerts_check' => [
            'enabled' => true,
            'interval' => 'everySixHours',
        ],
        'metrics_update' => [
            'enabled' => true,
            'interval' => 'hourly',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Notifications
    |--------------------------------------------------------------------------
    |
    | Configuración de notificaciones.
    |
    */

    'notifications' => [
        'channels' => [
            'database' => true,
            'mail' => true,
            'slack' => env('PAE_SLACK_ENABLED', false),
        ],
        
        'slack' => [
            'webhook' => env('PAE_SLACK_WEBHOOK', ''),
            'channel' => env('PAE_SLACK_CHANNEL', '#pae-alerts'),
        ],
        
        'mail' => [
            'from' => env('PAE_MAIL_FROM', 'pae@datapolis.cl'),
            'name' => env('PAE_MAIL_FROM_NAME', 'DATAPOLIS PAE'),
        ],
        
        'severity_channels' => [
            'critical' => ['database', 'mail', 'slack'],
            'high' => ['database', 'mail'],
            'medium' => ['database'],
            'low' => ['database'],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Integrations
    |--------------------------------------------------------------------------
    |
    | Configuración de integraciones con servicios externos.
    |
    */

    'integrations' => [
        'sii' => [
            'enabled' => env('PAE_SII_ENABLED', false),
            'api_url' => env('SII_API_URL', ''),
            'rut' => env('SII_RUT', ''),
            'clave' => env('SII_CLAVE', ''),
        ],
        'cbr' => [
            'enabled' => env('PAE_CBR_ENABLED', false),
            'api_url' => env('CBR_API_URL', ''),
        ],
        'bcch' => [
            'enabled' => env('PAE_BCCH_ENABLED', true),
            'api_url' => 'https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | ML Configuration
    |--------------------------------------------------------------------------
    |
    | Configuración de modelos de machine learning.
    |
    */

    'ml' => [
        'enabled' => env('PAE_ML_ENABLED', true),
        'model_version' => 'v1.0',
        'features' => [
            'location', 'financial', 'compliance', 'building',
            'market', 'temporal', 'contextual',
        ],
        'horizons' => [12, 24, 36, 60], // meses
        'confidence_threshold' => 0.6,
    ],

    /*
    |--------------------------------------------------------------------------
    | Spatial Configuration (PostGIS)
    |--------------------------------------------------------------------------
    |
    | Configuración de análisis espacial.
    |
    */

    'spatial' => [
        'srid' => 4326,
        'default_radius' => 1000, // metros
        'influence_zones' => [300, 500, 1000, 2000, 5000], // metros
        'heatmap_resolution' => 100, // metros
    ],

    /*
    |--------------------------------------------------------------------------
    | Performance
    |--------------------------------------------------------------------------
    |
    | Configuración de rendimiento.
    |
    */

    'performance' => [
        'max_concurrent_analyses' => 10,
        'queue_name' => 'pae',
        'job_timeout' => 120,
        'job_tries' => 3,
        'job_backoff' => [30, 60, 120],
    ],

    /*
    |--------------------------------------------------------------------------
    | Logging
    |--------------------------------------------------------------------------
    |
    | Configuración de logging.
    |
    */

    'logging' => [
        'channel' => env('PAE_LOG_CHANNEL', 'stack'),
        'level' => env('PAE_LOG_LEVEL', 'info'),
        'detailed' => env('PAE_LOG_DETAILED', false),
    ],

];
