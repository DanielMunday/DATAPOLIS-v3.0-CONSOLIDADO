<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tablas auxiliares para integración PAE M11 con módulos DATAPOLIS
 * 
 * Almacenan métricas calculadas, proyecciones y estadísticas
 * generadas por los listeners de integración.
 */
return new class extends Migration
{
    public function up(): void
    {
        // =========================================================
        // MÉTRICAS CONSOLIDADAS POR COPROPIEDAD
        // =========================================================
        Schema::create('copropiedad_metrics', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->unique()->constrained()->cascadeOnDelete();
            
            // Métricas tributarias (M04)
            $table->decimal('tax_risk_score', 5, 4)->nullable();
            $table->decimal('tax_projected_load_12m', 14, 2)->nullable();
            $table->decimal('tax_compliance_rate', 5, 2)->nullable();
            
            // Métricas gastos (M05)
            $table->decimal('expense_avg_monthly', 12, 2)->nullable();
            $table->string('expense_trend_direction', 20)->nullable();
            $table->decimal('expense_trend_percentage', 6, 2)->nullable();
            $table->string('expense_volatility_level', 20)->nullable();
            
            // Métricas compliance (M06)
            $table->decimal('compliance_score_global', 5, 2)->nullable();
            $table->decimal('compliance_ds7_score', 5, 2)->nullable();
            $table->string('compliance_ley21442_status', 30)->nullable();
            $table->integer('compliance_gaps_count')->default(0);
            $table->integer('compliance_critical_gaps')->default(0);
            
            // Métricas alícuotas (M07)
            $table->decimal('aliquot_gini', 5, 4)->nullable();
            $table->decimal('aliquot_revaluation_pct', 6, 2)->nullable();
            $table->date('aliquot_revaluation_date')->nullable();
            
            // Métricas valorización (M08)
            $table->decimal('valuation_current_uf', 12, 2)->nullable();
            $table->decimal('valuation_12m_uf', 12, 2)->nullable();
            $table->decimal('valuation_60m_uf', 12, 2)->nullable();
            $table->decimal('valuation_appreciation_60m', 6, 2)->nullable();
            $table->decimal('valuation_confidence', 5, 4)->nullable();
            
            // Métricas arriendos (M16)
            $table->integer('rental_active_count')->default(0);
            $table->decimal('rental_avg_monthly', 12, 2)->nullable();
            $table->decimal('rental_price_m2', 8, 2)->nullable();
            $table->decimal('rental_vacancy_rate', 5, 2)->nullable();
            $table->decimal('rental_gross_yield', 5, 2)->nullable();
            $table->decimal('rental_net_yield', 5, 2)->nullable();
            
            // Scores PAE agregados
            $table->decimal('pae_precession_score', 5, 2)->nullable();
            $table->decimal('pae_risk_score', 5, 4)->nullable();
            $table->decimal('pae_opportunity_score', 5, 4)->nullable();
            $table->timestamp('pae_last_analysis')->nullable();
            
            $table->timestamps();
            
            $table->index('tax_risk_score');
            $table->index('compliance_score_global');
            $table->index('pae_precession_score');
        });

        // =========================================================
        // PROYECCIONES DE GASTOS
        // =========================================================
        Schema::create('expense_forecasts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->unique()->constrained()->cascadeOnDelete();
            
            $table->json('forecast_12m')->nullable();
            $table->json('forecast_36m')->nullable();
            $table->json('seasonality_indices')->nullable();
            $table->string('trend_direction', 20)->nullable();
            $table->decimal('trend_percentage', 6, 2)->nullable();
            
            $table->timestamps();
        });

        // =========================================================
        // PROYECCIONES DE ALÍCUOTAS
        // =========================================================
        Schema::create('aliquot_projections', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->unique()->constrained()->cascadeOnDelete();
            
            $table->decimal('current_gini', 5, 4)->nullable();
            $table->string('revaluation_date', 10)->nullable();
            $table->decimal('revaluation_variation', 6, 2)->nullable();
            $table->decimal('affected_units_pct', 5, 2)->nullable();
            
            $table->timestamps();
        });

        // =========================================================
        // VALORIZACIONES PRECESIONALES
        // =========================================================
        Schema::create('precession_valuations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->unique()->constrained()->cascadeOnDelete();
            
            $table->decimal('current_value_uf', 12, 2)->nullable();
            $table->decimal('valuation_12m', 12, 2)->nullable();
            $table->decimal('valuation_24m', 12, 2)->nullable();
            $table->decimal('valuation_36m', 12, 2)->nullable();
            $table->decimal('valuation_60m', 12, 2)->nullable();
            $table->decimal('appreciation_60m_pct', 6, 2)->nullable();
            $table->decimal('confidence', 5, 4)->nullable();
            $table->json('main_factors')->nullable();
            
            $table->timestamps();
            
            $table->index('appreciation_60m_pct');
        });

        // =========================================================
        // MÉTRICAS DE ARRIENDOS
        // =========================================================
        Schema::create('rental_metrics', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->unique()->constrained()->cascadeOnDelete();
            
            $table->integer('active_rentals')->default(0);
            $table->decimal('average_rental', 12, 2)->nullable();
            $table->decimal('price_per_m2', 8, 2)->nullable();
            $table->decimal('vacancy_rate', 5, 2)->nullable();
            $table->decimal('forecast_12m', 12, 2)->nullable();
            $table->decimal('forecast_36m', 12, 2)->nullable();
            $table->decimal('gross_yield', 5, 2)->nullable();
            $table->decimal('net_yield', 5, 2)->nullable();
            $table->decimal('payback_years', 5, 1)->nullable();
            
            $table->timestamps();
            
            $table->index('vacancy_rate');
            $table->index('gross_yield');
        });

        // =========================================================
        // ESTADÍSTICAS PAE
        // =========================================================
        Schema::create('pae_statistics', function (Blueprint $table) {
            $table->id();
            $table->date('date')->unique();
            $table->unsignedInteger('tenant_id')->nullable();
            
            $table->integer('analyses_completed')->default(0);
            $table->integer('analyses_failed')->default(0);
            $table->integer('alerts_triggered')->default(0);
            $table->integer('alerts_resolved')->default(0);
            $table->integer('critical_alerts')->default(0);
            $table->decimal('total_execution_time', 10, 2)->default(0);
            $table->decimal('avg_execution_time', 8, 2)->nullable();
            
            $table->decimal('avg_precession_score', 5, 2)->nullable();
            $table->decimal('avg_risk_score', 5, 4)->nullable();
            $table->decimal('avg_opportunity_score', 5, 4)->nullable();
            
            $table->timestamps();
            
            $table->index(['date', 'tenant_id']);
        });

        // =========================================================
        // LOG DE CAMBIOS EN MÓDULOS
        // =========================================================
        Schema::create('pae_module_changes', function (Blueprint $table) {
            $table->id();
            $table->string('module_name', 50);
            $table->string('entity_type', 100);
            $table->unsignedBigInteger('entity_id');
            $table->unsignedBigInteger('copropiedad_id')->nullable();
            $table->string('change_type', 20);
            $table->json('changed_attributes')->nullable();
            $table->boolean('triggered_analysis')->default(false);
            $table->timestamp('created_at');
            
            $table->index(['module_name', 'created_at']);
            $table->index(['copropiedad_id', 'created_at']);
        });

        // =========================================================
        // COLA DE ANÁLISIS PENDIENTES
        // =========================================================
        Schema::create('pae_pending_analyses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
            $table->string('reason', 100);
            $table->string('priority', 20)->default('low');
            $table->integer('changes_count')->default(1);
            $table->json('reasons')->nullable();
            $table->timestamp('scheduled_at');
            $table->timestamp('dispatched_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->string('status', 20)->default('pending');
            $table->timestamps();
            
            $table->index(['status', 'scheduled_at']);
            $table->index(['copropiedad_id', 'status']);
        });

        // =========================================================
        // TABLAS AUXILIARES PARA MÓDULOS (si no existen)
        // =========================================================
        
        // Declaraciones Juradas (M04)
        if (!Schema::hasTable('declaraciones_juradas')) {
            Schema::create('declaraciones_juradas', function (Blueprint $table) {
                $table->id();
                $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
                $table->string('tipo', 20); // DJ1879, DJ1907
                $table->string('periodo', 10); // YYYY
                $table->decimal('monto_informado', 14, 2)->nullable();
                $table->decimal('monto_rentas', 14, 2)->nullable();
                $table->decimal('monto_retenciones', 14, 2)->nullable();
                $table->string('estado', 30)->default('pendiente');
                $table->date('fecha_presentacion')->nullable();
                $table->date('fecha_vencimiento')->nullable();
                $table->timestamps();
                
                $table->unique(['copropiedad_id', 'tipo', 'periodo']);
            });
        }

        // Ingresos Copropiedad (M04)
        if (!Schema::hasTable('ingresos_copropiedad')) {
            Schema::create('ingresos_copropiedad', function (Blueprint $table) {
                $table->id();
                $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
                $table->string('tipo', 50); // antena, arriendo_comun, publicidad
                $table->string('descripcion')->nullable();
                $table->decimal('monto_mensual', 12, 2);
                $table->boolean('gravado_renta')->default(true);
                $table->boolean('afecto_iva')->default(false);
                $table->date('fecha_inicio');
                $table->date('fecha_termino')->nullable();
                $table->string('estado', 20)->default('activo');
                $table->timestamps();
            });
        }

        // Pagos PPM (M04)
        if (!Schema::hasTable('pagos_ppm')) {
            Schema::create('pagos_ppm', function (Blueprint $table) {
                $table->id();
                $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
                $table->string('periodo', 10); // YYYY-MM
                $table->decimal('base_imponible', 14, 2);
                $table->decimal('tasa', 5, 4)->default(0.03);
                $table->decimal('monto', 12, 2);
                $table->string('estado', 20)->default('pendiente');
                $table->date('fecha_pago')->nullable();
                $table->timestamps();
                
                $table->unique(['copropiedad_id', 'periodo']);
            });
        }

        // Formulario 29 (M04)
        if (!Schema::hasTable('formularios_29')) {
            Schema::create('formularios_29', function (Blueprint $table) {
                $table->id();
                $table->foreignId('copropiedad_id')->constrained()->cascadeOnDelete();
                $table->string('periodo', 10); // YYYY-MM
                $table->decimal('debito_fiscal', 12, 2)->default(0);
                $table->decimal('credito_fiscal', 12, 2)->default(0);
                $table->decimal('saldo_a_pagar', 12, 2)->default(0);
                $table->string('estado', 20)->default('pendiente');
                $table->date('fecha_presentacion')->nullable();
                $table->timestamps();
                
                $table->unique(['copropiedad_id', 'periodo']);
            });
        }

        // Transacciones CBR (M08)
        if (!Schema::hasTable('transacciones_cbr')) {
            Schema::create('transacciones_cbr', function (Blueprint $table) {
                $table->id();
                $table->string('fojas', 50)->nullable();
                $table->string('numero_inscripcion', 50)->nullable();
                $table->integer('ano_inscripcion');
                $table->string('comuna', 100);
                $table->string('tipo_operacion', 50); // compraventa, hipoteca, etc
                $table->decimal('valor', 14, 2)->nullable();
                $table->decimal('superficie_m2', 10, 2)->nullable();
                $table->decimal('valor_m2', 10, 2)->nullable();
                $table->decimal('latitud', 10, 7)->nullable();
                $table->decimal('longitud', 10, 7)->nullable();
                $table->date('fecha');
                $table->timestamps();
                
                $table->index(['comuna', 'fecha']);
                $table->index(['latitud', 'longitud']);
            });
        }

        // Arriendos Mercado (M08/M16)
        if (!Schema::hasTable('arriendos_mercado')) {
            Schema::create('arriendos_mercado', function (Blueprint $table) {
                $table->id();
                $table->string('comuna', 100);
                $table->string('tipo', 50); // departamento, casa, oficina
                $table->decimal('precio_mensual', 12, 2);
                $table->decimal('superficie_m2', 10, 2);
                $table->decimal('precio_m2', 8, 2);
                $table->integer('dormitorios')->nullable();
                $table->integer('banos')->nullable();
                $table->string('fuente', 50)->nullable();
                $table->date('fecha_publicacion');
                $table->timestamps();
                
                $table->index(['comuna', 'tipo', 'fecha_publicacion']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('pae_pending_analyses');
        Schema::dropIfExists('pae_module_changes');
        Schema::dropIfExists('pae_statistics');
        Schema::dropIfExists('rental_metrics');
        Schema::dropIfExists('precession_valuations');
        Schema::dropIfExists('aliquot_projections');
        Schema::dropIfExists('expense_forecasts');
        Schema::dropIfExists('copropiedad_metrics');
        
        // No eliminar tablas de módulos existentes
        // Schema::dropIfExists('arriendos_mercado');
        // Schema::dropIfExists('transacciones_cbr');
        // Schema::dropIfExists('formularios_29');
        // Schema::dropIfExists('pagos_ppm');
        // Schema::dropIfExists('ingresos_copropiedad');
        // Schema::dropIfExists('declaraciones_juradas');
    }
};
