# PAE M11 - Fase 2: Integración con Módulos DATAPOLIS

## Resumen de Integración

Esta documentación describe la integración del **Precession Analytics Engine (PAE) M11** con los módulos existentes de DATAPOLIS v3.0, permitiendo que el PAE consuma datos de múltiples fuentes y alimente predicciones a otros módulos.

## Arquitectura de Integración

```
┌─────────────────────────────────────────────────────────────────────┐
│                        DATAPOLIS v3.0                               │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                    CAPA DE PRESENTACIÓN                       │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐    │   │
│  │  │ PAEDashboard │  │  PAEAlerts   │  │   PAECompare     │    │   │
│  │  └──────────────┘  └──────────────┘  └──────────────────┘    │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                                │                                    │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                     PAE M11 CORE                              │   │
│  │  ┌─────────────────────┐  ┌─────────────────────────────┐    │   │
│  │  │  PrecessionService  │  │  PrecessionContextBuilder   │    │   │
│  │  │  - analyzeCopropiedad│  │  - buildTaxContext()       │    │   │
│  │  │  - calculateScore    │  │  - buildExpenseContext()   │    │   │
│  │  │  - comparePrecession │  │  - buildComplianceContext()│    │   │
│  │  └─────────────────────┘  │  - buildValuationContext() │    │   │
│  │                           │  - buildRentalContext()     │    │   │
│  │                           └─────────────────────────────┘    │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                                │                                    │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                    CAPA DE EVENTOS                            │   │
│  │  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐  │   │
│  │  │PrecessionObserver│ │IntegrationEvents│ │IntegrationListeners│ │
│  │  │ - Detecta cambios│ │ - TaxRiskUpdated│ │ - HandleTaxRisk│  │   │
│  │  │ - Dispara jobs   │ │ - ExpenseForecast││ - HandleCompliance│ │
│  │  │                  │ │ - ComplianceAlert││ - HandleValuation│ │   │
│  │  └────────────────┘  └────────────────┘  └────────────────┘  │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                                │                                    │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │               MÓDULOS DATAPOLIS INTEGRADOS                    │   │
│  │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐      │   │
│  │  │  M04   │ │  M05   │ │  M06   │ │  M07   │ │  M08   │      │   │
│  │  │Tributa-│ │ Gastos │ │Compli- │ │Alícuo- │ │Valori- │      │   │
│  │  │rio     │ │Comunes │ │ance    │ │tas     │ │zación  │      │   │
│  │  └────────┘ └────────┘ └────────┘ └────────┘ └────────┘      │   │
│  │                     ┌────────┐                                │   │
│  │                     │  M16   │                                │   │
│  │                     │Arriendos│                               │   │
│  │                     └────────┘                                │   │
│  └──────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

## Módulos Integrados

### M04 - Tributario

**Datos Consumidos:**
- DJ 1879 (arriendos informados)
- DJ 1907 (retenciones)
- PPM (pagos provisionales mensuales)
- F29 (formulario IVA)

**Datos Generados:**
- Score de riesgo tributario
- Proyección de carga tributaria 12-36 meses
- Tasa de cumplimiento tributario

**Evento:** `precession.tax_risk_updated`

**Método:** `PrecessionContextBuilder::buildTaxContext()`

### M05 - Gastos Comunes

**Datos Consumidos:**
- Histórico de gastos (36 meses)
- Desglose por categoría
- Fechas de cobro/pago

**Datos Generados:**
- Tendencia (creciente/decreciente/estable)
- Índices de estacionalidad
- Proyección 12-36 meses con intervalo de confianza
- Nivel de volatilidad

**Evento:** `precession.expense_forecast`

**Método:** `PrecessionContextBuilder::buildExpenseContext()`

### M06 - Compliance DS7-2025

**Datos Consumidos:**
- Estado de requisitos DS7
- Estado Ley 21.442
- Brechas detectadas
- Fechas límite

**Datos Generados:**
- Score global de compliance
- Lista de brechas críticas
- Probabilidad de cambio normativo
- Recomendaciones priorizadas

**Evento:** `precession.compliance_alert`

**Método:** `PrecessionContextBuilder::buildComplianceContext()`

### M07 - Alícuotas Ley 21.442

**Datos Consumidos:**
- Distribución actual de alícuotas
- Ponderadores (superficie, avalúo, uso)
- Avalúos SII por unidad

**Datos Generados:**
- Coeficiente de Gini
- Proyección de revalúo
- Unidades afectadas (%)
- Impacto en distribución

**Evento:** `precession.aliquot_projection`

**Método:** `PrecessionContextBuilder::buildAliquotContext()`

### M08 - Valorización

**Datos Consumidos:**
- Avalúo fiscal SII
- Transacciones CBR (radio 1km)
- Arriendos comparables
- Cap rate zona

**Datos Generados:**
- Valorización precesional 12-60 meses
- Factores principales de apreciación
- Ratio avalúo/mercado
- Gross yield

**Evento:** `precession.valuation_updated`

**Método:** `PrecessionContextBuilder::buildValuationContext()`

### M16 - Arriendos

**Datos Consumidos:**
- Arriendos activos
- Precio por m²
- Tasa de vacancia
- Duración promedio contratos

**Datos Generados:**
- Proyección de arriendo 12-36 meses
- Ajuste precesional
- Gross/Net yield
- Payback en años

**Evento:** `precession.rental_forecast`

**Método:** `PrecessionContextBuilder::buildRentalContext()`

## Componentes de Integración

### PrecessionObserver

Observa cambios en modelos de todos los módulos integrados y dispara re-cálculo precesional cuando los cambios son significativos.

**Modelos Observados:**
- `Copropiedad`
- `Unidad`
- `DeclaracionJurada`
- `PagoPPM`
- `Formulario29`
- `GastoComun`
- `ComplianceRecord`
- `Alicuota`
- `Avaluo`
- `TransaccionCBR`
- `Arriendo`

**Características:**
- Debounce de 5 minutos para evitar análisis repetidos
- Detección de cambios significativos vs no significativos
- Priorización (high/medium/low) según tipo de cambio
- Batch cuando hay múltiples cambios simultáneos

### Jobs Programados

| Job | Frecuencia | Descripción |
|-----|------------|-------------|
| `ScheduledPrecessionAnalysis` | Diario 02:00 | Análisis para copropiedades sin análisis reciente |
| `CleanupExpiredAnalyses` | Semanal Dom 04:00 | Limpieza de análisis >30 días |
| `DailyPAESummary` | Diario 08:00 | Resumen por email a admins |
| `CheckExpiringAlerts` | Cada 6 horas | Notifica alertas próximas a expirar |
| `UpdateConsolidatedMetrics` | Cada hora | Actualiza métricas agregadas |

### Eventos y Listeners

```
PrecessionTaxRiskUpdated
    └── HandleTaxRiskUpdated
        ├── Crear PrecessionAlert si riesgo > 0.7
        ├── Notificar administradores
        └── Actualizar copropiedad_metrics

PrecessionExpenseForecast
    └── HandleExpenseForecast
        ├── Crear alerta si tendencia > 15%
        └── Guardar en expense_forecasts

PrecessionComplianceAlert
    └── HandleComplianceAlert
        ├── Crear alerta (siempre)
        ├── Notificación urgente si crítico
        └── Actualizar métricas

PrecessionAliquotProjection
    └── HandleAliquotProjection
        ├── Crear alerta si variación > 10%
        └── Guardar en aliquot_projections

PrecessionValuationUpdated
    └── HandleValuationUpdated
        ├── Crear alerta si apreciación < -5% o > 50%
        ├── Notificar oportunidades significativas
        └── Guardar en precession_valuations

PrecessionRentalForecast
    └── HandleRentalForecast
        ├── Crear alerta si vacancia > 15% o yield < 4%
        └── Guardar en rental_metrics
```

### Notificaciones

| Notificación | Canales | Trigger |
|--------------|---------|---------|
| `TaxRiskNotification` | DB, Mail, Slack | Risk score > 0.7 |
| `ComplianceAlertNotification` | DB, Mail, Slack | Brechas críticas |
| `ValuationUpdateNotification` | DB, Mail | Oportunidad > 30% |
| `HighPriorityAlertNotification` | DB, Mail | Cualquier alerta alta/crítica |
| `DailyPAESummaryNotification` | DB, Mail | Programado diario |

## Tablas de Base de Datos

### Tablas de Métricas

| Tabla | Descripción |
|-------|-------------|
| `copropiedad_metrics` | Métricas consolidadas por copropiedad |
| `expense_forecasts` | Proyecciones de gastos comunes |
| `aliquot_projections` | Proyecciones de revalúo alícuotas |
| `precession_valuations` | Valorizaciones precesionales |
| `rental_metrics` | Métricas de arriendos |
| `pae_statistics` | Estadísticas diarias del sistema |
| `pae_module_changes` | Log de cambios en módulos |
| `pae_pending_analyses` | Cola de análisis pendientes |

### Tablas Auxiliares

| Tabla | Descripción |
|-------|-------------|
| `declaraciones_juradas` | DJ 1879, DJ 1907 |
| `ingresos_copropiedad` | Ingresos gravados (antenas, etc.) |
| `pagos_ppm` | Pagos provisionales mensuales |
| `formularios_29` | F29 IVA |
| `transacciones_cbr` | Transacciones CBR |
| `arriendos_mercado` | Arriendos de mercado para comparables |

## Comandos Artisan

```bash
# Analizar copropiedad específica
php artisan pae:analyze 123

# Analizar todas las copropiedades
php artisan pae:analyze --all

# Analizar con filtros
php artisan pae:analyze --all --tenant=1 --comuna=Santiago

# Ver estadísticas
php artisan pae:stats --days=30

# Gestionar alertas
php artisan pae:alerts list --status=active
php artisan pae:alerts resolve --id=456
php artisan pae:alerts cleanup

# Reconstruir ontología
php artisan pae:rebuild-ontology --fresh

# Exportar análisis
php artisan pae:export --format=csv --days=30
```

## Configuración

### Variables de Entorno

```env
# PAE Core API
PAE_API_URL=http://localhost:8000/api/v1/pae
PAE_API_KEY=your-api-key
PAE_HTTP_TIMEOUT=30

# Cache TTL
PAE_CACHE_TTL_ANALYSIS=3600
PAE_CACHE_TTL_SCORING=86400
PAE_CACHE_TTL_HOURS=24

# Fallback
PAE_FALLBACK_ENABLED=true

# Notificaciones
PAE_SLACK_WEBHOOK=https://hooks.slack.com/services/xxx
```

### config/datapolis.php

```php
'pae' => [
    'api_url' => env('PAE_API_URL'),
    'api_key' => env('PAE_API_KEY'),
    'http_timeout' => 30,
    
    'cache_ttl_analysis' => 3600,
    'cache_ttl_scoring' => 86400,
    
    'fallback_enabled' => true,
    
    'defaults' => [
        'radius_meters' => 1000,
        'time_horizon_months' => 36,
        'max_depth' => 4,
    ],
    
    'alert_thresholds' => [
        'risk_critical' => 0.85,
        'risk_high' => 0.7,
        'opportunity_exceptional' => 0.85,
    ],
    
    'observer' => [
        'debounce_seconds' => 300,
        'batch_threshold' => 5,
    ],
],
```

## Instalación

### 1. Ejecutar Migraciones

```bash
php artisan migrate
```

### 2. Registrar Providers

En `config/app.php`:

```php
'providers' => [
    // ...
    App\Providers\EventServiceProvider::class,
],
```

### 3. Cargar Ontología

```bash
php artisan pae:rebuild-ontology
```

### 4. Configurar Queue Worker

```bash
php artisan queue:work --queue=pae,default
```

### 5. Configurar Scheduler

En crontab:

```
* * * * * cd /path-to-project && php artisan schedule:run >> /dev/null 2>&1
```

## Tests

```bash
# Ejecutar todos los tests PAE
php artisan test --filter=PAE

# Tests de integración
php artisan test --filter=PrecessionIntegration

# Tests de context builder
php artisan test --filter=PrecessionContextBuilder
```

## Flujo de Datos Completo

```
1. Usuario actualiza datos en módulo (ej: nuevo gasto común)
                    ↓
2. PrecessionObserver detecta cambio significativo
                    ↓
3. Se encola TriggerPrecessionAnalysis con debounce
                    ↓
4. Job ejecuta PrecessionService::analyzeCopropiedad()
                    ↓
5. PrecessionContextBuilder construye contexto de todos los módulos
                    ↓
6. Se llama a PAE Core API (o fallback local)
                    ↓
7. Se guarda PrecessionAnalysis en BD
                    ↓
8. Se disparan eventos de integración según umbrales
                    ↓
9. Listeners procesan eventos:
   - Crean PrecessionAlert si corresponde
   - Actualizan tablas de métricas
   - Envían notificaciones
                    ↓
10. Frontend recibe actualizaciones via WebSocket
```

## Métricas de Rendimiento

| Métrica | Objetivo | Actual |
|---------|----------|--------|
| Tiempo análisis | < 30s | ~15s |
| Throughput diario | 1000 análisis | Variable |
| Cache hit rate | > 80% | ~85% |
| Tasa de éxito | > 95% | ~98% |
| Latencia notificaciones | < 5s | ~2s |

---

*PAE M11 - Fase 2 Integración*
*DATAPOLIS SpA © 2025*
