<template>
    <div class="pae-integration-metrics">
        <!-- Header -->
        <div class="flex justify-between items-center mb-6">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">
                    Métricas Integradas PAE
                </h2>
                <p class="text-gray-600 text-sm">
                    {{ copropiedad?.nombre || 'Cargando...' }}
                </p>
            </div>
            <div class="flex gap-2">
                <Button 
                    icon="pi pi-refresh" 
                    label="Actualizar" 
                    class="p-button-outlined"
                    :loading="loading"
                    @click="loadMetrics"
                />
                <Button 
                    icon="pi pi-download" 
                    label="Exportar" 
                    class="p-button-success"
                    @click="exportMetrics"
                />
            </div>
        </div>

        <!-- Loading -->
        <div v-if="loading" class="flex justify-center items-center py-12">
            <ProgressSpinner />
        </div>

        <!-- Metrics Grid -->
        <div v-else-if="metrics" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            <!-- PAE Scores Card -->
            <Card class="shadow-lg">
                <template #header>
                    <div class="bg-gradient-to-r from-purple-600 to-indigo-600 p-4 rounded-t-lg">
                        <h3 class="text-white font-semibold flex items-center gap-2">
                            <i class="pi pi-chart-line"></i>
                            Scores PAE
                        </h3>
                    </div>
                </template>
                <template #content>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Precession Score</span>
                            <span class="text-2xl font-bold" :class="getScoreColor(metrics.pae?.precession_score)">
                                {{ formatNumber(metrics.pae?.precession_score, 1) }}
                            </span>
                        </div>
                        <ProgressBar 
                            :value="metrics.pae?.precession_score" 
                            :showValue="false"
                            :class="getProgressColor(metrics.pae?.precession_score)"
                        />
                        
                        <div class="grid grid-cols-2 gap-4 pt-4 border-t">
                            <div class="text-center">
                                <div class="text-sm text-gray-500">Risk</div>
                                <div class="text-lg font-semibold text-red-600">
                                    {{ formatPercent(metrics.pae?.risk_score) }}
                                </div>
                            </div>
                            <div class="text-center">
                                <div class="text-sm text-gray-500">Opportunity</div>
                                <div class="text-lg font-semibold text-green-600">
                                    {{ formatPercent(metrics.pae?.opportunity_score) }}
                                </div>
                            </div>
                        </div>
                        
                        <div class="text-xs text-gray-400 text-right">
                            Último análisis: {{ formatDate(metrics.pae?.last_analysis) }}
                        </div>
                    </div>
                </template>
            </Card>

            <!-- Tax Card (M04) -->
            <Card class="shadow-lg">
                <template #header>
                    <div class="bg-gradient-to-r from-red-500 to-orange-500 p-4 rounded-t-lg">
                        <h3 class="text-white font-semibold flex items-center gap-2">
                            <i class="pi pi-calculator"></i>
                            Tributario (M04)
                        </h3>
                    </div>
                </template>
                <template #content>
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Riesgo Tributario</span>
                            <Tag :severity="getRiskSeverity(metrics.tax?.risk_score)">
                                {{ formatPercent(metrics.tax?.risk_score) }}
                            </Tag>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Carga 12m</span>
                            <span class="font-semibold">
                                {{ formatUF(metrics.tax?.projected_load_12m) }} UF
                            </span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Cumplimiento</span>
                            <span :class="metrics.tax?.compliance_rate >= 90 ? 'text-green-600' : 'text-yellow-600'">
                                {{ formatPercent(metrics.tax?.compliance_rate / 100) }}
                            </span>
                        </div>
                        <Button 
                            label="Ver Detalle" 
                            icon="pi pi-arrow-right" 
                            class="p-button-text p-button-sm w-full"
                            @click="showModuleDetail('tax')"
                        />
                    </div>
                </template>
            </Card>

            <!-- Expenses Card (M05) -->
            <Card class="shadow-lg">
                <template #header>
                    <div class="bg-gradient-to-r from-blue-500 to-cyan-500 p-4 rounded-t-lg">
                        <h3 class="text-white font-semibold flex items-center gap-2">
                            <i class="pi pi-wallet"></i>
                            Gastos Comunes (M05)
                        </h3>
                    </div>
                </template>
                <template #content>
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Promedio Mensual</span>
                            <span class="font-semibold">
                                {{ formatCurrency(metrics.expenses?.avg_monthly) }}
                            </span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Tendencia</span>
                            <div class="flex items-center gap-1">
                                <i :class="getTrendIcon(metrics.expenses?.trend_direction)"></i>
                                <span :class="getTrendColor(metrics.expenses?.trend_percentage)">
                                    {{ formatTrend(metrics.expenses?.trend_percentage) }}
                                </span>
                            </div>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Volatilidad</span>
                            <Tag :severity="getVolatilitySeverity(metrics.expenses?.volatility_level)">
                                {{ metrics.expenses?.volatility_level || 'N/A' }}
                            </Tag>
                        </div>
                        <Button 
                            label="Ver Proyección" 
                            icon="pi pi-chart-bar" 
                            class="p-button-text p-button-sm w-full"
                            @click="showModuleDetail('expenses')"
                        />
                    </div>
                </template>
            </Card>

            <!-- Compliance Card (M06) -->
            <Card class="shadow-lg">
                <template #header>
                    <div class="bg-gradient-to-r from-green-500 to-teal-500 p-4 rounded-t-lg">
                        <h3 class="text-white font-semibold flex items-center gap-2">
                            <i class="pi pi-verified"></i>
                            Compliance (M06)
                        </h3>
                    </div>
                </template>
                <template #content>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Score Global</span>
                            <Knob 
                                v-model="complianceScore" 
                                :size="60" 
                                readonly
                                :valueColor="getKnobColor(metrics.compliance?.score_global)"
                            />
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">DS7-2025</span>
                            <span class="font-semibold">
                                {{ formatNumber(metrics.compliance?.ds7_score, 1) }}/100
                            </span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Ley 21.442</span>
                            <Tag :severity="getLey21442Severity(metrics.compliance?.ley21442_status)">
                                {{ metrics.compliance?.ley21442_status || 'Pendiente' }}
                            </Tag>
                        </div>
                        <div v-if="metrics.compliance?.critical_gaps > 0" class="p-2 bg-red-50 rounded text-red-700 text-sm">
                            <i class="pi pi-exclamation-triangle mr-1"></i>
                            {{ metrics.compliance?.critical_gaps }} brechas críticas
                        </div>
                        <Button 
                            label="Ver Brechas" 
                            icon="pi pi-list" 
                            class="p-button-text p-button-sm w-full"
                            @click="showModuleDetail('compliance')"
                        />
                    </div>
                </template>
            </Card>

            <!-- Valuation Card (M08) -->
            <Card class="shadow-lg">
                <template #header>
                    <div class="bg-gradient-to-r from-yellow-500 to-amber-500 p-4 rounded-t-lg">
                        <h3 class="text-white font-semibold flex items-center gap-2">
                            <i class="pi pi-home"></i>
                            Valorización (M08)
                        </h3>
                    </div>
                </template>
                <template #content>
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Valor Actual</span>
                            <span class="font-semibold">
                                {{ formatUF(metrics.valuation?.current_uf) }} UF
                            </span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Proyección 60m</span>
                            <span class="font-semibold">
                                {{ formatUF(metrics.valuation?.valuation_60m) }} UF
                            </span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Apreciación</span>
                            <span :class="metrics.valuation?.appreciation_60m >= 0 ? 'text-green-600' : 'text-red-600'" class="font-semibold">
                                {{ formatTrend(metrics.valuation?.appreciation_60m) }}
                            </span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Confianza</span>
                            <ProgressBar 
                                :value="(metrics.valuation?.confidence || 0) * 100" 
                                :showValue="true"
                                style="height: 8px; width: 100px;"
                            />
                        </div>
                        <Button 
                            label="Ver Proyección" 
                            icon="pi pi-chart-line" 
                            class="p-button-text p-button-sm w-full"
                            @click="showModuleDetail('valuation')"
                        />
                    </div>
                </template>
            </Card>

            <!-- Rental Card (M16) -->
            <Card class="shadow-lg">
                <template #header>
                    <div class="bg-gradient-to-r from-pink-500 to-rose-500 p-4 rounded-t-lg">
                        <h3 class="text-white font-semibold flex items-center gap-2">
                            <i class="pi pi-building"></i>
                            Arriendos (M16)
                        </h3>
                    </div>
                </template>
                <template #content>
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Arriendos Activos</span>
                            <span class="font-semibold">{{ metrics.rental?.active_count || 0 }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Arriendo Prom.</span>
                            <span class="font-semibold">
                                {{ formatCurrency(metrics.rental?.avg_monthly) }}
                            </span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Vacancia</span>
                            <Tag :severity="getVacancySeverity(metrics.rental?.vacancy_rate)">
                                {{ formatPercent(metrics.rental?.vacancy_rate / 100) }}
                            </Tag>
                        </div>
                        <div class="grid grid-cols-2 gap-2 pt-2 border-t">
                            <div class="text-center">
                                <div class="text-xs text-gray-500">Gross Yield</div>
                                <div class="font-semibold text-green-600">
                                    {{ formatPercent(metrics.rental?.gross_yield / 100) }}
                                </div>
                            </div>
                            <div class="text-center">
                                <div class="text-xs text-gray-500">Net Yield</div>
                                <div class="font-semibold text-blue-600">
                                    {{ formatPercent(metrics.rental?.net_yield / 100) }}
                                </div>
                            </div>
                        </div>
                        <Button 
                            label="Ver Análisis" 
                            icon="pi pi-chart-pie" 
                            class="p-button-text p-button-sm w-full"
                            @click="showModuleDetail('rental')"
                        />
                    </div>
                </template>
            </Card>
        </div>

        <!-- No Data -->
        <div v-else class="text-center py-12 text-gray-500">
            <i class="pi pi-info-circle text-4xl mb-4"></i>
            <p>No hay métricas disponibles para esta copropiedad.</p>
            <Button 
                label="Ejecutar Análisis" 
                icon="pi pi-play" 
                class="mt-4"
                @click="runAnalysis"
            />
        </div>

        <!-- Module Detail Dialog -->
        <Dialog 
            v-model:visible="detailDialogVisible" 
            :header="detailDialogTitle"
            :style="{ width: '700px' }"
            modal
        >
            <div v-if="moduleDetail">
                <pre class="bg-gray-100 p-4 rounded text-sm overflow-auto max-h-96">{{ JSON.stringify(moduleDetail, null, 2) }}</pre>
            </div>
            <template #footer>
                <Button label="Cerrar" icon="pi pi-times" @click="detailDialogVisible = false" />
            </template>
        </Dialog>
    </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import { useToast } from 'primevue/usetoast';
import axios from 'axios';

// PrimeVue Components
import Card from 'primevue/card';
import Button from 'primevue/button';
import Tag from 'primevue/tag';
import ProgressBar from 'primevue/progressbar';
import ProgressSpinner from 'primevue/progressspinner';
import Knob from 'primevue/knob';
import Dialog from 'primevue/dialog';

const props = defineProps({
    copropiedadId: {
        type: [Number, String],
        required: true,
    },
});

const emit = defineEmits(['analysis-requested']);

const toast = useToast();

// State
const loading = ref(false);
const metrics = ref(null);
const copropiedad = ref(null);
const detailDialogVisible = ref(false);
const detailDialogTitle = ref('');
const moduleDetail = ref(null);

// Computed
const complianceScore = computed(() => metrics.value?.compliance?.score_global || 0);

// Methods
const loadMetrics = async () => {
    loading.value = true;
    try {
        const response = await axios.get(`/api/v1/pae/metrics/${props.copropiedadId}`);
        metrics.value = response.data.data;
        
        // Load copropiedad info
        const copResponse = await axios.get(`/api/v1/copropiedades/${props.copropiedadId}`);
        copropiedad.value = copResponse.data.data;
    } catch (error) {
        console.error('Error loading metrics:', error);
        if (error.response?.status !== 404) {
            toast.add({
                severity: 'error',
                summary: 'Error',
                detail: 'No se pudieron cargar las métricas',
                life: 3000,
            });
        }
    } finally {
        loading.value = false;
    }
};

const showModuleDetail = async (module) => {
    const moduleNames = {
        tax: 'Contexto Tributario',
        expenses: 'Contexto Gastos Comunes',
        compliance: 'Contexto Compliance',
        aliquots: 'Contexto Alícuotas',
        valuation: 'Contexto Valorización',
        rental: 'Contexto Arriendos',
    };
    
    detailDialogTitle.value = moduleNames[module];
    
    try {
        const response = await axios.get(`/api/v1/pae/metrics/${props.copropiedadId}/${module}`);
        moduleDetail.value = response.data.data;
        detailDialogVisible.value = true;
    } catch (error) {
        toast.add({
            severity: 'error',
            summary: 'Error',
            detail: 'No se pudo cargar el detalle',
            life: 3000,
        });
    }
};

const runAnalysis = () => {
    emit('analysis-requested', props.copropiedadId);
};

const exportMetrics = () => {
    const dataStr = JSON.stringify(metrics.value, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pae_metrics_${props.copropiedadId}_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
};

// Formatters
const formatNumber = (value, decimals = 0) => {
    if (value === null || value === undefined) return 'N/A';
    return Number(value).toFixed(decimals);
};

const formatPercent = (value) => {
    if (value === null || value === undefined) return 'N/A';
    return `${(value * 100).toFixed(1)}%`;
};

const formatUF = (value) => {
    if (value === null || value === undefined) return 'N/A';
    return new Intl.NumberFormat('es-CL').format(Math.round(value));
};

const formatCurrency = (value) => {
    if (value === null || value === undefined) return 'N/A';
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(value);
};

const formatTrend = (value) => {
    if (value === null || value === undefined) return 'N/A';
    const sign = value >= 0 ? '+' : '';
    return `${sign}${value.toFixed(1)}%`;
};

const formatDate = (date) => {
    if (!date) return 'Nunca';
    return new Date(date).toLocaleDateString('es-CL', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
    });
};

// Styling helpers
const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
};

const getProgressColor = (score) => {
    if (score >= 80) return 'progress-green';
    if (score >= 60) return 'progress-yellow';
    return 'progress-red';
};

const getRiskSeverity = (risk) => {
    if (risk >= 0.7) return 'danger';
    if (risk >= 0.5) return 'warning';
    return 'success';
};

const getVolatilitySeverity = (level) => {
    if (level === 'alto') return 'danger';
    if (level === 'medio') return 'warning';
    return 'success';
};

const getVacancySeverity = (rate) => {
    if (rate >= 20) return 'danger';
    if (rate >= 10) return 'warning';
    return 'success';
};

const getLey21442Severity = (status) => {
    if (status === 'cumple') return 'success';
    if (status === 'parcial') return 'warning';
    return 'danger';
};

const getTrendIcon = (direction) => {
    if (direction === 'creciente') return 'pi pi-arrow-up text-red-500';
    if (direction === 'decreciente') return 'pi pi-arrow-down text-green-500';
    return 'pi pi-minus text-gray-500';
};

const getTrendColor = (percentage) => {
    if (percentage > 10) return 'text-red-600';
    if (percentage > 5) return 'text-yellow-600';
    if (percentage < 0) return 'text-green-600';
    return 'text-gray-600';
};

const getKnobColor = (score) => {
    if (score >= 80) return '#22c55e';
    if (score >= 60) return '#eab308';
    return '#ef4444';
};

// Watch for prop changes
watch(() => props.copropiedadId, loadMetrics);

// Lifecycle
onMounted(loadMetrics);
</script>

<style scoped>
.progress-green :deep(.p-progressbar-value) {
    background: linear-gradient(to right, #22c55e, #16a34a);
}

.progress-yellow :deep(.p-progressbar-value) {
    background: linear-gradient(to right, #eab308, #ca8a04);
}

.progress-red :deep(.p-progressbar-value) {
    background: linear-gradient(to right, #ef4444, #dc2626);
}
</style>
