<?php

/**
 * Rutas API para el módulo PAE M11 - Precession Analytics Engine
 * 
 * Incluir en routes/api.php:
 * require __DIR__ . '/pae.php';
 * 
 * @see PAE_Precession_Analytics_Engine_M11.docx Sección 4.3
 */

use App\Http\Controllers\Api\V1\PAE\PrecessionController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1/pae')->middleware(['auth:sanctum', 'tenant'])->group(function () {
    
    // =========================================================
    // ANÁLISIS PRECESIONALES
    // =========================================================
    
    /**
     * Ejecutar análisis precesional sobre una copropiedad
     * 
     * POST /api/v1/pae/analyze/copropiedad/{id}
     * 
     * Body:
     * - horizon: int (6-120 meses, default 36)
     * - radius: int (100-10000 metros, default 1000)
     * - max_depth: int (1-6, default 4)
     * - include_ml: bool (default true)
     * - generate_heatmap: bool (default true)
     * - force_refresh: bool (default false)
     */
    Route::post('/analyze/copropiedad/{id}', [PrecessionController::class, 'analyzeCopropiedad'])
        ->name('pae.analyze.copropiedad');
    
    /**
     * Listar análisis precesionales
     * 
     * GET /api/v1/pae/analyses
     * 
     * Query params:
     * - copropiedad_id: int
     * - status: pending|processing|completed|failed|expired
     * - analysis_type: string
     * - from_date: date
     * - to_date: date
     */
    Route::get('/analyses', [PrecessionController::class, 'listAnalyses'])
        ->name('pae.analyses.index');
    
    /**
     * Ver detalle de un análisis
     * 
     * GET /api/v1/pae/analyses/{id}
     */
    Route::get('/analyses/{id}', [PrecessionController::class, 'showAnalysis'])
        ->name('pae.analyses.show');
    
    // =========================================================
    // DASHBOARD Y VISUALIZACIÓN
    // =========================================================
    
    /**
     * Obtener dashboard precesional de una copropiedad
     * 
     * GET /api/v1/pae/dashboard/{copropiedadId}
     * 
     * Retorna:
     * - Scores (precession, risk, opportunity)
     * - Valores UF por ángulo
     * - Resumen de efectos
     * - Predicciones ML
     * - Alertas activas
     */
    Route::get('/dashboard/{copropiedadId}', [PrecessionController::class, 'getDashboard'])
        ->name('pae.dashboard');
    
    /**
     * Obtener heatmap precesional para un área
     * 
     * GET /api/v1/pae/heatmap
     * 
     * Query params:
     * - minLat: float (required)
     * - minLng: float (required)
     * - maxLat: float (required)
     * - maxLng: float (required)
     */
    Route::get('/heatmap', [PrecessionController::class, 'getHeatmap'])
        ->name('pae.heatmap');
    
    // =========================================================
    // SCORING DE INVERSIÓN
    // =========================================================
    
    /**
     * Calcular score de inversión ajustado por precesión
     * 
     * POST /api/v1/pae/investment-score
     * 
     * Body:
     * - copropiedad_id: int (optional)
     * - predio_id: int (optional)
     * - valor_inversion: float
     * - cap_rate: float
     * - cash_on_cash: float
     * - ocupacion: float (0-100)
     * - arriendo_mensual: float
     */
    Route::post('/investment-score', [PrecessionController::class, 'calculateInvestmentScore'])
        ->name('pae.investment-score');
    
    // =========================================================
    // ALERTAS PRECESIONALES
    // =========================================================
    
    /**
     * Obtener alertas precesionales activas
     * 
     * GET /api/v1/pae/alerts
     * 
     * Query params:
     * - copropiedad_id: int
     * - severity: low|medium|high|critical
     * - alert_type: string
     * - limit: int (1-100, default 50)
     */
    Route::get('/alerts', [PrecessionController::class, 'getActiveAlerts'])
        ->name('pae.alerts.index');
    
    /**
     * Reconocer una alerta
     * 
     * POST /api/v1/pae/alerts/{id}/acknowledge
     */
    Route::post('/alerts/{id}/acknowledge', [PrecessionController::class, 'acknowledgeAlert'])
        ->name('pae.alerts.acknowledge');
    
    /**
     * Resolver una alerta
     * 
     * POST /api/v1/pae/alerts/{id}/resolve
     * 
     * Body:
     * - resolution_notes: string (optional)
     */
    Route::post('/alerts/{id}/resolve', [PrecessionController::class, 'resolveAlert'])
        ->name('pae.alerts.resolve');
    
    // =========================================================
    // COMPARACIÓN
    // =========================================================
    
    /**
     * Comparar análisis precesionales entre copropiedades
     * 
     * POST /api/v1/pae/compare
     * 
     * Body:
     * - copropiedad_ids: array (2-10 IDs)
     */
    Route::post('/compare', [PrecessionController::class, 'comparePrecession'])
        ->name('pae.compare');
    
    // =========================================================
    // REPORTES
    // =========================================================
    
    /**
     * Generar reporte para inversionistas
     * 
     * GET /api/v1/pae/report/{copropiedadId}
     * 
     * Query params:
     * - format: json|pdf (default json)
     * - include_heatmap: bool
     * - include_predictions: bool
     */
    Route::get('/report/{copropiedadId}', [PrecessionController::class, 'generateInvestorReport'])
        ->name('pae.report');

    // =========================================================
    // MÉTRICAS INTEGRADAS (Fase 2)
    // =========================================================

    Route::prefix('metrics')->group(function () {
        /**
         * Obtener métricas consolidadas de todos los módulos
         * GET /api/v1/pae/metrics/{copropiedadId}
         */
        Route::get('/{copropiedadId}', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getConsolidatedMetrics'])
            ->name('pae.metrics.consolidated');

        /**
         * Contextos por módulo específico
         */
        Route::get('/{copropiedadId}/tax', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getTaxContext'])
            ->name('pae.metrics.tax');

        Route::get('/{copropiedadId}/expenses', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getExpenseContext'])
            ->name('pae.metrics.expenses');

        Route::get('/{copropiedadId}/compliance', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getComplianceContext'])
            ->name('pae.metrics.compliance');

        Route::get('/{copropiedadId}/aliquots', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getAliquotContext'])
            ->name('pae.metrics.aliquots');

        Route::get('/{copropiedadId}/valuation', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getValuationContext'])
            ->name('pae.metrics.valuation');

        Route::get('/{copropiedadId}/rental', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getRentalContext'])
            ->name('pae.metrics.rental');

        Route::get('/{copropiedadId}/full', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getFullContext'])
            ->name('pae.metrics.full');
    });

    // =========================================================
    // PROYECCIONES
    // =========================================================

    /**
     * Obtener todas las proyecciones precesionales
     * GET /api/v1/pae/projections/{copropiedadId}
     */
    Route::get('/projections/{copropiedadId}', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getProjections'])
        ->name('pae.projections');

    // =========================================================
    // ESTADÍSTICAS DEL SISTEMA
    // =========================================================

    Route::prefix('stats')->group(function () {
        /**
         * Estadísticas generales del PAE
         * GET /api/v1/pae/stats
         */
        Route::get('/', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getSystemStats'])
            ->name('pae.stats.system');

        /**
         * Top copropiedades por riesgo
         * GET /api/v1/pae/stats/top-risks
         */
        Route::get('/top-risks', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getTopRisks'])
            ->name('pae.stats.top-risks');

        /**
         * Top oportunidades de inversión
         * GET /api/v1/pae/stats/top-opportunities
         */
        Route::get('/top-opportunities', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getTopOpportunities'])
            ->name('pae.stats.top-opportunities');

        /**
         * Historial de cambios en módulos
         * GET /api/v1/pae/stats/module-changes
         */
        Route::get('/module-changes', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getModuleChanges'])
            ->name('pae.stats.module-changes');
    });

    // =========================================================
    // RANKINGS Y COMPARATIVAS
    // =========================================================

    /**
     * Rankings por diferentes métricas
     * GET /api/v1/pae/rankings
     */
    Route::get('/rankings', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'getRankings'])
        ->name('pae.rankings');

    /**
     * Comparar métricas entre copropiedades
     * POST /api/v1/pae/compare-metrics
     */
    Route::post('/compare-metrics', [\App\Http\Controllers\Api\V1\PAE\IntegrationMetricsController::class, 'compareMetrics'])
        ->name('pae.compare-metrics');
});
