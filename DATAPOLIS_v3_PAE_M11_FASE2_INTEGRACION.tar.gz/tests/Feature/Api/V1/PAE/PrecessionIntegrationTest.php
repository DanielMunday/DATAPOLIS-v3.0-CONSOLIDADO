<?php

namespace Tests\Feature\Api\V1\PAE;

use App\Models\PropTech\Copropiedad;
use App\Models\PropTech\Unidad;
use App\Models\PropTech\Arriendo;
use App\Models\PAE\PrecessionAnalysis;
use App\Models\PAE\PrecessionAlert;
use App\Models\Core\User;
use App\Models\Core\Tenant;
use App\Services\PrecessionService;
use App\Services\PAE\PrecessionContextBuilder;
use App\Jobs\PAE\TriggerPrecessionAnalysis;
use App\Jobs\PAE\ScheduledPrecessionAnalysis;
use App\Events\PAE\PrecessionTaxRiskUpdated;
use App\Events\PAE\PrecessionComplianceAlert;
use App\Events\PAE\PrecessionValuationUpdated;
use App\Events\PAE\ModuleDataUpdated;
use App\Listeners\PAE\HandleTaxRiskUpdated;
use App\Notifications\PAE\TaxRiskNotification;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Tests\TestCase;

/**
 * =========================================================
 * TESTS DE INTEGRACIÓN PAE M11
 * =========================================================
 * 
 * Verifica el flujo completo:
 * Copropiedad → PrecessionService → PAE Core → Alerts → Notifications
 */
class PrecessionIntegrationTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected Tenant $tenant;
    protected User $user;
    protected Copropiedad $copropiedad;

    protected function setUp(): void
    {
        parent::setUp();

        $this->tenant = Tenant::factory()->create();
        $this->user = User::factory()->create([
            'tenant_id' => $this->tenant->id,
            'role' => 'admin',
        ]);
        
        $this->copropiedad = Copropiedad::factory()->create([
            'tenant_id' => $this->tenant->id,
            'latitud' => -33.4489,
            'longitud' => -70.6693,
            'comuna' => 'Santiago',
            'activa' => true,
        ]);

        // Crear unidades de prueba
        Unidad::factory()->count(5)->create([
            'copropiedad_id' => $this->copropiedad->id,
        ]);
    }

    // =========================================================
    // TESTS DE FLUJO COMPLETO
    // =========================================================

    /** @test */
    public function flujo_completo_copropiedad_a_alertas()
    {
        // Arrange
        Event::fake();
        Queue::fake();

        // Mock PAE Core API
        Http::fake([
            '*/api/v1/pae/analyze' => Http::response([
                'success' => true,
                'data' => [
                    'precession_score' => 75.5,
                    'risk_score' => 0.72,
                    'opportunity_score' => 0.65,
                    'confidence' => 0.85,
                    'total_precession_value_uf' => 15000,
                    'direct_value_uf' => 5000,
                    'induced_value_uf' => 3000,
                    'precession_value_uf' => 4000,
                    'systemic_value_uf' => 2000,
                    'counter_value_uf' => 1000,
                    'ml_predictions' => [
                        '12m' => 0.05,
                        '24m' => 0.12,
                        '36m' => 0.18,
                    ],
                ],
            ], 200),
        ]);

        // Act - Ejecutar análisis via API
        $response = $this->actingAs($this->user)
            ->postJson("/api/v1/pae/analyze/copropiedad/{$this->copropiedad->id}", [
                'horizon' => 36,
                'radius' => 1000,
                'include_ml' => true,
            ]);

        // Assert
        $response->assertStatus(200);
        $response->assertJsonStructure([
            'data' => [
                'id',
                'copropiedad_id',
                'precession_score',
                'risk_score',
                'opportunity_score',
            ],
        ]);

        // Verificar que se creó el análisis
        $this->assertDatabaseHas('precession_analyses', [
            'copropiedad_id' => $this->copropiedad->id,
            'status' => 'completed',
        ]);

        // Verificar que se disparó evento
        Event::assertDispatched(\App\Events\PrecessionAnalysisCompleted::class);
    }

    /** @test */
    public function observer_dispara_job_al_actualizar_copropiedad()
    {
        Queue::fake();

        // Simular cambio significativo en copropiedad
        $this->copropiedad->update([
            'latitud' => -33.45,
            'longitud' => -70.67,
        ]);

        // Verificar que se encoló el job
        Queue::assertPushed(TriggerPrecessionAnalysis::class, function ($job) {
            return $job->copropiedadId === $this->copropiedad->id;
        });
    }

    /** @test */
    public function cambio_gasto_comun_dispara_evento_modulo()
    {
        Event::fake([ModuleDataUpdated::class]);

        // Crear gasto común
        \DB::table('gastos_comunes')->insert([
            'copropiedad_id' => $this->copropiedad->id,
            'monto_total' => 5000000,
            'fecha' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Simular observer call (normalmente lo haría el modelo)
        event(new ModuleDataUpdated(
            moduleName: 'gastos_comunes',
            entityType: 'GastoComun',
            entityId: 1,
            copropiedadId: $this->copropiedad->id,
            changeType: 'created',
            changedAttributes: ['monto_total']
        ));

        Event::assertDispatched(ModuleDataUpdated::class, function ($event) {
            return $event->moduleName === 'gastos_comunes' &&
                   $event->copropiedadId === $this->copropiedad->id;
        });
    }

    // =========================================================
    // TESTS DE CONTEXT BUILDER
    // =========================================================

    /** @test */
    public function build_tax_context_retorna_estructura_correcta()
    {
        $contextBuilder = app(PrecessionContextBuilder::class);
        
        $taxContext = $contextBuilder->buildTaxContext($this->copropiedad);

        $this->assertArrayHasKey('dj_1879', $taxContext);
        $this->assertArrayHasKey('dj_1907', $taxContext);
        $this->assertArrayHasKey('ppm', $taxContext);
        $this->assertArrayHasKey('iva', $taxContext);
        $this->assertArrayHasKey('f29', $taxContext);
        $this->assertArrayHasKey('metrics', $taxContext);
        $this->assertArrayHasKey('risk_score', $taxContext);
        $this->assertArrayHasKey('projected_load_12m', $taxContext);
    }

    /** @test */
    public function build_expense_context_retorna_estructura_correcta()
    {
        // Crear gastos históricos
        for ($i = 0; $i < 12; $i++) {
            \DB::table('gastos_comunes')->insert([
                'copropiedad_id' => $this->copropiedad->id,
                'monto_total' => 3000000 + rand(-200000, 200000),
                'fecha' => now()->subMonths($i),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $contextBuilder = app(PrecessionContextBuilder::class);
        
        $expenseContext = $contextBuilder->buildExpenseContext($this->copropiedad);

        $this->assertArrayHasKey('historico', $expenseContext);
        $this->assertArrayHasKey('tendencia', $expenseContext);
        $this->assertArrayHasKey('estacionalidad', $expenseContext);
        $this->assertArrayHasKey('volatilidad', $expenseContext);
        $this->assertArrayHasKey('proyecciones', $expenseContext);
        
        $this->assertEquals(12, $expenseContext['historico']['meses_disponibles']);
    }

    /** @test */
    public function build_compliance_context_detecta_brechas()
    {
        // Copropiedad sin reglamento inscrito
        $this->copropiedad->update([
            'reglamento_inscrito' => null,
            'nombre_administracion' => null,
        ]);

        $contextBuilder = app(PrecessionContextBuilder::class);
        
        $complianceContext = $contextBuilder->buildComplianceContext($this->copropiedad);

        $this->assertArrayHasKey('ds7_2025', $complianceContext);
        $this->assertArrayHasKey('ley_21442', $complianceContext);
        $this->assertArrayHasKey('brechas', $complianceContext);
        
        // Debe detectar brechas por falta de reglamento y administrador
        $this->assertGreaterThan(0, $complianceContext['brechas']['cantidad']);
    }

    /** @test */
    public function build_full_context_integra_todos_modulos()
    {
        $contextBuilder = app(PrecessionContextBuilder::class);
        
        $fullContext = $contextBuilder->buildFullContext($this->copropiedad);

        $this->assertArrayHasKey('copropiedad_id', $fullContext);
        $this->assertArrayHasKey('timestamp', $fullContext);
        $this->assertArrayHasKey('location', $fullContext);
        $this->assertArrayHasKey('tax', $fullContext);
        $this->assertArrayHasKey('expenses', $fullContext);
        $this->assertArrayHasKey('compliance', $fullContext);
        $this->assertArrayHasKey('aliquots', $fullContext);
        $this->assertArrayHasKey('valuation', $fullContext);
        $this->assertArrayHasKey('rental', $fullContext);
        
        $this->assertEquals($this->copropiedad->id, $fullContext['copropiedad_id']);
    }

    // =========================================================
    // TESTS DE EVENTOS Y LISTENERS
    // =========================================================

    /** @test */
    public function tax_risk_updated_crea_alerta_si_riesgo_alto()
    {
        Notification::fake();

        $event = new PrecessionTaxRiskUpdated(
            copropiedad: $this->copropiedad,
            taxContext: [
                'dj_1879' => ['cumplimiento' => 'pendiente'],
                'f29' => ['cumplimiento_12m' => 80],
                'metrics' => ['cumplimiento_global' => 70],
            ],
            riskScore: 0.75,
            projectedLoad: ['12m' => 50000, '36m' => 160000],
            recommendations: [['action' => 'Regularizar DJ 1879']]
        );

        $listener = new HandleTaxRiskUpdated();
        $listener->handle($event);

        // Verificar que se creó alerta
        $this->assertDatabaseHas('precession_alerts', [
            'copropiedad_id' => $this->copropiedad->id,
            'alert_type' => 'risk_threshold',
            'severity' => 'high',
        ]);

        // Verificar notificación
        Notification::assertSentTo(
            [$this->user],
            TaxRiskNotification::class
        );
    }

    /** @test */
    public function compliance_alert_crea_alerta_critica_si_brechas_criticas()
    {
        Notification::fake();

        $event = new PrecessionComplianceAlert(
            copropiedad: $this->copropiedad,
            complianceContext: [
                'ds7_2025' => ['score' => 45, 'nivel' => 'deficiente'],
                'ley_21442' => ['estado' => 'incumple'],
                'brechas' => [
                    'criticas' => [
                        ['requisito' => 'reglamento', 'severidad' => 'critica'],
                        ['requisito' => 'administrador', 'severidad' => 'critica'],
                    ],
                ],
                'recomendaciones' => [],
            ],
            globalScore: 45,
            gaps: [
                ['requisito' => 'reglamento', 'severidad' => 'critica'],
                ['requisito' => 'administrador', 'severidad' => 'critica'],
            ],
            regulatoryChangeProbability: ['prob_12m' => 0.15]
        );

        $listener = new \App\Listeners\PAE\HandleComplianceAlert();
        $listener->handle($event);

        // Verificar alerta crítica
        $this->assertDatabaseHas('precession_alerts', [
            'copropiedad_id' => $this->copropiedad->id,
            'alert_type' => 'regulatory_impact',
            'severity' => 'critical',
        ]);
    }

    // =========================================================
    // TESTS DE JOBS
    // =========================================================

    /** @test */
    public function trigger_precession_analysis_job_ejecuta_correctamente()
    {
        Http::fake([
            '*/api/v1/pae/analyze' => Http::response([
                'success' => true,
                'data' => [
                    'precession_score' => 70,
                    'risk_score' => 0.5,
                    'opportunity_score' => 0.6,
                    'confidence' => 0.8,
                    'total_precession_value_uf' => 10000,
                ],
            ], 200),
        ]);

        $job = new TriggerPrecessionAnalysis($this->copropiedad->id, [
            'reason' => 'test',
            'priority' => 'high',
        ]);

        $job->handle(
            app(PrecessionService::class),
            app(PrecessionContextBuilder::class)
        );

        // Verificar que se creó el análisis
        $this->assertDatabaseHas('precession_analyses', [
            'copropiedad_id' => $this->copropiedad->id,
        ]);
    }

    /** @test */
    public function scheduled_analysis_despacha_jobs_para_copropiedades()
    {
        Queue::fake();

        // Crear más copropiedades
        Copropiedad::factory()->count(5)->create([
            'tenant_id' => $this->tenant->id,
            'activa' => true,
        ]);

        $job = new ScheduledPrecessionAnalysis(
            tenantId: $this->tenant->id,
            filters: ['batch_size' => 10]
        );

        $job->handle();

        // Verificar que se despacharon jobs
        Queue::assertPushed(TriggerPrecessionAnalysis::class);
    }

    // =========================================================
    // TESTS DE CACHE
    // =========================================================

    /** @test */
    public function context_builder_usa_cache()
    {
        $contextBuilder = app(PrecessionContextBuilder::class);
        
        // Primera llamada
        $context1 = $contextBuilder->buildTaxContext($this->copropiedad);
        
        // Segunda llamada (debe venir de cache)
        $context2 = $contextBuilder->buildTaxContext($this->copropiedad);

        $this->assertEquals($context1, $context2);
        $this->assertTrue(Cache::has("pae:tax_context:{$this->copropiedad->id}"));
    }

    /** @test */
    public function analisis_invalida_cache_con_force_refresh()
    {
        Http::fake([
            '*/api/v1/pae/analyze' => Http::response([
                'success' => true,
                'data' => [
                    'precession_score' => 80,
                    'risk_score' => 0.4,
                    'opportunity_score' => 0.7,
                    'confidence' => 0.85,
                    'total_precession_value_uf' => 12000,
                ],
            ], 200),
        ]);

        $service = app(PrecessionService::class);

        // Primera llamada
        $result1 = $service->analyzeCopropiedad($this->copropiedad->id);

        // Cambiar respuesta del mock
        Http::fake([
            '*/api/v1/pae/analyze' => Http::response([
                'success' => true,
                'data' => [
                    'precession_score' => 90,
                    'risk_score' => 0.3,
                    'opportunity_score' => 0.8,
                    'confidence' => 0.9,
                    'total_precession_value_uf' => 15000,
                ],
            ], 200),
        ]);

        // Segunda llamada con force_refresh
        $result2 = $service->analyzeCopropiedad($this->copropiedad->id, [
            'force_refresh' => true,
        ]);

        // Los resultados deben ser diferentes
        $this->assertNotEquals(
            $result1['precession_score'] ?? 0,
            $result2['precession_score'] ?? 0
        );
    }

    // =========================================================
    // TESTS DE NOTIFICACIONES
    // =========================================================

    /** @test */
    public function notificacion_tax_risk_tiene_canales_correctos()
    {
        $alert = PrecessionAlert::factory()->create([
            'tenant_id' => $this->tenant->id,
            'copropiedad_id' => $this->copropiedad->id,
            'severity' => 'critical',
        ]);

        $event = new PrecessionTaxRiskUpdated(
            copropiedad: $this->copropiedad,
            taxContext: ['metrics' => ['cumplimiento_global' => 60]],
            riskScore: 0.85,
            projectedLoad: ['12m' => 100000],
            recommendations: []
        );

        $notification = new TaxRiskNotification($alert, $event);
        $channels = $notification->via($this->user);

        $this->assertContains('database', $channels);
        $this->assertContains('mail', $channels);
    }

    // =========================================================
    // TESTS DE RESILIENCIA
    // =========================================================

    /** @test */
    public function job_maneja_fallo_de_pae_core()
    {
        Http::fake([
            '*/api/v1/pae/analyze' => Http::response([
                'error' => 'Service unavailable',
            ], 503),
        ]);

        $this->expectException(\Exception::class);

        $job = new TriggerPrecessionAnalysis($this->copropiedad->id, [
            'reason' => 'test_failure',
        ]);

        $job->handle(
            app(PrecessionService::class),
            app(PrecessionContextBuilder::class)
        );
    }

    /** @test */
    public function service_usa_fallback_cuando_pae_core_no_disponible()
    {
        // Configurar fallback habilitado
        config(['datapolis.pae.fallback_enabled' => true]);

        Http::fake([
            '*/api/v1/pae/*' => Http::response(null, 500),
        ]);

        $service = app(PrecessionService::class);
        
        // El servicio debería usar fallback local
        $result = $service->analyzeCopropiedad($this->copropiedad->id);

        // Verificar que se usó fallback (confidence baja)
        $this->assertArrayHasKey('confidence', $result);
        $this->assertLessThanOrEqual(0.5, $result['confidence'] ?? 1);
    }
}

/**
 * =========================================================
 * TESTS UNITARIOS DE CONTEXT BUILDER
 * =========================================================
 */
class PrecessionContextBuilderTest extends TestCase
{
    use RefreshDatabase;

    protected Copropiedad $copropiedad;

    protected function setUp(): void
    {
        parent::setUp();

        $tenant = Tenant::factory()->create();
        $this->copropiedad = Copropiedad::factory()->create([
            'tenant_id' => $tenant->id,
        ]);
    }

    /** @test */
    public function calcula_tendencia_gastos_correctamente()
    {
        // Crear gastos con tendencia creciente
        $baseAmount = 2000000;
        for ($i = 11; $i >= 0; $i--) {
            \DB::table('gastos_comunes')->insert([
                'copropiedad_id' => $this->copropiedad->id,
                'monto_total' => $baseAmount + ((11 - $i) * 50000), // Aumenta cada mes
                'fecha' => now()->subMonths($i),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $contextBuilder = app(PrecessionContextBuilder::class);
        $context = $contextBuilder->buildExpenseContext($this->copropiedad);

        $this->assertEquals('creciente', $context['tendencia']['direccion']);
        $this->assertGreaterThan(0, $context['tendencia']['porcentaje_anual']);
    }

    /** @test */
    public function detecta_estacionalidad_en_gastos()
    {
        // Crear gastos con estacionalidad (altos en verano)
        $baseAmount = 2500000;
        for ($i = 0; $i < 24; $i++) {
            $month = (12 - ($i % 12));
            $seasonalFactor = in_array($month, [1, 2, 12]) ? 1.3 : 1.0; // Verano = alto
            
            \DB::table('gastos_comunes')->insert([
                'copropiedad_id' => $this->copropiedad->id,
                'monto_total' => $baseAmount * $seasonalFactor,
                'fecha' => now()->subMonths($i),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        $contextBuilder = app(PrecessionContextBuilder::class);
        $context = $contextBuilder->buildExpenseContext($this->copropiedad);

        $this->assertTrue($context['estacionalidad']['detectada']);
        $this->assertNotEmpty($context['estacionalidad']['meses_altos']);
    }

    /** @test */
    public function calcula_score_compliance_ponderado()
    {
        $this->copropiedad->update([
            'reglamento_inscrito' => true,
            'nombre_administracion' => 'Admin Test',
            'cuenta_bancaria' => '1234567890',
            'fondo_reserva' => 10000000,
            'gasto_comun_mensual' => 2000000,
        ]);

        $contextBuilder = app(PrecessionContextBuilder::class);
        $context = $contextBuilder->buildComplianceContext($this->copropiedad);

        // Con varios requisitos cumplidos, score debe ser > 50
        $this->assertGreaterThan(50, $context['ds7_2025']['score']);
    }

    /** @test */
    public function calcula_yield_correctamente()
    {
        // Crear arriendos activos
        $unidades = Unidad::factory()->count(3)->create([
            'copropiedad_id' => $this->copropiedad->id,
            'superficie' => 80,
        ]);

        foreach ($unidades as $unidad) {
            Arriendo::factory()->create([
                'unidad_id' => $unidad->id,
                'monto_mensual' => 800000,
                'estado' => 'activo',
            ]);
        }

        $this->copropiedad->update([
            'valor_comercial' => 200000, // UF
        ]);

        $contextBuilder = app(PrecessionContextBuilder::class);
        $context = $contextBuilder->buildRentalContext($this->copropiedad);

        // Verificar que yield está calculado
        $this->assertArrayHasKey('gross_yield', $context['metricas_inversion']);
        $this->assertGreaterThan(0, $context['metricas_inversion']['gross_yield']);
    }
}
