<?php

declare(strict_types=1);

namespace Tests\Feature\PAE;

use App\Models\Copropiedad;
use App\Services\PAE\PrecessionGraphEngine;
use App\Services\PAE\PrecessionScoringEngine;
use App\Services\PAE\PrecessionMLConnector;
use App\Services\PAE\PrecessionAlertEngine;
use App\Services\PAE\PrecessionSyncService;
use App\Services\PrecessionService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

/**
 * =========================================================================
 * PAE M11-DP - INTEGRATION TESTS
 * Tests de Integración para Arquitectura Nativa
 * =========================================================================
 *
 * CRITERIO PRINCIPAL:
 * Verificar que NINGÚN test hace llamadas HTTP al servicio externo PAE Core.
 * Todos los análisis deben ejecutarse in-process con engines nativos PHP.
 *
 * @package Tests\Feature\PAE
 * @version 1.0.0
 * @author DATAPOLIS SpA
 */
class PrecessionIntegrationNativeTest extends TestCase
{
    use RefreshDatabase;

    protected PrecessionGraphEngine $graphEngine;
    protected PrecessionScoringEngine $scoringEngine;
    protected PrecessionMLConnector $mlConnector;
    protected PrecessionAlertEngine $alertEngine;
    protected PrecessionService $precessionService;

    protected function setUp(): void
    {
        parent::setUp();

        // Instanciar engines nativos
        $this->graphEngine = new PrecessionGraphEngine();
        $this->scoringEngine = new PrecessionScoringEngine();
        $this->mlConnector = new PrecessionMLConnector();
        $this->alertEngine = new PrecessionAlertEngine();

        // Crear servicio con engines nativos
        $syncService = new PrecessionSyncService($this->graphEngine, $this->alertEngine);
        
        $this->precessionService = new PrecessionService(
            $this->graphEngine,
            $this->scoringEngine,
            $this->mlConnector,
            $this->alertEngine,
            $syncService
        );

        // Prevenir cualquier llamada HTTP real (excepto Ollama local)
        Http::preventStrayRequests();
    }

    // =========================================================================
    // TESTS DE NO DEPENDENCIA HTTP EXTERNA
    // =========================================================================

    /** @test */
    public function full_analysis_executes_without_external_api_calls(): void
    {
        // Fake todas las requests HTTP
        Http::fake([
            // Solo permitir Ollama local (si está disponible)
            'localhost:11434/*' => Http::response(['response' => 'Test narrative'], 200),
            // Cualquier otra URL debe fallar
            '*' => Http::response('External API not allowed', 500),
        ]);

        // Ejecutar análisis completo
        $intervention = [
            'node_id' => 'valor_suelo_m2',
            'magnitude' => 1.0,
            'type' => 'valuation',
        ];

        $result = $this->graphEngine->analyzePrecession($intervention, 4, 48);

        // Verificar que se ejecutó correctamente
        $this->assertNotEmpty($result['effects']);
        $this->assertArrayHasKey('metrics', $result);
        $this->assertArrayHasKey('effects_by_angle', $result);

        // Verificar que NO hubo llamadas a APIs externas (excepto Ollama)
        Http::assertNotSent(function ($request) {
            $url = $request->url();
            // Excluir Ollama local
            if (str_contains($url, 'localhost:11434')) {
                return false;
            }
            // Cualquier otra URL externa es un fallo
            return str_contains($url, 'pae_api') || 
                   str_contains($url, 'fastapi') ||
                   str_contains($url, ':8000');
        });
    }

    /** @test */
    public function scoring_executes_without_external_dependencies(): void
    {
        $effects = [
            ['weight' => 0.5, 'confidence' => 0.8, 'angle_class' => 'precession_90', 'lag_months' => 12],
            ['weight' => -0.3, 'confidence' => 0.7, 'angle_class' => 'counter_180', 'lag_months' => 18],
        ];

        // No debe hacer ninguna llamada externa
        Http::fake(['*' => Http::response('Not allowed', 500)]);

        $precessionScore = $this->scoringEngine->calculatePrecessionScore($effects);
        $riskScore = $this->scoringEngine->calculateRiskScore($effects);
        $opportunityScore = $this->scoringEngine->calculateOpportunityScore($effects);

        $this->assertGreaterThanOrEqual(0, $precessionScore);
        $this->assertLessThanOrEqual(100, $precessionScore);
        $this->assertGreaterThanOrEqual(0, $riskScore);
        $this->assertLessThanOrEqual(1, $riskScore);

        // Verificar cero requests HTTP
        Http::assertNothingSent();
    }

    /** @test */
    public function alert_evaluation_executes_without_external_dependencies(): void
    {
        Http::fake(['*' => Http::response('Not allowed', 500)]);

        $analysis = [
            'effects' => [
                ['weight' => -0.7, 'confidence' => 0.85, 'lag_months' => 6, 'angle_class' => 'counter_180'],
            ],
            'metrics' => ['avg_confidence' => 0.85],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [['weight' => -0.7]],
            ],
        ];

        $alerts = $this->alertEngine->evaluateThresholds($analysis, 1, 1);

        $this->assertIsArray($alerts);

        // Verificar cero requests HTTP
        Http::assertNothingSent();
    }

    /** @test */
    public function ml_connector_has_fallback_without_ollama(): void
    {
        // Simular Ollama no disponible
        Http::fake([
            'localhost:11434/*' => Http::response(null, 500),
            '*' => Http::response('Not allowed', 500),
        ]);

        // Forzar refresh del health check
        $this->mlConnector->refreshOllamaHealth();

        // predictTrend debe funcionar con fallback
        $historical = [
            '2024-01' => 100,
            '2024-02' => 105,
            '2024-03' => 108,
            '2024-04' => 112,
            '2024-05' => 115,
            '2024-06' => 118,
        ];

        $result = $this->mlConnector->predictTrend($historical, 12);

        // Debe retornar resultado válido (fallback PHP)
        $this->assertArrayHasKey('valor_predicho', $result);
        $this->assertArrayHasKey('tendencia', $result);
        $this->assertArrayHasKey('metodo', $result);

        // Método debe ser el fallback
        $this->assertEquals('linear_regression_ema_blend', $result['metodo']);
    }

    /** @test */
    public function morosidad_prediction_uses_heuristics_without_external_ml(): void
    {
        Http::fake(['*' => Http::response('Not allowed', 500)]);

        $copropiedadData = [
            'valor_suelo_m2' => 60,
            'gasto_comun_promedio' => 4,
            'compliance_score' => 40,
            'antiguedad_edificacion' => 25,
            'indice_morosidad' => 15,
            'tasa_vacancia' => 18,
        ];

        $result = $this->mlConnector->predictMorosidad($copropiedadData);

        $this->assertArrayHasKey('prediccion_morosidad_12m', $result);
        $this->assertArrayHasKey('riesgo_incremento', $result);
        $this->assertArrayHasKey('factores', $result);
        $this->assertArrayHasKey('recomendaciones', $result);

        // Confianza debe indicar que son heurísticas
        $this->assertLessThan(0.8, $result['confianza']);

        // Verificar cero requests HTTP
        Http::assertNothingSent();
    }

    /** @test */
    public function narrative_generation_has_template_fallback(): void
    {
        // Simular Ollama no disponible
        Http::fake([
            'localhost:11434/*' => Http::response(null, 500),
        ]);

        $this->mlConnector->refreshOllamaHealth();

        $analysis = [
            'intervention' => [
                'node_id' => 'valor_suelo_m2',
                'node_name' => 'Valor del Suelo',
                'magnitude' => 1.0,
            ],
            'metrics' => [
                'total_effects' => 5,
                'positive_effects' => 3,
                'negative_effects' => 2,
                'avg_confidence' => 0.75,
            ],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [['weight' => 0.4], ['weight' => 0.3]],
                'precession_90' => [['weight' => 0.5]],
                'systemic_135' => [],
                'counter_180' => [['weight' => -0.3], ['weight' => -0.2]],
            ],
        ];

        $narrative = $this->mlConnector->generateNarrative($analysis);

        // Debe generar narrativa con template
        $this->assertNotEmpty($narrative);
        $this->assertStringContainsString('análisis precesional', strtolower($narrative));
    }

    // =========================================================================
    // TESTS DE CONFIGURACIÓN SIN DEPENDENCIAS EXTERNAS
    // =========================================================================

    /** @test */
    public function config_does_not_contain_pae_api_url(): void
    {
        $config = config('datapolis.pae', []);

        // NO debe existir pae_api_url
        $this->assertArrayNotHasKey('pae_api_url', $config);
        $this->assertArrayNotHasKey('api_url', $config);
    }

    /** @test */
    public function config_does_not_contain_pae_api_key(): void
    {
        $config = config('datapolis.pae', []);

        // NO debe existir pae_api_key
        $this->assertArrayNotHasKey('pae_api_key', $config);
        $this->assertArrayNotHasKey('api_key', $config);
    }

    /** @test */
    public function config_contains_native_engine_settings(): void
    {
        // Cargar config nativo
        $config = include base_path('config/pae_native.php');

        // Debe contener configuración de engines nativos
        $this->assertArrayHasKey('graph', $config);
        $this->assertArrayHasKey('scoring', $config);
        $this->assertArrayHasKey('ml', $config);
        $this->assertArrayHasKey('alerts', $config);
        $this->assertArrayHasKey('sync', $config);

        // Verificar estructura de graph
        $this->assertArrayHasKey('max_depth', $config['graph']);
        $this->assertArrayHasKey('decay_factor', $config['graph']);

        // Verificar estructura de scoring
        $this->assertArrayHasKey('weights', $config['scoring']);

        // Verificar estructura de ml (solo Ollama local)
        $this->assertArrayHasKey('ollama_url', $config['ml']);
        $this->assertStringContainsString('localhost', $config['ml']['ollama_url']);
    }

    // =========================================================================
    // TESTS DE INTEGRACIÓN END-TO-END
    // =========================================================================

    /** @test */
    public function end_to_end_analysis_without_http_dependency(): void
    {
        Http::fake([
            'localhost:11434/*' => Http::response(['response' => 'Narrativa de prueba'], 200),
            '*' => Http::response('External API call detected!', 500),
        ]);

        // Simular flujo completo
        
        // 1. Análisis de grafo
        $intervention = [
            'node_id' => 'permisos_edificacion',
            'magnitude' => 1.0,
            'type' => 'urban_metric',
        ];
        $graphResult = $this->graphEngine->analyzePrecession($intervention, 4, 48);

        // 2. Scoring
        $precessionScore = $this->scoringEngine->calculatePrecessionScore($graphResult['effects']);
        $riskScore = $this->scoringEngine->calculateRiskScore($graphResult['effects']);

        // 3. Investment Score
        $copropiedadData = [
            'nombre' => 'Test Copropiedad',
            'indice_morosidad' => 10,
            'compliance_score' => 70,
            'valor_suelo_m2' => 45,
        ];
        $investmentScore = $this->scoringEngine->calculateInvestmentScore($copropiedadData, $graphResult);

        // 4. Alertas
        $analysisData = array_merge($graphResult, [
            'precession_score' => $precessionScore,
            'risk_score' => $riskScore,
        ]);
        $alerts = $this->alertEngine->evaluateThresholds($analysisData, 1, 1);

        // 5. Predicción ML
        $historical = ['2024-01' => 100, '2024-02' => 105, '2024-03' => 110];
        $prediction = $this->mlConnector->predictTrend($historical, 12);

        // Verificaciones
        $this->assertNotEmpty($graphResult['effects']);
        $this->assertGreaterThanOrEqual(0, $precessionScore);
        $this->assertLessThanOrEqual(100, $precessionScore);
        $this->assertArrayHasKey('score', $investmentScore);
        $this->assertIsArray($alerts);
        $this->assertArrayHasKey('valor_predicho', $prediction);

        // Verificar que NO hubo llamadas a APIs externas (excepto Ollama)
        Http::assertNotSent(function ($request) {
            $url = $request->url();
            if (str_contains($url, 'localhost:11434')) {
                return false;
            }
            return true;
        });
    }

    /** @test */
    public function comparison_works_without_external_dependencies(): void
    {
        Http::fake(['*' => Http::response('Not allowed', 500)]);

        $copropiedadesData = [
            1 => [
                'data' => ['nombre' => 'Copropiedad A', 'indice_morosidad' => 5, 'compliance_score' => 85],
                'analysis' => [
                    'effects' => [
                        ['weight' => 0.5, 'confidence' => 0.8, 'angle_class' => 'precession_90', 'lag_months' => 12],
                    ],
                ],
            ],
            2 => [
                'data' => ['nombre' => 'Copropiedad B', 'indice_morosidad' => 20, 'compliance_score' => 55],
                'analysis' => [
                    'effects' => [
                        ['weight' => -0.4, 'confidence' => 0.7, 'angle_class' => 'counter_180', 'lag_months' => 6],
                    ],
                ],
            ],
        ];

        $comparison = $this->scoringEngine->compareCopropiedades($copropiedadesData);

        $this->assertArrayHasKey('scores', $comparison);
        $this->assertArrayHasKey('rankings', $comparison);
        $this->assertArrayHasKey('differential', $comparison);
        $this->assertArrayHasKey('summary', $comparison);

        // Copropiedad A debería tener mejor score
        $this->assertEquals(1, $comparison['rankings']['by_investment'][0]);

        // Verificar cero requests HTTP
        Http::assertNothingSent();
    }

    // =========================================================================
    // TESTS DE ONTOLOGÍA
    // =========================================================================

    /** @test */
    public function ontology_export_import_works_without_http(): void
    {
        Http::fake(['*' => Http::response('Not allowed', 500)]);

        // Exportar ontología
        $exported = $this->graphEngine->exportOntology();

        $this->assertArrayHasKey('nodes', $exported);
        $this->assertArrayHasKey('edges', $exported);
        $this->assertEquals('DATAPOLIS_PAE', $exported['source']);

        // Simular ontología externa
        $externalOntology = [
            'source' => 'AGORA',
            'ontology' => [
                'nodes' => [
                    'test_external_node' => [
                        'name' => 'External Test',
                        'type' => 'external',
                        'source' => 'AGORA',
                    ],
                ],
                'edges' => [],
            ],
        ];

        // Importar
        $this->graphEngine->importOntology($externalOntology, true);

        // Verificar
        $this->assertTrue($this->graphEngine->hasNode('test_external_node'));

        // Verificar cero requests HTTP
        Http::assertNothingSent();
    }

    // =========================================================================
    // TESTS DE PERFORMANCE
    // =========================================================================

    /** @test */
    public function graph_analysis_completes_under_50ms(): void
    {
        $intervention = [
            'node_id' => 'valor_suelo_m2',
            'magnitude' => 1.0,
            'type' => 'valuation',
        ];

        $startTime = microtime(true);
        $result = $this->graphEngine->analyzePrecession($intervention, 4, 60);
        $endTime = microtime(true);

        $executionTimeMs = ($endTime - $startTime) * 1000;

        // Debe ejecutar en menos de 50ms
        $this->assertLessThan(50, $executionTimeMs);

        // También verificar el tiempo reportado
        $this->assertLessThan(50, $result['execution_time_ms']);
    }

    /** @test */
    public function full_scoring_pipeline_completes_under_100ms(): void
    {
        $effects = [];
        for ($i = 0; $i < 20; $i++) {
            $effects[] = [
                'weight' => rand(-100, 100) / 100,
                'confidence' => rand(50, 100) / 100,
                'angle_class' => ['direct_0', 'induced_45', 'precession_90', 'systemic_135', 'counter_180'][rand(0, 4)],
                'lag_months' => rand(3, 36),
            ];
        }

        $startTime = microtime(true);

        $precessionScore = $this->scoringEngine->calculatePrecessionScore($effects);
        $riskScore = $this->scoringEngine->calculateRiskScore($effects);
        $opportunityScore = $this->scoringEngine->calculateOpportunityScore($effects);

        $endTime = microtime(true);
        $executionTimeMs = ($endTime - $startTime) * 1000;

        // Todo el pipeline de scoring debe completar en menos de 100ms
        $this->assertLessThan(100, $executionTimeMs);
    }
}
