<?php

declare(strict_types=1);

namespace Tests\Unit\PAE;

use App\Services\PAE\PrecessionAlertEngine;
use App\Services\PAE\PrecessionScoringEngine;
use Tests\TestCase;

/**
 * =========================================================================
 * PAE M11-DP - ALERT ENGINE TESTS
 * Tests Unitarios para PrecessionAlertEngine
 * =========================================================================
 *
 * Valida el funcionamiento del motor de alertas nativo.
 * NO realiza ninguna llamada HTTP externa.
 *
 * @package Tests\Unit\PAE
 * @version 1.0.0
 * @author DATAPOLIS SpA
 */
class PrecessionAlertEngineNativeTest extends TestCase
{
    protected PrecessionAlertEngine $engine;

    protected function setUp(): void
    {
        parent::setUp();
        
        // Mock del ScoringEngine para inyección
        $this->app->singleton(PrecessionScoringEngine::class, function () {
            return new PrecessionScoringEngine();
        });
        
        $this->engine = new PrecessionAlertEngine();
    }

    // =========================================================================
    // TESTS DE EVALUACIÓN DE UMBRALES
    // =========================================================================

    /** @test */
    public function it_generates_critical_alert_for_high_risk(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => -0.9, 'confidence' => 0.95, 'lag_months' => 6, 'angle_class' => 'counter_180'],
                ['weight' => -0.8, 'confidence' => 0.9, 'lag_months' => 12, 'angle_class' => 'counter_180'],
            ],
            'metrics' => [
                'total_effects' => 2,
                'positive_effects' => 0,
                'negative_effects' => 2,
                'avg_confidence' => 0.925,
            ],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [
                    ['weight' => -0.9, 'confidence' => 0.95],
                    ['weight' => -0.8, 'confidence' => 0.9],
                ],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        // Debe haber al menos una alerta crítica
        $criticalAlerts = array_filter($alerts, fn($a) => $a['severity'] === 'critical');
        $this->assertNotEmpty($criticalAlerts);
    }

    /** @test */
    public function it_generates_warning_for_moderate_risk(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => -0.4, 'confidence' => 0.6, 'lag_months' => 12, 'angle_class' => 'counter_180'],
            ],
            'metrics' => [
                'total_effects' => 1,
                'positive_effects' => 0,
                'negative_effects' => 1,
                'avg_confidence' => 0.6,
            ],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [['weight' => -0.4, 'confidence' => 0.6]],
            ],
            'risk_score' => 0.55,
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        // Debe haber alertas de nivel warning o superior
        $warningOrHigher = array_filter($alerts, fn($a) => 
            in_array($a['severity'], ['warning', 'high', 'critical'])
        );
        $this->assertNotEmpty($warningOrHigher);
    }

    /** @test */
    public function it_generates_info_alert_for_opportunities(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => 0.8, 'confidence' => 0.85, 'lag_months' => 12, 'angle_class' => 'precession_90'],
                ['weight' => 0.6, 'confidence' => 0.8, 'lag_months' => 18, 'angle_class' => 'induced_45'],
            ],
            'metrics' => [
                'total_effects' => 2,
                'positive_effects' => 2,
                'negative_effects' => 0,
                'avg_confidence' => 0.825,
            ],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [['weight' => 0.6, 'confidence' => 0.8]],
                'precession_90' => [['weight' => 0.8, 'confidence' => 0.85]],
                'systemic_135' => [],
                'counter_180' => [],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        // Debe haber alerta de oportunidad
        $opportunityAlerts = array_filter($alerts, fn($a) => 
            $a['alert_type'] === 'opportunity_detected'
        );
        $this->assertNotEmpty($opportunityAlerts);
    }

    /** @test */
    public function it_detects_critical_negative_effects_with_high_confidence(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => -0.5, 'confidence' => 0.92, 'lag_months' => 6, 
                 'angle_class' => 'counter_180', 'target_name' => 'Test Effect'],
            ],
            'metrics' => [
                'total_effects' => 1,
                'positive_effects' => 0,
                'negative_effects' => 1,
                'avg_confidence' => 0.92,
            ],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [['weight' => -0.5, 'confidence' => 0.92, 'target_name' => 'Test']],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        // Debe detectar efectos negativos de alta confianza
        $anomalyAlerts = array_filter($alerts, fn($a) => 
            $a['alert_type'] === 'anomaly_detected'
        );
        $this->assertNotEmpty($anomalyAlerts);
    }

    /** @test */
    public function it_generates_deadline_alert_for_short_term_negative_effects(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => -0.5, 'confidence' => 0.8, 'lag_months' => 3, 'angle_class' => 'counter_180'],
                ['weight' => -0.4, 'confidence' => 0.75, 'lag_months' => 5, 'angle_class' => 'counter_180'],
            ],
            'metrics' => [
                'total_effects' => 2,
                'positive_effects' => 0,
                'negative_effects' => 2,
                'avg_confidence' => 0.775,
            ],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        // Debe haber alerta de deadline
        $deadlineAlerts = array_filter($alerts, fn($a) => 
            $a['alert_type'] === 'deadline_approaching'
        );
        $this->assertNotEmpty($deadlineAlerts);
    }

    // =========================================================================
    // TESTS DE ESTRUCTURA DE ALERTAS
    // =========================================================================

    /** @test */
    public function alert_has_required_structure(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => -0.8, 'confidence' => 0.9, 'lag_months' => 6, 'angle_class' => 'counter_180'],
            ],
            'metrics' => ['avg_confidence' => 0.9],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [['weight' => -0.8]],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        $this->assertNotEmpty($alerts);

        $alert = $alerts[0];

        // Verificar campos requeridos
        $this->assertArrayHasKey('tenant_id', $alert);
        $this->assertArrayHasKey('copropiedad_id', $alert);
        $this->assertArrayHasKey('alert_type', $alert);
        $this->assertArrayHasKey('severity', $alert);
        $this->assertArrayHasKey('status', $alert);
        $this->assertArrayHasKey('title', $alert);
        $this->assertArrayHasKey('description', $alert);
        $this->assertArrayHasKey('recommendation', $alert);
        $this->assertArrayHasKey('probability', $alert);
        $this->assertArrayHasKey('potential_impact_uf', $alert);
        $this->assertArrayHasKey('expected_months', $alert);
        $this->assertArrayHasKey('data', $alert);
    }

    /** @test */
    public function alert_severity_is_valid(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => -0.9, 'confidence' => 0.95, 'lag_months' => 6, 'angle_class' => 'counter_180'],
            ],
            'metrics' => ['avg_confidence' => 0.95],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        foreach ($alerts as $alert) {
            $this->assertContains($alert['severity'], ['critical', 'high', 'warning', 'info']);
        }
    }

    /** @test */
    public function alert_type_is_valid(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => 0.7, 'confidence' => 0.8, 'lag_months' => 12, 'angle_class' => 'precession_90'],
            ],
            'metrics' => ['avg_confidence' => 0.8],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [['weight' => 0.7]],
                'systemic_135' => [],
                'counter_180' => [],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        $validTypes = [
            'risk_threshold',
            'opportunity_detected',
            'trend_change',
            'anomaly_detected',
            'deadline_approaching',
            'regulatory_impact',
            'market_shift',
        ];

        foreach ($alerts as $alert) {
            $this->assertContains($alert['alert_type'], $validTypes);
        }
    }

    // =========================================================================
    // TESTS DE CONFIGURACIÓN DE UMBRALES
    // =========================================================================

    /** @test */
    public function it_can_configure_custom_thresholds(): void
    {
        // Configurar umbrales más estrictos
        $this->engine->configureThresholds([
            'critical_threshold' => 0.5, // Más bajo
            'warning_threshold' => 0.3,
        ]);

        $analysis = [
            'effects' => [
                ['weight' => -0.4, 'confidence' => 0.7, 'lag_months' => 12, 'angle_class' => 'counter_180'],
            ],
            'metrics' => ['avg_confidence' => 0.7],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [],
            ],
            'risk_score' => 0.55,
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        // Con umbral más bajo, debería generar alerta crítica
        $criticalAlerts = array_filter($alerts, fn($a) => $a['severity'] === 'critical');
        $this->assertNotEmpty($criticalAlerts);
    }

    // =========================================================================
    // TESTS DE COMPLIANCE IMPACT
    // =========================================================================

    /** @test */
    public function it_evaluates_compliance_impact(): void
    {
        $analysis = [
            'effects' => [],
            'metrics' => ['avg_confidence' => 0.7],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [],
            ],
            'context' => [
                'compliance' => [
                    'score_global' => 35, // Muy bajo
                    'brechas' => [
                        'criticas' => ['Gap 1', 'Gap 2'],
                    ],
                ],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        // Debe haber alerta regulatoria
        $regulatoryAlerts = array_filter($alerts, fn($a) => 
            $a['alert_type'] === 'regulatory_impact'
        );
        $this->assertNotEmpty($regulatoryAlerts);
    }

    // =========================================================================
    // TESTS DE PROBABILIDAD E IMPACTO
    // =========================================================================

    /** @test */
    public function it_calculates_probability_between_0_and_1(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => -0.7, 'confidence' => 0.85, 'lag_months' => 12, 'angle_class' => 'counter_180'],
            ],
            'metrics' => ['avg_confidence' => 0.85],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [],
                'precession_90' => [],
                'systemic_135' => [],
                'counter_180' => [],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        foreach ($alerts as $alert) {
            $this->assertGreaterThanOrEqual(0, $alert['probability']);
            $this->assertLessThanOrEqual(1, $alert['probability']);
        }
    }

    /** @test */
    public function it_calculates_potential_impact_based_on_severity(): void
    {
        $criticalAnalysis = [
            'effects' => [
                ['weight' => -0.95, 'confidence' => 0.95, 'lag_months' => 3, 'angle_class' => 'counter_180'],
            ],
            'metrics' => ['avg_confidence' => 0.95],
            'effects_by_angle' => ['direct_0' => [], 'induced_45' => [], 'precession_90' => [], 'systemic_135' => [], 'counter_180' => []],
        ];

        $warningAnalysis = [
            'effects' => [
                ['weight' => -0.3, 'confidence' => 0.6, 'lag_months' => 24, 'angle_class' => 'counter_180'],
            ],
            'metrics' => ['avg_confidence' => 0.6],
            'effects_by_angle' => ['direct_0' => [], 'induced_45' => [], 'precession_90' => [], 'systemic_135' => [], 'counter_180' => []],
            'risk_score' => 0.55,
        ];

        $criticalAlerts = $this->engine->evaluateThresholds($criticalAnalysis, 1, 1);
        $warningAlerts = $this->engine->evaluateThresholds($warningAnalysis, 1, 1);

        $criticalImpact = max(array_column($criticalAlerts, 'potential_impact_uf'));
        $warningImpact = max(array_column($warningAlerts, 'potential_impact_uf'));

        // Impacto crítico debe ser mayor
        $this->assertGreaterThan($warningImpact, $criticalImpact);
    }

    // =========================================================================
    // TESTS DE RECOMENDACIONES
    // =========================================================================

    /** @test */
    public function it_generates_appropriate_recommendations(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => -0.85, 'confidence' => 0.9, 'lag_months' => 6, 'angle_class' => 'counter_180'],
            ],
            'metrics' => ['avg_confidence' => 0.9],
            'effects_by_angle' => ['direct_0' => [], 'induced_45' => [], 'precession_90' => [], 'systemic_135' => [], 'counter_180' => []],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        foreach ($alerts as $alert) {
            $this->assertNotEmpty($alert['recommendation']);
            $this->assertIsString($alert['recommendation']);
            $this->assertGreaterThan(10, strlen($alert['recommendation']));
        }
    }

    // =========================================================================
    // TESTS DE ÁNGULO PREDOMINANTE
    // =========================================================================

    /** @test */
    public function it_determines_predominant_angle(): void
    {
        $analysis = [
            'effects' => [
                ['weight' => 0.5, 'confidence' => 0.8, 'lag_months' => 12, 'angle_class' => 'precession_90'],
                ['weight' => 0.6, 'confidence' => 0.85, 'lag_months' => 18, 'angle_class' => 'precession_90'],
                ['weight' => 0.3, 'confidence' => 0.7, 'lag_months' => 6, 'angle_class' => 'induced_45'],
            ],
            'metrics' => ['avg_confidence' => 0.78],
            'effects_by_angle' => [
                'direct_0' => [],
                'induced_45' => [['weight' => 0.3]],
                'precession_90' => [['weight' => 0.5], ['weight' => 0.6]],
                'systemic_135' => [],
                'counter_180' => [],
            ],
        ];

        $alerts = $this->engine->evaluateThresholds($analysis, 1, 1);

        // Si hay alertas, el ángulo predominante debe ser precession_90
        foreach ($alerts as $alert) {
            $this->assertEquals('precession_90', $alert['precession_angle']);
        }
    }

    // =========================================================================
    // TESTS DE ESTADÍSTICAS
    // =========================================================================

    /** @test */
    public function it_provides_alert_statistics(): void
    {
        $stats = $this->engine->getAlertStats(null, 30);

        $this->assertArrayHasKey('total', $stats);
        $this->assertArrayHasKey('by_severity', $stats);
        $this->assertArrayHasKey('by_type', $stats);
        $this->assertArrayHasKey('by_status', $stats);
        $this->assertArrayHasKey('critical_active', $stats);
        $this->assertArrayHasKey('resolved_rate', $stats);
    }
}
