<?php

declare(strict_types=1);

namespace Tests\Unit\PAE;

use App\Services\PAE\PrecessionScoringEngine;
use Tests\TestCase;

/**
 * =========================================================================
 * PAE M11-DP - SCORING ENGINE TESTS
 * Tests Unitarios para PrecessionScoringEngine
 * =========================================================================
 *
 * Valida el funcionamiento del motor de scoring nativo.
 * NO realiza ninguna llamada HTTP externa.
 *
 * @package Tests\Unit\PAE
 * @version 1.0.0
 * @author DATAPOLIS SpA
 */
class PrecessionScoringEngineNativeTest extends TestCase
{
    protected PrecessionScoringEngine $engine;

    protected function setUp(): void
    {
        parent::setUp();
        $this->engine = new PrecessionScoringEngine();
    }

    // =========================================================================
    // TESTS DE PRECESSION SCORE
    // =========================================================================

    /** @test */
    public function precession_score_is_between_0_and_100(): void
    {
        $effects = $this->getSampleEffects();

        $score = $this->engine->calculatePrecessionScore($effects);

        $this->assertGreaterThanOrEqual(0, $score);
        $this->assertLessThanOrEqual(100, $score);
    }

    /** @test */
    public function precession_score_returns_zero_for_empty_effects(): void
    {
        $score = $this->engine->calculatePrecessionScore([]);

        $this->assertEquals(0.0, $score);
    }

    /** @test */
    public function precession_score_weights_by_angle(): void
    {
        // Efectos solo a 90° (precesión) deberían tener mayor peso
        $effects90 = [
            [
                'weight' => 0.5,
                'angle_class' => 'precession_90',
                'confidence' => 0.8,
            ],
        ];

        // Efectos solo a 0° (directo) deberían tener menor peso
        $effects0 = [
            [
                'weight' => 0.5,
                'angle_class' => 'direct_0',
                'confidence' => 0.8,
            ],
        ];

        $score90 = $this->engine->calculatePrecessionScore($effects90);
        $score0 = $this->engine->calculatePrecessionScore($effects0);

        // El score con efectos a 90° debería ser mayor
        $this->assertGreaterThan($score0, $score90);
    }

    /** @test */
    public function precession_score_considers_confidence(): void
    {
        $highConfidence = [
            ['weight' => 0.5, 'angle_class' => 'precession_90', 'confidence' => 0.95],
        ];

        $lowConfidence = [
            ['weight' => 0.5, 'angle_class' => 'precession_90', 'confidence' => 0.3],
        ];

        $scoreHigh = $this->engine->calculatePrecessionScore($highConfidence);
        $scoreLow = $this->engine->calculatePrecessionScore($lowConfidence);

        $this->assertGreaterThan($scoreLow, $scoreHigh);
    }

    // =========================================================================
    // TESTS DE RISK SCORE
    // =========================================================================

    /** @test */
    public function risk_score_is_between_0_and_1(): void
    {
        $effects = $this->getSampleEffects();

        $score = $this->engine->calculateRiskScore($effects);

        $this->assertGreaterThanOrEqual(0, $score);
        $this->assertLessThanOrEqual(1, $score);
    }

    /** @test */
    public function risk_score_returns_zero_for_no_negative_effects(): void
    {
        $positiveEffects = [
            ['weight' => 0.5, 'confidence' => 0.8, 'lag_months' => 12],
            ['weight' => 0.3, 'confidence' => 0.7, 'lag_months' => 6],
        ];

        $score = $this->engine->calculateRiskScore($positiveEffects);

        $this->assertEquals(0.0, $score);
    }

    /** @test */
    public function risk_score_increases_with_negative_effects(): void
    {
        $fewNegative = [
            ['weight' => -0.3, 'confidence' => 0.8, 'lag_months' => 12],
        ];

        $manyNegative = [
            ['weight' => -0.3, 'confidence' => 0.8, 'lag_months' => 12],
            ['weight' => -0.4, 'confidence' => 0.9, 'lag_months' => 6],
            ['weight' => -0.5, 'confidence' => 0.85, 'lag_months' => 3],
        ];

        $scoreFew = $this->engine->calculateRiskScore($fewNegative);
        $scoreMany = $this->engine->calculateRiskScore($manyNegative);

        $this->assertGreaterThan($scoreFew, $scoreMany);
    }

    /** @test */
    public function risk_score_prioritizes_short_term_effects(): void
    {
        $shortTerm = [
            ['weight' => -0.5, 'confidence' => 0.8, 'lag_months' => 3],
        ];

        $longTerm = [
            ['weight' => -0.5, 'confidence' => 0.8, 'lag_months' => 36],
        ];

        $scoreShort = $this->engine->calculateRiskScore($shortTerm);
        $scoreLong = $this->engine->calculateRiskScore($longTerm);

        // Corto plazo debería tener mayor riesgo
        $this->assertGreaterThan($scoreLong, $scoreShort);
    }

    // =========================================================================
    // TESTS DE OPPORTUNITY SCORE
    // =========================================================================

    /** @test */
    public function opportunity_score_is_between_0_and_1(): void
    {
        $effects = $this->getSampleEffects();

        $score = $this->engine->calculateOpportunityScore($effects);

        $this->assertGreaterThanOrEqual(0, $score);
        $this->assertLessThanOrEqual(1, $score);
    }

    /** @test */
    public function opportunity_score_returns_zero_for_no_positive_effects(): void
    {
        $negativeEffects = [
            ['weight' => -0.5, 'confidence' => 0.8, 'angle_class' => 'counter_180'],
            ['weight' => -0.3, 'confidence' => 0.7, 'angle_class' => 'counter_180'],
        ];

        $score = $this->engine->calculateOpportunityScore($negativeEffects);

        $this->assertEquals(0.0, $score);
    }

    /** @test */
    public function opportunity_score_prioritizes_precession_angle(): void
    {
        $precessionEffects = [
            ['weight' => 0.5, 'confidence' => 0.8, 'angle_class' => 'precession_90'],
        ];

        $directEffects = [
            ['weight' => 0.5, 'confidence' => 0.8, 'angle_class' => 'direct_0'],
        ];

        $scorePrecession = $this->engine->calculateOpportunityScore($precessionEffects);
        $scoreDirect = $this->engine->calculateOpportunityScore($directEffects);

        // Efectos a 90° tienen bonus de oportunidad
        $this->assertGreaterThan($scoreDirect, $scorePrecession);
    }

    // =========================================================================
    // TESTS DE INVESTMENT SCORE
    // =========================================================================

    /** @test */
    public function investment_score_returns_complete_structure(): void
    {
        $copropiedadData = $this->getSampleCopropiedadData();
        $analysis = $this->getSampleAnalysis();

        $result = $this->engine->calculateInvestmentScore($copropiedadData, $analysis);

        $this->assertArrayHasKey('score', $result);
        $this->assertArrayHasKey('nivel_riesgo', $result);
        $this->assertArrayHasKey('recomendacion', $result);
        $this->assertArrayHasKey('horizonte_meses', $result);
        $this->assertArrayHasKey('breakdown', $result);
        $this->assertArrayHasKey('risk_score', $result);
        $this->assertArrayHasKey('opportunity_score', $result);
    }

    /** @test */
    public function investment_score_is_between_0_and_100(): void
    {
        $copropiedadData = $this->getSampleCopropiedadData();
        $analysis = $this->getSampleAnalysis();

        $result = $this->engine->calculateInvestmentScore($copropiedadData, $analysis);

        $this->assertGreaterThanOrEqual(0, $result['score']);
        $this->assertLessThanOrEqual(100, $result['score']);
    }

    /** @test */
    public function investment_score_breakdown_sums_to_composite(): void
    {
        $copropiedadData = $this->getSampleCopropiedadData();
        $analysis = $this->getSampleAnalysis();

        $result = $this->engine->calculateInvestmentScore($copropiedadData, $analysis);

        $breakdownSum = array_sum(array_column($result['breakdown'], 'contribution'));

        // Permitir pequeña diferencia por redondeo
        $this->assertEqualsWithDelta($result['score'] / 100, $breakdownSum, 0.01);
    }

    /** @test */
    public function investment_score_determines_risk_level(): void
    {
        $lowRiskData = [
            'indice_morosidad' => 3,
            'tasa_vacancia' => 2,
            'compliance_score' => 90,
        ];

        $highRiskData = [
            'indice_morosidad' => 35,
            'tasa_vacancia' => 25,
            'compliance_score' => 30,
        ];

        $lowRiskAnalysis = ['effects' => []];
        $highRiskAnalysis = [
            'effects' => [
                ['weight' => -0.8, 'confidence' => 0.9, 'lag_months' => 6, 'angle_class' => 'counter_180'],
            ],
        ];

        $lowRiskResult = $this->engine->calculateInvestmentScore($lowRiskData, $lowRiskAnalysis);
        $highRiskResult = $this->engine->calculateInvestmentScore($highRiskData, $highRiskAnalysis);

        $this->assertContains($lowRiskResult['nivel_riesgo'], ['muy_bajo', 'bajo', 'moderado']);
        $this->assertContains($highRiskResult['nivel_riesgo'], ['alto', 'muy_alto', 'moderado']);
    }

    /** @test */
    public function investment_score_generates_recommendation(): void
    {
        $copropiedadData = $this->getSampleCopropiedadData();
        $analysis = $this->getSampleAnalysis();

        $result = $this->engine->calculateInvestmentScore($copropiedadData, $analysis);

        $this->assertNotEmpty($result['recomendacion']);
        $this->assertIsString($result['recomendacion']);
    }

    /** @test */
    public function investment_score_determines_optimal_horizon(): void
    {
        $copropiedadData = $this->getSampleCopropiedadData();
        $analysis = $this->getSampleAnalysis();

        $result = $this->engine->calculateInvestmentScore($copropiedadData, $analysis);

        // Horizonte debe ser múltiplo de 6 y entre 6-60
        $this->assertGreaterThanOrEqual(6, $result['horizonte_meses']);
        $this->assertLessThanOrEqual(60, $result['horizonte_meses']);
        $this->assertEquals(0, $result['horizonte_meses'] % 6);
    }

    // =========================================================================
    // TESTS DE COMPARACIÓN
    // =========================================================================

    /** @test */
    public function compare_copropiedades_returns_rankings(): void
    {
        $copropiedadesData = [
            1 => [
                'data' => ['nombre' => 'Copropiedad 1', 'indice_morosidad' => 5],
                'analysis' => ['effects' => []],
            ],
            2 => [
                'data' => ['nombre' => 'Copropiedad 2', 'indice_morosidad' => 15],
                'analysis' => ['effects' => []],
            ],
            3 => [
                'data' => ['nombre' => 'Copropiedad 3', 'indice_morosidad' => 10],
                'analysis' => ['effects' => []],
            ],
        ];

        $result = $this->engine->compareCopropiedades($copropiedadesData);

        $this->assertArrayHasKey('scores', $result);
        $this->assertArrayHasKey('rankings', $result);
        $this->assertArrayHasKey('differential', $result);
        $this->assertArrayHasKey('summary', $result);

        // Verificar rankings
        $this->assertArrayHasKey('by_investment', $result['rankings']);
        $this->assertArrayHasKey('by_risk', $result['rankings']);
        $this->assertArrayHasKey('by_opportunity', $result['rankings']);
    }

    /** @test */
    public function compare_copropiedades_calculates_differential(): void
    {
        $copropiedadesData = [
            1 => [
                'data' => ['nombre' => 'Copropiedad 1'],
                'analysis' => ['effects' => []],
            ],
            2 => [
                'data' => ['nombre' => 'Copropiedad 2'],
                'analysis' => ['effects' => []],
            ],
        ];

        $result = $this->engine->compareCopropiedades($copropiedadesData);

        $this->assertArrayHasKey('1_vs_2', $result['differential']);

        $diff = $result['differential']['1_vs_2'];
        $this->assertArrayHasKey('investment_diff', $diff);
        $this->assertArrayHasKey('risk_diff', $diff);
        $this->assertArrayHasKey('better_investment', $diff);
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    protected function getSampleEffects(): array
    {
        return [
            [
                'weight' => 0.5,
                'confidence' => 0.8,
                'angle_class' => 'precession_90',
                'lag_months' => 12,
            ],
            [
                'weight' => -0.3,
                'confidence' => 0.7,
                'angle_class' => 'counter_180',
                'lag_months' => 18,
            ],
            [
                'weight' => 0.4,
                'confidence' => 0.85,
                'angle_class' => 'induced_45',
                'lag_months' => 6,
            ],
        ];
    }

    protected function getSampleCopropiedadData(): array
    {
        return [
            'nombre' => 'Test Copropiedad',
            'indice_morosidad' => 8,
            'gasto_comun_promedio' => 2.5,
            'compliance_score' => 75,
            'tasa_vacancia' => 5,
            'valor_suelo_m2' => 40,
            'cobertura_equipamiento' => 70,
        ];
    }

    protected function getSampleAnalysis(): array
    {
        return [
            'effects' => $this->getSampleEffects(),
            'metrics' => [
                'total_effects' => 3,
                'positive_effects' => 2,
                'negative_effects' => 1,
                'avg_confidence' => 0.78,
            ],
        ];
    }
}
