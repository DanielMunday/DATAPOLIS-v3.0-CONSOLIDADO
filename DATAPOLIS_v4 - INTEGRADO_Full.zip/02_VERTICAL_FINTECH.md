# DATAPOLIS v4.0 - ARQUITECTURA EMPRESARIAL
## PARTE 2: VERTICAL FINTECH (FINANCE)

---

# 3. VERTICAL FINTECH (FINANCE)

## 3.1 Visión General

La vertical FinTech de DATAPOLIS aborda las necesidades de instituciones financieras en cuatro dominios críticos: Open Finance (NCG 514), Riesgo de Crédito (Basel IV), Valoración de Colaterales, y Scoring Crediticio. Esta vertical está diseñada para bancos, cooperativas de ahorro, fintechs, y administradoras de fondos.

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        VERTICAL FINTECH                                 │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                    MÓDULOS FINTECH                              │   │
│  ├─────────────────────────────────────────────────────────────────┤   │
│  │                                                                 │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────┐│   │
│  │  │   M01-OF    │  │   M02-CS    │  │   M03-RWA   │  │ M04-COL ││   │
│  │  │   Open      │  │   Credit    │  │   Risk      │  │Collateral│   │
│  │  │  Finance    │  │  Scoring    │  │  Weighted   │  │ Valuation│   │
│  │  │             │  │  Basel IV   │  │   Assets    │  │          ││   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────┘│   │
│  │                                                                 │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │   │
│  │  │   M05-PF    │  │   M06-LIQ   │  │       M07-STRESS        │ │   │
│  │  │  Portfolio  │  │  Liquidity  │  │     Stress Testing      │ │   │
│  │  │ Management  │  │    Risk     │  │     & Scenarios         │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────────────┘ │   │
│  │                                                                 │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  INTEGRACIONES:                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ CMF → NCG 514  │  SBIF → Basel  │  SII → Impuestos  │  TGSS    │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 3.2 Módulo M01-OF: Open Finance (NCG 514)

### 3.2.1 Descripción

El módulo Open Finance implementa el marco regulatorio de la NCG 514 de la CMF (Comisión para el Mercado Financiero), habilitando el Sistema de Finanzas Abiertas de Chile. Permite la portabilidad segura de datos financieros entre instituciones bajo consentimiento explícito del cliente.

### 3.2.2 Funcionalidades Detalladas

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     M01-OF: OPEN FINANCE                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  FUNCIONALIDAD 1: GESTIÓN DE CONSENTIMIENTO                            │
│  ════════════════════════════════════════════                          │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ • Captura de consentimiento granular (por tipo de dato)           │ │
│  │ • Almacenamiento criptográfico de evidencia de consentimiento     │ │
│  │ • Revocación en tiempo real con propagación a terceros            │ │
│  │ • Dashboard de consentimientos activos por cliente                │ │
│  │ • Historial auditable de cambios de consentimiento                │ │
│  │ • Expiración automática configurable (30/60/90/365 días)          │ │
│  │ • Notificaciones pre-expiración al cliente                        │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  FUNCIONALIDAD 2: APIS DE DATOS FINANCIEROS                            │
│  ═══════════════════════════════════════════                           │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ ENDPOINTS IMPLEMENTADOS:                                          │ │
│  │                                                                   │ │
│  │ /accounts                                                         │ │
│  │ ├── GET  /accounts                    → Lista cuentas del cliente │ │
│  │ ├── GET  /accounts/{id}               → Detalle de cuenta         │ │
│  │ └── GET  /accounts/{id}/transactions  → Movimientos               │ │
│  │                                                                   │ │
│  │ /credit                                                           │ │
│  │ ├── GET  /credit/cards                → Tarjetas de crédito       │ │
│  │ ├── GET  /credit/loans                → Préstamos activos         │ │
│  │ └── GET  /credit/history              → Historial crediticio      │ │
│  │                                                                   │ │
│  │ /investments                                                      │ │
│  │ ├── GET  /investments/portfolios      → Portafolios               │ │
│  │ ├── GET  /investments/positions       → Posiciones actuales       │ │
│  │ └── GET  /investments/transactions    → Operaciones               │ │
│  │                                                                   │ │
│  │ /insurance                                                        │ │
│  │ ├── GET  /insurance/policies          → Pólizas vigentes          │ │
│  │ └── GET  /insurance/claims            → Siniestros                │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  FUNCIONALIDAD 3: SEGURIDAD FAPI 2.0                                   │
│  ═══════════════════════════════════                                   │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ IMPLEMENTACIÓN DE SEGURIDAD:                                      │ │
│  │                                                                   │ │
│  │ • OAuth 2.0 + PKCE (Proof Key for Code Exchange)                  │ │
│  │ • Mutual TLS (mTLS) con certificados X.509                        │ │
│  │ • JWT firmados con RS256 (RSA-SHA256)                             │ │
│  │ • Refresh tokens con rotación automática                          │ │
│  │ • Rate limiting por cliente (1000 req/min)                        │ │
│  │ • DDoS protection integrado                                       │ │
│  │ • Logs de acceso inmutables (append-only)                         │ │
│  │ • Cifrado AES-256-GCM para datos en reposo                        │ │
│  │ • TLS 1.3 obligatorio para datos en tránsito                      │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  FUNCIONALIDAD 4: TRAZABILIDAD Y AUDITORÍA                             │
│  ═════════════════════════════════════════                             │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ • Registro de cada request con timestamp UTC                      │ │
│  │ • Identificación de origen (IP, certificado, API key)             │ │
│  │ • Hash de payload para integridad                                 │ │
│  │ • Retención mínima 5 años (configurable)                          │ │
│  │ • Exportación en formatos CMF-compatibles                         │ │
│  │ • Alertas de anomalías (patrones inusuales de acceso)             │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.2.3 Arquitectura Técnica M01-OF

```
┌─────────────────────────────────────────────────────────────────────────┐
│                   ARQUITECTURA M01-OF                                   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  FRONTEND (Next.js 14)                                                  │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  /app/open-finance/                                               │ │
│  │  ├── consent/                                                     │ │
│  │  │   ├── page.tsx           → Gestión de consentimientos          │ │
│  │  │   ├── [id]/page.tsx      → Detalle de consentimiento           │ │
│  │  │   └── components/                                              │ │
│  │  │       ├── ConsentForm.tsx                                      │ │
│  │  │       ├── ConsentList.tsx                                      │ │
│  │  │       └── ConsentTimeline.tsx                                  │ │
│  │  │                                                                │ │
│  │  ├── accounts/                                                    │ │
│  │  │   ├── page.tsx           → Vista de cuentas                    │ │
│  │  │   └── [id]/page.tsx      → Detalle y transacciones             │ │
│  │  │                                                                │ │
│  │  ├── connections/                                                 │ │
│  │  │   ├── page.tsx           → Instituciones conectadas            │ │
│  │  │   └── add/page.tsx       → Agregar conexión                    │ │
│  │  │                                                                │ │
│  │  └── components/                                                  │ │
│  │      ├── AccountCard.tsx                                          │ │
│  │      ├── TransactionTable.tsx                                     │ │
│  │      ├── SecurityBadge.tsx                                        │ │
│  │      └── ConnectionStatus.tsx                                     │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  BACKEND (FastAPI + Laravel)                                           │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  FastAPI (api-gateway/):                                          │ │
│  │  ├── routers/                                                     │ │
│  │  │   ├── open_finance.py    → Endpoints públicos FAPI             │ │
│  │  │   ├── consent.py         → Gestión de consentimientos          │ │
│  │  │   └── webhooks.py        → Callbacks de terceros               │ │
│  │  │                                                                │ │
│  │  ├── services/                                                    │ │
│  │  │   ├── oauth_service.py   → OAuth 2.0 + PKCE                    │ │
│  │  │   ├── mtls_service.py    → Validación de certificados          │ │
│  │  │   ├── consent_service.py → Lógica de consentimiento            │ │
│  │  │   └── audit_service.py   → Logging y trazabilidad              │ │
│  │  │                                                                │ │
│  │  └── security/                                                    │ │
│  │      ├── fapi_middleware.py → Middleware FAPI 2.0                 │ │
│  │      ├── rate_limiter.py    → Control de tasa                     │ │
│  │      └── encryption.py      → Cifrado AES-256                     │ │
│  │                                                                   │ │
│  │  Laravel (laravel-app/):                                          │ │
│  │  ├── app/Http/Controllers/                                        │ │
│  │  │   └── OpenFinanceController.php → Admin y reportes             │ │
│  │  │                                                                │ │
│  │  ├── app/Models/                                                  │ │
│  │  │   ├── Consent.php                                              │ │
│  │  │   ├── Connection.php                                           │ │
│  │  │   └── AuditLog.php                                             │ │
│  │  │                                                                │ │
│  │  └── app/Jobs/                                                    │ │
│  │      ├── SyncAccountsJob.php                                      │ │
│  │      └── ConsentExpirationJob.php                                 │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  BASE DE DATOS                                                          │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  PostgreSQL:                                                      │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ consents                                                    │ │ │
│  │  │ ├── id: UUID (PK)                                           │ │ │
│  │  │ ├── client_id: UUID (FK → clients)                          │ │ │
│  │  │ ├── third_party_id: UUID (FK → institutions)                │ │ │
│  │  │ ├── scope: JSONB (permisos granulares)                      │ │ │
│  │  │ ├── status: ENUM (active, revoked, expired)                 │ │ │
│  │  │ ├── granted_at: TIMESTAMP                                   │ │ │
│  │  │ ├── expires_at: TIMESTAMP                                   │ │ │
│  │  │ ├── revoked_at: TIMESTAMP NULL                              │ │ │
│  │  │ └── evidence_hash: VARCHAR(64) (SHA-256)                    │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ api_access_logs (particionada por mes)                      │ │ │
│  │  │ ├── id: BIGSERIAL (PK)                                      │ │ │
│  │  │ ├── consent_id: UUID (FK)                                   │ │ │
│  │  │ ├── endpoint: VARCHAR(255)                                  │ │ │
│  │  │ ├── method: VARCHAR(10)                                     │ │ │
│  │  │ ├── request_hash: VARCHAR(64)                               │ │ │
│  │  │ ├── response_code: INT                                      │ │ │
│  │  │ ├── ip_address: INET                                        │ │ │
│  │  │ ├── user_agent: TEXT                                        │ │ │
│  │  │ ├── certificate_cn: VARCHAR(255)                            │ │ │
│  │  │ └── created_at: TIMESTAMP                                   │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  │  Redis:                                                           │ │
│  │  ├── rate_limit:{client_id}  → Contador con TTL                  │ │
│  │  ├── token:{access_token}    → Metadata de sesión                │ │
│  │  └── revoked:{token_id}      → Lista de tokens revocados         │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.2.4 API Reference M01-OF

```yaml
# OpenAPI 3.0 Specification - M01-OF

openapi: 3.0.3
info:
  title: DATAPOLIS Open Finance API (NCG 514)
  version: 1.0.0
  description: API compatible con NCG 514 CMF Chile

servers:
  - url: https://api.datapolis.cl/v1/open-finance
    description: Production

security:
  - BearerAuth: []
  - mTLS: []

paths:
  /consent:
    post:
      summary: Crear nuevo consentimiento
      tags: [Consent]
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ConsentRequest'
      responses:
        '201':
          description: Consentimiento creado
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ConsentResponse'
        '400':
          $ref: '#/components/responses/BadRequest'
        '401':
          $ref: '#/components/responses/Unauthorized'

  /consent/{consent_id}:
    get:
      summary: Obtener detalle de consentimiento
      tags: [Consent]
      parameters:
        - name: consent_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      responses:
        '200':
          description: Detalle del consentimiento
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ConsentDetail'

    delete:
      summary: Revocar consentimiento
      tags: [Consent]
      parameters:
        - name: consent_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      responses:
        '204':
          description: Consentimiento revocado

  /accounts:
    get:
      summary: Listar cuentas del cliente
      tags: [Accounts]
      parameters:
        - name: consent_id
          in: header
          required: true
          schema:
            type: string
            format: uuid
      responses:
        '200':
          description: Lista de cuentas
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/Account'

  /accounts/{account_id}/transactions:
    get:
      summary: Obtener transacciones de cuenta
      tags: [Accounts]
      parameters:
        - name: account_id
          in: path
          required: true
          schema:
            type: string
        - name: from_date
          in: query
          schema:
            type: string
            format: date
        - name: to_date
          in: query
          schema:
            type: string
            format: date
        - name: page
          in: query
          schema:
            type: integer
            default: 1
        - name: per_page
          in: query
          schema:
            type: integer
            default: 50
            maximum: 100
      responses:
        '200':
          description: Lista de transacciones
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/TransactionList'

components:
  schemas:
    ConsentRequest:
      type: object
      required:
        - client_id
        - third_party_id
        - scope
        - duration_days
      properties:
        client_id:
          type: string
          format: uuid
        third_party_id:
          type: string
          format: uuid
        scope:
          type: array
          items:
            type: string
            enum:
              - accounts:read
              - transactions:read
              - credit:read
              - investments:read
              - insurance:read
        duration_days:
          type: integer
          minimum: 1
          maximum: 365

    ConsentResponse:
      type: object
      properties:
        consent_id:
          type: string
          format: uuid
        status:
          type: string
          enum: [active, pending]
        granted_at:
          type: string
          format: date-time
        expires_at:
          type: string
          format: date-time
        scope:
          type: array
          items:
            type: string

    Account:
      type: object
      properties:
        account_id:
          type: string
        account_type:
          type: string
          enum: [checking, savings, credit_card, loan]
        currency:
          type: string
          example: CLP
        balance:
          type: number
          format: float
        available_balance:
          type: number
          format: float
        institution:
          type: string
        last_updated:
          type: string
          format: date-time

    Transaction:
      type: object
      properties:
        transaction_id:
          type: string
        date:
          type: string
          format: date-time
        amount:
          type: number
        currency:
          type: string
        description:
          type: string
        category:
          type: string
        merchant:
          type: string
        status:
          type: string
          enum: [pending, completed, reversed]

  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
    mTLS:
      type: mutualTLS
```

---

## 3.3 Módulo M02-CS: Credit Scoring Basel IV

### 3.3.1 Descripción

El módulo Credit Scoring implementa modelos de riesgo crediticio alineados con Basel IV, calculando los parámetros fundamentales: PD (Probability of Default), LGD (Loss Given Default), y EAD (Exposure at Default). Soporta tanto el enfoque estandarizado (SA) como el enfoque basado en calificaciones internas (IRB).

### 3.3.2 Funcionalidades Detalladas

```
┌─────────────────────────────────────────────────────────────────────────┐
│                  M02-CS: CREDIT SCORING BASEL IV                        │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  FUNCIONALIDAD 1: CÁLCULO DE PD (Probability of Default)              │
│  ══════════════════════════════════════════════════════                │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ METODOLOGÍAS IMPLEMENTADAS:                                       │ │
│  │                                                                   │ │
│  │ • Regresión Logística (Logit)                                     │ │
│  │   - Variables financieras: ratios de liquidez, endeudamiento      │ │
│  │   - Variables comportamentales: historial de pagos, morosidad     │ │
│  │   - Variables demográficas: edad, antigüedad laboral              │ │
│  │                                                                   │ │
│  │ • Machine Learning                                                │ │
│  │   - Gradient Boosting (XGBoost, LightGBM)                         │ │
│  │   - Random Forest con calibración                                 │ │
│  │   - Redes neuronales (para grandes volúmenes)                     │ │
│  │                                                                   │ │
│  │ • Modelos híbridos                                                │ │
│  │   - Ensemble de modelos con ponderación optimizada                │ │
│  │   - Stacking con meta-learner                                     │ │
│  │                                                                   │ │
│  │ OUTPUTS:                                                          │ │
│  │ ┌─────────────────────────────────────────────────────────────┐   │ │
│  │ │ • PD Point-in-Time (PIT): Probabilidad a 12 meses           │   │ │
│  │ │ • PD Through-the-Cycle (TTC): Probabilidad promedio ciclo   │   │ │
│  │ │ • Intervalo de confianza (95%)                              │   │ │
│  │ │ • Contribución de cada variable al score                    │   │ │
│  │ │ • Rating interno (escala 1-10 o AAA-D)                      │   │ │
│  │ └─────────────────────────────────────────────────────────────┘   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  FUNCIONALIDAD 2: CÁLCULO DE LGD (Loss Given Default)                  │
│  ═══════════════════════════════════════════════════                   │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ METODOLOGÍAS:                                                     │ │
│  │                                                                   │ │
│  │ • Workout LGD                                                     │ │
│  │   LGD = 1 - (Σ Recuperaciones / EAD)                              │ │
│  │   - Descuento a tasa apropiada al riesgo                          │ │
│  │   - Inclusión de costos de recuperación                           │ │
│  │                                                                   │ │
│  │ • Downturn LGD                                                    │ │
│  │   - Ajuste por condiciones adversas de mercado                    │ │
│  │   - Calibrado a peor período histórico                            │ │
│  │                                                                   │ │
│  │ SEGMENTACIÓN:                                                     │ │
│  │ ┌───────────────────────────────────────────────────────────────┐ │ │
│  │ │ Tipo de Garantía    │ LGD Base │ LGD Downturn │ Haircut      │ │ │
│  │ │ ──────────────────────────────────────────────────────────── │ │ │
│  │ │ Hipoteca residencial│   15%    │     25%      │    30%       │ │ │
│  │ │ Hipoteca comercial  │   25%    │     40%      │    40%       │ │ │
│  │ │ Prenda vehículo     │   35%    │     50%      │    35%       │ │ │
│  │ │ Prenda maquinaria   │   45%    │     60%      │    50%       │ │ │
│  │ │ Sin garantía        │   75%    │     85%      │    N/A       │ │ │
│  │ └───────────────────────────────────────────────────────────────┘ │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  FUNCIONALIDAD 3: CÁLCULO DE EAD (Exposure at Default)                 │
│  ════════════════════════════════════════════════════                  │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ FÓRMULA GENERAL:                                                  │ │
│  │ EAD = Outstanding + CCF × (Limit - Outstanding)                   │ │
│  │                                                                   │ │
│  │ CCF (Credit Conversion Factors):                                  │ │
│  │ ┌───────────────────────────────────────────────────────────────┐ │ │
│  │ │ Tipo de Producto        │ CCF Estándar │ CCF Interno (IRB)   │ │ │
│  │ │ ────────────────────────────────────────────────────────────  │ │ │
│  │ │ Préstamo plazo fijo     │    100%      │      100%           │ │ │
│  │ │ Línea de crédito        │     50%      │    40-60%           │ │ │
│  │ │ Tarjeta de crédito      │     75%      │    65-85%           │ │ │
│  │ │ Crédito contingente     │     20%      │    15-25%           │ │ │
│  │ │ Carta de crédito        │     50%      │    40-60%           │ │ │
│  │ │ Boletas de garantía     │     50%      │    45-55%           │ │ │
│  │ └───────────────────────────────────────────────────────────────┘ │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  FUNCIONALIDAD 4: SCORING INTEGRADO                                    │
│  ══════════════════════════════════                                    │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  FLUJO DE SCORING:                                                │ │
│  │                                                                   │ │
│  │  [Input Datos] ──→ [Preprocesamiento] ──→ [Feature Engineering]   │ │
│  │        │                   │                      │               │ │
│  │        ▼                   ▼                      ▼               │ │
│  │  ┌─────────┐         ┌─────────┐           ┌─────────────┐        │ │
│  │  │ Validar │    →    │ Limpiar │     →     │ Crear vars  │        │ │
│  │  │ formato │         │ outliers│           │ derivadas   │        │ │
│  │  └─────────┘         └─────────┘           └─────────────┘        │ │
│  │                                                   │               │ │
│  │                                                   ▼               │ │
│  │  [Output]   ◄────   [Post-proceso]   ◄────  [Modelo ML]           │ │
│  │     │                    │                      │                 │ │
│  │     ▼                    ▼                      ▼                 │ │
│  │  ┌─────────┐       ┌──────────┐          ┌─────────────┐          │ │
│  │  │ Rating  │  ◄──  │ Calibrar │    ◄──   │ Predecir PD │          │ │
│  │  │ + Score │       │ proba.   │          │ + LGD + EAD │          │ │
│  │  └─────────┘       └──────────┘          └─────────────┘          │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  FUNCIONALIDAD 5: BACKTESTING Y VALIDACIÓN                             │
│  ═════════════════════════════════════════                             │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ MÉTRICAS DE VALIDACIÓN:                                           │ │
│  │                                                                   │ │
│  │ • Poder discriminante:                                            │ │
│  │   - Gini coefficient (objetivo: >0.40)                            │ │
│  │   - AUC-ROC (objetivo: >0.70)                                     │ │
│  │   - Kolmogorov-Smirnov (objetivo: >0.30)                          │ │
│  │                                                                   │ │
│  │ • Calibración:                                                    │ │
│  │   - Brier Score (objetivo: <0.15)                                 │ │
│  │   - Hosmer-Lemeshow test                                          │ │
│  │   - Binomial test por bucket                                      │ │
│  │                                                                   │ │
│  │ • Estabilidad:                                                    │ │
│  │   - Population Stability Index (PSI < 0.25)                       │ │
│  │   - Characteristic Stability Index por variable                   │ │
│  │                                                                   │ │
│  │ REPORTES AUTOMÁTICOS:                                             │ │
│  │ ┌─────────────────────────────────────────────────────────────┐   │ │
│  │ │ • Reporte trimestral de backtesting                         │   │ │
│  │ │ • Alertas de degradación de modelo                          │   │ │
│  │ │ • Comparación PD estimada vs defaults reales                │   │ │
│  │ │ • Análisis de cohorts por vintage                           │   │ │
│  │ └─────────────────────────────────────────────────────────────┘   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.3.3 Modelos Matemáticos M02-CS

```python
# credit_models.py - Implementación de modelos Basel IV

import numpy as np
from scipy import stats
from scipy.optimize import minimize
from sklearn.base import BaseEstimator, ClassifierMixin
from typing import Dict, Tuple, Optional

class BaselIVCreditModel(BaseEstimator, ClassifierMixin):
    """
    Modelo de scoring crediticio Basel IV compliant.
    Implementa PD, LGD, EAD y RWA calculation.
    """
    
    def __init__(
        self,
        approach: str = 'irb_foundation',  # 'standardized', 'irb_foundation', 'irb_advanced'
        asset_class: str = 'corporate',    # 'corporate', 'retail', 'sovereign', 'bank'
        confidence_level: float = 0.999,   # Basel requirement
        time_horizon: int = 1              # Years
    ):
        self.approach = approach
        self.asset_class = asset_class
        self.confidence_level = confidence_level
        self.time_horizon = time_horizon
        
    def calculate_pd(
        self,
        features: np.ndarray,
        model_type: str = 'logistic'
    ) -> Dict[str, float]:
        """
        Calcula Probability of Default.
        
        Returns:
            Dict con PD point-in-time, through-the-cycle, y bounds
        """
        # Implementación del modelo logístico
        if model_type == 'logistic':
            # Log-odds
            log_odds = np.dot(features, self.coefficients_) + self.intercept_
            pd_pit = 1 / (1 + np.exp(-log_odds))
        
        # Ajuste Through-the-Cycle
        economic_adjustment = self._get_economic_cycle_adjustment()
        pd_ttc = pd_pit * economic_adjustment
        
        # Confidence interval
        pd_std = self._estimate_pd_std(features)
        z_score = stats.norm.ppf(0.975)  # 95% CI
        
        return {
            'pd_pit': float(pd_pit),
            'pd_ttc': float(pd_ttc),
            'pd_lower': float(max(0, pd_ttc - z_score * pd_std)),
            'pd_upper': float(min(1, pd_ttc + z_score * pd_std)),
            'rating': self._pd_to_rating(pd_ttc)
        }
    
    def calculate_lgd(
        self,
        collateral_type: str,
        collateral_value: float,
        exposure: float,
        seniority: str = 'senior'
    ) -> Dict[str, float]:
        """
        Calcula Loss Given Default según tipo de garantía.
        """
        # LGD base por tipo de colateral
        lgd_base = {
            'residential_mortgage': 0.15,
            'commercial_mortgage': 0.25,
            'vehicle_pledge': 0.35,
            'equipment_pledge': 0.45,
            'unsecured': 0.75
        }.get(collateral_type, 0.45)
        
        # Haircut por tipo de colateral
        haircuts = {
            'residential_mortgage': 0.30,
            'commercial_mortgage': 0.40,
            'vehicle_pledge': 0.35,
            'equipment_pledge': 0.50,
            'unsecured': 1.00
        }
        haircut = haircuts.get(collateral_type, 0.50)
        
        # Valor ajustado del colateral
        collateral_adj = collateral_value * (1 - haircut)
        
        # LGD efectivo
        if exposure > 0:
            recovery_rate = min(collateral_adj / exposure, 1.0)
            lgd_effective = 1 - recovery_rate
        else:
            lgd_effective = lgd_base
        
        # Downturn LGD (add-on regulatorio)
        downturn_factor = 1.25 if self.asset_class == 'corporate' else 1.15
        lgd_downturn = min(lgd_effective * downturn_factor, 1.0)
        
        return {
            'lgd_base': lgd_base,
            'lgd_effective': lgd_effective,
            'lgd_downturn': lgd_downturn,
            'recovery_rate': 1 - lgd_effective,
            'collateral_coverage': collateral_adj / exposure if exposure > 0 else 0
        }
    
    def calculate_ead(
        self,
        outstanding: float,
        limit: float,
        product_type: str
    ) -> Dict[str, float]:
        """
        Calcula Exposure at Default.
        """
        # Credit Conversion Factors por producto
        ccf = {
            'term_loan': 1.00,
            'revolving_credit': 0.50,
            'credit_card': 0.75,
            'contingent_credit': 0.20,
            'letter_of_credit': 0.50,
            'guarantee': 0.50
        }.get(product_type, 0.75)
        
        # EAD calculation
        undrawn = max(0, limit - outstanding)
        ead = outstanding + ccf * undrawn
        
        return {
            'outstanding': outstanding,
            'undrawn': undrawn,
            'ccf': ccf,
            'ead': ead,
            'utilization': outstanding / limit if limit > 0 else 1.0
        }
    
    def calculate_rwa(
        self,
        pd: float,
        lgd: float,
        ead: float,
        maturity: float = 2.5
    ) -> Dict[str, float]:
        """
        Calcula Risk-Weighted Assets según Basel IV.
        
        Fórmula IRB:
        K = LGD × N[(1-R)^(-0.5) × G(PD) + (R/(1-R))^0.5 × G(0.999)] - PD × LGD
        RWA = K × 12.5 × EAD
        """
        # Correlación de activos (R)
        if self.asset_class == 'corporate':
            R = 0.12 * (1 - np.exp(-50 * pd)) / (1 - np.exp(-50)) + \
                0.24 * (1 - (1 - np.exp(-50 * pd)) / (1 - np.exp(-50)))
        elif self.asset_class == 'retail':
            R = 0.03 * (1 - np.exp(-35 * pd)) / (1 - np.exp(-35)) + \
                0.16 * (1 - (1 - np.exp(-35 * pd)) / (1 - np.exp(-35)))
        else:
            R = 0.15  # Default
        
        # Maturity adjustment
        b = (0.11852 - 0.05478 * np.log(pd)) ** 2
        maturity_adj = (1 + (maturity - 2.5) * b) / (1 - 1.5 * b)
        
        # Capital requirement (K)
        G = stats.norm.ppf  # Función de distribución normal inversa
        N = stats.norm.cdf  # Función de distribución normal acumulada
        
        K = lgd * N(
            (1 - R) ** (-0.5) * G(pd) + 
            (R / (1 - R)) ** 0.5 * G(self.confidence_level)
        ) - pd * lgd
        
        K = K * maturity_adj
        
        # RWA
        rwa = K * 12.5 * ead
        
        # Capital mínimo (8%)
        capital_required = rwa * 0.08
        
        return {
            'correlation': R,
            'maturity_adjustment': maturity_adj,
            'capital_requirement_k': K,
            'rwa': rwa,
            'capital_required': capital_required,
            'risk_weight': (rwa / ead * 100) if ead > 0 else 0
        }
    
    def _pd_to_rating(self, pd: float) -> str:
        """Convierte PD a rating interno."""
        if pd < 0.0001:
            return 'AAA'
        elif pd < 0.0005:
            return 'AA+'
        elif pd < 0.001:
            return 'AA'
        elif pd < 0.002:
            return 'AA-'
        elif pd < 0.004:
            return 'A+'
        elif pd < 0.008:
            return 'A'
        elif pd < 0.015:
            return 'A-'
        elif pd < 0.03:
            return 'BBB+'
        elif pd < 0.05:
            return 'BBB'
        elif pd < 0.08:
            return 'BBB-'
        elif pd < 0.12:
            return 'BB+'
        elif pd < 0.18:
            return 'BB'
        elif pd < 0.25:
            return 'BB-'
        elif pd < 0.35:
            return 'B+'
        elif pd < 0.50:
            return 'B'
        elif pd < 0.70:
            return 'B-'
        else:
            return 'CCC/D'


class BacktestingModule:
    """Módulo de backtesting para validación de modelos."""
    
    def __init__(self):
        self.metrics = {}
    
    def calculate_gini(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray
    ) -> float:
        """
        Calcula coeficiente de Gini.
        Gini = 2 * AUC - 1
        """
        from sklearn.metrics import roc_auc_score
        auc = roc_auc_score(y_true, y_pred)
        return 2 * auc - 1
    
    def calculate_ks(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray
    ) -> float:
        """Calcula estadístico Kolmogorov-Smirnov."""
        # Separar scores por clase
        scores_good = y_pred[y_true == 0]
        scores_bad = y_pred[y_true == 1]
        
        # KS = max|F_good(x) - F_bad(x)|
        ks_stat, _ = stats.ks_2samp(scores_good, scores_bad)
        return ks_stat
    
    def calculate_psi(
        self,
        expected: np.ndarray,
        actual: np.ndarray,
        bins: int = 10
    ) -> float:
        """
        Calcula Population Stability Index.
        PSI = Σ (Actual% - Expected%) × ln(Actual% / Expected%)
        """
        # Crear bins basados en expected
        breakpoints = np.percentile(expected, np.linspace(0, 100, bins + 1))
        breakpoints[0] = -np.inf
        breakpoints[-1] = np.inf
        
        # Distribuir en bins
        expected_bins = np.histogram(expected, bins=breakpoints)[0] / len(expected)
        actual_bins = np.histogram(actual, bins=breakpoints)[0] / len(actual)
        
        # Evitar división por cero
        expected_bins = np.clip(expected_bins, 0.0001, None)
        actual_bins = np.clip(actual_bins, 0.0001, None)
        
        # PSI
        psi = np.sum((actual_bins - expected_bins) * np.log(actual_bins / expected_bins))
        return psi
    
    def run_full_backtesting(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_pred_baseline: Optional[np.ndarray] = None
    ) -> Dict:
        """Ejecuta suite completa de backtesting."""
        from sklearn.metrics import brier_score_loss, roc_auc_score
        
        results = {
            'discrimination': {
                'gini': self.calculate_gini(y_true, y_pred),
                'auc_roc': roc_auc_score(y_true, y_pred),
                'ks_statistic': self.calculate_ks(y_true, y_pred)
            },
            'calibration': {
                'brier_score': brier_score_loss(y_true, y_pred),
                'mean_predicted': np.mean(y_pred),
                'mean_actual': np.mean(y_true),
                'ratio': np.mean(y_pred) / np.mean(y_true) if np.mean(y_true) > 0 else np.inf
            },
            'thresholds': {
                'gini_passed': self.calculate_gini(y_true, y_pred) > 0.40,
                'auc_passed': roc_auc_score(y_true, y_pred) > 0.70,
                'ks_passed': self.calculate_ks(y_true, y_pred) > 0.30,
                'brier_passed': brier_score_loss(y_true, y_pred) < 0.15
            }
        }
        
        # PSI si hay baseline
        if y_pred_baseline is not None:
            psi = self.calculate_psi(y_pred_baseline, y_pred)
            results['stability'] = {
                'psi': psi,
                'psi_passed': psi < 0.25,
                'interpretation': 'No shift' if psi < 0.1 else 'Moderate shift' if psi < 0.25 else 'Significant shift'
            }
        
        return results
```

---

## 3.4 Módulo M03-RWA: Risk-Weighted Assets Calculator

### 3.4.1 Descripción

Módulo especializado en el cálculo automatizado de Activos Ponderados por Riesgo, integrando los parámetros de PD, LGD y EAD para generar métricas de capital regulatorio. Soporta portfolios de hasta 1 millón de exposiciones con procesamiento paralelo.

### 3.4.2 Funcionalidades

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     M03-RWA: RISK-WEIGHTED ASSETS                       │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  CÁLCULO DE RWA POR ENFOQUE:                                           │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  ENFOQUE ESTANDARIZADO (SA):                                      │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ Clase de Activo        │ Ponderación │ Condiciones         │ │ │
│  │  │ ──────────────────────────────────────────────────────────  │ │ │
│  │  │ Soberanos (Chile)      │     0%      │ Rating AA- o mejor  │ │ │
│  │  │ Bancos rated AA-       │    20%      │ Exposición < 3M     │ │ │
│  │  │ Bancos rated A         │    50%      │ Exposición < 3M     │ │ │
│  │  │ Corporativos rated A+  │    50%      │ Audited financials  │ │ │
│  │  │ Corporativos sin rating│   100%      │ Standard            │ │ │
│  │  │ Hipotecas residenciales│    35%      │ LTV < 80%           │ │ │
│  │  │ Retail                 │    75%      │ Criterios Basel     │ │ │
│  │  │ Equity (listed)        │   100%      │ Standard            │ │ │
│  │  │ Equity (non-listed)    │   150%      │ Standard            │ │ │
│  │  │ Past due (>90 días)    │   150%      │ Provisiones < 20%   │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  │  ENFOQUE IRB FOUNDATION:                                          │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ Parámetro │ Fuente      │ Descripción                       │ │ │
│  │  │ ──────────────────────────────────────────────────────────  │ │ │
│  │  │ PD        │ Interno     │ Modelo calibrado del banco        │ │ │
│  │  │ LGD       │ Regulador   │ 45% senior / 75% subordinado      │ │ │
│  │  │ EAD       │ Regulador   │ CCF estándar por producto         │ │ │
│  │  │ M         │ Regulador   │ 2.5 años (estándar)               │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  │  ENFOQUE IRB ADVANCED:                                            │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ Parámetro │ Fuente      │ Descripción                       │ │ │
│  │  │ ──────────────────────────────────────────────────────────  │ │ │
│  │  │ PD        │ Interno     │ Modelo calibrado del banco        │ │ │
│  │  │ LGD       │ Interno     │ Modelo workout/downturn           │ │ │
│  │  │ EAD       │ Interno     │ Modelo de CCF internos            │ │ │
│  │  │ M         │ Interno     │ Madurez efectiva por exposición   │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  AGREGACIÓN DE PORTFOLIO:                                              │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  Total Portfolio                                                  │ │
│  │  ├── Por clase de activo                                          │ │
│  │  │   ├── Corporate: RWA = $X, Capital = $Y                        │ │
│  │  │   ├── Retail: RWA = $X, Capital = $Y                           │ │
│  │  │   ├── Sovereign: RWA = $X, Capital = $Y                        │ │
│  │  │   └── ...                                                      │ │
│  │  ├── Por segmento geográfico                                      │ │
│  │  ├── Por industria/sector                                         │ │
│  │  ├── Por producto                                                 │ │
│  │  └── Por bucket de riesgo (rating)                                │ │
│  │                                                                   │ │
│  │  Métricas agregadas:                                              │ │
│  │  • RWA Total                                                      │ │
│  │  • Capital Tier 1 requerido (6%)                                  │ │
│  │  • Capital Total requerido (8%)                                   │ │
│  │  • CET1 Ratio                                                     │ │
│  │  • Leverage Ratio                                                 │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  REPORTES REGULATORIOS:                                                │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ • Formato SBIF/CMF para Chile                                     │ │
│  │ • Pillar 3 Disclosure (formato Basel)                             │ │
│  │ • Stress testing reports (DFAST style)                            │ │
│  │ • Concentración de riesgo (grandes exposiciones)                  │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 3.5 Módulo M04-COL: Collateral Valuation

### 3.5.1 Descripción

Módulo de valoración de garantías que integra metodologías IVS (International Valuation Standards) con los requerimientos de Basel IV para colaterales elegibles. Incluye el módulo hedónico M-HED para valoraciones inmobiliarias automatizadas.

### 3.5.2 Integración con M-HED

```
┌─────────────────────────────────────────────────────────────────────────┐
│               M04-COL: COLLATERAL VALUATION                             │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  TIPOS DE COLATERAL Y METODOLOGÍA:                                     │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  INMUEBLES → M-HED (Precios Hedónicos)                            │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ • Modelo hedónico calibrado por mercado local               │ │ │
│  │  │ • Variables: superficie, ubicación, antigüedad, amenities   │ │ │
│  │  │ • Ajustes por condición y obsolescencia                     │ │ │
│  │  │ • Integración con M-ESV para valor de servicios ecosist.    │ │ │
│  │  │ • Output: Valor de mercado, IC 95%, precio implícito vars   │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  │  VEHÍCULOS → Base de Datos de Mercado                             │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ • Integración con ACHS, ANAC, marketplaces                  │ │ │
│  │  │ • Curvas de depreciación por marca/modelo                   │ │ │
│  │  │ • Ajustes por kilometraje, estado, accesorios               │ │ │
│  │  │ • Liquidación estimada (30/60/90 días)                      │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  │  MAQUINARIA Y EQUIPOS → Cost Approach                             │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ • Costo de reposición nuevo (CRN)                           │ │ │
│  │  │ • Depreciación física, funcional, económica                 │ │ │
│  │  │ • Valor de liquidación ordenada                             │ │ │
│  │  │ • Especialización de mercado secundario                     │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  │  ACTIVOS FINANCIEROS → Market Approach                            │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ • Acciones: Último precio + volatilidad                     │ │ │
│  │  │ • Bonos: Mark-to-market + spread crediticio                 │ │ │
│  │  │ • Fondos: NAV ajustado por liquidez                         │ │ │
│  │  │ • Derivados: Valoración según normativa CMF                 │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  │  INVENTARIOS → Net Realizable Value                               │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ • Precio de venta estimado - costos de venta                │ │ │
│  │  │ • Obsolescencia y rotación                                  │ │ │
│  │  │ • Valoración por categoría (commodities, perecederos, etc)  │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  HAIRCUTS REGULATORIOS:                                                │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ Tipo de Colateral              │ Haircut SA │ Haircut IRB         │ │
│  │ ──────────────────────────────────────────────────────────────    │ │
│  │ Cash / Depósitos               │     0%     │      0%             │ │
│  │ Bonos soberanos AA-            │     1%     │      1%             │ │
│  │ Bonos corporativos A           │     8%     │      6%             │ │
│  │ Acciones índice principal      │    15%     │     12%             │ │
│  │ Acciones otras                 │    25%     │     20%             │ │
│  │ Inmuebles residenciales        │    30%     │     25%             │ │
│  │ Inmuebles comerciales          │    40%     │     35%             │ │
│  │ Vehículos                      │    35%     │     30%             │ │
│  │ Maquinaria                     │    50%     │     45%             │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 3.6 Resumen Vertical FinTech

### Tabla de Módulos

| Módulo | Nombre | Tipo de Análisis | Estándares | Estado |
|--------|--------|------------------|------------|--------|
| M01-OF | Open Finance | APIs financieras, consentimiento | NCG 514, FAPI 2.0 | ✅ Producción |
| M02-CS | Credit Scoring | PD/LGD/EAD, ML models | Basel IV IRB | ✅ Producción |
| M03-RWA | Risk-Weighted Assets | Capital calculation | Basel IV SA/IRB | ✅ Producción |
| M04-COL | Collateral Valuation | Market/Cost/Income | IVS 2022, RICS | ✅ Producción |
| M05-PF | Portfolio Management | Concentration, limits | CMF, Basel | 🔄 Beta |
| M06-LIQ | Liquidity Risk | LCR, NSFR | Basel III | 🔄 Beta |
| M07-STRESS | Stress Testing | Scenarios, shocks | DFAST, EBA | 📋 Roadmap |

### Stack Tecnológico FinTech

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    STACK TECNOLÓGICO FINTECH                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  FRONTEND:                                                              │
│  ├── Framework: Next.js 14 (App Router)                                 │
│  ├── Estado: Zustand + React Query                                      │
│  ├── Gráficos: Recharts, D3.js para visualizaciones complejas           │
│  ├── Tablas: TanStack Table con virtualización                          │
│  └── Formularios: React Hook Form + Zod validation                      │
│                                                                         │
│  BACKEND:                                                               │
│  ├── API Gateway: FastAPI (Python 3.11+)                                │
│  ├── Business Logic: Laravel 11 (PHP 8.3)                               │
│  ├── ML Models: Scikit-learn, XGBoost, PyTorch                          │
│  ├── Async Tasks: Celery + Redis                                        │
│  └── Seguridad: OAuth 2.0 (Authlib), mTLS                               │
│                                                                         │
│  BASE DE DATOS:                                                         │
│  ├── Principal: PostgreSQL 16 (partitioned tables)                      │
│  ├── Caché: Redis 7 (sessions, rate limiting)                           │
│  ├── Time Series: TimescaleDB (market data)                             │
│  └── Logs: Elasticsearch (audit trail)                                  │
│                                                                         │
│  INFRAESTRUCTURA:                                                       │
│  ├── Contenedores: Docker + Kubernetes                                  │
│  ├── CI/CD: GitHub Actions                                              │
│  ├── Monitoreo: Prometheus + Grafana                                    │
│  └── Seguridad: Vault (secrets), WAF                                    │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

*Continúa en Parte 3: Vertical LegalTech*
