# DATAPOLIS v4.0 - ARQUITECTURA EMPRESARIAL
## PARTE 4: VERTICALES REGTECH, DATATECH, PROPTECH

---

# 5. VERTICAL REGTECH

## 5.1 Visión General

La vertical RegTech (Regulatory Technology) automatiza el cumplimiento normativo, desde la generación de reportes regulatorios hasta el monitoreo continuo de compliance. Integra los marcos NCG 514 (Open Finance), Basel IV, TNFD/TCFD (disclosure ambiental), y Ley 21.713 (plusvalías urbanas).

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         VERTICAL REGTECH                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                    MÓDULOS REGTECH                              │   │
│  ├─────────────────────────────────────────────────────────────────┤   │
│  │                                                                 │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────┐│   │
│  │  │   R01-NCG   │  │   R02-BSL   │  │   R03-TNFD  │  │R04-21713││   │
│  │  │  Open       │  │   Basel     │  │  Nature     │  │Plusvalías│   │
│  │  │  Finance    │  │   IV/III    │  │  Disclosure │  │ Urbanas ││   │
│  │  │  Reporting  │  │  Reporting  │  │  Reporting  │  │         ││   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────┘│   │
│  │                                                                 │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │   │
│  │  │   R05-AML   │  │   R06-ESG   │  │       R07-AUTO          │ │   │
│  │  │  Anti-Money │  │    ESG      │  │    Report Automation    │ │   │
│  │  │  Laundering │  │   Scoring   │  │     & Scheduling        │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────────────┘ │   │
│  │                                                                 │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 5.2 Módulo R01-NCG: Open Finance Reporting

### 5.2.1 Funcionalidades

```
┌─────────────────────────────────────────────────────────────────────────┐
│                R01-NCG: OPEN FINANCE REPORTING                          │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  REPORTES NCG 514 CMF:                                                 │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ Reporte               │ Frecuencia │ Formato  │ Deadline          │ │
│  │ ────────────────────────────────────────────────────────────────  │ │
│  │ Registro de consents  │ Diario     │ XML/JSON │ D+1 23:59         │ │
│  │ Volumen transacciones │ Mensual    │ CSV      │ M+5 días          │ │
│  │ Incidentes seguridad  │ Inmediato  │ PDF+XML  │ 24 horas          │ │
│  │ Disponibilidad APIs   │ Mensual    │ Dashboard│ M+3 días          │ │
│  │ Terceros autorizados  │ Trimestral │ Excel    │ T+15 días         │ │
│  │ Auditoría anual       │ Anual      │ PDF      │ A+90 días         │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  GENERACIÓN AUTOMATIZADA:                                              │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  [Datos Operativos] ──→ [Validación] ──→ [Transformación]        │ │
│  │         │                    │                  │                 │ │
│  │         ▼                    ▼                  ▼                 │ │
│  │  ┌──────────────┐    ┌────────────┐     ┌────────────────┐       │ │
│  │  │Logs de APIs  │ → │Reglas CMF  │  →  │Formato oficial │       │ │
│  │  │Consentimientos│   │Completitud │     │XML Schema      │       │ │
│  │  │Métricas SLA  │    │Consistencia│     │Firma digital   │       │ │
│  │  └──────────────┘    └────────────┘     └────────────────┘       │ │
│  │                                                │                  │ │
│  │                                                ▼                  │ │
│  │                                    [Envío Automático CMF]         │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 5.3 Módulo R02-BSL: Basel Reporting

### 5.3.1 Reportes Basel IV

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    R02-BSL: BASEL REPORTING                             │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  PILLAR 1 - CAPITAL MÍNIMO:                                            │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ Reporte           │ Contenido                │ Frecuencia         │ │
│  │ ────────────────────────────────────────────────────────────────  │ │
│  │ CR SA             │ RWA enfoque estándar     │ Trimestral         │ │
│  │ CR IRB            │ RWA enfoque interno      │ Trimestral         │ │
│  │ MKT              │ Riesgo de mercado         │ Trimestral         │ │
│  │ OPR              │ Riesgo operacional        │ Anual              │ │
│  │ CCR              │ Riesgo contraparte        │ Trimestral         │ │
│  │ LR               │ Leverage ratio            │ Trimestral         │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  PILLAR 2 - SUPERVISIÓN:                                               │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ • ICAAP (Internal Capital Adequacy Assessment Process)            │ │
│  │ • ILAAP (Internal Liquidity Adequacy Assessment Process)          │ │
│  │ • Stress Testing Reports                                          │ │
│  │ • Recovery & Resolution Plans                                     │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  PILLAR 3 - DISCLOSURE:                                                │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ Template    │ Descripción                          │ Publicación  │ │
│  │ ────────────────────────────────────────────────────────────────  │ │
│  │ OV1         │ Overview of RWA                      │ Semestral    │ │
│  │ KM1         │ Key metrics                          │ Trimestral   │ │
│  │ CR1-CR10    │ Credit risk detailed                 │ Semestral    │ │
│  │ CCR1-CCR8   │ Counterparty credit risk             │ Semestral    │ │
│  │ LR1-LR2     │ Leverage ratio                       │ Trimestral   │ │
│  │ LIQ1-LIQ2   │ Liquidity coverage                   │ Trimestral   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  GENERACIÓN AUTOMATIZADA:                                              │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  ┌─────────────┐   ┌─────────────┐   ┌─────────────────────────┐ │ │
│  │  │  Exposures  │   │  Parameters │   │   Generated Reports     │ │ │
│  │  │  Database   │ + │  PD/LGD/EAD │ = │   • Excel templates     │ │ │
│  │  │             │   │  from M02   │   │   • XML XBRL            │ │ │
│  │  └─────────────┘   └─────────────┘   │   • PDF narrative       │ │ │
│  │                                       └─────────────────────────┘ │ │
│  │                                                                   │ │
│  │  Validaciones automáticas:                                        │ │
│  │  ├── Cross-checks entre templates                                 │ │
│  │  ├── Validación de totales y subtotales                           │ │
│  │  ├── Consistencia temporal (vs. período anterior)                 │ │
│  │  └── Alertas de umbrales regulatorios                             │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 5.4 Módulo R03-TNFD: Nature Disclosure

### 5.4.1 Funcionalidades

```
┌─────────────────────────────────────────────────────────────────────────┐
│                   R03-TNFD: NATURE DISCLOSURE                           │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ESTRUCTURA DE REPORTE TNFD:                                           │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  ┌───────────────────────────────────────────────────────────┐   │ │
│  │  │                     GOVERNANCE                             │   │ │
│  │  │  • Supervisión del directorio sobre riesgos naturales     │   │ │
│  │  │  • Rol de la administración en gestión                    │   │ │
│  │  │  • Integración con governance ESG existente               │   │ │
│  │  └───────────────────────────────────────────────────────────┘   │ │
│  │                           │                                       │ │
│  │                           ▼                                       │ │
│  │  ┌───────────────────────────────────────────────────────────┐   │ │
│  │  │                      STRATEGY                              │   │ │
│  │  │  • Dependencias e impactos identificados                  │   │ │
│  │  │  • Análisis de escenarios (1.5°C, 2°C, 3°C)               │   │ │
│  │  │  • Efectos en modelo de negocio                           │   │ │
│  │  │  • Resiliencia de la estrategia                           │   │ │
│  │  └───────────────────────────────────────────────────────────┘   │ │
│  │                           │                                       │ │
│  │                           ▼                                       │ │
│  │  ┌───────────────────────────────────────────────────────────┐   │ │
│  │  │                  RISK MANAGEMENT                           │   │ │
│  │  │  • Proceso de identificación de riesgos naturales         │   │ │
│  │  │  • Integración con ERM corporativo                        │   │ │
│  │  │  • Ubicaciones prioritarias (LEAP approach)               │   │ │
│  │  └───────────────────────────────────────────────────────────┘   │ │
│  │                           │                                       │ │
│  │                           ▼                                       │ │
│  │  ┌───────────────────────────────────────────────────────────┐   │ │
│  │  │                 METRICS & TARGETS                          │   │ │
│  │  │  • Métricas de dependencias/impactos                      │   │ │
│  │  │  • Metas de reducción de impacto                          │   │ │
│  │  │  • Valoración de capital natural (M-NCA)                  │   │ │
│  │  │  • Servicios ecosistémicos (M-ESV)                        │   │ │
│  │  └───────────────────────────────────────────────────────────┘   │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  INTEGRACIÓN CON MÓDULOS V4.0:                                         │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  M-NCA (Natural Capital)  ────→ Extent & Condition Accounts      │ │
│  │  M-ESV (Ecosystem Services) ──→ Ecosystem Services Flow Accounts │ │
│  │  M-HED (Hedonic Pricing)  ────→ Monetary Valuation               │ │
│  │  M-ENV (Environmental Hub) ───→ Data Integration                 │ │
│  │                                                                   │ │
│  │  Output: Reporte TNFD completo alineado con ISSB S2               │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  MÉTRICAS CORE + ADICIONALES:                                          │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ Métrica                    │ Unidad      │ Fuente DATAPOLIS       │ │
│  │ ──────────────────────────────────────────────────────────────    │ │
│  │ Extent of ecosystems       │ hectáreas   │ M-NCA                  │ │
│  │ Ecosystem condition        │ índice 0-1  │ M-NCA                  │ │
│  │ Dependencies identified    │ count       │ M-ESV                  │ │
│  │ ES monetary value          │ USD/año     │ M-ESV                  │ │
│  │ GHG emissions Scope 1,2,3  │ tCO2e       │ M-ENV                  │ │
│  │ Water withdrawal           │ m³          │ M-ENV                  │ │
│  │ Waste generated            │ tonnes      │ M-ENV                  │ │
│  │ Biodiversity impact        │ MSA.ha      │ M-NCA                  │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

# 6. VERTICAL DATATECH

## 6.1 Visión General

La vertical DataTech proporciona la infraestructura de datos, pipelines de ETL, modelos de machine learning, y capacidades analíticas que alimentan a todas las demás verticales. Es el "sistema nervioso central" de DATAPOLIS.

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         VERTICAL DATATECH                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                    MÓDULOS DATATECH                             │   │
│  ├─────────────────────────────────────────────────────────────────┤   │
│  │                                                                 │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────┐│   │
│  │  │   D01-ETL   │  │   D02-DWH   │  │   D03-ML    │  │ D04-VIZ ││   │
│  │  │   Extract   │  │   Data      │  │   Machine   │  │Business ││   │
│  │  │   Transform │  │  Warehouse  │  │   Learning  │  │ Intel.  ││   │
│  │  │    Load     │  │             │  │   Platform  │  │         ││   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────┘│   │
│  │                                                                 │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │   │
│  │  │   D05-VEC   │  │   D06-GEO   │  │       D07-STREAM        │ │   │
│  │  │   Vector    │  │  Geospatial │  │    Real-time Stream     │ │   │
│  │  │   Store     │  │   Analytics │  │      Processing         │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────────────────┘ │   │
│  │                                                                 │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 6.2 Módulo D01-ETL: Extract, Transform, Load

### 6.2.1 Arquitectura de Pipelines

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    D01-ETL: DATA PIPELINES                              │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  FUENTES DE DATOS:                                                     │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  PÚBLICAS:                                                        │ │
│  │  ├── SII: Avalúos fiscales, roles, contribuciones                 │ │
│  │  ├── MINVU: Permisos de edificación, recepciones                  │ │
│  │  ├── INE: Estadísticas demográficas, económicas                   │ │
│  │  ├── Banco Central: Indicadores financieros, UF, UTM              │ │
│  │  ├── CMF: Tasas, spreads, normativa                               │ │
│  │  ├── Conservador: Inscripciones inmobiliarias                     │ │
│  │  └── Municipalidades: Catastro, zonificación                      │ │
│  │                                                                   │ │
│  │  PRIVADAS:                                                        │ │
│  │  ├── Portales inmobiliarios: Precios de oferta                    │ │
│  │  ├── Bancos: Transacciones, scoring interno                       │ │
│  │  ├── Notarías: Escrituras digitalizadas                           │ │
│  │  ├── Empresas: ERP, CRM, data operacional                         │ │
│  │  └── Satelital: Imágenes, índices vegetación                      │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  ARQUITECTURA MEDALLION:                                               │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  ┌──────────┐      ┌──────────┐      ┌──────────┐                │ │
│  │  │  BRONZE  │ ──→  │  SILVER  │ ──→  │   GOLD   │                │ │
│  │  │          │      │          │      │          │                │ │
│  │  │ Raw data │      │ Cleaned  │      │ Business │                │ │
│  │  │ As-is    │      │ Validated│      │ Ready    │                │ │
│  │  │ Immutable│      │ Typed    │      │ Aggregated│               │ │
│  │  └──────────┘      └──────────┘      └──────────┘                │ │
│  │       │                 │                 │                       │ │
│  │       ▼                 ▼                 ▼                       │ │
│  │  ┌──────────┐      ┌──────────┐      ┌──────────┐                │ │
│  │  │ Parquet  │      │ Delta    │      │ Star     │                │ │
│  │  │ Raw      │      │ Lake     │      │ Schema   │                │ │
│  │  │ Storage  │      │ Tables   │      │ DWH      │                │ │
│  │  └──────────┘      └──────────┘      └──────────┘                │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  ORQUESTACIÓN (Apache Airflow):                                        │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  DAG: daily_property_data                                         │ │
│  │  Schedule: 0 6 * * *                                              │ │
│  │                                                                   │ │
│  │  Tasks:                                                           │ │
│  │  [extract_sii] ──→ [extract_portals] ──→ [validate_bronze]       │ │
│  │        │                  │                     │                 │ │
│  │        └──────────────────┴─────────────────────┘                 │ │
│  │                           │                                       │ │
│  │                           ▼                                       │ │
│  │                    [transform_silver]                             │ │
│  │                           │                                       │ │
│  │                           ▼                                       │ │
│  │  [aggregate_gold] ──→ [update_models] ──→ [notify_stakeholders]   │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  DATA QUALITY FRAMEWORK:                                               │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ Dimensión      │ Métrica            │ Umbral  │ Acción           │ │
│  │ ────────────────────────────────────────────────────────────────  │ │
│  │ Completitud    │ % campos no nulos  │ >95%    │ Alerta si <90%   │ │
│  │ Unicidad       │ % duplicados       │ <1%     │ Dedup automático │ │
│  │ Consistencia   │ Cross-checks       │ 100%    │ Rechazo batch    │ │
│  │ Exactitud      │ Validación reglas  │ >99%    │ Quarantine       │ │
│  │ Frescura       │ Lag desde fuente   │ <24h    │ Re-extract       │ │
│  │ Validez        │ Formato correcto   │ 100%    │ Transform        │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 6.3 Módulo D03-ML: Machine Learning Platform

### 6.3.1 MLOps Pipeline

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    D03-ML: MACHINE LEARNING PLATFORM                    │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  MODELOS PRODUCTIVOS:                                                  │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ Modelo              │ Tipo        │ Input            │ Output     │ │
│  │ ────────────────────────────────────────────────────────────────  │ │
│  │ hedonic_price_v3    │ Regression  │ Property features│ Price est. │ │
│  │ credit_pd_v2        │ Binary Clf  │ Borrower data    │ PD prob    │ │
│  │ lgd_estimator_v1    │ Regression  │ Collateral data  │ LGD %      │ │
│  │ clause_classifier   │ Multi-class │ Legal text       │ Clause type│ │
│  │ risk_detector       │ Binary Clf  │ Contract text    │ Risk flag  │ │
│  │ es_valuator         │ Regression  │ Geo + biome data │ ES value   │ │
│  │ anomaly_detector    │ Unsupervised│ Transaction data │ Anomaly    │ │
│  │ document_embedder   │ Embedding   │ Document text    │ Vector 768 │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  MLOPS LIFECYCLE:                                                      │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐ │ │
│  │  │ Develop │→ │  Train  │→ │Validate │→ │ Deploy  │→ │ Monitor │ │ │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘  └─────────┘ │ │
│  │       │            │            │            │            │       │ │
│  │       ▼            ▼            ▼            ▼            ▼       │ │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐ │ │
│  │  │Notebooks│  │ MLflow  │  │Backtests│  │FastAPI  │  │Prometheus│ │ │
│  │  │Git      │  │Tracking │  │A/B Test │  │Docker   │  │Grafana  │ │ │
│  │  │DVC      │  │Artifacts│  │Shadow   │  │K8s      │  │Alerts   │ │ │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘  └─────────┘ │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  FEATURE STORE:                                                        │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  Feature Group: property_features                                 │ │
│  │  ├── surface_m2: float (online + offline)                         │ │
│  │  ├── bedrooms: int                                                │ │
│  │  ├── bathrooms: int                                               │ │
│  │  ├── dist_metro_km: float                                         │ │
│  │  ├── dist_school_km: float                                        │ │
│  │  ├── commune_median_income: float (daily refresh)                 │ │
│  │  ├── zone_construction_index: float (monthly refresh)             │ │
│  │  └── neighborhood_crime_rate: float (quarterly refresh)           │ │
│  │                                                                   │ │
│  │  Storage: Redis (online) + Delta Lake (offline)                   │ │
│  │  Latency: <5ms (online serving)                                   │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  MODEL REGISTRY:                                                       │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  Model: hedonic_price                                             │ │
│  │  ├── v1.0.0 (archived)     - Deployed: 2024-01-15                 │ │
│  │  ├── v2.0.0 (archived)     - Deployed: 2024-06-01                 │ │
│  │  ├── v3.0.0 (production)   - Deployed: 2025-01-10                 │ │
│  │  └── v3.1.0 (staging)      - In validation                        │ │
│  │                                                                   │ │
│  │  Metrics (v3.0.0):                                                │ │
│  │  ├── R²: 0.847                                                    │ │
│  │  ├── MAPE: 8.2%                                                   │ │
│  │  ├── Requests/day: 12,450                                         │ │
│  │  ├── P99 latency: 45ms                                            │ │
│  │  └── Drift score: 0.03 (healthy)                                  │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 6.4 Módulo D05-VEC: Vector Store (ChromaDB)

### 6.4.1 Arquitectura RAG

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    D05-VEC: VECTOR STORE & RAG                          │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  COLECCIONES:                                                          │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ Colección          │ Documentos │ Embedding    │ Uso               │ │
│  │ ────────────────────────────────────────────────────────────────  │ │
│  │ legal_clauses      │ 45,000     │ legal-bert   │ Búsqueda cláusulas│ │
│  │ regulations        │ 12,000     │ legal-bert   │ RAG normativo     │ │
│  │ contracts          │ 8,500      │ legal-bert   │ Comparación       │ │
│  │ property_listings  │ 250,000    │ all-MiniLM   │ Similitud props   │ │
│  │ valuation_reports  │ 15,000     │ all-MiniLM   │ Benchmarking      │ │
│  │ support_docs       │ 3,000      │ all-MiniLM   │ Chatbot soporte   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  ARQUITECTURA RAG:                                                     │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  [User Query] ──→ [Embedding] ──→ [Vector Search] ──→ [Rerank]   │ │
│  │                        │               │                  │       │ │
│  │                        ▼               ▼                  ▼       │ │
│  │                 ┌──────────┐    ┌──────────┐       ┌──────────┐  │ │
│  │                 │ Sentence │    │ ChromaDB │       │ Cross-   │  │ │
│  │                 │Transformer│    │ k=20     │       │ Encoder  │  │ │
│  │                 └──────────┘    └──────────┘       │ top-5    │  │ │
│  │                                                     └──────────┘  │ │
│  │                                                          │        │ │
│  │                                                          ▼        │ │
│  │                                         [Context + Query to LLM]  │ │
│  │                                                          │        │ │
│  │                                                          ▼        │ │
│  │                                               [Generated Response] │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  MULTI-AGENT SYSTEM (10 Agentes):                                      │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐  │ │
│  │  │ Coordinator│  │  Legal     │  │  Financial │  │ Valuation  │  │ │
│  │  │   Agent    │  │   Agent    │  │   Agent    │  │   Agent    │  │ │
│  │  └────────────┘  └────────────┘  └────────────┘  └────────────┘  │ │
│  │                                                                   │ │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐  │ │
│  │  │ Compliance │  │  Research  │  │    Data    │  │   Report   │  │ │
│  │  │   Agent    │  │   Agent    │  │   Agent    │  │   Agent    │  │ │
│  │  └────────────┘  └────────────┘  └────────────┘  └────────────┘  │ │
│  │                                                                   │ │
│  │  ┌────────────┐  ┌────────────┐                                   │ │
│  │  │    ESG     │  │  Planning  │                                   │ │
│  │  │   Agent    │  │   Agent    │                                   │ │
│  │  └────────────┘  └────────────┘                                   │ │
│  │                                                                   │ │
│  │  Communication: FastAPI + Ollama + LangChain                      │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

# 7. VERTICAL PROPTECH

## 7.1 Visión General

La vertical PropTech es el corazón original de DATAPOLIS, enfocada en valuación inmobiliaria, análisis urbano, y cumplimiento de normativa territorial. Incluye los módulos v4.0 avanzados: M-HED (Hedónico), M-ESV (Servicios Ecosistémicos), M-NCA (Capital Natural), M-VAD (Asesor), y M-ENV (Hub Ambiental).

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         VERTICAL PROPTECH                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                    MÓDULOS PROPTECH                             │   │
│  ├─────────────────────────────────────────────────────────────────┤   │
│  │                                                                 │   │
│  │  CORE v3.0:                                                     │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────┐│   │
│  │  │   P01-VAL   │  │   P02-URB   │  │   P03-REG   │  │ P04-MKT ││   │
│  │  │  Property   │  │   Urban     │  │  Regulatory │  │ Market  ││   │
│  │  │  Valuation  │  │  Analysis   │  │  Compliance │  │Analytics││   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────┘│   │
│  │                                                                 │   │
│  │  ADVANCED v4.0:                                                 │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────┐│   │
│  │  │   M-HED     │  │   M-ESV     │  │   M-NCA     │  │  M-VAD  ││   │
│  │  │  Hedonic    │  │  Ecosystem  │  │  Natural    │  │ Valuation│   │
│  │  │  Pricing    │  │  Services   │  │  Capital    │  │ Advisor ││   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────┘│   │
│  │                                                                 │   │
│  │  ┌───────────────────────────────────────────────────────────┐ │   │
│  │  │                       M-ENV                                │ │   │
│  │  │              Environmental Data Hub                        │ │   │
│  │  └───────────────────────────────────────────────────────────┘ │   │
│  │                                                                 │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 7.2 Módulo M-HED: Hedonic Pricing

### 7.2.1 Descripción Técnica

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    M-HED: HEDONIC PRICING MODEL                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  FUNDAMENTO TEÓRICO (Rosen, 1974):                                     │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  P = f(Z₁, Z₂, ..., Zₙ)                                          │ │
│  │                                                                   │ │
│  │  Donde:                                                           │ │
│  │  P  = Precio de mercado del bien inmueble                        │ │
│  │  Zᵢ = Características del inmueble (atributos)                   │ │
│  │                                                                   │ │
│  │  El precio marginal de cada atributo (∂P/∂Zᵢ) representa         │ │
│  │  el "precio implícito" o "precio hedónico" de ese atributo.      │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  FORMAS FUNCIONALES IMPLEMENTADAS:                                     │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  1. LINEAL (OLS):                                                 │ │
│  │     P = β₀ + Σβᵢ·Zᵢ + ε                                          │ │
│  │     Interpretación: Cada unidad de Zᵢ agrega βᵢ pesos al precio  │ │
│  │                                                                   │ │
│  │  2. LOG-LINEAL (Semi-log):                                        │ │
│  │     ln(P) = β₀ + Σβᵢ·Zᵢ + ε                                      │ │
│  │     Interpretación: Cada unidad de Zᵢ agrega βᵢ% al precio       │ │
│  │                                                                   │ │
│  │  3. LOG-LOG (Double-log):                                         │ │
│  │     ln(P) = β₀ + Σβᵢ·ln(Zᵢ) + ε                                  │ │
│  │     Interpretación: βᵢ es la elasticidad precio-atributo         │ │
│  │                                                                   │ │
│  │  4. BOX-COX:                                                      │ │
│  │     P^(λ) = β₀ + Σβᵢ·Zᵢ^(θᵢ) + ε                                 │ │
│  │     λ y θᵢ estimados por máxima verosimilitud                    │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  VARIABLES IMPLEMENTADAS:                                              │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  ESTRUCTURALES:                                                   │ │
│  │  ├── surface_m2: Superficie construida                            │ │
│  │  ├── lot_m2: Superficie terreno                                   │ │
│  │  ├── bedrooms: Número de dormitorios                              │ │
│  │  ├── bathrooms: Número de baños                                   │ │
│  │  ├── parking: Estacionamientos                                    │ │
│  │  ├── storage: Bodegas                                             │ │
│  │  ├── floor: Piso (departamentos)                                  │ │
│  │  ├── age_years: Antigüedad                                        │ │
│  │  └── quality_score: Índice de calidad construcción                │ │
│  │                                                                   │ │
│  │  LOCACIONALES:                                                    │ │
│  │  ├── dist_metro_m: Distancia a metro (metros)                     │ │
│  │  ├── dist_school_m: Distancia a colegio más cercano               │ │
│  │  ├── dist_park_m: Distancia a área verde                          │ │
│  │  ├── dist_commerce_m: Distancia a centro comercial                │ │
│  │  ├── dist_cbd_km: Distancia a centro de negocios                  │ │
│  │  └── crime_index: Índice de criminalidad del sector               │ │
│  │                                                                   │ │
│  │  AMBIENTALES (integración M-ESV):                                 │ │
│  │  ├── green_view_index: Índice de vista a áreas verdes             │ │
│  │  ├── air_quality_index: Calidad del aire                          │ │
│  │  ├── noise_level_db: Nivel de ruido                               │ │
│  │  └── ecosystem_proximity: Proximidad a ecosistemas naturales      │ │
│  │                                                                   │ │
│  │  REGULATORIAS:                                                    │ │
│  │  ├── zoning_type: Tipo de zonificación                            │ │
│  │  ├── building_coefficient: Coeficiente de constructibilidad       │ │
│  │  └── floor_area_ratio: FAR permitido                              │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  DIAGNÓSTICOS ESTADÍSTICOS:                                            │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  Test/Métrica       │ Propósito              │ Umbral             │ │
│  │  ────────────────────────────────────────────────────────────────│ │
│  │  R² ajustado        │ Bondad de ajuste       │ >0.70              │ │
│  │  VIF                │ Multicolinealidad      │ <10 (ideal <5)     │ │
│  │  Durbin-Watson      │ Autocorrelación        │ 1.5-2.5            │ │
│  │  Breusch-Pagan      │ Heterocedasticidad     │ p-value >0.05      │ │
│  │  Ramsey RESET       │ Forma funcional        │ p-value >0.05      │ │
│  │  Jarque-Bera        │ Normalidad residuos    │ p-value >0.05      │ │
│  │  AIC/BIC            │ Selección de modelo    │ Menor es mejor     │ │
│  │  F-statistic        │ Significancia global   │ p-value <0.05      │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 7.3 Módulo M-ESV: Ecosystem Services Valuation

### 7.3.1 Metodología SEEA-EA

```
┌─────────────────────────────────────────────────────────────────────────┐
│               M-ESV: ECOSYSTEM SERVICES VALUATION                       │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  CLASIFICACIÓN DE SERVICIOS (CICES v5.1):                              │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  PROVISIÓN:                                                       │ │
│  │  ├── Alimentos (agricultura, ganadería, pesca)                    │ │
│  │  ├── Agua dulce                                                   │ │
│  │  ├── Materiales (madera, fibras)                                  │ │
│  │  └── Energía (biomasa, hidroeléctrica)                            │ │
│  │                                                                   │ │
│  │  REGULACIÓN:                                                      │ │
│  │  ├── Regulación climática (secuestro de carbono)                  │ │
│  │  ├── Regulación de calidad del aire                               │ │
│  │  ├── Regulación hídrica (control inundaciones)                    │ │
│  │  ├── Control de erosión                                           │ │
│  │  ├── Polinización                                                 │ │
│  │  └── Control biológico de plagas                                  │ │
│  │                                                                   │ │
│  │  CULTURALES:                                                      │ │
│  │  ├── Recreación y turismo                                         │ │
│  │  ├── Valor estético                                               │ │
│  │  ├── Patrimonio cultural                                          │ │
│  │  └── Educación e investigación                                    │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  METODOLOGÍAS DE VALORACIÓN:                                           │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  1. VALUE TRANSFER (Transferencia de beneficios):                 │ │
│  │     ┌─────────────────────────────────────────────────────────┐   │ │
│  │     │ Bioma              │ Valor (USD/ha/año) │ Fuente        │   │ │
│  │     │ ────────────────────────────────────────────────────────│   │ │
│  │     │ Bosque nativo      │ $3,800 - $5,200    │ TEEB, Costanza│   │ │
│  │     │ Humedal            │ $6,500 - $9,500    │ TEEB, de Groot│   │ │
│  │     │ Matorral esclerof. │ $1,800 - $2,400    │ Local studies │   │ │
│  │     │ Pradera            │ $1,200 - $1,800    │ TEEB          │   │ │
│  │     │ Zona costera       │ $4,500 - $7,000    │ Blue carbon   │   │ │
│  │     │ Área urbana verde  │ $2,800 - $4,200    │ iTree, UFORE  │   │ │
│  │     └─────────────────────────────────────────────────────────┘   │ │
│  │                                                                   │ │
│  │  2. REPLACEMENT COST (Costo de reemplazo):                        │ │
│  │     Ejemplo: Tratamiento de agua                                  │ │
│  │     Costo planta tratamiento vs. servicio ecosistémico natural    │ │
│  │                                                                   │ │
│  │  3. AVOIDED DAMAGE (Daño evitado):                                │ │
│  │     Ejemplo: Control de inundaciones                              │ │
│  │     Valor = Daños esperados sin humedal - Daños con humedal       │ │
│  │                                                                   │ │
│  │  4. HEDONIC PRICING (Precios hedónicos):                          │ │
│  │     Integración con M-HED para valorar amenidades ambientales     │ │
│  │     en precios inmobiliarios                                      │ │
│  │                                                                   │ │
│  │  5. CONTINGENT VALUATION (Valoración contingente):                │ │
│  │     Encuestas de disposición a pagar (WTP)                        │ │
│  │     Utilizado para servicios no de mercado                        │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  CÁLCULO NPV DE SERVICIOS:                                             │ │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  NPV = Σ [ESₜ / (1+r)ᵗ]  para t = 1 hasta T                       │ │
│  │                                                                   │ │
│  │  Donde:                                                           │ │
│  │  ESₜ = Valor de servicios ecosistémicos en año t                  │ │
│  │  r   = Tasa de descuento social (3.5% Chile, según MDS)           │ │
│  │  T   = Horizonte de análisis (típicamente 30 años)                │ │
│  │                                                                   │ │
│  │  Ejemplo:                                                         │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ Área: 500 hectáreas de humedal                              │ │ │
│  │  │ Valor anual: $7,500/ha/año = $3,750,000/año                 │ │ │
│  │  │ Tasa descuento: 3.5%                                        │ │ │
│  │  │ Horizonte: 30 años                                          │ │ │
│  │  │                                                             │ │ │
│  │  │ NPV = $3,750,000 × [1 - (1.035)⁻³⁰] / 0.035                 │ │ │
│  │  │ NPV = $69,234,000 USD                                       │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 7.4 Módulo M-VAD: Valuation Advisor (IA)

### 7.4.1 Sistema de Recomendación

```
┌─────────────────────────────────────────────────────────────────────────┐
│                   M-VAD: VALUATION ADVISOR (AI)                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ÁRBOL DE DECISIÓN METODOLÓGICO:                                       │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  [Inicio] ──→ ¿Tipo de activo?                                    │ │
│  │                    │                                              │ │
│  │      ┌─────────────┼─────────────┐                                │ │
│  │      ▼             ▼             ▼                                │ │
│  │  Residencial   Comercial     Rural/Agrícola                       │ │
│  │      │             │             │                                │ │
│  │      ▼             ▼             ▼                                │ │
│  │  ¿Comparables?  ¿Ingreso?   ¿Producción?                          │ │
│  │   Sí │ No      Sí │ No      Sí │ No                               │ │
│  │      ▼   ▼        ▼   ▼        ▼   ▼                              │ │
│  │  Market Cost  Income Cost  Income Cost                            │ │
│  │      │             │             │                                │ │
│  │      └─────────────┴─────────────┘                                │ │
│  │                    │                                              │ │
│  │                    ▼                                              │ │
│  │            ¿Propósito valuación?                                  │ │
│  │      ┌─────────┼─────────┬─────────┐                              │ │
│  │      ▼         ▼         ▼         ▼                              │ │
│  │   Crédito  Tributario  Venta   Contable                           │ │
│  │      │         │         │         │                              │ │
│  │      ▼         ▼         ▼         ▼                              │ │
│  │   Basel IV   SII      Market   IFRS 13                            │ │
│  │   haircuts  avalúo    value   fair value                          │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  LÓGICA DE SCORING:                                                    │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  score = Σ (wᵢ × factorᵢ)                                        │ │
│  │                                                                   │ │
│  │  Factor              │ Peso │ Evaluación                         │ │
│  │  ────────────────────────────────────────────────────────────────│ │
│  │  Data availability   │ 0.25 │ Comparables, ingresos, costos      │ │
│  │  Asset characteristics│ 0.20 │ Tipo, uso, condición               │ │
│  │  Purpose alignment   │ 0.20 │ Estándar requerido                 │ │
│  │  Market conditions   │ 0.15 │ Liquidez, volatilidad              │ │
│  │  Precedent/practice  │ 0.10 │ Práctica profesional local         │ │
│  │  Regulatory req.     │ 0.10 │ Normativa aplicable                │ │
│  │  ────────────────────────────────────────────────────────────────│ │
│  │  Total               │ 1.00 │                                    │ │
│  │                                                                   │ │
│  │  Score → Método recomendado:                                      │ │
│  │  >80: Alta confianza, método único                               │ │
│  │  60-80: Confianza media, considerar método secundario            │ │
│  │  <60: Baja confianza, recomendar enfoque híbrido                 │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  OUTPUT EJEMPLO:                                                       │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                                                                   │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │ 🎯 METODOLOGÍA RECOMENDADA                                  │ │ │
│  │  │                                                             │ │ │
│  │  │ Primaria: Market Approach (Comparación Directa)             │ │ │
│  │  │ Score: 87/100                                               │ │ │
│  │  │                                                             │ │ │
│  │  │ Justificación:                                              │ │ │
│  │  │ • Activo residencial con mercado activo                     │ │ │
│  │  │ • 47 comparables disponibles en el sector                   │ │ │
│  │  │ • Propósito crediticio alineado con práctica bancaria       │ │ │
│  │  │                                                             │ │ │
│  │  │ Precisión esperada: ±7%                                     │ │ │
│  │  │ Estándares aplicables: IVS 2022, RICS Red Book              │ │ │
│  │  │                                                             │ │ │
│  │  │ Método complementario: Income Approach                      │ │ │
│  │  │ (Útil para validación si hay datos de arriendo)             │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  │                                                                   │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 7.5 Resumen Verticales RegTech, DataTech, PropTech

| Vertical | Módulos | Análisis Principal | Estándares | Estado |
|----------|---------|-------------------|------------|--------|
| **RegTech** | 7 | Reportes regulatorios, compliance | NCG 514, Basel IV, TNFD | ✅ Producción |
| **DataTech** | 7 | ETL, ML, Analytics, Vector Store | MLOps, Data Quality | ✅ Producción |
| **PropTech** | 9 | Valuación, Hedónico, Ecosistemas | IVS, RICS, SEEA-EA | ✅ Producción |

---

*Continúa en Parte 5: Compliance Suite y Due Diligence*
