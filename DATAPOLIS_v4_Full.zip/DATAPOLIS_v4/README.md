# DATAPOLIS v4.0

## Plataforma PropTech/FinTech/RegTech/GovTech con Valuación Hedónica y Capital Natural

[![Build Status](https://github.com/datapolis/datapolis-v4/workflows/CI/badge.svg)](https://github.com/datapolis/datapolis-v4/actions)
[![License](https://img.shields.io/badge/license-Proprietary-red.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-4.0.0-blue.svg)](VERSION)

---

## 🚀 Novedades v4.0

DATAPOLIS v4.0 incorpora capacidades avanzadas de **econometría espacial**, **valoración de servicios ecosistémicos** y **contabilidad de capital natural**, posicionando la plataforma como líder en **finanzas verdes** y **ESG compliance**.

### Nuevos Módulos

| Módulo | Nombre | Descripción |
|--------|--------|-------------|
| M-HED | Hedonic Pricing | Modelos hedónicos espaciales (OLS, Log-Linear, Box-Cox, SAR/SEM) |
| M-ESV | Ecosystem Services | Valoración de servicios ecosistémicos (ESVD/InVEST) |
| M-NCA | Natural Capital | Contabilidad de capital natural (SEEA-EA compliant) |
| M-VAD | Valuation Advisor | Asistente IA para selección de métodos de valuación |
| M-ENV | Environmental Hub | Hub de datos ambientales normalizados y ESG layers |

---

## 📦 Módulos Completos

### v3.0 (Preservados)

| Dominio | Módulos |
|---------|---------|
| PropTech | M00 Expediente, M01 Ficha, M02 Copropiedad, M05-M09, MS |
| FinTech | M01-OF Open Finance, M03 Credit Scoring, M04 Valorización ML, M13, M16, RR |
| RegTech | M10, M11 PAE, M14, GT-PV Plusvalías |
| GovTech | M17 GIRES, M22 ÁGORA |
| DataTech | IE Indicadores, IA Multi-Agente |

### v4.0 (Nuevos)

| Dominio | Módulos |
|---------|---------|
| Econometrics | M-HED Hedonic Pricing Spatial |
| ESG/Green | M-ESV Ecosystem Services, M-NCA Natural Capital |
| Advisory | M-VAD Valuation Method Advisor |
| Data | M-ENV Environmental Data Hub |

---

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         DATAPOLIS v4.0                                   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐        │
│  │  PROPTECH  │  │  FINTECH   │  │  REGTECH   │  │  GOVTECH   │        │
│  │  M00-M09   │  │ M01-OF,M03 │  │ M10-M14    │  │ M17, M22   │        │
│  │  MS        │  │ M04,M13,M16│  │ GT-PV      │  │ GIRES,ÁGORA│        │
│  └─────┬──────┘  └─────┬──────┘  └─────┬──────┘  └─────┬──────┘        │
│        │               │               │               │                │
│  ┌─────┴───────────────┴───────────────┴───────────────┴──────┐        │
│  │                    v4.0 NEW MODULES                         │        │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐        │        │
│  │  │ M-HED   │  │ M-ESV   │  │ M-NCA   │  │ M-VAD   │        │        │
│  │  │Hedonic  │  │Ecosystem│  │Natural  │  │Valuation│        │        │
│  │  │Pricing  │  │Services │  │Capital  │  │Advisor  │        │        │
│  │  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘        │        │
│  │       └────────────┴────────────┴────────────┘              │        │
│  │                         │                                   │        │
│  │              ┌──────────┴──────────┐                        │        │
│  │              │    M-ENV            │                        │        │
│  │              │ Environmental Hub   │                        │        │
│  │              └─────────────────────┘                        │        │
│  └─────────────────────────────────────────────────────────────┘        │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────┐         │
│  │              DUAL BACKEND ARCHITECTURE                      │         │
│  │  ┌──────────────┐              ┌──────────────┐            │         │
│  │  │   FastAPI    │              │   Laravel    │            │         │
│  │  │   Python     │◄────────────►│   PHP        │            │         │
│  │  │  ML/Hedonic  │              │  CRUD/PAE    │            │         │
│  │  │  ESG/NCA     │              │  Auth/Docs   │            │         │
│  │  └──────────────┘              └──────────────┘            │         │
│  └────────────────────────────────────────────────────────────┘         │
│                                                                          │
│  ┌────────────────────────────────────────────────────────────┐         │
│  │   PostgreSQL + PostGIS  │  Redis  │  MinIO  │  Vue.js 3   │         │
│  └────────────────────────────────────────────────────────────┘         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## ⚡ Inicio Rápido

```bash
# 1. Descomprimir
unzip DATAPOLIS_v4_Full.zip
cd DATAPOLIS_v4_Full

# 2. Validar completitud
bash scripts/validate_100_percent.sh

# 3. Opción A: Docker
docker-compose up -d

# 3. Opción B: Local
# Ver docs/DEPLOY_LOCAL.md

# 4. Acceder
# Frontend: http://localhost:3000
# Laravel API: http://localhost:8000
# FastAPI: http://localhost:8001
# Docs: http://localhost:8001/docs
```

---

## 📖 Documentación

| Documento | Descripción |
|-----------|-------------|
| [ARCHITECTURE.md](docs/ARCHITECTURE.md) | Arquitectura técnica v4.0 |
| [API_REFERENCE.md](docs/API_REFERENCE.md) | 520+ endpoints documentados |
| [DEPLOY_LOCAL.md](docs/DEPLOY_LOCAL.md) | Guía de instalación local |
| [DEPLOY_CPANEL.md](docs/DEPLOY_CPANEL.md) | Guía para hosting cPanel |
| [DATAPOLIS_v4_INVERSIONISTAS.md](docs/DATAPOLIS_v4_INVERSIONISTAS.md) | Pitch para inversores |
| [DATAPOLIS_v4_CLIENTES.md](docs/DATAPOLIS_v4_CLIENTES.md) | Manual operativo |
| [DATAPOLIS_v4_REGULADOR.md](docs/DATAPOLIS_v4_REGULADOR.md) | Compliance NCG514/Basel IV/ESG |

---

## 🧪 Tests

```bash
# Tests E2E completos
pytest tests/test_e2e_v4.py -v

# Tests módulos v4.0
pytest tests/test_hedonic.py -v
pytest tests/test_ecosystem_services.py -v
pytest tests/test_valuation_advisor.py -v

# Validación completa
bash scripts/validate_100_percent.sh
```

---

## 📜 Licencia

Proprietary - DATAPOLIS SpA © 2026

---

## 📞 Contacto

- **Email**: info@datapolis.cl
- **Web**: https://datapolis.cl
- **Soporte**: soporte@datapolis.cl
