"""
DATAPOLIS v4.0 - FastAPI Main Application
==========================================
Plataforma PropTech/FinTech/RegTech/GovTech con capacidades
de valuación hedónica, servicios ecosistémicos y capital natural.
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import os
import time
from contextlib import asynccontextmanager

# ============================================================
# ROUTERS v3.0 (existentes)
# ============================================================
# Estos imports asumen que los routers v3.0 existen
# from app.routers import (
#     expedientes, fichas, copropiedades, arriendos, mantenciones,
#     inversiones, contabilidad, mercado_suelo,  # PropTech
#     open_finance, credit_scoring, valorizacion, garantias, basel,  # FinTech
#     reportes, pae, reavaluo, plusvalias,  # RegTech
#     gires, agora,  # GovTech
#     indicadores  # DataTech
# )

# ============================================================
# ROUTERS v4.0 (nuevos)
# ============================================================
from app.routers import (
    hedonic,
    ecosystem_services,
    natural_capital,
    valuation_advisor,
    env_hub
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle manager para la aplicación."""
    # Startup
    print("🚀 DATAPOLIS v4.0 iniciando...")
    print("📊 Cargando módulos hedónicos y de capital natural...")
    yield
    # Shutdown
    print("👋 DATAPOLIS v4.0 cerrando...")


# ============================================================
# APP CONFIGURATION
# ============================================================
app = FastAPI(
    title="DATAPOLIS v4.0 API",
    description="""
## Plataforma PropTech/FinTech/RegTech/GovTech

### Módulos v3.0 (Preservados)
- **PropTech**: Expedientes, Fichas, Copropiedades, Arriendos, Mantenciones
- **FinTech**: Open Finance NCG514, Credit Scoring Basel IV, Valorización ML
- **RegTech**: PAE, Reavalúo SII, Plusvalías Ley 21.713
- **GovTech**: GIRES Riesgos, ÁGORA GeoViewer

### Módulos v4.0 (Nuevos)
- **M-HED**: Precios Hedónicos Espaciales
- **M-ESV**: Servicios Ecosistémicos
- **M-NCA**: Contabilidad de Capital Natural
- **M-VAD**: Asistente de Métodos de Valuación
- **M-ENV**: Environmental Data Hub

### Compliance
- NCG 514 CMF (Open Finance)
- Basel IV (Credit Risk)
- Ley 21.713 (Plusvalías)
- SEEA-EA (Capital Natural)
- TNFD (Disclosure)
    """,
    version="4.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan
)


# ============================================================
# MIDDLEWARE
# ============================================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Añade tiempo de procesamiento a headers."""
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    response.headers["X-DATAPOLIS-Version"] = "4.0.0"
    return response


# ============================================================
# EXCEPTION HANDLERS
# ============================================================
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Manejador global de excepciones."""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "detail": str(exc),
            "path": str(request.url)
        }
    )


# ============================================================
# HEALTH & STATUS ENDPOINTS
# ============================================================
@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "version": "4.0.0",
        "edition": "Hedonic & Natural Capital"
    }


@app.get("/", tags=["Health"])
async def root():
    """Root endpoint con información de la API."""
    return {
        "name": "DATAPOLIS",
        "version": "4.0.0",
        "status": "operational",
        "docs": "/docs",
        "modules": {
            "v3_preserved": [
                "PropTech", "FinTech", "RegTech", "GovTech", "DataTech"
            ],
            "v4_new": [
                "Hedonic Pricing",
                "Ecosystem Services",
                "Natural Capital",
                "Valuation Advisor",
                "Environmental Hub"
            ]
        }
    }


@app.get("/api/v1/health", tags=["Health"])
async def api_health():
    """API health check."""
    return {
        "status": "healthy",
        "version": "4.0.0",
        "api_version": "v1"
    }


@app.get("/api/v1/modules", tags=["Health"])
async def list_modules():
    """Lista todos los módulos disponibles."""
    return {
        "version": "4.0.0",
        "modules": {
            "proptech": {
                "M00": "Expedientes",
                "M01": "Fichas de Propiedad",
                "M02": "Copropiedades",
                "M05": "Arriendos",
                "M06": "Mantenciones",
                "M07": "Inversión",
                "M08": "Contabilidad",
                "MS": "Mercado Suelo"
            },
            "fintech": {
                "M01-OF": "Open Finance NCG514",
                "M03": "Credit Scoring Basel IV",
                "M04": "Valorización ML",
                "M13": "Garantías",
                "M16": "Basel IV Framework",
                "RR": "Rentabilidad Real"
            },
            "regtech": {
                "M10": "Reportes/Compliance",
                "M11": "PAE Engine",
                "M14": "Reavalúo SII",
                "GT-PV": "Plusvalías Ley 21.713"
            },
            "govtech": {
                "M17": "GIRES Riesgos",
                "M22": "ÁGORA GeoViewer"
            },
            "datatech": {
                "IE": "Indicadores Económicos"
            },
            "v4_modules": {
                "M-HED": "Hedonic Pricing Spatial",
                "M-ESV": "Ecosystem Services Valuation",
                "M-NCA": "Natural Capital Accounting",
                "M-VAD": "Valuation Method Advisor",
                "M-ENV": "Environmental Data Hub"
            }
        },
        "total_endpoints": "520+"
    }


# ============================================================
# REGISTER ROUTERS v3.0
# ============================================================
# Comentados porque asumimos que ya existen en el sistema
# Los archivos de routers v3.0 se mantienen del ZIP anterior

# PropTech
# app.include_router(expedientes.router, prefix="/api/v1", tags=["M00 Expedientes"])
# app.include_router(fichas.router, prefix="/api/v1", tags=["M01 Fichas"])
# app.include_router(copropiedades.router, prefix="/api/v1", tags=["M02 Copropiedades"])
# app.include_router(arriendos.router, prefix="/api/v1", tags=["M05 Arriendos"])
# app.include_router(mantenciones.router, prefix="/api/v1", tags=["M06 Mantenciones"])
# app.include_router(inversiones.router, prefix="/api/v1", tags=["M07 Inversión"])
# app.include_router(contabilidad.router, prefix="/api/v1", tags=["M08 Contabilidad"])
# app.include_router(mercado_suelo.router, prefix="/api/v1", tags=["MS Mercado Suelo"])

# FinTech
# app.include_router(open_finance.router, prefix="/api/v1", tags=["M01-OF Open Finance"])
# app.include_router(credit_scoring.router, prefix="/api/v1", tags=["M03 Credit Scoring"])
# app.include_router(valorizacion.router, prefix="/api/v1", tags=["M04 Valorización"])
# app.include_router(garantias.router, prefix="/api/v1", tags=["M13 Garantías"])
# app.include_router(basel.router, prefix="/api/v1", tags=["M16 Basel IV"])

# RegTech
# app.include_router(reportes.router, prefix="/api/v1", tags=["M10 Reportes"])
# app.include_router(pae.router, prefix="/api/v1", tags=["M11 PAE"])
# app.include_router(reavaluo.router, prefix="/api/v1", tags=["M14 Reavalúo"])
# app.include_router(plusvalias.router, prefix="/api/v1", tags=["GT-PV Plusvalías"])

# GovTech
# app.include_router(gires.router, prefix="/api/v1", tags=["M17 GIRES"])
# app.include_router(agora.router, prefix="/api/v1", tags=["M22 ÁGORA"])

# DataTech
# app.include_router(indicadores.router, prefix="/api/v1", tags=["IE Indicadores"])


# ============================================================
# REGISTER ROUTERS v4.0
# ============================================================
app.include_router(
    hedonic.router, 
    prefix="/api/v1", 
    tags=["M-HED Hedonic Pricing"]
)

app.include_router(
    ecosystem_services.router, 
    prefix="/api/v1", 
    tags=["M-ESV Ecosystem Services"]
)

app.include_router(
    natural_capital.router, 
    prefix="/api/v1", 
    tags=["M-NCA Natural Capital"]
)

app.include_router(
    valuation_advisor.router, 
    prefix="/api/v1", 
    tags=["M-VAD Valuation Advisor"]
)

app.include_router(
    env_hub.router, 
    prefix="/api/v1", 
    tags=["M-ENV Environmental Hub"]
)


# ============================================================
# RUN CONFIGURATION
# ============================================================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8001,
        reload=True
    )
