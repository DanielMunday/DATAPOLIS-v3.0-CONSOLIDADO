"""
DATAPOLIS v4.0 - Ecosystem Services Router
============================================
Endpoints REST para valoración de servicios ecosistémicos.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from pydantic import BaseModel, Field
from enum import Enum

from app.services.m_ecosystem_services import (
    ecosystem_services, BiomeType, EcosystemService,
    EcosystemValuationResult
)

router = APIRouter(prefix="/ecosystem-services", tags=["Ecosystem Services (v4.0)"])


# Enums for API
class BiomeTypeEnum(str, Enum):
    tropical_forest = "tropical_forest"
    temperate_forest = "temperate_forest"
    wetland = "wetland"
    coastal = "coastal"
    urban_green = "urban_green"
    grassland = "grassland"
    freshwater = "freshwater"
    agricultural = "agricultural"


class RegionEnum(str, Enum):
    norte_grande = "norte_grande"
    norte_chico = "norte_chico"
    zona_central = "zona_central"
    zona_sur = "zona_sur"
    zona_austral = "zona_austral"


# Request Models
class ValuatePolygonRequest(BaseModel):
    """Request para valorar un polígono."""
    polygon_id: str
    area_hectares: float = Field(..., gt=0)
    biome_type: BiomeTypeEnum
    region: RegionEnum = RegionEnum.zona_central
    discount_rate: Optional[float] = Field(default=0.03, ge=0, le=0.2)
    time_horizon_years: Optional[int] = Field(default=30, ge=1, le=100)
    custom_services: Optional[dict] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "polygon_id": "parque_001",
                "area_hectares": 50.5,
                "biome_type": "urban_green",
                "region": "zona_central",
                "discount_rate": 0.03,
                "time_horizon_years": 30
            }
        }


class ProjectImpactRequest(BaseModel):
    """Request para evaluar impacto de proyecto."""
    project_id: str
    affected_areas: List[dict] = Field(..., min_length=1)
    scenario: str = Field(default="with_project")
    
    class Config:
        json_schema_extra = {
            "example": {
                "project_id": "inmobiliario_123",
                "affected_areas": [
                    {
                        "id": "area_1",
                        "biome_type": "urban_green",
                        "area_hectares": 10,
                        "change_factor": 0.3,
                        "region": "zona_central"
                    }
                ],
                "scenario": "with_project"
            }
        }


class ScenarioComparisonRequest(BaseModel):
    """Request para comparar escenarios."""
    polygon_id: str
    area_hectares: float
    current_biome: BiomeTypeEnum
    proposed_biome: BiomeTypeEnum
    region: RegionEnum = RegionEnum.zona_central


# Response Models
class ServiceBreakdownResponse(BaseModel):
    """Desglose de un servicio ecosistémico."""
    service: str
    annual_value_usd_ha: float
    confidence_level: str
    methodology: str


class ValuationResponse(BaseModel):
    """Respuesta de valoración."""
    polygon_id: str
    area_hectares: float
    biome_type: str
    total_annual_value_usd: float
    total_annual_value_clp: float
    npv_usd: float
    npv_clp: float
    discount_rate: float
    time_horizon_years: int
    services_breakdown: List[ServiceBreakdownResponse]
    confidence: str
    methodology: str
    valuation_date: str


# Endpoints
@router.post("/valuate", response_model=ValuationResponse)
async def valuate_ecosystem_polygon(request: ValuatePolygonRequest):
    """
    Valúa los servicios ecosistémicos de un polígono.
    
    Utiliza metodología de value transfer basada en ESVD/InVEST,
    ajustada para el contexto chileno.
    """
    try:
        biome = BiomeType(request.biome_type.value)
        
        result = ecosystem_services.valuate_polygon(
            polygon_id=request.polygon_id,
            area_hectares=request.area_hectares,
            biome_type=biome,
            region=request.region.value,
            custom_services=request.custom_services,
            discount_rate=request.discount_rate,
            time_horizon_years=request.time_horizon_years
        )
        
        services = [
            ServiceBreakdownResponse(
                service=s.service.value,
                annual_value_usd_ha=s.annual_value_usd_ha,
                confidence_level=s.confidence_level,
                methodology=s.methodology
            )
            for s in result.services_breakdown
        ]
        
        return ValuationResponse(
            polygon_id=result.polygon_id,
            area_hectares=result.area_hectares,
            biome_type=result.biome_type.value,
            total_annual_value_usd=result.total_annual_value_usd,
            total_annual_value_clp=result.total_annual_value_clp,
            npv_usd=result.npv_usd,
            npv_clp=result.npv_clp,
            discount_rate=result.discount_rate,
            time_horizon_years=result.time_horizon_years,
            services_breakdown=services,
            confidence=result.confidence,
            methodology=result.methodology,
            valuation_date=result.valuation_date
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/project-impact")
async def evaluate_project_impact(request: ProjectImpactRequest):
    """
    Evalúa el impacto de un proyecto sobre servicios ecosistémicos.
    
    Calcula la pérdida o ganancia neta de valor ecosistémico
    asociada a cambios de uso de suelo.
    """
    try:
        result = ecosystem_services.valuate_project_impact(
            project_id=request.project_id,
            affected_areas=request.affected_areas,
            scenario=request.scenario
        )
        
        return result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/compare-scenarios")
async def compare_land_use_scenarios(request: ScenarioComparisonRequest):
    """
    Compara escenarios de cambio de uso de suelo.
    
    Evalúa el impacto en servicios ecosistémicos de convertir
    un tipo de ecosistema a otro.
    """
    try:
        current_biome = BiomeType(request.current_biome.value)
        proposed_biome = BiomeType(request.proposed_biome.value)
        
        result = ecosystem_services.compare_scenarios(
            polygon_id=request.polygon_id,
            area_hectares=request.area_hectares,
            current_biome=current_biome,
            proposed_biome=proposed_biome,
            region=request.region.value
        )
        
        return result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/biomes")
async def list_available_biomes():
    """
    Lista todos los biomas disponibles con sus valores totales.
    """
    return ecosystem_services.get_available_biomes()


@router.get("/biomes/{biome_type}")
async def get_biome_services(biome_type: BiomeTypeEnum):
    """
    Obtiene la matriz de servicios para un bioma específico.
    """
    try:
        biome = BiomeType(biome_type.value)
        result = ecosystem_services.get_biome_services(biome)
        
        return {
            "biome": result.biome.value,
            "total_annual_value_usd_ha": result.total_annual_value_usd_ha,
            "data_year": result.data_year,
            "services": {
                s.value: {
                    "value_usd_ha": sv.annual_value_usd_ha,
                    "confidence": sv.confidence_level,
                    "source": sv.data_source
                }
                for s, sv in result.services.items()
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/services")
async def list_ecosystem_services():
    """
    Lista todos los servicios ecosistémicos disponibles.
    """
    services = []
    for service in EcosystemService:
        category = "provisioning"
        if "regulation" in service.value or "control" in service.value or "protection" in service.value:
            category = "regulating"
        elif service.value in ["recreation", "aesthetic_value", "spiritual_cultural", "education_research"]:
            category = "cultural"
        elif service.value in ["habitat_provision", "nutrient_cycling", "soil_formation"]:
            category = "supporting"
        
        services.append({
            "code": service.value,
            "name": service.value.replace("_", " ").title(),
            "category": category
        })
    
    return {"services": services, "total": len(services)}


@router.get("/methodology")
async def get_methodology_info():
    """
    Información sobre la metodología de valoración.
    """
    return {
        "methodology": "Benefit Transfer / Value Transfer",
        "data_sources": [
            "ESVD - Ecosystem Services Valuation Database",
            "InVEST - Integrated Valuation of Ecosystem Services",
            "TEEB - The Economics of Ecosystems and Biodiversity",
            "Regional studies for Chile adaptation"
        ],
        "adjustment_factors": {
            "regional": "Factores de ajuste por región de Chile (0.75-1.1)",
            "currency": "Conversión USD/CLP actualizada",
            "inflation": "Valores base año 2024"
        },
        "limitations": [
            "Valores transferidos pueden no reflejar condiciones locales exactas",
            "Incertidumbre inherente en valoración no-mercantil",
            "Interacciones entre servicios no completamente capturadas"
        ],
        "compliance": {
            "seea_ea": True,
            "tnfd": True,
            "natural_capital_protocol": True
        }
    }
