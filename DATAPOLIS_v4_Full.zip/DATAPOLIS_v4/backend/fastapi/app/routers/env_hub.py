"""
DATAPOLIS v4.0 - Environmental Data Hub Router
===============================================
Endpoints REST para el hub de datos ambientales.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from pydantic import BaseModel, Field
from enum import Enum

from app.services.m_env_hub import (
    env_hub_service, EnvironmentalLayerType
)

router = APIRouter(prefix="/env-hub", tags=["Environmental Data Hub (v4.0)"])


# Enums
class LayerTypeEnum(str, Enum):
    land_cover = "land_cover"
    vegetation = "vegetation_index"
    green_space = "green_space"
    water_bodies = "water_bodies"
    flood_risk = "flood_risk"
    seismic_risk = "seismic_risk"
    air_quality = "air_quality"
    noise_level = "noise_level"
    biodiversity = "biodiversity"
    protected_areas = "protected_areas"


class AmenityTypeEnum(str, Enum):
    park = "park"
    water = "water"
    forest = "forest"
    beach = "beach"
    protected_area = "protected_area"


# Request Models
class LocationRequest(BaseModel):
    """Request para consultar ubicación."""
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    
    class Config:
        json_schema_extra = {
            "example": {
                "latitude": -33.4489,
                "longitude": -70.6693
            }
        }


class ProfileRequest(BaseModel):
    """Request para perfil ambiental."""
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    radius_meters: float = Field(default=1000, ge=100, le=10000)
    layers: Optional[List[str]] = None


class TimeSeriesRequest(BaseModel):
    """Request para serie temporal."""
    variable: str
    latitude: float
    longitude: float
    start_date: str = Field(..., description="YYYY-MM-DD")
    end_date: str = Field(..., description="YYYY-MM-DD")
    frequency: str = Field(default="monthly")


# Endpoints
@router.post("/profile")
async def get_environmental_profile(request: ProfileRequest):
    """
    Obtiene el perfil ambiental completo de una ubicación.
    
    Incluye datos de múltiples capas ambientales, riesgos,
    indicadores de calidad y score ESG.
    """
    try:
        layers = None
        if request.layers:
            layers = [EnvironmentalLayerType(l) for l in request.layers]
        
        profile = env_hub_service.get_environmental_profile(
            latitude=request.latitude,
            longitude=request.longitude,
            radius_meters=request.radius_meters,
            layers=layers
        )
        
        return {
            "location_id": profile.location_id,
            "coordinates": profile.coordinates,
            "layers_data": profile.layers_data,
            "risk_summary": profile.risk_summary,
            "quality_indicators": profile.quality_indicators,
            "esg_score": profile.esg_score,
            "natural_capital_proximity": profile.natural_capital_proximity,
            "timestamp": profile.timestamp
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/esg-indicators")
async def get_esg_indicators(
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180)
):
    """
    Obtiene indicadores ESG agregados para una ubicación.
    
    Útil para integración con módulos de crédito y reporting.
    """
    try:
        indicators = env_hub_service.get_esg_indicators(latitude, longitude)
        return indicators
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/layers")
async def list_available_layers():
    """Lista todas las capas ambientales disponibles."""
    return {
        "layers": env_hub_service.list_available_layers()
    }


@router.get("/layers/{layer_type}")
async def get_layer_info(layer_type: LayerTypeEnum):
    """Obtiene información de una capa específica."""
    try:
        lt = EnvironmentalLayerType(layer_type.value)
        return env_hub_service.get_layer_data(lt)
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Capa no encontrada: {layer_type.value}")


@router.get("/proximity/{amenity_type}")
async def calculate_proximity(
    amenity_type: AmenityTypeEnum,
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180),
    max_distance_km: float = Query(default=5.0, ge=0.5, le=50)
):
    """
    Calcula proximidad a amenidades ambientales.
    
    Útil para análisis hedónico y valoración de atributos locacionales.
    """
    try:
        result = env_hub_service.calculate_proximity_to_amenity(
            latitude=latitude,
            longitude=longitude,
            amenity_type=amenity_type.value,
            max_distance_km=max_distance_km
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/time-series")
async def get_environmental_time_series(request: TimeSeriesRequest):
    """
    Obtiene serie temporal de una variable ambiental.
    
    Disponible para: air_quality, temperature, precipitation, vegetation_index.
    """
    try:
        series = env_hub_service.get_time_series(
            variable=request.variable,
            latitude=request.latitude,
            longitude=request.longitude,
            start_date=request.start_date,
            end_date=request.end_date,
            frequency=request.frequency
        )
        
        return {
            "series_id": series.series_id,
            "variable": series.variable,
            "location": {
                "id": series.location_id,
                "coordinates": series.coordinates
            },
            "period": {
                "start": series.start_date,
                "end": series.end_date,
                "frequency": series.frequency
            },
            "data": {
                "dates": series.dates,
                "values": series.values,
                "unit": series.unit
            },
            "metadata": {
                "source": series.source,
                "quality": series.quality_level.value
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/hedonic-features")
async def get_hedonic_environmental_features(
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180)
):
    """
    Obtiene features ambientales normalizadas para modelo hedónico.
    
    Retorna variables listas para ser usadas como regresores
    en un modelo de precios hedónicos.
    """
    try:
        profile = env_hub_service.get_environmental_profile(latitude, longitude)
        
        # Normalizar features para hedónico
        features = {
            "distancia_area_verde_m": round(1000 / (profile.natural_capital_proximity.get("green_space", 0.5) + 0.1), 0),
            "indice_calidad_aire": 100 - profile.quality_indicators.get("air_quality", 50),
            "riesgo_inundacion_score": {"low": 1, "moderate": 2, "high": 3, "very_high": 4, "critical": 5}.get(
                profile.risk_summary.get("flood_risk", "moderate"), 2
            ),
            "esg_score": profile.esg_score,
            "biodiversidad_index": profile.layers_data.get("biodiversity", 50),
            "cobertura_verde_pct": profile.layers_data.get("green_space", 20),
        }
        
        return {
            "location": {"latitude": latitude, "longitude": longitude},
            "hedonic_features": features,
            "feature_descriptions": {
                "distancia_area_verde_m": "Distancia estimada a área verde más cercana (metros)",
                "indice_calidad_aire": "Índice de calidad del aire (0-100, mayor=mejor)",
                "riesgo_inundacion_score": "Score de riesgo de inundación (1-5)",
                "esg_score": "Score ESG agregado de la ubicación (0-100)",
                "biodiversidad_index": "Índice de biodiversidad local (0-100)",
                "cobertura_verde_pct": "Porcentaje de cobertura verde en el área"
            },
            "ready_for_hedonic": True
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/integration-status")
async def get_integration_status():
    """
    Estado de integración del Environmental Data Hub con otros módulos.
    """
    return {
        "hub_status": "operational",
        "integrations": {
            "m_hedonic": {
                "status": "active",
                "endpoint": "/env-hub/hedonic-features",
                "description": "Features ambientales para modelos hedónicos"
            },
            "m_ecosystem_services": {
                "status": "active",
                "endpoint": "/env-hub/profile",
                "description": "Datos de ecosistemas para valoración de servicios"
            },
            "m_natural_capital": {
                "status": "active",
                "endpoint": "/env-hub/esg-indicators",
                "description": "Indicadores ESG para contabilidad de capital natural"
            },
            "m17_gires": {
                "status": "active",
                "endpoint": "/env-hub/layers/{risk_type}",
                "description": "Capas de riesgo para GIRES"
            },
            "m22_agora": {
                "status": "active",
                "endpoint": "/env-hub/layers",
                "description": "Todas las capas geoespaciales para ÁGORA GeoViewer"
            },
            "m03_credit_scoring": {
                "status": "active",
                "endpoint": "/env-hub/esg-indicators",
                "description": "Factores ESG para ajuste de PD/LGD"
            }
        },
        "data_sources": [
            "SINCA (Calidad del aire)",
            "DGA (Recursos hídricos)",
            "CONAF (Cobertura forestal)",
            "SERNAGEOMIN (Riesgos geológicos)",
            "SHOA (Riesgo tsunami)",
            "MMA (Biodiversidad y áreas protegidas)"
        ],
        "update_frequency": {
            "air_quality": "hourly",
            "vegetation_index": "weekly",
            "risk_layers": "quarterly",
            "biodiversity": "annual"
        }
    }
