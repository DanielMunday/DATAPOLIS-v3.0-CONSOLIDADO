"""
DATAPOLIS v4.0 - Hedonic Pricing Router
========================================
Endpoints REST para estimaciones hedónicas, diagnósticos y reportes.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from pydantic import BaseModel, Field
from enum import Enum

from app.services.m_hedonic import (
    hedonic_service, HedonicResult, ModelType
)

router = APIRouter(prefix="/hedonic", tags=["Hedonic Pricing (v4.0)"])


# Request/Response Models
class ModelTypeEnum(str, Enum):
    ols_linear = "ols_linear"
    log_linear = "log_linear"
    log_log = "log_log"
    box_cox = "box_cox"


class HedonicEstimateRequest(BaseModel):
    """Request para estimación hedónica."""
    data: List[dict] = Field(..., description="Datos de transacciones")
    dependent_variable: str = Field(..., description="Variable dependiente (precio)")
    independent_variables: List[str] = Field(..., description="Variables independientes")
    model_type: ModelTypeEnum = Field(default=ModelTypeEnum.ols_linear)
    include_diagnostics: bool = Field(default=True)
    
    class Config:
        json_schema_extra = {
            "example": {
                "data": [
                    {"precio": 150000000, "superficie": 80, "dormitorios": 3, "distancia_metro": 500},
                    {"precio": 180000000, "superficie": 95, "dormitorios": 3, "distancia_metro": 300}
                ],
                "dependent_variable": "precio",
                "independent_variables": ["superficie", "dormitorios", "distancia_metro"],
                "model_type": "log_linear",
                "include_diagnostics": True
            }
        }


class HedonicCompareRequest(BaseModel):
    """Request para comparación de modelos."""
    data: List[dict]
    dependent_variable: str
    independent_variables: List[str]


class HedonicPredictRequest(BaseModel):
    """Request para predicción."""
    new_data: List[dict]
    model_coefficients: dict
    model_type: ModelTypeEnum


class CoefficientResponse(BaseModel):
    """Respuesta de coeficiente."""
    variable: str
    coefficient: float
    std_error: float
    t_statistic: float
    p_value: float
    is_significant: bool
    implicit_price: Optional[float]
    elasticity: Optional[float]


class DiagnosticsResponse(BaseModel):
    """Respuesta de diagnósticos."""
    r_squared: float
    adj_r_squared: float
    f_statistic: float
    f_pvalue: float
    aic: float
    bic: float
    durbin_watson: float
    vif_scores: dict
    multicollinearity_warning: bool
    morans_i: Optional[float]
    spatial_autocorrelation: Optional[str]


class HedonicEstimateResponse(BaseModel):
    """Respuesta de estimación hedónica."""
    model_type: str
    n_observations: int
    n_variables: int
    dependent_variable: str
    coefficients: List[CoefficientResponse]
    diagnostics: Optional[DiagnosticsResponse]
    box_cox_lambda: Optional[float]
    sensitivity_analysis: Optional[dict]


# Endpoints
@router.post("/estimate", response_model=HedonicEstimateResponse)
async def estimate_hedonic_model(request: HedonicEstimateRequest):
    """
    Estima un modelo de precios hedónicos.
    
    Soporta modelos OLS, Log-Linear, Log-Log y Box-Cox.
    Incluye diagnósticos de multicolinealidad, AIC/BIC, y dependencia espacial.
    """
    import pandas as pd
    
    try:
        df = pd.DataFrame(request.data)
        model_type = ModelType(request.model_type.value)
        
        result = hedonic_service.estimate(
            data=df,
            dependent_var=request.dependent_variable,
            independent_vars=request.independent_variables,
            model_type=model_type,
            include_diagnostics=request.include_diagnostics
        )
        
        # Convertir a response
        coefficients = [
            CoefficientResponse(
                variable=c.variable,
                coefficient=c.coefficient,
                std_error=c.std_error,
                t_statistic=c.t_statistic,
                p_value=c.p_value,
                is_significant=c.is_significant,
                implicit_price=c.implicit_price,
                elasticity=c.elasticity
            )
            for c in result.coefficients
        ]
        
        diagnostics = None
        if result.diagnostics:
            d = result.diagnostics
            diagnostics = DiagnosticsResponse(
                r_squared=d.r_squared,
                adj_r_squared=d.adj_r_squared,
                f_statistic=d.f_statistic,
                f_pvalue=d.f_pvalue,
                aic=d.aic,
                bic=d.bic,
                durbin_watson=d.durbin_watson,
                vif_scores=d.vif_scores,
                multicollinearity_warning=d.multicollinearity_warning,
                morans_i=d.morans_i,
                spatial_autocorrelation=d.spatial_autocorrelation
            )
        
        return HedonicEstimateResponse(
            model_type=result.model_type.value,
            n_observations=result.n_observations,
            n_variables=result.n_variables,
            dependent_variable=result.dependent_variable,
            coefficients=coefficients,
            diagnostics=diagnostics,
            box_cox_lambda=result.box_cox_lambda,
            sensitivity_analysis=result.sensitivity_analysis
        )
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error en estimación: {str(e)}")


@router.post("/compare")
async def compare_hedonic_models(request: HedonicCompareRequest):
    """
    Compara múltiples especificaciones de modelo hedónico.
    
    Estima OLS, Log-Linear, Log-Log y Box-Cox, y recomienda el mejor según AIC.
    """
    import pandas as pd
    
    try:
        df = pd.DataFrame(request.data)
        
        results = hedonic_service.compare_models(
            data=df,
            dep_var=request.dependent_variable,
            indep_vars=request.independent_variables
        )
        
        best_model = hedonic_service.select_best_model(results)
        
        comparison = {}
        for model_name, result in results.items():
            comparison[model_name] = {
                "r_squared": result.diagnostics.r_squared if result.diagnostics else None,
                "adj_r_squared": result.diagnostics.adj_r_squared if result.diagnostics else None,
                "aic": result.diagnostics.aic if result.diagnostics else None,
                "bic": result.diagnostics.bic if result.diagnostics else None,
                "n_significant_vars": sum(1 for c in result.coefficients if c.is_significant),
                "box_cox_lambda": result.box_cox_lambda
            }
        
        return {
            "models_compared": list(comparison.keys()),
            "comparison": comparison,
            "best_model": best_model,
            "recommendation": f"Usar {best_model} basado en AIC mínimo"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/predict")
async def predict_prices(request: HedonicPredictRequest):
    """
    Predice precios usando un modelo hedónico estimado.
    """
    import pandas as pd
    import numpy as np
    
    try:
        df = pd.DataFrame(request.new_data)
        coefs = request.model_coefficients
        model_type = ModelType(request.model_type.value)
        
        # Construir predicción manual
        predictions = np.full(len(df), coefs.get('const', 0))
        
        for var, coef in coefs.items():
            if var != 'const' and var in df.columns:
                x = df[var].values
                if model_type in [ModelType.LOG_LOG]:
                    x = np.log(x)
                predictions += coef * x
        
        # Transformación inversa
        if model_type in [ModelType.LOG_LINEAR, ModelType.LOG_LOG]:
            predictions = np.exp(predictions)
        
        return {
            "predictions": predictions.tolist(),
            "model_type": model_type.value,
            "n_predictions": len(predictions)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/implicit-prices")
async def get_implicit_prices(
    superficie_coef: float = Query(..., description="Coeficiente de superficie"),
    mean_price: float = Query(..., description="Precio promedio de la muestra"),
    model_type: ModelTypeEnum = Query(default=ModelTypeEnum.ols_linear)
):
    """
    Calcula el precio implícito de un atributo.
    
    Para modelo lineal: precio implícito = coeficiente
    Para log-linear: precio implícito = coeficiente * precio_promedio
    """
    if model_type == ModelTypeEnum.ols_linear:
        implicit_price = superficie_coef
    else:
        implicit_price = superficie_coef * mean_price
    
    return {
        "attribute": "superficie",
        "coefficient": superficie_coef,
        "mean_price": mean_price,
        "model_type": model_type.value,
        "implicit_price": round(implicit_price, 2),
        "interpretation": f"Un m² adicional incrementa el precio en {implicit_price:,.0f} CLP"
    }


@router.get("/diagnostics-guide")
async def get_diagnostics_guide():
    """
    Guía de interpretación de diagnósticos hedónicos.
    """
    return {
        "r_squared": {
            "description": "Proporción de varianza explicada",
            "interpretation": "> 0.7 bueno, > 0.9 excelente"
        },
        "vif": {
            "description": "Factor de Inflación de Varianza",
            "interpretation": "VIF > 10 indica multicolinealidad severa"
        },
        "durbin_watson": {
            "description": "Test de autocorrelación serial",
            "interpretation": "Valores cercanos a 2 indican no autocorrelación"
        },
        "morans_i": {
            "description": "Índice de Moran para autocorrelación espacial",
            "interpretation": "Valores positivos significativos indican clustering espacial"
        },
        "aic_bic": {
            "description": "Criterios de información",
            "interpretation": "Menores valores indican mejor ajuste relativo"
        }
    }
