"""
DATAPOLIS v4.0 - Natural Capital Router
=========================================
Endpoints REST para contabilidad de capital natural.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from pydantic import BaseModel, Field
from enum import Enum

from app.services.m_natural_capital import (
    natural_capital_service, NaturalAssetType, AssetCondition,
    SchaeферModel, NaturalAssetAccount
)

router = APIRouter(prefix="/natural-capital", tags=["Natural Capital (v4.0)"])


# Enums
class AssetTypeEnum(str, Enum):
    timber = "timber_resources"
    aquatic = "aquatic_resources"
    water = "water_resources"
    ecosystem = "ecosystem_assets"
    land = "land"
    soil = "soil_resources"


# Request Models
class CreateAssetAccountRequest(BaseModel):
    """Request para crear cuenta de activo natural."""
    asset_id: str
    asset_type: AssetTypeEnum
    name: str
    location: str
    area_hectares: float = Field(..., gt=0)
    stock_physical: float = Field(..., ge=0)
    stock_unit: str
    opening_stock_monetary: float = Field(..., ge=0)
    additions: float = Field(default=0, ge=0)
    reductions: float = Field(default=0, ge=0)
    revaluations: float = Field(default=0)
    
    class Config:
        json_schema_extra = {
            "example": {
                "asset_id": "bosque_001",
                "asset_type": "timber_resources",
                "name": "Bosque Nativo Sector Norte",
                "location": "Región de Los Ríos",
                "area_hectares": 500,
                "stock_physical": 75000,
                "stock_unit": "m3",
                "opening_stock_monetary": 15000000,
                "additions": 500000,
                "reductions": 200000,
                "revaluations": 100000
            }
        }


class SchaeferModelRequest(BaseModel):
    """Request para modelo de Schaefer."""
    carrying_capacity: float = Field(..., gt=0, description="Capacidad de carga K")
    intrinsic_growth_rate: float = Field(..., gt=0, le=1, description="Tasa de crecimiento r")
    catchability_coefficient: float = Field(..., gt=0, description="Coeficiente de capturabilidad q")
    current_stock: float = Field(..., gt=0, description="Stock actual X")
    current_effort: float = Field(..., ge=0, description="Esfuerzo actual E")
    price_per_unit: float = Field(..., gt=0, description="Precio por unidad p")
    cost_per_effort: float = Field(..., gt=0, description="Costo por unidad de esfuerzo c")
    discount_rate: Optional[float] = Field(default=0.03, ge=0, le=0.2)
    
    class Config:
        json_schema_extra = {
            "example": {
                "carrying_capacity": 10000,
                "intrinsic_growth_rate": 0.15,
                "catchability_coefficient": 0.001,
                "current_stock": 6000,
                "current_effort": 100,
                "price_per_unit": 500,
                "cost_per_effort": 1000,
                "discount_rate": 0.03
            }
        }


class HamiltonianRequest(BaseModel):
    """Request para precio sombra Hamiltoniano."""
    current_stock: float = Field(..., gt=0)
    growth_function: str = Field(default="logistic")
    growth_params: dict
    price: float = Field(..., gt=0)
    extraction_cost_function: str = Field(default="linear")
    cost_params: dict
    discount_rate: Optional[float] = Field(default=0.03)


class ProjectStockRequest(BaseModel):
    """Request para proyección de stock."""
    initial_stock: float = Field(..., gt=0)
    carrying_capacity: float = Field(..., gt=0)
    growth_rate: float = Field(..., gt=0, le=1)
    extraction_rate: float = Field(..., ge=0)
    years: int = Field(default=50, ge=1, le=200)


class GenerateStatementRequest(BaseModel):
    """Request para generar estado de capital natural."""
    entity_id: str
    entity_name: str
    assets: List[dict]
    ecosystem_services_annual_usd: float = Field(default=0, ge=0)


# Endpoints
@router.post("/accounts")
async def create_asset_account(request: CreateAssetAccountRequest):
    """
    Crea una cuenta de activo natural.
    
    Registra un activo natural con su stock físico, valor monetario,
    y calcula automáticamente su condición y precio sombra.
    """
    try:
        asset_type = NaturalAssetType(request.asset_type.value)
        
        account = natural_capital_service.create_asset_account(
            asset_id=request.asset_id,
            asset_type=asset_type,
            name=request.name,
            location=request.location,
            area_hectares=request.area_hectares,
            stock_physical=request.stock_physical,
            stock_unit=request.stock_unit,
            opening_stock_monetary=request.opening_stock_monetary,
            additions=request.additions,
            reductions=request.reductions,
            revaluations=request.revaluations
        )
        
        return {
            "asset_id": account.asset_id,
            "name": account.name,
            "asset_type": account.asset_type.value,
            "location": account.location,
            "area_hectares": account.area_hectares,
            "stock_physical": account.stock_physical,
            "stock_unit": account.stock_unit,
            "opening_stock": account.opening_stock,
            "additions": account.additions,
            "reductions": account.reductions,
            "revaluations": account.revaluations,
            "closing_stock": account.closing_stock,
            "condition": account.condition.value,
            "condition_index": account.condition_index,
            "shadow_price_usd": account.shadow_price_usd,
            "accounting_period": account.accounting_period
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/shadow-price/schaefer")
async def calculate_shadow_price_schaefer(request: SchaeferModelRequest):
    """
    Calcula el precio sombra usando el modelo bioeconómico de Schaefer.
    
    El modelo de Schaefer es un modelo clásico para recursos renovables
    que balancea crecimiento biológico con extracción.
    """
    try:
        model = SchaeферModel(
            carrying_capacity=request.carrying_capacity,
            intrinsic_growth_rate=request.intrinsic_growth_rate,
            catchability_coefficient=request.catchability_coefficient,
            current_stock=request.current_stock,
            current_effort=request.current_effort,
            price_per_unit=request.price_per_unit,
            cost_per_effort=request.cost_per_effort
        )
        
        result = natural_capital_service.calculate_shadow_price_schaefer(
            model=model,
            discount_rate=request.discount_rate
        )
        
        return {
            "asset_id": result.asset_id,
            "shadow_price_usd": round(result.shadow_price_usd, 2),
            "marginal_user_cost": round(result.marginal_user_cost, 4),
            "scarcity_rent": round(result.scarcity_rent, 2),
            "optimal_extraction": round(result.optimal_extraction, 2),
            "sustainability_index": round(result.sustainability_index, 3),
            "discount_rate": result.discount_rate,
            "methodology": result.methodology,
            "interpretation": {
                "shadow_price": "Valor marginal de una unidad adicional de stock",
                "scarcity_rent": "Prima por escasez del recurso",
                "sustainability": "1.0 = stock óptimo, <1.0 = sobreexplotación"
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/shadow-price/hamiltonian")
async def calculate_shadow_price_hamiltonian(request: HamiltonianRequest):
    """
    Calcula el precio sombra usando el enfoque Hamiltoniano de control óptimo.
    """
    try:
        result = natural_capital_service.calculate_shadow_price_hamiltonian(
            current_stock=request.current_stock,
            growth_function=request.growth_function,
            growth_params=request.growth_params,
            price=request.price,
            extraction_cost_function=request.extraction_cost_function,
            cost_params=request.cost_params,
            discount_rate=request.discount_rate
        )
        
        return {
            "asset_id": result.asset_id,
            "shadow_price_usd": round(result.shadow_price_usd, 2),
            "marginal_user_cost": round(result.marginal_user_cost, 4),
            "scarcity_rent": round(result.scarcity_rent, 2),
            "optimal_extraction": round(result.optimal_extraction, 2),
            "sustainability_index": round(result.sustainability_index, 3),
            "methodology": result.methodology
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stock-projection")
async def project_stock_trajectory(request: ProjectStockRequest):
    """
    Proyecta la trayectoria del stock de un recurso natural.
    
    Usa el modelo logístico con extracción constante para simular
    la evolución del stock a lo largo del tiempo.
    """
    try:
        result = natural_capital_service.project_stock_trajectory(
            initial_stock=request.initial_stock,
            carrying_capacity=request.carrying_capacity,
            growth_rate=request.growth_rate,
            extraction_rate=request.extraction_rate,
            years=request.years
        )
        
        return result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/statement")
async def generate_capital_statement(request: GenerateStatementRequest):
    """
    Genera un estado de capital natural para una entidad.
    
    Consolida múltiples activos naturales en un reporte SEEA-EA compliant.
    """
    try:
        # Convertir dicts a objetos NaturalAssetAccount
        accounts = []
        for asset_data in request.assets:
            asset_type = NaturalAssetType(asset_data.get("asset_type", "ecosystem_assets"))
            account = natural_capital_service.create_asset_account(
                asset_id=asset_data.get("asset_id", ""),
                asset_type=asset_type,
                name=asset_data.get("name", ""),
                location=asset_data.get("location", ""),
                area_hectares=asset_data.get("area_hectares", 0),
                stock_physical=asset_data.get("stock_physical", 0),
                stock_unit=asset_data.get("stock_unit", "units"),
                opening_stock_monetary=asset_data.get("opening_stock_monetary", 0),
                additions=asset_data.get("additions", 0),
                reductions=asset_data.get("reductions", 0),
                revaluations=asset_data.get("revaluations", 0)
            )
            accounts.append(account)
        
        statement = natural_capital_service.generate_capital_statement(
            entity_id=request.entity_id,
            entity_name=request.entity_name,
            assets=accounts,
            ecosystem_services_annual_usd=request.ecosystem_services_annual_usd
        )
        
        return {
            "entity_id": statement.entity_id,
            "entity_name": statement.entity_name,
            "reporting_period": statement.reporting_period,
            "total_natural_assets_usd": statement.total_natural_assets_usd,
            "assets_by_type": statement.assets_by_type,
            "total_ecosystem_services_usd": statement.total_ecosystem_services_usd,
            "net_change_usd": statement.net_change_usd,
            "sustainability_score": statement.sustainability_score,
            "tnfd_aligned": statement.tnfd_aligned,
            "seea_compliant": statement.seea_compliant
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/tnfd-metrics")
async def get_tnfd_disclosure_metrics(assets: List[dict]):
    """
    Genera métricas para disclosure TNFD.
    
    Taskforce on Nature-related Financial Disclosures metrics.
    """
    try:
        # Convertir a cuentas
        accounts = []
        for asset_data in assets:
            asset_type = NaturalAssetType(asset_data.get("asset_type", "ecosystem_assets"))
            account = natural_capital_service.create_asset_account(
                asset_id=asset_data.get("asset_id", ""),
                asset_type=asset_type,
                name=asset_data.get("name", ""),
                location=asset_data.get("location", ""),
                area_hectares=asset_data.get("area_hectares", 0),
                stock_physical=asset_data.get("stock_physical", 0),
                stock_unit=asset_data.get("stock_unit", "units"),
                opening_stock_monetary=asset_data.get("opening_stock_monetary", 0)
            )
            accounts.append(account)
        
        metrics = natural_capital_service.get_tnfd_metrics(accounts)
        return metrics
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/asset-types")
async def list_asset_types():
    """Lista tipos de activos naturales disponibles."""
    return {
        "asset_types": [
            {"code": at.value, "name": at.value.replace("_", " ").title()}
            for at in NaturalAssetType
        ]
    }


@router.get("/methodology")
async def get_methodology_info():
    """Información sobre metodología de contabilidad de capital natural."""
    return {
        "framework": "SEEA-EA (System of Environmental-Economic Accounting - Ecosystem Accounting)",
        "models": {
            "schaefer": {
                "description": "Modelo bioeconómico clásico para recursos renovables",
                "equation": "dX/dt = r*X*(1 - X/K) - Y",
                "parameters": {
                    "K": "Capacidad de carga",
                    "r": "Tasa de crecimiento intrínseco",
                    "X": "Stock actual",
                    "Y": "Extracción"
                }
            },
            "hamiltonian": {
                "description": "Enfoque de control óptimo para precios sombra",
                "equation": "H = π(X,E) + λ[F(X) - Y]",
                "components": {
                    "H": "Hamiltoniano (valor total del sistema)",
                    "λ": "Precio sombra (variable co-estado)",
                    "F(X)": "Función de crecimiento",
                    "π": "Beneficio neto"
                }
            }
        },
        "compliance": {
            "seea_ea": "Sistema de Contabilidad Ambiental y Económica - Cuentas Ecosistémicas",
            "tnfd": "Taskforce on Nature-related Financial Disclosures",
            "eu_taxonomy": "Taxonomía de la UE para finanzas sostenibles"
        },
        "data_sources": [
            "Inventarios forestales nacionales",
            "Cuentas de agua (DGA)",
            "Estudios de biodiversidad (MMA/CONAF)",
            "Valoraciones de servicios ecosistémicos"
        ]
    }
