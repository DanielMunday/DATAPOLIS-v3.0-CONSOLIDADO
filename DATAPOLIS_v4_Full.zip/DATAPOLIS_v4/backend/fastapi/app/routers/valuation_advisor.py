"""
DATAPOLIS v4.0 - Valuation Advisor Router
==========================================
Endpoints REST para el Asistente de Métodos de Valuación.
"""

from fastapi import APIRouter, HTTPException
from typing import List, Optional
from pydantic import BaseModel, Field
from enum import Enum

from app.services.m_valuation_advisor import (
    valuation_advisor, ValuationContext, AssetType, ValuationPurpose,
    DataQuality, TimeHorizon, ValuationMethod
)

router = APIRouter(prefix="/valuation-advisor", tags=["Valuation Advisor (v4.0)"])


# Enums for API
class AssetTypeEnum(str, Enum):
    residential_property = "residential_property"
    commercial_property = "commercial_property"
    industrial_property = "industrial_property"
    land = "land"
    agricultural = "agricultural"
    special_use = "special_use"
    development_site = "development_site"
    natural_asset = "natural_asset"
    ecosystem = "ecosystem"
    water_rights = "water_rights"
    portfolio = "portfolio"


class PurposeEnum(str, Enum):
    market_transaction = "market_transaction"
    collateral = "collateral"
    financial_reporting = "financial_reporting"
    tax_assessment = "tax_assessment"
    expropriation = "expropriation"
    litigation = "litigation"
    insurance = "insurance"
    investment_analysis = "investment_analysis"
    esg_reporting = "esg_reporting"
    regulatory = "regulatory"
    internal_decision = "internal_decision"


class DataQualityEnum(str, Enum):
    excellent = "excellent"
    good = "good"
    moderate = "moderate"
    limited = "limited"
    poor = "poor"


class TimeHorizonEnum(str, Enum):
    spot = "spot"
    short_term = "short_term"
    medium_term = "medium_term"
    long_term = "long_term"
    perpetuity = "perpetuity"


class MethodEnum(str, Enum):
    market_comparison = "market_comparison"
    income_capitalization = "income_capitalization"
    dcf = "discounted_cash_flow"
    cost_approach = "cost_approach"
    hedonic_pricing = "hedonic_pricing"
    ml_ensemble = "ml_ensemble"
    ecosystem_services = "ecosystem_services"
    natural_capital_accounting = "natural_capital_accounting"


# Request Models
class ValuationContextRequest(BaseModel):
    """Request para obtener recomendación de método."""
    asset_type: AssetTypeEnum
    purpose: PurposeEnum
    time_horizon: TimeHorizonEnum = TimeHorizonEnum.spot
    data_quality: DataQualityEnum = DataQualityEnum.moderate
    market_activity: str = Field(default="moderate", description="active, moderate, limited, none")
    income_producing: bool = False
    comparable_availability: int = Field(default=50, ge=0, le=100)
    regulatory_requirement: Optional[str] = None
    special_considerations: List[str] = Field(default_factory=list)
    budget_constraint: Optional[str] = None
    time_constraint: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "asset_type": "residential_property",
                "purpose": "collateral",
                "time_horizon": "spot",
                "data_quality": "good",
                "market_activity": "active",
                "income_producing": False,
                "comparable_availability": 75,
                "regulatory_requirement": "NCG 514 CMF"
            }
        }


# Endpoints
@router.post("/recommend")
async def get_valuation_recommendation(request: ValuationContextRequest):
    """
    Obtiene recomendación de método de valuación basada en el contexto.
    
    Analiza el tipo de activo, propósito, calidad de datos y otras variables
    para recomendar el método más apropiado.
    """
    try:
        context = ValuationContext(
            asset_type=AssetType(request.asset_type.value),
            purpose=ValuationPurpose(request.purpose.value),
            time_horizon=TimeHorizon(request.time_horizon.value),
            data_quality=DataQuality(request.data_quality.value),
            market_activity=request.market_activity,
            income_producing=request.income_producing,
            comparable_availability=request.comparable_availability,
            regulatory_requirement=request.regulatory_requirement,
            special_considerations=request.special_considerations,
            budget_constraint=request.budget_constraint,
            time_constraint=request.time_constraint
        )
        
        result = valuation_advisor.get_recommendation(context)
        
        # Formatear respuesta
        primary = result.primary_recommendation
        alternatives = result.alternative_recommendations
        
        return {
            "request_id": result.request_id,
            "context_summary": {
                "asset_type": request.asset_type.value,
                "purpose": request.purpose.value,
                "data_quality": request.data_quality.value,
                "comparable_availability": request.comparable_availability
            },
            "primary_recommendation": {
                "method": primary.method.value,
                "suitability_score": primary.suitability_score,
                "rationale": primary.rationale,
                "strengths": primary.strengths,
                "limitations": primary.limitations,
                "data_requirements": primary.data_requirements,
                "estimated_accuracy": primary.estimated_accuracy,
                "compliance": {
                    "ivs_aligned": primary.ivs_aligned,
                    "rics_compliant": primary.rics_compliant,
                    "basel_compliant": primary.basel_compliant
                },
                "implementation_complexity": primary.implementation_complexity,
                "datapolis_module": primary.datapolis_module
            },
            "alternative_recommendations": [
                {
                    "method": alt.method.value,
                    "suitability_score": alt.suitability_score,
                    "rationale": alt.rationale,
                    "datapolis_module": alt.datapolis_module
                }
                for alt in alternatives
            ],
            "hybrid_approach": result.hybrid_approach,
            "reconciliation_guidance": result.reconciliation_guidance,
            "key_assumptions": result.key_assumptions,
            "risk_factors": result.risk_factors,
            "quality_considerations": result.quality_considerations,
            "regulatory_notes": result.regulatory_notes,
            "timestamp": result.timestamp
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/methods")
async def list_valuation_methods():
    """Lista todos los métodos de valuación disponibles."""
    return valuation_advisor.list_available_methods()


@router.get("/methods/{method}")
async def get_method_details(method: MethodEnum):
    """Obtiene detalles de un método de valuación específico."""
    try:
        vm = ValuationMethod(method.value)
        return valuation_advisor.get_method_details(vm)
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Método no encontrado: {method.value}")


@router.get("/asset-types")
async def list_asset_types():
    """Lista tipos de activos soportados."""
    return {
        "asset_types": [
            {"code": at.value, "name": at.value.replace("_", " ").title()}
            for at in AssetType
        ]
    }


@router.get("/purposes")
async def list_valuation_purposes():
    """Lista propósitos de valuación soportados."""
    return {
        "purposes": [
            {"code": p.value, "name": p.value.replace("_", " ").title()}
            for p in ValuationPurpose
        ]
    }


@router.post("/quick-recommend")
async def quick_recommendation(
    asset_type: AssetTypeEnum,
    purpose: PurposeEnum,
    comparable_availability: int = 50
):
    """
    Recomendación rápida con parámetros mínimos.
    """
    try:
        context = ValuationContext(
            asset_type=AssetType(asset_type.value),
            purpose=ValuationPurpose(purpose.value),
            time_horizon=TimeHorizon.SPOT,
            data_quality=DataQuality.MODERATE,
            market_activity="moderate",
            income_producing=False,
            comparable_availability=comparable_availability
        )
        
        result = valuation_advisor.get_recommendation(context)
        primary = result.primary_recommendation
        
        return {
            "recommended_method": primary.method.value,
            "suitability_score": primary.suitability_score,
            "datapolis_module": primary.datapolis_module,
            "quick_rationale": primary.rationale[:200] + "..." if len(primary.rationale) > 200 else primary.rationale
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/decision-tree")
async def get_decision_tree():
    """
    Retorna el árbol de decisión simplificado para selección de métodos.
    """
    return {
        "decision_tree": {
            "start": "¿Qué tipo de activo se va a valorar?",
            "branches": [
                {
                    "condition": "Propiedad inmobiliaria con mercado activo",
                    "questions": [
                        {
                            "question": "¿Hay comparables disponibles?",
                            "yes": "Market Comparison",
                            "no": {
                                "question": "¿Genera ingresos?",
                                "yes": "Income Capitalization / DCF",
                                "no": "Cost Approach o Hedonic Pricing"
                            }
                        }
                    ]
                },
                {
                    "condition": "Activo natural o ecosistema",
                    "questions": [
                        {
                            "question": "¿Para ESG/sustainability reporting?",
                            "yes": "Natural Capital Accounting + Ecosystem Services",
                            "no": {
                                "question": "¿Para crédito/colateral?",
                                "yes": "Market Comparison con ajustes ESG",
                                "no": "Ecosystem Services Valuation"
                            }
                        }
                    ]
                },
                {
                    "condition": "Proyecto de desarrollo",
                    "primary": "DCF / Residual Method"
                },
                {
                    "condition": "Activo especializado sin mercado",
                    "primary": "Cost Approach"
                }
            ]
        },
        "notes": [
            "Este árbol es una simplificación. Use /recommend para análisis completo.",
            "Los métodos pueden combinarse (hybrid approach) para mayor robustez."
        ]
    }
