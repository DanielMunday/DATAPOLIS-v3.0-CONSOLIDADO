"""
DATAPOLIS v4.0 - Ecosystem Services Valuation Module (M-ESV)
=============================================================
Implementación de valoración de servicios ecosistémicos.

Características:
- Valoración por bioma/tipo de ecosistema
- Value transfer methodology (ESVD/InVEST compatible)
- Cálculo de NPV de servicios ecosistémicos
- Integración con capas geoespaciales
- Compliance con SEEA-EA y TNFD
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class BiomeType(Enum):
    """Tipos de biomas según clasificación ESVD."""
    TROPICAL_FOREST = "tropical_forest"
    TEMPERATE_FOREST = "temperate_forest"
    BOREAL_FOREST = "boreal_forest"
    GRASSLAND = "grassland"
    WETLAND = "wetland"
    COASTAL = "coastal"
    MARINE = "marine"
    FRESHWATER = "freshwater"
    URBAN_GREEN = "urban_green"
    AGRICULTURAL = "agricultural"
    DESERT = "desert"
    TUNDRA = "tundra"


class EcosystemService(Enum):
    """Servicios ecosistémicos según clasificación CICES."""
    # Provisioning
    FOOD_PROVISION = "food_provision"
    WATER_PROVISION = "water_provision"
    RAW_MATERIALS = "raw_materials"
    GENETIC_RESOURCES = "genetic_resources"
    MEDICINAL_RESOURCES = "medicinal_resources"
    
    # Regulating
    AIR_QUALITY = "air_quality_regulation"
    CLIMATE_REGULATION = "climate_regulation"
    WATER_REGULATION = "water_regulation"
    EROSION_CONTROL = "erosion_control"
    WATER_PURIFICATION = "water_purification"
    POLLINATION = "pollination"
    BIOLOGICAL_CONTROL = "biological_control"
    STORM_PROTECTION = "storm_protection"
    
    # Cultural
    RECREATION = "recreation"
    AESTHETIC = "aesthetic_value"
    SPIRITUAL = "spiritual_cultural"
    EDUCATION = "education_research"
    
    # Supporting
    HABITAT = "habitat_provision"
    NUTRIENT_CYCLING = "nutrient_cycling"
    SOIL_FORMATION = "soil_formation"


@dataclass
class ServiceValueEstimate:
    """Estimación de valor de un servicio ecosistémico."""
    service: EcosystemService
    annual_value_usd_ha: float
    confidence_level: str  # low, medium, high
    data_source: str
    methodology: str
    adjustment_factor: float = 1.0
    notes: Optional[str] = None


@dataclass
class BiomeServiceMatrix:
    """Matriz de valores de servicios por bioma."""
    biome: BiomeType
    services: Dict[EcosystemService, ServiceValueEstimate]
    total_annual_value_usd_ha: float
    data_year: int
    region: str


@dataclass
class EcosystemValuationResult:
    """Resultado de valoración de servicios ecosistémicos."""
    polygon_id: str
    area_hectares: float
    biome_type: BiomeType
    services_breakdown: List[ServiceValueEstimate]
    total_annual_value_usd: float
    total_annual_value_clp: float
    npv_usd: float
    npv_clp: float
    discount_rate: float
    time_horizon_years: int
    valuation_date: str
    methodology: str
    confidence: str
    data_sources: List[str]


# Base de datos de valores de servicios ecosistémicos por bioma
# Basado en ESVD (Ecosystem Services Valuation Database) y literatura
# Valores en USD/ha/año (2024, ajustados por inflación y PPP)
BIOME_SERVICE_VALUES: Dict[BiomeType, Dict[EcosystemService, float]] = {
    BiomeType.TROPICAL_FOREST: {
        EcosystemService.CLIMATE_REGULATION: 1965.0,
        EcosystemService.WATER_REGULATION: 1195.0,
        EcosystemService.EROSION_CONTROL: 420.0,
        EcosystemService.FOOD_PROVISION: 315.0,
        EcosystemService.RAW_MATERIALS: 845.0,
        EcosystemService.GENETIC_RESOURCES: 210.0,
        EcosystemService.RECREATION: 525.0,
        EcosystemService.HABITAT: 385.0,
        EcosystemService.POLLINATION: 265.0,
        EcosystemService.AIR_QUALITY: 150.0,
    },
    BiomeType.TEMPERATE_FOREST: {
        EcosystemService.CLIMATE_REGULATION: 1245.0,
        EcosystemService.WATER_REGULATION: 895.0,
        EcosystemService.EROSION_CONTROL: 315.0,
        EcosystemService.FOOD_PROVISION: 185.0,
        EcosystemService.RAW_MATERIALS: 625.0,
        EcosystemService.RECREATION: 420.0,
        EcosystemService.HABITAT: 280.0,
        EcosystemService.AIR_QUALITY: 125.0,
        EcosystemService.AESTHETIC: 185.0,
    },
    BiomeType.WETLAND: {
        EcosystemService.WATER_PURIFICATION: 2450.0,
        EcosystemService.WATER_REGULATION: 1820.0,
        EcosystemService.STORM_PROTECTION: 1540.0,
        EcosystemService.CLIMATE_REGULATION: 980.0,
        EcosystemService.HABITAT: 715.0,
        EcosystemService.FOOD_PROVISION: 385.0,
        EcosystemService.RECREATION: 560.0,
        EcosystemService.NUTRIENT_CYCLING: 420.0,
    },
    BiomeType.COASTAL: {
        EcosystemService.STORM_PROTECTION: 2100.0,
        EcosystemService.EROSION_CONTROL: 1260.0,
        EcosystemService.FOOD_PROVISION: 945.0,
        EcosystemService.RECREATION: 1575.0,
        EcosystemService.HABITAT: 630.0,
        EcosystemService.WATER_PURIFICATION: 420.0,
        EcosystemService.AESTHETIC: 735.0,
    },
    BiomeType.URBAN_GREEN: {
        EcosystemService.AIR_QUALITY: 1120.0,
        EcosystemService.CLIMATE_REGULATION: 840.0,
        EcosystemService.RECREATION: 1680.0,
        EcosystemService.AESTHETIC: 980.0,
        EcosystemService.WATER_REGULATION: 560.0,
        EcosystemService.HABITAT: 280.0,
        EcosystemService.SPIRITUAL: 350.0,
    },
    BiomeType.GRASSLAND: {
        EcosystemService.FOOD_PROVISION: 445.0,
        EcosystemService.CLIMATE_REGULATION: 315.0,
        EcosystemService.EROSION_CONTROL: 185.0,
        EcosystemService.WATER_REGULATION: 245.0,
        EcosystemService.HABITAT: 210.0,
        EcosystemService.POLLINATION: 155.0,
        EcosystemService.RECREATION: 125.0,
    },
    BiomeType.FRESHWATER: {
        EcosystemService.WATER_PROVISION: 2240.0,
        EcosystemService.WATER_PURIFICATION: 1680.0,
        EcosystemService.FOOD_PROVISION: 560.0,
        EcosystemService.RECREATION: 840.0,
        EcosystemService.HABITAT: 420.0,
        EcosystemService.CLIMATE_REGULATION: 315.0,
    },
    BiomeType.AGRICULTURAL: {
        EcosystemService.FOOD_PROVISION: 985.0,
        EcosystemService.POLLINATION: 420.0,
        EcosystemService.WATER_REGULATION: 185.0,
        EcosystemService.SOIL_FORMATION: 155.0,
        EcosystemService.BIOLOGICAL_CONTROL: 210.0,
    },
}

# Factores de ajuste regional para Chile
CHILE_REGIONAL_FACTORS: Dict[str, float] = {
    "norte_grande": 0.75,      # Arica, Tarapacá, Antofagasta
    "norte_chico": 0.85,       # Atacama, Coquimbo
    "zona_central": 1.0,       # Valparaíso, RM, O'Higgins, Maule
    "zona_sur": 1.1,           # Biobío, Araucanía, Los Ríos, Los Lagos
    "zona_austral": 0.95,      # Aysén, Magallanes
}


class EcosystemServicesService:
    """
    Servicio de valoración de servicios ecosistémicos.
    
    Implementa metodología de value transfer para estimar el valor económico
    de los servicios ecosistémicos de un área determinada.
    """
    
    def __init__(self):
        self.usd_to_clp_rate = 950.0  # Tasa de cambio USD/CLP
        self.default_discount_rate = 0.03  # 3% real
        self.default_horizon_years = 30
        self.base_year = 2024
        self.inflation_rate = 0.02
    
    def valuate_polygon(
        self,
        polygon_id: str,
        area_hectares: float,
        biome_type: BiomeType,
        region: str = "zona_central",
        custom_services: Optional[Dict[str, float]] = None,
        discount_rate: Optional[float] = None,
        time_horizon_years: Optional[int] = None,
        include_all_services: bool = True
    ) -> EcosystemValuationResult:
        """
        Valúa los servicios ecosistémicos de un polígono.
        
        Args:
            polygon_id: Identificador del polígono
            area_hectares: Área en hectáreas
            biome_type: Tipo de bioma
            region: Región de Chile para ajuste
            custom_services: Valores personalizados de servicios (USD/ha/año)
            discount_rate: Tasa de descuento (default 3%)
            time_horizon_years: Horizonte de valoración (default 30)
            include_all_services: Incluir todos los servicios del bioma
            
        Returns:
            EcosystemValuationResult con valoración completa
        """
        discount_rate = discount_rate or self.default_discount_rate
        time_horizon_years = time_horizon_years or self.default_horizon_years
        
        # Obtener valores base del bioma
        base_values = BIOME_SERVICE_VALUES.get(biome_type, {})
        
        # Aplicar valores personalizados si existen
        if custom_services:
            for service_name, value in custom_services.items():
                try:
                    service = EcosystemService(service_name)
                    base_values[service] = value
                except ValueError:
                    pass
        
        # Aplicar factor regional
        regional_factor = CHILE_REGIONAL_FACTORS.get(region, 1.0)
        
        # Construir breakdown de servicios
        services_breakdown = []
        total_annual_per_ha = 0.0
        
        for service, value_usd_ha in base_values.items():
            adjusted_value = value_usd_ha * regional_factor
            total_annual_per_ha += adjusted_value
            
            services_breakdown.append(ServiceValueEstimate(
                service=service,
                annual_value_usd_ha=adjusted_value,
                confidence_level=self._get_confidence_level(service, biome_type),
                data_source="ESVD/InVEST adapted for Chile",
                methodology="benefit_transfer",
                adjustment_factor=regional_factor,
                notes=f"Regional factor: {regional_factor}"
            ))
        
        # Calcular valores totales
        total_annual_usd = total_annual_per_ha * area_hectares
        total_annual_clp = total_annual_usd * self.usd_to_clp_rate
        
        # Calcular NPV
        npv_usd = self._calculate_npv(
            annual_value=total_annual_usd,
            discount_rate=discount_rate,
            years=time_horizon_years
        )
        npv_clp = npv_usd * self.usd_to_clp_rate
        
        # Determinar confianza global
        confidence = self._aggregate_confidence(services_breakdown)
        
        return EcosystemValuationResult(
            polygon_id=polygon_id,
            area_hectares=area_hectares,
            biome_type=biome_type,
            services_breakdown=services_breakdown,
            total_annual_value_usd=round(total_annual_usd, 2),
            total_annual_value_clp=round(total_annual_clp, 0),
            npv_usd=round(npv_usd, 2),
            npv_clp=round(npv_clp, 0),
            discount_rate=discount_rate,
            time_horizon_years=time_horizon_years,
            valuation_date=datetime.now().isoformat(),
            methodology="benefit_transfer_esvd",
            confidence=confidence,
            data_sources=["ESVD", "InVEST", "TEEB", "Regional studies Chile"]
        )
    
    def valuate_project_impact(
        self,
        project_id: str,
        affected_areas: List[Dict[str, Any]],
        scenario: str = "with_project"
    ) -> Dict[str, Any]:
        """
        Valúa el impacto de un proyecto sobre servicios ecosistémicos.
        
        Args:
            project_id: Identificador del proyecto
            affected_areas: Lista de áreas afectadas con bioma y superficie
            scenario: 'with_project' o 'without_project'
            
        Returns:
            Valoración del impacto neto
        """
        total_impact_usd = 0.0
        area_valuations = []
        
        for area in affected_areas:
            biome = BiomeType(area.get("biome_type", "grassland"))
            hectares = area.get("area_hectares", 0)
            change_factor = area.get("change_factor", 1.0)  # 0=destrucción total, 1=sin cambio, >1=mejora
            
            # Valorar área original
            original = self.valuate_polygon(
                polygon_id=f"{project_id}_area_{len(area_valuations)}",
                area_hectares=hectares,
                biome_type=biome,
                region=area.get("region", "zona_central")
            )
            
            # Calcular impacto
            if scenario == "with_project":
                impact_annual = original.total_annual_value_usd * (change_factor - 1)
            else:
                impact_annual = 0
            
            area_valuations.append({
                "area_id": area.get("id", "unknown"),
                "biome": biome.value,
                "hectares": hectares,
                "original_annual_value_usd": original.total_annual_value_usd,
                "change_factor": change_factor,
                "impact_annual_usd": impact_annual
            })
            
            total_impact_usd += impact_annual
        
        # NPV del impacto
        npv_impact = self._calculate_npv(total_impact_usd, self.default_discount_rate, self.default_horizon_years)
        
        return {
            "project_id": project_id,
            "scenario": scenario,
            "total_areas_analyzed": len(affected_areas),
            "total_annual_impact_usd": round(total_impact_usd, 2),
            "total_annual_impact_clp": round(total_impact_usd * self.usd_to_clp_rate, 0),
            "npv_impact_usd": round(npv_impact, 2),
            "npv_impact_clp": round(npv_impact * self.usd_to_clp_rate, 0),
            "area_details": area_valuations,
            "valuation_date": datetime.now().isoformat()
        }
    
    def get_biome_services(self, biome_type: BiomeType) -> BiomeServiceMatrix:
        """Obtiene la matriz de servicios para un bioma."""
        services = {}
        values = BIOME_SERVICE_VALUES.get(biome_type, {})
        total = 0.0
        
        for service, value in values.items():
            services[service] = ServiceValueEstimate(
                service=service,
                annual_value_usd_ha=value,
                confidence_level=self._get_confidence_level(service, biome_type),
                data_source="ESVD/TEEB",
                methodology="meta_analysis"
            )
            total += value
        
        return BiomeServiceMatrix(
            biome=biome_type,
            services=services,
            total_annual_value_usd_ha=total,
            data_year=self.base_year,
            region="global_with_chile_adjustment"
        )
    
    def compare_scenarios(
        self,
        polygon_id: str,
        area_hectares: float,
        current_biome: BiomeType,
        proposed_biome: BiomeType,
        region: str = "zona_central"
    ) -> Dict[str, Any]:
        """Compara escenarios de cambio de uso de suelo."""
        current = self.valuate_polygon(polygon_id, area_hectares, current_biome, region)
        proposed = self.valuate_polygon(f"{polygon_id}_proposed", area_hectares, proposed_biome, region)
        
        annual_change = proposed.total_annual_value_usd - current.total_annual_value_usd
        npv_change = proposed.npv_usd - current.npv_usd
        
        return {
            "polygon_id": polygon_id,
            "current_scenario": {
                "biome": current_biome.value,
                "annual_value_usd": current.total_annual_value_usd,
                "npv_usd": current.npv_usd
            },
            "proposed_scenario": {
                "biome": proposed_biome.value,
                "annual_value_usd": proposed.total_annual_value_usd,
                "npv_usd": proposed.npv_usd
            },
            "change": {
                "annual_usd": round(annual_change, 2),
                "annual_clp": round(annual_change * self.usd_to_clp_rate, 0),
                "npv_usd": round(npv_change, 2),
                "npv_clp": round(npv_change * self.usd_to_clp_rate, 0),
                "percent_change": round(annual_change / current.total_annual_value_usd * 100, 2) if current.total_annual_value_usd > 0 else 0
            },
            "recommendation": "proceed" if annual_change >= 0 else "reconsider"
        }
    
    def _calculate_npv(
        self, annual_value: float, discount_rate: float, years: int
    ) -> float:
        """Calcula el Valor Presente Neto de un flujo anual constante."""
        if discount_rate <= 0:
            return annual_value * years
        
        # Fórmula de anualidad: NPV = C * [(1 - (1+r)^-n) / r]
        npv = annual_value * ((1 - (1 + discount_rate) ** (-years)) / discount_rate)
        return npv
    
    def _get_confidence_level(
        self, service: EcosystemService, biome: BiomeType
    ) -> str:
        """Determina el nivel de confianza basado en disponibilidad de datos."""
        # Servicios bien estudiados
        high_confidence = {
            EcosystemService.FOOD_PROVISION,
            EcosystemService.WATER_PROVISION,
            EcosystemService.RECREATION,
            EcosystemService.RAW_MATERIALS,
        }
        
        medium_confidence = {
            EcosystemService.CLIMATE_REGULATION,
            EcosystemService.WATER_REGULATION,
            EcosystemService.EROSION_CONTROL,
            EcosystemService.AIR_QUALITY,
        }
        
        if service in high_confidence:
            return "high"
        elif service in medium_confidence:
            return "medium"
        return "low"
    
    def _aggregate_confidence(
        self, services: List[ServiceValueEstimate]
    ) -> str:
        """Agrega niveles de confianza de múltiples servicios."""
        if not services:
            return "low"
        
        confidence_scores = {"low": 1, "medium": 2, "high": 3}
        avg_score = np.mean([
            confidence_scores.get(s.confidence_level, 1) for s in services
        ])
        
        if avg_score >= 2.5:
            return "high"
        elif avg_score >= 1.5:
            return "medium"
        return "low"
    
    def get_available_biomes(self) -> List[Dict[str, Any]]:
        """Lista biomas disponibles con sus valores totales."""
        biomes = []
        for biome, services in BIOME_SERVICE_VALUES.items():
            total = sum(services.values())
            biomes.append({
                "biome_type": biome.value,
                "total_annual_value_usd_ha": round(total, 2),
                "num_services": len(services),
                "top_services": sorted(
                    [(s.value, v) for s, v in services.items()],
                    key=lambda x: x[1],
                    reverse=True
                )[:3]
            })
        return sorted(biomes, key=lambda x: x["total_annual_value_usd_ha"], reverse=True)


# Singleton instance
ecosystem_services = EcosystemServicesService()
