"""
DATAPOLIS v4.0 - Environmental Data Hub Module (M-ENV)
========================================================
Hub centralizado de datos ambientales y ESG.

Características:
- Normalización de capas geoespaciales ambientales
- Series temporales de variables ambientales
- Integración con GIRES, ÁGORA, Hedonic, y Ecosystem Services
- API interna para todos los módulos v4.0
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import json


class EnvironmentalLayerType(Enum):
    """Tipos de capas ambientales."""
    # Coberturas de suelo
    LAND_COVER = "land_cover"
    VEGETATION = "vegetation_index"
    IMPERVIOUS = "impervious_surface"
    
    # Recursos hídricos
    WATER_BODIES = "water_bodies"
    WATERSHED = "watershed"
    GROUNDWATER = "groundwater"
    
    # Áreas verdes
    GREEN_SPACE = "green_space"
    URBAN_FOREST = "urban_forest"
    PARKS = "parks"
    
    # Riesgos
    FLOOD_RISK = "flood_risk"
    SEISMIC_RISK = "seismic_risk"
    LANDSLIDE_RISK = "landslide_risk"
    WILDFIRE_RISK = "wildfire_risk"
    COASTAL_EROSION = "coastal_erosion"
    
    # Calidad ambiental
    AIR_QUALITY = "air_quality"
    NOISE_LEVEL = "noise_level"
    LIGHT_POLLUTION = "light_pollution"
    
    # Biodiversidad
    BIODIVERSITY_INDEX = "biodiversity"
    PROTECTED_AREAS = "protected_areas"
    ECOLOGICAL_CORRIDORS = "ecological_corridors"
    
    # Clima
    TEMPERATURE = "temperature"
    PRECIPITATION = "precipitation"
    SOLAR_RADIATION = "solar_radiation"
    WIND = "wind_patterns"


class DataQualityLevel(Enum):
    """Nivel de calidad de datos."""
    VERIFIED = "verified"
    PROVISIONAL = "provisional"
    ESTIMATED = "estimated"
    MODELED = "modeled"


@dataclass
class EnvironmentalLayer:
    """Capa ambiental geoespacial."""
    layer_id: str
    layer_type: EnvironmentalLayerType
    name: str
    description: str
    source: str
    resolution_meters: float
    coverage_area: str
    last_updated: str
    quality_level: DataQualityLevel
    unit: str
    min_value: float
    max_value: float
    nodata_value: float
    crs: str = "EPSG:4326"
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EnvironmentalTimeSeries:
    """Serie temporal de datos ambientales."""
    series_id: str
    variable: str
    location_id: str
    location_name: str
    coordinates: Tuple[float, float]
    start_date: str
    end_date: str
    frequency: str  # daily, weekly, monthly, yearly
    values: List[float]
    dates: List[str]
    unit: str
    source: str
    quality_level: DataQualityLevel


@dataclass
class EnvironmentalProfile:
    """Perfil ambiental de una ubicación."""
    location_id: str
    coordinates: Tuple[float, float]
    address: Optional[str]
    layers_data: Dict[str, Any]
    risk_summary: Dict[str, str]
    quality_indicators: Dict[str, float]
    esg_score: float
    natural_capital_proximity: Dict[str, float]
    timestamp: str


# Base de datos de capas ambientales disponibles (simulada)
AVAILABLE_LAYERS: Dict[EnvironmentalLayerType, EnvironmentalLayer] = {
    EnvironmentalLayerType.GREEN_SPACE: EnvironmentalLayer(
        layer_id="green_space_rm",
        layer_type=EnvironmentalLayerType.GREEN_SPACE,
        name="Áreas Verdes Región Metropolitana",
        description="Cobertura de áreas verdes urbanas y periurbanas",
        source="MINVU/CONAF",
        resolution_meters=10,
        coverage_area="Región Metropolitana",
        last_updated="2025-12-01",
        quality_level=DataQualityLevel.VERIFIED,
        unit="percentage",
        min_value=0,
        max_value=100,
        nodata_value=-9999
    ),
    EnvironmentalLayerType.AIR_QUALITY: EnvironmentalLayer(
        layer_id="air_quality_chile",
        layer_type=EnvironmentalLayerType.AIR_QUALITY,
        name="Índice de Calidad del Aire",
        description="ICA basado en PM2.5, PM10, O3, NO2",
        source="MMA/SINCA",
        resolution_meters=1000,
        coverage_area="Chile",
        last_updated="2026-02-01",
        quality_level=DataQualityLevel.VERIFIED,
        unit="ICA",
        min_value=0,
        max_value=500,
        nodata_value=-9999
    ),
    EnvironmentalLayerType.FLOOD_RISK: EnvironmentalLayer(
        layer_id="flood_risk_chile",
        layer_type=EnvironmentalLayerType.FLOOD_RISK,
        name="Riesgo de Inundación",
        description="Zonas de riesgo de inundación fluvial y pluvial",
        source="DGA/SERNAGEOMIN",
        resolution_meters=30,
        coverage_area="Chile",
        last_updated="2025-06-01",
        quality_level=DataQualityLevel.VERIFIED,
        unit="risk_level",
        min_value=1,
        max_value=5,
        nodata_value=0
    ),
    EnvironmentalLayerType.BIODIVERSITY_INDEX: EnvironmentalLayer(
        layer_id="biodiversity_chile",
        layer_type=EnvironmentalLayerType.BIODIVERSITY_INDEX,
        name="Índice de Biodiversidad",
        description="Riqueza de especies y conectividad ecológica",
        source="MMA/CONAF",
        resolution_meters=100,
        coverage_area="Chile",
        last_updated="2025-03-01",
        quality_level=DataQualityLevel.MODELED,
        unit="index",
        min_value=0,
        max_value=100,
        nodata_value=-9999
    ),
}


class EnvironmentalDataHubService:
    """
    Hub centralizado de datos ambientales para DATAPOLIS v4.0.
    
    Provee una API interna unificada para acceder a datos ambientales
    desde cualquier módulo de la plataforma.
    """
    
    def __init__(self):
        self.layers = AVAILABLE_LAYERS
        self._cache = {}
    
    def get_environmental_profile(
        self,
        latitude: float,
        longitude: float,
        radius_meters: float = 1000,
        layers: Optional[List[EnvironmentalLayerType]] = None
    ) -> EnvironmentalProfile:
        """
        Obtiene el perfil ambiental completo de una ubicación.
        
        Args:
            latitude: Latitud
            longitude: Longitud
            radius_meters: Radio de análisis
            layers: Capas específicas a consultar (None = todas)
            
        Returns:
            EnvironmentalProfile con todos los datos ambientales
        """
        if layers is None:
            layers = list(EnvironmentalLayerType)
        
        layers_data = {}
        risk_summary = {}
        quality_indicators = {}
        natural_capital = {}
        
        for layer_type in layers:
            if layer_type in self.layers:
                # Simular extracción de datos
                value = self._extract_layer_value(latitude, longitude, layer_type)
                layers_data[layer_type.value] = value
                
                # Categorizar riesgos
                if "RISK" in layer_type.value.upper():
                    risk_summary[layer_type.value] = self._categorize_risk(value)
                
                # Indicadores de calidad
                if layer_type in [EnvironmentalLayerType.AIR_QUALITY, 
                                  EnvironmentalLayerType.NOISE_LEVEL]:
                    quality_indicators[layer_type.value] = value
                
                # Proximidad a capital natural
                if layer_type in [EnvironmentalLayerType.GREEN_SPACE,
                                  EnvironmentalLayerType.WATER_BODIES,
                                  EnvironmentalLayerType.PROTECTED_AREAS]:
                    natural_capital[layer_type.value] = self._calculate_proximity(value)
        
        # Calcular score ESG
        esg_score = self._calculate_esg_score(layers_data, risk_summary)
        
        return EnvironmentalProfile(
            location_id=f"loc_{latitude:.6f}_{longitude:.6f}",
            coordinates=(latitude, longitude),
            address=None,  # Puede enrichecerse con geocoding
            layers_data=layers_data,
            risk_summary=risk_summary,
            quality_indicators=quality_indicators,
            esg_score=esg_score,
            natural_capital_proximity=natural_capital,
            timestamp=datetime.now().isoformat()
        )
    
    def get_layer_data(
        self,
        layer_type: EnvironmentalLayerType,
        bbox: Optional[Tuple[float, float, float, float]] = None
    ) -> Dict[str, Any]:
        """
        Obtiene datos de una capa ambiental específica.
        
        Args:
            layer_type: Tipo de capa
            bbox: Bounding box (min_lon, min_lat, max_lon, max_lat)
            
        Returns:
            Datos de la capa y metadata
        """
        if layer_type not in self.layers:
            return {"error": f"Capa {layer_type.value} no disponible"}
        
        layer = self.layers[layer_type]
        
        return {
            "layer_id": layer.layer_id,
            "name": layer.name,
            "type": layer_type.value,
            "description": layer.description,
            "source": layer.source,
            "resolution": f"{layer.resolution_meters}m",
            "quality": layer.quality_level.value,
            "last_updated": layer.last_updated,
            "unit": layer.unit,
            "value_range": [layer.min_value, layer.max_value],
            "bbox": bbox,
            "data_url": f"/api/v1/env-hub/layers/{layer_type.value}/data"
        }
    
    def get_time_series(
        self,
        variable: str,
        latitude: float,
        longitude: float,
        start_date: str,
        end_date: str,
        frequency: str = "monthly"
    ) -> EnvironmentalTimeSeries:
        """
        Obtiene serie temporal de una variable ambiental.
        
        Args:
            variable: Variable a consultar (air_quality, temperature, etc.)
            latitude: Latitud
            longitude: Longitud
            start_date: Fecha inicio (YYYY-MM-DD)
            end_date: Fecha fin (YYYY-MM-DD)
            frequency: Frecuencia (daily, weekly, monthly)
            
        Returns:
            EnvironmentalTimeSeries con los datos
        """
        # Generar serie temporal simulada
        dates = pd.date_range(start=start_date, end=end_date, freq={
            "daily": "D", "weekly": "W", "monthly": "M"
        }.get(frequency, "M"))
        
        # Valores simulados con tendencia y estacionalidad
        n = len(dates)
        base_value = self._get_base_value(variable)
        seasonal = np.sin(np.linspace(0, 4*np.pi, n)) * (base_value * 0.2)
        noise = np.random.normal(0, base_value * 0.05, n)
        values = base_value + seasonal + noise
        
        return EnvironmentalTimeSeries(
            series_id=f"ts_{variable}_{latitude:.4f}_{longitude:.4f}",
            variable=variable,
            location_id=f"loc_{latitude:.6f}_{longitude:.6f}",
            location_name=f"Location ({latitude:.4f}, {longitude:.4f})",
            coordinates=(latitude, longitude),
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            values=values.tolist(),
            dates=[d.strftime("%Y-%m-%d") for d in dates],
            unit=self._get_variable_unit(variable),
            source="Environmental Data Hub",
            quality_level=DataQualityLevel.MODELED
        )
    
    def calculate_proximity_to_amenity(
        self,
        latitude: float,
        longitude: float,
        amenity_type: str,
        max_distance_km: float = 5.0
    ) -> Dict[str, Any]:
        """
        Calcula proximidad a amenidades ambientales.
        
        Args:
            latitude: Latitud
            longitude: Longitud
            amenity_type: Tipo de amenidad (park, water, forest, etc.)
            max_distance_km: Distancia máxima de búsqueda
            
        Returns:
            Información de proximidad
        """
        # Simulación de búsqueda de amenidades cercanas
        amenities_found = []
        
        # Simular algunas amenidades cercanas
        np.random.seed(int(latitude * 1000 + longitude * 100) % 2**31)
        n_amenities = np.random.randint(1, 6)
        
        for i in range(n_amenities):
            distance = np.random.uniform(0.1, max_distance_km)
            amenities_found.append({
                "id": f"{amenity_type}_{i+1}",
                "name": f"{amenity_type.title()} {i+1}",
                "distance_km": round(distance, 2),
                "area_hectares": round(np.random.uniform(1, 50), 1) if amenity_type != "water" else None
            })
        
        amenities_found.sort(key=lambda x: x["distance_km"])
        nearest = amenities_found[0] if amenities_found else None
        
        return {
            "amenity_type": amenity_type,
            "search_radius_km": max_distance_km,
            "count_found": len(amenities_found),
            "nearest_distance_km": nearest["distance_km"] if nearest else None,
            "amenities": amenities_found,
            "accessibility_score": self._calculate_accessibility_score(amenities_found)
        }
    
    def get_esg_indicators(
        self,
        latitude: float,
        longitude: float
    ) -> Dict[str, Any]:
        """
        Obtiene indicadores ESG agregados para una ubicación.
        
        Args:
            latitude: Latitud
            longitude: Longitud
            
        Returns:
            Indicadores ESG estructurados
        """
        profile = self.get_environmental_profile(latitude, longitude)
        
        # Environmental indicators
        env_score = profile.esg_score
        
        # Calculate sub-scores
        air_quality = profile.quality_indicators.get("air_quality", 50)
        green_proximity = profile.natural_capital_proximity.get("green_space", 0.5)
        flood_risk_level = profile.risk_summary.get("flood_risk", "moderate")
        
        # Risk multiplier
        risk_multiplier = {
            "low": 1.0, "moderate": 0.9, "high": 0.7, "very_high": 0.5, "critical": 0.3
        }.get(flood_risk_level, 0.8)
        
        return {
            "location": {"latitude": latitude, "longitude": longitude},
            "overall_esg_score": round(env_score, 1),
            "environmental": {
                "score": round(env_score, 1),
                "air_quality_index": round(100 - air_quality, 1),  # Invertir (menor ICA = mejor)
                "green_space_access": round(green_proximity * 100, 1),
                "climate_risk_factor": round(risk_multiplier, 2),
                "biodiversity_index": round(profile.layers_data.get("biodiversity", 50), 1)
            },
            "natural_hazards": {
                "flood_risk": flood_risk_level,
                "seismic_risk": profile.risk_summary.get("seismic_risk", "moderate"),
                "wildfire_risk": profile.risk_summary.get("wildfire_risk", "low"),
                "composite_risk_score": round((1 - risk_multiplier) * 100, 1)
            },
            "natural_capital": {
                "proximity_green_space_km": round(1 / (green_proximity + 0.1), 2),
                "ecosystem_services_potential": round(green_proximity * 80 + 20, 1),
                "carbon_sequestration_index": round(profile.layers_data.get("vegetation_index", 40), 1)
            },
            "compliance": {
                "tnfd_aligned": True,
                "seea_compatible": True,
                "eu_taxonomy_relevant": True
            },
            "timestamp": datetime.now().isoformat()
        }
    
    def list_available_layers(self) -> List[Dict[str, Any]]:
        """Lista todas las capas disponibles."""
        return [
            {
                "type": layer_type.value,
                "name": layer.name,
                "description": layer.description,
                "source": layer.source,
                "quality": layer.quality_level.value,
                "coverage": layer.coverage_area,
                "resolution": f"{layer.resolution_meters}m",
                "last_updated": layer.last_updated
            }
            for layer_type, layer in self.layers.items()
        ]
    
    def _extract_layer_value(
        self, lat: float, lon: float, layer_type: EnvironmentalLayerType
    ) -> float:
        """Extrae valor de una capa en una ubicación (simulado)."""
        # Simulación basada en coordenadas
        np.random.seed(int(lat * 1000 + lon * 100 + hash(layer_type.value)) % 2**31)
        
        layer = self.layers.get(layer_type)
        if layer:
            return np.random.uniform(layer.min_value, layer.max_value)
        return 0.0
    
    def _categorize_risk(self, value: float) -> str:
        """Categoriza nivel de riesgo."""
        if value <= 1:
            return "low"
        elif value <= 2:
            return "moderate"
        elif value <= 3:
            return "high"
        elif value <= 4:
            return "very_high"
        else:
            return "critical"
    
    def _calculate_proximity(self, value: float) -> float:
        """Calcula score de proximidad (0-1)."""
        return min(1.0, value / 100) if value > 0 else 0.0
    
    def _calculate_esg_score(
        self, layers_data: Dict[str, Any], risk_summary: Dict[str, str]
    ) -> float:
        """Calcula score ESG agregado."""
        score = 70.0  # Base
        
        # Ajuste por áreas verdes
        green = layers_data.get("green_space", 0)
        score += min(15, green * 0.15)
        
        # Ajuste por calidad del aire
        air = layers_data.get("air_quality", 100)
        score -= min(15, (air - 50) * 0.15) if air > 50 else 0
        
        # Ajuste por riesgos
        risk_penalties = {"high": 5, "very_high": 10, "critical": 15}
        for risk_type, level in risk_summary.items():
            score -= risk_penalties.get(level, 0)
        
        return max(0, min(100, score))
    
    def _calculate_accessibility_score(self, amenities: List[Dict]) -> float:
        """Calcula score de accesibilidad a amenidades."""
        if not amenities:
            return 0.0
        
        # Ponderar por distancia inversa
        weights = [1 / (a["distance_km"] + 0.1) for a in amenities[:5]]
        score = sum(weights) / 5 * 10  # Normalizar a 0-100
        return min(100, round(score, 1))
    
    def _get_base_value(self, variable: str) -> float:
        """Obtiene valor base para series temporales."""
        base_values = {
            "air_quality": 50,
            "temperature": 15,
            "precipitation": 50,
            "vegetation_index": 60,
            "soil_moisture": 40
        }
        return base_values.get(variable, 50)
    
    def _get_variable_unit(self, variable: str) -> str:
        """Obtiene unidad de una variable."""
        units = {
            "air_quality": "ICA",
            "temperature": "°C",
            "precipitation": "mm",
            "vegetation_index": "NDVI",
            "soil_moisture": "%"
        }
        return units.get(variable, "unit")


# Singleton instance
env_hub_service = EnvironmentalDataHubService()
