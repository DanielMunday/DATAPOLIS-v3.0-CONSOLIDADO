"""
DATAPOLIS v4.0 - Hedonic Pricing Spatial Module (M-HED)
========================================================
Implementación de modelos de precios hedónicos espaciales para valoración inmobiliaria.

Características:
- Modelos OLS, Log-Linear, Box-Cox
- Diagnósticos de multicolinealidad (VIF)
- Criterios de información (AIC/BIC)
- Dependencia espacial (Moran's I)
- Tratamiento conceptual SAR/SEM
- Cálculo de precios implícitos y elasticidades
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
from scipy import stats
from scipy.optimize import minimize_scalar
import warnings

class ModelType(Enum):
    """Tipos de modelos hedónicos soportados."""
    OLS_LINEAR = "ols_linear"
    LOG_LINEAR = "log_linear"
    LOG_LOG = "log_log"
    BOX_COX = "box_cox"
    SAR = "sar"  # Spatial Autoregressive
    SEM = "sem"  # Spatial Error Model


@dataclass
class HedonicCoefficient:
    """Coeficiente de regresión hedónica."""
    variable: str
    coefficient: float
    std_error: float
    t_statistic: float
    p_value: float
    confidence_interval_lower: float
    confidence_interval_upper: float
    is_significant: bool
    implicit_price: Optional[float] = None
    elasticity: Optional[float] = None


@dataclass
class HedonicDiagnostics:
    """Diagnósticos del modelo hedónico."""
    r_squared: float
    adj_r_squared: float
    f_statistic: float
    f_pvalue: float
    aic: float
    bic: float
    durbin_watson: float
    jarque_bera: float
    jarque_bera_pvalue: float
    vif_scores: Dict[str, float]
    multicollinearity_warning: bool
    morans_i: Optional[float] = None
    morans_i_pvalue: Optional[float] = None
    spatial_autocorrelation: Optional[str] = None


@dataclass
class HedonicResult:
    """Resultado completo de estimación hedónica."""
    model_type: ModelType
    n_observations: int
    n_variables: int
    dependent_variable: str
    coefficients: List[HedonicCoefficient]
    diagnostics: HedonicDiagnostics
    box_cox_lambda: Optional[float] = None
    residuals: Optional[List[float]] = None
    fitted_values: Optional[List[float]] = None
    sensitivity_analysis: Optional[Dict[str, Any]] = None


class HedonicPricingService:
    """
    Servicio de estimación de modelos de precios hedónicos espaciales.
    
    Implementa econometría espacial para descomposición del valor inmobiliario
    en atributos estructurales, locacionales y ambientales.
    """
    
    def __init__(self):
        self.alpha = 0.05  # Nivel de significancia
        self.vif_threshold = 10.0  # Umbral de multicolinealidad
    
    def estimate(
        self,
        data: pd.DataFrame,
        dependent_var: str,
        independent_vars: List[str],
        model_type: ModelType = ModelType.OLS_LINEAR,
        weights_matrix: Optional[np.ndarray] = None,
        include_diagnostics: bool = True
    ) -> HedonicResult:
        """
        Estima un modelo hedónico.
        
        Args:
            data: DataFrame con las variables
            dependent_var: Variable dependiente (precio)
            independent_vars: Lista de variables independientes
            model_type: Tipo de modelo a estimar
            weights_matrix: Matriz de pesos espaciales (para SAR/SEM)
            include_diagnostics: Incluir diagnósticos completos
            
        Returns:
            HedonicResult con coeficientes y diagnósticos
        """
        # Validar datos
        self._validate_data(data, dependent_var, independent_vars)
        
        # Preparar matrices
        y = data[dependent_var].values
        X = data[independent_vars].values
        X = np.column_stack([np.ones(len(y)), X])  # Agregar constante
        var_names = ['const'] + independent_vars
        
        # Transformar según tipo de modelo
        y_transformed, lambda_bc = self._transform_dependent(y, model_type)
        X_transformed = self._transform_independent(X, data, independent_vars, model_type)
        
        # Estimar coeficientes OLS
        coefficients, residuals, fitted = self._ols_estimate(y_transformed, X_transformed)
        
        # Calcular estadísticas
        n = len(y)
        k = len(coefficients)
        
        # Errores estándar y t-stats
        mse = np.sum(residuals**2) / (n - k)
        var_coef = mse * np.linalg.inv(X_transformed.T @ X_transformed)
        std_errors = np.sqrt(np.diag(var_coef))
        t_stats = coefficients / std_errors
        p_values = 2 * (1 - stats.t.cdf(np.abs(t_stats), n - k))
        
        # Intervalos de confianza
        t_critical = stats.t.ppf(1 - self.alpha/2, n - k)
        ci_lower = coefficients - t_critical * std_errors
        ci_upper = coefficients + t_critical * std_errors
        
        # Construir coeficientes
        coef_results = []
        for i, var in enumerate(var_names):
            implicit_price = self._calculate_implicit_price(
                coefficients[i], y, model_type, var, data, independent_vars
            )
            elasticity = self._calculate_elasticity(
                coefficients[i], X_transformed[:, i], y_transformed, model_type
            )
            
            coef_results.append(HedonicCoefficient(
                variable=var,
                coefficient=float(coefficients[i]),
                std_error=float(std_errors[i]),
                t_statistic=float(t_stats[i]),
                p_value=float(p_values[i]),
                confidence_interval_lower=float(ci_lower[i]),
                confidence_interval_upper=float(ci_upper[i]),
                is_significant=p_values[i] < self.alpha,
                implicit_price=implicit_price,
                elasticity=elasticity
            ))
        
        # Diagnósticos
        diagnostics = None
        if include_diagnostics:
            diagnostics = self._calculate_diagnostics(
                y_transformed, X_transformed, residuals, fitted,
                coefficients, var_names[1:], weights_matrix
            )
        
        return HedonicResult(
            model_type=model_type,
            n_observations=n,
            n_variables=k - 1,  # Sin constante
            dependent_variable=dependent_var,
            coefficients=coef_results,
            diagnostics=diagnostics,
            box_cox_lambda=lambda_bc,
            residuals=residuals.tolist() if residuals is not None else None,
            fitted_values=fitted.tolist() if fitted is not None else None,
            sensitivity_analysis=self._sensitivity_analysis(data, dependent_var, independent_vars, model_type)
        )
    
    def _validate_data(self, data: pd.DataFrame, dep_var: str, indep_vars: List[str]):
        """Valida los datos de entrada."""
        if dep_var not in data.columns:
            raise ValueError(f"Variable dependiente '{dep_var}' no encontrada")
        
        missing_vars = [v for v in indep_vars if v not in data.columns]
        if missing_vars:
            raise ValueError(f"Variables independientes no encontradas: {missing_vars}")
        
        if data[dep_var].isna().any() or data[indep_vars].isna().any().any():
            raise ValueError("Datos contienen valores faltantes")
        
        if len(data) < len(indep_vars) + 1:
            raise ValueError("Insuficientes observaciones para el número de variables")
    
    def _transform_dependent(
        self, y: np.ndarray, model_type: ModelType
    ) -> Tuple[np.ndarray, Optional[float]]:
        """Transforma la variable dependiente según el tipo de modelo."""
        lambda_bc = None
        
        if model_type == ModelType.OLS_LINEAR:
            return y, None
        
        elif model_type in [ModelType.LOG_LINEAR, ModelType.LOG_LOG]:
            if (y <= 0).any():
                raise ValueError("Log transformation requires positive values")
            return np.log(y), None
        
        elif model_type == ModelType.BOX_COX:
            if (y <= 0).any():
                raise ValueError("Box-Cox transformation requires positive values")
            # Optimizar lambda
            lambda_bc = self._optimize_box_cox_lambda(y)
            return self._box_cox_transform(y, lambda_bc), lambda_bc
        
        return y, None
    
    def _transform_independent(
        self, X: np.ndarray, data: pd.DataFrame,
        indep_vars: List[str], model_type: ModelType
    ) -> np.ndarray:
        """Transforma variables independientes según el tipo de modelo."""
        if model_type == ModelType.LOG_LOG:
            # Log-log: logaritmo de variables continuas positivas
            X_transformed = X.copy()
            for i, var in enumerate(indep_vars, start=1):
                col = data[var].values
                if np.all(col > 0) and not np.issubdtype(data[var].dtype, np.bool_):
                    X_transformed[:, i] = np.log(col)
            return X_transformed
        return X
    
    def _optimize_box_cox_lambda(self, y: np.ndarray) -> float:
        """Optimiza el parámetro lambda de Box-Cox."""
        def neg_log_likelihood(lmbda):
            y_transformed = self._box_cox_transform(y, lmbda)
            n = len(y)
            sigma2 = np.var(y_transformed)
            if sigma2 <= 0:
                return np.inf
            ll = -n/2 * np.log(sigma2) + (lmbda - 1) * np.sum(np.log(y))
            return -ll
        
        result = minimize_scalar(neg_log_likelihood, bounds=(-2, 2), method='bounded')
        return result.x
    
    def _box_cox_transform(self, y: np.ndarray, lmbda: float) -> np.ndarray:
        """Aplica transformación Box-Cox."""
        if abs(lmbda) < 1e-10:
            return np.log(y)
        return (y**lmbda - 1) / lmbda
    
    def _ols_estimate(
        self, y: np.ndarray, X: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Estimación OLS."""
        # Coeficientes: (X'X)^-1 X'y
        XtX_inv = np.linalg.inv(X.T @ X)
        coefficients = XtX_inv @ X.T @ y
        
        # Valores ajustados y residuos
        fitted = X @ coefficients
        residuals = y - fitted
        
        return coefficients, residuals, fitted
    
    def _calculate_implicit_price(
        self, coef: float, y: np.ndarray, model_type: ModelType,
        var_name: str, data: pd.DataFrame, indep_vars: List[str]
    ) -> Optional[float]:
        """Calcula el precio implícito de un atributo."""
        if var_name == 'const':
            return None
        
        mean_price = np.mean(y)
        
        if model_type == ModelType.OLS_LINEAR:
            # Precio implícito directo
            return coef
        
        elif model_type in [ModelType.LOG_LINEAR, ModelType.LOG_LOG]:
            # Para log-linear: ∂P/∂x = β * P
            return coef * mean_price
        
        return coef
    
    def _calculate_elasticity(
        self, coef: float, x: np.ndarray, y: np.ndarray, model_type: ModelType
    ) -> Optional[float]:
        """Calcula la elasticidad."""
        if model_type == ModelType.LOG_LOG:
            # En log-log, el coeficiente es directamente la elasticidad
            return coef
        
        elif model_type == ModelType.LOG_LINEAR:
            # Elasticidad = β * mean(x)
            return coef * np.mean(x)
        
        elif model_type == ModelType.OLS_LINEAR:
            # Elasticidad = β * (mean(x) / mean(y))
            mean_x = np.mean(x)
            mean_y = np.mean(y)
            if mean_y != 0:
                return coef * (mean_x / mean_y)
        
        return None
    
    def _calculate_diagnostics(
        self, y: np.ndarray, X: np.ndarray, residuals: np.ndarray,
        fitted: np.ndarray, coefficients: np.ndarray,
        var_names: List[str], weights_matrix: Optional[np.ndarray]
    ) -> HedonicDiagnostics:
        """Calcula diagnósticos del modelo."""
        n = len(y)
        k = len(coefficients)
        
        # R² y R² ajustado
        ss_res = np.sum(residuals**2)
        ss_tot = np.sum((y - np.mean(y))**2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
        adj_r_squared = 1 - (1 - r_squared) * (n - 1) / (n - k)
        
        # Estadístico F
        ms_reg = (ss_tot - ss_res) / (k - 1) if k > 1 else 0
        ms_res = ss_res / (n - k)
        f_stat = ms_reg / ms_res if ms_res > 0 else 0
        f_pvalue = 1 - stats.f.cdf(f_stat, k - 1, n - k) if f_stat > 0 else 1
        
        # AIC y BIC
        log_likelihood = -n/2 * (1 + np.log(2 * np.pi) + np.log(ss_res / n))
        aic = -2 * log_likelihood + 2 * k
        bic = -2 * log_likelihood + k * np.log(n)
        
        # Durbin-Watson
        dw = np.sum(np.diff(residuals)**2) / ss_res if ss_res > 0 else 0
        
        # Jarque-Bera
        skew = stats.skew(residuals)
        kurt = stats.kurtosis(residuals)
        jb = n/6 * (skew**2 + (kurt**2)/4)
        jb_pvalue = 1 - stats.chi2.cdf(jb, 2)
        
        # VIF (Variance Inflation Factor)
        vif_scores = self._calculate_vif(X[:, 1:], var_names)  # Sin constante
        multicollinearity = any(v > self.vif_threshold for v in vif_scores.values())
        
        # Moran's I (si hay matriz de pesos)
        morans_i, morans_pvalue, spatial_autocorr = None, None, None
        if weights_matrix is not None:
            morans_i, morans_pvalue = self._calculate_morans_i(residuals, weights_matrix)
            if morans_pvalue < self.alpha:
                spatial_autocorr = "positive" if morans_i > 0 else "negative"
        
        return HedonicDiagnostics(
            r_squared=float(r_squared),
            adj_r_squared=float(adj_r_squared),
            f_statistic=float(f_stat),
            f_pvalue=float(f_pvalue),
            aic=float(aic),
            bic=float(bic),
            durbin_watson=float(dw),
            jarque_bera=float(jb),
            jarque_bera_pvalue=float(jb_pvalue),
            vif_scores=vif_scores,
            multicollinearity_warning=multicollinearity,
            morans_i=morans_i,
            morans_i_pvalue=morans_pvalue,
            spatial_autocorrelation=spatial_autocorr
        )
    
    def _calculate_vif(self, X: np.ndarray, var_names: List[str]) -> Dict[str, float]:
        """Calcula VIF para cada variable."""
        vif_scores = {}
        n_vars = X.shape[1]
        
        for i, var in enumerate(var_names):
            if n_vars <= 1:
                vif_scores[var] = 1.0
                continue
            
            # Regresión de x_i sobre las demás variables
            y_i = X[:, i]
            X_others = np.delete(X, i, axis=1)
            X_others = np.column_stack([np.ones(len(y_i)), X_others])
            
            try:
                coef = np.linalg.lstsq(X_others, y_i, rcond=None)[0]
                fitted = X_others @ coef
                ss_res = np.sum((y_i - fitted)**2)
                ss_tot = np.sum((y_i - np.mean(y_i))**2)
                r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0
                vif = 1 / (1 - r2) if r2 < 1 else float('inf')
            except:
                vif = float('inf')
            
            vif_scores[var] = float(vif)
        
        return vif_scores
    
    def _calculate_morans_i(
        self, residuals: np.ndarray, W: np.ndarray
    ) -> Tuple[float, float]:
        """Calcula el estadístico I de Moran para autocorrelación espacial."""
        n = len(residuals)
        z = residuals - np.mean(residuals)
        
        # I de Moran
        numerator = n * (z @ W @ z)
        denominator = np.sum(W) * np.sum(z**2)
        
        if denominator == 0:
            return 0.0, 1.0
        
        I = numerator / denominator
        
        # Esperanza y varianza bajo H0
        E_I = -1 / (n - 1)
        
        # Varianza simplificada (normalidad)
        S0 = np.sum(W)
        S1 = 0.5 * np.sum((W + W.T)**2)
        S2 = np.sum((np.sum(W, axis=0) + np.sum(W, axis=1))**2)
        
        var_I = (n * ((n**2 - 3*n + 3)*S1 - n*S2 + 3*S0**2) - 
                 (n - 1)*(S1 - 2*n*S2 + 6*S0**2)) / ((n - 1)*(n - 2)*(n - 3)*S0**2)
        var_I = max(var_I - E_I**2, 1e-10)
        
        # Z-score y p-value
        z_score = (I - E_I) / np.sqrt(var_I)
        p_value = 2 * (1 - stats.norm.cdf(abs(z_score)))
        
        return float(I), float(p_value)
    
    def _sensitivity_analysis(
        self, data: pd.DataFrame, dep_var: str,
        indep_vars: List[str], model_type: ModelType
    ) -> Dict[str, Any]:
        """Análisis de sensibilidad del modelo."""
        sensitivities = {}
        
        # Elasticidades promedio
        y = data[dep_var].values
        mean_price = np.mean(y)
        
        for var in indep_vars:
            x = data[var].values
            mean_x = np.mean(x)
            std_x = np.std(x)
            
            # Impacto de 1 desviación estándar
            sensitivities[var] = {
                "mean": float(mean_x),
                "std": float(std_x),
                "coefficient_of_variation": float(std_x / mean_x) if mean_x != 0 else 0,
            }
        
        return sensitivities
    
    def compare_models(
        self, data: pd.DataFrame, dep_var: str, indep_vars: List[str]
    ) -> Dict[str, HedonicResult]:
        """Compara múltiples especificaciones de modelo."""
        results = {}
        
        for model_type in [ModelType.OLS_LINEAR, ModelType.LOG_LINEAR, ModelType.LOG_LOG]:
            try:
                result = self.estimate(data, dep_var, indep_vars, model_type)
                results[model_type.value] = result
            except Exception as e:
                warnings.warn(f"Could not estimate {model_type.value}: {str(e)}")
        
        # Intentar Box-Cox si los datos son positivos
        if (data[dep_var] > 0).all():
            try:
                result = self.estimate(data, dep_var, indep_vars, ModelType.BOX_COX)
                results[ModelType.BOX_COX.value] = result
            except Exception as e:
                warnings.warn(f"Could not estimate Box-Cox: {str(e)}")
        
        return results
    
    def select_best_model(self, comparison_results: Dict[str, HedonicResult]) -> str:
        """Selecciona el mejor modelo basado en AIC."""
        best_model = None
        best_aic = float('inf')
        
        for model_name, result in comparison_results.items():
            if result.diagnostics and result.diagnostics.aic < best_aic:
                best_aic = result.diagnostics.aic
                best_model = model_name
        
        return best_model
    
    def predict(
        self, result: HedonicResult, new_data: pd.DataFrame
    ) -> np.ndarray:
        """Predice precios usando el modelo estimado."""
        coef_dict = {c.variable: c.coefficient for c in result.coefficients}
        
        # Construir predicción
        predictions = np.full(len(new_data), coef_dict.get('const', 0))
        
        for var, coef in coef_dict.items():
            if var != 'const' and var in new_data.columns:
                x = new_data[var].values
                
                if result.model_type == ModelType.LOG_LOG:
                    x = np.log(x) if (x > 0).all() else x
                
                predictions += coef * x
        
        # Transformación inversa
        if result.model_type in [ModelType.LOG_LINEAR, ModelType.LOG_LOG]:
            predictions = np.exp(predictions)
        elif result.model_type == ModelType.BOX_COX and result.box_cox_lambda:
            lmbda = result.box_cox_lambda
            if abs(lmbda) < 1e-10:
                predictions = np.exp(predictions)
            else:
                predictions = (lmbda * predictions + 1) ** (1 / lmbda)
        
        return predictions


# Singleton instance
hedonic_service = HedonicPricingService()
