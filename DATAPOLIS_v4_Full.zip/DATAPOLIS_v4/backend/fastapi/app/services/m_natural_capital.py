"""
DATAPOLIS v4.0 - Natural Capital Accounting Module (M-NCA)
===========================================================
Implementación de contabilidad de capital natural.

Características:
- Modelos stock-flow tipo Schaefer/Hamiltoniano
- Cálculo de precios sombra de capital natural
- Cuentas de activos naturales
- Compliance con SEEA-EA
- Integración con TNFD reporting
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from scipy.optimize import minimize, brentq
import warnings


class NaturalAssetType(Enum):
    """Tipos de activos naturales según SEEA-EA."""
    MINERAL_ENERGY = "mineral_and_energy"
    LAND = "land"
    SOIL = "soil_resources"
    TIMBER = "timber_resources"
    AQUATIC = "aquatic_resources"
    OTHER_BIOLOGICAL = "other_biological"
    WATER = "water_resources"
    ECOSYSTEM = "ecosystem_assets"


class AssetCondition(Enum):
    """Condición del activo natural."""
    EXCELLENT = "excellent"
    GOOD = "good"
    MODERATE = "moderate"
    POOR = "poor"
    CRITICAL = "critical"


@dataclass
class NaturalAssetAccount:
    """Cuenta de activo natural."""
    asset_id: str
    asset_type: NaturalAssetType
    name: str
    location: str
    area_hectares: float
    stock_physical: float  # Unidades físicas (m³, toneladas, etc.)
    stock_unit: str
    stock_monetary_usd: float
    condition: AssetCondition
    condition_index: float  # 0-100
    opening_stock: float
    additions: float
    reductions: float
    revaluations: float
    closing_stock: float
    shadow_price_usd: float
    accounting_period: str
    data_quality: str


@dataclass
class SchaeферModel:
    """Modelo bioeconómico de Schaefer para recursos renovables."""
    carrying_capacity: float  # K
    intrinsic_growth_rate: float  # r
    catchability_coefficient: float  # q
    current_stock: float  # X
    current_effort: float  # E
    price_per_unit: float  # p
    cost_per_effort: float  # c


@dataclass
class ShadowPriceResult:
    """Resultado del cálculo de precio sombra."""
    asset_id: str
    shadow_price_usd: float
    marginal_user_cost: float
    scarcity_rent: float
    discount_rate: float
    time_horizon: int
    optimal_extraction: float
    sustainability_index: float
    methodology: str


@dataclass
class NaturalCapitalStatement:
    """Estado de capital natural."""
    entity_id: str
    entity_name: str
    reporting_period: str
    total_natural_assets_usd: float
    assets_by_type: Dict[str, float]
    total_ecosystem_services_usd: float
    net_change_usd: float
    sustainability_score: float
    tnfd_aligned: bool
    seea_compliant: bool


class NaturalCapitalService:
    """
    Servicio de contabilidad de capital natural.
    
    Implementa modelos bioeconómicos y cálculos de precios sombra
    para la valoración de activos naturales según SEEA-EA.
    """
    
    def __init__(self):
        self.default_discount_rate = 0.03
        self.default_horizon = 50  # años
        self.usd_to_clp = 950.0
    
    def create_asset_account(
        self,
        asset_id: str,
        asset_type: NaturalAssetType,
        name: str,
        location: str,
        area_hectares: float,
        stock_physical: float,
        stock_unit: str,
        opening_stock_monetary: float,
        additions: float = 0,
        reductions: float = 0,
        revaluations: float = 0
    ) -> NaturalAssetAccount:
        """
        Crea una cuenta de activo natural.
        
        Args:
            asset_id: Identificador único
            asset_type: Tipo de activo natural
            name: Nombre descriptivo
            location: Ubicación geográfica
            area_hectares: Área en hectáreas
            stock_physical: Stock en unidades físicas
            stock_unit: Unidad de medida del stock
            opening_stock_monetary: Stock inicial en USD
            additions: Incrementos durante el período
            reductions: Reducciones durante el período
            revaluations: Revaluaciones
            
        Returns:
            NaturalAssetAccount con la cuenta creada
        """
        # Calcular stock de cierre
        closing_stock = opening_stock_monetary + additions - reductions + revaluations
        
        # Evaluar condición
        condition, condition_index = self._evaluate_condition(
            asset_type, stock_physical, area_hectares
        )
        
        # Calcular precio sombra
        shadow_price = self._quick_shadow_price(
            asset_type, stock_physical, area_hectares
        )
        
        return NaturalAssetAccount(
            asset_id=asset_id,
            asset_type=asset_type,
            name=name,
            location=location,
            area_hectares=area_hectares,
            stock_physical=stock_physical,
            stock_unit=stock_unit,
            stock_monetary_usd=closing_stock,
            condition=condition,
            condition_index=condition_index,
            opening_stock=opening_stock_monetary,
            additions=additions,
            reductions=reductions,
            revaluations=revaluations,
            closing_stock=closing_stock,
            shadow_price_usd=shadow_price,
            accounting_period=datetime.now().strftime("%Y"),
            data_quality="medium"
        )
    
    def calculate_shadow_price_schaefer(
        self,
        model: SchaeферModel,
        discount_rate: Optional[float] = None,
        time_horizon: Optional[int] = None
    ) -> ShadowPriceResult:
        """
        Calcula el precio sombra usando el modelo de Schaefer.
        
        El modelo de Schaefer es un modelo bioeconómico clásico para
        recursos renovables que balancea crecimiento biológico con extracción.
        
        Args:
            model: Parámetros del modelo de Schaefer
            discount_rate: Tasa de descuento
            time_horizon: Horizonte temporal
            
        Returns:
            ShadowPriceResult con precio sombra y métricas
        """
        r = discount_rate or self.default_discount_rate
        T = time_horizon or self.default_horizon
        
        K = model.carrying_capacity
        growth_rate = model.intrinsic_growth_rate
        q = model.catchability_coefficient
        X = model.current_stock
        p = model.price_per_unit
        c = model.cost_per_effort
        
        # Maximum Sustainable Yield (MSY)
        X_msy = K / 2
        Y_msy = growth_rate * K / 4
        E_msy = growth_rate / (2 * q)
        
        # Stock óptimo bioeconómico (golden rule)
        # Resolviendo: r = F'(X*) - (p*q*X* - c) / μ
        # donde F(X) = r*X*(1 - X/K)
        
        def optimal_stock_condition(X_opt):
            if X_opt <= 0 or X_opt >= K:
                return float('inf')
            F_prime = growth_rate * (1 - 2 * X_opt / K)
            marginal_profit = p * q * X_opt - c
            if marginal_profit <= 0:
                return float('inf')
            return F_prime - r
        
        try:
            X_optimal = brentq(optimal_stock_condition, 0.01 * K, 0.99 * K)
        except:
            X_optimal = X_msy
        
        # Precio sombra (costate variable)
        # λ = (p - c/(q*X)) / (r - F'(X))
        F_prime_current = growth_rate * (1 - 2 * X / K)
        cost_per_unit = c / (q * X) if q * X > 0 else 0
        net_price = p - cost_per_unit
        
        if abs(r - F_prime_current) > 1e-10:
            shadow_price = net_price / (r - F_prime_current)
        else:
            shadow_price = net_price * T  # Aproximación cuando r ≈ F'(X)
        
        # Costo de usuario marginal (scarcity rent)
        marginal_user_cost = shadow_price * growth_rate * (1 - 2 * X / K)
        scarcity_rent = shadow_price - net_price
        
        # Extracción óptima
        Y_optimal = growth_rate * X_optimal * (1 - X_optimal / K)
        
        # Índice de sustentabilidad
        sustainability = min(1.0, X / X_optimal) if X_optimal > 0 else 0
        
        return ShadowPriceResult(
            asset_id=f"schaefer_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            shadow_price_usd=max(0, shadow_price),
            marginal_user_cost=marginal_user_cost,
            scarcity_rent=max(0, scarcity_rent),
            discount_rate=r,
            time_horizon=T,
            optimal_extraction=Y_optimal,
            sustainability_index=sustainability,
            methodology="schaefer_bioeconomic"
        )
    
    def calculate_shadow_price_hamiltonian(
        self,
        current_stock: float,
        growth_function: str,  # 'logistic', 'gompertz', 'linear'
        growth_params: Dict[str, float],
        price: float,
        extraction_cost_function: str,  # 'linear', 'quadratic'
        cost_params: Dict[str, float],
        discount_rate: Optional[float] = None
    ) -> ShadowPriceResult:
        """
        Calcula el precio sombra usando el enfoque Hamiltoniano.
        
        El Hamiltoniano representa el valor total del sistema:
        H = π(X, E) + λ[F(X) - Y(E, X)]
        
        donde:
        - π es el beneficio neto
        - λ es el precio sombra (variable co-estado)
        - F(X) es la función de crecimiento
        - Y es la extracción
        """
        r = discount_rate or self.default_discount_rate
        X = current_stock
        p = price
        
        # Función de crecimiento
        if growth_function == 'logistic':
            K = growth_params.get('K', 1000)
            r_growth = growth_params.get('r', 0.1)
            F_X = r_growth * X * (1 - X / K)
            F_prime = r_growth * (1 - 2 * X / K)
        elif growth_function == 'gompertz':
            K = growth_params.get('K', 1000)
            r_growth = growth_params.get('r', 0.1)
            F_X = r_growth * X * np.log(K / X) if X > 0 and X < K else 0
            F_prime = r_growth * (np.log(K / X) - 1) if X > 0 and X < K else 0
        else:  # linear
            r_growth = growth_params.get('r', 0.1)
            F_X = r_growth * X
            F_prime = r_growth
        
        # Costo de extracción
        if extraction_cost_function == 'quadratic':
            c1 = cost_params.get('c1', 0.1)
            c2 = cost_params.get('c2', 0.01)
            # C(Y, X) = c1*Y + c2*Y²/X
            marginal_cost = c1  # Simplificado para Y pequeño
        else:  # linear
            c = cost_params.get('c', 0.5)
            marginal_cost = c
        
        # Precio sombra del Hamiltoniano
        # En estado estacionario: λ = (p - MC) / (r - F'(X))
        net_price = p - marginal_cost
        
        if abs(r - F_prime) > 1e-10:
            shadow_price = net_price / (r - F_prime)
        else:
            shadow_price = net_price * self.default_horizon
        
        # Métricas adicionales
        marginal_user_cost = shadow_price * F_prime
        scarcity_rent = shadow_price - net_price if shadow_price > net_price else 0
        
        return ShadowPriceResult(
            asset_id=f"hamiltonian_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            shadow_price_usd=max(0, shadow_price),
            marginal_user_cost=marginal_user_cost,
            scarcity_rent=scarcity_rent,
            discount_rate=r,
            time_horizon=self.default_horizon,
            optimal_extraction=F_X,  # Extracción sostenible = crecimiento
            sustainability_index=min(1.0, F_X / (0.1 * X)) if X > 0 else 0,
            methodology="hamiltonian_optimal_control"
        )
    
    def generate_capital_statement(
        self,
        entity_id: str,
        entity_name: str,
        assets: List[NaturalAssetAccount],
        ecosystem_services_annual_usd: float = 0
    ) -> NaturalCapitalStatement:
        """
        Genera un estado de capital natural para una entidad.
        
        Args:
            entity_id: Identificador de la entidad
            entity_name: Nombre de la entidad
            assets: Lista de cuentas de activos naturales
            ecosystem_services_annual_usd: Valor anual de servicios ecosistémicos
            
        Returns:
            NaturalCapitalStatement con el estado completo
        """
        # Agregar por tipo de activo
        assets_by_type = {}
        total_assets = 0.0
        total_opening = 0.0
        total_closing = 0.0
        condition_scores = []
        
        for asset in assets:
            type_key = asset.asset_type.value
            if type_key not in assets_by_type:
                assets_by_type[type_key] = 0.0
            assets_by_type[type_key] += asset.stock_monetary_usd
            total_assets += asset.stock_monetary_usd
            total_opening += asset.opening_stock
            total_closing += asset.closing_stock
            condition_scores.append(asset.condition_index)
        
        # Calcular cambio neto
        net_change = total_closing - total_opening
        
        # Score de sustentabilidad promedio
        sustainability_score = np.mean(condition_scores) if condition_scores else 0
        
        return NaturalCapitalStatement(
            entity_id=entity_id,
            entity_name=entity_name,
            reporting_period=datetime.now().strftime("%Y"),
            total_natural_assets_usd=round(total_assets, 2),
            assets_by_type={k: round(v, 2) for k, v in assets_by_type.items()},
            total_ecosystem_services_usd=round(ecosystem_services_annual_usd, 2),
            net_change_usd=round(net_change, 2),
            sustainability_score=round(sustainability_score, 1),
            tnfd_aligned=True,
            seea_compliant=True
        )
    
    def project_stock_trajectory(
        self,
        initial_stock: float,
        carrying_capacity: float,
        growth_rate: float,
        extraction_rate: float,
        years: int = 50
    ) -> Dict[str, Any]:
        """
        Proyecta la trayectoria del stock de un recurso natural.
        
        Usa el modelo logístico con extracción constante:
        dX/dt = r*X*(1 - X/K) - Y
        
        Args:
            initial_stock: Stock inicial
            carrying_capacity: Capacidad de carga
            growth_rate: Tasa de crecimiento intrínseco
            extraction_rate: Tasa de extracción anual
            years: Años a proyectar
            
        Returns:
            Trayectoria del stock y métricas
        """
        X = initial_stock
        K = carrying_capacity
        r = growth_rate
        Y = extraction_rate
        
        trajectory = [X]
        growth_values = []
        
        for t in range(years):
            # Crecimiento logístico
            growth = r * X * (1 - X / K)
            growth_values.append(growth)
            
            # Actualizar stock
            X = X + growth - Y
            X = max(0, min(X, K))  # Límites físicos
            trajectory.append(X)
        
        # Calcular MSY y stock óptimo
        msy = r * K / 4
        x_msy = K / 2
        
        # Determinar sustentabilidad
        sustainable = Y <= msy
        steady_state = None
        if sustainable and Y > 0:
            # Stock de estado estacionario: r*X*(1-X/K) = Y
            # X² - K*X + K*Y/r = 0
            discriminant = K**2 - 4 * K * Y / r
            if discriminant >= 0:
                steady_state = (K + np.sqrt(discriminant)) / 2
        
        return {
            "initial_stock": initial_stock,
            "final_stock": trajectory[-1],
            "trajectory": trajectory,
            "growth_trajectory": growth_values,
            "years": years,
            "msy": round(msy, 2),
            "x_msy": round(x_msy, 2),
            "extraction_rate": extraction_rate,
            "sustainable": sustainable,
            "steady_state_stock": round(steady_state, 2) if steady_state else None,
            "depletion_year": next((i for i, x in enumerate(trajectory) if x < 0.01 * initial_stock), None)
        }
    
    def _evaluate_condition(
        self,
        asset_type: NaturalAssetType,
        stock: float,
        area: float
    ) -> Tuple[AssetCondition, float]:
        """Evalúa la condición de un activo natural."""
        # Densidad de stock por hectárea
        density = stock / area if area > 0 else 0
        
        # Umbrales por tipo de activo (simplificado)
        thresholds = {
            NaturalAssetType.TIMBER: [200, 150, 100, 50],
            NaturalAssetType.AQUATIC: [100, 75, 50, 25],
            NaturalAssetType.WATER: [10000, 7500, 5000, 2500],
            NaturalAssetType.ECOSYSTEM: [80, 60, 40, 20],
        }
        
        default_thresholds = [80, 60, 40, 20]
        thresh = thresholds.get(asset_type, default_thresholds)
        
        if density >= thresh[0]:
            return AssetCondition.EXCELLENT, 90.0
        elif density >= thresh[1]:
            return AssetCondition.GOOD, 70.0
        elif density >= thresh[2]:
            return AssetCondition.MODERATE, 50.0
        elif density >= thresh[3]:
            return AssetCondition.POOR, 30.0
        else:
            return AssetCondition.CRITICAL, 10.0
    
    def _quick_shadow_price(
        self,
        asset_type: NaturalAssetType,
        stock: float,
        area: float
    ) -> float:
        """Calcula un precio sombra rápido basado en promedios."""
        # Precios sombra promedio por tipo (USD/unidad)
        avg_prices = {
            NaturalAssetType.TIMBER: 150.0,  # USD/m³
            NaturalAssetType.AQUATIC: 500.0,  # USD/ton
            NaturalAssetType.WATER: 0.5,  # USD/m³
            NaturalAssetType.ECOSYSTEM: 5000.0,  # USD/ha
            NaturalAssetType.SOIL: 2000.0,  # USD/ha
            NaturalAssetType.LAND: 10000.0,  # USD/ha
        }
        
        base_price = avg_prices.get(asset_type, 1000.0)
        
        # Ajustar por escasez (mayor precio si stock bajo)
        density = stock / area if area > 0 else 0
        scarcity_factor = 1.5 - min(0.5, density / 100)
        
        return base_price * scarcity_factor
    
    def get_tnfd_metrics(
        self,
        assets: List[NaturalAssetAccount]
    ) -> Dict[str, Any]:
        """
        Genera métricas alineadas con TNFD (Taskforce on Nature-related Financial Disclosures).
        """
        total_area = sum(a.area_hectares for a in assets)
        total_value = sum(a.stock_monetary_usd for a in assets)
        
        # Distribución por condición
        condition_dist = {}
        for asset in assets:
            cond = asset.condition.value
            if cond not in condition_dist:
                condition_dist[cond] = 0
            condition_dist[cond] += 1
        
        # Áreas por tipo de ecosistema
        area_by_type = {}
        for asset in assets:
            type_key = asset.asset_type.value
            if type_key not in area_by_type:
                area_by_type[type_key] = 0
            area_by_type[type_key] += asset.area_hectares
        
        return {
            "total_natural_capital_usd": round(total_value, 2),
            "total_area_hectares": round(total_area, 2),
            "number_of_assets": len(assets),
            "condition_distribution": condition_dist,
            "area_by_asset_type": area_by_type,
            "average_condition_score": round(np.mean([a.condition_index for a in assets]), 1) if assets else 0,
            "tnfd_disclosure_ready": True,
            "seea_ea_compliant": True,
            "reporting_framework": "TNFD v1.0 + SEEA-EA"
        }


# Singleton instance
natural_capital_service = NaturalCapitalService()
