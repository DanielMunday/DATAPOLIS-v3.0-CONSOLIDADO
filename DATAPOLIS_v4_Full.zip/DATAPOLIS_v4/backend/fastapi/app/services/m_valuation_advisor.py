"""
DATAPOLIS v4.0 - Valuation Method Advisor Module (M-VAD)
=========================================================
Asistente inteligente para selección de métodos de valuación.

Características:
- Análisis de contexto del activo y propósito
- Recomendación de métodos óptimos
- Justificación basada en estándares (IVS, RICS, Basel)
- Integración con módulos de valorización existentes
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class AssetType(Enum):
    """Tipos de activos para valuación."""
    RESIDENTIAL_PROPERTY = "residential_property"
    COMMERCIAL_PROPERTY = "commercial_property"
    INDUSTRIAL_PROPERTY = "industrial_property"
    LAND = "land"
    AGRICULTURAL = "agricultural"
    SPECIAL_USE = "special_use"
    DEVELOPMENT_SITE = "development_site"
    NATURAL_ASSET = "natural_asset"
    ECOSYSTEM = "ecosystem"
    WATER_RIGHTS = "water_rights"
    MINING_RIGHTS = "mining_rights"
    PORTFOLIO = "portfolio"


class ValuationPurpose(Enum):
    """Propósito de la valuación."""
    MARKET_TRANSACTION = "market_transaction"
    COLLATERAL = "collateral"
    FINANCIAL_REPORTING = "financial_reporting"
    TAX_ASSESSMENT = "tax_assessment"
    EXPROPRIATION = "expropriation"
    LITIGATION = "litigation"
    INSURANCE = "insurance"
    INVESTMENT_ANALYSIS = "investment_analysis"
    ESG_REPORTING = "esg_reporting"
    REGULATORY = "regulatory"
    INTERNAL_DECISION = "internal_decision"


class ValuationMethod(Enum):
    """Métodos de valuación disponibles."""
    # Traditional
    MARKET_COMPARISON = "market_comparison"
    INCOME_CAPITALIZATION = "income_capitalization"
    DCF = "discounted_cash_flow"
    COST_APPROACH = "cost_approach"
    RESIDUAL = "residual"
    PROFITS = "profits_method"
    
    # Advanced
    HEDONIC_PRICING = "hedonic_pricing"
    ML_ENSEMBLE = "ml_ensemble"
    SPATIAL_REGRESSION = "spatial_regression"
    
    # ESG/Natural Capital
    ECOSYSTEM_SERVICES = "ecosystem_services"
    NATURAL_CAPITAL_ACCOUNTING = "natural_capital_accounting"
    CONTINGENT_VALUATION = "contingent_valuation"
    TRAVEL_COST = "travel_cost"
    REPLACEMENT_COST = "replacement_cost"
    
    # Hybrid
    HYBRID_ML_TRADITIONAL = "hybrid_ml_traditional"
    MULTI_CRITERIA = "multi_criteria"


class DataQuality(Enum):
    """Calidad de datos disponibles."""
    EXCELLENT = "excellent"
    GOOD = "good"
    MODERATE = "moderate"
    LIMITED = "limited"
    POOR = "poor"


class TimeHorizon(Enum):
    """Horizonte temporal de la valuación."""
    SPOT = "spot"  # Valor actual
    SHORT_TERM = "short_term"  # < 1 año
    MEDIUM_TERM = "medium_term"  # 1-5 años
    LONG_TERM = "long_term"  # 5-30 años
    PERPETUITY = "perpetuity"  # Indefinido


@dataclass
class ValuationContext:
    """Contexto completo para la recomendación de valuación."""
    asset_type: AssetType
    purpose: ValuationPurpose
    time_horizon: TimeHorizon
    data_quality: DataQuality
    market_activity: str  # active, moderate, limited, none
    income_producing: bool
    comparable_availability: int  # 0-100
    regulatory_requirement: Optional[str] = None
    special_considerations: List[str] = field(default_factory=list)
    budget_constraint: Optional[str] = None  # low, medium, high
    time_constraint: Optional[str] = None  # urgent, normal, flexible


@dataclass
class MethodRecommendation:
    """Recomendación de método de valuación."""
    method: ValuationMethod
    suitability_score: float  # 0-100
    primary: bool
    rationale: str
    strengths: List[str]
    limitations: List[str]
    data_requirements: List[str]
    estimated_accuracy: str
    ivs_aligned: bool
    rics_compliant: bool
    basel_compliant: bool
    implementation_complexity: str  # low, medium, high
    datapolis_module: str  # Módulo de DATAPOLIS que lo implementa


@dataclass
class ValuationAdvisorResult:
    """Resultado del asistente de valuación."""
    request_id: str
    context: ValuationContext
    primary_recommendation: MethodRecommendation
    alternative_recommendations: List[MethodRecommendation]
    hybrid_approach: Optional[Dict[str, Any]]
    reconciliation_guidance: str
    key_assumptions: List[str]
    risk_factors: List[str]
    quality_considerations: str
    regulatory_notes: str
    timestamp: str


# Base de conocimiento de métodos de valuación
METHOD_KNOWLEDGE_BASE: Dict[ValuationMethod, Dict[str, Any]] = {
    ValuationMethod.MARKET_COMPARISON: {
        "description": "Comparación directa con transacciones de mercado similares",
        "strengths": [
            "Refleja directamente las condiciones del mercado",
            "Fácil de entender y explicar",
            "Aceptado universalmente por tribunales y reguladores"
        ],
        "limitations": [
            "Requiere mercado activo con comparables",
            "Sensible a ajustes subjetivos",
            "Difícil en activos únicos o especializados"
        ],
        "data_requirements": [
            "Mínimo 3-5 transacciones comparables",
            "Datos de características físicas",
            "Fechas de transacción recientes"
        ],
        "best_for": ["residential_property", "commercial_property", "land"],
        "ivs_aligned": True,
        "rics_compliant": True,
        "basel_compliant": True,
        "complexity": "low",
        "datapolis_module": "M04 Valorización"
    },
    ValuationMethod.INCOME_CAPITALIZATION: {
        "description": "Capitalización de ingresos netos a perpetuidad",
        "strengths": [
            "Refleja el valor de inversión",
            "Apropiado para activos productivos",
            "Base teórica sólida"
        ],
        "limitations": [
            "Sensible a la tasa de capitalización",
            "Asume estabilidad de ingresos",
            "Requiere datos de mercado de rentas"
        ],
        "data_requirements": [
            "Ingresos operacionales actuales",
            "Gastos operacionales",
            "Tasas de capitalización de mercado"
        ],
        "best_for": ["commercial_property", "industrial_property"],
        "ivs_aligned": True,
        "rics_compliant": True,
        "basel_compliant": True,
        "complexity": "medium",
        "datapolis_module": "M04 Valorización + M07 Inversión"
    },
    ValuationMethod.DCF: {
        "description": "Valor presente de flujos de caja proyectados",
        "strengths": [
            "Captura variaciones en flujos",
            "Permite análisis de escenarios",
            "Apropiado para proyectos de desarrollo"
        ],
        "limitations": [
            "Altamente sensible a supuestos",
            "Requiere proyecciones confiables",
            "Complejidad en la tasa de descuento"
        ],
        "data_requirements": [
            "Proyecciones de ingresos y gastos",
            "Tasa de descuento apropiada",
            "Valor terminal o de salida"
        ],
        "best_for": ["development_site", "investment_analysis"],
        "ivs_aligned": True,
        "rics_compliant": True,
        "basel_compliant": True,
        "complexity": "high",
        "datapolis_module": "M07 Inversión + RR Rentabilidad"
    },
    ValuationMethod.HEDONIC_PRICING: {
        "description": "Descomposición del precio en atributos mediante regresión",
        "strengths": [
            "Cuantifica valor de atributos individuales",
            "Base empírica robusta",
            "Identifica drivers de valor"
        ],
        "limitations": [
            "Requiere datos extensos",
            "Sensible a especificación del modelo",
            "Puede sufrir de multicolinealidad"
        ],
        "data_requirements": [
            "Base de datos amplia de transacciones",
            "Características detalladas",
            "Variables ambientales y locacionales"
        ],
        "best_for": ["residential_property", "land", "ecosystem"],
        "ivs_aligned": True,
        "rics_compliant": True,
        "basel_compliant": True,
        "complexity": "high",
        "datapolis_module": "M-HED Hedonic Pricing (v4.0)"
    },
    ValuationMethod.ML_ENSEMBLE: {
        "description": "Ensemble de modelos de machine learning",
        "strengths": [
            "Alta precisión predictiva",
            "Captura relaciones no lineales",
            "Escalable a grandes datasets"
        ],
        "limitations": [
            "Caja negra difícil de explicar",
            "Requiere datos de entrenamiento",
            "Puede sobreajustar"
        ],
        "data_requirements": [
            "Dataset amplio de entrenamiento",
            "Features estructuradas",
            "Datos de validación"
        ],
        "best_for": ["residential_property", "portfolio"],
        "ivs_aligned": False,
        "rics_compliant": False,
        "basel_compliant": True,
        "complexity": "high",
        "datapolis_module": "M04 Valorización ML"
    },
    ValuationMethod.ECOSYSTEM_SERVICES: {
        "description": "Valoración de servicios ecosistémicos mediante value transfer",
        "strengths": [
            "Captura valor no mercantil",
            "Alineado con ESG/TNFD",
            "Metodología estandarizada"
        ],
        "limitations": [
            "Basado en transferencia de valores",
            "Incertidumbre en parámetros",
            "No refleja mercado directo"
        ],
        "data_requirements": [
            "Tipo de ecosistema/bioma",
            "Área en hectáreas",
            "Condición ecológica"
        ],
        "best_for": ["ecosystem", "natural_asset", "agricultural"],
        "ivs_aligned": False,
        "rics_compliant": False,
        "basel_compliant": False,
        "complexity": "medium",
        "datapolis_module": "M-ESV Ecosystem Services (v4.0)"
    },
    ValuationMethod.NATURAL_CAPITAL_ACCOUNTING: {
        "description": "Contabilidad de capital natural con precios sombra",
        "strengths": [
            "Framework SEEA-EA compliant",
            "Integra stock y flujos",
            "Base para reporting ESG"
        ],
        "limitations": [
            "Requiere datos especializados",
            "Metodología en evolución",
            "No aceptado para fines crediticios"
        ],
        "data_requirements": [
            "Inventario de activos naturales",
            "Parámetros bioeconómicos",
            "Series temporales de stock"
        ],
        "best_for": ["natural_asset", "ecosystem", "water_rights"],
        "ivs_aligned": False,
        "rics_compliant": False,
        "basel_compliant": False,
        "complexity": "high",
        "datapolis_module": "M-NCA Natural Capital (v4.0)"
    },
    ValuationMethod.COST_APPROACH: {
        "description": "Costo de reposición depreciado",
        "strengths": [
            "Aplicable a activos especializados",
            "No depende del mercado",
            "Verificable con costos reales"
        ],
        "limitations": [
            "No refleja valor de mercado",
            "Difícil estimar depreciación",
            "No captura valor de ubicación"
        ],
        "data_requirements": [
            "Costos de construcción",
            "Vida útil y depreciación",
            "Valor del terreno separado"
        ],
        "best_for": ["special_use", "industrial_property"],
        "ivs_aligned": True,
        "rics_compliant": True,
        "basel_compliant": True,
        "complexity": "medium",
        "datapolis_module": "M04 Valorización"
    },
}


class ValuationAdvisorService:
    """
    Servicio de asesoría para selección de métodos de valuación.
    
    Analiza el contexto del activo y propósito para recomendar
    los métodos de valuación más apropiados.
    """
    
    def __init__(self):
        self.knowledge_base = METHOD_KNOWLEDGE_BASE
    
    def get_recommendation(
        self,
        context: ValuationContext
    ) -> ValuationAdvisorResult:
        """
        Genera recomendación de métodos de valuación.
        
        Args:
            context: Contexto completo de la valuación
            
        Returns:
            ValuationAdvisorResult con recomendaciones
        """
        # Evaluar todos los métodos
        scored_methods = []
        for method in ValuationMethod:
            score = self._score_method(method, context)
            if score > 0:
                scored_methods.append((method, score))
        
        # Ordenar por score
        scored_methods.sort(key=lambda x: x[1], reverse=True)
        
        # Construir recomendaciones
        recommendations = []
        for method, score in scored_methods[:5]:  # Top 5
            rec = self._build_recommendation(method, score, context)
            recommendations.append(rec)
        
        # Primary y alternatives
        primary = recommendations[0] if recommendations else None
        alternatives = recommendations[1:4] if len(recommendations) > 1 else []
        
        # Hybrid approach si es apropiado
        hybrid = self._suggest_hybrid_approach(recommendations, context)
        
        # Guidance adicional
        reconciliation = self._get_reconciliation_guidance(recommendations, context)
        assumptions = self._identify_assumptions(context)
        risks = self._identify_risks(context)
        quality_notes = self._get_quality_considerations(context)
        regulatory = self._get_regulatory_notes(context)
        
        return ValuationAdvisorResult(
            request_id=f"VAD_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            context=context,
            primary_recommendation=primary,
            alternative_recommendations=alternatives,
            hybrid_approach=hybrid,
            reconciliation_guidance=reconciliation,
            key_assumptions=assumptions,
            risk_factors=risks,
            quality_considerations=quality_notes,
            regulatory_notes=regulatory,
            timestamp=datetime.now().isoformat()
        )
    
    def _score_method(
        self, method: ValuationMethod, context: ValuationContext
    ) -> float:
        """Calcula score de idoneidad de un método para el contexto."""
        if method not in self.knowledge_base:
            return 0.0
        
        kb = self.knowledge_base[method]
        score = 50.0  # Base score
        
        # Ajuste por tipo de activo
        if context.asset_type.value in kb.get("best_for", []):
            score += 25
        
        # Ajuste por propósito
        if context.purpose in [ValuationPurpose.COLLATERAL, ValuationPurpose.REGULATORY]:
            if kb.get("basel_compliant"):
                score += 15
            else:
                score -= 20
        
        if context.purpose == ValuationPurpose.ESG_REPORTING:
            if method in [ValuationMethod.ECOSYSTEM_SERVICES, ValuationMethod.NATURAL_CAPITAL_ACCOUNTING]:
                score += 30
        
        # Ajuste por calidad de datos
        if context.data_quality == DataQuality.POOR:
            if kb.get("complexity") == "high":
                score -= 20
        elif context.data_quality == DataQuality.EXCELLENT:
            if kb.get("complexity") == "high":
                score += 10
        
        # Ajuste por disponibilidad de comparables
        if method == ValuationMethod.MARKET_COMPARISON:
            if context.comparable_availability >= 70:
                score += 20
            elif context.comparable_availability < 30:
                score -= 30
        
        # Ajuste por activo productor de ingresos
        if context.income_producing:
            if method in [ValuationMethod.INCOME_CAPITALIZATION, ValuationMethod.DCF]:
                score += 20
        
        # Ajuste por horizonte temporal
        if context.time_horizon == TimeHorizon.LONG_TERM:
            if method in [ValuationMethod.DCF, ValuationMethod.NATURAL_CAPITAL_ACCOUNTING]:
                score += 15
        
        # Ajuste por actividad del mercado
        if context.market_activity == "none":
            if method == ValuationMethod.MARKET_COMPARISON:
                score -= 40
            if method == ValuationMethod.COST_APPROACH:
                score += 20
        
        return max(0, min(100, score))
    
    def _build_recommendation(
        self, method: ValuationMethod, score: float, context: ValuationContext
    ) -> MethodRecommendation:
        """Construye una recomendación detallada."""
        kb = self.knowledge_base.get(method, {})
        
        # Determinar precisión estimada
        if score >= 80:
            accuracy = "Alta (±5-10%)"
        elif score >= 60:
            accuracy = "Moderada (±10-20%)"
        else:
            accuracy = "Limitada (±20-30%)"
        
        return MethodRecommendation(
            method=method,
            suitability_score=round(score, 1),
            primary=score == max([self._score_method(m, context) for m in ValuationMethod]),
            rationale=self._generate_rationale(method, context, score),
            strengths=kb.get("strengths", []),
            limitations=kb.get("limitations", []),
            data_requirements=kb.get("data_requirements", []),
            estimated_accuracy=accuracy,
            ivs_aligned=kb.get("ivs_aligned", False),
            rics_compliant=kb.get("rics_compliant", False),
            basel_compliant=kb.get("basel_compliant", False),
            implementation_complexity=kb.get("complexity", "medium"),
            datapolis_module=kb.get("datapolis_module", "N/A")
        )
    
    def _generate_rationale(
        self, method: ValuationMethod, context: ValuationContext, score: float
    ) -> str:
        """Genera justificación textual de la recomendación."""
        reasons = []
        
        kb = self.knowledge_base.get(method, {})
        
        if context.asset_type.value in kb.get("best_for", []):
            reasons.append(f"Método especialmente apropiado para {context.asset_type.value}")
        
        if context.purpose == ValuationPurpose.COLLATERAL and kb.get("basel_compliant"):
            reasons.append("Cumple con requisitos Basel IV para colaterales")
        
        if context.purpose == ValuationPurpose.ESG_REPORTING:
            if method in [ValuationMethod.ECOSYSTEM_SERVICES, ValuationMethod.NATURAL_CAPITAL_ACCOUNTING]:
                reasons.append("Alineado con frameworks ESG/TNFD")
        
        if context.income_producing and method in [ValuationMethod.INCOME_CAPITALIZATION, ValuationMethod.DCF]:
            reasons.append("Apropiado para activos generadores de ingresos")
        
        if context.comparable_availability >= 70 and method == ValuationMethod.MARKET_COMPARISON:
            reasons.append("Alta disponibilidad de comparables en el mercado")
        
        if not reasons:
            reasons.append(kb.get("description", "Método de valuación estándar"))
        
        return "; ".join(reasons) + f". Score de idoneidad: {score:.0f}/100."
    
    def _suggest_hybrid_approach(
        self, recommendations: List[MethodRecommendation], context: ValuationContext
    ) -> Optional[Dict[str, Any]]:
        """Sugiere enfoque híbrido si es apropiado."""
        if len(recommendations) < 2:
            return None
        
        top_methods = [r.method for r in recommendations[:3]]
        
        # Híbrido tradicional + ML
        if (ValuationMethod.MARKET_COMPARISON in top_methods and 
            ValuationMethod.ML_ENSEMBLE in top_methods):
            return {
                "approach": "Tradicional + ML",
                "description": "Combinar comparación de mercado con ajustes de ML",
                "weight_traditional": 0.6,
                "weight_ml": 0.4,
                "rationale": "ML captura patrones no lineales; tradicional aporta transparencia"
            }
        
        # Híbrido económico + ESG
        if (ValuationMethod.DCF in top_methods and 
            ValuationMethod.ECOSYSTEM_SERVICES in top_methods):
            return {
                "approach": "Financiero + Capital Natural",
                "description": "Integrar valor financiero con servicios ecosistémicos",
                "weight_financial": 0.7,
                "weight_natural_capital": 0.3,
                "rationale": "Captura valor integral incluyendo externalidades ambientales"
            }
        
        # Híbrido hedónico + tradicional
        if ValuationMethod.HEDONIC_PRICING in top_methods:
            return {
                "approach": "Hedónico + Comparables",
                "description": "Usar hedónico para ajustes precisos de comparables",
                "weight_hedonic": 0.5,
                "weight_comparison": 0.5,
                "rationale": "Hedónico cuantifica drivers; comparables validan mercado"
            }
        
        return None
    
    def _get_reconciliation_guidance(
        self, recommendations: List[MethodRecommendation], context: ValuationContext
    ) -> str:
        """Guía para reconciliar múltiples valuaciones."""
        if len(recommendations) < 2:
            return "Aplicar método primario con análisis de sensibilidad."
        
        guidance = [
            "Proceso de reconciliación recomendado:",
            "1. Aplicar los métodos primario y alternativo(s)",
            "2. Analizar diferencias y sus causas",
            "3. Ponderar según confiabilidad de inputs",
        ]
        
        if context.purpose == ValuationPurpose.COLLATERAL:
            guidance.append("4. Para fines de crédito, usar el valor más conservador")
        elif context.purpose == ValuationPurpose.MARKET_TRANSACTION:
            guidance.append("4. Adoptar el valor más cercano a evidencia de mercado")
        else:
            guidance.append("4. Usar promedio ponderado basado en calidad de datos")
        
        guidance.append("5. Documentar juicio profesional en la reconciliación")
        
        return " ".join(guidance)
    
    def _identify_assumptions(self, context: ValuationContext) -> List[str]:
        """Identifica supuestos clave según el contexto."""
        assumptions = [
            "Información proporcionada es precisa y completa",
            "No existen vicios ocultos no revelados"
        ]
        
        if context.time_horizon in [TimeHorizon.MEDIUM_TERM, TimeHorizon.LONG_TERM]:
            assumptions.append("Condiciones macroeconómicas se mantienen estables")
        
        if context.purpose == ValuationPurpose.COLLATERAL:
            assumptions.append("Valor asume venta forzada con descuento apropiado")
        
        if context.asset_type in [AssetType.NATURAL_ASSET, AssetType.ECOSYSTEM]:
            assumptions.append("Servicios ecosistémicos continuarán en condiciones actuales")
        
        return assumptions
    
    def _identify_risks(self, context: ValuationContext) -> List[str]:
        """Identifica factores de riesgo."""
        risks = []
        
        if context.data_quality in [DataQuality.LIMITED, DataQuality.POOR]:
            risks.append("Calidad de datos limita confiabilidad del resultado")
        
        if context.market_activity in ["limited", "none"]:
            risks.append("Mercado poco activo aumenta incertidumbre")
        
        if context.comparable_availability < 50:
            risks.append("Escasez de comparables puede sesgar ajustes")
        
        if context.time_horizon == TimeHorizon.LONG_TERM:
            risks.append("Proyecciones de largo plazo son inherentemente inciertas")
        
        if context.asset_type in [AssetType.NATURAL_ASSET, AssetType.ECOSYSTEM]:
            risks.append("Riesgos climáticos y ambientales pueden afectar valor")
        
        return risks if risks else ["Riesgos estándar de valuación"]
    
    def _get_quality_considerations(self, context: ValuationContext) -> str:
        """Consideraciones sobre calidad de la valuación."""
        if context.data_quality == DataQuality.EXCELLENT:
            return "Alta confiabilidad esperada. Datos robustos permiten precisión óptima."
        elif context.data_quality == DataQuality.GOOD:
            return "Confiabilidad adecuada. Análisis de sensibilidad recomendado."
        elif context.data_quality == DataQuality.MODERATE:
            return "Confiabilidad moderada. Múltiples enfoques y reconciliación requeridos."
        else:
            return "Confiabilidad limitada. Resultados deben tratarse como indicativos."
    
    def _get_regulatory_notes(self, context: ValuationContext) -> str:
        """Notas regulatorias según propósito."""
        notes = []
        
        if context.purpose == ValuationPurpose.COLLATERAL:
            notes.append("Debe cumplir NCG 514 CMF y requisitos Basel IV para garantías.")
        
        if context.purpose == ValuationPurpose.TAX_ASSESSMENT:
            notes.append("Debe alinearse con metodología SII y Ley 21.713 para plusvalías.")
        
        if context.purpose == ValuationPurpose.ESG_REPORTING:
            notes.append("Alineamiento con TNFD y SEEA-EA recomendado para disclosure.")
        
        if context.regulatory_requirement:
            notes.append(f"Requisito específico: {context.regulatory_requirement}")
        
        return " ".join(notes) if notes else "Sin requisitos regulatorios específicos identificados."
    
    def get_method_details(self, method: ValuationMethod) -> Dict[str, Any]:
        """Obtiene detalles completos de un método."""
        if method not in self.knowledge_base:
            return {"error": "Método no encontrado"}
        
        kb = self.knowledge_base[method]
        return {
            "method": method.value,
            "description": kb.get("description"),
            "strengths": kb.get("strengths"),
            "limitations": kb.get("limitations"),
            "data_requirements": kb.get("data_requirements"),
            "best_for_asset_types": kb.get("best_for"),
            "ivs_aligned": kb.get("ivs_aligned"),
            "rics_compliant": kb.get("rics_compliant"),
            "basel_compliant": kb.get("basel_compliant"),
            "complexity": kb.get("complexity"),
            "datapolis_module": kb.get("datapolis_module")
        }
    
    def list_available_methods(self) -> List[Dict[str, Any]]:
        """Lista todos los métodos disponibles."""
        methods = []
        for method in ValuationMethod:
            kb = self.knowledge_base.get(method, {})
            methods.append({
                "method": method.value,
                "description": kb.get("description", ""),
                "complexity": kb.get("complexity", "unknown"),
                "datapolis_module": kb.get("datapolis_module", "N/A")
            })
        return methods


# Singleton instance
valuation_advisor = ValuationAdvisorService()
