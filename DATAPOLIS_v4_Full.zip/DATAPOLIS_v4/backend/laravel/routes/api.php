<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ExpedienteController;
use App\Http\Controllers\CopropiedadController;
use App\Http\Controllers\PAEController;
use App\Http\Controllers\ESGReportController;

/*
|--------------------------------------------------------------------------
| DATAPOLIS v4.0 - API Routes
|--------------------------------------------------------------------------
|
| Rutas API para backend Laravel
| Incluye módulos v3.0 + endpoints v4.0 para ESG y Capital Natural
|
*/

// ============================================================
// HEALTH CHECK
// ============================================================
Route::get('/health', function () {
    return response()->json([
        'status' => 'healthy',
        'version' => '4.0.0',
        'laravel' => app()->version(),
        'timestamp' => now()->toIso8601String()
    ]);
});

Route::prefix('v1')->group(function () {
    
    // ============================================================
    // AUTENTICACIÓN
    // ============================================================
    Route::prefix('auth')->group(function () {
        Route::post('/login', [AuthController::class, 'login']);
        Route::post('/register', [AuthController::class, 'register']);
        Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');
        Route::get('/me', [AuthController::class, 'me'])->middleware('auth:sanctum');
        Route::post('/refresh', [AuthController::class, 'refresh'])->middleware('auth:sanctum');
    });
    
    // ============================================================
    // RUTAS PROTEGIDAS
    // ============================================================
    Route::middleware('auth:sanctum')->group(function () {
        
        // --------------------------------------------------------
        // M00 EXPEDIENTES (v3.0)
        // --------------------------------------------------------
        Route::prefix('expedientes')->group(function () {
            Route::get('/', [ExpedienteController::class, 'index']);
            Route::post('/', [ExpedienteController::class, 'store']);
            Route::get('/{id}', [ExpedienteController::class, 'show']);
            Route::put('/{id}', [ExpedienteController::class, 'update']);
            Route::delete('/{id}', [ExpedienteController::class, 'destroy']);
            Route::get('/{id}/timeline', [ExpedienteController::class, 'timeline']);
            Route::post('/{id}/documents', [ExpedienteController::class, 'uploadDocument']);
        });
        
        // --------------------------------------------------------
        // M02 COPROPIEDADES (v3.0)
        // --------------------------------------------------------
        Route::prefix('copropiedades')->group(function () {
            Route::get('/', [CopropiedadController::class, 'index']);
            Route::post('/', [CopropiedadController::class, 'store']);
            Route::get('/{id}', [CopropiedadController::class, 'show']);
            Route::put('/{id}', [CopropiedadController::class, 'update']);
            Route::delete('/{id}', [CopropiedadController::class, 'destroy']);
            Route::get('/{id}/dashboard', [CopropiedadController::class, 'dashboard']);
            Route::get('/{id}/unidades', [CopropiedadController::class, 'unidades']);
            Route::get('/{id}/gastos-comunes', [CopropiedadController::class, 'gastosComunes']);
            Route::get('/{id}/morosidad', [CopropiedadController::class, 'morosidad']);
        });
        
        // --------------------------------------------------------
        // M11 PAE ENGINE (v3.0)
        // --------------------------------------------------------
        Route::prefix('pae')->group(function () {
            Route::post('/analyze/{copropiedadId}', [PAEController::class, 'analyze']);
            Route::get('/alerts/{copropiedadId}', [PAEController::class, 'getAlerts']);
            Route::get('/score/{copropiedadId}', [PAEController::class, 'getScore']);
            Route::get('/recommendations/{copropiedadId}', [PAEController::class, 'getRecommendations']);
            Route::post('/resolve-alert/{alertId}', [PAEController::class, 'resolveAlert']);
            Route::get('/history/{copropiedadId}', [PAEController::class, 'getHistory']);
        });
        
        // --------------------------------------------------------
        // ESG REPORTS (v4.0 - NUEVO)
        // --------------------------------------------------------
        Route::prefix('esg')->group(function () {
            
            // Reportes ESG para entidades
            Route::get('/report/{entityId}', [ESGReportController::class, 'getReport']);
            Route::post('/report/generate', [ESGReportController::class, 'generateReport']);
            
            // Capital Natural
            Route::get('/natural-capital/{entityId}', [ESGReportController::class, 'getNaturalCapital']);
            Route::post('/natural-capital/statement', [ESGReportController::class, 'generateStatement']);
            
            // Servicios Ecosistémicos
            Route::get('/ecosystem-services/{entityId}', [ESGReportController::class, 'getEcosystemServices']);
            Route::post('/ecosystem-services/valuate', [ESGReportController::class, 'valuateEcosystemServices']);
            
            // TNFD Metrics
            Route::get('/tnfd-metrics/{entityId}', [ESGReportController::class, 'getTNFDMetrics']);
            Route::post('/tnfd-disclosure', [ESGReportController::class, 'generateTNFDDisclosure']);
            
            // Dashboard ESG
            Route::get('/dashboard/{entityId}', [ESGReportController::class, 'getDashboard']);
            Route::get('/score/{entityId}', [ESGReportController::class, 'getESGScore']);
            
            // Exportación
            Route::get('/export/{entityId}', [ESGReportController::class, 'exportReport']);
        });
        
        // --------------------------------------------------------
        // INTEGRATION ENDPOINTS (v4.0)
        // --------------------------------------------------------
        Route::prefix('integration')->group(function () {
            
            // Proxy a FastAPI para módulos v4.0
            Route::post('/hedonic/estimate', [ESGReportController::class, 'proxyHedonicEstimate']);
            Route::post('/ecosystem/valuate', [ESGReportController::class, 'proxyEcosystemValuate']);
            Route::post('/valuation-advisor/recommend', [ESGReportController::class, 'proxyValuationRecommend']);
            Route::get('/env-hub/profile', [ESGReportController::class, 'proxyEnvProfile']);
        });
    });
    
    // ============================================================
    // RUTAS PÚBLICAS
    // ============================================================
    
    // Indicadores económicos (público)
    Route::prefix('indicadores')->group(function () {
        Route::get('/uf', function () {
            // Proxy a FastAPI o cálculo local
            return response()->json([
                'uf' => 38500.00, // Valor de ejemplo
                'fecha' => now()->toDateString()
            ]);
        });
        
        Route::get('/utm', function () {
            return response()->json([
                'utm' => 67500.00,
                'fecha' => now()->toDateString()
            ]);
        });
    });
    
    // Módulos disponibles
    Route::get('/modules', function () {
        return response()->json([
            'version' => '4.0.0',
            'modules' => [
                'v3' => ['M00', 'M01', 'M02', 'M03', 'M04', 'M05', 'M06', 'M07', 'M08', 
                         'M09', 'M10', 'M11', 'M13', 'M14', 'M16', 'M17', 'M22', 
                         'MS', 'GT-PV', 'M01-OF', 'RR', 'IE'],
                'v4' => ['M-HED', 'M-ESV', 'M-NCA', 'M-VAD', 'M-ENV']
            ]
        ]);
    });
});
