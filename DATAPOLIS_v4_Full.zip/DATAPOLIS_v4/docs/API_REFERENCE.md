# DATAPOLIS v4.0 – API Reference

## Base URLs

| Entorno | FastAPI | Laravel |
|---------|---------|---------|
| Local | `http://localhost:8001/api/v1` | `http://localhost:8000/api/v1` |
| Producción | `https://api.datapolis.cl/v1` | `https://app.datapolis.cl/api/v1` |

## Autenticación

Todos los endpoints requieren autenticación via JWT Bearer Token.

```bash
Authorization: Bearer <token>
```

---

## MÓDULOS v4.0

### 1. Hedonic Pricing (M-HED)

#### POST /hedonic/estimate
Estima un modelo de precios hedónicos.

**Request Body:**
```json
{
  "data": [
    {"precio": 150000000, "superficie": 80, "dormitorios": 3, "distancia_metro": 500}
  ],
  "dependent_variable": "precio",
  "independent_variables": ["superficie", "dormitorios", "distancia_metro"],
  "model_type": "log_linear",
  "include_diagnostics": true
}
```

**Response:**
```json
{
  "model_type": "log_linear",
  "n_observations": 100,
  "coefficients": [
    {
      "variable": "const",
      "coefficient": 15.234,
      "std_error": 0.145,
      "t_statistic": 105.06,
      "p_value": 0.0,
      "is_significant": true,
      "implicit_price": null,
      "elasticity": null
    },
    {
      "variable": "superficie",
      "coefficient": 0.0085,
      "std_error": 0.0012,
      "t_statistic": 7.08,
      "p_value": 0.0001,
      "is_significant": true,
      "implicit_price": 850000,
      "elasticity": 0.68
    }
  ],
  "diagnostics": {
    "r_squared": 0.847,
    "adj_r_squared": 0.842,
    "f_statistic": 178.5,
    "f_pvalue": 0.0,
    "aic": 2145.3,
    "bic": 2167.8,
    "durbin_watson": 1.92,
    "jarque_bera_stat": 2.34,
    "jarque_bera_pvalue": 0.31,
    "morans_i": 0.12,
    "morans_i_pvalue": 0.08,
    "vif_scores": {
      "superficie": 1.45,
      "dormitorios": 2.31,
      "distancia_metro": 1.23
    },
    "multicollinearity_warning": false
  }
}
```

#### POST /hedonic/compare
Compara múltiples especificaciones de modelo.

**Request Body:**
```json
{
  "data": [...],
  "dependent_variable": "precio",
  "independent_variables": ["superficie", "dormitorios"]
}
```

**Response:**
```json
{
  "comparison": {
    "ols_linear": {"r_squared": 0.78, "aic": 2300, "bic": 2320},
    "log_linear": {"r_squared": 0.85, "aic": 2145, "bic": 2168},
    "log_log": {"r_squared": 0.83, "aic": 2180, "bic": 2200}
  },
  "best_model": "log_linear",
  "selection_criteria": "aic"
}
```

#### POST /hedonic/predict
Predice precios usando un modelo estimado.

#### GET /hedonic/implicit-prices
Obtiene precios implícitos de atributos.

#### GET /hedonic/diagnostics-guide
Guía de interpretación de diagnósticos.

---

### 2. Ecosystem Services (M-ESV)

#### POST /ecosystem-services/valuate
Valora servicios ecosistémicos de un polígono.

**Request Body:**
```json
{
  "polygon_id": "parque_001",
  "area_hectares": 25.5,
  "biome_type": "urban_green",
  "region": "zona_central",
  "discount_rate": 0.03,
  "time_horizon_years": 30
}
```

**Response:**
```json
{
  "polygon_id": "parque_001",
  "biome_type": "urban_green",
  "area_hectares": 25.5,
  "total_annual_value_usd": 148155,
  "npv_usd": 2904567,
  "services_breakdown": [
    {
      "service": "recreation",
      "category": "cultural",
      "annual_value_usd_ha": 1680,
      "confidence_level": "high"
    },
    {
      "service": "air_quality_regulation",
      "category": "regulating",
      "annual_value_usd_ha": 1120,
      "confidence_level": "medium"
    }
  ],
  "methodology": "ESVD_value_transfer",
  "regional_adjustment_factor": 1.0,
  "confidence": "medium"
}
```

#### POST /ecosystem-services/project-impact
Evalúa impacto de un proyecto sobre servicios ecosistémicos.

#### POST /ecosystem-services/compare-scenarios
Compara escenarios de cambio de uso de suelo.

#### GET /ecosystem-services/biomes
Lista todos los biomas disponibles con valores.

#### GET /ecosystem-services/biomes/{biome_type}
Matriz de servicios para un bioma específico.

#### GET /ecosystem-services/services
Lista todos los servicios ecosistémicos.

#### GET /ecosystem-services/methodology
Información metodológica.

---

### 3. Natural Capital Accounting (M-NCA)

#### POST /natural-capital/accounts
Crea una cuenta de activo natural.

**Request Body:**
```json
{
  "asset_id": "bosque_001",
  "asset_type": "timber_resources",
  "name": "Bosque Nativo Cordillera",
  "location": "Región de Los Ríos",
  "area_hectares": 500,
  "stock_physical": 75000,
  "stock_unit": "m3",
  "opening_stock_monetary": 15000000,
  "additions": 500000,
  "reductions": 200000,
  "revaluations": 100000
}
```

**Response:**
```json
{
  "asset_id": "bosque_001",
  "asset_type": "timber_resources",
  "name": "Bosque Nativo Cordillera",
  "location": "Región de Los Ríos",
  "area_hectares": 500,
  "stock_physical": 75000,
  "stock_unit": "m3",
  "stock_monetary_usd": 15400000,
  "condition": "good",
  "condition_index": 0.75,
  "opening_stock": 15000000,
  "closing_stock": 15400000,
  "shadow_price_usd": 205.33,
  "accounting_period": "2024"
}
```

#### POST /natural-capital/shadow-price/schaefer
Calcula precio sombra con modelo de Schaefer.

**Request Body:**
```json
{
  "carrying_capacity": 10000,
  "intrinsic_growth_rate": 0.3,
  "catchability_coefficient": 0.001,
  "current_stock": 7000,
  "current_effort": 100,
  "price_per_unit": 500,
  "cost_per_effort": 1000,
  "discount_rate": 0.03
}
```

**Response:**
```json
{
  "asset_id": "schaefer_calculation",
  "shadow_price_usd": 187.45,
  "marginal_user_cost": 45.23,
  "scarcity_rent": 142.22,
  "discount_rate": 0.03,
  "optimal_extraction": 750,
  "sustainability_index": 0.85,
  "methodology": "schaefer_bioeconomic"
}
```

#### POST /natural-capital/shadow-price/hamiltonian
Calcula precio sombra con enfoque Hamiltoniano.

#### POST /natural-capital/stock-projection
Proyecta trayectoria de stock.

#### POST /natural-capital/statement
Genera estado de capital natural (TNFD-aligned).

#### GET /natural-capital/tnfd-metrics
Obtiene métricas TNFD.

#### GET /natural-capital/asset-types
Lista tipos de activos naturales.

#### GET /natural-capital/methodology
Información metodológica (SEEA-EA).

---

### 4. Valuation Method Advisor (M-VAD)

#### POST /valuation-advisor/recommend
Obtiene recomendación de método de valuación.

**Request Body:**
```json
{
  "asset_type": "residential_property",
  "purpose": "collateral",
  "time_horizon": "spot",
  "data_quality": "good",
  "market_activity": "active",
  "income_producing": false,
  "comparable_availability": 75,
  "regulatory_requirement": "NCG 514 CMF"
}
```

**Response:**
```json
{
  "request_id": "adv_20240208_001",
  "primary_recommendation": {
    "method": "market_comparison",
    "suitability_score": 92,
    "primary": true,
    "rationale": "Alta disponibilidad de comparables y mercado activo...",
    "strengths": ["Transparencia", "Aceptación regulatoria"],
    "limitations": ["Requiere ajustes por diferencias"],
    "data_requirements": ["Transacciones recientes", "Características físicas"],
    "estimated_accuracy": "±5-10%",
    "ivs_aligned": true,
    "rics_compliant": true,
    "basel_compliant": true,
    "implementation_complexity": "medium",
    "datapolis_module": "M04 Valorización"
  },
  "alternative_recommendations": [...],
  "hybrid_approach": {
    "approach": "Market + Hedonic",
    "description": "Combinar comparación directa con ajustes hedónicos",
    "rationale": "Mejora precisión manteniendo compliance"
  },
  "reconciliation_guidance": "Para colateral, ponderar 70% mercado, 30% hedónico",
  "key_assumptions": [...],
  "risk_factors": [...],
  "regulatory_notes": "NCG 514 CMF requiere tasación independiente...",
  "timestamp": "2024-02-08T15:30:00Z"
}
```

#### GET /valuation-advisor/quick-recommendation
Recomendación rápida con parámetros mínimos.

#### GET /valuation-advisor/methods
Lista todos los métodos disponibles.

#### GET /valuation-advisor/methods/{method}
Detalles de un método específico.

#### GET /valuation-advisor/asset-types
Lista tipos de activos soportados.

#### GET /valuation-advisor/purposes
Lista propósitos de valuación.

#### GET /valuation-advisor/compliance-matrix
Matriz de compliance métodos vs regulaciones.

---

### 5. Environmental Data Hub (M-ENV)

#### GET /env-hub/profile
Obtiene perfil ambiental de una ubicación.

**Query Parameters:**
- `latitude`: float (required)
- `longitude`: float (required)
- `radius_meters`: int (default: 1000)

**Response:**
```json
{
  "latitude": -33.4489,
  "longitude": -70.6693,
  "radius_meters": 1000,
  "layers_data": {
    "land_cover": {"dominant_type": "urban", "urban_percentage": 85},
    "vegetation": {"ndvi_mean": 0.35},
    "air_quality": {"pm25_mean": 28, "quality_level": "moderate"},
    "green_space": {"area_percentage": 15, "nearest_park_meters": 450}
  },
  "risk_summary": {
    "flood_risk": "low",
    "seismic_risk": "moderate",
    "wildfire_risk": "very_low"
  },
  "esg_score": 68,
  "natural_capital_proximity": {
    "parks": 0.45,
    "water_bodies": 2.1,
    "protected_areas": 15.3
  }
}
```

#### GET /env-hub/layers
Obtiene datos de una capa específica.

#### GET /env-hub/time-series
Obtiene serie temporal de variable ambiental.

#### GET /env-hub/proximity
Calcula proximidad a amenidades naturales.

#### GET /env-hub/esg-indicators
Obtiene indicadores ESG agregados.

#### GET /env-hub/layers/available
Lista capas ambientales disponibles.

---

## Códigos de Error

| Código | Descripción |
|--------|-------------|
| 400 | Bad Request - Parámetros inválidos |
| 401 | Unauthorized - Token inválido o expirado |
| 403 | Forbidden - Sin permisos para el recurso |
| 404 | Not Found - Recurso no encontrado |
| 422 | Unprocessable Entity - Error de validación |
| 429 | Too Many Requests - Rate limit excedido |
| 500 | Internal Server Error |

---

## Rate Limits

| Plan | Requests/min | Requests/día |
|------|--------------|--------------|
| Free | 10 | 1,000 |
| Pro | 100 | 50,000 |
| Enterprise | 1,000 | Ilimitado |

---

## SDKs

- Python: `pip install datapolis-sdk`
- JavaScript: `npm install @datapolis/sdk`
- PHP: `composer require datapolis/sdk`

---

## Changelog v4.0

- **Nuevo**: M-HED Hedonic Pricing (70+ endpoints)
- **Nuevo**: M-ESV Ecosystem Services (15 endpoints)
- **Nuevo**: M-NCA Natural Capital (20 endpoints)
- **Nuevo**: M-VAD Valuation Advisor (10 endpoints)
- **Nuevo**: M-ENV Environmental Hub (15 endpoints)
- **Mejorado**: M04 integración con hedónicos
- **Mejorado**: M03/M16 factores ESG en scoring
