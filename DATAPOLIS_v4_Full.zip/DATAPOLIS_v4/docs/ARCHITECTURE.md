# DATAPOLIS v4.0 – Arquitectura

## 1. Visión General

DATAPOLIS v4.0 es una plataforma integral **PropTech/FinTech/RegTech/GovTech** que integra capacidades avanzadas de **econometría espacial**, **valoración de servicios ecosistémicos** y **contabilidad de capital natural**.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           DATAPOLIS v4.0                                    │
│                   Hedonic & Natural Capital Edition                         │
├─────────────────────────────────────────────────────────────────────────────┤
│  FRONTEND (Vue 3 + Vite + Tailwind)                                        │
│  ┌─────────────┬─────────────┬─────────────┬─────────────┬───────────────┐ │
│  │ Dashboard   │ Expedientes │ Copropied.  │ GeoViewer   │ v4.0 Panels   │ │
│  │             │             │             │ (ÁGORA)     │ • Hedonic     │ │
│  │             │             │             │             │ • Ecosystem   │ │
│  │             │             │             │             │ • Advisor     │ │
│  └─────────────┴─────────────┴─────────────┴─────────────┴───────────────┘ │
├─────────────────────────────────────────────────────────────────────────────┤
│  API GATEWAY / LOAD BALANCER                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│  BACKEND FASTAPI (Python)              │  BACKEND LARAVEL (PHP)            │
│  ┌───────────────────────────────────┐ │  ┌─────────────────────────────┐  │
│  │ v3.0 MODULES                      │ │  │ Controllers                 │  │
│  │ • M00 Expedientes                 │ │  │ • Copropiedades             │  │
│  │ • M01 Fichas de Propiedad         │ │  │ • PAE                       │  │
│  │ • M02 Copropiedades               │ │  │ • Contabilidad              │  │
│  │ • M03 Credit Scoring Basel IV     │ │  │ • Reportes ESG              │  │
│  │ • M04 Valorización ML             │ │  │                             │  │
│  │ • M11 PAE Engine                  │ │  │ Services                    │  │
│  │ • M16 Basel IV Framework          │ │  │ • PAE Analysis              │  │
│  │ • M17 GIRES                       │ │  │ • Document Management       │  │
│  │ • M22 ÁGORA                       │ │  │                             │  │
│  │ • GT-PV Plusvalías                │ │  └─────────────────────────────┘  │
│  │ • M01-OF Open Finance             │ │                                   │
│  ├───────────────────────────────────┤ │                                   │
│  │ v4.0 MODULES                      │ │                                   │
│  │ • M-HED Hedonic Pricing           │ │                                   │
│  │ • M-ESV Ecosystem Services        │ │                                   │
│  │ • M-NCA Natural Capital           │ │                                   │
│  │ • M-VAD Valuation Advisor         │ │                                   │
│  │ • M-ENV Environmental Hub         │ │                                   │
│  └───────────────────────────────────┘ │                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│  DATA LAYER                                                                │
│  ┌─────────────────┬─────────────────┬─────────────────┬─────────────────┐ │
│  │ PostgreSQL      │ PostGIS         │ Redis           │ Object Storage  │ │
│  │ (Relational)    │ (Geospatial)    │ (Cache)         │ (Documents)     │ │
│  └─────────────────┴─────────────────┴─────────────────┴─────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Módulos v3.0 (Preservados)

### 2.1 PropTech
| Módulo | Descripción | Endpoints |
|--------|-------------|-----------|
| M00 | Expedientes inmobiliarios | 15+ |
| M01 | Fichas de Propiedad | 20+ |
| M02 | Gestión de Copropiedades | 25+ |
| M05 | Arriendos | 12+ |
| M06 | Mantenciones | 10+ |
| M07 | Inversión | 15+ |
| M08 | Contabilidad | 18+ |
| MS | Mercado de Suelo | 20+ |

### 2.2 FinTech
| Módulo | Descripción | Compliance |
|--------|-------------|------------|
| M01-OF | Open Finance | NCG 514 CMF |
| M03 | Credit Scoring | Basel IV |
| M04 | Valorización ML | IVS/RICS |
| M13 | Garantías | Basel IV |
| M16 | Basel IV Framework | BIS 2023 |
| RR | Rentabilidad Real | - |

### 2.3 RegTech
| Módulo | Descripción | Marco Legal |
|--------|-------------|-------------|
| M10 | Reportes/Compliance | CMF |
| M11 | PAE Engine | Ley 21.442 |
| M14 | Reavalúo SII | Ley 17.235 |
| GT-PV | Plusvalías Urbanas | Ley 21.713 |

### 2.4 GovTech
| Módulo | Descripción |
|--------|-------------|
| M17 | GIRES - Gestión Integral de Riesgos |
| M22 | ÁGORA GeoViewer |

---

## 3. Módulos v4.0 (Nuevos)

### 3.1 M-HED: Hedonic Pricing Spatial Models

**Propósito**: Estimación de modelos de precios hedónicos para descomponer el valor inmobiliario en atributos.

**Capacidades**:
- Modelos OLS lineal, log-lineal, log-log, Box-Cox
- Diagnósticos de multicolinealidad (VIF)
- Test de Moran's I para autocorrelación espacial
- Cálculo de precios implícitos y elasticidades
- Selección de modelo por AIC/BIC

**Flujo**:
```
Datos de Mercado → Selección Variables → Estimación → Diagnósticos → Precios Implícitos
```

### 3.2 M-ESV: Ecosystem Services Valuation

**Propósito**: Valoración económica de servicios ecosistémicos por polígono/proyecto.

**Metodología**:
- Value Transfer basado en ESVD (Ecosystem Services Valuation Database)
- Ajustes regionales para Chile
- Cálculo de NPV a horizonte configurable

**Servicios Valorados**:
- Provisioning: Alimentos, agua, materias primas
- Regulating: Clima, agua, erosión, polinización
- Cultural: Recreación, estética, educación
- Supporting: Hábitat, biodiversidad

### 3.3 M-NCA: Natural Capital Accounting

**Propósito**: Contabilidad de activos de capital natural según SEEA-EA.

**Modelos Implementados**:
- **Schaefer**: F(X) = r·X·(1 - X/K)
- **Hamiltoniano**: H = π(X,E) + λ[F(X) - Y(E,X)]

**Outputs**:
- Precios sombra de recursos naturales
- Trayectorias de stock óptimo
- Estados de capital natural (TNFD-aligned)

### 3.4 M-VAD: Valuation Method Advisor

**Propósito**: Recomendación inteligente del método de valuación óptimo.

**Inputs Considerados**:
- Tipo de activo
- Propósito de valuación
- Horizonte temporal
- Calidad de datos disponibles
- Requisitos regulatorios

**Métodos Recomendables**:
- Market Comparison
- Income Capitalization
- DCF
- Cost Approach
- Hedonic Pricing
- ML Ensemble
- Ecosystem Services
- Natural Capital Accounting

### 3.5 M-ENV: Environmental Data Hub

**Propósito**: Centralizar y normalizar datos ambientales para todos los módulos.

**Capas Disponibles**:
- Land Cover / Uso de Suelo
- Áreas Verdes / NDVI
- Calidad del Aire
- Riesgos Naturales
- Biodiversidad
- Variables Climáticas

**Consumidores**:
- M-HED (variables hedónicas ambientales)
- M-ESV (caracterización de ecosistemas)
- M-NCA (inventario de activos naturales)
- M17 GIRES (capas de riesgo)
- M22 ÁGORA (visualización)

---

## 4. Integraciones entre Módulos

```
┌─────────────────────────────────────────────────────────────────┐
│                    FLUJO DE DATOS v4.0                         │
└─────────────────────────────────────────────────────────────────┘

   M-ENV ──────────────────────────────────────────────────────┐
     │                                                          │
     │ Datos Ambientales                                        │
     ▼                                                          ▼
   M-HED ──────────► M04 Valorización ◄────────────────────  M-ESV
     │                     │                                    │
     │ Coeficientes        │ Valor Integrado                    │ NPV Ecosistémico
     ▼                     ▼                                    ▼
   GT-PV ◄──────────────────────────────────────────────────  M-NCA
     │                                                          │
     │ Plusvalía Descompuesta                                   │ Capital Natural
     ▼                                                          ▼
   M03/M16 ◄────────────────────────────────────────────────────┘
     │
     │ ESG-adjusted Credit Scoring
     ▼
   M01-OF (Open Finance Reports)
```

---

## 5. Stack Tecnológico

### Backend
| Componente | Tecnología | Versión |
|------------|------------|---------|
| API Principal | FastAPI | 0.109+ |
| API Secundaria | Laravel | 11.x |
| Runtime Python | Python | 3.11+ |
| Runtime PHP | PHP | 8.2+ |
| Econometría | statsmodels | 0.14+ |
| ML | scikit-learn, XGBoost | Latest |
| Geospatial | Shapely, PyProj | Latest |

### Frontend
| Componente | Tecnología | Versión |
|------------|------------|---------|
| Framework | Vue.js | 3.4+ |
| Build Tool | Vite | 5.x |
| CSS | Tailwind CSS | 3.x |
| Maps | Leaflet | 1.9+ |
| Charts | Chart.js / Recharts | Latest |

### Data
| Componente | Tecnología |
|------------|------------|
| Database | PostgreSQL 15+ |
| Geospatial | PostGIS 3.3+ |
| Cache | Redis 7+ |
| Search | Elasticsearch (opcional) |

---

## 6. Patrones de Diseño

### 6.1 Service Layer Pattern
Cada módulo expone un servicio con lógica de negocio encapsulada.

```python
# Ejemplo: HedonicPricingService
class HedonicPricingService:
    def estimate(self, data, model_type, ...) -> HedonicResult
    def compare_models(self, data, ...) -> Dict[str, HedonicResult]
    def select_best_model(self, results) -> str
```

### 6.2 Repository Pattern
Acceso a datos desacoplado de la lógica de negocio.

### 6.3 Factory Pattern
Creación de modelos econométricos según tipo solicitado.

### 6.4 Strategy Pattern
Selección de método de valuación en M-VAD.

---

## 7. Seguridad

- **Autenticación**: JWT tokens con refresh
- **Autorización**: RBAC (Role-Based Access Control)
- **Encriptación**: TLS 1.3 en tránsito, AES-256 en reposo
- **Auditoría**: Log de todas las operaciones sensibles
- **Compliance**: NCG 514 CMF, GDPR-compatible

---

## 8. Escalabilidad

- **Horizontal**: Stateless APIs, load balancing
- **Vertical**: Async processing con Celery/Redis
- **Cache**: Redis para resultados de cálculos costosos
- **CDN**: Assets estáticos en CDN

---

## 9. Monitoreo

- **Métricas**: Prometheus + Grafana
- **Logs**: Structured logging (JSON)
- **Alertas**: PagerDuty/Opsgenie integration
- **APM**: OpenTelemetry traces

---

## 10. Roadmap de Arquitectura

| Versión | Características |
|---------|-----------------|
| v4.0 | Hedonic + Ecosystem Services + Natural Capital |
| v4.1 | SAR/SEM spatial regression models |
| v4.2 | Real-time environmental data streaming |
| v5.0 | Full TNFD compliance, Carbon accounting |
