# DATAPOLIS v4.0 - Guía Operativa para Clientes

## Bienvenido a DATAPOLIS v4.0

Esta guía describe las nuevas funcionalidades de la versión 4.0, enfocadas en **valoración avanzada**, **servicios ecosistémicos** y **capital natural**.

---

## Nuevos Módulos v4.0

### 🎯 M-HED: Análisis Hedónico de Precios

**¿Qué es?**  
Un modelo econométrico que descompone el precio de una propiedad en el valor individual de cada uno de sus atributos (superficie, ubicación, amenidades, etc.).

**¿Para qué sirve?**
- Entender qué atributos generan más valor
- Justificar precios con evidencia estadística
- Identificar oportunidades de mejora
- Cuantificar el "precio implícito" de características específicas

**Cómo usarlo:**

1. Navegue a **Hedonic Panel** en el menú lateral
2. Seleccione el tipo de modelo:
   - **OLS Lineal**: Para relaciones directas
   - **Log-Lineal**: Para efectos porcentuales
   - **Box-Cox**: Para ajuste óptimo automático
3. Seleccione las variables independientes
4. Click en **Estimar Modelo**

**Interpretación de resultados:**

| Métrica | Qué significa | Valor ideal |
|---------|---------------|-------------|
| R² | % de variación explicada | > 0.70 |
| VIF | Multicolinealidad | < 10 |
| p-value | Significancia estadística | < 0.05 |
| Precio implícito | Valor de cada m² adicional | Positivo |

**Ejemplo práctico:**
```
Resultado: Coeficiente "distancia_metro" = -15,000 CLP
Interpretación: Cada metro adicional de distancia al metro 
                reduce el valor en $15,000 CLP
```

---

### 🌿 M-ESV: Servicios Ecosistémicos

**¿Qué es?**  
Un módulo que calcula el valor monetario de los servicios que proveen los ecosistemas naturales (regulación climática, purificación de agua, recreación, etc.).

**¿Para qué sirve?**
- Valorar áreas verdes y espacios naturales
- Justificar inversiones en sustentabilidad
- Cumplir con reportes ESG/TNFD
- Evaluar impacto ambiental de proyectos

**Cómo usarlo:**

1. Navegue a **Ecosystem Dashboard**
2. Ingrese los datos del polígono:
   - ID del área
   - Superficie en hectáreas
   - Tipo de bioma
   - Región de Chile
3. Click en **Agregar Valoración**

**Tipos de biomas disponibles:**

| Bioma | Valor aprox. USD/ha/año | Servicios principales |
|-------|-------------------------|----------------------|
| Bosque Tropical | $6,275 | Clima, agua, biodiversidad |
| Humedal | $8,870 | Purificación, inundaciones |
| Área Verde Urbana | $5,810 | Recreación, aire, clima |
| Zona Costera | $7,665 | Protección, pesca, turismo |
| Pradera | $1,680 | Forraje, erosión |

**Ejemplo de valoración:**
```
Parque urbano de 5 hectáreas en Santiago:
- Valor anual: 5 ha × $5,810/ha = $29,050 USD/año
- NPV (30 años, 3%): ~$569,000 USD
```

---

### 📊 M-NCA: Capital Natural

**¿Qué es?**  
Un sistema de contabilidad para activos naturales, siguiendo el estándar internacional SEEA-EA (Sistema de Contabilidad Ambiental-Económica).

**¿Para qué sirve?**
- Registrar y valorar recursos naturales
- Calcular precios sombra de recursos
- Proyectar sostenibilidad de extracción
- Generar reportes TNFD

**Conceptos clave:**

| Término | Definición |
|---------|------------|
| **Precio sombra** | Valor marginal del recurso considerando escasez futura |
| **Tasa de descuento** | Factor que ajusta valores futuros a presente |
| **MSY** | Máximo Rendimiento Sostenible (extracción óptima) |
| **Stock** | Cantidad física del recurso natural |

**Cómo crear una cuenta de activo:**

1. Navegue a **Natural Capital**
2. Seleccione **Nueva Cuenta**
3. Complete los datos:
   - Tipo de activo (bosque, agua, suelo, etc.)
   - Ubicación y área
   - Stock físico y unidad
   - Valor monetario inicial
4. El sistema calcula automáticamente:
   - Condición del activo
   - Precio sombra
   - Índice de sostenibilidad

---

### 🧭 M-VAD: Asistente de Valuación

**¿Qué es?**  
Un sistema experto que recomienda el método de valuación más apropiado según las características del activo y el propósito de la valuación.

**¿Para qué sirve?**
- Seleccionar el método óptimo para cada caso
- Cumplir con estándares IVS/RICS
- Justificar metodología ante reguladores
- Reducir errores metodológicos

**Cómo usarlo:**

1. Navegue a **Valuation Advisor**
2. Complete el contexto:
   - Tipo de activo (residencial, comercial, natural, etc.)
   - Propósito (transacción, colateral, ESG, etc.)
   - Calidad de datos disponibles
   - Disponibilidad de comparables
3. Click en **Obtener Recomendación**

**Interpretación:**

El sistema entrega:
- **Método primario**: La mejor opción para su caso
- **Score de idoneidad**: 0-100 (mayor es mejor)
- **Alternativas**: Otros métodos viables
- **Enfoque híbrido**: Combinación sugerida si aplica
- **Notas regulatorias**: Compliance relevante

**Ejemplo:**
```
Caso: Departamento para garantía hipotecaria
Recomendación: Comparación de Mercado (Score: 87)
Razón: Alta disponibilidad de comparables, propósito de 
       colateral requiere compliance Basel IV
Módulo DATAPOLIS: M04 Valorización ML
```

---

### 🌍 M-ENV: Environmental Hub

**¿Qué es?**  
Un hub centralizado de datos ambientales que alimenta a los otros módulos con información geoespacial sobre riesgos, calidad ambiental y proximidad a amenidades.

**¿Para qué sirve?**
- Obtener perfil ambiental de cualquier ubicación
- Integrar variables ambientales en valuaciones
- Generar indicadores ESG automáticos
- Visualizar capas de riesgo

**Capas disponibles:**

| Categoría | Capas |
|-----------|-------|
| **Cobertura** | Land cover, vegetación, agua |
| **Riesgos** | Inundación, sísmico, incendios |
| **Calidad** | Aire, ruido, agua |
| **Proximidad** | Parques, transporte, servicios |
| **ESG** | Score consolidado, indicadores |

**Cómo obtener un perfil:**

1. En cualquier módulo, use las coordenadas del activo
2. El Environmental Hub retorna automáticamente:
   - ESG Score (0-100)
   - Riesgos naturales
   - Proximidad a amenidades
   - Variables para modelo hedónico

---

## Flujos de Trabajo Recomendados

### Flujo 1: Valoración Completa con ESG

```
1. Crear Expediente (M00)
         ↓
2. Obtener Perfil Ambiental (M-ENV)
         ↓
3. Consultar Método Recomendado (M-VAD)
         ↓
4. Si hay comparables → Valorización ML (M04)
   Si hay datos estructurales → Hedónico (M-HED)
         ↓
5. Agregar Valor Ecosistémico (M-ESV)
         ↓
6. Generar Reporte Integrado
```

### Flujo 2: Due Diligence ESG Rápida

```
1. Ingresar coordenadas
         ↓
2. Environmental Hub genera perfil
         ↓
3. Ecosystem Services valora área verde
         ↓
4. Obtener Score ESG consolidado
```

### Flujo 3: Análisis de Plusvalía Verde

```
1. Modelo Hedónico base
         ↓
2. Agregar variables ambientales (M-ENV)
         ↓
3. Estimar nuevo modelo con variables verdes
         ↓
4. Calcular precio implícito de características ESG
         ↓
5. Valorar servicios ecosistémicos adicionales
         ↓
6. Consolidar plusvalía total
```

---

## Preguntas Frecuentes

### ¿Los módulos v4.0 reemplazan a los existentes?
No. Los módulos v4.0 **complementan** los módulos v3.0. Por ejemplo, M-HED puede usarse junto con M04 para obtener valuaciones híbridas más robustas.

### ¿Necesito conocimientos de estadística?
No es indispensable. Los módulos están diseñados para usuarios no técnicos, con interpretaciones en lenguaje simple. Sin embargo, los usuarios avanzados pueden acceder a todos los diagnósticos estadísticos.

### ¿Los valores ecosistémicos están calibrados para Chile?
Sí. Los valores base provienen de estudios internacionales (ESVD) pero se aplican factores de ajuste regional para reflejar condiciones chilenas (Norte Grande, Zona Central, Zona Sur, etc.).

### ¿Puedo exportar los resultados?
Sí. Todos los módulos permiten exportar a:
- PDF (reportes formales)
- Excel (datos tabulares)
- JSON (integración con otros sistemas)
- Shapefile/GeoJSON (datos geoespaciales)

### ¿Cómo se integran los resultados con reportes regulatorios?
Los módulos v4.0 generan outputs compatibles con:
- **TNFD**: Métricas de dependencias e impactos
- **TCFD**: Riesgos climáticos
- **GRI 304**: Biodiversidad
- **Basel IV**: LTV ajustado por ESG

---

## Soporte

### Canales de Ayuda

| Canal | Uso | Tiempo de respuesta |
|-------|-----|---------------------|
| 📧 soporte@datapolis.cl | Consultas generales | 24-48 horas |
| 💬 Chat en plataforma | Dudas rápidas | < 4 horas |
| 📞 +56 2 XXXX XXXX | Urgencias | Inmediato |
| 📚 docs.datapolis.cl | Documentación | Autoservicio |

### Capacitación

- **Webinars mensuales**: Nuevas funcionalidades
- **Tutoriales en video**: En plataforma
- **Certificación DATAPOLIS**: Programa formal (opcional)

---

*DATAPOLIS v4.0.0 - Guía actualizada Febrero 2026*
