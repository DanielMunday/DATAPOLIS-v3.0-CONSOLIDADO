# DATAPOLIS v4.0 - Documento para Inversionistas

## Propuesta de Valor Ejecutiva

**DATAPOLIS v4.0** representa una evolución estratégica hacia el mercado de **finanzas verdes y ESG**, posicionándose como la primera plataforma latinoamericana que integra:

- ✅ **Valuación inmobiliaria tradicional** (ML + comparables)
- ✅ **Econometría espacial avanzada** (precios hedónicos)
- ✅ **Valoración de capital natural** (servicios ecosistémicos)
- ✅ **Compliance regulatorio** (NCG 514, Basel IV, TNFD)

---

## Oportunidad de Mercado

### Mercado Objetivo

| Segmento | TAM (Chile) | SAM | SOM (3 años) |
|----------|-------------|-----|--------------|
| PropTech/FinTech | $850M USD | $120M USD | $15M USD |
| ESG/Finanzas Verdes | $2.1B USD | $300M USD | $25M USD |
| RegTech Compliance | $180M USD | $45M USD | $8M USD |
| **Total** | **$3.13B USD** | **$465M USD** | **$48M USD** |

### Drivers de Crecimiento

1. **Regulación ESG Obligatoria**
   - CMF exige reportes TCFD desde 2023
   - TNFD será obligatorio 2025-2026
   - EU Taxonomy influencia estándares LATAM

2. **Taxonomía Verde Chile**
   - En desarrollo por Ministerio de Hacienda
   - Requiere métricas de capital natural
   - DATAPOLIS v4.0 ya cumple estándares SEEA-EA

3. **Financiamiento Verde Creciente**
   - Bonos verdes Chile: $12B USD emitidos
   - Créditos verdes bancarios: +45% anual
   - Requieren métricas ESG verificables

---

## Ventajas Competitivas v4.0

### 1. First-Mover en Capital Natural

```
┌─────────────────────────────────────────────────────────────┐
│                    DIFERENCIACIÓN v4.0                       │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Competidores          DATAPOLIS v4.0                       │
│  ─────────────         ──────────────                       │
│  ❌ Solo ML/Comparables ✅ ML + Hedónico + Ecosistemas      │
│  ❌ Sin métricas ESG    ✅ TNFD/SEEA-EA nativo              │
│  ❌ Datos ambientales   ✅ Environmental Hub integrado       │
│     externos               con 25+ capas                     │
│  ❌ Valuación única     ✅ Advisor recomienda método         │
│                            óptimo                            │
└─────────────────────────────────────────────────────────────┘
```

### 2. Compliance Multinivel

| Regulación | Cobertura v4.0 | Competidores |
|------------|----------------|--------------|
| NCG 514 CMF | ✅ 100% | 60-80% |
| Basel IV | ✅ 100% | 70% |
| Ley 21.713 | ✅ 100% | 30% |
| TNFD | ✅ 85% | 0% |
| SEEA-EA | ✅ 90% | 0% |

### 3. Tecnología Propietaria

- **5 módulos v4.0** completamente nuevos
- **520+ endpoints** API documentados
- **Modelos econométricos** (Schaefer, Hamiltoniano)
- **Base de valores ecosistémicos** calibrada para Chile

---

## Modelo de Negocio

### Estructura de Ingresos

```
                    ┌─────────────────────────────────────┐
                    │        REVENUE STREAMS              │
                    └─────────────────────────────────────┘
                                    │
        ┌───────────────────────────┼───────────────────────────┐
        │                           │                           │
        ▼                           ▼                           ▼
┌───────────────┐          ┌───────────────┐          ┌───────────────┐
│   SaaS Fees   │          │  Transaction  │          │   Consulting  │
│     (60%)     │          │   Fees (25%)  │          │     (15%)     │
├───────────────┤          ├───────────────┤          ├───────────────┤
│ • Copropied.  │          │ • Valuaciones │          │ • Implementac.│
│ • PAE         │          │ • Reportes    │          │ • Training    │
│ • Módulos v4  │          │ • Certificac. │          │ • Customizac. │
└───────────────┘          └───────────────┘          └───────────────┘
```

### Pricing Tiers

| Plan | Precio/mes | Incluye |
|------|------------|---------|
| **Starter** | $199 USD | PropTech básico, 50 propiedades |
| **Professional** | $599 USD | + FinTech, + RegTech, 500 propiedades |
| **Enterprise** | $1,499 USD | + Módulos v4.0 completos, ilimitado |
| **Custom** | Desde $5,000 USD | White-label, API dedicada, SLA |

### Proyección Financiera

| Año | ARR | Clientes | Margen Bruto |
|-----|-----|----------|--------------|
| 2026 | $480K USD | 45 | 72% |
| 2027 | $1.8M USD | 120 | 75% |
| 2028 | $4.2M USD | 280 | 78% |
| 2029 | $8.5M USD | 520 | 80% |

---

## Casos de Uso de Alto Valor

### 1. Bancos - Créditos Verdes

**Problema**: Falta de métricas para clasificar activos como "verdes"

**Solución DATAPOLIS v4.0**:
- Valoración de servicios ecosistémicos del terreno
- Score ESG automatizado por ubicación
- Compliance TNFD para disclosure

**Impacto**: Acceso a funding internacional verde (spreads -50bps)

### 2. Fondos de Inversión - ESG Scoring

**Problema**: Due diligence ESG manual y costoso

**Solución DATAPOLIS v4.0**:
- Perfil ambiental automatizado por coordenada
- Métricas de capital natural cuantificadas
- Comparación de escenarios de desarrollo

**Impacto**: Reducción 80% tiempo due diligence ESG

### 3. Desarrolladores - Plusvalías Verdes

**Problema**: Justificar premium por características sustentables

**Solución DATAPOLIS v4.0**:
- Modelo hedónico descompone valor por atributo
- Cuantifica precio implícito de áreas verdes
- Proyecta valor de servicios ecosistémicos

**Impacto**: Pricing optimizado, argumentario de ventas basado en datos

---

## Roadmap Estratégico

```
2026 Q1-Q2                    2026 Q3-Q4                    2027
────────────                  ────────────                  ────
│                             │                             │
├─ v4.0 Launch               ├─ Expansión Colombia         ├─ Series A
├─ 30 clientes piloto        ├─ Partnership SBIF           ├─ Perú/México
├─ Certificación TNFD        ├─ API Marketplace            ├─ AI Advisor v2
└─ Case studies              └─ 100 clientes               └─ 500 clientes
```

---

## Uso de Fondos

### Ronda Actual: $1.5M USD (Seed Extension)

| Área | % | Monto | Uso |
|------|---|-------|-----|
| **Producto** | 45% | $675K | Módulos v4.0, AI, integraciones |
| **Comercial** | 30% | $450K | Ventas Chile, expansion LATAM |
| **Operaciones** | 15% | $225K | Infraestructura, compliance |
| **G&A** | 10% | $150K | Legal, admin, contingencia |

### Hitos con la Inversión

- ✅ 100 clientes pagando (12 meses)
- ✅ $1M ARR (18 meses)
- ✅ Presencia en 3 países LATAM (24 meses)
- ✅ Preparación Series A (24 meses)

---

## Equipo

### Liderazgo

| Rol | Experiencia |
|-----|-------------|
| **CEO/Founder** | 18 años arquitectura/urbanismo, ex-CEPAL consulting |
| **CTO** | 12 años desarrollo, ex-fintech unicornio |
| **CFO** | 15 años banca, ex-gerente riesgo banco top-3 |
| **Head of Product** | 10 años PropTech, PhD econometría |

### Advisors

- Ex-regulador CMF (compliance)
- Partner Big4 (ESG advisory)
- Académico SEEA-EA (metodología capital natural)

---

## Métricas Clave

| KPI | Actual | Meta 12M | Meta 24M |
|-----|--------|----------|----------|
| MRR | $15K | $80K | $200K |
| Clientes | 12 | 100 | 280 |
| Churn | 8% | <5% | <3% |
| NPS | 42 | 50 | 60 |
| CAC Payback | 14 meses | 10 meses | 8 meses |

---

## Inversión Solicitada

### Términos Propuestos

- **Monto**: $1.5M USD
- **Instrumento**: SAFE / Equity (negociable)
- **Valoración Cap**: $8M USD pre-money
- **Uso primario**: Expansión comercial + producto v4.0

### Por Qué Ahora

1. **Ventana regulatoria**: TNFD se vuelve obligatorio 2025-2026
2. **v4.0 lista**: Producto diferenciado terminado
3. **Pipeline caliente**: 15 LOIs de instituciones financieras
4. **Competencia rezagada**: 18-24 meses de ventaja técnica

---

## Contacto

**DATAPOLIS SpA**  
Santiago, Chile

📧 inversores@datapolis.cl  
🌐 www.datapolis.cl  
📱 +56 9 XXXX XXXX

---

*Este documento es confidencial y destinado exclusivamente para potenciales inversionistas.*

*DATAPOLIS v4.0.0 - Febrero 2026*
