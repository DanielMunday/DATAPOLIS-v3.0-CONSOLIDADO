# DATAPOLIS v4.0 - Documento para Reguladores

## Resumen Ejecutivo

DATAPOLIS v4.0 es una plataforma tecnológica diseñada para cumplir con los marcos regulatorios chilenos e internacionales en materia de:

- **Finanzas abiertas** (NCG 514 CMF)
- **Riesgo de crédito** (Basel IV)
- **Plusvalías urbanas** (Ley 21.713)
- **Disclosure ambiental** (TNFD/TCFD)
- **Contabilidad ambiental** (SEEA-EA)

Este documento detalla cómo DATAPOLIS v4.0 implementa y facilita el cumplimiento de cada marco regulatorio.

---

## 1. NCG 514 CMF - Open Finance

### Normativa Aplicable
Norma de Carácter General 514 de la Comisión para el Mercado Financiero (CMF), que establece el Sistema de Finanzas Abiertas en Chile.

### Implementación en DATAPOLIS

#### Módulo M01-OF: Open Finance

| Requisito NCG 514 | Implementación DATAPOLIS | Estado |
|-------------------|-------------------------|--------|
| **Art. 3** - Estándar FAPI 2.0 | OAuth 2.0 + MTLS certificados | ✅ Cumple |
| **Art. 5** - Consentimiento cliente | UI de consentimiento granular | ✅ Cumple |
| **Art. 7** - Trazabilidad | Logs inmutables con timestamps | ✅ Cumple |
| **Art. 9** - APIs estandarizadas | OpenAPI 3.0, endpoints versionados | ✅ Cumple |
| **Art. 12** - Seguridad | Cifrado AES-256, TLS 1.3 | ✅ Cumple |

#### Evidencia de Cumplimiento

```
Endpoints NCG 514:
POST /api/v1/open-finance/consent
GET  /api/v1/open-finance/accounts
GET  /api/v1/open-finance/transactions
POST /api/v1/open-finance/revoke

Certificaciones:
- TLS 1.3 con cipher suites aprobados
- Certificados X.509 para MTLS
- Tokens JWT con expiración configurable
```

---

## 2. Basel IV - Riesgo de Crédito

### Normativa Aplicable
Basilea IV (CRR3/CRD VI), implementado en Chile a través de normativa SBIF/CMF para entidades fiscalizadas.

### Implementación en DATAPOLIS

#### Módulo M03: Credit Scoring Basel IV

| Componente Basel IV | Implementación | Metodología |
|--------------------|----------------|-------------|
| **PD** (Probability of Default) | Modelo logístico + ML | Through-the-cycle |
| **LGD** (Loss Given Default) | Modelo por tipo de garantía | Downturn LGD |
| **EAD** (Exposure at Default) | CCF por producto | Enfoque IRB |
| **RWA** | Cálculo automático | SA + IRB Foundation |

#### Módulo M04: Valorización para Colaterales

| Requisito | Implementación | Compliance |
|-----------|---------------|------------|
| Valoración independiente | Separación de roles | ✅ |
| Metodologías aceptadas | Market, Income, Cost | ✅ |
| Haircuts conservadores | Tablas parametrizables | ✅ |
| Reevaluación periódica | Alertas automáticas | ✅ |

#### Módulo M-HED: Precios Hedónicos

El modelo hedónico complementa las valoraciones tradicionales proporcionando:

- Descomposición transparente del valor
- Justificación estadística de ajustes
- Detección de outliers
- Sensibilidad a cambios de mercado

```
Ejemplo de output para auditoría:
─────────────────────────────────
Variable          Coef.      p-value   VIF
─────────────────────────────────
superficie_m2     0.0082     0.001     2.1
dormitorios       0.0543     0.003     1.8
dist_metro        -0.0012    0.021     1.4
─────────────────────────────────
R² = 0.78  |  AIC = 1245  |  N = 342
```

---

## 3. Ley 21.713 - Plusvalías Urbanas

### Normativa Aplicable
Ley 21.713 que modifica la Ley General de Urbanismo y Construcciones, estableciendo mecanismos de recuperación de plusvalías.

### Implementación en DATAPOLIS

#### Módulo GT-PV: Plusvalías Urbanas

| Componente Ley 21.713 | Implementación | Detalle |
|-----------------------|----------------|---------|
| **Cálculo de plusvalía** | Diferencia de valor antes/después | Metodología SII |
| **Hechos gravados** | Detector automático de cambios normativos | Integración MINVU |
| **Base imponible** | Cálculo por m² o % incremento | Configurable |
| **Trazabilidad** | Historial completo de valores | Auditable |

#### Integración con M-HED

El módulo hedónico permite:

1. **Antes del cambio normativo**: Estimar valor base con modelo calibrado
2. **Después del cambio**: Re-estimar con nuevas condiciones (ej: aumento de constructibilidad)
3. **Diferencia**: Cuantificar plusvalía atribuible al cambio

```
Ejemplo:
─────────────────────────────────────────
Estado          Valor Est.    IC 95%
─────────────────────────────────────────
Antes (COS 0.6) $85,000,000   ±$8,500,000
Después (COS 1.0) $120,000,000 ±$12,000,000
─────────────────────────────────────────
Plusvalía Bruta: $35,000,000
Plusvalía Neta (Ley 21.713): $28,000,000
```

---

## 4. TNFD - Disclosure Ambiental

### Marco Aplicable
Taskforce on Nature-related Financial Disclosures (TNFD), marco voluntario que se prevé obligatorio en Chile 2025-2026.

### Implementación en DATAPOLIS

#### Módulo M-NCA: Natural Capital Accounting

| Pilar TNFD | Implementación DATAPOLIS | Métricas |
|------------|-------------------------|----------|
| **Governance** | Roles y permisos ESG | Dashboard ejecutivo |
| **Strategy** | Escenarios de capital natural | Proyecciones a 30 años |
| **Risk Management** | Identificación de dependencias | Risk heat maps |
| **Metrics & Targets** | Indicadores SEEA-EA | Reportes automáticos |

#### Módulo M-ESV: Servicios Ecosistémicos

| Categoría TNFD | Servicios Cubiertos | Metodología |
|----------------|---------------------|-------------|
| **Dependencies** | Agua, regulación climática, polinización | Value transfer |
| **Impacts** | Cambio de uso de suelo, emisiones | Escenarios comparativos |
| **Risks** | Degradación de ecosistemas | Proyecciones de stock |
| **Opportunities** | Restauración, conservación | NPV de intervenciones |

#### Reporte TNFD Automatizado

```
DATAPOLIS genera automáticamente:

1. Extent metrics
   - Área de ecosistemas por tipo
   - Condición de activos naturales

2. State metrics
   - Índice de integridad ecosistémica
   - Tendencias de stock

3. Impact metrics
   - Cambio de uso de suelo
   - Huella de agua/biodiversidad

4. Dependency metrics
   - Servicios ecosistémicos utilizados
   - Valoración monetaria de dependencias
```

---

## 5. SEEA-EA - Contabilidad Ambiental

### Marco Aplicable
System of Environmental-Economic Accounting - Ecosystem Accounting (SEEA-EA), estándar de Naciones Unidas adoptado por Chile.

### Implementación en DATAPOLIS

#### Cuentas de Activos Naturales

| Tipo de Cuenta SEEA | Implementación | Unidades |
|--------------------|----------------|----------|
| **Extent accounts** | Superficie por ecosistema | Hectáreas |
| **Condition accounts** | Índice de condición | 0-100 |
| **Ecosystem services** | Flujos por servicio | USD/año |
| **Monetary accounts** | Valor presente | USD |

#### Modelos Bioeconómicos

DATAPOLIS implementa modelos reconocidos académicamente:

**Modelo de Schaefer (Recursos Renovables)**
```
dX/dt = r·X·(1 - X/K) - Y

Donde:
- X: Stock del recurso
- r: Tasa intrínseca de crecimiento
- K: Capacidad de carga
- Y: Extracción
```

**Control Óptimo Hamiltoniano**
```
H = π(X,E) + λ[F(X) - Y(E,X)]

El precio sombra λ representa el valor marginal
del recurso considerando escasez futura.
```

---

## 6. Auditoría y Trazabilidad

### Logs de Sistema

DATAPOLIS mantiene registros inmutables de:

| Evento | Datos Registrados | Retención |
|--------|-------------------|-----------|
| Valuaciones | Input, output, modelo, usuario, timestamp | 10 años |
| Cambios de parámetros | Valor anterior, nuevo, justificación | Permanente |
| Accesos | Usuario, IP, endpoint, resultado | 5 años |
| Reportes regulatorios | Hash del documento, destinatario | Permanente |

### Exportación para Fiscalización

```bash
# Generar paquete de auditoría
python scripts/audit_export.py \
  --desde 2025-01-01 \
  --hasta 2025-12-31 \
  --entidad "Banco XYZ" \
  --formato pdf,csv,json
```

Output incluye:
- Listado de valuaciones con metodología
- Parámetros de modelos utilizados
- Justificaciones de ajustes
- Logs de acceso relevantes

---

## 7. Certificaciones y Validaciones

### Validaciones Internas

| Validación | Frecuencia | Metodología |
|------------|------------|-------------|
| Backtesting modelos PD | Trimestral | Gini, KS, Brier Score |
| Calibración LGD | Semestral | Workout vs. estimado |
| Benchmark valuaciones | Mensual | vs. transacciones reales |
| Integridad datos | Continua | Checksums, reconciliación |

### Certificaciones Externas (En Proceso)

- ISO 27001 (Seguridad de la información)
- SOC 2 Type II (Controles de servicio)
- Certificación TNFD-aligned

---

## 8. Contacto Regulatorio

### Para Consultas de Fiscalizadores

**Oficial de Cumplimiento**  
📧 compliance@datapolis.cl  
📞 +56 2 XXXX XXXX

**Documentación Técnica**  
🔗 docs.datapolis.cl/regulatory

**Solicitudes de Información**  
Formulario: datapolis.cl/regulatory-request

---

## Anexos

### A. Mapeo de Endpoints por Regulación

```yaml
NCG_514:
  - POST /api/v1/open-finance/consent
  - GET /api/v1/open-finance/accounts
  
Basel_IV:
  - POST /api/v1/credit-scoring/pd
  - POST /api/v1/credit-scoring/lgd
  - GET /api/v1/credit-scoring/rwa
  
Ley_21713:
  - POST /api/v1/plusvalias/calculate
  - GET /api/v1/plusvalias/timeline
  
TNFD_SEEA:
  - POST /api/v1/natural-capital/accounts
  - GET /api/v1/natural-capital/tnfd-metrics
  - POST /api/v1/ecosystem-services/valuate
```

### B. Referencias Normativas

1. NCG 514 CMF (2023)
2. Basel Committee on Banking Supervision - Basel IV (2017)
3. Ley 21.713 Chile (2023)
4. TNFD Recommendations v1.0 (2023)
5. SEEA-EA UN (2021)
6. International Valuation Standards IVS (2022)

---

*DATAPOLIS v4.0.0 - Documento Regulatorio - Febrero 2026*
