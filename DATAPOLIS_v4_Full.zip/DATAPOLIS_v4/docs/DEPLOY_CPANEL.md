# DATAPOLIS v4.0 - Despliegue en cPanel

## Visión General

Esta guía detalla el proceso de despliegue de DATAPOLIS v4.0 en un servidor con cPanel, incluyendo la configuración de los backends FastAPI y Laravel, así como el frontend Vue.js.

---

## Requisitos del Servidor

### Mínimos
- **cPanel/WHM** versión 102+
- **PHP** 8.1+ con extensiones: mbstring, pdo_pgsql, curl, json
- **Python** 3.10+ (vía CloudLinux o virtualenv)
- **PostgreSQL** 14+ con PostGIS
- **Node.js** 18+ (para build de frontend)
- **SSL** certificado válido

### Recomendados
- RAM: 4GB+
- Almacenamiento: 50GB+ SSD
- Redis (para caché)

---

## Estructura de Directorios

```
/home/usuario/
├── public_html/                    # Frontend Vue.js (build)
│   ├── index.html
│   ├── assets/
│   └── .htaccess
├── api/                            # Backend FastAPI
│   ├── app/
│   ├── venv/
│   └── passenger_wsgi.py
├── laravel/                        # Backend Laravel
│   ├── app/
│   ├── public/
│   └── .env
└── logs/
    ├── fastapi.log
    └── laravel.log
```

---

## Paso 1: Preparar la Base de Datos

### 1.1 Crear Base de Datos PostgreSQL

En cPanel > PostgreSQL Databases:

```
Nombre: datapolis_prod
Usuario: datapolis_user
Contraseña: [contraseña_segura]
```

### 1.2 Habilitar PostGIS

```bash
# Conectar a PostgreSQL
psql -U datapolis_user -d datapolis_prod

# Crear extensiones
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
```

### 1.3 Ejecutar Migraciones

```bash
# Desde directorio Laravel
cd /home/usuario/laravel
php artisan migrate --force

# Desde directorio FastAPI (si aplica)
cd /home/usuario/api
source venv/bin/activate
alembic upgrade head
```

---

## Paso 2: Desplegar Backend FastAPI

### 2.1 Subir Código

```bash
cd /home/usuario/api
unzip backend_fastapi.zip
```

### 2.2 Crear Entorno Virtual

```bash
cd /home/usuario/api
python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### 2.3 Configurar Variables de Entorno

Crear `/home/usuario/api/.env`:

```env
# Database
DATABASE_URL=postgresql://datapolis_user:password@localhost:5432/datapolis_prod

# Security
SECRET_KEY=tu_clave_secreta_muy_larga_y_segura
API_KEY=clave_api_produccion

# CORS
CORS_ORIGINS=https://tudominio.cl,https://www.tudominio.cl

# Environment
ENVIRONMENT=production
DEBUG=false

# Redis (opcional)
REDIS_URL=redis://localhost:6379/0
```

### 2.4 Configurar Passenger (cPanel)

Crear `/home/usuario/api/passenger_wsgi.py`:

```python
import sys
import os

# Añadir directorio al path
sys.path.insert(0, os.path.dirname(__file__))

# Cargar variables de entorno
from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

# Activar virtualenv
VENV = os.path.join(os.path.dirname(__file__), 'venv')
python_path = os.path.join(VENV, 'lib', 'python3.11', 'site-packages')
sys.path.insert(0, python_path)

# Importar aplicación
from app.main import app as application
```

### 2.5 Configurar Subdominio para API

En cPanel > Subdomains:
- Subdominio: `api`
- Document Root: `/home/usuario/api`

En cPanel > Python Apps:
- Python Version: 3.11
- Application Root: /home/usuario/api
- Application URL: api.tudominio.cl
- Application Startup File: passenger_wsgi.py
- Application Entry Point: application

---

## Paso 3: Desplegar Backend Laravel

### 3.1 Subir Código

```bash
cd /home/usuario
unzip backend_laravel.zip -d laravel
```

### 3.2 Instalar Dependencias

```bash
cd /home/usuario/laravel
composer install --no-dev --optimize-autoloader
```

### 3.3 Configurar .env

```env
APP_NAME=DATAPOLIS
APP_ENV=production
APP_KEY=base64:GENERAR_CON_php_artisan_key:generate
APP_DEBUG=false
APP_URL=https://laravel.tudominio.cl

DB_CONNECTION=pgsql
DB_HOST=localhost
DB_PORT=5432
DB_DATABASE=datapolis_prod
DB_USERNAME=datapolis_user
DB_PASSWORD=tu_password

CACHE_DRIVER=redis
SESSION_DRIVER=redis
QUEUE_CONNECTION=redis

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379
```

### 3.4 Optimizar Laravel

```bash
cd /home/usuario/laravel
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan optimize
```

### 3.5 Configurar Subdominio Laravel

En cPanel > Subdomains:
- Subdominio: `laravel`
- Document Root: `/home/usuario/laravel/public`

Crear `/home/usuario/laravel/public/.htaccess`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteRule ^index\.php$ - [L]
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.php [L]
</IfModule>

# Headers de seguridad
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
</IfModule>
```

---

## Paso 4: Desplegar Frontend Vue.js

### 4.1 Build Local

En tu máquina local:

```bash
cd frontend

# Configurar variables de producción
cat > .env.production << EOF
VITE_API_URL=https://laravel.tudominio.cl/api/v1
VITE_FASTAPI_URL=https://api.tudominio.cl/api/v1
EOF

# Build
npm run build
```

### 4.2 Subir Build

```bash
# Comprimir dist
cd frontend
zip -r dist.zip dist/

# Subir via cPanel File Manager o SCP
scp dist.zip usuario@servidor:/home/usuario/
```

### 4.3 Desplegar en public_html

```bash
cd /home/usuario
unzip dist.zip
rm -rf public_html/*
mv dist/* public_html/
```

### 4.4 Configurar .htaccess

Crear `/home/usuario/public_html/.htaccess`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    
    # No reescribir archivos existentes
    RewriteCond %{REQUEST_FILENAME} -f [OR]
    RewriteCond %{REQUEST_FILENAME} -d
    RewriteRule ^ - [L]
    
    # SPA fallback
    RewriteRule ^ index.html [L]
</IfModule>

# Compresión GZIP
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/css application/json
    AddOutputFilterByType DEFLATE application/javascript text/xml application/xml
</IfModule>

# Caché de assets
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

---

## Paso 5: Configurar SSL

### 5.1 Usar AutoSSL de cPanel

En cPanel > SSL/TLS Status:
- Seleccionar todos los dominios
- Click "Run AutoSSL"

### 5.2 Forzar HTTPS

Añadir a cada `.htaccess`:

```apache
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

---

## Paso 6: Configurar Cron Jobs

En cPanel > Cron Jobs:

```bash
# Laravel Scheduler (cada minuto)
* * * * * cd /home/usuario/laravel && php artisan schedule:run >> /dev/null 2>&1

# Limpiar cache (diario a las 3am)
0 3 * * * cd /home/usuario/laravel && php artisan cache:clear

# Logs rotation (semanal)
0 0 * * 0 find /home/usuario/logs -name "*.log" -mtime +7 -delete
```

---

## Paso 7: Verificación

### 7.1 Endpoints de Health

```bash
# FastAPI
curl https://api.tudominio.cl/health

# Laravel
curl https://laravel.tudominio.cl/api/v1/health

# Frontend
curl https://tudominio.cl
```

### 7.2 Checklist de Verificación

- [ ] Frontend carga correctamente
- [ ] Login funciona
- [ ] API FastAPI responde en /health
- [ ] API Laravel responde en /api/v1/health
- [ ] Módulos v4.0 accesibles:
  - [ ] /hedonic
  - [ ] /ecosystem
  - [ ] /valuation-advisor
- [ ] SSL activo en todos los dominios
- [ ] Base de datos conectada
- [ ] Logs escribiendo correctamente

---

## Troubleshooting

### Error 500 en FastAPI
```bash
# Ver logs
tail -f /home/usuario/api/logs/error.log

# Verificar permisos
chmod -R 755 /home/usuario/api
```

### Error de conexión a DB
```bash
# Verificar credenciales
psql -U datapolis_user -d datapolis_prod -h localhost

# Verificar que PostGIS esté instalado
SELECT PostGIS_version();
```

### Frontend no carga assets
```bash
# Verificar rutas en build
grep -r "baseUrl" /home/usuario/public_html/assets/
```

---

## Mantenimiento

### Actualizar DATAPOLIS

```bash
# 1. Backup
pg_dump datapolis_prod > backup_$(date +%Y%m%d).sql

# 2. Desplegar nuevos archivos
# ... seguir pasos anteriores ...

# 3. Migrar DB si es necesario
php artisan migrate --force

# 4. Limpiar caches
php artisan cache:clear
php artisan config:cache
```

---

*Documento actualizado: DATAPOLIS v4.0.0 - Febrero 2026*
