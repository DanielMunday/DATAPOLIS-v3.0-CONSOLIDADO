# DATAPOLIS v4.0 – Despliegue Local

## Requisitos Previos

### Software
- Python 3.11+
- Node.js 20+
- PHP 8.2+ (opcional, para Laravel)
- PostgreSQL 15+ con PostGIS 3.3+
- Redis 7+
- Git

### Hardware Mínimo
- CPU: 4 cores
- RAM: 8 GB
- Disco: 20 GB SSD

---

## 1. Clonar Repositorio

```bash
git clone https://github.com/datapolis/datapolis.git
cd datapolis
```

O extraer desde ZIP:

```bash
unzip DATAPOLIS_v4_Full.zip
cd DATAPOLIS_v4
```

---

## 2. Configurar Base de Datos

### PostgreSQL + PostGIS

```bash
# Crear usuario y base de datos
sudo -u postgres psql

CREATE USER datapolis WITH PASSWORD 'tu_password_seguro';
CREATE DATABASE datapolis_db OWNER datapolis;
\c datapolis_db
CREATE EXTENSION postgis;
CREATE EXTENSION postgis_topology;
\q
```

### Redis

```bash
# Ubuntu/Debian
sudo apt install redis-server
sudo systemctl start redis
sudo systemctl enable redis

# Verificar
redis-cli ping  # Debe responder PONG
```

---

## 3. Backend FastAPI (Python)

### 3.1 Crear Entorno Virtual

```bash
cd backend/fastapi
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# o: venv\Scripts\activate  # Windows
```

### 3.2 Instalar Dependencias

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 3.3 Configurar Variables de Entorno

```bash
cp .env.example .env
```

Editar `.env`:

```env
# Database
DATABASE_URL=postgresql://datapolis:tu_password@localhost:5432/datapolis_db

# Redis
REDIS_URL=redis://localhost:6379/0

# Security
SECRET_KEY=genera-una-clave-segura-de-32-caracteres
JWT_SECRET_KEY=otra-clave-segura-diferente

# CORS
CORS_ORIGINS=http://localhost:5173,http://localhost:3000

# API
API_V1_PREFIX=/api/v1
DEBUG=true

# Hedonic Module
HEDONIC_DEFAULT_ALPHA=0.05
HEDONIC_VIF_THRESHOLD=10.0

# Ecosystem Services
ESV_DEFAULT_DISCOUNT_RATE=0.03
ESV_DEFAULT_TIME_HORIZON=30

# Environmental Hub
ENV_HUB_DATA_PATH=/path/to/environmental/data
```

### 3.4 Ejecutar Migraciones

```bash
alembic upgrade head
```

### 3.5 Iniciar Servidor

```bash
# Desarrollo
uvicorn app.main:app --reload --host 0.0.0.0 --port 8001

# Producción
uvicorn app.main:app --host 0.0.0.0 --port 8001 --workers 4
```

### 3.6 Verificar

```bash
curl http://localhost:8001/health
# Debe responder: {"status":"healthy","version":"4.0.0","edition":"Hedonic & Natural Capital"}
```

Documentación interactiva disponible en:
- Swagger UI: http://localhost:8001/docs
- ReDoc: http://localhost:8001/redoc

---

## 4. Backend Laravel (PHP) [Opcional]

### 4.1 Instalar Dependencias

```bash
cd backend/laravel
composer install
```

### 4.2 Configurar Entorno

```bash
cp .env.example .env
php artisan key:generate
```

Editar `.env`:

```env
APP_NAME=DATAPOLIS
APP_ENV=local
APP_DEBUG=true
APP_URL=http://localhost:8000

DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=datapolis_db
DB_USERNAME=datapolis
DB_PASSWORD=tu_password

CACHE_DRIVER=redis
QUEUE_CONNECTION=redis
SESSION_DRIVER=redis

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379
```

### 4.3 Migraciones y Seeders

```bash
php artisan migrate
php artisan db:seed
```

### 4.4 Iniciar Servidor

```bash
php artisan serve --host=0.0.0.0 --port=8000
```

---

## 5. Frontend Vue 3

### 5.1 Instalar Dependencias

```bash
cd frontend
npm install
```

### 5.2 Configurar Entorno

```bash
cp .env.example .env.local
```

Editar `.env.local`:

```env
VITE_API_URL=http://localhost:8000/api/v1
VITE_FASTAPI_URL=http://localhost:8001/api/v1
VITE_APP_TITLE=DATAPOLIS v4.0
```

### 5.3 Iniciar Servidor de Desarrollo

```bash
npm run dev
```

El frontend estará disponible en: http://localhost:5173

### 5.4 Build de Producción

```bash
npm run build
npm run preview  # Para probar el build
```

---

## 6. Ejecutar Tests

### Backend FastAPI

```bash
cd backend/fastapi
source venv/bin/activate
pytest tests/ -v --tb=short
```

### Tests v4.0 Específicos

```bash
pytest tests/test_hedonic.py -v
pytest tests/test_ecosystem_services.py -v
pytest tests/test_valuation_advisor.py -v
pytest tests/test_e2e_v4.py -v
```

### Frontend

```bash
cd frontend
npm run test:unit
```

---

## 7. Docker (Alternativo)

### 7.1 Docker Compose

```bash
docker-compose up -d
```

### 7.2 Verificar Servicios

```bash
docker-compose ps
docker-compose logs -f fastapi
```

---

## 8. Validación de Instalación

Ejecutar script de validación:

```bash
chmod +x scripts/validate_100_percent.sh
./scripts/validate_100_percent.sh
```

Debe mostrar:
```
✓ DATAPOLIS v4.0 - VALIDACIÓN EXITOSA (100%)
```

---

## 9. Troubleshooting

### Error: "GDAL not found"
```bash
# Ubuntu/Debian
sudo apt install gdal-bin libgdal-dev
pip install GDAL==$(gdal-config --version)
```

### Error: "PostGIS extension not available"
```bash
sudo apt install postgresql-15-postgis-3
```

### Error: "Redis connection refused"
```bash
sudo systemctl start redis
sudo systemctl status redis
```

### Error: "CORS blocked"
Verificar que `CORS_ORIGINS` en `.env` incluya la URL del frontend.

---

## 10. Puertos por Defecto

| Servicio | Puerto |
|----------|--------|
| Frontend Vue | 5173 |
| Backend Laravel | 8000 |
| Backend FastAPI | 8001 |
| PostgreSQL | 5432 |
| Redis | 6379 |

---

## Siguiente Paso

Una vez verificado el despliegue local, consultar `docs/DEPLOY_CPANEL.md` para despliegue en producción.
