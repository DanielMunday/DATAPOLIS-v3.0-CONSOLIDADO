/**
 * DATAPOLIS v4.0 - Vue Router Configuration
 * ==========================================
 * Rutas para módulos v3.0 + v4.0
 */

import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

// ============================================================
// VISTAS v3.0 (Existentes)
// ============================================================
const LoginView = () => import('@/views/LoginView.vue')
const DashboardView = () => import('@/views/DashboardView.vue')
const ExpedientesView = () => import('@/views/ExpedientesView.vue')
const PropiedadesView = () => import('@/views/PropiedadesView.vue')
const CopropiedadesView = () => import('@/views/CopropiedadesView.vue')
const CopropiedadDetailView = () => import('@/views/CopropiedadDetailView.vue')
const PlusvaliaView = () => import('@/views/PlusvaliaView.vue')
const AgoraView = () => import('@/views/AgoraView.vue')
const GiresView = () => import('@/views/GiresView.vue')
const OpenFinanceView = () => import('@/views/OpenFinanceView.vue')
const CreditScoringView = () => import('@/views/CreditScoringView.vue')

// ============================================================
// VISTAS v4.0 (Nuevas)
// ============================================================
const HedonicPanel = () => import('@/views/HedonicPanel.vue')
const EcosystemDashboard = () => import('@/views/EcosystemDashboard.vue')
const ValuationAdvisor = () => import('@/views/ValuationAdvisor.vue')
const NaturalCapitalView = () => import('@/views/NaturalCapitalView.vue')
const EnvironmentalHubView = () => import('@/views/EnvironmentalHubView.vue')

// ============================================================
// RUTAS
// ============================================================
const routes = [
  // Auth
  {
    path: '/login',
    name: 'login',
    component: LoginView,
    meta: { requiresAuth: false }
  },
  
  // Dashboard
  {
    path: '/',
    name: 'dashboard',
    component: DashboardView,
    meta: { requiresAuth: true }
  },
  
  // ============================================================
  // RUTAS v3.0 (PropTech)
  // ============================================================
  {
    path: '/expedientes',
    name: 'expedientes',
    component: ExpedientesView,
    meta: { requiresAuth: true, module: 'M00' }
  },
  {
    path: '/propiedades',
    name: 'propiedades',
    component: PropiedadesView,
    meta: { requiresAuth: true, module: 'M01' }
  },
  {
    path: '/copropiedades',
    name: 'copropiedades',
    component: CopropiedadesView,
    meta: { requiresAuth: true, module: 'M02' }
  },
  {
    path: '/copropiedades/:id',
    name: 'copropiedad-detail',
    component: CopropiedadDetailView,
    meta: { requiresAuth: true, module: 'M02' }
  },
  
  // ============================================================
  // RUTAS v3.0 (FinTech)
  // ============================================================
  {
    path: '/open-finance',
    name: 'open-finance',
    component: OpenFinanceView,
    meta: { requiresAuth: true, module: 'M01-OF' }
  },
  {
    path: '/credit-scoring',
    name: 'credit-scoring',
    component: CreditScoringView,
    meta: { requiresAuth: true, module: 'M03' }
  },
  
  // ============================================================
  // RUTAS v3.0 (RegTech)
  // ============================================================
  {
    path: '/plusvalia',
    name: 'plusvalia',
    component: PlusvaliaView,
    meta: { requiresAuth: true, module: 'GT-PV' }
  },
  
  // ============================================================
  // RUTAS v3.0 (GovTech)
  // ============================================================
  {
    path: '/agora',
    name: 'agora',
    component: AgoraView,
    meta: { requiresAuth: true, module: 'M22' }
  },
  {
    path: '/gires',
    name: 'gires',
    component: GiresView,
    meta: { requiresAuth: true, module: 'M17' }
  },
  
  // ============================================================
  // RUTAS v4.0 (Nuevas)
  // ============================================================
  {
    path: '/hedonic',
    name: 'hedonic',
    component: HedonicPanel,
    meta: { 
      requiresAuth: true, 
      module: 'M-HED',
      title: 'Análisis Hedónico',
      version: '4.0'
    }
  },
  {
    path: '/ecosystem',
    name: 'ecosystem',
    component: EcosystemDashboard,
    meta: { 
      requiresAuth: true, 
      module: 'M-ESV',
      title: 'Servicios Ecosistémicos',
      version: '4.0'
    }
  },
  {
    path: '/natural-capital',
    name: 'natural-capital',
    component: NaturalCapitalView,
    meta: { 
      requiresAuth: true, 
      module: 'M-NCA',
      title: 'Capital Natural',
      version: '4.0'
    }
  },
  {
    path: '/valuation-advisor',
    name: 'valuation-advisor',
    component: ValuationAdvisor,
    meta: { 
      requiresAuth: true, 
      module: 'M-VAD',
      title: 'Asistente de Valuación',
      version: '4.0'
    }
  },
  {
    path: '/environmental-hub',
    name: 'environmental-hub',
    component: EnvironmentalHubView,
    meta: { 
      requiresAuth: true, 
      module: 'M-ENV',
      title: 'Environmental Hub',
      version: '4.0'
    }
  },
  
  // ============================================================
  // CATCH ALL
  // ============================================================
  {
    path: '/:pathMatch(.*)*',
    redirect: '/'
  }
]

// ============================================================
// ROUTER INSTANCE
// ============================================================
const router = createRouter({
  history: createWebHistory(),
  routes
})

// ============================================================
// NAVIGATION GUARDS
// ============================================================
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()
  
  // Check if route requires authentication
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next({ name: 'login', query: { redirect: to.fullPath } })
  } else if (to.name === 'login' && authStore.isAuthenticated) {
    next({ name: 'dashboard' })
  } else {
    next()
  }
})

// Update document title
router.afterEach((to) => {
  const title = to.meta.title || 'DATAPOLIS'
  const version = to.meta.version ? ` (v${to.meta.version})` : ''
  document.title = `${title}${version} | DATAPOLIS`
})

export default router
