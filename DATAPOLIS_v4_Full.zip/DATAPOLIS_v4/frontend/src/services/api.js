/**
 * DATAPOLIS v4.0 - API Services
 * ==============================
 * Funciones para consumir endpoints v3.0 + v4.0
 */

import axios from 'axios'

// ============================================================
// CONFIGURACIÓN BASE
// ============================================================
const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1'
const FASTAPI_BASE = import.meta.env.VITE_FASTAPI_URL || 'http://localhost:8001/api/v1'

// Axios instances
const laravelApi = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
})

const fastApi = axios.create({
  baseURL: FASTAPI_BASE,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
})

// ============================================================
// INTERCEPTORS
// ============================================================
const setupInterceptors = (instance) => {
  // Request interceptor - add auth token
  instance.interceptors.request.use(
    (config) => {
      const token = localStorage.getItem('token')
      if (token) {
        config.headers.Authorization = `Bearer ${token}`
      }
      return config
    },
    (error) => Promise.reject(error)
  )

  // Response interceptor - handle errors
  instance.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response?.status === 401) {
        localStorage.removeItem('token')
        window.location.href = '/login'
      }
      return Promise.reject(error)
    }
  )
}

setupInterceptors(laravelApi)
setupInterceptors(fastApi)

// ============================================================
// SERVICIOS v3.0 (Existentes)
// ============================================================

// Auth Service
export const authService = {
  login: (credentials) => laravelApi.post('/auth/login', credentials),
  logout: () => laravelApi.post('/auth/logout'),
  me: () => laravelApi.get('/auth/me'),
  register: (data) => laravelApi.post('/auth/register', data)
}

// Expedientes Service
export const expedientesService = {
  list: (params) => laravelApi.get('/expedientes', { params }),
  get: (id) => laravelApi.get(`/expedientes/${id}`),
  create: (data) => laravelApi.post('/expedientes', data),
  update: (id, data) => laravelApi.put(`/expedientes/${id}`, data),
  delete: (id) => laravelApi.delete(`/expedientes/${id}`)
}

// Copropiedades Service
export const copropiedadesService = {
  list: (params) => laravelApi.get('/copropiedades', { params }),
  get: (id) => laravelApi.get(`/copropiedades/${id}`),
  dashboard: (id) => laravelApi.get(`/copropiedades/${id}/dashboard`),
  paeAnalyze: (id) => laravelApi.post(`/copropiedades/${id}/pae/analyze`),
  paeAlerts: (id) => laravelApi.get(`/copropiedades/${id}/pae/alerts`)
}

// Credit Scoring Service (FastAPI)
export const creditScoringService = {
  calculate: (data) => fastApi.post('/credit-scoring/calculate', data),
  getPD: (entityId) => fastApi.get(`/credit-scoring/pd/${entityId}`),
  getLGD: (entityId) => fastApi.get(`/credit-scoring/lgd/${entityId}`),
  getRWA: (entityId) => fastApi.get(`/credit-scoring/rwa/${entityId}`)
}

// Indicadores Service (FastAPI)
export const indicadoresService = {
  getUF: (fecha) => fastApi.get('/indicadores/uf', { params: { fecha } }),
  getUTM: (fecha) => fastApi.get('/indicadores/utm', { params: { fecha } }),
  getDolar: () => fastApi.get('/indicadores/dolar'),
  getHistorico: (tipo, params) => fastApi.get(`/indicadores/historico/${tipo}`, { params })
}

// ============================================================
// SERVICIOS v4.0 (Nuevos)
// ============================================================

/**
 * Hedonic Pricing Service (M-HED)
 * Modelos de precios hedónicos espaciales
 */
export const hedonicService = {
  estimate: async (data) => {
    const response = await fastApi.post('/hedonic/estimate', data)
    return response.data
  },
  
  compare: async (data) => {
    const response = await fastApi.post('/hedonic/compare', data)
    return response.data
  },
  
  predict: async (data) => {
    const response = await fastApi.post('/hedonic/predict', data)
    return response.data
  },
  
  getImplicitPrices: async (params) => {
    const response = await fastApi.get('/hedonic/implicit-prices', { params })
    return response.data
  },
  
  getDiagnosticsGuide: async () => {
    const response = await fastApi.get('/hedonic/diagnostics-guide')
    return response.data
  }
}

/**
 * Ecosystem Services Service (M-ESV)
 * Valoración de servicios ecosistémicos
 */
export const ecosystemService = {
  valuatePolygon: async (data) => {
    const response = await fastApi.post('/ecosystem-services/valuate', data)
    return response.data
  },
  
  projectImpact: async (data) => {
    const response = await fastApi.post('/ecosystem-services/project-impact', data)
    return response.data
  },
  
  compareScenarios: async (data) => {
    const response = await fastApi.post('/ecosystem-services/compare-scenarios', data)
    return response.data
  },
  
  getBiomes: async () => {
    const response = await fastApi.get('/ecosystem-services/biomes')
    return response.data
  },
  
  getBiomeServices: async (biomeType) => {
    const response = await fastApi.get(`/ecosystem-services/biomes/${biomeType}`)
    return response.data
  },
  
  getServices: async () => {
    const response = await fastApi.get('/ecosystem-services/services')
    return response.data
  },
  
  getMethodology: async () => {
    const response = await fastApi.get('/ecosystem-services/methodology')
    return response.data
  }
}

/**
 * Natural Capital Service (M-NCA)
 * Contabilidad de capital natural
 */
export const naturalCapitalService = {
  createAccount: async (data) => {
    const response = await fastApi.post('/natural-capital/accounts', data)
    return response.data
  },
  
  shadowPriceSchaefer: async (data) => {
    const response = await fastApi.post('/natural-capital/shadow-price/schaefer', data)
    return response.data
  },
  
  shadowPriceHamiltonian: async (params) => {
    const response = await fastApi.post('/natural-capital/shadow-price/hamiltonian', null, { params })
    return response.data
  },
  
  projectStock: async (data) => {
    const response = await fastApi.post('/natural-capital/stock-projection', data)
    return response.data
  },
  
  generateStatement: async (data) => {
    const response = await fastApi.post('/natural-capital/statement', data)
    return response.data
  },
  
  getTNFDMetrics: async (entityId) => {
    const response = await fastApi.get('/natural-capital/tnfd-metrics', { 
      params: { entity_id: entityId, include_sample_data: true } 
    })
    return response.data
  },
  
  getAssetTypes: async () => {
    const response = await fastApi.get('/natural-capital/asset-types')
    return response.data
  },
  
  getMethodology: async () => {
    const response = await fastApi.get('/natural-capital/methodology')
    return response.data
  }
}

/**
 * Valuation Advisor Service (M-VAD)
 * Asistente de métodos de valuación
 */
export const valuationAdvisorService = {
  recommend: async (data) => {
    const response = await fastApi.post('/valuation-advisor/recommend', data)
    return response.data
  },
  
  quickRecommendation: async (params) => {
    const response = await fastApi.get('/valuation-advisor/quick-recommendation', { params })
    return response.data
  },
  
  getMethods: async () => {
    const response = await fastApi.get('/valuation-advisor/methods')
    return response.data
  },
  
  getMethodDetails: async (method) => {
    const response = await fastApi.get(`/valuation-advisor/methods/${method}`)
    return response.data
  },
  
  getAssetTypes: async () => {
    const response = await fastApi.get('/valuation-advisor/asset-types')
    return response.data
  },
  
  getPurposes: async () => {
    const response = await fastApi.get('/valuation-advisor/purposes')
    return response.data
  },
  
  getComplianceMatrix: async () => {
    const response = await fastApi.get('/valuation-advisor/compliance-matrix')
    return response.data
  }
}

/**
 * Environmental Data Hub Service (M-ENV)
 * Hub de datos ambientales y ESG
 */
export const envHubService = {
  getProfile: async (lat, lng, radius = 1000) => {
    const response = await fastApi.get('/env-hub/profile', { 
      params: { latitude: lat, longitude: lng, radius_meters: radius } 
    })
    return response.data
  },
  
  getLayerData: async (layerType, bbox = null) => {
    const params = { layer_type: layerType }
    if (bbox) params.bbox = bbox.join(',')
    const response = await fastApi.get('/env-hub/layers', { params })
    return response.data
  },
  
  getTimeSeries: async (params) => {
    const response = await fastApi.get('/env-hub/time-series', { params })
    return response.data
  },
  
  getProximity: async (lat, lng, amenityType, maxDistance = 5) => {
    const response = await fastApi.get('/env-hub/proximity', { 
      params: { latitude: lat, longitude: lng, amenity_type: amenityType, max_distance_km: maxDistance } 
    })
    return response.data
  },
  
  getESGIndicators: async (lat, lng) => {
    const response = await fastApi.get('/env-hub/esg-indicators', { 
      params: { latitude: lat, longitude: lng } 
    })
    return response.data
  },
  
  getLayers: async () => {
    const response = await fastApi.get('/env-hub/layers/available')
    return response.data
  }
}

// ============================================================
// HEALTH CHECK
// ============================================================
export const healthService = {
  checkLaravel: () => laravelApi.get('/health'),
  checkFastAPI: () => fastApi.get('/health'),
  getModules: () => fastApi.get('/modules')
}

// ============================================================
// DEFAULT EXPORT
// ============================================================
export default {
  auth: authService,
  expedientes: expedientesService,
  copropiedades: copropiedadesService,
  creditScoring: creditScoringService,
  indicadores: indicadoresService,
  hedonic: hedonicService,
  ecosystem: ecosystemService,
  naturalCapital: naturalCapitalService,
  valuationAdvisor: valuationAdvisorService,
  envHub: envHubService,
  health: healthService
}
