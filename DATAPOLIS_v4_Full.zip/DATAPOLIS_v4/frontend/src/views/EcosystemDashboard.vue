<template>
  <div class="ecosystem-dashboard p-6 bg-gray-50 min-h-screen">
    <!-- Header -->
    <div class="mb-6">
      <h1 class="text-2xl font-bold text-gray-900">
        Servicios Ecosistémicos
      </h1>
      <p class="text-gray-600 mt-1">
        Valoración de servicios ecosistémicos y capital natural
      </p>
    </div>

    <!-- Tarjetas de Resumen -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <div class="bg-white rounded-lg shadow p-4">
        <div class="text-sm text-gray-500">Valor Anual Total</div>
        <div class="text-2xl font-bold text-green-600">
          {{ formatCurrency(totalAnnualValue, 'USD') }}
        </div>
        <div class="text-xs text-gray-400">USD/año</div>
      </div>
      
      <div class="bg-white rounded-lg shadow p-4">
        <div class="text-sm text-gray-500">Valor NPV (30 años)</div>
        <div class="text-2xl font-bold text-blue-600">
          {{ formatCurrency(totalNPV, 'USD') }}
        </div>
        <div class="text-xs text-gray-400">Tasa: 3%</div>
      </div>
      
      <div class="bg-white rounded-lg shadow p-4">
        <div class="text-sm text-gray-500">Área Total Analizada</div>
        <div class="text-2xl font-bold text-emerald-600">
          {{ formatNumber(totalArea, 0) }} ha
        </div>
      </div>
      
      <div class="bg-white rounded-lg shadow p-4">
        <div class="text-sm text-gray-500">Polígonos Valorados</div>
        <div class="text-2xl font-bold text-purple-600">
          {{ valuations.length }}
        </div>
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Panel de Entrada -->
      <div class="lg:col-span-1 space-y-4">
        <!-- Nueva Valoración -->
        <div class="bg-white rounded-lg shadow p-4">
          <h2 class="font-semibold text-gray-800 mb-4">Nueva Valoración</h2>
          
          <div class="space-y-4">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                ID del Polígono
              </label>
              <input v-model="newValuation.polygonId" type="text"
                     class="w-full border rounded-md p-2 text-sm"
                     placeholder="ej: parque_001">
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Área (hectáreas)
              </label>
              <input v-model.number="newValuation.area" type="number"
                     class="w-full border rounded-md p-2 text-sm"
                     min="0" step="0.1">
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Tipo de Bioma
              </label>
              <select v-model="newValuation.biomeType"
                      class="w-full border rounded-md p-2 text-sm">
                <option v-for="biome in biomes" :key="biome.code" :value="biome.code">
                  {{ biome.name }}
                </option>
              </select>
            </div>
            
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Región
              </label>
              <select v-model="newValuation.region"
                      class="w-full border rounded-md p-2 text-sm">
                <option value="zona_central">Zona Central</option>
                <option value="zona_sur">Zona Sur</option>
                <option value="zona_austral">Zona Austral</option>
                <option value="norte_chico">Norte Chico</option>
                <option value="norte_grande">Norte Grande</option>
              </select>
            </div>
            
            <button @click="addValuation" 
                    :disabled="loading || !isValidInput"
                    class="w-full bg-green-600 text-white py-2 px-4 rounded-md 
                           hover:bg-green-700 disabled:bg-gray-400 transition">
              {{ loading ? 'Valorando...' : 'Agregar Valoración' }}
            </button>
          </div>
        </div>

        <!-- Biomas Disponibles -->
        <div class="bg-white rounded-lg shadow p-4">
          <h3 class="font-semibold text-gray-800 mb-3">Biomas Disponibles</h3>
          <div class="space-y-2 max-h-64 overflow-y-auto">
            <div v-for="biome in biomes" :key="biome.code"
                 class="flex justify-between items-center p-2 bg-gray-50 rounded text-sm">
              <span>{{ biome.name }}</span>
              <span class="font-medium text-green-600">
                ${{ formatNumber(biome.value, 0) }}/ha/año
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Resultados -->
      <div class="lg:col-span-2 space-y-4">
        <!-- Lista de Valoraciones -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
          <div class="px-4 py-3 border-b bg-gray-50 flex justify-between items-center">
            <h3 class="font-semibold text-gray-800">Valoraciones</h3>
            <button v-if="valuations.length > 0" @click="clearValuations"
                    class="text-sm text-red-600 hover:text-red-800">
              Limpiar todo
            </button>
          </div>
          
          <div v-if="valuations.length === 0" class="p-8 text-center text-gray-500">
            No hay valoraciones. Agregue un polígono para comenzar.
          </div>
          
          <div v-else class="divide-y">
            <div v-for="(val, idx) in valuations" :key="idx"
                 class="p-4 hover:bg-gray-50">
              <div class="flex justify-between items-start">
                <div>
                  <div class="font-medium text-gray-900">{{ val.polygon_id }}</div>
                  <div class="text-sm text-gray-500">
                    {{ val.biome_type }} | {{ val.area_hectares }} ha
                  </div>
                </div>
                <div class="text-right">
                  <div class="font-semibold text-green-600">
                    {{ formatCurrency(val.total_annual_value_usd, 'USD') }}/año
                  </div>
                  <div class="text-sm text-blue-600">
                    NPV: {{ formatCurrency(val.npv_usd, 'USD') }}
                  </div>
                </div>
              </div>
              
              <!-- Desglose de Servicios -->
              <div class="mt-3 pt-3 border-t">
                <div class="text-xs text-gray-500 mb-2">Desglose por servicio:</div>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div v-for="service in val.services_breakdown" :key="service.service"
                       class="text-xs bg-gray-50 p-2 rounded">
                    <div class="text-gray-600 truncate">{{ formatServiceName(service.service) }}</div>
                    <div class="font-medium">${{ formatNumber(service.annual_value_usd_ha, 0) }}/ha</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Gráfico de Servicios -->
        <div v-if="valuations.length > 0" class="bg-white rounded-lg shadow p-4">
          <h3 class="font-semibold text-gray-800 mb-4">Distribución por Tipo de Servicio</h3>
          <div class="h-64 flex items-end justify-around gap-2">
            <div v-for="(value, service) in servicesSummary" :key="service"
                 class="flex flex-col items-center">
              <div class="bg-green-500 w-12 rounded-t transition-all duration-300"
                   :style="{ height: `${(value / maxServiceValue) * 200}px` }">
              </div>
              <div class="text-xs text-gray-600 mt-2 text-center max-w-16 truncate">
                {{ formatServiceName(service) }}
              </div>
              <div class="text-xs font-medium text-gray-800">
                ${{ formatNumber(value/1000, 0) }}k
              </div>
            </div>
          </div>
        </div>

        <!-- Información Metodológica -->
        <div class="bg-blue-50 rounded-lg p-4 border border-blue-200">
          <h4 class="font-medium text-blue-800 mb-2">📊 Metodología</h4>
          <ul class="text-sm text-blue-700 space-y-1">
            <li>• Valores basados en ESVD (Ecosystem Services Valuation Database)</li>
            <li>• Metodología de benefit transfer ajustada para Chile</li>
            <li>• NPV calculado con tasa de descuento del 3% a 30 años</li>
            <li>• Compatible con SEEA-EA y marcos TNFD</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ecosystemService } from '@/services/api'

// Estado
const loading = ref(false)
const valuations = ref([])

const newValuation = ref({
  polygonId: '',
  area: 10,
  biomeType: 'urban_green',
  region: 'zona_central'
})

const biomes = ref([
  { code: 'tropical_forest', name: 'Bosque Tropical', value: 6275 },
  { code: 'temperate_forest', name: 'Bosque Templado', value: 4275 },
  { code: 'wetland', name: 'Humedal', value: 8870 },
  { code: 'coastal', name: 'Zona Costera', value: 7665 },
  { code: 'urban_green', name: 'Áreas Verdes Urbanas', value: 5810 },
  { code: 'grassland', name: 'Pradera', value: 1680 },
  { code: 'freshwater', name: 'Agua Dulce', value: 6055 },
  { code: 'agricultural', name: 'Agrícola', value: 1955 }
])

// Computed
const isValidInput = computed(() => {
  return newValuation.value.polygonId.trim() !== '' && 
         newValuation.value.area > 0
})

const totalAnnualValue = computed(() => {
  return valuations.value.reduce((sum, v) => sum + v.total_annual_value_usd, 0)
})

const totalNPV = computed(() => {
  return valuations.value.reduce((sum, v) => sum + v.npv_usd, 0)
})

const totalArea = computed(() => {
  return valuations.value.reduce((sum, v) => sum + v.area_hectares, 0)
})

const servicesSummary = computed(() => {
  const summary = {}
  valuations.value.forEach(val => {
    val.services_breakdown?.forEach(s => {
      const key = s.service
      if (!summary[key]) summary[key] = 0
      summary[key] += s.annual_value_usd_ha * val.area_hectares
    })
  })
  return summary
})

const maxServiceValue = computed(() => {
  const values = Object.values(servicesSummary.value)
  return values.length > 0 ? Math.max(...values) : 1
})

// Métodos
const addValuation = async () => {
  loading.value = true
  
  try {
    const response = await ecosystemService.valuatePolygon({
      polygon_id: newValuation.value.polygonId,
      area_hectares: newValuation.value.area,
      biome_type: newValuation.value.biomeType,
      region: newValuation.value.region,
      discount_rate: 0.03,
      time_horizon_years: 30
    })
    
    valuations.value.push(response)
    
    // Reset form
    newValuation.value.polygonId = ''
    newValuation.value.area = 10
  } catch (e) {
    console.error('Error en valoración:', e)
    alert('Error al valorar el polígono')
  } finally {
    loading.value = false
  }
}

const clearValuations = () => {
  if (confirm('¿Eliminar todas las valoraciones?')) {
    valuations.value = []
  }
}

const formatNumber = (value, decimals = 2) => {
  if (value === null || value === undefined) return '-'
  return Number(value).toLocaleString('es-CL', { 
    maximumFractionDigits: decimals 
  })
}

const formatCurrency = (value, currency = 'USD') => {
  if (value === null || value === undefined) return '-'
  return new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: currency,
    maximumFractionDigits: 0
  }).format(value)
}

const formatServiceName = (service) => {
  return service.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
}

// Lifecycle
onMounted(async () => {
  // Cargar biomas disponibles
  try {
    const response = await ecosystemService.getBiomes()
    if (response && Array.isArray(response)) {
      biomes.value = response.map(b => ({
        code: b.biome_type,
        name: b.biome_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
        value: b.total_annual_value_usd_ha
      }))
    }
  } catch (e) {
    console.log('Usando biomas por defecto')
  }
})
</script>
