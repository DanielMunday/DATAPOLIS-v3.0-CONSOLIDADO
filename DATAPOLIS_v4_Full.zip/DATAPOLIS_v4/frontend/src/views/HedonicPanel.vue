<template>
  <div class="hedonic-panel p-6 bg-gray-50 min-h-screen">
    <!-- Header -->
    <div class="mb-6">
      <h1 class="text-2xl font-bold text-gray-900">
        Análisis Hedónico de Precios
      </h1>
      <p class="text-gray-600 mt-1">
        Estimación de modelos de precios hedónicos espaciales
      </p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <!-- Panel de Configuración -->
      <div class="lg:col-span-1 space-y-4">
        <div class="bg-white rounded-lg shadow p-4">
          <h2 class="font-semibold text-gray-800 mb-4">Configuración del Modelo</h2>
          
          <!-- Tipo de Modelo -->
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">
              Tipo de Modelo
            </label>
            <select v-model="config.modelType" 
                    class="w-full border rounded-md p-2 text-sm">
              <option value="ols_linear">OLS Lineal</option>
              <option value="log_linear">Log-Lineal</option>
              <option value="log_log">Log-Log</option>
              <option value="box_cox">Box-Cox</option>
            </select>
          </div>

          <!-- Variable Dependiente -->
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">
              Variable Dependiente
            </label>
            <select v-model="config.dependentVar" 
                    class="w-full border rounded-md p-2 text-sm">
              <option value="precio">Precio</option>
              <option value="precio_m2">Precio por m²</option>
              <option value="valor_uf">Valor UF</option>
            </select>
          </div>

          <!-- Variables Independientes -->
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">
              Variables Independientes
            </label>
            <div class="space-y-2 max-h-48 overflow-y-auto">
              <label v-for="v in availableVariables" :key="v.code" 
                     class="flex items-center">
                <input type="checkbox" v-model="config.independentVars" 
                       :value="v.code" class="mr-2">
                <span class="text-sm">{{ v.name }}</span>
              </label>
            </div>
          </div>

          <!-- Botón Estimar -->
          <button @click="runEstimation" 
                  :disabled="loading || config.independentVars.length === 0"
                  class="w-full bg-blue-600 text-white py-2 px-4 rounded-md 
                         hover:bg-blue-700 disabled:bg-gray-400 
                         disabled:cursor-not-allowed transition">
            <span v-if="loading">Estimando...</span>
            <span v-else>Estimar Modelo</span>
          </button>
        </div>

        <!-- Diagnósticos Rápidos -->
        <div v-if="result" class="bg-white rounded-lg shadow p-4">
          <h3 class="font-semibold text-gray-800 mb-3">Diagnósticos</h3>
          
          <div class="space-y-2 text-sm">
            <div class="flex justify-between">
              <span class="text-gray-600">R²:</span>
              <span class="font-medium">{{ formatNumber(result.diagnostics?.r_squared) }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">R² Ajustado:</span>
              <span class="font-medium">{{ formatNumber(result.diagnostics?.adj_r_squared) }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">AIC:</span>
              <span class="font-medium">{{ formatNumber(result.diagnostics?.aic, 0) }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">BIC:</span>
              <span class="font-medium">{{ formatNumber(result.diagnostics?.bic, 0) }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">Durbin-Watson:</span>
              <span class="font-medium">{{ formatNumber(result.diagnostics?.durbin_watson) }}</span>
            </div>
            
            <!-- Warnings -->
            <div v-if="result.diagnostics?.multicollinearity_warning" 
                 class="mt-3 p-2 bg-yellow-50 border border-yellow-200 rounded text-yellow-800">
              ⚠️ Multicolinealidad detectada (VIF > 10)
            </div>
            <div v-if="result.diagnostics?.spatial_autocorrelation" 
                 class="mt-2 p-2 bg-blue-50 border border-blue-200 rounded text-blue-800">
              🗺️ Autocorrelación espacial: {{ result.diagnostics.spatial_autocorrelation }}
            </div>
          </div>
        </div>
      </div>

      <!-- Panel de Resultados -->
      <div class="lg:col-span-2 space-y-4">
        <!-- Coeficientes -->
        <div v-if="result" class="bg-white rounded-lg shadow overflow-hidden">
          <div class="px-4 py-3 border-b bg-gray-50">
            <h3 class="font-semibold text-gray-800">Coeficientes Estimados</h3>
            <p class="text-sm text-gray-500">
              Modelo: {{ result.model_type }} | N = {{ result.n_observations }}
            </p>
          </div>
          
          <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
              <thead class="bg-gray-50">
                <tr>
                  <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                    Variable
                  </th>
                  <th class="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                    Coeficiente
                  </th>
                  <th class="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                    Std. Error
                  </th>
                  <th class="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                    t-stat
                  </th>
                  <th class="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                    p-value
                  </th>
                  <th class="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">
                    Sig.
                  </th>
                  <th class="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                    Precio Implícito
                  </th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-200">
                <tr v-for="coef in result.coefficients" :key="coef.variable"
                    :class="{ 'bg-green-50': coef.is_significant }">
                  <td class="px-4 py-2 text-sm font-medium text-gray-900">
                    {{ coef.variable }}
                  </td>
                  <td class="px-4 py-2 text-sm text-right text-gray-700">
                    {{ formatNumber(coef.coefficient, 4) }}
                  </td>
                  <td class="px-4 py-2 text-sm text-right text-gray-500">
                    {{ formatNumber(coef.std_error, 4) }}
                  </td>
                  <td class="px-4 py-2 text-sm text-right text-gray-700">
                    {{ formatNumber(coef.t_statistic, 2) }}
                  </td>
                  <td class="px-4 py-2 text-sm text-right text-gray-700">
                    {{ formatPValue(coef.p_value) }}
                  </td>
                  <td class="px-4 py-2 text-center">
                    <span v-if="coef.is_significant" 
                          class="inline-flex px-2 py-0.5 text-xs font-medium 
                                 rounded-full bg-green-100 text-green-800">
                      ✓
                    </span>
                  </td>
                  <td class="px-4 py-2 text-sm text-right text-gray-700">
                    {{ coef.implicit_price ? formatCurrency(coef.implicit_price) : '-' }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Elasticidades -->
        <div v-if="result" class="bg-white rounded-lg shadow p-4">
          <h3 class="font-semibold text-gray-800 mb-3">Elasticidades</h3>
          <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div v-for="coef in significantCoefficients" :key="coef.variable"
                 class="bg-gray-50 rounded-lg p-3 text-center">
              <div class="text-xs text-gray-500 mb-1">{{ coef.variable }}</div>
              <div class="text-lg font-semibold text-blue-600">
                {{ formatNumber(coef.elasticity, 3) }}
              </div>
            </div>
          </div>
        </div>

        <!-- VIF Scores -->
        <div v-if="result?.diagnostics?.vif_scores" class="bg-white rounded-lg shadow p-4">
          <h3 class="font-semibold text-gray-800 mb-3">Factor de Inflación de Varianza (VIF)</h3>
          <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div v-for="(vif, variable) in result.diagnostics.vif_scores" 
                 :key="variable"
                 class="rounded-lg p-2 text-center"
                 :class="vif > 10 ? 'bg-red-50' : vif > 5 ? 'bg-yellow-50' : 'bg-green-50'">
              <div class="text-xs text-gray-600">{{ variable }}</div>
              <div class="text-sm font-semibold"
                   :class="vif > 10 ? 'text-red-600' : vif > 5 ? 'text-yellow-600' : 'text-green-600'">
                {{ formatNumber(vif, 2) }}
              </div>
            </div>
          </div>
          <p class="text-xs text-gray-500 mt-2">
            VIF > 10 indica multicolinealidad severa | VIF > 5 indica multicolinealidad moderada
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { hedonicService } from '@/services/api'

// Estado
const loading = ref(false)
const result = ref(null)
const error = ref(null)

const config = ref({
  modelType: 'log_linear',
  dependentVar: 'precio',
  independentVars: ['superficie', 'dormitorios', 'banos']
})

const availableVariables = [
  { code: 'superficie', name: 'Superficie (m²)' },
  { code: 'dormitorios', name: 'Dormitorios' },
  { code: 'banos', name: 'Baños' },
  { code: 'estacionamientos', name: 'Estacionamientos' },
  { code: 'antiguedad', name: 'Antigüedad (años)' },
  { code: 'piso', name: 'Piso' },
  { code: 'distancia_metro', name: 'Distancia Metro (m)' },
  { code: 'distancia_parque', name: 'Distancia Parque (m)' },
  { code: 'indice_verde', name: 'Índice de Áreas Verdes' },
  { code: 'calidad_aire', name: 'Índice Calidad Aire' },
  { code: 'riesgo_inundacion', name: 'Riesgo Inundación' }
]

// Computed
const significantCoefficients = computed(() => {
  if (!result.value?.coefficients) return []
  return result.value.coefficients
    .filter(c => c.is_significant && c.variable !== 'const' && c.elasticity)
})

// Métodos
const runEstimation = async () => {
  loading.value = true
  error.value = null
  
  try {
    // Datos de ejemplo para demostración
    const sampleData = generateSampleData()
    
    const response = await hedonicService.estimate({
      data: sampleData,
      dependent_variable: config.value.dependentVar,
      independent_variables: config.value.independentVars,
      model_type: config.value.modelType,
      include_diagnostics: true
    })
    
    result.value = response
  } catch (e) {
    error.value = e.message
    console.error('Error en estimación:', e)
  } finally {
    loading.value = false
  }
}

const generateSampleData = () => {
  const data = []
  for (let i = 0; i < 100; i++) {
    const superficie = 50 + Math.random() * 150
    const dormitorios = Math.floor(1 + Math.random() * 4)
    const banos = Math.floor(1 + Math.random() * 3)
    const estacionamientos = Math.floor(Math.random() * 3)
    const antiguedad = Math.floor(Math.random() * 30)
    const piso = Math.floor(1 + Math.random() * 20)
    const distancia_metro = 100 + Math.random() * 2000
    const distancia_parque = 50 + Math.random() * 1000
    const indice_verde = Math.random() * 100
    const calidad_aire = 20 + Math.random() * 80
    const riesgo_inundacion = Math.random() * 5
    
    // Precio simulado con relación hedónica
    const precio = 50000000 + 
                   superficie * 800000 + 
                   dormitorios * 15000000 + 
                   banos * 8000000 +
                   estacionamientos * 10000000 -
                   antiguedad * 500000 +
                   piso * 300000 -
                   distancia_metro * 5000 -
                   distancia_parque * 2000 +
                   indice_verde * 100000 -
                   calidad_aire * 50000 -
                   riesgo_inundacion * 5000000 +
                   (Math.random() - 0.5) * 20000000
    
    data.push({
      precio: Math.max(30000000, precio),
      superficie, dormitorios, banos, estacionamientos,
      antiguedad, piso, distancia_metro, distancia_parque,
      indice_verde, calidad_aire, riesgo_inundacion
    })
  }
  return data
}

const formatNumber = (value, decimals = 4) => {
  if (value === null || value === undefined) return '-'
  return Number(value).toFixed(decimals)
}

const formatPValue = (value) => {
  if (value === null || value === undefined) return '-'
  if (value < 0.001) return '< 0.001'
  return value.toFixed(4)
}

const formatCurrency = (value) => {
  if (value === null || value === undefined) return '-'
  return new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    maximumFractionDigits: 0
  }).format(value)
}
</script>
