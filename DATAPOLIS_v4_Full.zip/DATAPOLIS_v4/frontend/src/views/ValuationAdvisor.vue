<template>
  <div class="valuation-advisor p-6 bg-gray-50 min-h-screen">
    <!-- Header -->
    <div class="mb-6">
      <h1 class="text-2xl font-bold text-gray-900">
        Asistente de Métodos de Valuación
      </h1>
      <p class="text-gray-600 mt-1">
        Recomendación inteligente del método de valuación óptimo
      </p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <!-- Panel de Entrada -->
      <div class="space-y-4">
        <div class="bg-white rounded-lg shadow p-6">
          <h2 class="font-semibold text-gray-800 mb-4 text-lg">
            Contexto de la Valuación
          </h2>
          
          <div class="space-y-4">
            <!-- Tipo de Activo -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Tipo de Activo *
              </label>
              <select v-model="context.assetType"
                      class="w-full border rounded-md p-2.5">
                <option value="">Seleccione...</option>
                <option value="residential_property">Propiedad Residencial</option>
                <option value="commercial_property">Propiedad Comercial</option>
                <option value="industrial_property">Propiedad Industrial</option>
                <option value="land">Terreno</option>
                <option value="agricultural">Agrícola</option>
                <option value="development_site">Sitio de Desarrollo</option>
                <option value="natural_asset">Activo Natural</option>
                <option value="ecosystem">Ecosistema</option>
                <option value="portfolio">Portafolio</option>
              </select>
            </div>

            <!-- Propósito -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Propósito de la Valuación *
              </label>
              <select v-model="context.purpose"
                      class="w-full border rounded-md p-2.5">
                <option value="">Seleccione...</option>
                <option value="market_transaction">Transacción de Mercado</option>
                <option value="collateral">Colateral/Garantía Crediticia</option>
                <option value="financial_reporting">Reportes Financieros</option>
                <option value="tax_assessment">Evaluación Tributaria</option>
                <option value="expropriation">Expropiación</option>
                <option value="investment_analysis">Análisis de Inversión</option>
                <option value="esg_reporting">Reportes ESG</option>
                <option value="regulatory">Regulatorio</option>
              </select>
            </div>

            <!-- Horizonte Temporal -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Horizonte Temporal
              </label>
              <select v-model="context.timeHorizon"
                      class="w-full border rounded-md p-2.5">
                <option value="spot">Valor Actual (Spot)</option>
                <option value="short_term">Corto Plazo (&lt; 1 año)</option>
                <option value="medium_term">Mediano Plazo (1-5 años)</option>
                <option value="long_term">Largo Plazo (5-30 años)</option>
              </select>
            </div>

            <!-- Calidad de Datos -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Calidad de Datos Disponibles
              </label>
              <select v-model="context.dataQuality"
                      class="w-full border rounded-md p-2.5">
                <option value="excellent">Excelente</option>
                <option value="good">Buena</option>
                <option value="moderate">Moderada</option>
                <option value="limited">Limitada</option>
                <option value="poor">Pobre</option>
              </select>
            </div>

            <!-- Actividad del Mercado -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Actividad del Mercado
              </label>
              <select v-model="context.marketActivity"
                      class="w-full border rounded-md p-2.5">
                <option value="active">Activo</option>
                <option value="moderate">Moderado</option>
                <option value="limited">Limitado</option>
                <option value="none">Sin Actividad</option>
              </select>
            </div>

            <!-- Disponibilidad de Comparables -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Disponibilidad de Comparables: {{ context.comparableAvailability }}%
              </label>
              <input type="range" v-model="context.comparableAvailability"
                     min="0" max="100" step="10"
                     class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer">
            </div>

            <!-- ¿Genera Ingresos? -->
            <div class="flex items-center">
              <input type="checkbox" v-model="context.incomeProducing"
                     class="h-4 w-4 text-blue-600 rounded">
              <label class="ml-2 text-sm text-gray-700">
                El activo genera ingresos
              </label>
            </div>

            <!-- Requisito Regulatorio -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Requisito Regulatorio (opcional)
              </label>
              <input v-model="context.regulatoryRequirement" type="text"
                     class="w-full border rounded-md p-2.5"
                     placeholder="ej: NCG 514 CMF">
            </div>

            <!-- Botón -->
            <button @click="getRecommendation" 
                    :disabled="loading || !isValidInput"
                    class="w-full bg-blue-600 text-white py-3 px-4 rounded-md 
                           font-medium hover:bg-blue-700 disabled:bg-gray-400 
                           transition mt-4">
              {{ loading ? 'Analizando...' : 'Obtener Recomendación' }}
            </button>
          </div>
        </div>
      </div>

      <!-- Panel de Resultados -->
      <div class="space-y-4">
        <div v-if="!result" class="bg-white rounded-lg shadow p-8 text-center">
          <div class="text-gray-400 text-6xl mb-4">🎯</div>
          <p class="text-gray-500">
            Complete el formulario para obtener una recomendación personalizada
          </p>
        </div>

        <template v-else>
          <!-- Recomendación Principal -->
          <div class="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg shadow p-6 text-white">
            <div class="text-sm opacity-80 mb-1">Método Recomendado</div>
            <div class="text-2xl font-bold mb-2">
              {{ formatMethodName(result.primary_recommendation.method) }}
            </div>
            <div class="flex items-center gap-4 text-sm">
              <span class="bg-white/20 px-2 py-1 rounded">
                Score: {{ result.primary_recommendation.suitability_score }}/100
              </span>
              <span class="bg-white/20 px-2 py-1 rounded">
                {{ result.primary_recommendation.estimated_accuracy }}
              </span>
            </div>
            <p class="mt-3 text-sm opacity-90">
              {{ result.primary_recommendation.rationale }}
            </p>
            
            <!-- Compliance Badges -->
            <div class="flex gap-2 mt-4">
              <span v-if="result.primary_recommendation.ivs_aligned"
                    class="bg-green-500/80 px-2 py-0.5 rounded text-xs">
                ✓ IVS
              </span>
              <span v-if="result.primary_recommendation.rics_compliant"
                    class="bg-green-500/80 px-2 py-0.5 rounded text-xs">
                ✓ RICS
              </span>
              <span v-if="result.primary_recommendation.basel_compliant"
                    class="bg-green-500/80 px-2 py-0.5 rounded text-xs">
                ✓ Basel
              </span>
            </div>
          </div>

          <!-- Fortalezas y Limitaciones -->
          <div class="grid grid-cols-2 gap-4">
            <div class="bg-white rounded-lg shadow p-4">
              <h4 class="font-medium text-green-700 mb-2">✓ Fortalezas</h4>
              <ul class="text-sm text-gray-600 space-y-1">
                <li v-for="s in result.primary_recommendation.strengths" :key="s">
                  • {{ s }}
                </li>
              </ul>
            </div>
            
            <div class="bg-white rounded-lg shadow p-4">
              <h4 class="font-medium text-amber-700 mb-2">⚠ Limitaciones</h4>
              <ul class="text-sm text-gray-600 space-y-1">
                <li v-for="l in result.primary_recommendation.limitations" :key="l">
                  • {{ l }}
                </li>
              </ul>
            </div>
          </div>

          <!-- Alternativas -->
          <div v-if="result.alternative_recommendations.length > 0" 
               class="bg-white rounded-lg shadow p-4">
            <h4 class="font-medium text-gray-800 mb-3">Métodos Alternativos</h4>
            <div class="space-y-2">
              <div v-for="alt in result.alternative_recommendations" :key="alt.method"
                   class="flex justify-between items-center p-2 bg-gray-50 rounded">
                <span class="font-medium">{{ formatMethodName(alt.method) }}</span>
                <div class="flex items-center gap-2">
                  <span class="text-sm text-gray-500">
                    Score: {{ alt.suitability_score }}
                  </span>
                  <span class="text-xs px-2 py-0.5 bg-gray-200 rounded">
                    {{ alt.implementation_complexity }}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <!-- Enfoque Híbrido -->
          <div v-if="result.hybrid_approach" class="bg-purple-50 rounded-lg shadow p-4 border border-purple-200">
            <h4 class="font-medium text-purple-800 mb-2">💡 Enfoque Híbrido Sugerido</h4>
            <p class="text-sm text-purple-700">{{ result.hybrid_approach.description }}</p>
            <p class="text-xs text-purple-600 mt-2">{{ result.hybrid_approach.rationale }}</p>
          </div>

          <!-- Notas Regulatorias -->
          <div class="bg-amber-50 rounded-lg p-4 border border-amber-200">
            <h4 class="font-medium text-amber-800 mb-2">📋 Notas Regulatorias</h4>
            <p class="text-sm text-amber-700">{{ result.regulatory_notes }}</p>
          </div>

          <!-- Supuestos y Riesgos -->
          <div class="grid grid-cols-2 gap-4">
            <div class="bg-gray-50 rounded-lg p-4">
              <h4 class="font-medium text-gray-700 mb-2 text-sm">Supuestos Clave</h4>
              <ul class="text-xs text-gray-600 space-y-1">
                <li v-for="a in result.key_assumptions" :key="a">• {{ a }}</li>
              </ul>
            </div>
            
            <div class="bg-red-50 rounded-lg p-4">
              <h4 class="font-medium text-red-700 mb-2 text-sm">Factores de Riesgo</h4>
              <ul class="text-xs text-red-600 space-y-1">
                <li v-for="r in result.risk_factors" :key="r">• {{ r }}</li>
              </ul>
            </div>
          </div>

          <!-- Módulo DATAPOLIS -->
          <div class="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div class="flex items-center justify-between">
              <div>
                <span class="text-sm text-blue-600">Implementar con:</span>
                <span class="font-semibold text-blue-800 ml-2">
                  {{ result.primary_recommendation.datapolis_module }}
                </span>
              </div>
              <button class="bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700">
                Ir al Módulo →
              </button>
            </div>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { valuationAdvisorService } from '@/services/api'

// Estado
const loading = ref(false)
const result = ref(null)

const context = ref({
  assetType: '',
  purpose: '',
  timeHorizon: 'spot',
  dataQuality: 'moderate',
  marketActivity: 'moderate',
  incomeProducing: false,
  comparableAvailability: 50,
  regulatoryRequirement: ''
})

// Computed
const isValidInput = computed(() => {
  return context.value.assetType && context.value.purpose
})

// Métodos
const getRecommendation = async () => {
  loading.value = true
  
  try {
    const response = await valuationAdvisorService.recommend({
      asset_type: context.value.assetType,
      purpose: context.value.purpose,
      time_horizon: context.value.timeHorizon,
      data_quality: context.value.dataQuality,
      market_activity: context.value.marketActivity,
      income_producing: context.value.incomeProducing,
      comparable_availability: context.value.comparableAvailability,
      regulatory_requirement: context.value.regulatoryRequirement || null,
      special_considerations: [],
      budget_constraint: null,
      time_constraint: null
    })
    
    result.value = response
  } catch (e) {
    console.error('Error obteniendo recomendación:', e)
    alert('Error al obtener recomendación')
  } finally {
    loading.value = false
  }
}

const formatMethodName = (method) => {
  const names = {
    'market_comparison': 'Comparación de Mercado',
    'income_capitalization': 'Capitalización de Ingresos',
    'discounted_cash_flow': 'Flujo de Caja Descontado (DCF)',
    'cost_approach': 'Enfoque de Costos',
    'hedonic_pricing': 'Precios Hedónicos',
    'ml_ensemble': 'ML Ensemble',
    'ecosystem_services': 'Servicios Ecosistémicos',
    'natural_capital_accounting': 'Contabilidad de Capital Natural',
    'hybrid_ml_traditional': 'Híbrido ML + Tradicional'
  }
  return names[method] || method.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
}
</script>
