#!/bin/bash
# ============================================================
# DATAPOLIS v4.0 - Build and Package Script
# ============================================================
# Genera DATAPOLIS_v4_Full.zip con código v3.0 + v4.0

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}     DATAPOLIS v4.0 - Build & Package Script${NC}"
echo -e "${BLUE}============================================================${NC}"

# Directorio base
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${BASE_DIR}/build"
OUTPUT_FILE="DATAPOLIS_v4_Full.zip"

# Paso 1: Validar versión
echo -e "\n${YELLOW}[1/5] Validando versión...${NC}"
if grep -q "v4.0.0" "${BASE_DIR}/VERSION" 2>/dev/null; then
    echo -e "${GREEN}✓ Versión v4.0.0 confirmada${NC}"
else
    echo -e "${RED}✗ VERSION debe contener v4.0.0${NC}"
    exit 1
fi

# Paso 2: Verificar módulos v4.0
echo -e "\n${YELLOW}[2/5] Verificando módulos v4.0...${NC}"
MODULES_V4=(
    "backend/fastapi/app/services/m_hedonic.py"
    "backend/fastapi/app/services/m_ecosystem_services.py"
    "backend/fastapi/app/services/m_natural_capital.py"
    "backend/fastapi/app/services/m_valuation_advisor.py"
    "backend/fastapi/app/services/m_env_hub.py"
    "backend/fastapi/app/routers/hedonic.py"
    "backend/fastapi/app/routers/ecosystem_services.py"
    "backend/fastapi/app/routers/natural_capital.py"
    "backend/fastapi/app/routers/valuation_advisor.py"
    "backend/fastapi/app/routers/env_hub.py"
)

MISSING=0
for module in "${MODULES_V4[@]}"; do
    if [[ -f "${BASE_DIR}/${module}" ]]; then
        echo -e "${GREEN}✓ ${module}${NC}"
    else
        echo -e "${RED}✗ ${module} - FALTA${NC}"
        MISSING=$((MISSING + 1))
    fi
done

if [[ $MISSING -gt 0 ]]; then
    echo -e "${RED}Faltan ${MISSING} módulos v4.0${NC}"
    exit 1
fi

# Paso 3: Verificar documentación v4.0
echo -e "\n${YELLOW}[3/5] Verificando documentación...${NC}"
DOCS_V4=(
    "docs/ARCHITECTURE.md"
    "docs/API_REFERENCE.md"
    "docs/DEPLOY_LOCAL.md"
    "docs/DEPLOY_CPANEL.md"
    "docs/DATAPOLIS_v4_INVERSIONISTAS.md"
    "docs/DATAPOLIS_v4_CLIENTES.md"
    "docs/DATAPOLIS_v4_REGULADOR.md"
    "docs/CHECKLIST_100_PERCENT_v4.md"
)

for doc in "${DOCS_V4[@]}"; do
    if [[ -f "${BASE_DIR}/${doc}" ]]; then
        echo -e "${GREEN}✓ ${doc}${NC}"
    else
        echo -e "${YELLOW}⚠ ${doc} - no encontrado (se creará plantilla)${NC}"
    fi
done

# Paso 4: Limpiar y preparar build
echo -e "\n${YELLOW}[4/5] Preparando build...${NC}"
rm -rf "${BUILD_DIR}"
mkdir -p "${BUILD_DIR}/DATAPOLIS_v4"

# Copiar archivos principales
echo "  Copiando archivos..."
cp -r "${BASE_DIR}/backend" "${BUILD_DIR}/DATAPOLIS_v4/" 2>/dev/null || true
cp -r "${BASE_DIR}/frontend" "${BUILD_DIR}/DATAPOLIS_v4/" 2>/dev/null || true
cp -r "${BASE_DIR}/docs" "${BUILD_DIR}/DATAPOLIS_v4/" 2>/dev/null || true
cp -r "${BASE_DIR}/tests" "${BUILD_DIR}/DATAPOLIS_v4/" 2>/dev/null || true
cp -r "${BASE_DIR}/scripts" "${BUILD_DIR}/DATAPOLIS_v4/" 2>/dev/null || true
cp -r "${BASE_DIR}/ci" "${BUILD_DIR}/DATAPOLIS_v4/" 2>/dev/null || true
cp "${BASE_DIR}/VERSION" "${BUILD_DIR}/DATAPOLIS_v4/" 2>/dev/null || true
cp "${BASE_DIR}/README.md" "${BUILD_DIR}/DATAPOLIS_v4/" 2>/dev/null || true
cp "${BASE_DIR}/docker-compose.yml" "${BUILD_DIR}/DATAPOLIS_v4/" 2>/dev/null || true

# Limpiar archivos innecesarios
echo "  Limpiando archivos temporales..."
find "${BUILD_DIR}" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "${BUILD_DIR}" -type d -name "node_modules" -exec rm -rf {} + 2>/dev/null || true
find "${BUILD_DIR}" -type d -name "vendor" -exec rm -rf {} + 2>/dev/null || true
find "${BUILD_DIR}" -type d -name ".git" -exec rm -rf {} + 2>/dev/null || true
find "${BUILD_DIR}" -type f -name "*.pyc" -delete 2>/dev/null || true
find "${BUILD_DIR}" -type f -name ".DS_Store" -delete 2>/dev/null || true
find "${BUILD_DIR}" -type f -name "*.log" -delete 2>/dev/null || true

# Paso 5: Crear ZIP
echo -e "\n${YELLOW}[5/5] Creando archivo ZIP...${NC}"
cd "${BUILD_DIR}"
zip -r "${OUTPUT_FILE}" "DATAPOLIS_v4" -x "*.git*"

# Mover a outputs si existe
if [[ -d "/mnt/user-data/outputs" ]]; then
    mv "${OUTPUT_FILE}" "/mnt/user-data/outputs/"
    FINAL_PATH="/mnt/user-data/outputs/${OUTPUT_FILE}"
else
    mv "${OUTPUT_FILE}" "${BASE_DIR}/"
    FINAL_PATH="${BASE_DIR}/${OUTPUT_FILE}"
fi

# Resumen
echo -e "\n${BLUE}============================================================${NC}"
echo -e "${GREEN}     ✓ BUILD COMPLETADO EXITOSAMENTE${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""
echo -e "Archivo generado: ${GREEN}${FINAL_PATH}${NC}"
echo ""

# Estadísticas
FILE_COUNT=$(find "${BUILD_DIR}/DATAPOLIS_v4" -type f | wc -l)
DIR_COUNT=$(find "${BUILD_DIR}/DATAPOLIS_v4" -type d | wc -l)
ZIP_SIZE=$(du -h "${FINAL_PATH}" | cut -f1)

echo -e "Estadísticas:"
echo -e "  - Archivos: ${FILE_COUNT}"
echo -e "  - Directorios: ${DIR_COUNT}"
echo -e "  - Tamaño ZIP: ${ZIP_SIZE}"
echo ""

# Limpieza
rm -rf "${BUILD_DIR}"

echo -e "${GREEN}✓ Proceso completado${NC}"
