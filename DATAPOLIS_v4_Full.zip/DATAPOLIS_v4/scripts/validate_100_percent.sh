#!/bin/bash
# ============================================================
# DATAPOLIS v4.0 - Validation Script (100% Completeness)
# ============================================================

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Contadores
TOTAL_CHECKS=0
PASSED_CHECKS=0
WARNINGS=0

# Funciones
check_file() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    if [[ -f "$1" ]]; then
        echo -e "${GREEN}✓${NC} $1"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $1 - NO ENCONTRADO"
        return 1
    fi
}

check_dir() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    if [[ -d "$1" ]]; then
        echo -e "${GREEN}✓${NC} $1/"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $1/ - NO ENCONTRADO"
        return 1
    fi
}

warn_file() {
    if [[ -f "$1" ]]; then
        echo -e "${GREEN}✓${NC} $1"
    else
        echo -e "${YELLOW}⚠${NC} $1 - OPCIONAL"
        WARNINGS=$((WARNINGS + 1))
    fi
}

echo -e "${BLUE}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     DATAPOLIS v4.0 - VALIDACIÓN 100% COMPLETITUD         ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$BASE_DIR"

# ============================================================
# 1. METADATOS
# ============================================================
echo -e "${CYAN}[1/8] METADATOS${NC}"
echo "─────────────────────────────────────────────────"
check_file "VERSION"
check_file "README.md"

if grep -q "v4.0.0" "VERSION" 2>/dev/null; then
    echo -e "${GREEN}✓${NC} VERSION contiene v4.0.0"
    PASSED_CHECKS=$((PASSED_CHECKS + 1))
else
    echo -e "${RED}✗${NC} VERSION debe contener v4.0.0"
fi
TOTAL_CHECKS=$((TOTAL_CHECKS + 1))

# ============================================================
# 2. BACKEND FASTAPI - SERVICIOS v4.0
# ============================================================
echo ""
echo -e "${CYAN}[2/8] BACKEND FASTAPI - SERVICIOS v4.0${NC}"
echo "─────────────────────────────────────────────────"
check_file "backend/fastapi/app/services/m_hedonic.py"
check_file "backend/fastapi/app/services/m_ecosystem_services.py"
check_file "backend/fastapi/app/services/m_natural_capital.py"
check_file "backend/fastapi/app/services/m_valuation_advisor.py"
check_file "backend/fastapi/app/services/m_env_hub.py"

# ============================================================
# 3. BACKEND FASTAPI - ROUTERS v4.0
# ============================================================
echo ""
echo -e "${CYAN}[3/8] BACKEND FASTAPI - ROUTERS v4.0${NC}"
echo "─────────────────────────────────────────────────"
check_file "backend/fastapi/app/routers/hedonic.py"
check_file "backend/fastapi/app/routers/ecosystem_services.py"
check_file "backend/fastapi/app/routers/natural_capital.py"
check_file "backend/fastapi/app/routers/valuation_advisor.py"
check_file "backend/fastapi/app/routers/env_hub.py"
check_file "backend/fastapi/app/main.py"
check_file "backend/fastapi/requirements.txt"

# ============================================================
# 4. BACKEND FASTAPI - SCHEMAS v4.0
# ============================================================
echo ""
echo -e "${CYAN}[4/8] BACKEND FASTAPI - SCHEMAS v4.0${NC}"
echo "─────────────────────────────────────────────────"
warn_file "backend/fastapi/app/schemas/hedonic.py"
warn_file "backend/fastapi/app/schemas/ecosystem_services.py"
warn_file "backend/fastapi/app/schemas/natural_capital.py"
warn_file "backend/fastapi/app/schemas/valuation_advisor.py"
warn_file "backend/fastapi/openapi.yaml"

# ============================================================
# 5. FRONTEND VUE 3 - VISTAS v4.0
# ============================================================
echo ""
echo -e "${CYAN}[5/8] FRONTEND VUE 3 - VISTAS v4.0${NC}"
echo "─────────────────────────────────────────────────"
check_file "frontend/src/views/HedonicPanel.vue"
check_file "frontend/src/views/EcosystemDashboard.vue"
check_file "frontend/src/views/ValuationAdvisor.vue"
check_file "frontend/src/router/index.js"
check_file "frontend/src/services/api.js"

# ============================================================
# 6. TESTS v4.0
# ============================================================
echo ""
echo -e "${CYAN}[6/8] TESTS v4.0${NC}"
echo "─────────────────────────────────────────────────"
check_file "tests/test_hedonic.py"
check_file "tests/test_ecosystem_services.py"
check_file "tests/test_valuation_advisor.py"
check_file "tests/test_e2e_v4.py"

# ============================================================
# 7. DOCUMENTACIÓN v4.0
# ============================================================
echo ""
echo -e "${CYAN}[7/8] DOCUMENTACIÓN v4.0${NC}"
echo "─────────────────────────────────────────────────"
check_file "docs/ARCHITECTURE.md"
check_file "docs/API_REFERENCE.md"
check_file "docs/DEPLOY_LOCAL.md"
check_file "docs/DEPLOY_CPANEL.md"
check_file "docs/DATAPOLIS_v4_INVERSIONISTAS.md"
check_file "docs/DATAPOLIS_v4_CLIENTES.md"
check_file "docs/DATAPOLIS_v4_REGULADOR.md"
check_file "docs/CHECKLIST_100_PERCENT_v4.md"

# ============================================================
# 8. CI/CD & SCRIPTS
# ============================================================
echo ""
echo -e "${CYAN}[8/8] CI/CD & SCRIPTS${NC}"
echo "─────────────────────────────────────────────────"
check_file "scripts/build_and_zip.sh"
check_file "scripts/validate_100_percent.sh"
warn_file "ci/.github/workflows/ci.yml"
warn_file "docker-compose.yml"

# ============================================================
# RESUMEN
# ============================================================
echo ""
echo -e "${BLUE}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                      RESUMEN                              ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

PERCENTAGE=$((PASSED_CHECKS * 100 / TOTAL_CHECKS))

echo -e "  Checks realizados: ${TOTAL_CHECKS}"
echo -e "  Checks pasados:    ${GREEN}${PASSED_CHECKS}${NC}"
echo -e "  Warnings:          ${YELLOW}${WARNINGS}${NC}"
echo -e "  Completitud:       ${PERCENTAGE}%"
echo ""

if [[ $PERCENTAGE -ge 90 ]]; then
    echo -e "${GREEN}╔═══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║  ✓ DATAPOLIS v4.0 - VALIDACIÓN EXITOSA (${PERCENTAGE}%)              ║${NC}"
    echo -e "${GREEN}╚═══════════════════════════════════════════════════════════╝${NC}"
    exit 0
elif [[ $PERCENTAGE -ge 70 ]]; then
    echo -e "${YELLOW}╔═══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║  ⚠ DATAPOLIS v4.0 - VALIDACIÓN PARCIAL (${PERCENTAGE}%)              ║${NC}"
    echo -e "${YELLOW}╚═══════════════════════════════════════════════════════════╝${NC}"
    exit 0
else
    echo -e "${RED}╔═══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${RED}║  ✗ DATAPOLIS v4.0 - VALIDACIÓN FALLIDA (${PERCENTAGE}%)               ║${NC}"
    echo -e "${RED}╚═══════════════════════════════════════════════════════════╝${NC}"
    exit 1
fi
