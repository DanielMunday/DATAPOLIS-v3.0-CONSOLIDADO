"""
DATAPOLIS v4.0 - Tests End-to-End
==================================
Flujo completo: expediente → valorización hedónica + servicios ecosistémicos + 
recomendación de método → capital natural.
"""

import pytest
import httpx
import os
from datetime import datetime

# Configuración
BASE_URL = os.getenv("FASTAPI_URL", "http://localhost:8001/api/v1")


@pytest.fixture
def client():
    """Cliente HTTP para tests."""
    return httpx.Client(base_url=BASE_URL, timeout=30)


class TestHealthChecks:
    """Tests de health check."""
    
    def test_api_health(self, client):
        """Verificar que la API responde."""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "4.0" in data.get("version", "")
        

class TestHedonicEndpoints:
    """Tests de endpoints hedónicos."""
    
    def test_hedonic_estimate(self, client):
        """Test de estimación hedónica."""
        # Datos de ejemplo
        sample_data = [
            {"precio": 150000000, "superficie": 80, "dormitorios": 3},
            {"precio": 180000000, "superficie": 95, "dormitorios": 3},
            {"precio": 120000000, "superficie": 65, "dormitorios": 2},
            {"precio": 200000000, "superficie": 110, "dormitorios": 4},
            {"precio": 160000000, "superficie": 85, "dormitorios": 3},
        ]
        
        response = client.post("/hedonic/estimate", json={
            "data": sample_data,
            "dependent_variable": "precio",
            "independent_variables": ["superficie", "dormitorios"],
            "model_type": "ols_linear",
            "include_diagnostics": True
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "coefficients" in data
        assert "diagnostics" in data
        assert data["model_type"] == "ols_linear"
        
    def test_hedonic_compare(self, client):
        """Test de comparación de modelos."""
        sample_data = [
            {"precio": 150000000, "superficie": 80, "dormitorios": 3},
            {"precio": 180000000, "superficie": 95, "dormitorios": 3},
            {"precio": 120000000, "superficie": 65, "dormitorios": 2},
            {"precio": 200000000, "superficie": 110, "dormitorios": 4},
            {"precio": 160000000, "superficie": 85, "dormitorios": 3},
        ]
        
        response = client.post("/hedonic/compare", json={
            "data": sample_data,
            "dependent_variable": "precio",
            "independent_variables": ["superficie", "dormitorios"]
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "comparison" in data
        assert "best_model" in data


class TestEcosystemServicesEndpoints:
    """Tests de endpoints de servicios ecosistémicos."""
    
    def test_valuate_polygon(self, client):
        """Test de valoración de polígono."""
        response = client.post("/ecosystem-services/valuate", json={
            "polygon_id": "test_e2e_001",
            "area_hectares": 25.5,
            "biome_type": "urban_green",
            "region": "zona_central",
            "discount_rate": 0.03,
            "time_horizon_years": 30
        })
        
        assert response.status_code == 200
        data = response.json()
        assert data["polygon_id"] == "test_e2e_001"
        assert data["total_annual_value_usd"] > 0
        assert data["npv_usd"] > 0
        assert len(data["services_breakdown"]) > 0
        
    def test_biomes_list(self, client):
        """Test de listado de biomas."""
        response = client.get("/ecosystem-services/biomes")
        
        assert response.status_code == 200
        data = response.json()
        assert len(data) > 0
        
    def test_project_impact(self, client):
        """Test de evaluación de impacto."""
        response = client.post("/ecosystem-services/project-impact", json={
            "project_id": "proyecto_e2e",
            "affected_areas": [
                {
                    "id": "area_1",
                    "biome_type": "urban_green",
                    "area_hectares": 5,
                    "change_factor": 0.5
                }
            ],
            "scenario": "with_project"
        })
        
        assert response.status_code == 200
        data = response.json()
        assert data["project_id"] == "proyecto_e2e"


class TestNaturalCapitalEndpoints:
    """Tests de endpoints de capital natural."""
    
    def test_create_account(self, client):
        """Test de creación de cuenta de activo."""
        response = client.post("/natural-capital/accounts", json={
            "asset_id": "bosque_e2e_001",
            "asset_type": "timber_resources",
            "name": "Bosque Nativo Test",
            "location": "Región de Los Ríos",
            "area_hectares": 100,
            "stock_physical": 10000,
            "stock_unit": "m3",
            "opening_stock_monetary": 1500000
        })
        
        assert response.status_code == 200
        data = response.json()
        assert data["asset_id"] == "bosque_e2e_001"
        assert data["shadow_price_usd"] > 0
        
    def test_schaefer_shadow_price(self, client):
        """Test de precio sombra con modelo Schaefer."""
        response = client.post("/natural-capital/shadow-price/schaefer", json={
            "carrying_capacity": 10000,
            "intrinsic_growth_rate": 0.3,
            "catchability_coefficient": 0.001,
            "current_stock": 7000,
            "current_effort": 100,
            "price_per_unit": 500,
            "cost_per_effort": 1000,
            "discount_rate": 0.03
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "shadow_price_usd" in data
        assert "sustainability_index" in data


class TestValuationAdvisorEndpoints:
    """Tests de endpoints del advisor."""
    
    def test_get_recommendation(self, client):
        """Test de obtención de recomendación."""
        response = client.post("/valuation-advisor/recommend", json={
            "asset_type": "residential_property",
            "purpose": "collateral",
            "time_horizon": "spot",
            "data_quality": "good",
            "market_activity": "active",
            "income_producing": False,
            "comparable_availability": 75
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "primary_recommendation" in data
        assert data["primary_recommendation"]["method"] is not None
        assert data["primary_recommendation"]["suitability_score"] > 0
        
    def test_quick_recommendation(self, client):
        """Test de recomendación rápida."""
        response = client.get("/valuation-advisor/quick-recommendation", params={
            "asset_type": "land",
            "purpose": "market_transaction",
            "comparable_availability": 60
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "recommended_method" in data
        
    def test_list_methods(self, client):
        """Test de listado de métodos."""
        response = client.get("/valuation-advisor/methods")
        
        assert response.status_code == 200
        data = response.json()
        assert len(data) > 0


class TestEnvironmentalHubEndpoints:
    """Tests de endpoints del Environmental Hub."""
    
    def test_environmental_profile(self, client):
        """Test de perfil ambiental."""
        response = client.get("/env-hub/profile", params={
            "latitude": -33.4489,
            "longitude": -70.6693,
            "radius_meters": 1000
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "esg_score" in data
        assert "layers_data" in data
        
    def test_esg_indicators(self, client):
        """Test de indicadores ESG."""
        response = client.get("/env-hub/esg-indicators", params={
            "latitude": -33.4489,
            "longitude": -70.6693
        })
        
        assert response.status_code == 200
        data = response.json()
        assert "overall_esg_score" in data
        assert "environmental" in data


class TestIntegratedFlow:
    """Tests de flujo integrado completo v4.0."""
    
    def test_full_valuation_flow(self, client):
        """
        Flujo completo de valoración integrando módulos v4.0:
        1. Obtener perfil ambiental de ubicación
        2. Valorar servicios ecosistémicos del área
        3. Obtener recomendación de método de valuación
        4. Estimar modelo hedónico
        """
        # 1. Perfil ambiental
        env_response = client.get("/env-hub/profile", params={
            "latitude": -33.45,
            "longitude": -70.65,
            "radius_meters": 500
        })
        assert env_response.status_code == 200
        env_data = env_response.json()
        esg_score = env_data.get("esg_score", 0)
        
        # 2. Servicios ecosistémicos
        eco_response = client.post("/ecosystem-services/valuate", json={
            "polygon_id": "flow_test_001",
            "area_hectares": 10,
            "biome_type": "urban_green",
            "region": "zona_central"
        })
        assert eco_response.status_code == 200
        eco_data = eco_response.json()
        ecosystem_value = eco_data.get("total_annual_value_usd", 0)
        
        # 3. Recomendación de método
        advisor_response = client.post("/valuation-advisor/recommend", json={
            "asset_type": "residential_property",
            "purpose": "market_transaction",
            "time_horizon": "spot",
            "data_quality": "good",
            "market_activity": "active",
            "income_producing": False,
            "comparable_availability": 70
        })
        assert advisor_response.status_code == 200
        advisor_data = advisor_response.json()
        recommended_method = advisor_data["primary_recommendation"]["method"]
        
        # 4. Estimación hedónica
        hedonic_response = client.post("/hedonic/estimate", json={
            "data": [
                {"precio": 150000000, "superficie": 80, "esg_score": esg_score},
                {"precio": 180000000, "superficie": 95, "esg_score": esg_score + 5},
                {"precio": 120000000, "superficie": 65, "esg_score": esg_score - 5},
            ],
            "dependent_variable": "precio",
            "independent_variables": ["superficie", "esg_score"],
            "model_type": "ols_linear"
        })
        assert hedonic_response.status_code == 200
        
        # Verificar integración
        print(f"\n=== Flujo Integrado v4.0 ===")
        print(f"ESG Score de ubicación: {esg_score}")
        print(f"Valor ecosistémico anual: ${ecosystem_value:,.0f} USD")
        print(f"Método recomendado: {recommended_method}")
        print(f"Modelo hedónico estimado: OK")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
