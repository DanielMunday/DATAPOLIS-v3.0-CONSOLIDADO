"""
DATAPOLIS v4.0 - Tests del Módulo de Servicios Ecosistémicos (M-ESV)
=====================================================================
Tests de valoración de servicios ecosistémicos.
"""

import pytest
from app.services.m_ecosystem_services import (
    EcosystemServicesService, BiomeType, EcosystemService,
    EcosystemValuationResult
)


@pytest.fixture
def ecosystem_service():
    """Instancia del servicio de servicios ecosistémicos."""
    return EcosystemServicesService()


class TestEcosystemServicesValuation:
    """Tests de valoración de servicios ecosistémicos."""
    
    def test_valuate_polygon_basic(self, ecosystem_service):
        """Test básico de valoración de polígono."""
        result = ecosystem_service.valuate_polygon(
            polygon_id="test_001",
            area_hectares=100,
            biome_type=BiomeType.URBAN_GREEN,
            region="zona_central"
        )
        
        assert isinstance(result, EcosystemValuationResult)
        assert result.polygon_id == "test_001"
        assert result.area_hectares == 100
        assert result.total_annual_value_usd > 0
        assert result.npv_usd > 0
        
    def test_valuate_different_biomes(self, ecosystem_service):
        """Test de valoración para diferentes biomas."""
        biomes = [BiomeType.TROPICAL_FOREST, BiomeType.WETLAND, BiomeType.COASTAL]
        
        results = {}
        for biome in biomes:
            result = ecosystem_service.valuate_polygon(
                polygon_id=f"test_{biome.value}",
                area_hectares=10,
                biome_type=biome
            )
            results[biome] = result.total_annual_value_usd
        
        # Los biomas tienen diferentes valores
        assert len(set(results.values())) > 1
        
    def test_area_proportionality(self, ecosystem_service):
        """Verifica que el valor sea proporcional al área."""
        result_10ha = ecosystem_service.valuate_polygon(
            polygon_id="test_10ha",
            area_hectares=10,
            biome_type=BiomeType.URBAN_GREEN
        )
        
        result_20ha = ecosystem_service.valuate_polygon(
            polygon_id="test_20ha",
            area_hectares=20,
            biome_type=BiomeType.URBAN_GREEN
        )
        
        # El doble de área debería dar aproximadamente el doble de valor
        ratio = result_20ha.total_annual_value_usd / result_10ha.total_annual_value_usd
        assert 1.9 < ratio < 2.1
        
    def test_regional_adjustment(self, ecosystem_service):
        """Test de ajuste regional."""
        result_central = ecosystem_service.valuate_polygon(
            polygon_id="test_central",
            area_hectares=10,
            biome_type=BiomeType.TEMPERATE_FOREST,
            region="zona_central"
        )
        
        result_sur = ecosystem_service.valuate_polygon(
            polygon_id="test_sur",
            area_hectares=10,
            biome_type=BiomeType.TEMPERATE_FOREST,
            region="zona_sur"
        )
        
        # Zona sur tiene factor 1.1, debería ser mayor
        assert result_sur.total_annual_value_usd > result_central.total_annual_value_usd
        
    def test_services_breakdown(self, ecosystem_service):
        """Verifica que se incluya desglose de servicios."""
        result = ecosystem_service.valuate_polygon(
            polygon_id="test_breakdown",
            area_hectares=50,
            biome_type=BiomeType.WETLAND
        )
        
        assert len(result.services_breakdown) > 0
        
        # Verificar estructura de cada servicio
        for service in result.services_breakdown:
            assert service.service is not None
            assert service.annual_value_usd_ha > 0
            assert service.confidence_level in ["low", "medium", "high"]
            
    def test_npv_calculation(self, ecosystem_service):
        """Verifica cálculo de NPV."""
        result = ecosystem_service.valuate_polygon(
            polygon_id="test_npv",
            area_hectares=10,
            biome_type=BiomeType.URBAN_GREEN,
            discount_rate=0.03,
            time_horizon_years=30
        )
        
        # NPV debería ser mayor que valor anual pero menor que suma simple
        assert result.npv_usd > result.total_annual_value_usd
        assert result.npv_usd < result.total_annual_value_usd * 30
        
    def test_discount_rate_effect(self, ecosystem_service):
        """Verifica efecto de tasa de descuento en NPV."""
        result_low_rate = ecosystem_service.valuate_polygon(
            polygon_id="test_low",
            area_hectares=10,
            biome_type=BiomeType.URBAN_GREEN,
            discount_rate=0.02
        )
        
        result_high_rate = ecosystem_service.valuate_polygon(
            polygon_id="test_high",
            area_hectares=10,
            biome_type=BiomeType.URBAN_GREEN,
            discount_rate=0.08
        )
        
        # Mayor tasa de descuento = menor NPV
        assert result_low_rate.npv_usd > result_high_rate.npv_usd
        
    def test_confidence_levels(self, ecosystem_service):
        """Verifica niveles de confianza."""
        result = ecosystem_service.valuate_polygon(
            polygon_id="test_confidence",
            area_hectares=10,
            biome_type=BiomeType.TROPICAL_FOREST
        )
        
        assert result.confidence in ["low", "medium", "high"]


class TestProjectImpact:
    """Tests de evaluación de impacto de proyectos."""
    
    def test_project_impact_basic(self, ecosystem_service):
        """Test básico de impacto de proyecto."""
        affected_areas = [
            {
                "id": "area_1",
                "biome_type": "urban_green",
                "area_hectares": 5,
                "change_factor": 0.3,  # 70% de pérdida
                "region": "zona_central"
            }
        ]
        
        result = ecosystem_service.valuate_project_impact(
            project_id="proyecto_001",
            affected_areas=affected_areas,
            scenario="with_project"
        )
        
        assert result["project_id"] == "proyecto_001"
        assert result["total_annual_impact_usd"] < 0  # Impacto negativo
        
    def test_project_impact_multiple_areas(self, ecosystem_service):
        """Test de impacto con múltiples áreas."""
        affected_areas = [
            {"id": "a1", "biome_type": "urban_green", "area_hectares": 5, "change_factor": 0.5},
            {"id": "a2", "biome_type": "wetland", "area_hectares": 2, "change_factor": 0.2}
        ]
        
        result = ecosystem_service.valuate_project_impact(
            project_id="proyecto_multi",
            affected_areas=affected_areas
        )
        
        assert result["total_areas_analyzed"] == 2
        assert len(result["area_details"]) == 2


class TestScenarioComparison:
    """Tests de comparación de escenarios."""
    
    def test_scenario_comparison(self, ecosystem_service):
        """Test de comparación de escenarios de uso de suelo."""
        result = ecosystem_service.compare_scenarios(
            polygon_id="test_compare",
            area_hectares=20,
            current_biome=BiomeType.AGRICULTURAL,
            proposed_biome=BiomeType.URBAN_GREEN,
            region="zona_central"
        )
        
        assert "current_scenario" in result
        assert "proposed_scenario" in result
        assert "change" in result
        assert "recommendation" in result


class TestBiomeServices:
    """Tests de matriz bioma-servicios."""
    
    def test_get_biome_services(self, ecosystem_service):
        """Test de obtención de servicios por bioma."""
        matrix = ecosystem_service.get_biome_services(BiomeType.TROPICAL_FOREST)
        
        assert matrix.biome == BiomeType.TROPICAL_FOREST
        assert len(matrix.services) > 0
        assert matrix.total_annual_value_usd_ha > 0
        
    def test_available_biomes(self, ecosystem_service):
        """Test de lista de biomas disponibles."""
        biomes = ecosystem_service.get_available_biomes()
        
        assert len(biomes) > 0
        for biome in biomes:
            assert "biome_type" in biome
            assert "total_annual_value_usd_ha" in biome


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
