"""
DATAPOLIS v4.0 - Tests del Módulo Hedónico (M-HED)
===================================================
Tests de coherencia y funcionalidad para el módulo de precios hedónicos.
"""

import pytest
import numpy as np
import pandas as pd
from app.services.m_hedonic import (
    HedonicPricingService, ModelType, HedonicResult
)


@pytest.fixture
def hedonic_service():
    """Instancia del servicio hedónico."""
    return HedonicPricingService()


@pytest.fixture
def sample_data():
    """Genera datos de ejemplo para tests."""
    np.random.seed(42)
    n = 100
    
    superficie = 50 + np.random.uniform(0, 150, n)
    dormitorios = np.random.randint(1, 5, n)
    banos = np.random.randint(1, 4, n)
    antiguedad = np.random.randint(0, 30, n)
    distancia_metro = 100 + np.random.uniform(0, 2000, n)
    
    # Precio con relación hedónica conocida
    precio = (50000000 + 
              superficie * 800000 + 
              dormitorios * 15000000 + 
              banos * 8000000 - 
              antiguedad * 500000 - 
              distancia_metro * 5000 + 
              np.random.normal(0, 10000000, n))
    
    precio = np.maximum(precio, 30000000)  # Precio mínimo
    
    return pd.DataFrame({
        'precio': precio,
        'superficie': superficie,
        'dormitorios': dormitorios,
        'banos': banos,
        'antiguedad': antiguedad,
        'distancia_metro': distancia_metro
    })


class TestHedonicPricingService:
    """Tests del servicio de precios hedónicos."""
    
    def test_ols_estimation(self, hedonic_service, sample_data):
        """Test de estimación OLS lineal."""
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=['superficie', 'dormitorios', 'banos'],
            model_type=ModelType.OLS_LINEAR
        )
        
        assert isinstance(result, HedonicResult)
        assert result.model_type == ModelType.OLS_LINEAR
        assert result.n_observations == len(sample_data)
        assert len(result.coefficients) == 4  # const + 3 variables
        
    def test_log_linear_estimation(self, hedonic_service, sample_data):
        """Test de estimación log-lineal."""
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=['superficie', 'dormitorios'],
            model_type=ModelType.LOG_LINEAR
        )
        
        assert result.model_type == ModelType.LOG_LINEAR
        assert result.diagnostics is not None
        
    def test_coefficients_presence(self, hedonic_service, sample_data):
        """Verifica que se generen coeficientes para todas las variables."""
        variables = ['superficie', 'dormitorios', 'banos']
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=variables,
            model_type=ModelType.OLS_LINEAR
        )
        
        coef_names = [c.variable for c in result.coefficients]
        
        assert 'const' in coef_names
        for var in variables:
            assert var in coef_names
    
    def test_diagnostics_computed(self, hedonic_service, sample_data):
        """Verifica que los diagnósticos se calculen."""
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=['superficie', 'dormitorios'],
            model_type=ModelType.OLS_LINEAR,
            include_diagnostics=True
        )
        
        diag = result.diagnostics
        assert diag is not None
        assert 0 <= diag.r_squared <= 1
        assert diag.adj_r_squared <= diag.r_squared
        assert diag.aic is not None
        assert diag.bic is not None
        assert diag.durbin_watson is not None
        
    def test_vif_calculation(self, hedonic_service, sample_data):
        """Verifica que se calculen los VIF."""
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=['superficie', 'dormitorios', 'banos'],
            model_type=ModelType.OLS_LINEAR
        )
        
        assert result.diagnostics.vif_scores is not None
        assert len(result.diagnostics.vif_scores) == 3
        
    def test_significance_detection(self, hedonic_service, sample_data):
        """Verifica detección de variables significativas."""
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=['superficie', 'dormitorios'],
            model_type=ModelType.OLS_LINEAR
        )
        
        # Con datos generados, superficie y dormitorios deberían ser significativos
        significant_count = sum(1 for c in result.coefficients if c.is_significant)
        assert significant_count >= 2  # Al menos algunas variables significativas
        
    def test_implicit_prices(self, hedonic_service, sample_data):
        """Verifica cálculo de precios implícitos."""
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=['superficie'],
            model_type=ModelType.OLS_LINEAR
        )
        
        superficie_coef = next(c for c in result.coefficients if c.variable == 'superficie')
        assert superficie_coef.implicit_price is not None
        assert superficie_coef.implicit_price > 0  # Precio por m² positivo
        
    def test_model_comparison(self, hedonic_service, sample_data):
        """Test de comparación de modelos."""
        results = hedonic_service.compare_models(
            data=sample_data,
            dep_var='precio',
            indep_vars=['superficie', 'dormitorios']
        )
        
        assert len(results) >= 2
        assert 'ols_linear' in results
        assert 'log_linear' in results
        
    def test_best_model_selection(self, hedonic_service, sample_data):
        """Test de selección del mejor modelo."""
        results = hedonic_service.compare_models(
            data=sample_data,
            dep_var='precio',
            indep_vars=['superficie', 'dormitorios']
        )
        
        best = hedonic_service.select_best_model(results)
        assert best in results
        
    def test_box_cox_estimation(self, hedonic_service, sample_data):
        """Test de estimación Box-Cox."""
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=['superficie', 'dormitorios'],
            model_type=ModelType.BOX_COX
        )
        
        assert result.model_type == ModelType.BOX_COX
        assert result.box_cox_lambda is not None
        
    def test_invalid_data_raises_error(self, hedonic_service):
        """Verifica que datos inválidos generen error."""
        df = pd.DataFrame({'precio': [100, 200], 'x': [1, None]})
        
        with pytest.raises(ValueError):
            hedonic_service.estimate(
                data=df,
                dependent_var='precio',
                independent_vars=['x'],
                model_type=ModelType.OLS_LINEAR
            )
            
    def test_missing_variable_raises_error(self, hedonic_service, sample_data):
        """Verifica error con variable inexistente."""
        with pytest.raises(ValueError):
            hedonic_service.estimate(
                data=sample_data,
                dependent_var='precio',
                independent_vars=['variable_inexistente'],
                model_type=ModelType.OLS_LINEAR
            )


class TestHedonicElasticities:
    """Tests específicos para elasticidades."""
    
    def test_log_log_elasticity(self, hedonic_service, sample_data):
        """En log-log, el coeficiente es la elasticidad."""
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=['superficie'],
            model_type=ModelType.LOG_LOG
        )
        
        superficie_coef = next(c for c in result.coefficients if c.variable == 'superficie')
        
        # En log-log, elasticidad ≈ coeficiente
        if superficie_coef.elasticity is not None:
            assert abs(superficie_coef.elasticity - superficie_coef.coefficient) < 0.01


class TestHedonicSensitivity:
    """Tests de análisis de sensibilidad."""
    
    def test_sensitivity_analysis_present(self, hedonic_service, sample_data):
        """Verifica que se genere análisis de sensibilidad."""
        result = hedonic_service.estimate(
            data=sample_data,
            dependent_var='precio',
            independent_vars=['superficie', 'dormitorios'],
            model_type=ModelType.OLS_LINEAR
        )
        
        assert result.sensitivity_analysis is not None
        assert 'superficie' in result.sensitivity_analysis
        assert 'dormitorios' in result.sensitivity_analysis


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
