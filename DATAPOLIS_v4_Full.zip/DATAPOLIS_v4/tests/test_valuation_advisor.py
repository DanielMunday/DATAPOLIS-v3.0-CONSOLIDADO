"""
DATAPOLIS v4.0 - Tests del Asistente de Métodos de Valuación (M-VAD)
=====================================================================
Tests de recomendaciones del Valuation Advisor.
"""

import pytest
from app.services.m_valuation_advisor import (
    ValuationAdvisorService, ValuationContext, AssetType,
    ValuationPurpose, TimeHorizon, DataQuality, ValuationMethod
)


@pytest.fixture
def advisor():
    """Instancia del servicio advisor."""
    return ValuationAdvisorService()


class TestValuationAdvisorRecommendations:
    """Tests de recomendaciones del advisor."""
    
    def test_residential_collateral_recommendation(self, advisor):
        """Test de recomendación para residencial como colateral."""
        context = ValuationContext(
            asset_type=AssetType.RESIDENTIAL_PROPERTY,
            purpose=ValuationPurpose.COLLATERAL,
            time_horizon=TimeHorizon.SPOT,
            data_quality=DataQuality.GOOD,
            market_activity="active",
            income_producing=False,
            comparable_availability=75
        )
        
        result = advisor.get_recommendation(context)
        
        assert result.primary_recommendation is not None
        assert result.primary_recommendation.basel_compliant == True
        # Para colateral, debería recomendar métodos compliance
        
    def test_commercial_investment_recommendation(self, advisor):
        """Test de recomendación para comercial como inversión."""
        context = ValuationContext(
            asset_type=AssetType.COMMERCIAL_PROPERTY,
            purpose=ValuationPurpose.INVESTMENT_ANALYSIS,
            time_horizon=TimeHorizon.MEDIUM_TERM,
            data_quality=DataQuality.GOOD,
            market_activity="moderate",
            income_producing=True,
            comparable_availability=50
        )
        
        result = advisor.get_recommendation(context)
        
        # Para activo que genera ingresos, debería sugerir DCF o capitalización
        recommended_methods = [result.primary_recommendation.method]
        recommended_methods.extend([r.method for r in result.alternative_recommendations])
        
        income_methods = [ValuationMethod.DCF, ValuationMethod.INCOME_CAPITALIZATION]
        assert any(m in recommended_methods for m in income_methods)
        
    def test_natural_asset_esg_recommendation(self, advisor):
        """Test de recomendación para activo natural con propósito ESG."""
        context = ValuationContext(
            asset_type=AssetType.NATURAL_ASSET,
            purpose=ValuationPurpose.ESG_REPORTING,
            time_horizon=TimeHorizon.LONG_TERM,
            data_quality=DataQuality.MODERATE,
            market_activity="none",
            income_producing=False,
            comparable_availability=10
        )
        
        result = advisor.get_recommendation(context)
        
        # Para ESG debería recomendar métodos de capital natural/ecosistemas
        esg_methods = [
            ValuationMethod.ECOSYSTEM_SERVICES, 
            ValuationMethod.NATURAL_CAPITAL_ACCOUNTING
        ]
        
        recommended = result.primary_recommendation.method
        alternatives = [r.method for r in result.alternative_recommendations]
        
        assert recommended in esg_methods or any(m in alternatives for m in esg_methods)
        
    def test_low_comparable_availability(self, advisor):
        """Test con baja disponibilidad de comparables."""
        context = ValuationContext(
            asset_type=AssetType.SPECIAL_USE,
            purpose=ValuationPurpose.MARKET_TRANSACTION,
            time_horizon=TimeHorizon.SPOT,
            data_quality=DataQuality.LIMITED,
            market_activity="limited",
            income_producing=False,
            comparable_availability=15
        )
        
        result = advisor.get_recommendation(context)
        
        # Con pocos comparables, no debería recomendar market comparison como primario
        if result.primary_recommendation.method == ValuationMethod.MARKET_COMPARISON:
            assert result.primary_recommendation.suitability_score < 60
            
    def test_recommendation_contains_required_fields(self, advisor):
        """Verifica que la recomendación tenga todos los campos."""
        context = ValuationContext(
            asset_type=AssetType.LAND,
            purpose=ValuationPurpose.TAX_ASSESSMENT,
            time_horizon=TimeHorizon.SPOT,
            data_quality=DataQuality.MODERATE,
            market_activity="moderate",
            income_producing=False,
            comparable_availability=50
        )
        
        result = advisor.get_recommendation(context)
        
        # Verificar campos de la recomendación principal
        rec = result.primary_recommendation
        assert rec.method is not None
        assert rec.suitability_score is not None
        assert rec.rationale is not None
        assert rec.strengths is not None
        assert rec.limitations is not None
        assert rec.data_requirements is not None
        assert rec.datapolis_module is not None
        
    def test_alternative_recommendations(self, advisor):
        """Verifica que se generen alternativas."""
        context = ValuationContext(
            asset_type=AssetType.RESIDENTIAL_PROPERTY,
            purpose=ValuationPurpose.MARKET_TRANSACTION,
            time_horizon=TimeHorizon.SPOT,
            data_quality=DataQuality.GOOD,
            market_activity="active",
            income_producing=False,
            comparable_availability=80
        )
        
        result = advisor.get_recommendation(context)
        
        # Debería haber alternativas
        assert len(result.alternative_recommendations) > 0
        
        # Las alternativas deberían tener menor score que la principal
        for alt in result.alternative_recommendations:
            assert alt.suitability_score <= result.primary_recommendation.suitability_score
            
    def test_regulatory_notes_for_collateral(self, advisor):
        """Verifica notas regulatorias para colaterales."""
        context = ValuationContext(
            asset_type=AssetType.COMMERCIAL_PROPERTY,
            purpose=ValuationPurpose.COLLATERAL,
            time_horizon=TimeHorizon.SPOT,
            data_quality=DataQuality.GOOD,
            market_activity="active",
            income_producing=True,
            comparable_availability=60
        )
        
        result = advisor.get_recommendation(context)
        
        # Debería mencionar regulaciones relevantes
        assert "NCG 514" in result.regulatory_notes or "Basel" in result.regulatory_notes


class TestMethodDetails:
    """Tests de detalles de métodos."""
    
    def test_get_method_details(self, advisor):
        """Test de obtención de detalles de método."""
        details = advisor.get_method_details(ValuationMethod.HEDONIC_PRICING)
        
        assert "description" in details
        assert "strengths" in details
        assert "limitations" in details
        assert "datapolis_module" in details
        
    def test_list_methods(self, advisor):
        """Test de listado de métodos."""
        methods = advisor.list_available_methods()
        
        assert len(methods) > 5
        for method in methods:
            assert "method" in method
            assert "description" in method


class TestHybridApproach:
    """Tests de enfoque híbrido."""
    
    def test_hybrid_suggestion_when_appropriate(self, advisor):
        """Verifica sugerencia de híbrido cuando es apropiado."""
        context = ValuationContext(
            asset_type=AssetType.RESIDENTIAL_PROPERTY,
            purpose=ValuationPurpose.INVESTMENT_ANALYSIS,
            time_horizon=TimeHorizon.MEDIUM_TERM,
            data_quality=DataQuality.EXCELLENT,
            market_activity="active",
            income_producing=False,
            comparable_availability=80
        )
        
        result = advisor.get_recommendation(context)
        
        # Puede o no sugerir híbrido, pero si lo hace debe tener estructura
        if result.hybrid_approach:
            assert "approach" in result.hybrid_approach
            assert "description" in result.hybrid_approach


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
