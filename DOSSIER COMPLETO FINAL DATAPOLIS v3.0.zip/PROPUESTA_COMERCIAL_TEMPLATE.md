# ══════════════════════════════════════════════════════════════════════════════
#                              DATAPOLIS v3.0
#                         PROPUESTA COMERCIAL
#                   Plantilla para Clientes Potenciales
# ══════════════════════════════════════════════════════════════════════════════

---

# PROPUESTA COMERCIAL
## [NOMBRE DEL CLIENTE]

**Fecha:** [FECHA]
**Válida hasta:** [FECHA + 30 días]
**Preparada por:** DATAPOLIS SpA

---

## 1. RESUMEN EJECUTIVO

Estimados [NOMBRE],

En respuesta a su interés en optimizar la gestión de sus copropiedades, nos complace presentar esta propuesta de implementación de **DATAPOLIS**, la plataforma más completa del mercado chileno para administración de condominios.

### Su Situación Actual

| Aspecto | Situación Identificada |
|---------|----------------------|
| Copropiedades administradas | [X] |
| Total de unidades | [X] |
| Contratos de antenas | [X] |
| Sistema actual | [Excel/Manual/Otro] |
| Cumplimiento Ley 21.442 | [Estado] |

### Nuestra Propuesta

DATAPOLIS le permitirá:

- ✅ Automatizar el 80% de las tareas administrativas
- ✅ Cumplir automáticamente con Ley 21.442 y 21.713
- ✅ Gestionar tributación de antenas sin riesgo fiscal
- ✅ Reducir morosidad con herramientas inteligentes
- ✅ Obtener insights predictivos con nuestro motor PAE

---

## 2. SOLUCIÓN PROPUESTA

### 2.1 Plan Recomendado

Basado en su volumen de [X] copropiedades con [X] unidades totales:

| Plan | Descripción | Precio/mes |
|------|-------------|------------|
| **[PLAN RECOMENDADO]** | [Descripción] | UF [X] |

### 2.2 Módulos Incluidos

#### Módulos Core (Todos los planes)
- ✅ M01: Multi-tenancy (aislamiento de datos)
- ✅ M02: Usuarios y Roles (control de acceso)
- ✅ M03: Copropiedades (gestión centralizada)
- ✅ M04: Unidades (registro de copropietarios)
- ✅ M05: Gastos Comunes (prorrateo automático)
- ✅ M08: Morosidad (cobranza inteligente)

#### Módulos Avanzados (Plan Professional+)
- ✅ M06: Contabilidad Completa (libro diario, balance, certificados)
- ✅ M07: Gestión de Antenas (tributación automática)
- ✅ M09: Fondo de Reserva (cumplimiento legal)
- ✅ M12: Asambleas (convocatoria y actas digitales)

#### Módulos Premium (Plan Enterprise+)
- ✅ M10: Compliance (evaluación Ley 21.442)
- ✅ M11: Motor PAE (análisis predictivo)
- ✅ M22: ÁGORA (inteligencia territorial)
- ✅ M23: Dashboard Ejecutivo

### 2.3 Beneficios Específicos para [CLIENTE]

| Problema Actual | Solución DATAPOLIS | Beneficio |
|-----------------|-------------------|-----------|
| [Problema 1] | [Solución] | [Beneficio cuantificable] |
| [Problema 2] | [Solución] | [Beneficio cuantificable] |
| [Problema 3] | [Solución] | [Beneficio cuantificable] |

---

## 3. INVERSIÓN

### 3.1 Costos Mensuales

| Concepto | Cantidad | Precio Unitario | Total Mensual |
|----------|----------|-----------------|---------------|
| Licencia [PLAN] | [X] copropiedades | UF [X] | UF [X] |
| Soporte incluido | - | - | Incluido |
| **TOTAL MENSUAL** | | | **UF [X]** |

### 3.2 Costos Únicos (Implementación)

| Concepto | Descripción | Inversión |
|----------|-------------|-----------|
| Setup inicial | Configuración de cuenta y copropiedades | UF [X] |
| Migración de datos | Importación de información histórica | UF [X] |
| Capacitación | [X] horas de entrenamiento | UF [X] |
| **TOTAL IMPLEMENTACIÓN** | | **UF [X]** |

### 3.3 Oferta Especial de Lanzamiento

**Por ser uno de nuestros primeros [X] clientes:**

| Beneficio | Valor Normal | Valor Promocional |
|-----------|--------------|-------------------|
| Descuento mensual | - | 40% de por vida |
| Implementación | UF [X] | **GRATIS** |
| Capacitación adicional | UF [X] | **GRATIS** |
| Soporte premium (3 meses) | UF [X] | **GRATIS** |

**Precio final mensual: UF [X] (en vez de UF [X])**

*Oferta válida hasta [FECHA]*

---

## 4. RETORNO DE INVERSIÓN

### 4.1 Ahorro en Tiempo

| Tarea | Tiempo Actual | Con DATAPOLIS | Ahorro |
|-------|---------------|---------------|--------|
| Generación de cobros | [X] horas/mes | [X] minutos | [X] horas |
| Registro de pagos | [X] horas/mes | Automático | [X] horas |
| Informes financieros | [X] horas/mes | 1 clic | [X] horas |
| Gestión de morosidad | [X] horas/mes | [X] minutos | [X] horas |
| Contabilidad | [X] horas/mes | Automático | [X] horas |
| **TOTAL MENSUAL** | **[X] horas** | **[X] horas** | **[X] horas** |

### 4.2 Ahorro Económico Proyectado

| Concepto | Ahorro Mensual | Ahorro Anual |
|----------|----------------|--------------|
| Horas administrativas | $[X] | $[X] |
| Evitar multas SII (antenas) | $[X] | $[X] |
| Reducción morosidad (15%) | $[X] | $[X] |
| Eficiencia operativa | $[X] | $[X] |
| **TOTAL AHORRO** | **$[X]** | **$[X]** |

### 4.3 ROI Calculado

| Métrica | Valor |
|---------|-------|
| Inversión mensual | UF [X] |
| Ahorro mensual estimado | UF [X] |
| **ROI** | **[X]x** |
| Payback | [X] meses |

---

## 5. IMPLEMENTACIÓN

### 5.1 Cronograma

| Fase | Actividad | Duración | Responsable |
|------|-----------|----------|-------------|
| 1 | Kick-off y planificación | 1 día | DATAPOLIS + Cliente |
| 2 | Configuración inicial | 2-3 días | DATAPOLIS |
| 3 | Migración de datos | 3-5 días | DATAPOLIS |
| 4 | Capacitación equipo | 2-4 horas | DATAPOLIS |
| 5 | Go-live asistido | 1 semana | DATAPOLIS |
| 6 | Soporte post-implementación | 30 días | DATAPOLIS |

**Tiempo total estimado: 2-3 semanas**

### 5.2 Requerimientos del Cliente

| Requerimiento | Descripción |
|---------------|-------------|
| Designar responsable | Persona de contacto para el proyecto |
| Acceso a datos | Información histórica de copropiedades |
| Disponibilidad | Tiempo para capacitación y validación |
| Conexión internet | Para acceso a la plataforma |

### 5.3 Entregables

| Entregable | Descripción |
|------------|-------------|
| Plataforma configurada | Todas las copropiedades cargadas |
| Datos migrados | Histórico importado y validado |
| Usuarios creados | Accesos para todo el equipo |
| Manual de usuario | Documentación completa |
| Capacitación completada | Equipo entrenado |

---

## 6. SOPORTE Y GARANTÍAS

### 6.1 Niveles de Soporte

| Nivel | Incluido en | Características |
|-------|-------------|-----------------|
| Básico | Todos | Email, respuesta 24-48 horas |
| Estándar | Professional+ | + Chat, respuesta 8 horas |
| Premium | Enterprise+ | + Teléfono, respuesta 4 horas |
| VIP | Corporate | + Ejecutivo dedicado, respuesta 1 hora |

### 6.2 Garantías

| Garantía | Compromiso |
|----------|------------|
| Uptime | 99.5% disponibilidad mensual |
| Datos | Backup diario automático |
| Seguridad | Encriptación en reposo y tránsito |
| Actualizaciones | Incluidas sin costo adicional |
| Satisfacción | 30 días de prueba con reembolso |

### 6.3 SLA (Service Level Agreement)

| Severidad | Descripción | Tiempo Respuesta | Tiempo Resolución |
|-----------|-------------|------------------|-------------------|
| Crítica | Sistema no disponible | 1 hora | 4 horas |
| Alta | Funcionalidad crítica afectada | 4 horas | 24 horas |
| Media | Funcionalidad no crítica afectada | 8 horas | 48 horas |
| Baja | Consultas y mejoras | 24 horas | 5 días |

---

## 7. TÉRMINOS Y CONDICIONES

### 7.1 Contratación

- Contrato mínimo: 12 meses
- Facturación: Mensual anticipada
- Método de pago: Transferencia bancaria, tarjeta de crédito
- Moneda: UF (Unidad de Fomento)

### 7.2 Renovación

- Renovación automática por períodos iguales
- Aviso de no renovación: 30 días antes del vencimiento
- Ajuste de precios: Máximo IPC anual

### 7.3 Cancelación

- Aviso: 30 días de anticipación
- Datos: Exportación disponible por 30 días post-cancelación
- Sin penalidades después del período mínimo

---

## 8. PRÓXIMOS PASOS

### Para Aceptar Esta Propuesta:

1. ☐ Confirmar aceptación por email
2. ☐ Completar formulario de onboarding
3. ☐ Programar kick-off meeting
4. ☐ Designar responsable del proyecto
5. ☐ Proporcionar acceso a datos históricos

### Contacto

| Rol | Nombre | Email | Teléfono |
|-----|--------|-------|----------|
| Ejecutivo Comercial | [Nombre] | [Email] | [Teléfono] |
| Soporte Técnico | Equipo DATAPOLIS | soporte@datapolis.cl | - |
| Gerencia | [Nombre] | [Email] | [Teléfono] |

---

## 9. ACEPTACIÓN

Al firmar este documento, [NOMBRE DEL CLIENTE] acepta los términos y condiciones de esta propuesta comercial.

| | |
|---|---|
| **Cliente:** | _________________________ |
| **Nombre:** | _________________________ |
| **Cargo:** | _________________________ |
| **RUT:** | _________________________ |
| **Fecha:** | _________________________ |
| **Firma:** | _________________________ |

| | |
|---|---|
| **DATAPOLIS SpA** | _________________________ |
| **Nombre:** | _________________________ |
| **Cargo:** | _________________________ |
| **RUT:** | _________________________ |
| **Fecha:** | _________________________ |
| **Firma:** | _________________________ |

---

## ANEXOS

### Anexo A: Especificaciones Técnicas
### Anexo B: Política de Privacidad
### Anexo C: Términos de Servicio
### Anexo D: SLA Detallado

---

**DATAPOLIS SpA**
📧 contacto@datapolis.cl
🌐 www.datapolis.cl
📍 Santiago, Chile

*Transformando la gestión de copropiedades*
*PropTech | FinTech | RegTech | GeoTech | GovTech*

© 2026 DATAPOLIS SpA - Propuesta Confidencial
